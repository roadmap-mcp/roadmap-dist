"""Git diff viewer plugin activator.

Frontend-only: the viewer page is contributed via the frontend PageRegistry
(``frontend/src/register.ts``). The diff *data* comes from the context plugin's
``GET /api/contexts/meta/repo-diff/{repo_name}`` — repositories are context config —
so there is no backend router here. Declaring ``requires = ["roadmap.context"]``
keeps the two enabled together per workspace and orders activation.
"""

from roadmap_framework import Plugin, PluginContext


class GitDiffPlugin(Plugin):
    id = "roadmap.gitdiff"
    name = "Git Diff Viewer"
    requires = ["roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        # No backend surface — the page consumes the context plugin's repo-diff route.
        pass
