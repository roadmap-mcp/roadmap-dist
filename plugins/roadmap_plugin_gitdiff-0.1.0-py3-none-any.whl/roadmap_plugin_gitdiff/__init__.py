"""Git diff viewer plugin — a frontend page that renders a repository's
working-directory diff. The diff *data* is served by the context plugin's existing
``GET /api/contexts/meta/repo-diff/{repo_name}`` (repositories are context config), so
this plugin ships no backend router — only the viewer page."""
