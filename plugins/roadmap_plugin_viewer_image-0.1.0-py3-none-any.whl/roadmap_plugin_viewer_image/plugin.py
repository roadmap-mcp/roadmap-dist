"""Image viewer plugin activator — contributes an image viewer to the host's
``roadmap.viewers`` point. The image bytes are served by the host's existing
``/api/browse-dir/image`` endpoint, so there is no backend router here."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_fileviewer import VIEWERS_POINT, FileViewer

IMAGE_VIEWER = FileViewer(
    extensions=[".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg", ".ico"],
    kind="image",
    label="Image",
)


class ImageViewerPlugin(Plugin):
    id = "roadmap.viewer.image"
    name = "Image Viewer"
    requires = ["roadmap.fileviewer"]

    def activate(self, ctx: PluginContext) -> None:
        ctx.extend(VIEWERS_POINT, IMAGE_VIEWER)
