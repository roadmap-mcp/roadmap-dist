"""Image viewer plugin — contributes an image file viewer (png/jpg/gif/svg/…)."""
