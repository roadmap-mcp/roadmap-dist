"""Git Repos plugin — the local git working copies an installation reads.

The ``repositories`` list of the config document (``{name, path, tags}`` each) is
its settings slice. Readers use the ``git_repos`` service (or, as the knowledge base
flows do, read the slice directly); contexts add repos as items on top of it.
"""
