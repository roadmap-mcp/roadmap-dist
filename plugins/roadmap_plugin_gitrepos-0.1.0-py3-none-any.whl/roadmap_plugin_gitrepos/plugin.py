"""Git Repos plugin activator — the Git Repos settings tab (it owns the
``repositories`` list), the ``git_repos`` service, ``GET /api/git-repos``, and the
``list_git_repos`` / ``get_git_repo_info`` MCP tools."""

from fastapi import APIRouter

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import repos

# id="repos": the tab's id has been "repos" since it was the edition's own.
REPOS_SECTION = SettingsSection(
    id="repos", label="Git Repos", order=30, group="Information Sources",
    defaults=lambda: {"repositories": []},
)


class GitReposService:
    """For plugins that read the configured repositories."""

    repositories = staticmethod(repos.repositories)
    find = staticmethod(repos.find)
    render_repo_detail = staticmethod(repos.render_repo_detail)


def _router() -> APIRouter:
    router = APIRouter(prefix="/api/git-repos", tags=["git-repos"])

    @router.get("")
    def list_repos():
        """The configured repositories (``name``, ``path``, ``tags``)."""
        return {"repositories": [{"name": r.name, "path": r.path, "tags": list(r.tags)}
                                 for r in repos.repositories()]}

    return router


def _register_tools(mcp) -> None:
    @mcp.tool()
    def list_git_repos() -> str:
        """List the git repositories configured in this workspace (Settings ->
        Git Repos): their names and local checkout paths.

        Use get_git_repo_info() for one repository's branches and recent commits.
        """
        found = repos.repositories()
        if not found:
            return "No git repositories configured."
        lines = ["Available git repositories:\n"]
        for r in found:
            tags = f" ({', '.join(r.tags)})" if r.tags else ""
            lines.append(f"- **{r.name}**: `{r.path}`{tags}")
        return "\n".join(lines)

    @mcp.tool()
    def get_git_repo_info(repo_name: str) -> str:
        """One configured git repository: its checkout path, branches and recent
        commits.

        Args:
            repo_name: repository name as shown by list_git_repos()
        """
        repo = repos.find(repo_name)
        if repo is None:
            return f"Repository '{repo_name}' not found. Use list_git_repos() to see available names."
        return repos.render_repo_detail(repo.name, repo.name, repo.path)


class GitReposPlugin(Plugin):
    id = "roadmap.gitrepos"
    name = "Git Repos"
    requires = ["roadmap.settings", "roadmap.mcp"]

    def activate(self, ctx: PluginContext) -> None:
        repos.set_store(ctx.config)
        ctx.extend(SETTINGS_SECTIONS_POINT, REPOS_SECTION)
        ctx.services.register("git_repos", GitReposService())
        ctx.add_router(_router())
        _register_tools(ctx.services.require("mcp").mcp)
