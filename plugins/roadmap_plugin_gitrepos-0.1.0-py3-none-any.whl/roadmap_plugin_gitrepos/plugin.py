"""Git Repos plugin activator — the Git Repos settings tab (it owns the
``repositories`` list and the ``git_checkout`` folders), the ``git_repos`` service,
``GET /api/git-repos``, and the ``list_git_repos`` / ``get_git_repo_info`` MCP tools."""

from fastapi import APIRouter

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import repos

# id="repos": the tab's id has been "repos" since it was the edition's own.
REPOS_SECTION = SettingsSection(
    id="repos", label="Git Repos", order=30, group="Information Sources",
    defaults=lambda: {"repositories": [],
                      "git_checkout": {"server_folder": "", "local_folder": ""}},
    after_save=repos.normalise,
)


class GitReposService:
    """For plugins that read the configured repositories: each one's
    ``server_path`` (where git runs) and ``local_location`` (where it is on a
    user's machine, in words — what an AI working there is told)."""

    repositories = staticmethod(repos.repositories)
    find = staticmethod(repos.find)
    resolved_document = staticmethod(repos.resolved_document)
    render_repo_detail = staticmethod(repos.render_repo_detail)


def _as_json(r: repos.GitRepo) -> dict:
    return {"name": r.name, "folder": r.folder, "tags": list(r.tags),
            "server_path": r.server_path, "local_location": r.local_location}


def _router() -> APIRouter:
    router = APIRouter(prefix="/api/git-repos", tags=["git-repos"])

    @router.get("")
    def list_repos():
        """The configured repositories, each with where it is on the server and on
        a user's machine, and the two checkout folders they are resolved from."""
        server_folder, local_folder = repos.checkout_folders()
        return {"server_folder": server_folder, "local_folder": local_folder,
                "repositories": [_as_json(r) for r in repos.repositories()]}

    return router


def _register_tools(mcp) -> None:
    @mcp.tool()
    def list_git_repos() -> str:
        """List the git repositories configured in this workspace (Settings ->
        Git Repos): each one's name, where it is on your machine, and where it is
        on the Roadmap server.

        Use get_git_repo_info() for one repository's branches and recent commits.
        """
        found = repos.repositories()
        if not found:
            return "No git repositories configured."
        lines = ["Available git repositories:\n"]
        for r in found:
            tags = f" ({', '.join(r.tags)})" if r.tags else ""
            server = f"; on the Roadmap server: `{r.server_path}`" if r.server_path else ""
            lines.append(f"- **{r.name}**{tags}: on your machine: {r.local_location}{server}")
        return "\n".join(lines)

    @mcp.tool()
    def get_git_repo_info(repo_name: str) -> str:
        """One configured git repository: where it is (on your machine and on the
        Roadmap server), its branches and recent commits (read on the server).

        Args:
            repo_name: repository name as shown by list_git_repos()
        """
        repo = repos.find(repo_name)
        if repo is None:
            return f"Repository '{repo_name}' not found. Use list_git_repos() to see available names."
        return repos.render_repo_detail(repo.name, repo.name, repo.server_path, repo.local_location)


class GitReposPlugin(Plugin):
    id = "roadmap.gitrepos"
    name = "Git Repos"
    requires = ["roadmap.settings", "roadmap.mcp"]

    def activate(self, ctx: PluginContext) -> None:
        repos.set_store(ctx.config)
        ctx.extend(SETTINGS_SECTIONS_POINT, REPOS_SECTION)
        ctx.services.register("git_repos", GitReposService())
        ctx.add_router(_router())
        _register_tools(ctx.services.require("mcp").mcp)
