"""The configured git repositories and what reading one looks like.

Shared by this plugin's MCP tools and by the plugins that build on it (contexts
render a repo the same way when an agent asks about one).
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass

from roadmap_framework import ConfigStore

_store: ConfigStore | None = None


def set_store(store: ConfigStore) -> None:
    global _store
    _store = store


@dataclass(frozen=True)
class GitRepo:
    name: str
    path: str
    tags: tuple[str, ...] = ()


def repositories() -> list[GitRepo]:
    """The repositories configured in the current workspace."""
    assert _store is not None, "git repos runtime not initialised"
    raw = _store.load_decrypted().get("repositories") or []
    return [GitRepo(name=r.get("name", ""), path=r.get("path", ""),
                    tags=tuple(r.get("tags") or [])) for r in raw if isinstance(r, dict)]


def find(name: str) -> GitRepo | None:
    return next((r for r in repositories() if r.name == name), None)


def render_repo_detail(repo_name: str, label: str, path: str) -> str:
    """A git repo with its branches and recent commits, as Markdown."""
    lines = [
        f"## {label} (Git Repository)",
        f"**Repository:** {repo_name}",
        f"**Checkout path:** {path}",
    ]
    try:
        proc = subprocess.run(
            ["git", "branch", "-a", "--format=%(refname:short)"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            branches = [b for b in proc.stdout.strip().splitlines() if b][:20]
            if branches:
                lines.append(f"\n**Branches:** {', '.join(branches)}")

        proc = subprocess.run(
            ["git", "log", "--format=%h %aI %an\t%s", "-20"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            commit_lines = [l for l in proc.stdout.strip().splitlines() if l]
            if commit_lines:
                lines.append("\n**Recent commits:**")
                for line in commit_lines:
                    tab = line.find("\t")
                    if tab >= 0:
                        meta, msg = line[:tab], line[tab + 1:]
                        parts = meta.split(" ", 2)
                        if len(parts) >= 3:
                            h, date, author = parts[0], parts[1][:10], parts[2]
                            lines.append(f"- `{h}` {date} {author} — {msg}")
                        else:
                            lines.append(f"- {line}")
    except Exception:
        pass
    return "\n".join(lines)
