"""The configured git repositories, and where each one is.

A repository is a **name** and a **folder** (by default its name). Where that
folder lives depends on who is asking, so two settings say it once for all of them
(``git_checkout`` in the config document):

* ``server_folder`` — a real path on the machine Roadmap runs on. Whatever runs git
  on the server (the knowledge base's flows, the repo tools, a context's repo
  preview) reads ``<server_folder>/<folder>``.
* ``local_folder`` — a *description*, in words, of where users keep their clones:
  "the parent directory of the current project", "~/src". It differs from user
  to user, so it is not a path; it is what an AI working on a user's machine is
  told (``<local_folder>/<folder>``).

In a single-user install both are the same place, and the server folder is enough.
A repository written before these settings, with a full ``path`` of its own, keeps
working: its folder is the path's last part, and the path itself is used on the
server until the settings are saved (``normalise``), which moves it over.
"""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import PurePath

from roadmap_framework import ConfigStore

_store: ConfigStore | None = None


def set_store(store: ConfigStore) -> None:
    global _store
    _store = store


@dataclass(frozen=True)
class GitRepo:
    name: str
    folder: str
    tags: tuple[str, ...]
    #: where the checkout is on the machine Roadmap runs on ("" when not set up)
    server_path: str
    #: where it is on a user's machine, in words (for an AI working there); ""
    #: while the users'-machine checkout folder is not set
    local_location: str


def _checkout(raw: dict) -> tuple[str, str]:
    gc = raw.get("git_checkout") or {}
    return (str(gc.get("server_folder") or "").strip(),
            str(gc.get("local_folder") or "").strip())


def _join(parent: str, folder: str) -> str:
    if not parent:
        return folder
    return parent.rstrip("/\\") + ("\\" if "\\" in parent and "/" not in parent else "/") + folder


def _resolve(r: dict, server_folder: str, local_folder: str) -> GitRepo:
    legacy = str(r.get("path") or "").strip()
    folder = str(r.get("folder") or "").strip() or (PurePath(legacy).name if legacy else "") \
        or str(r.get("name") or "")
    name = str(r.get("name") or "") or folder
    if legacy:
        server = legacy                 # set before the checkout folders: still honoured
    elif server_folder:
        server = _join(server_folder, folder)
    else:
        server = ""
    local = _join(local_folder, folder) if local_folder else ""
    return GitRepo(name=name, folder=folder, tags=tuple(r.get("tags") or []),
                   server_path=server, local_location=local)


def resolve_all(raw: dict) -> list[GitRepo]:
    """The repositories of a config document, with both locations worked out."""
    server_folder, local_folder = _checkout(raw)
    # an entry with neither name, folder nor path names nothing — skipped, rather
    # than read as the whole checkout folder
    return [_resolve(r, server_folder, local_folder)
            for r in (raw.get("repositories") or []) if _names_something(r)]


def _names_something(r) -> bool:
    return isinstance(r, dict) and any(str(r.get(k) or "").strip()
                                       for k in ("name", "folder", "path"))


def resolved_document(raw: dict) -> dict:
    """``raw`` with each repository given ``path`` (its server path), ``folder`` and
    ``local`` — for code that reads ``repositories`` straight from the document and
    runs git on the server (contexts' repo preview, diff, tree)."""
    out = dict(raw)
    out["repositories"] = [
        {"name": g.name, "folder": g.folder, "tags": list(g.tags),
         "path": g.server_path, "local": g.local_location}
        for g in resolve_all(raw)]
    return out


def repositories() -> list[GitRepo]:
    """The repositories configured in the current workspace."""
    assert _store is not None, "git repos runtime not initialised"
    return resolve_all(_store.load_decrypted())


def find(name: str) -> GitRepo | None:
    return next((r for r in repositories() if r.name == name), None)


def checkout_folders() -> tuple[str, str]:
    """``(server_folder, local_folder)`` of the current workspace."""
    assert _store is not None, "git repos runtime not initialised"
    return _checkout(_store.load_decrypted())


def normalise() -> None:
    """Move repositories written with a full ``path`` over to ``folder`` +
    ``server_folder``: the first one's parent becomes the server folder when none
    is set, and a path under it becomes just its folder. A path elsewhere stays,
    and keeps working, as that repository's own."""
    assert _store is not None, "git repos runtime not initialised"
    raw = _store.load_decrypted()
    repos = raw.get("repositories") or []
    gc = dict(raw.get("git_checkout") or {})
    changed = False
    kept = [r for r in repos if _names_something(r)]
    if len(kept) != len(repos):          # an empty entry is dropped
        raw["repositories"] = repos = kept
        changed = True
    for r in repos:
        if not isinstance(r, dict) or not str(r.get("path") or "").strip():
            continue
        p = PurePath(str(r["path"]).strip())
        if not str(gc.get("server_folder") or "").strip():
            gc["server_folder"] = str(p.parent)
            changed = True
        if PurePath(str(gc["server_folder"])) == p.parent:
            r["folder"] = r.get("folder") or p.name
            r.pop("path", None)
            changed = True
    if changed:
        gc.setdefault("local_folder", "")
        raw["git_checkout"] = gc
        _store.save(raw)


def render_repo_detail(repo_name: str, label: str, path: str, local: str = "") -> str:
    """A git repo with its branches and recent commits, as Markdown. ``path`` is
    where git runs (the server); ``local`` says where the repo is on the reader's
    machine, when that is what they need to open it."""
    lines = [
        f"## {label} (Git Repository)",
        f"**Repository:** {repo_name}",
    ]
    if local:
        lines.append(f"**On your machine:** {local}")
    if path:
        lines.append(f"**On the Roadmap server:** {path}")
    try:
        proc = subprocess.run(
            ["git", "branch", "-a", "--format=%(refname:short)"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            branches = [b for b in proc.stdout.strip().splitlines() if b][:20]
            if branches:
                lines.append(f"\n**Branches:** {', '.join(branches)}")

        proc = subprocess.run(
            ["git", "log", "--format=%h %aI %an\t%s", "-20"],
            cwd=path, capture_output=True, text=True, timeout=10,
        )
        if proc.returncode == 0:
            commit_lines = [l for l in proc.stdout.strip().splitlines() if l]
            if commit_lines:
                lines.append("\n**Recent commits:**")
                for line in commit_lines:
                    tab = line.find("\t")
                    if tab >= 0:
                        meta, msg = line[:tab], line[tab + 1:]
                        parts = meta.split(" ", 2)
                        if len(parts) >= 3:
                            h, date, author = parts[0], parts[1][:10], parts[2]
                            lines.append(f"- `{h}` {date} {author} — {msg}")
                        else:
                            lines.append(f"- {line}")
    except Exception:
        pass
    return "\n".join(lines)
