"""Local folder-picker plugin — a native (Tk) folder-selection dialog and a
subfolder listing endpoint. Inherently single-user / desktop, so it is the kind
of plugin you'd install for a local / desktop setup, not a shared server."""
