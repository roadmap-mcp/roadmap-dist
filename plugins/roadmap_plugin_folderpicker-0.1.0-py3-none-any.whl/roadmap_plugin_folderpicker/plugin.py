"""Folder-picker plugin activator."""

from roadmap_framework import Plugin, PluginContext

from .router import router as folderpicker_router


class FolderPickerPlugin(Plugin):
    id = "roadmap.folderpicker"
    name = "Folder Picker"
    requires = []

    def activate(self, ctx: PluginContext) -> None:
        ctx.add_router(folderpicker_router)
