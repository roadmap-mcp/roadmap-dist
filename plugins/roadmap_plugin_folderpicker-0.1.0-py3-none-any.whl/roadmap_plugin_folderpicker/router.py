"""Local folder-picker endpoints, mounted under ``/api/settings``.

- ``POST /api/settings/list-subfolders`` — list immediate subdirectories of a path.
- ``POST /api/settings/browse-folder`` — open a native folder-selection dialog on
  the machine running the backend and return the chosen path.

Both are inherently local / single-user (the dialog opens on the *server* host),
so this plugin suits a local / desktop setup, not a shared server.
"""

import asyncio
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/api/settings", tags=["settings", "folderpicker"])


class ListSubfoldersRequest(BaseModel):
    path: str


@router.post("/list-subfolders")
def list_subfolders(req: ListSubfoldersRequest):
    p = Path(req.path)
    if not p.is_dir():
        raise HTTPException(status_code=400, detail=f"Not a directory: {req.path}")
    # Report each immediate (non-hidden) subdirectory and whether it looks like a
    # git checkout — the ``.git`` entry may be a directory (normal clone) or a file
    # (worktree / submodule), so ``.exists()`` covers both.
    folders = sorted(
        (
            {"name": entry.name, "is_git": (entry / ".git").exists()}
            for entry in p.iterdir()
            if entry.is_dir() and not entry.name.startswith(".")
        ),
        key=lambda f: f["name"],
    )
    return {"folders": folders}


class BrowseFolderRequest(BaseModel):
    initial_dir: str = ""


_FOLDER_PICKER_SCRIPT = '''
import sys, tkinter as tk
from tkinter import filedialog
root = tk.Tk()
root.withdraw()
root.attributes("-topmost", True)
kwargs = {"title": "Select folder"}
if len(sys.argv) > 1 and sys.argv[1]:
    from pathlib import Path
    p = Path(sys.argv[1])
    if p.is_dir():
        kwargs["initialdir"] = str(p)
folder = filedialog.askdirectory(**kwargs)
root.destroy()
print(folder or "")
'''


@router.post("/browse-folder")
async def browse_folder(req: BrowseFolderRequest):
    import subprocess, sys
    proc = await asyncio.to_thread(
        subprocess.run,
        [sys.executable, "-c", _FOLDER_PICKER_SCRIPT, req.initial_dir],
        capture_output=True, text=True, timeout=120,
    )
    path = proc.stdout.strip()
    if not path:
        raise HTTPException(status_code=204, detail="No folder selected")
    return {"path": path}
