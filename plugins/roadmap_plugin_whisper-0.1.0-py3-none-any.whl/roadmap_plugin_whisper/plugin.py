"""Whisper plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .runtime import DEFAULTS
from .whisper_router import router as whisper_router

WHISPER_SECTION = SettingsSection(
    id="whisper", label="Whisper", order=80,
    defaults=lambda: {"whisper": dict(DEFAULTS["whisper"])},
    sensitive_fields=["whisper.api_key"],
)


class WhisperPlugin(Plugin):
    id = "roadmap.whisper"
    name = "Whisper"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.register_sensitive_path("whisper.api_key")
        ctx.extend(SETTINGS_SECTIONS_POINT, WHISPER_SECTION)
        ctx.add_router(whisper_router)
