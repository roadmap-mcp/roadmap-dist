"""Whisper plugin — speech-to-text transcription + its settings section."""
