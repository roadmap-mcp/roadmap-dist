import httpx
from fastapi import APIRouter, HTTPException, UploadFile, File

from . import runtime
from .runtime import load_config_decrypted
from roadmap_framework import session

router = APIRouter(prefix="/api/whisper", tags=["whisper"])

_POSTPROCESS_PROMPT = """Clean up this speech-to-text transcription. Fix grammar, punctuation, and phrasing while preserving the original meaning and intent. Do not add or remove information. Return only the cleaned text, no explanation."""


def _require_unlocked():
    if not session.is_unlocked():
        raise HTTPException(status_code=403, detail="App is locked")


def _postprocess(text: str, provider) -> str:
    """Clean up the transcription using the selected AI provider's own model.

    Goes through the shared AI client, so provider quirks (e.g. models that need
    `max_completion_tokens`) are handled in one place.
    """
    return runtime.ai_service().chat_text(
        provider,
        [
            {"role": "system", "content": _POSTPROCESS_PROMPT},
            {"role": "user", "content": text},
        ],
        temperature=0.3,
        max_tokens=2000,
    )


@router.get("/status")
def whisper_status():
    """Check whether Whisper is configured (without leaking the key)."""
    _require_unlocked()
    config = load_config_decrypted()
    return {"configured": bool(config.whisper.api_key)}


@router.post("/transcribe")
async def transcribe(file: UploadFile = File(...)):
    _require_unlocked()
    config = load_config_decrypted()
    w = config.whisper
    if not w.api_key:
        raise HTTPException(status_code=400,
                            detail="Whisper not configured — set API key in Settings")

    audio_bytes = await file.read()
    filename = file.filename or "audio.webm"

    url = f"{w.base_url.rstrip('/')}/audio/transcriptions"

    async with httpx.AsyncClient(timeout=60) as client:
        resp = await client.post(
            url,
            headers={"Authorization": f"Bearer {w.api_key}"},
            files={"file": (filename, audio_bytes, file.content_type or "audio/webm")},
            data={"model": w.model},
        )

    if resp.status_code != 200:
        detail = resp.text[:300]
        raise HTTPException(status_code=resp.status_code,
                            detail=f"Whisper API error: {detail}")

    body = resp.json()
    raw_text = body.get("text", "")

    # Always return the raw Whisper output; if a post-process provider is
    # configured, also run the cleanup and return the final text + a flag.
    result = {"raw": raw_text, "text": raw_text, "postprocessed": False}
    if w.postprocess_provider and raw_text:
        ai = runtime.ai_service()
        if ai is None:
            result["postprocess_error"] = (
                "The AI plugin is not installed, so the transcription cannot be post-processed.")
        elif not (provider := ai.get_provider(w.postprocess_provider)):
            result["postprocess_error"] = (
                f"Post-process provider '{w.postprocess_provider}' is not a configured AI provider")
        else:
            try:
                result["text"] = _postprocess(raw_text, provider)
                result["postprocessed"] = True
            except Exception as e:
                result["postprocess_error"] = ai.describe_error(e)
    return result
