"""Whisper plugin runtime — config access for the moved router."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore

_store: Optional[ConfigStore] = None

DEFAULTS = {
    "whisper": {"base_url": "https://api.openai.com/v1", "api_key": "",
                "model": "whisper-1", "postprocess_provider": "",
                "postprocess_model": ""},
    "ai_providers": [],   # read for optional post-processing
}


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def load_config_decrypted():
    assert _store is not None, "whisper runtime not initialised"
    return _store.load_ns(DEFAULTS)
