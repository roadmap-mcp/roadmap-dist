"""Whisper plugin runtime — config access for the moved router."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ServiceRegistry

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None

DEFAULTS = {
    "whisper": {"base_url": "https://api.openai.com/v1", "api_key": "",
                "model": "whisper-1", "postprocess_provider": "",
                "postprocess_model": ""},
    "ai_providers": [],   # read for optional post-processing
}


def set_runtime(config: ConfigStore, services: ServiceRegistry) -> None:
    global _store, _services
    _store = config
    _services = services


def ai_service():
    """The shared AI client, or ``None`` when the AI plugin isn't installed.

    Whisper transcribes fine without it; only the optional post-processing step
    needs AI. Resolved lazily because ``roadmap.ai`` is not in ``requires``, so
    activation order relative to this plugin is not guaranteed.
    """
    return _services.get("ai") if _services is not None else None


def load_config_decrypted():
    assert _store is not None, "whisper runtime not initialised"
    return _store.load_ns(DEFAULTS)
