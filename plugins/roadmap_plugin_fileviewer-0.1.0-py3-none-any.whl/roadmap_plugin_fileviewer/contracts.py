"""The file-viewer extension point contract.

The fileviewer plugin is the *viewer host*: it browses directories and defines
the ``roadmap.viewers`` extension point. Each file type (PlantUML, markdown,
images, …) is contributed by its own viewer plugin as a :class:`FileViewer`,
declaring the extensions it handles and a ``kind`` the frontend renderer keys on.
"""

from __future__ import annotations

from dataclasses import dataclass, field

#: extension point id — viewer plugins contribute FileViewer instances here.
VIEWERS_POINT = "roadmap.viewers"


@dataclass
class FileViewer:
    #: file extensions this viewer handles, lower-case with the dot, e.g. [".puml"]
    extensions: list[str]
    #: renderer discriminator the frontend ViewerRegistry keys on, e.g. "plantuml"
    kind: str
    #: human label, e.g. "PlantUML"
    label: str = ""
    #: optional backend route that renders/serves the file (informational)
    endpoint: str = ""
    #: optional extra tags (unused for now)
    tags: list[str] = field(default_factory=list)
