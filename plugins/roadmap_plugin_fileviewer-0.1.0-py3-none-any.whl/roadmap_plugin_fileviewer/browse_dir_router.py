from pathlib import Path

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from roadmap_framework import session

from . import runtime
from .contracts import VIEWERS_POINT, FileViewer

IMAGE_EXTENSIONS = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".webp", ".svg", ".ico"}

router = APIRouter(prefix="/api/browse-dir", tags=["browse-dir"])


def _require_unlocked():
    if not session.is_unlocked():
        raise HTTPException(status_code=403, detail="App is locked")


def _check_allowed(path: str):
    """Ensure the path is under a configured browsable root (scratch dir / repo)."""
    if not runtime.allowed_roots():
        raise HTTPException(status_code=403, detail="No browsable directories configured")
    if not runtime.is_allowed(path):
        raise HTTPException(status_code=403,
                            detail="Access denied: path is outside allowed directories")


@router.get("")
def list_dir(path: str):
    """List files and directories at the given path."""
    _require_unlocked()
    _check_allowed(path)
    p = Path(path)
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {path}")
    if not p.is_dir():
        raise HTTPException(status_code=400, detail=f"Not a directory: {path}")

    entries = []
    try:
        for child in sorted(p.iterdir(), key=lambda c: (c.is_file(), c.name.lower())):
            entry = {
                "name": child.name,
                "path": str(child),
                "type": "dir" if child.is_dir() else "file",
            }
            if child.is_file():
                entry["size"] = child.stat().st_size
                entry["ext"] = child.suffix.lower()
            entries.append(entry)
    except PermissionError:
        raise HTTPException(status_code=403, detail="Permission denied")

    return {"path": str(p), "parent": str(p.parent) if p.parent != p else None, "entries": entries}


@router.get("/viewers")
def list_viewers():
    """The file viewers contributed to the ``roadmap.viewers`` extension point —
    the extensions each handles and its renderer ``kind``. The frontend uses this
    (alongside its ViewerRegistry) to know which files are viewable."""
    reg = runtime.extensions()
    viewers = reg.get(VIEWERS_POINT) if reg is not None else []
    return [
        {"extensions": [e.lower() for e in v.extensions], "kind": v.kind,
         "label": v.label, "endpoint": v.endpoint}
        for v in viewers if isinstance(v, FileViewer)
    ]


@router.get("/viewer-config")
def get_viewer_config(ext: str):
    """Get the (legacy, config-driven) viewer config for a file extension."""
    _require_unlocked()
    config = runtime.load_config_decrypted()
    for v in config.file_viewers:
        if v.extension.lower() == ext.lower():
            return {"extension": v.extension, "label": v.label,
                    "renderer": v.renderer, "server_url": v.server_url}
    return {"extension": ext, "label": "", "renderer": "text", "server_url": ""}


@router.get("/read")
def read_file(path: str):
    """Read a text file's content."""
    _require_unlocked()
    _check_allowed(path)
    p = Path(path)
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")
    if not p.is_file():
        raise HTTPException(status_code=400, detail=f"Not a file: {path}")
    if p.stat().st_size > 500_000:
        raise HTTPException(status_code=400, detail="File too large (>500KB)")
    try:
        content = p.read_text(encoding="utf-8", errors="replace")
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to read: {e}")
    return {"path": str(p), "name": p.name, "ext": p.suffix.lower(), "content": content}


@router.get("/image")
def serve_image(path: str):
    """Serve an image file."""
    _require_unlocked()
    _check_allowed(path)
    p = Path(path)
    if not p.exists():
        raise HTTPException(status_code=404, detail=f"File not found: {path}")
    if not p.is_file():
        raise HTTPException(status_code=400, detail=f"Not a file: {path}")
    if p.suffix.lower() not in IMAGE_EXTENSIONS:
        raise HTTPException(status_code=400, detail="Not a supported image type")
    if p.stat().st_size > 10_000_000:
        raise HTTPException(status_code=400, detail="Image too large (>10MB)")
    return FileResponse(p)
