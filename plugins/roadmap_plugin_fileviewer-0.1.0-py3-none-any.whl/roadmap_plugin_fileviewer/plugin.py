"""File viewer plugin activator — the viewer host: browses directories, declares
the ``roadmap.viewers`` extension point, and publishes the ``fileviewer`` service
(the shared path-allow check) that viewer plugins reuse."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .browse_dir_router import router as browse_dir_router
from .contracts import VIEWERS_POINT, FileViewer

VIEWERS_SECTION = SettingsSection(
    id="viewers", label="File Viewers", order=40, group="General",
    defaults=lambda: {"file_viewers": []},
)


class FileViewerPlugin(Plugin):
    id = "roadmap.fileviewer"
    name = "File Viewers"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.extensions)
        ctx.define_point(VIEWERS_POINT, FileViewer,
                         "A file viewer contributed by a viewer plugin (keyed by extension).")
        ctx.extend(SETTINGS_SECTIONS_POINT, VIEWERS_SECTION)
        ctx.add_router(browse_dir_router)
        ctx.services.register("fileviewer", runtime.FileViewerService())
