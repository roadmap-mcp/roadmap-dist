"""File viewer plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .browse_dir_router import router as browse_dir_router

VIEWERS_SECTION = SettingsSection(
    id="viewers", label="File Viewers", order=40,
    defaults=lambda: {"file_viewers": []},
)


class FileViewerPlugin(Plugin):
    id = "roadmap.fileviewer"
    name = "File Viewers"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.extend(SETTINGS_SECTIONS_POINT, VIEWERS_SECTION)
        ctx.add_router(browse_dir_router)
