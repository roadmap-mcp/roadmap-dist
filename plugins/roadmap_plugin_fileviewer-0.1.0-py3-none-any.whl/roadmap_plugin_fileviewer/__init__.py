"""File viewer plugin — the *viewer host*.

Browses directories (``/api/browse-dir``) and declares the ``roadmap.viewers``
extension point. Per-file-type viewer plugins (PlantUML, markdown, images, …)
contribute :class:`FileViewer` instances; import the contract from here::

    from roadmap_plugin_fileviewer import VIEWERS_POINT, FileViewer
"""

from .contracts import VIEWERS_POINT, FileViewer

__all__ = ["VIEWERS_POINT", "FileViewer"]
