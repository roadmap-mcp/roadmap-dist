"""File viewer plugin — directory browsing + file viewers (PlantUML/markdown/images)."""
