"""File viewer plugin runtime — config + the shared path-allow check.

The allow-check (is a path under a configured browsable root?) is the security
boundary for every viewer. It lives here so the host router and viewer plugins
(via the ``fileviewer`` service) share one source of truth for allowed roots.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry

_store: Optional[ConfigStore] = None
_extensions: Optional[ExtensionRegistry] = None

DEFAULTS = {
    "file_viewers": [],
    "repositories": [],       # browsable roots
    "scratch_base_dir": "",   # browsable root
}


def set_runtime(config: ConfigStore, extensions: Optional[ExtensionRegistry] = None) -> None:
    global _store, _extensions
    _store = config
    _extensions = extensions


def extensions() -> Optional[ExtensionRegistry]:
    return _extensions


def load_config_decrypted():
    assert _store is not None, "fileviewer runtime not initialised"
    return _store.load_ns(DEFAULTS)


def allowed_roots() -> list[Path]:
    config = load_config_decrypted()
    roots: list[Path] = []
    if config.scratch_base_dir:
        roots.append(Path(config.scratch_base_dir).resolve())
    for repo in config.repositories:
        if repo.path:
            roots.append(Path(repo.path).resolve())
    return roots


def is_allowed(path: str) -> bool:
    """True if ``path`` is under a configured browsable root (scratch dir / repo)."""
    resolved = Path(path).resolve()
    for root in allowed_roots():
        try:
            resolved.relative_to(root)
            return True
        except ValueError:
            continue
    return False


class FileViewerService:
    """Facade other viewer plugins use (via ``ctx.services.require('fileviewer')``)
    to reuse the host's path-allow check without importing its internals."""

    def is_allowed(self, path: str) -> bool:
        return is_allowed(path)

    def allowed_roots(self) -> list[Path]:
        return allowed_roots()
