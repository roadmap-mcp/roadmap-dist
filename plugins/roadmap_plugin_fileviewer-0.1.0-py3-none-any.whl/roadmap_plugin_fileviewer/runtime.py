"""File viewer plugin runtime — config access for the moved router."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore

_store: Optional[ConfigStore] = None

DEFAULTS = {
    "file_viewers": [],
    "repositories": [],       # browsable roots
    "scratch_base_dir": "",   # browsable root
}


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def load_config_decrypted():
    assert _store is not None, "fileviewer runtime not initialised"
    return _store.load_ns(DEFAULTS)
