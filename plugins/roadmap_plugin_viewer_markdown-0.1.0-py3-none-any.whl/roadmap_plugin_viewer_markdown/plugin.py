"""Markdown viewer plugin activator — contributes a ``.md`` viewer to the host's
``roadmap.viewers`` point. Rendering is entirely client-side (marked), so there
is no backend router; this just advertises the viewer."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_fileviewer import VIEWERS_POINT, FileViewer

MARKDOWN_VIEWER = FileViewer(
    extensions=[".md", ".markdown"],
    kind="markdown",
    label="Markdown",
)


class MarkdownViewerPlugin(Plugin):
    id = "roadmap.viewer.markdown"
    name = "Markdown Viewer"
    requires = ["roadmap.fileviewer"]

    def activate(self, ctx: PluginContext) -> None:
        ctx.extend(VIEWERS_POINT, MARKDOWN_VIEWER)
