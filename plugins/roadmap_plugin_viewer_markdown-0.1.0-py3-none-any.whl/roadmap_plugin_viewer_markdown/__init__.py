"""Markdown viewer plugin — contributes a ``.md`` file viewer (rendered client-side)."""
