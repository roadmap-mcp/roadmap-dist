"""MCP server plugin activator — mounts the shared, workspace-aware MCP server and
publishes it as the ``mcp`` service, so every plugin (the knowledge base, contexts,
Trello, workflows…) registers its tools in one place.

A core plugin: every edition installs it, and it is on in every workspace.
"""

from roadmap_framework import Plugin, PluginContext

from .server import create_mcp_sse_app, mcp
from .stateless_mcp import create_stateless_endpoint
from .workspace_mcp import WorkspaceScopedMCP, set_workspace_runtime


class McpService:
    """What other plugins use: ``mcp`` — add ``@mcp.tool()``s to it. Every tool
    registered on it gains an optional ``workspace`` argument, so a contributing
    plugin never has to handle tenancy itself; a tool whose plugin is switched off
    in a workspace is refused there."""

    def __init__(self):
        self.mcp = mcp


class McpPlugin(Plugin):
    id = "roadmap.mcp"
    name = "MCP server"
    requires: list[str] = []

    def activate(self, ctx: PluginContext) -> None:
        ctx.services.register("mcp", McpService())

        # Two workspace layers: the mount picks the *connection* workspace
        # (/mcp/<workspace>/sse; /mcp/sse stays on default), and every tool takes an
        # optional `workspace` argument that overrides it for a single call.
        workspaces = ctx.services.get("workspaces")
        set_workspace_runtime(workspaces, ctx.app)
        ctx.app.mount("/mcp", WorkspaceScopedMCP(create_mcp_sse_app(), workspaces))
        # The stateless endpoint (one fixed `roadmap` tool; survives reloads). The mount
        # above serves /mcp/<workspace>; bare /mcp needs its own route (a mount only
        # matches below its path) and takes the workspace from the header or ?ws=.
        ctx.app.add_route("/mcp", create_stateless_endpoint(mcp), methods=["GET", "POST"])
