"""Workspace plumbing for the MCP server.

An MCP connection is long-lived, so the workspace can't be resolved per request the
way :class:`roadmap_framework.WorkspaceMiddleware` does for HTTP. Two mechanisms
cover that, and they compose:

* :class:`WorkspaceScopedMCP` — the *connection* workspace, taken from the mount path:
  ``/mcp/<workspace>/sse`` runs that tenant; ``/mcp/sse`` stays on ``default``.
* :class:`WorkspaceAwareMCP` — the *per-call* workspace: every tool registered on the
  shared server automatically gains an optional ``workspace`` argument, so one
  connection can reach any tenant on the server. Omitted (the default) keeps the
  connection workspace, so existing clients are unaffected.

The extra argument is injected at registration time rather than written out by each
tool, so plugins contributing tools (Jira, Trello, brain, e2e, workflow…) get it for
free and can never drift out of sync with the host.
"""

from __future__ import annotations

import inspect
from typing import Any, Callable, get_type_hints

from mcp.server.fastmcp import FastMCP
from starlette._utils import get_route_path
from starlette.types import Receive, Scope, Send

#: the injected argument's name — also an opt-out marker: a tool that declares a
#: ``workspace`` parameter itself is left alone.
WORKSPACE_ARG = "workspace"

#: attribute stamped on a function by ``tool(workspace_arg=False)`` — read back in
#: ``add_tool``, which is the single funnel every registration passes through.
_OPT_OUT = "_roadmap_no_workspace_arg"

_WORKSPACE_DOC = (
    "\n\nOptional `workspace`: run this call against another workspace (tenant) on the "
    "server instead of the connection's own. Omit it for the connected workspace. "
    "Call list_workspaces() to discover the names."
)

#: set at plugin activation — the server's workspace registry + the FastAPI app
#: (the latter only to read ``app.state.plugins`` for the enablement check).
_registry: Any = None
_app: Any = None


def set_workspace_runtime(registry, app) -> None:
    """Wire the workspace registry (and app) the tool wrapper consults."""
    global _registry, _app
    _registry, _app = registry, app


def workspace_names() -> list[str]:
    return list(_registry.names()) if _registry is not None else []


# ── per-call workspace resolution ─────────────────────────────────────────────

def resolve_workspace(name: str) -> tuple[str | None, str | None]:
    """Validate a caller-supplied workspace name.

    Returns ``(workspace, None)`` when the call should be pinned to ``workspace``,
    ``(None, None)`` when the caller didn't ask for one (keep the connection's), or
    ``(None, message)`` when the name is unusable — the message is returned to the
    caller verbatim, since MCP tools here answer in plain text.
    """
    from roadmap_framework.workspace import normalize_name

    if not (name or "").strip():
        return None, None
    if _registry is None:
        return None, "Workspaces are not available on this server."
    cand = normalize_name(name)
    if not _registry.exists(cand):
        return None, (
            f"Unknown workspace '{name}'. Available: {', '.join(_registry.names())}."
        )
    return cand, None


def _installed_plugin_ids() -> list[str]:
    return [p.id for p in getattr(getattr(_app, "state", None), "plugins", [])]


def _owner_plugin_id(module: str) -> str | None:
    """Map a tool function's module back to the plugin that contributed it, by its
    top-level package (``roadmap_plugin_jira.mcp_tools`` → ``roadmap.jira``).
    Best-effort: an unresolvable owner simply skips the enablement check."""
    root = (module or "").split(".", 1)[0]
    for p in getattr(getattr(_app, "state", None), "plugins", []):
        if type(p).__module__.split(".", 1)[0] == root:
            return p.id
    return None


def _enablement_error(module: str, ws: str) -> str | None:
    """Refuse a tool whose plugin is disabled in the workspace the call resolves to —
    the same gate the extension registry applies to HTTP requests."""
    if _registry is None or _app is None:
        return None
    owner = _owner_plugin_id(module)
    if owner is None:
        return None
    installed = _installed_plugin_ids()
    if owner in _registry.enabled_plugin_ids(ws, installed):
        return None
    return (
        f"Plugin '{owner}' is not enabled in workspace '{ws}', so this tool is "
        f"unavailable there."
    )


# ── signature injection ───────────────────────────────────────────────────────

def _signature_with_workspace(fn: Callable) -> inspect.Signature:
    """The tool's signature plus a keyword-only ``workspace: str = ""``.

    Annotations are resolved against *the tool's own* module globals, because the
    wrapper that carries this signature lives here and couldn't resolve them itself.
    """
    sig = inspect.signature(fn)
    try:
        hints = get_type_hints(fn)
    except Exception:                                   # unresolvable ⇒ keep as-is
        hints = {}

    params = [p.replace(annotation=hints.get(p.name, p.annotation))
              for p in sig.parameters.values()]
    ws_param = inspect.Parameter(
        WORKSPACE_ARG, inspect.Parameter.KEYWORD_ONLY, default="", annotation=str)
    # keyword-only args must precede **kwargs
    at = next((i for i, p in enumerate(params)
               if p.kind is inspect.Parameter.VAR_KEYWORD), len(params))
    params.insert(at, ws_param)

    return sig.replace(parameters=params,
                       return_annotation=hints.get("return", sig.return_annotation))


def with_workspace_arg(fn: Callable) -> Callable:
    """Wrap ``fn`` so an optional ``workspace`` argument pins the tenant for the call.

    ``functools.wraps`` is deliberately not used: it sets ``__wrapped__``, which
    ``inspect.signature`` follows back to the original signature — losing the very
    argument we're adding.
    """
    if getattr(fn, _OPT_OUT, False):
        return fn                                       # explicitly opted out
    if WORKSPACE_ARG in inspect.signature(fn).parameters:
        return fn                                       # the tool handles it itself

    module = fn.__module__

    def _pin(workspace: str):
        """→ (token_or_None, error_or_None); token is reset by the caller."""
        from roadmap_framework import current_workspace

        ws, err = resolve_workspace(workspace)
        if err:
            return None, err
        effective = ws if ws is not None else current_workspace.get()
        err = _enablement_error(module, effective)
        if err:
            return None, err
        return (current_workspace.set(ws) if ws is not None else None), None

    if inspect.iscoroutinefunction(fn):
        async def _async_wrapper(*args, workspace: str = "", **kwargs):
            from roadmap_framework import current_workspace
            token, err = _pin(workspace)
            if err:
                return err
            try:
                return await fn(*args, **kwargs)
            finally:
                if token is not None:
                    current_workspace.reset(token)
        wrapper: Callable = _async_wrapper
    else:
        def _sync_wrapper(*args, workspace: str = "", **kwargs):
            from roadmap_framework import current_workspace
            token, err = _pin(workspace)
            if err:
                return err
            try:
                return fn(*args, **kwargs)
            finally:
                if token is not None:
                    current_workspace.reset(token)
        wrapper = _sync_wrapper

    wrapper.__name__ = fn.__name__
    wrapper.__qualname__ = fn.__qualname__
    wrapper.__module__ = module
    wrapper.__doc__ = (fn.__doc__ or "").rstrip() + _WORKSPACE_DOC
    wrapper.__signature__ = _signature_with_workspace(fn)   # type: ignore[attr-defined]
    return wrapper


class WorkspaceAwareMCP(FastMCP):
    """The shared MCP server: every tool registered on it takes an optional
    ``workspace`` argument (see :func:`with_workspace_arg`).

    Pass ``workspace_arg=False`` to opt a tool out — for tools that are about the
    server itself rather than a tenant, e.g. ``list_workspaces``.
    """

    def tool(self, *args, workspace_arg: bool = True, **kwargs):
        register = super().tool(*args, **kwargs)

        def decorator(fn):
            if not workspace_arg:
                setattr(fn, _OPT_OUT, True)
            register(fn)                                 # funnels into add_tool below
            return fn                                    # callers keep the plain fn

        return decorator

    def add_tool(self, fn, *args, **kwargs):
        """Every registration — decorator or direct — passes through here, so this is
        the one place the argument is injected."""
        return super().add_tool(with_workspace_arg(fn), *args, **kwargs)


class WorkspaceScopedMCP:
    """ASGI wrapper that pins the workspace for an MCP connection from the URL path:
    ``/mcp/<workspace>/sse`` (and its ``/messages/`` posts) run against that tenant's
    contexts. ``/mcp/sse`` (no workspace segment) stays on the default workspace
    (backward compatible). ``root_path`` is extended with the workspace so the SSE
    transport advertises workspace-prefixed message URLs back to the client.

    This is the *connection* workspace; individual calls can still override it with
    the ``workspace`` tool argument."""

    def __init__(self, app, registry) -> None:
        self.app = app
        self.registry = registry

    async def __call__(self, scope: Scope, receive: Receive, send: Send):
        from roadmap_framework import current_workspace, DEFAULT_WORKSPACE

        if scope["type"] not in ("http", "websocket") or self.registry is None:
            await self.app(scope, receive, send)
            return

        # Starlette passes a mounted app the full path, with the mount prefix in
        # root_path; routing inside uses what follows root_path.
        seg = get_route_path(scope).lstrip("/").split("/", 1)
        first = seg[0] if seg and seg[0] else ""
        ws = DEFAULT_WORKSPACE
        used = scope
        if first and first not in ("sse", "messages") and self.registry.exists(first):
            ws = first
            used = dict(scope)
            used["root_path"] = scope.get("root_path", "") + "/" + first
            if len(seg) == 1:                  # bare /mcp/<ws>: the stateless endpoint
                used["path"] = scope["path"] + "/"

        token = current_workspace.set(ws)
        try:
            await self.app(used, receive, send)
        finally:
            current_workspace.reset(token)
