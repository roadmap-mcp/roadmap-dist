"""MCP server plugin — the shared, workspace-aware MCP server (``/mcp``) every
plugin registers its tools on, through the ``mcp`` service::

    mcp = ctx.services.require("mcp").mcp

    @mcp.tool()
    def my_tool(...) -> str: ...
"""
