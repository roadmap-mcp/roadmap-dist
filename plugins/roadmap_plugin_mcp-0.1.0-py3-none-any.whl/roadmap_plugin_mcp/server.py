"""The shared MCP server every plugin registers its tools on.

``mcp`` is workspace-aware (see :mod:`.workspace_mcp`): each tool registered on it
gains an optional ``workspace`` argument. Two ways in, both mounted by the plugin:
the SSE session at ``/mcp[/<workspace>]/sse`` (one MCP tool per registered tool),
and the stateless endpoint at ``/mcp[/<workspace>]`` (one fixed tool, see
:mod:`.stateless_mcp`).
"""

from mcp.server.sse import SseServerTransport
from starlette.applications import Starlette
from starlette.routing import Mount, Route
from starlette.types import Receive, Scope, Send

from .stateless_mcp import create_stateless_endpoint
from .workspace_mcp import WorkspaceAwareMCP, workspace_names

#: The shared MCP server. Plugins reach it through the ``mcp`` service.
mcp = WorkspaceAwareMCP("roadmap")


@mcp.tool(workspace_arg=False)
def list_workspaces() -> str:
    """List the workspaces (tenants) on this server.

    Every other tool takes an optional ``workspace`` argument: pass one of these
    names to run that call against another workspace than the connected one.
    Settings and data are per-workspace, so something that is "not found" may
    simply live in another one.
    """
    from roadmap_framework import current_workspace

    names = workspace_names()
    if not names:
        return "Workspaces are not available on this server."

    cur = current_workspace.get()
    lines = [f"- {n}" + ("  (connected)" if n == cur else "") for n in names]
    return ("Available workspaces:\n" + "\n".join(lines)
            + "\n\nPass workspace=\"<name>\" to any tool to run it against that "
              "workspace.")


def create_mcp_sse_app() -> Starlette:
    """Create a Starlette app that handles MCP SSE connections, plus the stateless
    endpoint at its root (``/mcp/<workspace>``; see :mod:`.stateless_mcp`)."""
    sse = SseServerTransport("/messages/")

    class _SseEndpoint:
        """ASGI app wrapper so Starlette doesn't wrap it with request_response."""

        async def __call__(self, scope: Scope, receive: Receive, send: Send):
            async with sse.connect_sse(scope, receive, send) as streams:
                await mcp._mcp_server.run(
                    streams[0], streams[1],
                    mcp._mcp_server.create_initialization_options(),
                )

    routes = [
        Route("/", endpoint=create_stateless_endpoint(mcp), methods=["GET", "POST"]),
        Route("/sse", endpoint=_SseEndpoint(), methods=["GET"]),
        Mount("/messages/", app=sse.handle_post_message),
    ]

    return Starlette(routes=routes)
