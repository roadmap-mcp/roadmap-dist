"""Context-assistant plugin — an AI chat that proposes context items/tags from a
message, optionally enriched with Jira issue data when the Jira plugin is present."""
