"""Context-assistant HTTP surface.

- ``POST /api/context-assistant`` — turn a chat message into proposed context
  items / tags / description. Jira issue enrichment is **optional**: the Jira
  plugin's services are imported lazily inside a guarded block, so the assistant
  works (minus enrichment) when Jira isn't installed.
- ``GET /api/settings/ai-task-prompts/{task_type}`` — prompt-preview for the
  Settings UI (moved off the edition; same path as before).
"""

import re

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from roadmap_framework import session

from . import runtime
from .prompts import _SYSTEM_PROMPT, get_prompts

assistant_router = APIRouter(prefix="/api/context-assistant", tags=["context-assistant"])
prompts_router = APIRouter(prefix="/api/settings", tags=["settings"])

_JIRA_KEY_RE = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")


class AssistantRequest(BaseModel):
    message: str
    context_name: str
    existing_items: list[dict] = []
    tags: list[str] = []
    description: str = ""


class ProposedAction(BaseModel):
    action: str  # "add_item" | "add_tag" | "remove_tag" | "set_description"
    # add_item fields
    type: str = ""
    id: str = ""
    label: str = ""
    # tag fields
    tag: str = ""
    # description fields
    description: str = ""
    reason: str = ""


class AssistantResponse(BaseModel):
    reply: str
    proposals: list[ProposedAction]
    fetched_issues: dict[str, dict] = {}


def _require_unlocked():
    if not session.is_unlocked():
        raise HTTPException(status_code=403, detail="App is locked")


def _fetch_issue_data(svc, key: str) -> dict | None:
    """Fetch and return a compact view of a Jira issue."""
    data = svc.get_issue(key)
    if not data:
        return None
    return {
        "key": data.get("key", key),
        "summary": data.get("summary", ""),
        "status": data.get("status", ""),
        "issuetype": data.get("issuetype", ""),
        "description": (data.get("description", "") or "")[:3000],
        "issuelinks": data.get("issuelinks", []),
        "subtasks": data.get("subtasks", []),
        "labels": data.get("labels", []),
        "components": data.get("components", []),
        "branches": data.get("branches", []),
        "commits": data.get("commits", [])[:10],
        "pull_requests": data.get("pull_requests", []),
    }


@assistant_router.post("", response_model=AssistantResponse)
def assist(request: AssistantRequest):
    _require_unlocked()
    config = runtime.load_config_decrypted()

    provider = runtime.ai_service().provider_for_task(
        "context_assistant", "cypher_generation", "repository_analysis")
    if not provider:
        raise HTTPException(status_code=400,
                            detail="No AI provider configured. Set up in Settings → AI Tasks.")

    # Extract Jira keys from user message
    mentioned_keys = _JIRA_KEY_RE.findall(request.message)

    # Fetch Jira issue data for mentioned keys — optional: only when the Jira
    # plugin is installed. Best-effort; the AI can still work with the message.
    fetched: dict[str, dict] = {}
    try:
        from roadmap_plugin_jira.jira_cache import JiraCache
        from roadmap_plugin_jira.jira_issue_service import JiraIssueService

        atl = config.atlassian
        cache = JiraCache(atl.cache_dir if atl else "", atl.refresh_duration if atl else 3600)
        svc = JiraIssueService(atl, cache)
        for key in mentioned_keys:
            data = _fetch_issue_data(svc, key)
            if data:
                fetched[key] = data
                # Also fetch linked issues for richer context
                for link in data.get("issuelinks", []):
                    lk = link.get("key", "")
                    if lk and lk not in fetched:
                        linked = _fetch_issue_data(svc, lk)
                        if linked:
                            fetched[lk] = linked
    except Exception:
        pass  # Jira not installed / not configured — proceed without enrichment

    # Build AI prompt
    existing_ids = {(i.get("type", ""), i.get("id", "")) for i in request.existing_items}
    existing_desc = "\n".join(
        f"- [{i.get('type')}] {i.get('id')} — {i.get('label', '')}"
        for i in request.existing_items
    ) or "(empty)"

    issue_context = ""
    if fetched:
        import json
        issue_context = "\n\nJira issue data:\n" + json.dumps(fetched, indent=2, default=str)

    repo_names = [r.name for r in config.repositories]
    repos_context = f"\n\nConfigured git repositories: {', '.join(repo_names)}" if repo_names else ""

    from pathlib import Path
    scratch_path = ""
    if config.scratch_base_dir:
        scratch_path = str(Path(config.scratch_base_dir) / request.context_name)

    tags_desc = ", ".join(request.tags) if request.tags else "(none)"
    user_content = (
        f"Context: {request.context_name}\n"
        f"Description: {request.description or '(not set)'}\n"
        f"Tags: {tags_desc}\n"
        f"Existing items:\n{existing_desc}\n\n"
        f"User message: {request.message}"
        f"{issue_context}"
        f"{repos_context}"
        f"{f'\n\nScratch directory for this context: {scratch_path}' if scratch_path else ''}"
    )

    # Call AI through the shared client, which handles provider quirks such as
    # models that require `max_completion_tokens` instead of `max_tokens`.
    try:
        text = runtime.ai_service().chat_text(
            provider,
            [
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": user_content},
            ],
            temperature=0.3,
            max_tokens=2000,
        )
        if text.startswith("```"):
            text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()

        import json
        result = json.loads(text)

        # Filter out already-existing items for add_item actions
        proposals = []
        for p in result.get("proposals", []):
            action = p.get("action", "add_item")
            if action == "add_item" and (p.get("type", ""), p.get("id", "")) in existing_ids:
                continue
            proposals.append(ProposedAction(**p))

        return AssistantResponse(
            reply=result.get("reply", ""),
            proposals=proposals,
            fetched_issues=fetched,
        )
    except Exception as e:
        raise HTTPException(status_code=500,
                            detail=f"AI assistant failed: {e}")


@prompts_router.get("/ai-task-prompts/{task_type}")
def get_ai_task_prompts(task_type: str):
    if runtime.has_encrypted_fields() and not session.is_unlocked():
        raise HTTPException(status_code=403,
                            detail="App is locked. Provide password to unlock.")
    if task_type == "context_assistant":
        return {"task_type": task_type, "steps": get_prompts()}
    raise HTTPException(status_code=404,
                        detail=f"Prompt preview not implemented for task type: {task_type}")
