"""Context-assistant plugin runtime — decrypted config access.

Reads only the config slices the assistant needs (AI providers/tasks to pick a
provider, Atlassian cache settings for optional Jira enrichment, repositories +
scratch dir for prompt context). Other plugins own these slices' settings tabs;
here we just read them via the shared ConfigStore.
"""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ServiceRegistry

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None

DEFAULTS = {
    "ai_providers": [],
    "ai_tasks": [],
    "repositories": [],
    "scratch_base_dir": "",
    "atlassian": {"cache_dir": "", "refresh_duration": 3600},
}


def set_runtime(config: ConfigStore, services: ServiceRegistry) -> None:
    global _store, _services
    _store = config
    _services = services


def ai_service():
    """The shared AI client (``roadmap.ai`` is a declared dependency).

    Resolved lazily so this module never caches a service from activation time.
    """
    assert _services is not None, "context-assistant runtime not initialised"
    return _services.require("ai")


def has_encrypted_fields() -> bool:
    assert _store is not None, "context-assistant runtime not initialised"
    return _store.has_encrypted_fields()


def load_config_decrypted():
    assert _store is not None, "context-assistant runtime not initialised"
    return _store.load_ns(DEFAULTS)
