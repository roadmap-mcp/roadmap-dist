"""Context-assistant plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_ai import AI_TASK_TYPES_POINT, AITaskType

from . import runtime
from .router import assistant_router, prompts_router


class ContextAssistantPlugin(Plugin):
    id = "roadmap.contextassistant"
    name = "Context Assistant"
    # Needs the context domain + AI config/settings. Jira is an *optional*
    # enrichment (lazy import in the router), so it is intentionally not required.
    requires = ["roadmap.context", "roadmap.ai"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services)
        ctx.add_router(assistant_router)
        ctx.add_router(prompts_router)
        ctx.extend(AI_TASK_TYPES_POINT, AITaskType(
            id="context_assistant", label="Context assistant", order=10,
            description="Powers the AI chat on the context-detail page."))
