"""The ``workflow`` service — the facade the router (and future MCP tools / context
item) use.

Thin CRUD over stepdefs/flows/invocations plus starting an invocation (which kicks the
runner). Keeps a stable surface so the executor/runner internals can change without
touching callers.
"""

from __future__ import annotations

import uuid
from datetime import datetime, timezone

from dataclasses import asdict

from . import engine, runtime, storage, vault
from .models import Flow, FlowInvocation, Step, StepDef, StepResult


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class WorkflowService:
    # ── executors (self-describing registry — drives the step editor) ──────────
    def list_executors(self) -> list[dict]:
        """The registered executors as ``{id, label, icon, fields}`` — the UI renders
        the step-kind dropdown and each kind's config form from this, so a new executor
        (in any plugin) appears with no engine change."""
        out = []
        for p in runtime.executor_providers():
            out.append({
                "id": p.id,
                "label": p.label,
                "icon": getattr(p, "icon", "bi-box"),
                "fields": [asdict(f) for f in getattr(p, "fields", [])],
            })
        return sorted(out, key=lambda e: e["label"].lower())

    # ── stepdefs (reusable single-step templates) ─────────────────────────────
    def list_stepdefs(self) -> list[StepDef]:
        return storage.list_stepdefs()

    def get_stepdef(self, stepdef_id: str) -> StepDef | None:
        return storage.get_stepdef(stepdef_id)

    def save_stepdef(self, stepdef: StepDef) -> StepDef:
        return storage.save_stepdef(stepdef)

    def delete_stepdef(self, stepdef_id: str) -> bool:
        return storage.delete_stepdef(stepdef_id)

    # ── flows ──────────────────────────────────────────────────────────────────
    def list_flows(self) -> list[Flow]:
        return storage.list_flows()

    def get_flow(self, flow_id: str) -> Flow | None:
        return storage.get_flow(flow_id)

    def save_flow(self, flow: Flow) -> Flow:
        return storage.save_flow(flow)

    def delete_flow(self, flow_id: str) -> bool:
        return storage.delete_flow(flow_id)

    # ── invocations ────────────────────────────────────────────────────────────
    def list_invocations(self) -> list[FlowInvocation]:
        return storage.list_invocations()

    def get_invocation(self, invocation_id: str) -> FlowInvocation | None:
        return storage.get_invocation(invocation_id)

    def delete_invocation(self, invocation_id: str) -> bool:
        return storage.delete_invocation(invocation_id)

    def start_invocation(self, flow_id: str, context: dict | None = None) -> FlowInvocation:
        """Create an invocation, persist it as ``running``, launch the background runner,
        and return immediately. The caller polls ``get_invocation`` for progress."""
        flow = storage.get_flow(flow_id)
        if flow is None:
            raise ValueError(f"Flow '{flow_id}' not found.")
        ctx_in = dict(context or {})
        # Pin a correlation id for the whole invocation: `${uuid}` then resolves to the
        # same value in every step (and stays put across re-runs, since context_in wins
        # over the per-run builtin). A caller-supplied `uuid` is kept as-is.
        ctx_in.setdefault("uuid", str(uuid.uuid4()))
        inv = FlowInvocation(
            id=storage.new_id("inv"),
            flow_id=flow_id,
            flow_name=flow.name,
            status="running",
            started=_now(),
            context_in=ctx_in,
        )
        storage.save_invocation(inv)
        engine.start_async(inv.id)
        return inv

    def resume_invocation(self, invocation_id: str, approved: bool) -> FlowInvocation | None:
        """Approve (continue) or abort a step the invocation is paused on for confirmation."""
        engine.resume(invocation_id, approved)
        return storage.get_invocation(invocation_id)

    def rerun_invocation(self, invocation_id: str) -> FlowInvocation | None:
        """Re-run the whole invocation from scratch (drops all prior step results)."""
        engine.rerun_flow(invocation_id)
        return storage.get_invocation(invocation_id)

    def rerun_step(self, invocation_id: str, index: int) -> FlowInvocation | None:
        """Re-run a single step in place, replacing only that step's result."""
        engine.rerun_step_async(invocation_id, index)
        return storage.get_invocation(invocation_id)

    def probe_step(self, step: dict, context: dict | None = None, ref: str = "") -> dict:
        """Run **one** step once (the "Test this step" action in the editor) and return the
        redacted ``{status, output, error, resolved}``. Resolves ``${param}`` (from the given
        context + builtins) and injects/redacts ``{{vault…}}`` secrets like a real run — it
        executes against the real target, so it's a user-initiated action only.

        For a **derived** step, pass ``ref`` (the stepdef id): the stepdef is merged with the
        given fill-ins first, so the probe sees the inherited (pre-filled) fields too."""
        s = Step.model_validate(step)
        if ref:
            merged = engine.merge_probe_step(ref, s)
            if merged is None:
                return {"status": "failed", "error": f"Step definition '{ref}' not found.",
                        "output": {}, "resolved": {}}
            s = merged
        return engine.run_probe(s, context or {})

    # ── credentials vault (metadata only — values never leave the server) ──────
    def list_credentials(self) -> list[dict]:
        return vault.list_metadata()

    def get_credential(self, cred_id: str) -> dict | None:
        return vault.get_metadata(cred_id)

    def save_credential(self, cred_id: str, name: str, kind: str,
                        fields: dict, notes: str = "") -> dict:
        return vault.save_credential(cred_id, name, kind, fields, notes)

    def delete_credential(self, cred_id: str) -> bool:
        return vault.delete_credential(cred_id)

    # ── invocation report as markdown (used by the workflow_invocation item) ───
    def render_invocation(self, invocation_id: str) -> str:
        inv = storage.get_invocation(invocation_id)
        if inv is None:
            return f"*Workflow invocation `{invocation_id}` not found.*"
        return render_invocation_markdown(inv)


def render_invocation_markdown(inv: FlowInvocation) -> str:
    icon = {"passed": "✓", "failed": "✗", "error": "!", "running": "…",
            "skipped": "–", "awaiting_approval": "?"}
    lines = [
        f"# Flow invocation — {inv.flow_name or inv.flow_id}",
        "",
        f"- **Status:** {inv.status}",
        f"- **Started:** {inv.started}",
        f"- **Finished:** {inv.finished or '—'}",
    ]
    if inv.context_in:
        params = ", ".join(f"`{k}`={v!r}" for k, v in inv.context_in.items())
        lines.append(f"- **Parameters:** {params}")
    if inv.error:
        lines += ["", f"> **Error:** {inv.error}"]
    lines += ["", "## Steps", ""]
    for r in inv.step_results:
        _step_markdown(lines, r, icon)
    return "\n".join(lines)


def _step_markdown(lines: list[str], r: StepResult, icon: dict) -> None:
    mark = icon.get(r.status, "·")
    lines.append(f"{r.index + 1}. {mark} **{r.label or r.kind}** (`{r.kind}`) — {r.status}")
    if r.error:
        lines.append(f"   - error: {r.error}")
