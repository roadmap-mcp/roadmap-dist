"""The credentials vault — AI-blind, encrypted-at-rest, write + metadata only.

Secrets (SaaS logins, API tokens) are stored as **per-credential JSON files** under
``<config_dir>/workflow/vault/<id>.json``, with every field **value** encrypted at rest via
the framework's Fernet key (the same server-level key that unlocks the config store). This
is deliberately **separate** from the settings/config namespace — the settings router
returns *decrypted* config to any unlocked caller, which is exactly what a credentials vault
must not do.

The public surface is intentionally asymmetric:

* **write** — ``save_credential`` accepts plaintext field values and encrypts them;
* **read metadata** — ``list_metadata`` / ``get_metadata`` return only the name, kind, field
  *names*, and notes — **never a field value**;
* **resolve** — ``resolve(name, field)`` decrypts a single value **server-side only**, used
  exclusively by the engine at run time to inject ``{{vault.<name>.<field>}}`` references. It
  is never wired to an HTTP response or an AI context.

Because there is no endpoint (and no AI tool) that returns a value, a secret can reach a real
backend system through the executor but can never reach the API surface or the LLM.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from roadmap_framework import session
from roadmap_framework.crypto import decrypt_value, encrypt_value, is_encrypted

from . import runtime

#: credential kinds — organizational; drive the default field set in the UI.
VAULT_KINDS = ["basic", "token", "apikey"]


class VaultLocked(RuntimeError):
    """Raised when a vault write is attempted while the server is locked."""


def _vault_dir() -> Path:
    d = runtime.workflow_dir() / "vault"
    d.mkdir(parents=True, exist_ok=True)
    return d


def new_id() -> str:
    return f"vc_{uuid.uuid4().hex[:8]}"


def _read(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _raw(cred_id: str) -> dict | None:
    """Internal — the on-disk record (encrypted field values). Never returned by the API."""
    return _read(_vault_dir() / f"{cred_id}.json")


def _raw_by_name(name: str) -> dict | None:
    for f in _vault_dir().glob("*.json"):
        d = _read(f)
        if d and d.get("name") == name:
            return d
    return None


def _metadata(d: dict) -> dict:
    """Project an on-disk record to safe metadata — **no field values**."""
    return {
        "id": d.get("id", ""),
        "name": d.get("name", ""),
        "kind": d.get("kind", "basic"),
        "field_names": sorted((d.get("fields") or {}).keys()),
        "notes": d.get("notes", ""),
    }


# ── public: metadata reads (never expose values) ──────────────────────────────

def list_metadata() -> list[dict]:
    out = [_metadata(d) for f in sorted(_vault_dir().glob("*.json")) if (d := _read(f))]
    return sorted(out, key=lambda c: c["name"].lower())


def get_metadata(cred_id: str) -> dict | None:
    d = _raw(cred_id)
    return _metadata(d) if d else None


# ── public: write (encrypts; returns metadata only) ───────────────────────────

def save_credential(cred_id: str, name: str, kind: str,
                    fields: dict[str, str], notes: str = "") -> dict:
    """Create/update a credential. Each non-blank field value is encrypted; a **blank**
    value keeps the existing encrypted value (so the UI can show ``••••`` placeholders and
    only overwrite what the user re-typed). Returns metadata only.

    Raises :class:`VaultLocked` if the server is locked (no key to encrypt with).
    """
    if not session.is_unlocked():
        raise VaultLocked("Server is locked — unlock it before storing credentials.")
    key = session.get_key()

    existing = _raw(cred_id) if cred_id else None
    enc_fields: dict[str, str] = dict((existing or {}).get("fields") or {})
    for fname, val in (fields or {}).items():
        if val == "":
            continue  # blank = keep existing encrypted value
        enc_fields[fname] = val if is_encrypted(val) else encrypt_value(val, key)

    cid = cred_id or new_id()
    data = {"id": cid, "name": name, "kind": kind, "fields": enc_fields, "notes": notes}
    _write(_vault_dir() / f"{cid}.json", data)
    return _metadata(data)


def delete_credential(cred_id: str) -> bool:
    f = _vault_dir() / f"{cred_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── engine-only: resolve a single value (server-side, never serialized) ───────

def resolve(name: str, field: str) -> str | None:
    """Decrypt one credential field for the runner. Returns ``None`` if the server is
    locked, the credential/field is unknown, or decryption fails — the engine then leaves
    the ``{{vault…}}`` placeholder in place so the step fails visibly rather than silently
    running with an empty secret."""
    if not session.is_unlocked():
        return None
    d = _raw_by_name(name)
    if not d:
        return None
    val = (d.get("fields") or {}).get(field)
    if val is None:
        return None
    try:
        return decrypt_value(val, session.get_key())
    except Exception:
        return None
