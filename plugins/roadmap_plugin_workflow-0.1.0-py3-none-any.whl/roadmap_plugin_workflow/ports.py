"""The executor *port* — the interface a step executor implements.

The engine owns everything executor-agnostic: compiling flows, interpolating
``${param}`` values, resolving ``{{vault.<name>.<field>}}`` credentials (server-side,
AI-blind), redacting secrets out of results, merging captured context, assembling the
invocation report, and persisting it. An :class:`Executor` owns only the target-specific
concern — performing one already-resolved step and reporting what happened.

Steps reach the executor as plain dicts (a resolved :class:`~.models.Step`), so the port
stays free of the engine's pydantic models. The executor **must not** raise for an
ordinary failure (a non-2xx HTTP status, a non-zero exit code) — it returns
``status="failed"`` instead, so the runner records it as a normal step outcome.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol, runtime_checkable


@dataclass
class StepOutcome:
    """What an executor reports back for one step.

    ``output`` is a small, **already-sanitized** dict describing what happened (e.g.
    ``{"status": 200, "body": "<head…>"}``) — it is merged into the run context and, if
    the step has ``capture_as``, stored under that key. Executors must not place secret
    values here; the runner additionally scrubs any resolved secret it injected.
    """

    status: str                                   # "passed" | "failed"
    error: str = ""                               # message when status == "failed"
    output: dict = field(default_factory=dict)    # sanitized result of the step


@runtime_checkable
class Executor(Protocol):
    id: str

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        """Perform one resolved step against the target. ``step`` is a fully-resolved
        :class:`~.models.Step` dict (``${param}`` interpolated, ``{{vault…}}`` secrets
        already injected by the runner); ``ctx`` is the live run context. Return an
        outcome; never raise for an ordinary failure — set ``status='failed'`` instead."""
        ...

    def close(self) -> None:
        """Tear down any session/connection this executor opened (always called at the
        end of a run, even after a failure). Stateless executors no-op."""
        ...
