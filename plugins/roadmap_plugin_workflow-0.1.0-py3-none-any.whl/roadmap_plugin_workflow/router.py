"""HTTP surface: ``/api/workflow/{stepdefs,flows,invocations}``.

CRUD for stepdefs (reusable single-step templates) and flows, plus starting/polling
invocations. An invocation is started with ``POST /invocations`` and returns immediately;
the frontend polls ``GET /invocations/{id}`` for the growing report. (The credentials
vault endpoints are added in phase 3.)
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from . import vault
from .models import Flow, StepDef


class InvokeRequest(BaseModel):
    flow_id: str
    context: dict = {}


class ResumeRequest(BaseModel):
    approved: bool = True


class RerunStepRequest(BaseModel):
    index: int


class ProbeRequest(BaseModel):
    step: dict
    context: dict = {}
    ref: str = ""          # stepdef id when testing a derived step (merge before running)


class VaultWriteRequest(BaseModel):
    name: str
    kind: str = "basic"
    fields: dict = {}          # plaintext field values; blank value = keep existing
    notes: str = ""


def create_workflow_router(workflow) -> APIRouter:
    router = APIRouter(prefix="/api/workflow", tags=["workflow"])

    # ── executors (self-describing registry; drives the step editor form) ──────
    @router.get("/executors")
    def list_executors():
        return {"executors": workflow.list_executors()}

    # ── stepdefs (reusable single-step templates) ─────────────────────────────
    @router.get("/stepdefs")
    def list_stepdefs():
        return {"stepdefs": [s.model_dump() for s in workflow.list_stepdefs()]}

    @router.get("/stepdefs/{stepdef_id}")
    def get_stepdef(stepdef_id: str):
        s = workflow.get_stepdef(stepdef_id)
        if s is None:
            raise HTTPException(status_code=404, detail="Step definition not found.")
        return s.model_dump()

    @router.post("/stepdefs")
    def create_stepdef(stepdef: StepDef):
        return workflow.save_stepdef(stepdef).model_dump()

    @router.put("/stepdefs/{stepdef_id}")
    def update_stepdef(stepdef_id: str, stepdef: StepDef):
        stepdef.id = stepdef_id
        return workflow.save_stepdef(stepdef).model_dump()

    @router.delete("/stepdefs/{stepdef_id}")
    def delete_stepdef(stepdef_id: str):
        return {"deleted": workflow.delete_stepdef(stepdef_id)}

    # ── flows ──────────────────────────────────────────────────────────────────
    @router.get("/flows")
    def list_flows():
        return {"flows": [f.model_dump() for f in workflow.list_flows()]}

    @router.get("/flows/{flow_id}")
    def get_flow(flow_id: str):
        f = workflow.get_flow(flow_id)
        if f is None:
            raise HTTPException(status_code=404, detail="Flow not found.")
        return f.model_dump()

    @router.post("/flows")
    def create_flow(flow: Flow):
        return workflow.save_flow(flow).model_dump()

    @router.put("/flows/{flow_id}")
    def update_flow(flow_id: str, flow: Flow):
        flow.id = flow_id
        return workflow.save_flow(flow).model_dump()

    @router.delete("/flows/{flow_id}")
    def delete_flow(flow_id: str):
        return {"deleted": workflow.delete_flow(flow_id)}

    # ── probe (test a single step from the editor) ─────────────────────────────
    @router.post("/probe")
    def probe_step(req: ProbeRequest):
        """Run one step once and return the redacted result. A user action (the editor's
        Test button) — it executes the step against the real target, secrets injected
        server-side and redacted out of the response."""
        try:
            return workflow.probe_step(req.step, req.context, req.ref)
        except Exception as ex:
            raise HTTPException(status_code=400, detail=str(ex))

    # ── invocations ────────────────────────────────────────────────────────────
    @router.get("/invocations")
    def list_invocations():
        return {"invocations": [i.model_dump() for i in workflow.list_invocations()]}

    @router.post("/invocations")
    def start_invocation(req: InvokeRequest):
        try:
            return workflow.start_invocation(req.flow_id, req.context).model_dump()
        except ValueError as ex:
            raise HTTPException(status_code=404, detail=str(ex))

    @router.get("/invocations/{invocation_id}")
    def get_invocation(invocation_id: str):
        i = workflow.get_invocation(invocation_id)
        if i is None:
            raise HTTPException(status_code=404, detail="Invocation not found.")
        return i.model_dump()

    @router.post("/invocations/{invocation_id}/resume")
    def resume_invocation(invocation_id: str, req: ResumeRequest):
        i = workflow.resume_invocation(invocation_id, req.approved)
        if i is None:
            raise HTTPException(status_code=404, detail="Invocation not found.")
        return i.model_dump()

    @router.post("/invocations/{invocation_id}/rerun")
    def rerun_invocation(invocation_id: str):
        """Re-run the whole invocation from scratch (drops all prior step results)."""
        i = workflow.rerun_invocation(invocation_id)
        if i is None:
            raise HTTPException(status_code=404, detail="Invocation not found.")
        return i.model_dump()

    @router.post("/invocations/{invocation_id}/rerun-step")
    def rerun_step(invocation_id: str, req: RerunStepRequest):
        """Re-run a single step in place, replacing only that step's result."""
        i = workflow.rerun_step(invocation_id, req.index)
        if i is None:
            raise HTTPException(status_code=404, detail="Invocation not found.")
        return i.model_dump()

    @router.delete("/invocations/{invocation_id}")
    def delete_invocation(invocation_id: str):
        return {"deleted": workflow.delete_invocation(invocation_id)}

    # ── credentials vault (write + metadata only; no value is ever returned) ────
    @router.get("/vault")
    def list_vault():
        return {"credentials": workflow.list_credentials()}

    @router.get("/vault/{cred_id}")
    def get_credential(cred_id: str):
        m = workflow.get_credential(cred_id)
        if m is None:
            raise HTTPException(status_code=404, detail="Credential not found.")
        return m   # metadata only — no field values

    @router.post("/vault")
    def create_credential(req: VaultWriteRequest):
        try:
            return workflow.save_credential("", req.name, req.kind, req.fields, req.notes)
        except vault.VaultLocked as ex:
            raise HTTPException(status_code=423, detail=str(ex))

    @router.put("/vault/{cred_id}")
    def update_credential(cred_id: str, req: VaultWriteRequest):
        try:
            return workflow.save_credential(cred_id, req.name, req.kind, req.fields, req.notes)
        except vault.VaultLocked as ex:
            raise HTTPException(status_code=423, detail=str(ex))

    @router.delete("/vault/{cred_id}")
    def delete_credential(cred_id: str):
        return {"deleted": workflow.delete_credential(cred_id)}

    return router
