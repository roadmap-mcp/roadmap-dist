"""JSON persistence for stepdefs, flows, and invocations under ``<config_dir>/workflow/``.

Layout (workspace-aware, since ``config_dir`` is workspace-scoped)::

    workflow/
      stepdefs/<id>.json
      flows/<id>.json
      invocations/<id>.json
      vault/<id>.json        (encrypted credentials — see vault.py; added in phase 3)

No database — plain files, one per entity, matching how contexts and the other plugins
store their data. Invocations are persisted *incrementally* during execution so the UI
can poll a running report.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from . import runtime
from .models import Flow, FlowInvocation, StepDef


# ── directories ───────────────────────────────────────────────────────────────

def _dir(name: str) -> Path:
    d = runtime.workflow_dir() / name
    d.mkdir(parents=True, exist_ok=True)
    return d


def _stepdefs_dir() -> Path:
    return _dir("stepdefs")


def _flows_dir() -> Path:
    return _dir("flows")


def _invocations_dir() -> Path:
    return _dir("invocations")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ── stepdefs ──────────────────────────────────────────────────────────────────

def list_stepdefs() -> list[StepDef]:
    out = []
    for f in sorted(_stepdefs_dir().glob("*.json")):
        d = _read_json(f)
        if d:
            out.append(StepDef(**d))
    return sorted(out, key=lambda s: s.name.lower())


def get_stepdef(stepdef_id: str) -> StepDef | None:
    d = _read_json(_stepdefs_dir() / f"{stepdef_id}.json")
    return StepDef(**d) if d else None


def save_stepdef(stepdef: StepDef) -> StepDef:
    if not stepdef.id:
        stepdef.id = new_id("sd")
    _write_json(_stepdefs_dir() / f"{stepdef.id}.json", stepdef.model_dump())
    return stepdef


def delete_stepdef(stepdef_id: str) -> bool:
    f = _stepdefs_dir() / f"{stepdef_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── flows ─────────────────────────────────────────────────────────────────────

def list_flows() -> list[Flow]:
    out = []
    for f in sorted(_flows_dir().glob("*.json")):
        d = _read_json(f)
        if d:
            out.append(Flow(**d))
    return sorted(out, key=lambda s: s.name.lower())


def get_flow(flow_id: str) -> Flow | None:
    d = _read_json(_flows_dir() / f"{flow_id}.json")
    return Flow(**d) if d else None


def save_flow(flow: Flow) -> Flow:
    if not flow.id:
        flow.id = new_id("flow")
    _write_json(_flows_dir() / f"{flow.id}.json", flow.model_dump())
    return flow


def delete_flow(flow_id: str) -> bool:
    f = _flows_dir() / f"{flow_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── invocations ───────────────────────────────────────────────────────────────

def list_invocations() -> list[FlowInvocation]:
    out = []
    for f in _invocations_dir().glob("*.json"):
        d = _read_json(f)
        if d:
            out.append(FlowInvocation(**d))
    return sorted(out, key=lambda r: r.started, reverse=True)   # newest first


def get_invocation(invocation_id: str) -> FlowInvocation | None:
    d = _read_json(_invocations_dir() / f"{invocation_id}.json")
    return FlowInvocation(**d) if d else None


def save_invocation(inv: FlowInvocation) -> FlowInvocation:
    _write_json(_invocations_dir() / f"{inv.id}.json", inv.model_dump())
    return inv


def delete_invocation(invocation_id: str) -> bool:
    f = _invocations_dir() / f"{invocation_id}.json"
    existed = f.exists()
    if existed:
        f.unlink()
    return existed
