"""Per-process runtime wiring for the workflow engine.

Stashes the framework handles at activate time so the storage/engine/vault modules can
read config, resolve the on-disk data dir, and pick executors without threading the
context through every call. Because ``ConfigStore.path`` is already workspace-scoped,
everything under it is per-workspace automatically. Mirrors the e2e plugin's ``runtime``.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import WORKFLOW_EXECUTORS_POINT
from .models import WorkflowConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def config_dir() -> Path:
    assert _store is not None, "workflow runtime not initialised"
    return _store.path.parent


def workflow_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/workflow``). Created on demand."""
    d = config_dir() / "workflow"
    d.mkdir(parents=True, exist_ok=True)
    return d


def workflow_config() -> WorkflowConfig:
    assert _store is not None, "workflow runtime not initialised"
    raw = _store.load_decrypted()
    return WorkflowConfig(**(raw.get("workflow") or {}))


def store() -> ConfigStore:
    assert _store is not None, "workflow runtime not initialised"
    return _store


def services() -> ServiceRegistry:
    assert _services is not None, "workflow runtime not initialised"
    return _services


def _executors() -> list:
    if _extensions is None:
        return []
    return list(_extensions.get(WORKFLOW_EXECUTORS_POINT))


def executor_providers() -> list:
    """The registered executor providers (self-describing: id/label/icon/fields).
    Public accessor for the service so the UI can list executors + their config schema."""
    return _executors()


def component_env() -> SimpleNamespace:
    """Context handed to an executor provider's ``create(env)``: the resolved config
    and the data dir (an executor may want a place for downloads/artifacts)."""
    return SimpleNamespace(config=workflow_config(), workflow_dir=workflow_dir())


def resolve_executor(kind: str):
    """Build the executor for a step ``kind`` from its registered provider.

    Raises if no provider is registered for that kind — which means either an unknown
    kind or an executor plugin that isn't enabled in this workspace.
    """
    providers = _executors()
    chosen = next((p for p in providers if p.id == kind), None)
    if chosen is None:
        raise RuntimeError(
            f"No executor is registered for step kind '{kind}'. Enable the executor "
            f"plugin that provides it, or check the step's kind.")
    return chosen.create(component_env())
