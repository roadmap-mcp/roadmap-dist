"""Roadmap workflow-automation engine (executor-agnostic).

Owns the automation domain (stepdefs / flows / invocations), the credentials
vault, storage, the flow compiler + runner, the HTTP API, and the
``roadmap.workflow.executors`` extension point. An *executor* (built-in http /
shell / python / readdir, or a satellite plugin's browser executor) contributes an
:class:`ExecutorProvider` that builds an :class:`Executor` — the thing that actually
performs one resolved step against a target.

Re-exported here so executor plugins can ``from roadmap_plugin_workflow import
WORKFLOW_EXECUTORS_POINT, ExecutorProvider, ExecutorField, Executor, StepOutcome``
without reaching into submodules.
"""

from .contracts import WORKFLOW_EXECUTORS_POINT, ExecutorField, ExecutorProvider
from .ports import Executor, StepOutcome

__all__ = ["WORKFLOW_EXECUTORS_POINT", "ExecutorProvider", "ExecutorField",
           "Executor", "StepOutcome"]
