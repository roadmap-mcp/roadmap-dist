"""The flow compiler + runner.

The engine is executor-agnostic. It:

1. **compiles** a flow — turning its :class:`CompositeStep` list into an ordered list of
   concrete steps, carrying each entry's ``bindings``. An inline entry (``ref == ""``)
   contributes its ``step`` as-is; a reference entry (``ref != ""``) loads the named
   :class:`StepDef` template and overlays the entry's partial ``step`` (fill-ins) on top of
   it (a **live** reference). A dangling ref becomes a ``_broken`` failed step rather than
   crashing;
2. **interpolates** ``${param}`` from the run context into each step's ``config``/``label``;
3. **runs** each step on the executor named by its ``kind``, merging the sanitized output
   into the context (and into ``capture_as``), and **persists the invocation after every
   step** so the UI can poll a growing report.

Execution is backgrounded on a daemon thread that re-pins ``current_workspace`` (background
threads don't inherit it). Steps whose ``confirm`` gate is set pause the run
(``awaiting_approval``) until a human approves via :func:`resume`. ``{{vault…}}`` secret
resolution + redaction is layered into ``_resolve_step`` in phase 3.
"""

from __future__ import annotations

import re
import threading
import uuid
from datetime import datetime, timezone
from typing import Any

from roadmap_framework import current_workspace

from . import runtime, storage, vault
from .models import CompositeStep, Flow, Step, StepDef, StepResult

_PARAM_RE = re.compile(r"\$\{([^}]+)\}")
_VAULT_RE = re.compile(r"\{\{\s*vault\.([^.}\s]+)\.([^}\s]+)\s*\}\}")
_MASK = "••••••"   # ••••••


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _builtin_context() -> dict:
    """Read-only context values the engine seeds into every run so any step can use them
    via ``${…}`` (a flow param / captured value of the same name overrides them). Evaluated
    when the run starts, so ``${now}`` is the send time:

        now        ISO-8601 in the **server's local timezone**, with offset + milliseconds
                   (e.g. 2026-08-03T09:30:00.123+02:00)
        now_utc    ISO-8601 UTC, Zulu + ms (e.g. 2026-08-03T07:30:00.123Z — the JS
                   `Date.toISOString()` shape)
        now_unix   epoch seconds           (timezone-independent)
        now_ms     epoch milliseconds      (the JMSTimestamp / epoch-millis convention)
        uuid       a fresh uuid4, canonical dashed form (a correlation id / idempotency key,
                   e.g. 573bfb37-ec61-4ef6-b783-0b513ceb5cfb)
    """
    dt = datetime.now().astimezone()          # local time, tz-aware (current UTC offset)
    return {
        "now": dt.isoformat(timespec="milliseconds"),
        "now_utc": dt.astimezone(timezone.utc).isoformat(timespec="milliseconds").replace("+00:00", "Z"),
        "now_unix": str(int(dt.timestamp())),
        "now_ms": str(int(dt.timestamp() * 1000)),
        "uuid": str(uuid.uuid4()),
    }


# ── compile ───────────────────────────────────────────────────────────────────

def compile_flow(flow: Flow) -> list[tuple[str, Step, dict]]:
    """Flatten a flow to ``[(ref_label, Step, bindings), …]`` in execution order.

    Each :class:`CompositeStep` yields exactly one concrete step: an inline entry
    (``ref == ""``) contributes its ``step`` as-is; a reference entry (``ref != ""``)
    resolves its named :class:`StepDef` and merges the entry's fill-ins over the template
    (see :func:`_merge_stepdef`). A ref to a missing stepdef becomes a ``_broken`` step.
    """
    out: list[tuple[str, Step, dict]] = []
    for entry in flow.steps:
        merged = dict(entry.bindings or {})
        ref = entry.ref or ""
        if not ref:
            step = entry.step
            if step is None:
                out.append(("(empty)", _broken("Empty flow entry (no ref and no inline step)"), merged))
                continue
            label = step.label or step.kind
            out.append((label.strip(" /"), step, merged))
            continue
        sd = storage.get_stepdef(ref)
        if sd is None:
            out.append((ref, _broken(f"Unknown stepdef ref '{ref}'"), merged))
            continue
        step = _merge_stepdef(sd, entry)
        label = entry.label or sd.label or sd.name or sd.kind
        out.append((label.strip(" /"), step, merged))
    return out


def _merge_stepdef(sd: StepDef, entry: CompositeStep) -> Step:
    """Produce the concrete :class:`Step` for a reference entry: the stepdef ``sd`` as the
    template, with the entry's partial ``step`` (``ov``) as fill-ins/overrides.

    Fill-ins overlay only *blank* template config fields — a non-empty template value is
    inherited; a blank/absent override value does not clobber it.
    """
    ov = entry.step
    config = {
        **sd.config,
        **{k: v for k, v in (ov.config or {}).items() if v not in ("", None)},
    } if ov else dict(sd.config)
    return Step(
        id=(ov.id if ov and ov.id else sd.id),
        kind=sd.kind,
        label=(entry.label or sd.label),
        config=config,
        params=list(sd.params),
        uses_secrets=(ov.uses_secrets if (ov and ov.uses_secrets) else list(sd.uses_secrets)),
        capture_as=(ov.capture_as if (ov and ov.capture_as) else sd.capture_as),
        confirm=(sd.confirm or bool(ov and ov.confirm)),
        timeout=(ov.timeout if (ov and ov.timeout) else sd.timeout),
    )


def _broken(msg: str) -> Step:
    return Step(id="_broken", kind="_broken", label=msg)


def merge_probe_step(ref: str, overrides: Step) -> Step | None:
    """Merge a stepdef ``ref`` with the given fill-in ``overrides`` into one concrete Step —
    used by the editor's **Test** on a *derived* step, so the probe sees the stepdef's inherited
    (pre-filled) fields, not just the fill-ins. Returns ``None`` if the stepdef is missing."""
    sd = storage.get_stepdef(ref)
    if sd is None:
        return None
    return _merge_stepdef(sd, CompositeStep(ref=ref, step=overrides, bindings={},
                                            label=overrides.label or ""))


# ── interpolation ─────────────────────────────────────────────────────────────

def _interp(value, ctx: dict):
    """Recursively substitute ``${param}`` in strings, using ``ctx`` (missing → empty)."""
    if isinstance(value, str):
        return _PARAM_RE.sub(lambda m: str(ctx.get(m.group(1).strip(), "")), value)
    if isinstance(value, dict):
        return {k: _interp(v, ctx) for k, v in value.items()}
    if isinstance(value, list):
        return [_interp(v, ctx) for v in value]
    return value


def _resolve_secrets(value, secrets: set):
    """Recursively replace ``{{vault.name.field}}`` with the real (decrypted) value,
    collecting each injected plaintext in ``secrets`` for later redaction. An unresolved
    ref (locked server / unknown credential) is left in place so the step fails visibly."""
    if isinstance(value, str):
        def sub(m):
            val = vault.resolve(m.group(1), m.group(2))
            if val is None:
                return m.group(0)
            if val:
                secrets.add(val)
            return val
        return _VAULT_RE.sub(sub, value)
    if isinstance(value, dict):
        return {k: _resolve_secrets(v, secrets) for k, v in value.items()}
    if isinstance(value, list):
        return [_resolve_secrets(v, secrets) for v in value]
    return value


def _redact(value, secrets: set):
    """Replace every injected secret substring with a mask — applied to everything that is
    ever persisted or shown (resolved config, output, error messages)."""
    if not secrets:
        return value
    if isinstance(value, str):
        out = value
        for sec in secrets:
            if sec:
                out = out.replace(sec, _MASK)
        return out
    if isinstance(value, dict):
        return {k: _redact(v, secrets) for k, v in value.items()}
    if isinstance(value, list):
        return [_redact(v, secrets) for v in value]
    return value


def _resolve_step(step: Step, ctx: dict) -> tuple[dict, dict, set]:
    """Return ``(real, masked, secrets)``: the executor-facing resolved step (``${param}``
    interpolated + ``{{vault…}}`` secrets injected), a secret-masked copy for persistence/UI,
    and the set of plaintext secrets that were injected. Only ``real`` ever reaches the
    executor; only ``masked`` is ever stored or returned."""
    secrets: set = set()
    label = _resolve_secrets(_interp(step.label, ctx), secrets)
    config = _resolve_secrets(_interp(step.config, ctx), secrets)
    real = {
        "id": step.id, "kind": step.kind, "label": label, "config": config,
        "capture_as": step.capture_as, "timeout": step.timeout,
    }
    return real, _redact(real, secrets), secrets


# ── run ───────────────────────────────────────────────────────────────────────

def run_flow(invocation_id: str, start_index: int = 0, skip_confirm_at: int = -1) -> None:
    """Execute an invocation, persisting after every step.

    Runs steps ``start_index..N``. Before each step whose ``confirm`` gate is set (and
    ``workflow.require_confirmation`` is on), the runner appends an ``awaiting_approval``
    step result, sets the invocation ``awaiting_approval``, persists, and **stops** — the
    user resumes via :func:`resume`, which re-enters here with ``skip_confirm_at`` = the
    approved index so that one step runs instead of pausing again.
    """
    inv = storage.get_invocation(invocation_id)
    if inv is None:
        return
    flow = storage.get_flow(inv.flow_id)
    if flow is None:
        inv.status = "error"
        inv.error = f"Flow '{inv.flow_id}' not found."
        inv.finished = _now()
        storage.save_invocation(inv)
        return

    cfg = runtime.workflow_config()
    # re-seed context: engine builtins (now/uuid…), then param defaults, the invocation
    # inputs, and whatever prior steps captured (so a resumed run continues its context).
    # Later layers override builtins, so a user param named `now` still wins.
    ctx: dict = _builtin_context()
    ctx.update({p.name: p.default for p in flow.params})
    ctx.update(inv.context_in or {})
    ctx.update(inv.context_out or {})

    executors: dict[str, object] = {}
    paused = False
    try:
        steps = compile_flow(flow)
        i = start_index
        while i < len(steps):
            ref, step, bindings = steps[i]
            local = {**ctx, **bindings}
            if step.confirm and cfg.require_confirmation and i != skip_confirm_at:
                _, masked, _secrets = _resolve_step(step, local)
                inv.step_results.append(StepResult(
                    index=i, ref=ref, kind=step.kind, label=masked["label"],
                    status="awaiting_approval", started=_now(), resolved=masked))
                inv.status = "awaiting_approval"
                inv.context_out = dict(ctx)
                storage.save_invocation(inv)
                paused = True
                return
            result = _run_one(i, ref, step, local, executors)
            inv.step_results.append(result)
            if result.output:
                ctx.update(result.output if not step.capture_as
                           else {step.capture_as: result.output})
            inv.context_out = dict(ctx)
            storage.save_invocation(inv)
            if result.status == "failed":
                inv.status = "failed"
                _skip_rest(inv, steps, i + 1)
                break
            i += 1
        else:
            inv.status = "passed"
    except Exception as ex:   # pragma: no cover - defensive
        inv.status = "error"
        inv.error = f"{type(ex).__name__}: {ex}"
    finally:
        for ex in executors.values():
            try:
                ex.close()
            except Exception:
                pass
        if not paused:
            inv.finished = _now()
        storage.save_invocation(inv)


def run_probe(step: Step, ctx: dict | None = None) -> dict:
    """Run a **single** step once and return a fully-redacted result dict.

    This is the executor path the AI design assistant uses when the **user** clicks "Run"
    on a proposed step: it resolves ``${param}`` + injects ``{{vault…}}`` secrets, runs the
    step on its executor, then redacts every injected secret out of the result. Only the
    redacted ``{status, output, error, resolved}`` is returned — safe to show the user and
    to feed back into the AI's context. The AI never calls this itself; only a user action
    does. Secrets reach the real backend but never the response or the LLM.
    """
    ctx = {**_builtin_context(), **dict(ctx or {})}
    real, masked, secrets = _resolve_step(step, ctx)
    if step.kind == "_broken":
        return {"status": "failed", "error": step.label, "output": {}, "resolved": masked}
    ex = None
    try:
        ex = runtime.resolve_executor(step.kind)
        outcome = ex.run_step(real, ctx)
        return {"status": outcome.status, "error": _redact(outcome.error, secrets),
                "output": _redact(outcome.output, secrets), "resolved": masked}
    except Exception as e:
        return {"status": "failed", "error": _redact(f"{type(e).__name__}: {e}", secrets),
                "output": {}, "resolved": masked}
    finally:
        if ex is not None:
            try:
                ex.close()
            except Exception:
                pass


def _run_one(index: int, ref: str, step: Step, ctx: dict,
             executors: dict) -> StepResult:
    started = _now()
    if step.kind == "_broken":
        return StepResult(index=index, ref=ref, kind="_broken", label=step.label,
                          status="failed", started=started, finished=_now(),
                          error=step.label)
    real, masked, secrets = _resolve_step(step, ctx)
    try:
        ex = executors.get(step.kind)
        if ex is None:
            ex = runtime.resolve_executor(step.kind)
            executors[step.kind] = ex
        outcome = ex.run_step(real, ctx)   # only `real` (with secrets) reaches the executor
    except Exception as e:
        return StepResult(index=index, ref=ref, kind=step.kind, label=masked["label"],
                          status="failed", started=started, finished=_now(),
                          error=_redact(f"{type(e).__name__}: {e}", secrets), resolved=masked)
    # everything persisted/returned is redacted: resolved config, output, and error text.
    return StepResult(
        index=index, ref=ref, kind=step.kind, label=masked["label"],
        status=outcome.status, started=started, finished=_now(),
        error=_redact(outcome.error, secrets), output=_redact(outcome.output, secrets),
        resolved=masked)


def _skip_rest(inv, steps, start: int) -> None:
    for j in range(start, len(steps)):
        ref, step, _ = steps[j]
        inv.step_results.append(StepResult(
            index=j, ref=ref, kind=step.kind,
            label=step.label or step.kind, status="skipped"))


# ── background launch + resume ────────────────────────────────────────────────

def start_async(invocation_id: str, start_index: int = 0, skip_confirm_at: int = -1) -> None:
    """Run an invocation on a daemon thread, re-pinning the current workspace inside it.

    Background threads don't inherit request contextvars, so the worker re-pins
    ``current_workspace`` (captured before the thread starts) — otherwise the
    workspace-scoped storage dir resolves to the wrong tenant.
    """
    ws = current_workspace.get()

    def _worker() -> None:
        token = current_workspace.set(ws)
        try:
            run_flow(invocation_id, start_index, skip_confirm_at)
        finally:
            current_workspace.reset(token)

    threading.Thread(target=_worker, name=f"wf-inv-{invocation_id}", daemon=True).start()


def pending_index(inv) -> int:
    """Index of the step currently awaiting approval, or ``-1`` if none."""
    for r in inv.step_results:
        if r.status == "awaiting_approval":
            return r.index
    return -1


def resume(invocation_id: str, approved: bool) -> None:
    """Approve (continue) or abort the step an invocation is paused on."""
    inv = storage.get_invocation(invocation_id)
    if inv is None or inv.status != "awaiting_approval":
        return
    pend = pending_index(inv)
    if pend < 0:
        return
    # drop the awaiting_approval placeholder — it's re-created or replaced below.
    inv.step_results = [r for r in inv.step_results if r.status != "awaiting_approval"]

    if not approved:
        flow = storage.get_flow(inv.flow_id)
        steps = compile_flow(flow) if flow else []
        for j in range(pend, len(steps)):
            ref, step, _ = steps[j]
            inv.step_results.append(StepResult(
                index=j, ref=ref, kind=step.kind,
                label=step.label or step.kind, status="skipped"))
        inv.status = "failed"
        inv.error = f"Aborted by user before step {pend + 1}."
        inv.finished = _now()
        storage.save_invocation(inv)
        return

    inv.status = "running"
    storage.save_invocation(inv)
    start_async(invocation_id, start_index=pend, skip_confirm_at=pend)


# ── re-run (whole flow / single step) ─────────────────────────────────────────

def _replay_context(flow: Flow, inv, steps, upto: int | None = None) -> dict:
    """Rebuild the run context from param defaults + inputs + the captured outputs of the
    persisted step results whose index is ``< upto`` (default: all steps). Mirrors how the
    live runner accumulates context, so a re-run step sees exactly what it would have."""
    limit = len(steps) if upto is None else min(upto, len(steps))
    ctx: dict = _builtin_context()
    ctx.update({p.name: p.default for p in flow.params})
    ctx.update(inv.context_in or {})
    by_index = {r.index: r for r in inv.step_results}
    for j in range(limit):
        r = by_index.get(j)
        if r is None or not r.output:
            continue
        _, step, _ = steps[j]
        ctx.update(r.output if not step.capture_as else {step.capture_as: r.output})
    return ctx


def rerun_flow(invocation_id: str) -> None:
    """Re-run the whole invocation from scratch: drop **all** step results + captured
    context, then run again from the top with the original inputs (``context_in``)."""
    inv = storage.get_invocation(invocation_id)
    if inv is None:
        return
    inv.step_results = []
    inv.context_out = {}
    inv.status = "running"
    inv.error = ""
    inv.started = _now()
    inv.finished = ""
    storage.save_invocation(inv)
    start_async(invocation_id, start_index=0)


def rerun_step_async(invocation_id: str, index: int) -> None:
    """Re-run a **single** already-run step in place, replacing only its result — later
    steps keep theirs. Marks the step ``running`` so the UI streams a spinner, then executes
    on a daemon thread that re-pins ``current_workspace`` (as the main runner does)."""
    inv = storage.get_invocation(invocation_id)
    if inv is None:
        return
    flow = storage.get_flow(inv.flow_id)
    if flow is None:
        return
    steps = compile_flow(flow)
    if not (0 <= index < len(steps)):
        return
    for r in inv.step_results:
        if r.index == index:
            r.status = "running"
            r.error = ""
            r.output = {}
            r.started = _now()
            r.finished = ""
            break
    inv.status = "running"
    inv.finished = ""
    storage.save_invocation(inv)

    ws = current_workspace.get()

    def _worker() -> None:
        token = current_workspace.set(ws)
        try:
            _do_rerun_step(invocation_id, index)
        finally:
            current_workspace.reset(token)

    threading.Thread(target=_worker, name=f"wf-rerun-{invocation_id}-{index}", daemon=True).start()


def _do_rerun_step(invocation_id: str, index: int) -> None:
    inv = storage.get_invocation(invocation_id)
    if inv is None:
        return
    flow = storage.get_flow(inv.flow_id)
    if flow is None:
        return
    executors: dict[str, Any] = {}
    try:
        steps = compile_flow(flow)
        if not (0 <= index < len(steps)):
            return
        ref, step, bindings = steps[index]
        local = {**_replay_context(flow, inv, steps, upto=index), **bindings}
        result = _run_one(index, ref, step, local, executors)
        # replace this index's result (or slot it in order if it was somehow missing)
        for k, r in enumerate(inv.step_results):
            if r.index == index:
                inv.step_results[k] = result
                break
        else:
            inv.step_results.append(result)
            inv.step_results.sort(key=lambda r: r.index)
        # recompute the captured context so it reflects the replaced step
        inv.context_out = _replay_context(flow, inv, steps)
        inv.status = "failed" if any(
            r.status in ("failed", "error") for r in inv.step_results) else "passed"
        inv.error = ""
        inv.finished = _now()
    except Exception as ex:   # pragma: no cover - defensive
        inv.status = "error"
        inv.error = f"{type(ex).__name__}: {ex}"
    finally:
        for ex in executors.values():
            try:
                ex.close()
            except Exception:
                pass
        storage.save_invocation(inv)
