"""Pydantic models for the workflow-automation domain.

The shape mirrors the e2e engine (reusable *steps* → captured as reusable *step
definitions* (stepdefs) → composed into *flows* → executed as *invocations* with
per-step results), but is generic: a step names an **executor** (``kind``) instead of a
browser action, its ``config`` is schema-less (executor-specific), and it can declare the
vault ``uses_secrets`` it needs and a per-step ``confirm`` gate (enterprise safety — the
runner pauses for explicit user approval before touching a backend system).

Ids are assigned by the storage layer (``new_id`` with a per-entity prefix). The string
list ``STEP_KINDS`` stands in for an enum, matching the rest of the codebase.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

#: executor ids a step can run on — one per built-in :class:`Executor`.
STEP_KINDS = ["http", "shell", "python", "readdir", "mock"]


class Step(BaseModel):
    """One reusable action, executed by the executor named in ``kind``.

    ``config`` is schema-less and executor-specific, e.g.::

        http     {method, url, headers, body, expect_status}
        shell    {command, cwd}
        python   {snippet}
        readdir  {path, glob, read}

    Both ``config`` string values and the ``label`` support ``${param}`` interpolation
    from the run context and ``{{vault.<name>.<field>}}`` credential references (the
    latter resolved only at run time by the runner — never by an AI, never returned in
    an API response). ``uses_secrets`` lists the vault credential names this step needs
    (drives redaction). ``capture_as`` stores the step's sanitized output into a context
    key. ``confirm`` makes the runner pause for explicit user approval before this step.
    """

    id: str
    kind: str = "http"                              # one of STEP_KINDS
    label: str = ""
    config: dict = Field(default_factory=dict)      # executor-specific, ${param}/{{vault…}} aware
    params: list[str] = Field(default_factory=list)  # ${param} names it reads (UX hint)
    uses_secrets: list[str] = Field(default_factory=list)  # vault credential names (names only)
    capture_as: str = ""                            # context key to store output into
    confirm: bool = False                           # per-step approval gate (enterprise safety)
    timeout: float | None = None


class CompositeStep(BaseModel):
    """One ordered entry in a flow — the composition primitive.

    If ``ref == ""`` the entry is an **inline** action and ``step`` is the full
    :class:`Step` (unchanged behaviour). If ``ref != ""`` it names a **stepdef id**; the
    engine loads that :class:`StepDef` template and overlays this entry's ``step`` (a
    *partial* Step holding only the fill-ins/overrides) on top of it at run time — a live
    reference, so editing the stepdef changes every flow that uses it. ``bindings`` overlay
    the run context for this entry (remap ``{"user": "${admin}"}`` or pin ``{"user": "root"}``).
    """

    ref: str = ""
    step: Step | None = None
    bindings: dict[str, str] = Field(default_factory=dict)
    label: str = ""                                 # this entry's display name in the flow


class StepDef(BaseModel):
    """A reusable **template for a single step** — the same attributes as a :class:`Step`,
    but partially filled, plus a ``name`` + ``description``.

    A flow step references a stepdef by id and fills in the remaining (blank) fields; the
    engine merges template + fill-ins at run time (see :func:`engine._merge_stepdef`).
    Because the merge reads the stepdef live, editing it changes every flow that uses it.
    ``description`` is the catalog text the flow-composer AI reads (never any secret value).
    """

    id: str
    name: str
    description: str = ""
    kind: str = "http"                              # one of STEP_KINDS
    label: str = ""
    config: dict = Field(default_factory=dict)      # executor-specific; blank fields = fill-in slots
    capture_as: str = ""
    uses_secrets: list[str] = Field(default_factory=list)
    confirm: bool = False
    timeout: float | None = None
    params: list[str] = Field(default_factory=list)


class FlowParam(BaseModel):
    name: str
    label: str = ""
    default: str = ""
    required: bool = False


class Flow(BaseModel):
    """An ordered composition of inline steps and stepdef references, with declared parameters."""

    id: str
    name: str
    description: str = ""
    params: list[FlowParam] = Field(default_factory=list)
    steps: list[CompositeStep] = Field(default_factory=list)


class StepResult(BaseModel):
    """Per-step progress within an invocation (persisted incrementally so the UI polls).

    ``status`` ∈ ``pending|running|passed|failed|skipped|awaiting_approval``. ``output``
    is the executor's **sanitized/redacted** result (status code, stdout head, …).
    ``resolved`` is the interpolated config actually run, with any secret values masked.
    """

    index: int
    ref: str = ""
    kind: str = ""
    label: str = ""
    status: str = "pending"
    started: str = ""
    finished: str = ""
    error: str = ""
    output: dict = Field(default_factory=dict)
    resolved: dict = Field(default_factory=dict)


class FlowInvocation(BaseModel):
    """One execution instance of a flow (the automation analog of a test run).

    ``status`` ∈ ``running|passed|failed|error|awaiting_approval``. ``context_out`` holds
    the live/final context (captured outputs); ``step_results`` grows as the run advances.
    """

    id: str
    flow_id: str
    flow_name: str = ""
    status: str = "running"
    started: str = ""
    finished: str = ""
    context_in: dict = Field(default_factory=dict)
    context_out: dict = Field(default_factory=dict)
    step_results: list[StepResult] = Field(default_factory=list)
    error: str = ""


class WorkflowConfig(BaseModel):
    """The ``workflow`` config slice (a Workflows settings tab).

    ``shell_enabled`` / ``python_enabled`` are **off by default** — arbitrary shell and
    python are the riskiest surface in an enterprise environment, so they are opt-in.
    ``require_confirmation`` honors per-step ``confirm`` gates.
    """

    default_timeout: float = 30.0
    shell_enabled: bool = False
    python_enabled: bool = False
    require_confirmation: bool = True
