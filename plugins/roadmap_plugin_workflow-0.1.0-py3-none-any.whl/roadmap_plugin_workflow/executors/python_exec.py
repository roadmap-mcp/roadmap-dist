"""The ``python`` executor — run one python snippet.

**Off by default** (``workflow.python_enabled``): ``exec`` is not a sandbox, so arbitrary
python is opt-in, exactly like the shell executor.

``config.snippet`` runs with ``ctx`` (a copy of the live run context) and an empty
``result`` dict in scope; whatever the snippet puts in ``result`` becomes the step's
sanitized output (and, with ``capture_as``, is stored in the context). Raise / assert to
fail the step.
"""

from __future__ import annotations

from ..ports import StepOutcome


class PythonExecutor:
    id = "python"

    def __init__(self, config):
        self._enabled = bool(getattr(config, "python_enabled", False))

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        if not self._enabled:
            return StepOutcome(status="failed",
                               error="Python executor is disabled. Enable it in "
                                     "Settings → Workflows.")
        c = step.get("config") or {}
        snippet = c.get("snippet") or ""
        if not snippet.strip():
            return StepOutcome(status="failed", error="python step needs config.snippet")

        glbls: dict = {"__builtins__": __builtins__}
        lcls: dict = {"ctx": dict(ctx), "result": {}}
        try:
            exec(snippet, glbls, lcls)   # noqa: S102 - opt-in, gated executor
        except AssertionError as e:
            return StepOutcome(status="failed", error=f"Assertion failed: {e}")
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        res = lcls.get("result")
        out = res if isinstance(res, dict) else {"result": res}
        return StepOutcome(status="passed", output=out)

    def close(self) -> None:
        return None
