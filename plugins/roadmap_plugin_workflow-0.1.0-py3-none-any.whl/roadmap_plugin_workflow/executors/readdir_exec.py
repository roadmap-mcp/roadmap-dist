"""The ``readdir`` executor — list (and optionally read) files under a directory.

Always available (read-only, no side effects). ``config`` fields::

    path   directory or single file (required)
    glob   glob pattern within a directory (default ``*``)
    read   when true, include each file's text content (head-limited)

Returns ``{count, files:[{name, path, size, content?}]}`` (capped at 200 files, content
head-limited). A missing path is an ordinary ``failed`` outcome.
"""

from __future__ import annotations

from pathlib import Path

from ..ports import StepOutcome

_MAX_FILES = 200
_CONTENT_HEAD = 20000


class ReaddirExecutor:
    id = "readdir"

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        c = step.get("config") or {}
        path = (c.get("path") or "").strip()
        if not path:
            return StepOutcome(status="failed", error="readdir step needs config.path")
        pattern = c.get("glob") or "*"
        read = bool(c.get("read"))

        p = Path(path)
        if not p.exists():
            return StepOutcome(status="failed", error=f"path not found: {path}")
        try:
            entries = [p] if p.is_file() else sorted(
                x for x in p.glob(pattern) if x.is_file())
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        files = []
        for f in entries[:_MAX_FILES]:
            item = {"name": f.name, "path": str(f), "size": f.stat().st_size}
            if read:
                try:
                    item["content"] = f.read_text(encoding="utf-8", errors="replace")[:_CONTENT_HEAD]
                except Exception as e:
                    item["content_error"] = str(e)
            files.append(item)
        return StepOutcome(status="passed", output={"count": len(files), "files": files})

    def close(self) -> None:
        return None
