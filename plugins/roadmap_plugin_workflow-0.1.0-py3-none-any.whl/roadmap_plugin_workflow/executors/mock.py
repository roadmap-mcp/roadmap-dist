"""A dependency-free executor: a deterministic in-memory stand-in for a real target.

It lets the whole engine — compile, interpolate, resolve secrets, run, capture, report,
persist — work and be tested without any real backend, and backs UI previews. It simply
echoes its resolved config back as the step output (so ``capture_as`` round-trips), and
can be told to fail via ``config.fail = true`` to exercise the failure path.
"""

from __future__ import annotations

from ..ports import StepOutcome


class MockExecutor:
    id = "mock"

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        config = step.get("config") or {}
        if config.get("fail"):
            return StepOutcome(status="failed", error=str(config.get("fail")))
        # echo the resolved config back as the (sanitized) output so a typed value
        # round-trips through capture_as, exactly like the e2e mock driver's fields.
        return StepOutcome(status="passed", output={"echo": config})

    def close(self) -> None:
        return None
