"""The ``shell`` executor — run one shell command via ``subprocess``.

**Off by default** (``workflow.shell_enabled``): arbitrary shell is the riskiest surface in
an enterprise environment, so the executor refuses to run until explicitly enabled in
Settings → Workflows.

``config`` fields::

    command  the shell command line (required)
    cwd      optional working directory

Returns ``{returncode, stdout(head), stderr(head)}``. A non-zero exit is an ordinary
``failed`` outcome.
"""

from __future__ import annotations

import subprocess

from ..ports import StepOutcome

_OUT_HEAD = 8000


class ShellExecutor:
    id = "shell"

    def __init__(self, config):
        self._enabled = bool(getattr(config, "shell_enabled", False))
        self._timeout = getattr(config, "default_timeout", 30.0)

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        if not self._enabled:
            return StepOutcome(status="failed",
                               error="Shell executor is disabled. Enable it in "
                                     "Settings → Workflows.")
        c = step.get("config") or {}
        command = c.get("command") or ""
        if not command.strip():
            return StepOutcome(status="failed", error="shell step needs config.command")
        cwd = c.get("cwd") or None
        timeout = step.get("timeout") or self._timeout
        try:
            proc = subprocess.run(command, shell=True, cwd=cwd, capture_output=True,
                                  text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return StepOutcome(status="failed", error=f"shell command timed out after {timeout}s")
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        out = {"returncode": proc.returncode,
               "stdout": (proc.stdout or "")[:_OUT_HEAD],
               "stderr": (proc.stderr or "")[:_OUT_HEAD]}
        if proc.returncode != 0:
            return StepOutcome(status="failed", error=f"exit code {proc.returncode}", output=out)
        return StepOutcome(status="passed", output=out)

    def close(self) -> None:
        return None
