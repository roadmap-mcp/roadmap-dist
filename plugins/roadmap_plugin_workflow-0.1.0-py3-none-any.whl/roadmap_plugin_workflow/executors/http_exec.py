"""The ``http`` executor — perform one REST/HTTP request with ``httpx``.

``config`` fields (all ``${param}``/``{{vault…}}`` aware, resolved by the engine before
we see them)::

    method         GET | POST | PUT | PATCH | DELETE | …   (default GET)
    url            request URL (required)
    headers        object of request headers
    body           string, or object/array (sent as JSON)
    expect_status  optional int — the exact status that counts as success
                   (default: any 2xx/3xx passes)

Returns a sanitized ``output`` of ``{status, body(head), headers, json?}``. A non-2xx/3xx
(or a mismatch against ``expect_status``) is an ordinary ``failed`` outcome, not a raise.
"""

from __future__ import annotations

import httpx

from ..ports import StepOutcome

_BODY_HEAD = 4000


class HttpExecutor:
    id = "http"

    def __init__(self, config):
        self._timeout = getattr(config, "default_timeout", 30.0)

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        c = step.get("config") or {}
        url = (c.get("url") or "").strip()
        if not url:
            return StepOutcome(status="failed", error="http step needs config.url")
        method = (c.get("method") or "GET").upper()
        headers = {k: str(v) for k, v in (c.get("headers") or {}).items()}
        body = c.get("body")
        expect = c.get("expect_status")
        timeout = step.get("timeout") or self._timeout

        kwargs: dict = {"headers": headers}
        if body not in (None, ""):
            if isinstance(body, (dict, list)):
                kwargs["json"] = body
            else:
                kwargs["content"] = str(body)
        try:
            with httpx.Client(timeout=timeout, follow_redirects=True) as client:
                resp = client.request(method, url, **kwargs)
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        out: dict = {
            "status": resp.status_code,
            "body": resp.text[:_BODY_HEAD],
            "headers": dict(resp.headers),
        }
        try:
            out["json"] = resp.json()
        except Exception:
            pass

        ok = (200 <= resp.status_code < 400) if expect is None \
            else (resp.status_code == int(expect))
        if not ok:
            return StepOutcome(status="failed", error=f"HTTP {resp.status_code}", output=out)
        return StepOutcome(status="passed", output=out)

    def close(self) -> None:
        return None
