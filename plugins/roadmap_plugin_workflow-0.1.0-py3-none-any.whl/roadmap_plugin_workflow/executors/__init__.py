"""Built-in executors shipped with the engine.

Which one runs a step is chosen by the step's ``kind``:

* ``http``    — a REST/HTTP request (``httpx``).
* ``shell``   — a shell command (``subprocess``); **off by default** (``shell_enabled``).
* ``python``  — a python snippet (``exec``); **off by default** (``python_enabled``).
* ``readdir`` — list/read files under a directory (read-only, always available).
* ``mock``    — a browser-free, side-effect-free stand-in for tests and previews.

A Selenium/browser executor lives in its own satellite plugin. Each executor is supplied
as an :class:`~..contracts.ExecutorProvider` whose ``create(env)`` builds it lazily from
the resolved config (``env.config``).
"""

from ..contracts import ExecutorField, ExecutorProvider
from .http_exec import HttpExecutor
from .mock import MockExecutor
from .python_exec import PythonExecutor
from .readdir_exec import ReaddirExecutor
from .shell_exec import ShellExecutor

_HTTP_METHODS = ["GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"]

BUILTIN_EXECUTORS = [
    ExecutorProvider(
        id="http", label="HTTP / REST", icon="bi-hdd-network",
        create=lambda env: HttpExecutor(env.config),
        fields=[
            ExecutorField(key="method", label="Method", type="select", options=_HTTP_METHODS),
            ExecutorField(key="url", label="URL", type="text",
                          placeholder="https://api.example.com/…"),
            ExecutorField(key="headers", label="Headers", type="headers"),
            ExecutorField(key="body", label="Body", type="textarea",
                          placeholder="raw string or JSON"),
            ExecutorField(key="expect_status", label="Expect status", type="number",
                          hint="blank = any 2xx/3xx passes"),
        ]),
    ExecutorProvider(
        id="shell", label="Shell command", icon="bi-terminal",
        create=lambda env: ShellExecutor(env.config),
        fields=[
            ExecutorField(key="command", label="Command", type="textarea", placeholder="ls -la"),
            ExecutorField(key="cwd", label="Working dir", type="text"),
        ]),
    ExecutorProvider(
        id="python", label="Python snippet", icon="bi-filetype-py",
        create=lambda env: PythonExecutor(env.config),
        fields=[
            ExecutorField(key="snippet", label="Python", type="textarea",
                          placeholder="# reads `ctx`, sets `result`\nresult = {'ok': True}"),
        ]),
    ExecutorProvider(
        id="readdir", label="Read directory", icon="bi-folder2-open",
        create=lambda env: ReaddirExecutor(),
        fields=[
            ExecutorField(key="path", label="Path", type="text", placeholder="/data/incoming"),
            ExecutorField(key="glob", label="Glob", type="text", placeholder="*.csv"),
            ExecutorField(key="read", label="Read file contents", type="checkbox"),
        ]),
    ExecutorProvider(
        id="mock", label="Mock (no side effects)", icon="bi-dot",
        create=lambda env: MockExecutor()),
]

__all__ = ["BUILTIN_EXECUTORS", "HttpExecutor", "ShellExecutor",
           "PythonExecutor", "ReaddirExecutor", "MockExecutor"]
