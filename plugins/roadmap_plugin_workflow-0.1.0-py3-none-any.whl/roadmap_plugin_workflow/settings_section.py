"""The Workflows settings section (the ``workflow`` config slice + defaults)."""

from roadmap_plugin_settings import SettingsSection

from .models import WorkflowConfig

WORKFLOW_SECTION = SettingsSection(
    id="workflow",
    label="Workflows",
    order=52,
    group="Automation",
    defaults=lambda: {"workflow": WorkflowConfig().model_dump()},
)
