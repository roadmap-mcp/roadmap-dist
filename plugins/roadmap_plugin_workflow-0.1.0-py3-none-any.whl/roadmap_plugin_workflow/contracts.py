"""The workflow engine's one extension point: pluggable step *executors*.

An executor is what actually performs a step against a target — built-in ``http`` /
``shell`` / ``python`` / ``readdir`` today; a Selenium/browser executor as a satellite
plugin later. Executors are supplied as a small ``{id, label, create}`` *provider*
descriptor whose ``create(env)`` builds the :class:`~.ports.Executor` lazily (an
executor may need runtime context — the resolved config, the data dir — so it is built
on demand, not registered as a pre-made singleton).

Unlike the e2e engine (one driver per run), a *step* names the executor it runs on via
its ``kind``, so a single flow can mix HTTP calls, shell snippets, and directory reads.
The engine declares this point and contributes the built-in executors; any other plugin
contributes an alternative by depending on ``roadmap.workflow`` and extending
:data:`WORKFLOW_EXECUTORS_POINT`.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

WORKFLOW_EXECUTORS_POINT = "roadmap.workflow.executors"


@dataclass
class ExecutorField:
    """One config field an executor understands — drives the step editor's form.

    ``type`` is one of ``text | textarea | number | checkbox | select | headers``. The
    ``headers`` type renders the dedicated key/value editor; everything else is a plain
    typed input. This is the backend source of truth the frontend renders from, so a new
    executor (in any plugin) shows the right fields in the UI without touching the engine.
    """

    key: str
    label: str
    type: str = "text"
    options: list[str] = field(default_factory=list)   # for type == "select"
    placeholder: str = ""
    hint: str = ""


@dataclass
class ExecutorProvider:
    """Registers a named :class:`~.ports.Executor` implementation.

    Beyond wiring (``create``), a provider is **self-describing**: ``icon`` + ``fields``
    let the workflow UI list the executor and render its config form from the backend,
    so a capability plugin contributes a new step kind end-to-end without any engine edit.
    """

    id: str                               # "http", "shell", "python", "readdir", "sql", …
    label: str
    create: Callable[[Any], Any]          # create(env) -> Executor
    icon: str = "bi-box"                  # bootstrap icon for the step kind
    fields: list[ExecutorField] = field(default_factory=list)  # config fields (UI schema)
