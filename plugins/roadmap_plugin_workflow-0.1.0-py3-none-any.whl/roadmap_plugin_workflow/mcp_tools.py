"""Workflow MCP tools on the shared server.

* ``workflow_list_flows`` — list runnable flows (id + name + params).
* ``workflow_run``        — start an invocation (async); returns the id to poll.
* ``workflow_get``        — the step-by-step report for an invocation id (markdown).

Follows the e2e convention: *start returns an id; a separate tool polls it*. No
``from __future__ import annotations`` — FastMCP introspects the real annotations.

Note: an MCP client can start and read flows, but it **cannot** create/approve steps or
read credentials — the vault is never exposed, and a paused (``awaiting_approval``) flow
can only be resumed by a human in the UI. This keeps the "AI proposes, user runs" boundary
intact even over MCP.
"""

import json


def register_mcp_tools(context, workflow) -> None:
    mcp = context.mcp

    @mcp.tool()
    def workflow_list_flows() -> str:
        """List the workflows (flows) that can be run, with their parameters."""
        flows = workflow.list_flows()
        if not flows:
            return "No flows defined. Create one in the Workflows workbench first."
        lines = ["# Workflows", ""]
        for f in flows:
            params = ", ".join(p.name for p in f.params) or "none"
            lines.append(f"- `{f.id}` — {f.name} ({len(f.steps)} step(s); params: {params})")
        return "\n".join(lines)

    @mcp.tool()
    def workflow_run(flow_id: str, context_json: str = "") -> str:
        """Start a workflow invocation.

        The invocation executes in the background; use ``workflow_get`` with the returned
        id to poll status and read the step-by-step report. If any step has a confirmation
        gate, the invocation pauses (``awaiting_approval``) and must be resumed by a human
        in the Workflows UI.

        Args:
            flow_id:      the flow's id (from workflow_list_flows).
            context_json: optional JSON object of parameter values, e.g. '{"user": "alice"}'.
        """
        ctx = {}
        if context_json.strip():
            try:
                ctx = json.loads(context_json)
            except json.JSONDecodeError as ex:
                return f"Invalid context_json: {ex}"
        try:
            inv = workflow.start_invocation(flow_id, ctx)
        except ValueError as ex:
            return str(ex)
        return (f"Started invocation `{inv.id}` for '{inv.flow_name}' (status: {inv.status}). "
                f"Poll it with workflow_get('{inv.id}').")

    @mcp.tool()
    def workflow_get(invocation_id: str) -> str:
        """The step-by-step report for an invocation id (status + per-step results), markdown."""
        inv = workflow.get_invocation(invocation_id)
        if inv is None:
            return f"Invocation '{invocation_id}' not found."
        return workflow.render_invocation(invocation_id)
