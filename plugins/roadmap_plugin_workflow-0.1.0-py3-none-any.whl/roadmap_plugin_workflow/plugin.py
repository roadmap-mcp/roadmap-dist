"""Workflow-automation engine plugin activator (executor-agnostic).

Declares the ``roadmap.workflow.executors`` extension point, contributes the built-in
executors (phase 1: browser-free ``mock``), publishes the ``workflow`` service, mounts
``/api/workflow`` (stepdefs / flows / invocations), and contributes a Workflows settings
tab. Real executors, the credentials vault, the context/MCP surfaces, and the AI assistants
are wired by later phases / their own plugins.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .contracts import WORKFLOW_EXECUTORS_POINT, ExecutorProvider
from .executors import BUILTIN_EXECUTORS
from .mcp_tools import register_mcp_tools
from .router import create_workflow_router
from .service import WorkflowService
from .settings_section import WORKFLOW_SECTION


class WorkflowPlugin(Plugin):
    id = "roadmap.workflow"
    name = "Workflows"
    requires = ["roadmap.settings", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)

        # the swappable component: the step executor (http, shell, browser, …)
        ctx.define_point(WORKFLOW_EXECUTORS_POINT, ExecutorProvider,
                         "Executors that perform one resolved step against a target.")
        for ex in BUILTIN_EXECUTORS:
            ctx.extend(WORKFLOW_EXECUTORS_POINT, ex)

        ctx.extend(SETTINGS_SECTIONS_POINT, WORKFLOW_SECTION)

        workflow = WorkflowService()
        ctx.services.register("workflow", workflow)
        ctx.add_router(create_workflow_router(workflow))
        register_mcp_tools(ctx.services.require("context"), workflow)
