"""Per-process runtime wiring for the flow runner.

Stashes the framework handles at activate time so the readers and the engine can
reach config, services and the reader registry without threading a context
through every call. Mirrors the knowledgebase / gitmining plugins' ``runtime``.
"""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import FLOW_READERS_POINT, FlowReader

#: The slice this plugin reads out of the shared config document. It configures
#: nothing of its own — a flow is Knowledge Base configuration — but it does
#: need the repository list to resolve a ``repo`` source.
DEFAULTS = {
    "repositories": [],
}

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def load_config():
    assert _store is not None, "knowledgebase-flows runtime not initialised"
    return _store.load_ns(DEFAULTS)


def services() -> ServiceRegistry:
    assert _services is not None, "knowledgebase-flows runtime not initialised"
    return _services


def kb():
    """The Knowledge Base service — a hard dependency, so this may raise."""
    return services().require("knowledgebase")


def ai():
    """The AI service, or ``None``.

    Soft on purpose even though the plugin requires ``roadmap.ai``: a workspace
    can have the plugin on with no provider configured, and that should read as
    "nothing to run with" rather than as a crash.
    """
    try:
        return services().get("ai")
    except Exception:
        return None


def readers() -> list[FlowReader]:
    if _extensions is None:
        return []
    return list(_extensions.get(FLOW_READERS_POINT))


def reader_for(kind: str) -> Optional[FlowReader]:
    return next((r for r in readers() if r.id == kind), None)
