"""``/api/knowledgebase-flows`` — what only the runner can answer.

Deliberately small. Starting a run is the Knowledge Base's own
``POST /flows/{id}/run``, because that is where a flow lives and the page
calling it should not have to know whether a satellite is installed — the core
asks this plugin through the service registry and returns 501 when it is not.

What is left here is the part that is genuinely this plugin's: which source
kinds can be read, and whether there is a provider to read them with.
"""

from __future__ import annotations

from fastapi import APIRouter

from . import runtime
from .engine import TASK_TYPE


def create_flow_runner_router() -> APIRouter:
    router = APIRouter(prefix="/api/knowledgebase-flows", tags=["knowledgebase-flows"])

    @router.get("/status")
    def status():
        """Whether this deployment can actually run a flow, and with what.

        The settings tab shows Run on the strength of this: a button that is
        always there and always fails is worse than one that is absent with a
        reason beside it.
        """
        ai = runtime.ai()
        provider = ai.provider_for_task(TASK_TYPE) if ai is not None else None
        return {
            "installed": True,
            "provider": getattr(provider, "name", ""),
            "model": getattr(provider, "default_model", ""),
            "readers": [
                {"id": r.id, "label": r.label, "description": r.description}
                for r in runtime.readers()
            ],
        }

    return router
