"""The flow runner's one extension point: **source readers**.

A flow names what it reads (``source.kind`` + ``ref`` + ``scope``); a
:class:`FlowReader` is what turns that into the material the prompt is built
from. The built-ins cover a configured Git Repo's working tree, the nodes
already in the graph, and a Roadmap context; a satellite adds a reader for
anything else — a git-mining mirror at a historical commit, a Confluence space,
a database schema — with no change to the engine.

``id`` matches ``FlowSource.kind``, so adding a reader is what makes a new kind
of source selectable at all.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable

FLOW_READERS_POINT = "roadmap.knowledgebase.flows.readers"


@dataclass
class ReadResult:
    """What a reader produced.

    ``material`` is dropped into the prompt verbatim, so a reader is responsible
    for making it legible — file headings, node titles, whatever the shape
    deserves. ``truncated`` is not a detail: a run over half a codebase that
    says it read all of it is worse than one that refuses, so the engine records
    it on the run and the prompt says so.
    """

    label: str = ""
    material: str = ""
    items: int = 0
    truncated: bool = False
    #: where the source stood, if it can say — a commit for a repository. The
    #: engine records it on the run, which is how the scheduled scan later knows
    #: this state has already been analysed. Empty means "cannot tell", and a
    #: source that cannot tell is never started by the scan.
    position: str = ""
    notes: list[str] = field(default_factory=list)


@dataclass
class FlowReader:
    """Registers a way of reading one kind of flow source.

    ``read(source, max_chars)`` gets the flow's :class:`~..models.FlowSource` and
    the character budget from its limits, and returns a :class:`ReadResult`. It
    should raise ``ValueError`` with a sentence the user can act on when the
    source cannot be read — a missing repo, an unknown context — because that
    message is what lands in the job log.
    """

    id: str
    label: str
    read: Callable[[Any, int], ReadResult]
    description: str = ""
