"""The three built-in source readers.

A reader turns "read the git repository `legacy-delphi` at HEAD under `src/**`"
into the text a prompt is built from. They are deliberately plain: concatenated
material with a heading per item, a hard character budget, and an honest
``truncated`` flag — a run over half a codebase that claims to have read all of
it is worse than one that says it stopped.

* ``repo``      — a **configured Git Repo**'s working tree. Not a git-mining
  mirror: a checkout needs no credentials and no clone, and for a frozen
  repository the working tree *is* its tip, which is the case this was built
  for. A mirror reader at a historical commit is a satellite's job, and the
  extension point is there for it.
* ``kb_source`` — what the graph already holds from one source. Lets a flow
  reason over ingested pointers without re-fetching anything.
* ``context``   — a Roadmap context, rendered the same way the MCP tools render
  it, so a curated pile of material can drive a flow.
"""

from __future__ import annotations

import fnmatch
import subprocess
from pathlib import Path

from . import runtime
from .contracts import FlowReader, ReadResult

#: Read no more of one file than this, however generous the overall budget —
#: twenty files read in part beats one read in full.
_MAX_FILE_CHARS = 40_000

#: Directories never worth reading into a prompt.
_SKIP_DIRS = {".git", "node_modules", "__pycache__", ".venv", "venv", "dist",
              "build", ".angular", ".idea", ".vs", "bin", "obj"}

#: Extensions that are certainly not text.
_BINARY = {".png", ".jpg", ".jpeg", ".gif", ".bmp", ".ico", ".pdf", ".zip", ".gz",
           ".7z", ".exe", ".dll", ".so", ".dylib", ".class", ".jar", ".pyc",
           ".mp4", ".mp3", ".woff", ".woff2", ".ttf", ".eot", ".db", ".sqlite"}


# ── repo ─────────────────────────────────────────────────────────────────────

def repo_path(ref: str) -> Path:
    """The configured Git Repo called ``ref``.

    Resolved against the repository list in settings rather than a path from the
    flow, on purpose: a flow is configuration a person edits, and letting it name
    an arbitrary directory would make it a way to read any file on the server.
    """
    git_repos = runtime.services().get("git_repos")
    if git_repos is None:
        raise ValueError("Git Repos is not installed, so a flow cannot read a repository.")
    found = git_repos.find(ref)
    if found is None:
        known = ", ".join(r.name for r in git_repos.repositories()) or "none configured"
        raise ValueError(
            f"No Git Repo called '{ref}'. Add it under Settings -> Information Sources -> Git Repos, or "
            f"point the flow at one of: {known}.")
    if not found.server_path:
        raise ValueError(f"Git Repo '{ref}' has no place on this server: set the checkout "
                         f"folder on the server under Settings -> Information Sources -> Git Repos.")
    # the server's checkout: the flow runs here, not on a user's machine
    path = Path(found.server_path)
    if not path.is_dir():
        raise ValueError(f"Git Repo '{ref}' should be at {path} on this server, which is "
                         f"not a directory: clone it there, or correct the checkout folder.")
    return path


def head_commit(path: Path) -> str:
    """The checkout's current commit, or ``""`` if it is not a git working tree.

    Used for provenance, and by the scheduled scan to notice that a repository
    has moved.
    """
    try:
        out = subprocess.run(["git", "-C", str(path), "rev-parse", "HEAD"],
                             capture_output=True, text=True, timeout=30)
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, subprocess.SubprocessError):
        return ""


def _matches(rel: str, patterns: list[str]) -> bool:
    if not patterns:
        return True
    # `src/**` should mean everything under src/, which fnmatch does not do on
    # its own: its `*` crosses separators, but the trailing `/**` still has to
    # match the directory itself.
    for p in patterns:
        if fnmatch.fnmatch(rel, p) or fnmatch.fnmatch(rel, p.rstrip("/*") + "/*"):
            return True
    return False


def read_repo(source, max_chars: int) -> ReadResult:
    root = repo_path(source.ref)
    scope = source.scope or {}
    raw_paths = scope.get("paths") or []
    patterns = ([raw_paths] if isinstance(raw_paths, str) else list(raw_paths))
    patterns = [p for p in (str(x).strip() for x in patterns) if p]

    chunks: list[str] = []
    used = 0
    items = 0
    truncated = False
    for file in sorted(root.rglob("*")):
        if not file.is_file():
            continue
        if any(part in _SKIP_DIRS for part in file.relative_to(root).parts[:-1]):
            continue
        if file.suffix.lower() in _BINARY:
            continue
        rel = file.relative_to(root).as_posix()
        if not _matches(rel, patterns):
            continue
        try:
            text = file.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if not text.strip():
            continue
        text = text[:_MAX_FILE_CHARS]
        block = f"### {rel}\n\n{text}\n"
        if used + len(block) > max_chars:
            truncated = True
            break
        chunks.append(block)
        used += len(block)
        items += 1

    notes = []
    commit = head_commit(root)
    if commit:
        notes.append(f"at commit {commit[:12]}")
    if truncated:
        notes.append(f"stopped at {items} file(s) — the character budget ran out")
    label = f"{source.ref} ({items} file(s)"
    label += f", {', '.join(notes)})" if notes else ")"
    return ReadResult(label=label, material="\n".join(chunks), items=items,
                      truncated=truncated, position=commit, notes=notes)


# ── kb_source ────────────────────────────────────────────────────────────────

def read_kb_source(source, max_chars: int) -> ReadResult:
    kb = runtime.kb()
    nodes = kb.store.nodes(source=source.ref, limit=2000)
    if not nodes:
        raise ValueError(
            f"The graph holds nothing from source '{source.ref}'. Ingest it first, "
            "or point the flow somewhere else.")
    chunks: list[str] = []
    used = 0
    items = 0
    truncated = False
    for n in nodes:
        body = ""
        if n.content is not None:
            body = n.content.body or ""
            if n.content.fields:
                body += "\n" + "\n".join(f"- {k}: {v}" for k, v in n.content.fields.items())
        block = f"### {n.title or n.id}\n\n`{n.source}/{n.kind}/{n.id}`" \
                + (f"\n{n.uri}" if n.uri else "") + (f"\n\n{body}" if body.strip() else "") + "\n"
        if used + len(block) > max_chars:
            truncated = True
            break
        chunks.append(block)
        used += len(block)
        items += 1
    return ReadResult(label=f"{source.ref} ({items} node(s))", material="\n".join(chunks),
                      items=items, truncated=truncated)


# ── context ──────────────────────────────────────────────────────────────────

def read_context(source, max_chars: int) -> ReadResult:
    try:
        contexts = runtime.services().require("context")
    except Exception:
        raise ValueError("The contexts plugin is not available in this workspace.")
    sections = contexts.render_sections(source.ref) or []
    if not sections:
        raise ValueError(f"Context '{source.ref}' is empty or does not exist.")
    chunks: list[str] = []
    used = 0
    items = 0
    truncated = False
    for s in sections:
        block = f"### {s.get('label') or s.get('id') or ''}\n\n{s.get('content') or ''}\n"
        if used + len(block) > max_chars:
            truncated = True
            break
        chunks.append(block)
        used += len(block)
        items += 1
    return ReadResult(label=f"{source.ref} ({items} item(s))", material="\n".join(chunks),
                      items=items, truncated=truncated)


BUILTIN_READERS = [
    FlowReader(id="repo", label="Git repository", read=read_repo,
               description="A configured Git Repo's working tree, filtered by the "
                           "scope's `paths` globs."),
    FlowReader(id="kb_source", label="Knowledge-base source", read=read_kb_source,
               description="What the graph already holds from one source."),
    FlowReader(id="context", label="Context", read=read_context,
               description="A Roadmap context, rendered item by item."),
]
