"""The scheduled task that starts a flow when its source has moved.

One ``knowledgebase.flows.scan`` task, invoked per workspace with
``current_workspace`` already pinned. It walks the flows that list ``source``
among their triggers and starts the ones whose source has changed since the
last run that recorded a position.

**What "moved" means is per source kind**, and today only a ``repo`` can answer
it: the checkout's current commit, compared with the commit the flow's last run
recorded. A ``kb_source`` or a ``context`` has no cheap equivalent, so flows on
those are skipped rather than re-run on a timer — a scheduled task that reruns
an expensive analysis for no reason is worse than one that does nothing.

Disabled by default, like every scheduled task: nothing starts spending money
because a plugin was installed.
"""

from __future__ import annotations

from . import readers, runtime
from .engine import FlowRunner


def _position(flow) -> tuple[str, str]:
    """Where the flow's source stands now, as ``(kind, marker)``.

    An empty marker means "cannot tell", which is treated as "do not run" —
    guessing would mean re-running an expensive flow on every tick.
    """
    if flow.source.kind != "repo":
        return (flow.source.kind, "")
    try:
        path = readers.repo_path(flow.source.ref)
    except ValueError:
        return ("repo", "")
    return ("repo", readers.head_commit(path))


def _last_marker(kb, flow) -> str:
    """Where the source stood on the most recent run of this flow that recorded it.

    Any run counts, not only a source-triggered one: a manual run that has
    already analysed this very commit is exactly the reason not to start
    another. ``trigger["commit"]`` is read as a fallback for runs written
    before the position was recorded in its own right.
    """
    for run in kb.store.flow_runs(flow.id, limit=20):
        marker = run.source_position or str((run.trigger or {}).get("commit") or "")
        if marker:
            return marker
    return ""


def scan() -> list[dict]:
    """Start every source-triggered flow whose source has moved. Returns what it
    did, so the caller (a test, or a future manual "scan now") can see it."""
    kb = runtime.kb()
    runner = FlowRunner()
    started: list[dict] = []
    for flow in kb.flows():
        if not flow.enabled or "source" not in flow.triggers:
            continue
        if kb.flow_issues(flow):
            continue
        kind, marker = _position(flow)
        if not marker or marker == _last_marker(kb, flow):
            continue
        try:
            out = runner.start(flow, {"mode": "source", "kind": kind,
                                      "ref": flow.source.ref, "commit": marker})
            started.append({"flow": flow.id, "run": out["run"]["id"], "commit": marker})
        except ValueError as ex:
            # One misconfigured flow must not stop the others; the reason is
            # worth keeping, so it rides along in the result.
            started.append({"flow": flow.id, "error": str(ex)})
    return started


def _run() -> None:
    scan()


def scan_task():
    """The :class:`ScheduledTask`, built lazily so this module imports with no
    scheduler installed — the plugin only contributes it when there is one."""
    from roadmap_plugin_scheduler import ScheduledTask

    return ScheduledTask(
        id="knowledgebase.flows.scan",
        label="Start knowledge flows whose source moved",
        description="For each flow triggered by its source, compare the source's "
                    "position with the last run's and start a new run if it moved. "
                    "Only repositories can be compared today.",
        run=_run,
        default_cron="0 * * * *",     # hourly
        default_enabled=False,
    )
