"""Knowledge Base flow-runner plugin activator.

Registers the ``knowledgebase.flows`` service — the seam the Knowledge Base's
``POST /flows/{id}/run`` looks for — plus the source-reader extension point and
its three built-ins, an AI task type so a provider can be bound to flows
specifically, and (when the scheduler is installed) the task that starts a flow
whose source has moved.

Keeping all of this out of the Knowledge Base is the point: the core has flows,
renders their prompts and hands out briefs with no AI dependency at all, so it
installs and works on a deployment that has no provider. This plugin is what
lets Roadmap do the thinking itself.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_ai import AI_TASK_TYPES_POINT, AITaskType

from . import runtime
from .contracts import FLOW_READERS_POINT, FlowReader
from .engine import TASK_TYPE, FlowRunner
from .readers import BUILTIN_READERS
from .router import create_flow_runner_router


class KnowledgebaseFlowsPlugin(Plugin):
    id = "roadmap.knowledgebase.flows"
    name = "Knowledge Base — flow runner"
    requires = ["roadmap.knowledgebase", "roadmap.ai", "roadmap.jobs"]
    # activated after the scheduler when it is installed: the scan task goes into
    # its extension point, which must be declared by then
    optional_requires = ["roadmap.scheduler"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)
        ctx.define_point(
            FLOW_READERS_POINT, FlowReader,
            "Turns a flow's source into the material its prompt is built from.")
        for reader in BUILTIN_READERS:
            ctx.extend(FLOW_READERS_POINT, reader)

        ctx.services.register("knowledgebase.flows", FlowRunner())
        ctx.add_router(create_flow_runner_router())

        ctx.extend(AI_TASK_TYPES_POINT, AITaskType(
            id=TASK_TYPE, label="Knowledge flow", order=24,
            description="Powers a knowledge flow run: reads the flow's source and "
                        "writes topics for its personas."))

        # The scheduler is optional — source triggers are a convenience, and a
        # deployment without it still has manual runs, briefs and MCP.
        try:
            from roadmap_plugin_scheduler import SCHEDULER_TASKS_POINT

            from .tasks import scan_task

            ctx.extend(SCHEDULER_TASKS_POINT, scan_task())
        except ImportError:
            pass
