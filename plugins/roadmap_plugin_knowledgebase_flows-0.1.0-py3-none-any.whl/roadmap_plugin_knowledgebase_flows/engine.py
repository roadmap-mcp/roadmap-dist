"""Running a flow on the server: read the source, ask the AI, write the answer.

One pass, on a background job, with the whole story in the job log — what was
read, how much of it, which provider answered, what came back and what was
written. A run that goes wrong is read in that log, which is why every step
logs before it acts rather than after.

The answer is **validated against the node types** before anything is written
(``KnowledgeBaseService.apply_result``), so a misunderstood contract fails with
the reason instead of leaving half a graph behind. Because the store keys on
``source/kind/id``, a corrected re-run overwrites rather than duplicating.

What this does *not* do is stream, retry or chunk. A flow is one prompt and one
answer; if the material does not fit, the reader says so and the run records it
rather than quietly reading less. Splitting a large source into several passes
is a real feature and a later one.
"""

from __future__ import annotations

import json

from . import runtime

#: The AI task type this registers, so Workspace settings -> AI -> AI Tasks can bind a
#: provider to flows specifically rather than falling back to the first one.
TASK_TYPE = "knowledge_flow"

_SYSTEM = (
    "You write into a structured knowledge base. Follow the brief exactly: use "
    "only the node types it describes, answer every required field, and reply "
    "with ONE JSON object and nothing else — no prose, no code fence."
)


def _parse_json(text: str) -> dict:
    """The answer, as an object.

    Models fence JSON even when told not to, so the fence is stripped rather
    than treated as a failure; anything else that is not an object is one, and
    the raw text goes in the error because that is what explains it.
    """
    raw = (text or "").strip()
    if raw.startswith("```"):
        raw = raw.split("\n", 1)[-1].rsplit("```", 1)[0]
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ValueError(f"The answer was not JSON ({e}). It began: {raw[:300]}")
    if not isinstance(value, dict):
        raise ValueError(f"The answer was {type(value).__name__}, not an object.")
    return value


class FlowRunner:
    """Registered as the ``knowledgebase.flows`` service — what the Knowledge
    Base's ``POST /flows/{id}/run`` calls when this plugin is installed."""

    def ready(self) -> bool:
        """Installed *and* able to run here: something to read the source with,
        and a provider to ask.

        The reader list is the part that knows about the workspace. Services are
        registered once per process and stay visible even where this plugin is
        switched off, while extensions are gated by the workspace's enabled
        plugins — so an empty reader list is how the runner finds out it is off
        here. Without that check ``can_run`` is true in a workspace where every
        run dies on its first line, which is the lie the flag exists to avoid.
        """
        return bool(runtime.readers()) and self._provider() is not None

    def start(self, flow, trigger: dict, *, work_item: str = "") -> dict:
        """Open a run and execute it on a job thread. Returns at once.

        The run record is created here, synchronously, so the caller gets an id
        to poll even if the worker has not started — and so a run that dies on
        its first line is still in the history rather than having never existed.
        """
        kb = runtime.kb()
        jobs = runtime.services().require("jobs")
        reader = runtime.reader_for(flow.source.kind)
        if reader is None:
            known = ", ".join(r.id for r in runtime.readers()) or "none"
            raise ValueError(
                f"Nothing can read a '{flow.source.kind}' source. Readers: {known}.")
        provider = self._provider()
        if provider is None:
            raise ValueError(
                "No AI provider is configured. Set one up under Workspace settings -> AI, or "
                "use Brief and let an AI you already have carry the flow out.")

        run = kb.start_flow_run(flow, trigger, work_item=work_item)
        job = jobs.run_async(
            "knowledgebase", "flow", f"Flow: {flow.name or flow.id}",
            lambda job_id: self._execute(job_id, flow, run.id),
            {"flow": flow.id, "run": run.id},
        )
        return {"run": run.model_dump(), "job": job.id}

    # ── the work ─────────────────────────────────────────────────────────────

    def _execute(self, job_id: str, flow, run_id: str) -> None:
        # on a job thread: in the run's branch and space, as the caller was
        with runtime.kb().in_run(run_id):
            self._work(job_id, flow, run_id)

    def _work(self, job_id: str, flow, run_id: str) -> None:
        kb = runtime.kb()
        jobs = runtime.services().require("jobs")

        def log(message: str, level: str = "info") -> None:
            jobs.log(job_id, message, level)

        try:
            reader = runtime.reader_for(flow.source.kind)
            ai = runtime.ai()
            provider = self._provider()
            # re-checked here, not only in start(): the two run on different
            # threads, and a workspace can have been reconfigured in between
            if reader is None:
                raise ValueError(f"Nothing can read a '{flow.source.kind}' source.")
            if ai is None or provider is None:
                raise ValueError("No AI provider is configured any more.")
            log(f"Reading {flow.source.kind} '{flow.source.ref}'…")
            material = reader.read(flow.source, flow.limits.max_input_chars)
            log(f"Read {material.label}.")
            # before the AI call, not after: a run that fails still has to say
            # which state of the source it was looking at
            if material.position:
                kb.store.set_run_position(run_id, material.position)
            if material.truncated:
                log("The source did not fit in the character budget — this run saw "
                    "only part of it. Narrow the scope's paths, or raise the limit.",
                    "warn")
            if not material.material.strip():
                raise ValueError("The source is empty — there is nothing to analyse.")
            jobs.set_progress(job_id, 0.2)

            prompt = kb.render_prompt(flow, work_item=kb.store.flow_run(run_id).work_item,
                                      mode="run")
            model = getattr(provider, "default_model", "") or ""
            log(f"Asking {getattr(provider, 'name', 'the provider')} ({model})…")
            jobs.set_progress(job_id, 0.3)

            answer = ai.chat_text(provider, [
                {"role": "system", "content": _SYSTEM},
                {"role": "user", "content": prompt + "\n\n# The source\n\n"
                                            + material.material},
            ])
            log(f"Answer: {len(answer)} characters.")
            jobs.set_progress(job_id, 0.7)

            payload = _parse_json(answer)
            nodes = payload.get("nodes") or []
            if len(nodes) > flow.limits.max_nodes:
                raise ValueError(
                    f"The answer holds {len(nodes)} nodes, over this flow's limit of "
                    f"{flow.limits.max_nodes}. Nothing was written.")
            log(f"Writing {len(nodes)} node(s) and "
                f"{len(payload.get('links') or [])} link(s)…")

            written = kb.apply_result(run_id, payload, model=model)
            kb.finish_run(
                run_id, status="ok",
                message=f"{written['nodes']} node(s), {written['links']} link(s), "
                        f"{written['about']} about-link(s)")
            log(f"Wrote {written['nodes']} node(s), {written['links']} link(s) and "
                f"{written['about']} about-link(s).")
            jobs.set_progress(job_id, 1.0)
            jobs.finish(job_id, f"{written['nodes']} node(s) written")
        except Exception as ex:                       # noqa: BLE001 - reported, not swallowed
            # The run is closed as failed whatever went wrong, because a run left
            # open looks like one still in flight, and the next brief would list
            # its (empty) output as "already written".
            # the run broke, which says nothing about the work: `error`, not the
            # `failed` outcome that sends a work item back
            kb.finish_run(run_id, status="error", message=str(ex)[:500])
            jobs.fail(job_id, str(ex))

    @staticmethod
    def _provider():
        ai = runtime.ai()
        return ai.provider_for_task(TASK_TYPE) if ai is not None else None
