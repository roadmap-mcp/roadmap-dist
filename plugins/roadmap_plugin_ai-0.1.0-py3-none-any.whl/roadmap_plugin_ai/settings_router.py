"""AI provider connection-test endpoint, mounted under /api/settings."""

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from roadmap_framework import session

from . import runtime
from .service import AIService, friendly_error


class TestAIProviderRequest(BaseModel):
    provider_name: str
    message: str


class ListAIModelsRequest(BaseModel):
    # base_url/api_key carry the (possibly unsaved) values typed in the form; if
    # blank we fall back to the saved provider looked up by name.
    provider_name: str = ""
    base_url: str = ""
    api_key: str = ""


def create_ai_settings_router(ai: AIService) -> APIRouter:
    router = APIRouter(prefix="/api/settings", tags=["settings", "ai"])

    @router.get("/ai-task-types")
    def ai_task_types():
        """The AI task types plugins have registered (enabled in this workspace) — the
        AI Tasks tab renders a provider picker per entry."""
        return {"task_types": [
            {"id": t.id, "label": t.label, "description": t.description}
            for t in runtime.task_types()]}

    def require_unlocked():
        if runtime.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    @router.post("/test-ai-provider")
    def test_ai_provider(req: TestAIProviderRequest):
        require_unlocked()
        provider = ai.get_provider(req.provider_name)
        if not provider:
            raise HTTPException(status_code=400, detail=f"AI provider '{req.provider_name}' not found")

        import time
        from openai import APITimeoutError

        start = time.time()
        try:
            response = ai.chat(
                provider,
                [{"role": "user", "content": req.message}],
                max_tokens=500,
                timeout=30.0,
            )
            elapsed = round(time.time() - start, 2)
            content = response.choices[0].message.content if response.choices else "(empty response)"
            usage = response.usage
            return {
                "status": "ok",
                "response": content,
                "model": response.model or provider.default_model,
                "elapsed_seconds": elapsed,
                "usage": {
                    "prompt_tokens": usage.prompt_tokens if usage else None,
                    "completion_tokens": usage.completion_tokens if usage else None,
                },
            }
        except APITimeoutError:
            raise HTTPException(
                status_code=400,
                detail=f"Request timed out after {round(time.time() - start, 2)}s")
        except Exception as e:
            raise HTTPException(status_code=400, detail=friendly_error(e))

    @router.post("/list-ai-models")
    def list_ai_models(req: ListAIModelsRequest):
        """List the models a provider's OpenAI-compatible API advertises.

        Uses the form's current base_url/api_key so it works before saving; falls
        back to the saved provider (by name) for any blank field — e.g. the API
        key the user didn't re-type.
        """
        require_unlocked()
        base_url, api_key = req.base_url, req.api_key
        if not base_url or not api_key:
            config = runtime.load_config_decrypted()
            saved = next((p for p in config.ai_providers if p.name == req.provider_name), None)
            if saved:
                base_url = base_url or saved.base_url
                api_key = api_key or saved.api_key
        if not base_url:
            raise HTTPException(status_code=400, detail="No base URL configured for this provider.")

        try:
            return {"models": ai.list_models(base_url=base_url, api_key=api_key)}
        except Exception as e:
            raise HTTPException(status_code=400, detail=friendly_error(e))

    return router
