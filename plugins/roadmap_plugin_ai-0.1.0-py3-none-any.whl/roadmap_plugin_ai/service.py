"""The one place Roadmap talks to an AI provider.

Every OpenAI-compatible call goes through :class:`AIService`, so provider quirks
(most notably ``max_tokens`` vs ``max_completion_tokens``) and error formatting
are handled once instead of being copy-pasted into each feature plugin.

Other plugins obtain it from the service registry::

    ai = ctx.services.require("ai")     # hard dependency (declare in `requires`)
    ai = ctx.services.get("ai")         # optional dependency

Resolve it lazily (at call time) if your plugin does not list ``roadmap.ai`` in
``requires`` — activation order is only guaranteed for declared dependencies.
"""

from __future__ import annotations

from typing import Any, Iterable, Optional

from . import runtime


def friendly_error(e: Exception) -> str:
    """Map an OpenAI SDK exception to a message that is safe to show a user."""
    from openai import (APIConnectionError, APIError, APITimeoutError,
                        AuthenticationError)

    # Most specific first: AuthenticationError is an APIStatusError, and
    # APITimeoutError is an APIConnectionError.
    if isinstance(e, AuthenticationError):
        return f"Authentication failed: {e.message}"
    if isinstance(e, APITimeoutError):
        return "Request timed out."
    if isinstance(e, APIConnectionError):
        return f"Connection error: {e.message}"
    if isinstance(e, APIError):
        code = getattr(e, "status_code", "unknown")
        return f"API error ({code}): {e.message}"
    return str(e)


class AIService:
    """Facade over the configured AI providers."""

    # ── provider lookup ──────────────────────────────────────────────────

    def providers(self) -> list:
        """Every configured provider (decrypted)."""
        return list(runtime.load_config_decrypted().ai_providers)

    def get_provider(self, name: str):
        """The provider with this name, or ``None``."""
        return next((p for p in self.providers() if p.name == name), None)

    def provider_for_task(self, *task_types: str):
        """The provider bound to the first of ``task_types`` that has one.

        Falls back to the first configured provider, then ``None``. This is how
        features pick a provider without hard-coding a name.
        """
        config = runtime.load_config_decrypted()
        for task_type in task_types:
            task = next((t for t in config.ai_tasks if t.task_type == task_type), None)
            if not task:
                continue
            provider = next(
                (p for p in config.ai_providers if p.name == task.provider_name), None)
            if provider:
                return provider
        return config.ai_providers[0] if config.ai_providers else None

    # ── calls ────────────────────────────────────────────────────────────

    def client(self, provider: Any = None, *, base_url: Optional[str] = None,
               api_key: Optional[str] = None, timeout: Optional[float] = None):
        """An OpenAI client for a provider (or for explicit base_url/api_key)."""
        from openai import OpenAI

        if provider is not None:
            base_url = base_url or provider.base_url
            api_key = api_key or provider.api_key
        kwargs: dict[str, Any] = {"api_key": api_key or "unused", "base_url": base_url}
        if timeout is not None:
            kwargs["timeout"] = timeout
        return OpenAI(**kwargs)

    def chat(self, provider: Any, messages: Iterable[dict], *,
             model: Optional[str] = None, max_tokens: Optional[int] = None,
             temperature: Optional[float] = None, timeout: Optional[float] = None):
        """A chat completion, transparently handling the token-limit parameter.

        Newer OpenAI models (gpt-5.x, o-series) reject ``max_tokens`` and require
        ``max_completion_tokens``; older models and OpenAI-compatible proxies only
        know ``max_tokens``. Send the legacy parameter and retry with the new one
        only when the API explicitly asks for it.
        """
        from openai import APIError

        client = self.client(provider, timeout=timeout)
        kwargs: dict[str, Any] = {
            "model": model or provider.default_model,
            "messages": list(messages),
        }
        if temperature is not None:
            kwargs["temperature"] = temperature
        if max_tokens is None:
            return client.chat.completions.create(**kwargs)
        try:
            return client.chat.completions.create(max_tokens=max_tokens, **kwargs)
        except APIError as e:
            if "max_completion_tokens" not in str(getattr(e, "message", "") or e):
                raise
            return client.chat.completions.create(
                max_completion_tokens=max_tokens, **kwargs)

    def chat_text(self, provider: Any, messages: Iterable[dict], **kwargs) -> str:
        """:meth:`chat`, reduced to the assistant's stripped text content."""
        response = self.chat(provider, messages, **kwargs)
        if not response.choices:
            return ""
        return (response.choices[0].message.content or "").strip()

    def embed(self, texts: list[str], *, provider: Any = None,
              model: Optional[str] = None) -> list[list[float]]:
        """Embedding vectors for ``texts`` via an OpenAI-compatible provider.

        Picks the provider bound to the ``embedding`` task when one is not given,
        falling back to the first configured provider. ``model`` defaults to the
        provider's default model, then ``text-embedding-3-small``. This is the one
        embedding entry point — feature plugins (e.g. the Company Brain) call it
        instead of importing ``openai`` themselves.
        """
        if provider is None:
            provider = self.provider_for_task("embedding")
        if provider is None:
            raise RuntimeError("No AI provider is configured for embeddings.")
        client = self.client(provider)
        model = str(model or getattr(provider, "default_model", None)
                    or "text-embedding-3-small")
        response = client.embeddings.create(model=model, input=list(texts))
        return [list(d.embedding) for d in response.data]

    def describe_error(self, e: Exception) -> str:
        """User-facing message for an exception raised by one of these calls.

        Lets consumers format AI errors without importing this package (handy for
        plugins that depend on AI only optionally).
        """
        return friendly_error(e)

    def list_models(self, *, base_url: str, api_key: str = "",
                    timeout: float = 30.0) -> list[str]:
        """Model ids a provider's OpenAI-compatible API advertises."""
        client = self.client(base_url=base_url, api_key=api_key, timeout=timeout)
        return sorted({m.id for m in client.models.list().data})
