"""The AI plugin's extension point: registrable **AI task types**.

A plugin that calls ``ai.provider_for_task("<id>")`` contributes an ``AITaskType`` for
``<id>`` so it appears in Workspace settings → AI → AI Tasks, where the user can bind a provider
to it. Without this, a task type is an anonymous string the settings UI can't surface.
"""

from __future__ import annotations

from dataclasses import dataclass

AI_TASK_TYPES_POINT = "roadmap.ai.taskTypes"


@dataclass
class AITaskType:
    id: str                               # the task_type string used in provider_for_task(id)
    label: str
    description: str = ""
    order: int = 100
