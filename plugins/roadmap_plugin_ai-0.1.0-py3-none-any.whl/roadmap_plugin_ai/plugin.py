"""AI plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .settings_router import create_ai_settings_router

PROVIDERS_SECTION = SettingsSection(
    id="providers", label="AI Providers", order=50,
    defaults=lambda: {"ai_providers": []},
    sensitive_fields=["ai_providers.*.api_key"],
)
PROXY_SECTION = SettingsSection(
    id="proxy", label="AI Proxy", order=60,
    defaults=lambda: {"ai_proxy": {"name": "Proxy", "base_url": "", "api_key": ""}},
)
TASKS_SECTION = SettingsSection(
    id="tasks", label="AI Tasks", order=70,
    defaults=lambda: {"ai_tasks": []},
)


class AIPlugin(Plugin):
    id = "roadmap.ai"
    name = "AI"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.register_sensitive_path("ai_providers.*.api_key")
        for section in (PROVIDERS_SECTION, PROXY_SECTION, TASKS_SECTION):
            ctx.extend(SETTINGS_SECTIONS_POINT, section)
        ctx.add_router(create_ai_settings_router())
