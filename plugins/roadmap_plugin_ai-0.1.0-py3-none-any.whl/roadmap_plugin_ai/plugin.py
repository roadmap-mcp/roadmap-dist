"""AI plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .contracts import AI_TASK_TYPES_POINT, AITaskType
from .service import AIService
from .settings_router import create_ai_settings_router

PROVIDERS_SECTION = SettingsSection(
    id="providers", label="AI Providers", order=50, group="AI",
    defaults=lambda: {"ai_providers": []},
    sensitive_fields=["ai_providers.*.api_key"],
)
PROXY_SECTION = SettingsSection(
    id="proxy", label="AI Proxy", order=60, group="AI",
    defaults=lambda: {"ai_proxy": {"name": "Proxy", "base_url": "", "api_key": ""}},
)
TASKS_SECTION = SettingsSection(
    id="tasks", label="AI Tasks", order=70, group="AI",
    defaults=lambda: {"ai_tasks": []},
)


class AIPlugin(Plugin):
    id = "roadmap.ai"
    name = "AI"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.extensions)
        ctx.register_sensitive_path("ai_providers.*.api_key")
        for section in (PROVIDERS_SECTION, PROXY_SECTION, TASKS_SECTION):
            ctx.extend(SETTINGS_SECTIONS_POINT, section)
        # plugins register their AI task types here so the AI Tasks tab can offer a
        # provider binding for each (e.g. context_assistant, webtest_design).
        ctx.define_point(AI_TASK_TYPES_POINT, AITaskType,
                         "AI task types that can be bound to a provider in settings.")
        # The single entry point for AI calls; other plugins consume it via
        # ctx.services.require("ai") / .get("ai").
        ai = AIService()
        ctx.services.register("ai", ai)
        ctx.add_router(create_ai_settings_router(ai))
