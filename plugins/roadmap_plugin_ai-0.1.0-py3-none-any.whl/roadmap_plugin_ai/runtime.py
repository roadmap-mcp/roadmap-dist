"""AI plugin runtime — config access."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry

from .contracts import AI_TASK_TYPES_POINT

_store: Optional[ConfigStore] = None
_extensions: Optional[ExtensionRegistry] = None

DEFAULTS = {
    "ai_providers": [],
    "ai_proxy": {"name": "Proxy", "base_url": "", "api_key": ""},
    "ai_tasks": [],
}


def set_runtime(config: ConfigStore, extensions: ExtensionRegistry | None = None) -> None:
    global _store, _extensions
    _store, _extensions = config, extensions


def task_types() -> list:
    """The AI task types registered by plugins (gated by the current workspace's
    enabled plugins), sorted for display."""
    if _extensions is None:
        return []
    return sorted(_extensions.get(AI_TASK_TYPES_POINT), key=lambda t: (t.order, t.label))


def has_encrypted_fields() -> bool:
    assert _store is not None, "ai runtime not initialised"
    return _store.has_encrypted_fields()


def load_config_decrypted():
    assert _store is not None, "ai runtime not initialised"
    return _store.load_ns(DEFAULTS)
