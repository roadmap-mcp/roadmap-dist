"""AI plugin runtime — config access."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore

_store: Optional[ConfigStore] = None

DEFAULTS = {
    "ai_providers": [],
    "ai_proxy": {"name": "Proxy", "base_url": "", "api_key": ""},
    "ai_tasks": [],
}


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def has_encrypted_fields() -> bool:
    assert _store is not None, "ai runtime not initialised"
    return _store.has_encrypted_fields()


def load_config_decrypted():
    assert _store is not None, "ai runtime not initialised"
    return _store.load_ns(DEFAULTS)
