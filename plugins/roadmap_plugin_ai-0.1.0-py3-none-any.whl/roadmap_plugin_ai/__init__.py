"""AI plugin — AI provider/proxy/task configuration, and the shared AI client.

:class:`AIService` (registered as the ``"ai"`` service) is the single place
Roadmap calls an AI provider from; see ``service.py``.
"""

from .contracts import AI_TASK_TYPES_POINT, AITaskType
from .service import AIService, friendly_error

__all__ = ["AIService", "friendly_error", "AI_TASK_TYPES_POINT", "AITaskType"]
