"""AI plugin — AI provider/proxy/task configuration + connection testing."""
