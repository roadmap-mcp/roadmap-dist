"""Per-process runtime wiring for the assistant plugin."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ServiceRegistry

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry) -> None:
    global _store, _services
    _store, _services = config, services


def ai_service():
    assert _services is not None, "assistant runtime not initialised"
    return _services.require("ai")


def e2e_service():
    assert _services is not None, "assistant runtime not initialised"
    return _services.require("e2e")


def build_live_driver():
    """Build the configured e2e driver and require live-introspection support.

    Reuses the engine's ``resolve_driver`` (so the driver is chosen by ``e2e.driver``
    and built from the workspace-aware config) but — unlike a scenario run — the caller
    keeps it open across requests instead of closing it in a ``finally``."""
    from roadmap_plugin_e2e import LiveDriver
    from roadmap_plugin_e2e.runtime import resolve_driver

    driver = resolve_driver()
    if not isinstance(driver, LiveDriver):
        raise RuntimeError(
            "The configured E2E driver has no live introspection. Set the Web Testing "
            "driver to 'selenium' (Settings → Web Testing) to design tests with the AI.")
    return driver
