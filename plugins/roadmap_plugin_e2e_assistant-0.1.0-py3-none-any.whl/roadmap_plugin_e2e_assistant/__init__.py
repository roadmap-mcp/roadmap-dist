"""AI test-design assistant for the Roadmap E2E engine.

Drives a live browser session the user talks to: the assistant "sees" the page
(interactive elements + real selectors), performs actions as instructed, records them
as steps, and saves the result as a reusable e2e Component. Backend for the immersive
"AI Test Design" view.
"""
