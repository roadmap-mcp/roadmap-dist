"""The browser tools the assistant can call, and the dispatcher that runs them.

Each *acting* tool runs against the session's live driver and, on success, **records a
Step** onto the session (that's how talking builds the test). ``see_page`` is read-only
— it returns the page's interactive elements + URL so the model knows what it can act
on and which selector to use. No raw-``script`` tool is exposed: the model only emits
structured actions.

Tool schemas are OpenAI function-calling format (passed straight to the chat API).
"""

from __future__ import annotations

import json
from urllib.parse import urljoin

from roadmap_plugin_e2e.models import Component, CompositeStep, Step, Target

from . import runtime

_ABSOLUTE = ("http://", "https://", "file://", "about:")

TOOLS = [
    {"type": "function", "function": {
        "name": "see_page",
        "description": "Look at the current page: returns its URL and the visible "
                       "interactive elements (buttons, links, inputs, selects) each with "
                       "a ready-to-use CSS selector. Call this before acting so you use "
                       "real selectors from the page.",
        "parameters": {"type": "object", "properties": {}},
    }},
    {"type": "function", "function": {
        "name": "navigate",
        "description": "Go to a URL. Relative URLs (e.g. '/login') resolve against the "
                       "site's base URL.",
        "parameters": {"type": "object", "properties": {
            "url": {"type": "string"}}, "required": ["url"]},
    }},
    {"type": "function", "function": {
        "name": "click",
        "description": "Click the element matching a CSS selector (from see_page).",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"},
            "label": {"type": "string", "description": "short human label for this step"}},
            "required": ["selector"]},
    }},
    {"type": "function", "function": {
        "name": "type_text",
        "description": "Type text into an input/textarea matching a CSS selector. Use "
                       "${paramName} in the value to make it a test parameter.",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"}, "value": {"type": "string"},
            "label": {"type": "string"}}, "required": ["selector", "value"]},
    }},
    {"type": "function", "function": {
        "name": "select_option",
        "description": "Select an option (by visible text) in a <select> matching a CSS selector.",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"}, "value": {"type": "string"},
            "label": {"type": "string"}}, "required": ["selector", "value"]},
    }},
    {"type": "function", "function": {
        "name": "assert_text",
        "description": "Assert that the element at a CSS selector contains the given text.",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"}, "text": {"type": "string"},
            "label": {"type": "string"}}, "required": ["selector", "text"]},
    }},
    {"type": "function", "function": {
        "name": "capture",
        "description": "Capture the text/value of the element at a CSS selector into a "
                       "context key for later steps.",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"}, "key": {"type": "string"},
            "label": {"type": "string"}}, "required": ["selector", "key"]},
    }},
    {"type": "function", "function": {
        "name": "wait_for",
        "description": "Wait until the element at a CSS selector is visible.",
        "parameters": {"type": "object", "properties": {
            "selector": {"type": "string"}, "label": {"type": "string"}},
            "required": ["selector"]},
    }},
    {"type": "function", "function": {
        "name": "save_component",
        "description": "Group the most recent loose steps in the scenario into a reusable "
                       "Component and replace them with a single reference to it. Call this "
                       "when the user asks to create/make a component. Keep components "
                       "focused — use discard_steps first to drop setup navigation you don't "
                       "want in a reusable fragment (e.g. a cookie popup or menu).",
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string"},
            "kind": {"type": "string", "enum": ["page", "popup", "menu", "section", "table", "other"]}},
            "required": ["name"]},
    }},
    {"type": "function", "function": {
        "name": "use_component",
        "description": "Add an EXISTING component to the scenario by name. If no component "
                       "with that name exists, build its actions first and call "
                       "save_component to create it.",
        "parameters": {"type": "object", "properties": {
            "name": {"type": "string"}}, "required": ["name"]},
    }},
    {"type": "function", "function": {
        "name": "discard_steps",
        "description": "Drop the most recent loose steps from the scenario without affecting "
                       "the browser — use to remove setup navigation before capturing a "
                       "focused fragment.",
        "parameters": {"type": "object", "properties": {}},
    }},
]


def _join(base: str, value: str) -> str:
    if not value or value.lower().startswith(_ABSOLUTE) or not base:
        return value
    return urljoin(base.rstrip("/") + "/", value.lstrip("/"))


def _add_inline(session, step_type: str, *, selector: str = "", value: str = "",
                capture_as: str = "", label: str = "") -> None:
    """Append an inline action step to the scenario being composed."""
    target = Target(by="css", value=selector) if selector else Target()
    step = Step(id="", type=step_type, label=label, target=target, value=value,
                capture_as=capture_as)
    session.scenario.append({"ref": "", "step": step.model_dump(), "bindings": {}})


def _act(session, step_type: str, *, selector: str = "", value: str = "",
         capture_as: str = "", label: str = "") -> tuple[bool, str]:
    """Run one step live; return (ok, message). Adds it to the scenario on success."""
    resolved = {"type": step_type, "label": label,
                "target": {"by": "css", "value": selector}, "value": value,
                "capture_as": capture_as, "snippet": "", "timeout": None}
    outcome = session.driver.run_step(resolved, {})
    if outcome.status != "passed":
        return False, f"failed: {outcome.error}"
    _add_inline(session, step_type, selector=selector, value=value,
                capture_as=capture_as, label=label)
    return True, "ok"


def _trailing_inline(session) -> list[int]:
    """Indices of the trailing run of inline steps (from the end back to the last
    component include) — the steps a save_component would group into a component."""
    idx = []
    for i in range(len(session.scenario) - 1, -1, -1):
        if session.scenario[i].get("step") is not None:
            idx.append(i)
        else:
            break
    return list(reversed(idx))


def run_tool(session, name: str, args: dict) -> str:
    """Dispatch one tool call. Returns a string the model reads as the tool result."""
    try:
        if name == "see_page":
            elements = session.driver.snapshot()
            return json.dumps({"url": session.driver.url(), "elements": elements})

        if name == "navigate":
            url = str(args.get("url", ""))
            resolved = {"type": "navigate", "label": args.get("label", ""),
                        "target": {"by": "css", "value": ""}, "value": _join(session.base_url, url),
                        "capture_as": "", "snippet": "", "timeout": None}
            outcome = session.driver.run_step(resolved, {})
            if outcome.status != "passed":
                return f"failed to navigate: {outcome.error}"
            _add_inline(session, "navigate", value=url, label=args.get("label") or f"Go to {url}")
            return f"navigated; current url: {session.driver.url()}"

        if name in ("click", "wait_for"):
            step_type = "click" if name == "click" else "wait"
            ok, msg = _act(session, step_type, selector=args["selector"],
                           label=args.get("label", ""))
            return f"{msg}; url: {session.driver.url()}" if ok else msg

        if name == "type_text":
            ok, msg = _act(session, "type", selector=args["selector"],
                           value=args.get("value", ""), label=args.get("label", ""))
            return msg

        if name == "select_option":
            ok, msg = _act(session, "select", selector=args["selector"],
                           value=args.get("value", ""), label=args.get("label", ""))
            return msg

        if name == "assert_text":
            ok, msg = _act(session, "assert_text", selector=args["selector"],
                           value=args.get("text", ""), label=args.get("label", ""))
            return msg

        if name == "capture":
            ok, msg = _act(session, "capture", selector=args["selector"],
                           capture_as=args.get("key", ""), label=args.get("label", ""))
            return msg

        if name == "discard_steps":
            idx = _trailing_inline(session)
            for i in reversed(idx):
                session.scenario.pop(i)
            return f"discarded {len(idx)} loose step(s)"

        if name == "save_component":
            idx = _trailing_inline(session)
            if not idx:
                return ("no loose steps to group — perform the component's actions first, "
                        "then save_component")
            steps = [CompositeStep(step=Step(**session.scenario[i]["step"]), ref="", bindings={})
                     for i in idx]
            comp = Component(id="", site_id=session.site_id, name=args["name"],
                             kind=args.get("kind", "page"), steps=steps)
            saved = runtime.e2e_service().save_component(comp)
            # replace the grouped inline steps with a single include reference
            first = idx[0]
            del session.scenario[first:first + len(idx)]
            session.scenario.insert(first, {"ref": saved.id, "step": None, "bindings": {}})
            session.new_component_ids.append(saved.id)
            return (f"created component '{saved.name}' ({saved.kind}, {len(idx)} step(s)) "
                    "and added it to the scenario")

        if name == "use_component":
            want = str(args.get("name", "")).strip().lower()
            match = next((c for c in runtime.e2e_service().list_components()
                          if c.name.strip().lower() == want), None)
            if match is None:
                return (f"no component named '{args.get('name')}' — build its actions, then "
                        "save_component to create it")
            session.scenario.append({"ref": match.id, "step": None, "bindings": {}})
            return f"added existing component '{match.name}' to the scenario"

        return f"unknown tool: {name}"
    except KeyError as e:
        return f"missing argument: {e}"
    except Exception as e:
        return f"error: {type(e).__name__}: {e}"
