"""HTTP surface: ``/api/e2e-assistant`` — start/drive/save a live design session."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel

from roadmap_plugin_e2e.models import Scenario

from . import agent, runtime, scenario_agent, session as sessions


class StartRequest(BaseModel):
    site_id: str = ""


class MessageRequest(BaseModel):
    message: str


class SaveScenarioRequest(BaseModel):
    name: str


class ScenarioRequest(BaseModel):
    message: str
    scenario: dict = {}


def create_assistant_router() -> APIRouter:
    router = APIRouter(prefix="/api/e2e-assistant", tags=["e2e-assistant"])

    def _require(session_id: str) -> sessions.LiveSession:
        s = sessions.get(session_id)
        if s is None:
            raise HTTPException(status_code=404, detail="Design session not found (it may have expired).")
        return s

    def _view(s: sessions.LiveSession) -> dict:
        """The session as the design view renders it: the scenario resolved for
        display — component includes carry the component name/kind + a `new` flag."""
        comps = {c.id: c for c in runtime.e2e_service().list_components()}
        new = set(s.new_component_ids)
        scenario = []
        for cs in s.scenario:
            st = cs.get("step")
            if st is not None:
                scenario.append({"kind": "step", "type": st.get("type", ""),
                                 "label": st.get("label") or st.get("type", ""),
                                 "target": st.get("target", {}), "value": st.get("value", "")})
            else:
                ref = cs.get("ref", "")
                c = comps.get(ref)
                scenario.append({"kind": "component", "ref": ref,
                                 "name": c.name if c else ref,
                                 "comp_kind": c.kind if c else "",
                                 "new": ref in new})
        return {"id": s.id, "site_id": s.site_id, "base_url": s.base_url,
                "url": s.url(), "scenario": scenario}

    @router.post("/sessions")
    def start_session(req: StartRequest):
        base_url = ""
        if req.site_id:
            site = runtime.e2e_service().get_site(req.site_id)
            base_url = site.base_url if site else ""
        try:
            driver = runtime.build_live_driver()
            driver.start()
        except Exception as e:
            raise HTTPException(status_code=400, detail=str(e))
        s = sessions.create(req.site_id, base_url, driver)
        if base_url:
            try:
                driver.run_step({"type": "navigate", "target": {"by": "css", "value": ""},
                                 "value": base_url, "capture_as": "", "snippet": "",
                                 "timeout": None}, {})
            except Exception:
                pass
        return _view(s)

    @router.post("/sessions/{session_id}/message")
    def message(session_id: str, req: MessageRequest):
        s = _require(session_id)
        try:
            reply = agent.run_turn(s, req.message)
        except Exception as e:
            raise HTTPException(status_code=400, detail=runtime.ai_service().describe_error(e))
        return {"reply": reply, **_view(s)}

    @router.get("/sessions/{session_id}")
    def get_session(session_id: str):
        return _view(_require(session_id))

    @router.get("/sessions/{session_id}/screenshot")
    def screenshot(session_id: str):
        s = _require(session_id)
        png = None
        try:
            png = s.driver.screenshot()
        except Exception:
            png = None
        if not png:
            raise HTTPException(status_code=404, detail="No screenshot yet.")
        return Response(content=png, media_type="image/png")

    @router.post("/sessions/{session_id}/save-scenario")
    def save_scenario(session_id: str, req: SaveScenarioRequest):
        s = _require(session_id)
        if not s.scenario:
            raise HTTPException(status_code=400, detail="The scenario is empty.")
        scenario = Scenario(id="", name=req.name, steps=list(s.scenario))
        saved = runtime.e2e_service().save_scenario(scenario)
        return {"id": saved.id, "name": saved.name}

    @router.delete("/sessions/{session_id}")
    def end_session(session_id: str):
        return {"closed": sessions.close(session_id)}

    # ── scenario composition by chat (stateless — no browser) ──────────────────
    @router.post("/scenario")
    def compose_scenario(req: ScenarioRequest):
        try:
            return scenario_agent.compose(req.scenario, req.message)
        except Exception as e:
            raise HTTPException(status_code=400, detail=runtime.ai_service().describe_error(e))

    return router
