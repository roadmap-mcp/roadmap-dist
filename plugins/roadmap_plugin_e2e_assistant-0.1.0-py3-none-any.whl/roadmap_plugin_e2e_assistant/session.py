"""Live browser sessions the assistant drives — a keyed registry of open drivers.

Generalizes the brain scheduler's module-singleton idiom to a ``dict[id, LiveSession]``.
A session owns a **started, kept-open** driver, the workspace it belongs to (Chrome is
process-global while ``current_workspace`` is per-request — the stored workspace is the
tenant guard), the recorded steps, and the chat history. An idle reaper closes stale
browsers, re-pinning the workspace per session like ``engine.start_async`` does.
"""

from __future__ import annotations

import time
import uuid
from typing import Optional

from roadmap_framework import current_workspace

#: idle timeout — a session with no activity for this long is reaped (browser closed)
IDLE_SECONDS = 20 * 60


class LiveSession:
    def __init__(self, session_id: str, workspace: str, site_id: str,
                 base_url: str, driver) -> None:
        self.id = session_id
        self.workspace = workspace
        self.site_id = site_id
        self.base_url = base_url
        self.driver = driver
        #: the scenario being composed — an ordered list of CompositeStep dicts:
        #: an inline action ({ref:"", step:{...}}) or a component include ({ref:id}).
        self.scenario: list[dict] = []
        #: ids of components created *this session* (shown with a "*" new marker).
        self.new_component_ids: list[str] = []
        self.messages: list[dict] = []     # serializable chat history for the agent
        self.last_used = time.time()

    def touch(self) -> None:
        self.last_used = time.time()

    def url(self) -> str:
        try:
            return self.driver.url()
        except Exception:
            return ""

    def summary(self) -> dict:
        return {"id": self.id, "site_id": self.site_id, "base_url": self.base_url,
                "url": self.url(), "scenario": self.scenario,
                "new_component_ids": self.new_component_ids}


_sessions: dict[str, LiveSession] = {}


def create(site_id: str, base_url: str, driver) -> LiveSession:
    sid = f"des_{uuid.uuid4().hex[:10]}"
    s = LiveSession(sid, current_workspace.get(), site_id, base_url, driver)
    _sessions[sid] = s
    return s


def get(session_id: str) -> Optional[LiveSession]:
    s = _sessions.get(session_id)
    if s is not None:
        s.touch()
    return s


def close(session_id: str) -> bool:
    s = _sessions.pop(session_id, None)
    if s is None:
        return False
    try:
        s.driver.close()
    except Exception:
        pass
    return True


def reap_idle() -> None:
    """Close sessions idle past IDLE_SECONDS (called by the scheduler)."""
    now = time.time()
    for sid in [s.id for s in list(_sessions.values()) if now - s.last_used > IDLE_SECONDS]:
        s = _sessions.get(sid)
        if s is None:
            continue
        token = current_workspace.set(s.workspace)     # tenant-correct teardown
        try:
            close(sid)
        finally:
            current_workspace.reset(token)


def close_all() -> None:
    for sid in list(_sessions):
        close(sid)
