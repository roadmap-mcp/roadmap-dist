"""The tool-calling loop: turn one user message into live browser actions + a reply.

We bypass ``ai.chat`` (which can't carry ``tools``/``tool_choice``) and drive the raw
OpenAI client from ``ai.client(provider)`` ourselves, executing tool calls against the
live session between round-trips. The conversation is kept as plain serializable dicts
on the session so it survives across turns.
"""

from __future__ import annotations

import json

from . import runtime, tools

MAX_ITERS = 8

_SYSTEM_PROMPT = """\
You are an assistant that builds an automated test SCENARIO by DRIVING A LIVE BROWSER
for a QA engineer. The browser is already open at the site under test (base URL:
{base_url}). You are composing ONE scenario: an ordered list of steps and reusable
components.

You have tools to look at the page, act on it, and organise the scenario. RULES:
- Before acting, call see_page to get the real elements and their CSS selectors. Never
  invent selectors — always use ones returned by see_page.
- Every action you take (navigate, click, type_text, select_option, assert_text,
  capture, wait_for) runs on the live browser AND is added to the scenario as a step,
  in order. Do exactly what the user asks.
- **Grouping into components is your job.** When the user asks to "create/make a
  component" for something, first perform its actions, then call
  save_component(name, kind). That groups the most recent loose steps into a reusable
  Component and replaces them in the scenario with a single reference to it. You MUST
  call save_component — don't just perform the actions and stop. Kinds: page, popup,
  menu, section, table, other (a cookie dialog is "popup").
- Keep components focused. A fragment (cookie popup, menu) should contain only its own
  interactions — NOT the navigation used to reach a page. If you navigated only to make
  the element appear, call discard_steps first to drop that navigation, then perform the
  fragment's actions and save_component.
- To reuse an EXISTING component the user names, call use_component(name). If it doesn't
  exist, build its actions and save_component to create it.
- Prefer stable selectors (an id like #login is best). If an action fails, call see_page
  again and retry with a better selector.
- When the user gives a value that should be a test parameter (a username, a search
  term), type it as ${{paramName}} so the scenario is reusable.
- Keep replies short: say what you did (including any component you created) and what
  you see now.
"""


def _create(oa, model, messages):
    """chat.completions.create with the max_tokens→max_completion_tokens quirk avoided
    (we simply don't cap tokens, which is safe across model families)."""
    return oa.chat.completions.create(
        model=model, messages=messages, tools=tools.TOOLS, tool_choice="auto")


def run_turn(session, user_message: str) -> str:
    """Execute one conversational turn; returns the assistant's reply text."""
    ai = runtime.ai_service()
    provider = ai.provider_for_task("webtest_design", "context_assistant")
    if provider is None:
        raise RuntimeError(
            "No AI provider is configured. Add one in Settings → AI (and optionally "
            "bind it to the 'webtest_design' task).")

    session.messages.append({"role": "user", "content": user_message})
    system = {"role": "system",
              "content": _SYSTEM_PROMPT.format(base_url=session.base_url or "(none)")}
    oa = ai.client(provider, timeout=120)
    model = provider.default_model

    for _ in range(MAX_ITERS):
        resp = _create(oa, model, [system] + session.messages)
        msg = resp.choices[0].message
        tool_calls = msg.tool_calls or []

        if not tool_calls:
            reply = (msg.content or "").strip() or "(done)"
            session.messages.append({"role": "assistant", "content": reply})
            return reply

        # persist the assistant's tool-call message (serializable form), then run them
        session.messages.append({
            "role": "assistant", "content": msg.content or "",
            "tool_calls": [
                {"id": tc.id, "type": "function",
                 "function": {"name": tc.function.name, "arguments": tc.function.arguments}}
                for tc in tool_calls],
        })
        for tc in tool_calls:
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            result = tools.run_tool(session, tc.function.name, args)
            session.messages.append({"role": "tool", "tool_call_id": tc.id, "content": result})

    reply = "I've reached the action limit for this message — tell me the next step."
    session.messages.append({"role": "assistant", "content": reply})
    return reply
