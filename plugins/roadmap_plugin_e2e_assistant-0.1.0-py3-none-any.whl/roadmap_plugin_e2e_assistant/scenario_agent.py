"""Compose a test **scenario** from existing components, by chat.

Unlike the live component assistant (which drives a browser), scenario building is pure
composition over the saved component catalog — so it's a stateless one-shot: the model
gets the current scenario draft + the catalog + the instruction and returns the updated
draft. The scenario draft itself carries the state across turns. Every returned step
reference is **validated against the catalog** (unknown components/actions are dropped
and reported) so a hallucinated id can't corrupt the scenario.
"""

from __future__ import annotations

import json

from . import runtime

_SYSTEM_PROMPT = """\
You compose end-to-end test SCENARIOS by ordering reusable COMPONENTS (page-objects).

A scenario has:
- params: named inputs, each {"name": ..., "default": ...}.
- steps: an ordered list. Each step references a component from the catalog:
  {"ref": "<componentId>"} includes the WHOLE component (all its actions), or
  {"ref": "<componentId>/<actionId>"} uses a single action of it.
  You may add {"bindings": {"paramName": "value"}} to a step to override a value.

You are given the current scenario and the catalog of available components. Apply the
user's instruction and return the UPDATED scenario. Keep existing steps unless the user
asks to change them. Only use ids that appear in the catalog — never invent ids.

Respond with JSON ONLY, no prose, in this exact shape:
{"reply": "<one short sentence about what you did>",
 "params": [{"name": "user", "default": "alice"}],
 "steps": [{"ref": "login", "bindings": {}}, {"ref": "table/sort", "bindings": {}}]}
"""


def _catalog(components) -> str:
    lines = []
    for c in components:
        actions = [cs.step for cs in c.steps if cs.step is not None]
        act = "; ".join(f'{a.id}="{a.label or a.id}"' for a in actions) or "(no single actions)"
        lines.append(f'- {c.id} "{c.name}" ({c.kind}) — whole, or actions: {act}')
    return "\n".join(lines) or "(no components defined yet)"


def _describe_steps(steps: list[dict]) -> str:
    if not steps:
        return "(none)"
    return "\n".join(f'  - {s.get("ref", "")}' for s in steps)


def _valid_refs(components) -> dict[str, set]:
    """componentId -> set of its inline-action ids (for validating refs)."""
    out = {}
    for c in components:
        out[c.id] = {cs.step.id for cs in c.steps if cs.step is not None}
    return out


def compose(scenario: dict, message: str) -> dict:
    """Return ``{"reply", "params", "steps"}`` — the updated scenario draft."""
    ai = runtime.ai_service()
    provider = ai.provider_for_task("webtest_design", "context_assistant")
    if provider is None:
        raise RuntimeError("No AI provider configured. Add one in Settings → AI.")

    components = runtime.e2e_service().list_components()
    user = (
        f"Current scenario:\n"
        f"name: {scenario.get('name', '')}\n"
        f"params: {json.dumps(scenario.get('params', []))}\n"
        f"steps:\n{_describe_steps(scenario.get('steps', []))}\n\n"
        f"Available components:\n{_catalog(components)}\n\n"
        f"Instruction: {message}"
    )
    text = ai.chat_text(
        provider,
        [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user}],
        max_tokens=1500,
    ).strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    data = json.loads(text)

    # ── validate every ref against the catalog; drop + report unknowns ──────────
    valid = _valid_refs(components)
    steps, dropped = [], []
    for s in data.get("steps", []):
        ref = str(s.get("ref", "")).strip()
        comp_id, _, action_id = ref.partition("/")
        if comp_id not in valid or (action_id and action_id not in valid[comp_id]):
            dropped.append(ref or "(empty)")
            continue
        steps.append({"ref": ref, "step": None, "bindings": s.get("bindings", {}) or {}})

    params = [{"name": p.get("name", ""), "label": "", "default": p.get("default", ""),
               "required": False}
              for p in data.get("params", []) if p.get("name")]

    reply = str(data.get("reply", "")).strip() or "Updated the scenario."
    if dropped:
        reply += f" (Skipped unknown references: {', '.join(dropped)}.)"
    return {"reply": reply, "params": params, "steps": steps}
