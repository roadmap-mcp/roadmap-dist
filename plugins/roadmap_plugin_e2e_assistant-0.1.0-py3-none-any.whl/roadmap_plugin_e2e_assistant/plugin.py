"""AI test-design assistant plugin activator.

Mounts ``/api/e2e-assistant`` and starts an idle-session reaper. Requires the e2e
engine (models + save + driver resolution), the ai service (the tool-calling loop),
and the context plugin (co-located with the rest of the e2e stack).
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_ai import AI_TASK_TYPES_POINT, AITaskType

from . import runtime, session
from .router import create_assistant_router


class E2EAssistantPlugin(Plugin):
    id = "roadmap.e2e.assistant"
    name = "Web Testing — AI design assistant"
    requires = ["roadmap.e2e", "roadmap.ai", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services)
        ctx.add_router(create_assistant_router())
        ctx.extend(AI_TASK_TYPES_POINT, AITaskType(
            id="webtest_design", label="Web test design", order=20,
            description="Powers the AI test-design assistant (live browser) + "
                        "scenario composition."))

        # reap idle browser sessions (best-effort; skip if APScheduler is unavailable)
        try:
            from apscheduler.schedulers.background import BackgroundScheduler
            self._scheduler = BackgroundScheduler(daemon=True)
            self._scheduler.add_job(session.reap_idle, "interval", minutes=5,
                                    id="e2e-assistant-reaper", max_instances=1, coalesce=True)
            self._scheduler.start()
        except Exception:
            self._scheduler = None

    def deactivate(self, ctx: PluginContext) -> None:
        if getattr(self, "_scheduler", None) is not None:
            self._scheduler.shutdown(wait=False)
        session.close_all()
