"""The ``.puml`` FileViewer contribution."""

from __future__ import annotations

from roadmap_plugin_fileviewer import FileViewer

PLANTUML_VIEWER = FileViewer(
    extensions=[".puml"],
    kind="plantuml",
    label="PlantUML",
    endpoint="/api/viewer/plantuml/url",
)
