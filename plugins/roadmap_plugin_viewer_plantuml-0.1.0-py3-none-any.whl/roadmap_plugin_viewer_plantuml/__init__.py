"""PlantUML viewer plugin — contributes a ``.puml`` file viewer to the
``roadmap.viewers`` extension point and renders diagrams via a PlantUML server."""
