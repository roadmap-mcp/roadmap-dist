"""``/api/viewer/plantuml`` — turn a ``.puml`` file, or a diagram's source, into
PlantUML server URLs."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from roadmap_framework import session

from . import runtime
from .encode import plantuml_encode_source

router = APIRouter(prefix="/api/viewer/plantuml", tags=["viewer-plantuml"])

#: set at activate — the fileviewer host service (shared path-allow check).
_host = None


def set_host(host) -> None:
    global _host
    _host = host


@router.get("/url")
def plantuml_url(path: str):
    """SVG/PNG URLs for a ``.puml`` file, rendered by the configured PlantUML server."""
    if not session.is_unlocked():
        raise HTTPException(status_code=403, detail="App is locked")
    if _host is None or not _host.is_allowed(path):
        raise HTTPException(status_code=403,
                            detail="Access denied: path is outside allowed directories")
    p = Path(path)
    if not p.is_file():
        raise HTTPException(status_code=404, detail="File not found")

    encoded = plantuml_encode_source(p.read_text(encoding="utf-8", errors="replace"))
    server = runtime.server_url()
    if not server:
        raise HTTPException(status_code=400,
                            detail="No PlantUML server configured.")
    return {"svg_url": f"{server}/svg/{encoded}", "png_url": f"{server}/png/{encoded}"}


class DiagramSource(BaseModel):
    source: str


@router.post("/encode")
def plantuml_encode(body: DiagramSource):
    """SVG/PNG URLs for a diagram's source text — what another plugin shows a
    diagram it holds with (a knowledge-base topic's ``plantuml`` fragment)."""
    if not session.is_unlocked():
        raise HTTPException(status_code=403, detail="App is locked")
    server = runtime.server_url()
    if not server:
        raise HTTPException(status_code=400,
                            detail="No PlantUML server configured.")
    encoded = plantuml_encode_source(body.source)
    return {"svg_url": f"{server}/svg/{encoded}", "png_url": f"{server}/png/{encoded}"}
