"""PlantUML viewer plugin activator — contributes the ``.puml`` FileViewer to the
host's ``roadmap.viewers`` point and serves ``/api/viewer/plantuml``."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_fileviewer import VIEWERS_POINT

from . import runtime
from . import router as router_module
from .router import router as plantuml_router
from .viewer import PLANTUML_VIEWER


class PlantumlViewerPlugin(Plugin):
    id = "roadmap.viewer.plantuml"
    name = "PlantUML Viewer"
    requires = ["roadmap.fileviewer"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.extend(VIEWERS_POINT, PLANTUML_VIEWER)
        # reuse the host's shared path-allow check
        router_module.set_host(ctx.services.require("fileviewer"))
        ctx.add_router(plantuml_router)
