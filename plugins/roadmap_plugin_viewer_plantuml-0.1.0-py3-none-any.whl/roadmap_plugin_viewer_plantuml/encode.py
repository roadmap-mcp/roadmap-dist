"""PlantUML's custom base64-ish encoding of a raw-deflated diagram source.

Ported verbatim from the previous fileviewer implementation (which mirrors the
PlantUML text-encoding spec). Given raw-deflated bytes, produce the path segment
a PlantUML server accepts at ``/svg/<encoded>`` or ``/png/<encoded>``.
"""

from __future__ import annotations

import zlib


def plantuml_encode_source(content: str) -> str:
    """Encode diagram *source text* to a PlantUML server path segment."""
    compressed = zlib.compress(content.encode("utf-8"))[2:-4]  # raw deflate
    return _plantuml_encode(compressed)


def _plantuml_encode(data: bytes) -> str:
    res = []
    for i in range(0, len(data), 3):
        if i + 2 < len(data):
            b1, b2, b3 = data[i], data[i + 1], data[i + 2]
            res.append(_encode6bit(b1 >> 2))
            res.append(_encode6bit(((b1 & 0x3) << 4) | (b2 >> 4)))
            res.append(_encode6bit(((b2 & 0xF) << 2) | (b3 >> 6)))
            res.append(_encode6bit(b3 & 0x3F))
        elif i + 1 < len(data):
            b1, b2 = data[i], data[i + 1]
            res.append(_encode6bit(b1 >> 2))
            res.append(_encode6bit(((b1 & 0x3) << 4) | (b2 >> 4)))
            res.append(_encode6bit((b2 & 0xF) << 2))
            res.append("=")
        else:
            b1 = data[i]
            res.append(_encode6bit(b1 >> 2))
            res.append(_encode6bit((b1 & 0x3) << 4))
            res.append("=")
            res.append("=")
    return "".join(res)


def _encode6bit(b: int) -> str:
    if b < 10:
        return chr(48 + b)       # 0-9
    b -= 10
    if b < 26:
        return chr(65 + b)       # A-Z
    b -= 26
    if b < 26:
        return chr(97 + b)       # a-z
    b -= 26
    if b == 0:
        return "-"
    return "_"
