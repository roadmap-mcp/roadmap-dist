"""Runtime wiring + config for the PlantUML viewer.

Its own config key ``plantuml_server_url`` (defaults to the public plantuml.org
server, so diagrams render out of the box). For back-compat it still honours a
legacy ``file_viewers[.puml].server_url`` entry if one is configured.
"""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore

_store: Optional[ConfigStore] = None

DEFAULT_SERVER = "https://www.plantuml.com/plantuml"

DEFAULTS = {
    "plantuml_server_url": DEFAULT_SERVER,
    "file_viewers": [],  # legacy per-extension config (back-compat)
}


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def server_url() -> str:
    """Resolve the PlantUML server: an explicit legacy ``.puml`` viewer wins
    (back-compat), else the ``plantuml_server_url`` key (defaults to plantuml.org)."""
    assert _store is not None, "plantuml runtime not initialised"
    config = _store.load_ns(DEFAULTS)
    for v in config.file_viewers:
        if getattr(v, "extension", "").lower() == ".puml" and getattr(v, "server_url", ""):
            return v.server_url.rstrip("/")
    return (config.plantuml_server_url or DEFAULT_SERVER).rstrip("/")
