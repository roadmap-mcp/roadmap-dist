"""Workflow AI-assistant plugin activator.

Mounts ``/api/workflow-assistant`` (the stateless flow composer) and registers its AI task
type. Requires the workflow engine (the stepdef catalog), the ai service (the chat call),
and the context plugin (co-located with the rest of the workflow stack). The composer only
proposes a flow draft — it never executes or saves anything — so no session registry or
resource reaper is needed.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_ai import AI_TASK_TYPES_POINT, AITaskType

from . import runtime
from .router import create_assistant_router


class WorkflowAssistantPlugin(Plugin):
    id = "roadmap.workflow.assistant"
    name = "Workflows — AI assistant"
    requires = ["roadmap.workflow", "roadmap.ai", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services)
        ctx.add_router(create_assistant_router())
        ctx.extend(AI_TASK_TYPES_POINT, AITaskType(
            id="workflow_flow_design", label="Workflow flow design", order=23,
            description="Powers the AI that composes a flow from existing step definitions."))
