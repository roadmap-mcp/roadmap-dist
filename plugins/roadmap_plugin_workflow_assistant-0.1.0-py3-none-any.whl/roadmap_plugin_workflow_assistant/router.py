"""HTTP surface: ``/api/workflow-assistant``.

A single stateless endpoint — the flow composer. It assembles a flow draft from the text
catalog of existing stepdefs (ids/names/kinds/descriptions + which fields are pre-filled vs
blank — never a secret, never a credential). It only proposes a draft; nothing is executed
and nothing is saved here.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from . import flow_agent, runtime


class ComposeRequest(BaseModel):
    message: str
    flow: dict = {}


def create_assistant_router() -> APIRouter:
    router = APIRouter(prefix="/api/workflow-assistant", tags=["workflow-assistant"])

    # ── flow composition by chat (stateless — no session, no browser) ──────────
    @router.post("/flow")
    def compose_flow(req: ComposeRequest):
        try:
            return flow_agent.compose(req.flow, req.message)
        except Exception as e:
            raise HTTPException(status_code=400, detail=runtime.ai_service().describe_error(e))

    return router
