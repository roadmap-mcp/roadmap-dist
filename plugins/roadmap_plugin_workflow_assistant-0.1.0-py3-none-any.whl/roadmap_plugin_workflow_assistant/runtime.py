"""Per-process runtime wiring for the workflow-assistant plugin."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ServiceRegistry

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry) -> None:
    global _store, _services
    _store, _services = config, services


def ai_service():
    assert _services is not None, "workflow-assistant runtime not initialised"
    return _services.require("ai")


def workflow_service():
    assert _services is not None, "workflow-assistant runtime not initialised"
    return _services.require("workflow")
