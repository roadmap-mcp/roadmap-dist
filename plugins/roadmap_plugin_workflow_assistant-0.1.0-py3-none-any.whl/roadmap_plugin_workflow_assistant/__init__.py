"""AI assistant for the workflow engine.

* **flow composer** — a stateless assistant that assembles a flow from a text catalog of
  existing step definitions (ids/names/kinds/descriptions + which config fields are pre-filled
  vs blank — no secrets, no step values). It proposes a flow draft; the user reviews, edits,
  and saves it. Every reference it emits is validated against the stepdef catalog.
"""
