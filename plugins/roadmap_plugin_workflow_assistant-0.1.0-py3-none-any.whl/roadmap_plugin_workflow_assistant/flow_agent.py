"""Compose a **flow** from existing step definitions, by chat (stateless).

Flow building is pure composition over the saved stepdef catalog, so it's a one-shot: the
model gets the current flow draft + the catalog + the instruction and returns the updated
draft. The draft itself carries state across turns. Every returned reference is **validated
against the catalog** (unknown stepdefs are dropped and reported) so a hallucinated id can't
corrupt the flow.

The catalog the model sees contains only stepdef **ids, names, kinds, descriptions, and
which config fields are pre-filled vs left blank** — never a pre-filled value that is a
secret, and never a credential. So this assistant never sees a secret. Each proposed flow
step is a CompositeStep: ``{"ref": <stepdefId>, "step": {"config": {fill-ins}}, "bindings":
{}, "label": ...}`` — the stepdef is the template, the ``step`` holds only the blanks to
fill in.
"""

from __future__ import annotations

import json

from . import runtime

_SYSTEM_PROMPT = """\
You compose automation FLOWS by ordering reusable STEP DEFINITIONS (stepdefs). A stepdef is
a template for a single step (an executor `kind` plus a partially-filled `config`); a flow
step references one and fills in its remaining BLANK config fields.

A flow has:
- params: named inputs, each {"name": ..., "default": ...}.
- steps: an ordered list. Each step references a stepdef from the catalog:
  {"ref": "<stepdefId>", "config": {"<blankField>": "<value>"}}
  where `config` supplies values ONLY for the fields the stepdef leaves blank (you may use
  ${paramName} to pass a flow param through). Fields the stepdef already fills are inherited
  — do not repeat them. You may add {"label": "..."} to rename the step in the flow.

You are given the current flow and the catalog of available stepdefs (each lists its
pre-filled fields and its blank fill-in fields). Apply the user's instruction and return the
UPDATED flow. Keep existing steps unless the user asks to change them. Only use stepdef ids
that appear in the catalog — never invent ids. You never handle credentials; those are
referenced inside stepdefs and injected at run time.

Respond with JSON ONLY, no prose, in this exact shape:
{"reply": "<one short sentence about what you did>",
 "params": [{"name": "user", "default": "alice"}],
 "steps": [{"ref": "sd_123", "config": {"path": "${user}"}, "label": ""}]}
"""


def _catalog(stepdefs) -> str:
    lines = []
    for sd in stepdefs:
        filled = [k for k, v in (sd.config or {}).items() if v not in ("", None)]
        blank = [k for k, v in (sd.config or {}).items() if v in ("", None)]
        prefilled = ", ".join(filled) or "(none)"
        fillins = ", ".join(blank) or "(none)"
        desc = f" — {sd.description}" if sd.description else ""
        lines.append(
            f'- {sd.id} "{sd.name}" ({sd.kind}){desc}. '
            f'Pre-filled: {prefilled}. Fill-in (blank): {fillins}'
        )
    return "\n".join(lines) or "(no step definitions defined yet)"


def _describe_steps(steps: list[dict]) -> str:
    if not steps:
        return "(none)"
    return "\n".join(f'  - {s.get("ref", "")}' for s in steps)


def compose(flow: dict, message: str) -> dict:
    """Return ``{"reply", "params", "steps"}`` — the updated flow draft."""
    ai = runtime.ai_service()
    provider = ai.provider_for_task("workflow_flow_design", "context_assistant")
    if provider is None:
        raise RuntimeError("No AI provider configured. Add one in Settings → AI.")

    stepdefs = runtime.workflow_service().list_stepdefs()
    user = (
        f"Current flow:\n"
        f"name: {flow.get('name', '')}\n"
        f"params: {json.dumps(flow.get('params', []))}\n"
        f"steps:\n{_describe_steps(flow.get('steps', []))}\n\n"
        f"Available step definitions:\n{_catalog(stepdefs)}\n\n"
        f"Instruction: {message}"
    )
    text = ai.chat_text(
        provider,
        [{"role": "system", "content": _SYSTEM_PROMPT}, {"role": "user", "content": user}],
        max_tokens=1500,
    ).strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1].rsplit("```", 1)[0].strip()
    data = json.loads(text)

    # ── validate every ref against the stepdef catalog; drop + report unknowns ──
    valid = {sd.id for sd in stepdefs}
    steps, dropped = [], []
    for s in data.get("steps", []):
        ref = str(s.get("ref", "")).strip()
        if ref not in valid:
            dropped.append(ref or "(empty)")
            continue
        config = s.get("config") or {}
        step = {"config": config if isinstance(config, dict) else {}}
        steps.append({
            "ref": ref,
            "step": step,
            "bindings": s.get("bindings", {}) or {},
            "label": str(s.get("label", "") or ""),
        })

    params = [{"name": p.get("name", ""), "label": "", "default": p.get("default", ""),
               "required": False}
              for p in data.get("params", []) if p.get("name")]

    reply = str(data.get("reply", "")).strip() or "Updated the flow."
    if dropped:
        reply += f" (Skipped unknown references: {', '.join(dropped)}.)"
    return {"reply": reply, "params": params, "steps": steps}
