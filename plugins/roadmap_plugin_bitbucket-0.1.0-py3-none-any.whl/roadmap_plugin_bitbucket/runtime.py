"""Bitbucket plugin runtime — config + cache access.

Module-level singletons stashed at activation so routers/services don't have to
thread the config store through every call (same pattern as the jira plugin).
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from roadmap_framework import ConfigStore

from .cache import BitbucketCache
from .models import BitbucketConfig

_store: Optional[ConfigStore] = None


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def _require_store() -> ConfigStore:
    assert _store is not None, "bitbucket runtime not initialised"
    return _store


def config_dir() -> Path:
    return _require_store().path.parent


def has_encrypted_fields() -> bool:
    return _require_store().has_encrypted_fields()


def bitbucket_config() -> BitbucketConfig:
    raw = _require_store().load_decrypted()
    return BitbucketConfig(**(raw.get("bitbucket") or {}))


def cache() -> BitbucketCache:
    cfg = bitbucket_config()
    return BitbucketCache(cfg.cache_dir or str(config_dir() / "cache"),
                          cfg.refresh_duration)


def service():
    """A :class:`BitbucketService` bound to the current config + cache."""
    from .bitbucket_service import BitbucketService
    return BitbucketService(bitbucket_config(), cache())
