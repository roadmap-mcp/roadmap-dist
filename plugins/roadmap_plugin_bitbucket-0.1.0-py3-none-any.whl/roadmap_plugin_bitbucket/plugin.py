"""Bitbucket plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .pr_router import router as pr_router
from .settings_section import BITBUCKET_SECTION, create_bitbucket_settings_router


class BitbucketPlugin(Plugin):
    id = "roadmap.bitbucket"
    name = "Bitbucket"
    requires = ["roadmap.settings"]
    # Contexts (Lite) adds bitbucket's context item types (and tools) when installed
    optional_requires = ["roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.register_sensitive_path("bitbucket.api_token")

        ctx.extend(SETTINGS_SECTIONS_POINT, BITBUCKET_SECTION)

        ctx.add_router(pr_router)
        ctx.add_router(create_bitbucket_settings_router())

        # Its pull-request context item type, where Contexts is installed (Lite); the
        # Bitbucket source itself (settings, API, the knowledge base's Layer 1) works
        # without it.
        if ctx.services.get("context") is not None:
            from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT

            from .context_items import BITBUCKET_ITEM_TYPES, BITBUCKET_PREVIEWS
            for item_type in BITBUCKET_ITEM_TYPES:
                ctx.extend(CONTEXT_ITEM_TYPES_POINT, item_type)
            for preview in BITBUCKET_PREVIEWS:
                ctx.extend(CONTEXT_PREVIEW_POINT, preview)
