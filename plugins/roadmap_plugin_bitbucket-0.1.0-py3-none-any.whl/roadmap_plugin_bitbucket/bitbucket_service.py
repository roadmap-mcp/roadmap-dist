"""Bitbucket Cloud pull-request fetching with read-through caching."""

from __future__ import annotations

import logging

from .bitbucket_client import bitbucket_request, parse_pr_url
from .cache import BitbucketCache
from .models import BitbucketConfig

log = logging.getLogger(__name__)

_MAX_COMMENT_PAGES = 10
_COMMENT_PAGE_LEN = 50


def _build_comment(c: dict) -> dict:
    """Normalise one comment, preserving inline file/line information."""
    user = c.get("user", {}) or {}
    inline = c.get("inline", {}) or {}
    comment: dict = {
        "author": user.get("display_name", user.get("nickname", "")),
        "created": c.get("created_on", ""),
        "body": (c.get("content", {}) or {}).get("raw", ""),
    }
    if inline.get("path"):
        comment["file"] = inline["path"]
        # "to" is the line the comment sits on; "from" is set for moved/deleted lines.
        line = inline.get("to") or inline.get("from")
        if line is not None:
            comment["line"] = line
    return comment


def _build_reviews(pr: dict) -> list[dict]:
    """Reviewer approval status, derived from the PR's ``participants``.

    Bitbucket reports each participant with a ``role`` (REVIEWER/PARTICIPANT), an
    ``approved`` flag and a ``state``. Surface designated reviewers plus anyone
    who has actually acted on the PR.
    """
    reviews: list[dict] = []
    for p in pr.get("participants", []) or []:
        user = p.get("user", {}) or {}
        role = p.get("role", "")
        approved = bool(p.get("approved", False))
        state = p.get("state")  # "approved" | "changes_requested" | None
        if role != "REVIEWER" and not approved and not state:
            continue
        reviews.append({
            "name": user.get("display_name", user.get("nickname", "")),
            "role": role or "PARTICIPANT",
            "approved": approved,
            "state": state or ("approved" if approved else ""),
        })
    return reviews


def _build_pr_result(pr: dict, comments: list[dict]) -> dict:
    """Flatten a Bitbucket PR + its comments into the shape we cache and render."""
    author = pr.get("author", {}) or {}
    src = (pr.get("source", {}) or {}).get("branch", {}) or {}
    dst = (pr.get("destination", {}) or {}).get("branch", {}) or {}
    links = pr.get("links", {}) or {}
    return {
        "id": pr.get("id"),
        "title": pr.get("title", ""),
        "description": pr.get("description", ""),
        "state": pr.get("state", ""),
        "author": author.get("display_name", author.get("nickname", "")),
        "source_branch": src.get("name", ""),
        "destination_branch": dst.get("name", ""),
        "url": (links.get("html", {}) or {}).get("href", ""),
        "created_on": pr.get("created_on", ""),
        "updated_on": pr.get("updated_on", ""),
        "reviews": _build_reviews(pr),
        "comments": [_build_comment(c) for c in comments],
    }


class BitbucketService:
    def __init__(self, cfg: BitbucketConfig, cache: BitbucketCache):
        self.cfg = cfg
        self.cache = cache

    def fetch_pr(self, workspace: str, repo_slug: str, pr_id: int) -> dict:
        """Always hit the API (so reviews are current) and refresh the cache.

        Raises ``HTTPException`` when credentials are missing or the call fails.
        """
        pr = bitbucket_request(
            self.cfg, f"/repositories/{workspace}/{repo_slug}/pullrequests/{pr_id}")
        comments = self._fetch_comments(workspace, repo_slug, pr_id)
        result = _build_pr_result(pr, comments)
        self.cache.write(self.cache.pr_path(workspace, repo_slug, pr_id), result)
        return result

    def get_pr(self, workspace: str, repo_slug: str, pr_id: int) -> dict | None:
        """Read-through cache: cached copy if fresh, else the API, else ``None``."""
        path = self.cache.pr_path(workspace, repo_slug, pr_id)
        cached = self.cache.read(path)
        if cached is not None:
            return cached
        try:
            return self.fetch_pr(workspace, repo_slug, pr_id)
        except Exception:
            log.warning("Failed to fetch Bitbucket PR %s/%s#%s",
                        workspace, repo_slug, pr_id)
            return None

    def get_pr_from_url(self, url: str) -> dict | None:
        return self.get_pr(*parse_pr_url(url))

    def _fetch_comments(self, workspace: str, repo_slug: str, pr_id: int) -> list[dict]:
        """All comments for a PR, following pagination (bounded)."""
        comments: list[dict] = []
        page_path = (f"/repositories/{workspace}/{repo_slug}/pullrequests/{pr_id}"
                     f"/comments?pagelen={_COMMENT_PAGE_LEN}")
        base = self.cfg.base_url.rstrip("/")
        pages = 0
        while page_path and pages < _MAX_COMMENT_PAGES:
            try:
                data = bitbucket_request(self.cfg, page_path)
            except Exception:
                break
            comments.extend(data.get("values", []))
            next_url = data.get("next", "")
            # `next` is absolute; strip the base back off to get a relative path.
            page_path = next_url.replace(base, "") if next_url else ""
            pages += 1
        return comments
