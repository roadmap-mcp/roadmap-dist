"""Pull-request lookup / refresh endpoints (``/api/bitbucket``).

Used by the "add Bitbucket PR" UI to validate a URL and prefill the label before
the item is added, and to force a refresh of an already-cached PR.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from roadmap_framework import session

from . import runtime
from .bitbucket_client import parse_pr_url, require_bitbucket_configured

router = APIRouter(prefix="/api/bitbucket", tags=["bitbucket"])


class PrUrlRequest(BaseModel):
    url: str


def _require_unlocked():
    if runtime.has_encrypted_fields() and not session.is_unlocked():
        raise HTTPException(status_code=403,
                            detail="App is locked. Provide password to unlock.")


def _summary(workspace: str, repo_slug: str, pr_id: int, data: dict) -> dict:
    return {
        "workspace": workspace,
        "repo": repo_slug,
        "pr_id": pr_id,
        "title": data.get("title", ""),
        "state": data.get("state", ""),
        "author": data.get("author", ""),
        "source_branch": data.get("source_branch", ""),
        "destination_branch": data.get("destination_branch", ""),
        "url": data.get("url", ""),
        "comment_count": len(data.get("comments", [])),
        "review_count": len(data.get("reviews", [])),
    }


@router.get("/pr")
def lookup_pr(url: str):
    """Look up a PR by URL (read-through cache) — for validating before adding."""
    _require_unlocked()
    cfg = runtime.bitbucket_config()
    require_bitbucket_configured(cfg)
    workspace, repo_slug, pr_id = parse_pr_url(url)
    data = runtime.service().get_pr(workspace, repo_slug, pr_id)
    if not data:
        raise HTTPException(
            status_code=404,
            detail=f"Bitbucket PR {workspace}/{repo_slug}#{pr_id} could not be fetched.")
    return _summary(workspace, repo_slug, pr_id, data)


@router.post("/pr/refresh")
def refresh_pr(req: PrUrlRequest):
    """Force-refresh a PR from the API, bypassing the cache."""
    _require_unlocked()
    cfg = runtime.bitbucket_config()
    require_bitbucket_configured(cfg)
    workspace, repo_slug, pr_id = parse_pr_url(req.url)
    data = runtime.service().fetch_pr(workspace, repo_slug, pr_id)
    return _summary(workspace, repo_slug, pr_id, data)
