"""Bitbucket settings section + its token-test endpoint."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from roadmap_framework import session
from roadmap_plugin_settings import SettingsSection

from . import runtime
from .bitbucket_client import (auth_mode_hint, bitbucket_request,
                               require_bitbucket_configured)
from .models import BitbucketConfig


def _bitbucket_defaults() -> dict:
    return {"bitbucket": BitbucketConfig().model_dump()}


BITBUCKET_SECTION = SettingsSection(
    id="bitbucket",
    label="Bitbucket",
    order=25,
    group="Information Sources",
    defaults=_bitbucket_defaults,
    sensitive_fields=["bitbucket.api_token"],
)


def create_bitbucket_settings_router() -> APIRouter:
    router = APIRouter(prefix="/api/settings", tags=["settings", "bitbucket"])

    def require_unlocked():
        if runtime.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    @router.post("/test-bitbucket")
    def test_bitbucket():
        """Verify the configured token by identifying the caller.

        On failure, append which auth mode was used — a bare "token is invalid"
        from Bitbucket is almost always an API-token-sent-as-Bearer mismatch.
        (``/workspaces`` is not used as a fallback: Atlassian deprecated it and it
        now returns 410, which would mask the real error.)
        """
        require_unlocked()
        cfg = runtime.bitbucket_config()
        require_bitbucket_configured(cfg)

        try:
            data = bitbucket_request(cfg, "/user")
        except HTTPException as e:
            raise HTTPException(status_code=400,
                                detail=f"{e.detail} {auth_mode_hint(cfg)}")
        name = data.get("display_name") or data.get("nickname") or "Unknown"
        return {"status": "ok", "message": f"Connected as {name}"}

    return router
