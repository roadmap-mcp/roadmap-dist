"""The ``bitbucket_pr`` context item type + its preview contribution."""

from __future__ import annotations

from fastapi import HTTPException

from roadmap_plugin_context import ContextItemType, PreviewContribution

from . import runtime
from .bitbucket_client import parse_pr_url

#: Comments rendered in full before the "and N more" tail.
_MAX_RENDERED_COMMENTS = 20


def resolve_bitbucket_pr(pr_url: str, *, text=None, path=None) -> dict:
    """Add-time metadata for a PR. The item id is the PR URL itself."""
    workspace, repo_slug, pr_id = parse_pr_url(pr_url)
    data = runtime.service().get_pr(workspace, repo_slug, pr_id)
    if not data:
        raise HTTPException(
            status_code=404,
            detail=f"Bitbucket PR {workspace}/{repo_slug}#{pr_id} could not be fetched. "
                   "Check the URL and your token in Settings -> Bitbucket.",
        )
    return {
        "type": "bitbucket_pr",
        "id": pr_url,
        "title": f"{workspace}/{repo_slug}#{pr_id}",
        "label": data.get("title", f"PR #{pr_id}"),
    }


def render_bitbucket_pr(pr_url: str, label: str) -> str:
    """Render a PR — metadata, description, reviews and comments — as markdown."""
    workspace, repo_slug, pr_id = parse_pr_url(pr_url)
    data = runtime.service().get_pr(workspace, repo_slug, pr_id)
    if not data:
        return f"## {label} (Bitbucket PR)\n\n(PR not found)"

    lines = [
        f"## {label} ({workspace}/{repo_slug}#{pr_id})",
        f"**State:** {data.get('state', 'Unknown')} | "
        f"**Author:** {data.get('author', 'Unknown')}",
        f"**Branch:** {data.get('source_branch', '?')} -> {data.get('destination_branch', '?')}",
    ]

    if description := data.get("description", ""):
        lines.append(f"\n### Description\n{description}")

    reviews = data.get("reviews", [])
    if reviews:
        lines.append(f"\n### Reviews ({len(reviews)})")
        for r in reviews:
            if r.get("approved"):
                status = "approved"
            elif r.get("state") == "changes_requested":
                status = "changes requested"
            else:
                status = "pending"
            role = (r.get("role") or "reviewer").lower()
            lines.append(f"- {r.get('name', 'Unknown')} ({role}): {status}")

    comments = data.get("comments", [])
    if comments:
        lines.append(f"\n### Comments ({len(comments)})")
        for c in comments[:_MAX_RENDERED_COMMENTS]:
            location = ""
            if c.get("file"):
                location = f" `{c['file']}"
                if c.get("line"):
                    location += f":{c['line']}"
                location += "`"
            lines.append(
                f"\n**{c.get('author', 'Unknown')}** "
                f"({c.get('created', '')[:10]}){location}:\n{c.get('body', '')}"
            )
        if len(comments) > _MAX_RENDERED_COMMENTS:
            lines.append(f"\n... and {len(comments) - _MAX_RENDERED_COMMENTS} more comments")

    return "\n".join(lines)


BITBUCKET_ITEM_TYPES = [
    ContextItemType(
        "bitbucket_pr",
        resolve=resolve_bitbucket_pr,
        render=lambda item, cfg: render_bitbucket_pr(
            item.get("id", ""),
            item.get("label", item.get("title", "Untitled")),
        ),
        label="Bitbucket PR",
        icon="bi-git",
    ),
]

BITBUCKET_PREVIEWS = [
    PreviewContribution(
        "bitbucket_pr",
        lambda params, label, cfg: render_bitbucket_pr(params.get("url", ""), label),
        label="Bitbucket PR",
    ),
]
