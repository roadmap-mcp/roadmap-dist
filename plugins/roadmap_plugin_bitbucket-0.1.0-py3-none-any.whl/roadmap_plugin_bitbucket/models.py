"""Bitbucket configuration schema."""

from pydantic import BaseModel


class BitbucketConfig(BaseModel):
    """Connection settings for the Bitbucket Cloud REST API.

    Authentication is token-based. How the token is sent depends on ``username``:

    * ``username`` set  -> HTTP Basic ``username:api_token``. Use this for an
      Atlassian API token (paired with your account email) or an app password
      (paired with your Bitbucket username).
    * ``username`` blank -> ``Authorization: Bearer <api_token>``. Use this for a
      workspace / repository / project access token.
    """

    base_url: str = "https://api.bitbucket.org/2.0"
    username: str = ""
    api_token: str = ""
    cache_dir: str = ""
    refresh_duration: int = 3600
