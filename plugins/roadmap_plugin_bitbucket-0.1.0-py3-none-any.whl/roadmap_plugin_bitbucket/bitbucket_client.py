"""HTTP client for the Bitbucket Cloud REST API.

Token-based auth only. See :class:`~.models.BitbucketConfig` for how ``username``
selects between Basic (API token / app password) and Bearer (access token).
"""

from __future__ import annotations

import base64
import json
import re
import urllib.error
import urllib.request

from fastapi import HTTPException

from .models import BitbucketConfig

_PR_URL_RE = re.compile(
    r"https?://bitbucket\.org/(?P<workspace>[^/]+)/(?P<repo>[^/]+)/pull-requests/(?P<id>\d+)"
)

#: Atlassian-issued API tokens. These authenticate as an *account* and must be sent
#: as Basic auth with that account's email — Bearer always yields 401.
_ACCOUNT_TOKEN_PREFIXES = ("ATATT", "ATCTT")


def auth_mode_hint(cfg: BitbucketConfig) -> str:
    """Guidance to append to an auth failure, based on how the token was sent."""
    if cfg.username:
        return ("It was sent as Basic auth with the configured username/email. For a "
                "workspace, project or repository access token, clear Username / email "
                "so the token is sent as a Bearer token instead.")
    return ("It was sent as a Bearer token because Username / email is blank. Atlassian "
            "API tokens (ATATT.../ATCTT...) and app passwords must be sent as Basic auth "
            "— fill in Username / email in Workspace settings -> Bitbucket.")


def require_bitbucket_configured(cfg: BitbucketConfig) -> None:
    if not cfg.base_url:
        raise HTTPException(status_code=400, detail="Bitbucket base URL is not configured.")
    if not cfg.api_token:
        raise HTTPException(
            status_code=400,
            detail="Bitbucket API token is not configured. Add one in Workspace settings -> Bitbucket.",
        )
    # Fail fast on the combination that can only ever 401, rather than letting the
    # API return an opaque "Token is invalid, expired, or not supported".
    if not cfg.username and cfg.api_token.startswith(_ACCOUNT_TOKEN_PREFIXES):
        raise HTTPException(
            status_code=400,
            detail="This looks like an Atlassian API token, which must be sent with your "
                   "account email. Fill in Username / email in Workspace settings -> Bitbucket.",
        )


def parse_pr_url(url: str) -> tuple[str, str, int]:
    """Extract ``(workspace, repo_slug, pr_id)`` from a Bitbucket PR URL."""
    m = _PR_URL_RE.match((url or "").strip())
    if not m:
        raise HTTPException(
            status_code=400,
            detail="Invalid Bitbucket PR URL. Expected: "
                   "https://bitbucket.org/{workspace}/{repo}/pull-requests/{id}",
        )
    return m.group("workspace"), m.group("repo"), int(m.group("id"))


def _auth_header(cfg: BitbucketConfig) -> str:
    """Basic when a username is set, Bearer otherwise (access tokens)."""
    if cfg.username:
        credentials = base64.b64encode(
            f"{cfg.username}:{cfg.api_token}".encode()).decode()
        return f"Basic {credentials}"
    return f"Bearer {cfg.api_token}"


def bitbucket_request(cfg: BitbucketConfig, path: str) -> dict:
    """Authenticated GET against the Bitbucket API. ``path`` is base-relative."""
    req = urllib.request.Request(
        cfg.base_url.rstrip("/") + path,
        headers={"Authorization": _auth_header(cfg), "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            detail = json.loads(body).get("error", {}).get("message", body[:200])
        except Exception:
            detail = body[:200]
        raise HTTPException(status_code=400, detail=f"Bitbucket returned {e.code}: {detail}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
