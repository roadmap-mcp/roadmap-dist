"""Bitbucket plugin — pull requests as context items."""
