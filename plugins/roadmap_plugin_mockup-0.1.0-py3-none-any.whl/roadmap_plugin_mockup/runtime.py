"""Per-process runtime wiring for the mock-UI designer.

Stashes the ``ConfigStore`` at activate time so the storage module can resolve the
on-disk data dir and read config without threading the context through every call.
Because ``ConfigStore.path`` is already workspace-scoped, everything under it is
per-workspace automatically.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from roadmap_framework import ConfigStore

from .models import MockupConfig

_store: Optional[ConfigStore] = None


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def config_dir() -> Path:
    assert _store is not None, "mockup runtime not initialised"
    return _store.path.parent


def mockup_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/mockups``). Created on demand."""
    d = config_dir() / "mockups"
    d.mkdir(parents=True, exist_ok=True)
    return d


def mockup_config() -> MockupConfig:
    assert _store is not None, "mockup runtime not initialised"
    raw = _store.load_decrypted()
    return MockupConfig(**(raw.get("mockup") or {}))
