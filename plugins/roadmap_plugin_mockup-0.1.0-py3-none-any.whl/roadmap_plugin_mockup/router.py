"""HTTP surface: ``/api/mockups/{projects,screens}``.

CRUD for projects and screens. Handlers take the Pydantic models directly as the body
and return ``.model_dump()``; a missing entity is a 404.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from .models import MockupProject, Screen


def create_mockup_router(mockup) -> APIRouter:
    router = APIRouter(prefix="/api/mockups", tags=["mockup"])

    # ── projects ────────────────────────────────────────────────────────────
    @router.get("/projects")
    def list_projects():
        return {"projects": [p.model_dump() for p in mockup.list_projects()]}

    @router.get("/projects/{project_id}")
    def get_project(project_id: str):
        p = mockup.get_project(project_id)
        if p is None:
            raise HTTPException(status_code=404, detail="Project not found.")
        return p.model_dump()

    @router.post("/projects")
    def create_project(project: MockupProject):
        return mockup.save_project(project).model_dump()

    @router.put("/projects/{project_id}")
    def update_project(project_id: str, project: MockupProject):
        project.id = project_id
        return mockup.save_project(project).model_dump()

    @router.delete("/projects/{project_id}")
    def delete_project(project_id: str):
        return {"deleted": mockup.delete_project(project_id)}

    # ── screens ─────────────────────────────────────────────────────────────
    @router.get("/screens")
    def list_screens(project_id: str | None = None):
        return {"screens": [s.model_dump() for s in mockup.list_screens(project_id)]}

    @router.get("/screens/{screen_id}")
    def get_screen(screen_id: str):
        s = mockup.get_screen(screen_id)
        if s is None:
            raise HTTPException(status_code=404, detail="Screen not found.")
        return s.model_dump()

    @router.post("/screens")
    def create_screen(screen: Screen):
        return mockup.save_screen(screen).model_dump()

    @router.put("/screens/{screen_id}")
    def update_screen(screen_id: str, screen: Screen):
        screen.id = screen_id
        return mockup.save_screen(screen).model_dump()

    @router.delete("/screens/{screen_id}")
    def delete_screen(screen_id: str):
        return {"deleted": mockup.delete_screen(screen_id)}

    return router
