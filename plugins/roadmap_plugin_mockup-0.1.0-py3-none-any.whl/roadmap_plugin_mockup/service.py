"""The ``mockup`` service — the facade the router (and any future consumer) uses.

Thin CRUD over projects/screens. Keeps a stable surface so the storage internals can
change without touching callers.
"""

from __future__ import annotations

from . import storage
from .models import MockupProject, Screen


class MockupService:
    # ── projects ────────────────────────────────────────────────────────────
    def list_projects(self) -> list[MockupProject]:
        return storage.list_projects()

    def get_project(self, project_id: str) -> MockupProject | None:
        return storage.get_project(project_id)

    def save_project(self, project: MockupProject) -> MockupProject:
        return storage.save_project(project)

    def delete_project(self, project_id: str) -> bool:
        return storage.delete_project(project_id)

    # ── screens ─────────────────────────────────────────────────────────────
    def list_screens(self, project_id: str | None = None) -> list[Screen]:
        return storage.list_screens(project_id)

    def get_screen(self, screen_id: str) -> Screen | None:
        return storage.get_screen(screen_id)

    def save_screen(self, screen: Screen) -> Screen:
        return storage.save_screen(screen)

    def delete_screen(self, screen_id: str) -> bool:
        return storage.delete_screen(screen_id)
