"""JSON persistence for projects and screens under ``<config_dir>/mockups/``.

Layout (workspace-aware, since ``config_dir`` is workspace-scoped)::

    mockups/
      projects/<id>.json
      screens/<id>.json

No database — plain files, one per entity, matching how contexts and the other
plugins store their data.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from . import runtime
from .models import MockupProject, Screen


# ── directories ───────────────────────────────────────────────────────────────

def _dir(name: str) -> Path:
    d = runtime.mockup_dir() / name
    d.mkdir(parents=True, exist_ok=True)
    return d


def _projects_dir() -> Path:
    return _dir("projects")


def _screens_dir() -> Path:
    return _dir("screens")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ── projects ──────────────────────────────────────────────────────────────────

def list_projects() -> list[MockupProject]:
    out = []
    for f in sorted(_projects_dir().glob("*.json")):
        d = _read_json(f)
        if d:
            out.append(MockupProject(**d))
    return sorted(out, key=lambda p: (p.order, p.name.lower()))


def get_project(project_id: str) -> MockupProject | None:
    d = _read_json(_projects_dir() / f"{project_id}.json")
    return MockupProject(**d) if d else None


def save_project(project: MockupProject) -> MockupProject:
    if not project.id:
        project.id = new_id("prj")
    _write_json(_projects_dir() / f"{project.id}.json", project.model_dump())
    return project


def delete_project(project_id: str) -> bool:
    """Delete a project and cascade-delete its screens."""
    f = _projects_dir() / f"{project_id}.json"
    existed = f.exists()
    if existed:
        f.unlink()
    for scr in list_screens(project_id):
        delete_screen(scr.id)
    return existed


# ── screens ───────────────────────────────────────────────────────────────────

def list_screens(project_id: str | None = None) -> list[Screen]:
    out = []
    for f in sorted(_screens_dir().glob("*.json")):
        d = _read_json(f)
        if d and (project_id is None or d.get("project_id") == project_id):
            out.append(Screen(**d))
    return sorted(out, key=lambda s: (s.order, s.name.lower()))


def get_screen(screen_id: str) -> Screen | None:
    d = _read_json(_screens_dir() / f"{screen_id}.json")
    return Screen(**d) if d else None


def save_screen(screen: Screen) -> Screen:
    if not screen.id:
        screen.id = new_id("scr")
    _write_json(_screens_dir() / f"{screen.id}.json", screen.model_dump())
    return screen


def delete_screen(screen_id: str) -> bool:
    f = _screens_dir() / f"{screen_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False
