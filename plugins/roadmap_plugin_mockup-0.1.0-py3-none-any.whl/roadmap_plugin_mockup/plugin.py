"""Mock-UI designer plugin activator.

Publishes the ``mockup`` service, mounts ``/api/mockups``, and contributes a Mockups
settings tab. Self-contained — no extension points declared, no cross-plugin wiring.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .router import create_mockup_router
from .service import MockupService
from .settings_section import MOCKUP_SECTION


class MockupPlugin(Plugin):
    id = "roadmap.mockup"
    name = "Mockups"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)

        ctx.extend(SETTINGS_SECTIONS_POINT, MOCKUP_SECTION)

        mockup = MockupService()
        ctx.services.register("mockup", mockup)
        ctx.add_router(create_mockup_router(mockup))
