"""Domain models for the mock-UI designer.

Conventions mirror the other plugins: every model is a ``pydantic.BaseModel``;
collections use ``Field(default_factory=...)``; enum-like value sets are module-level
string lists (not ``Enum``); ids are plain ``str`` assigned by storage. A mockup is a
document you edit and save — there is nothing to execute.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

# Widget kinds. Phase 2 ships the core set; phase 3 adds the richer ones. The backend
# never dispatches on these (props are schema-less) — the list is documentation + the
# seed for the frontend palette catalog.
WIDGET_TYPES = [
    # ── core (phase 2) ──
    "label", "heading", "button", "textinput", "textarea", "checkbox", "radio",
    "dropdown", "link", "image", "icon", "panel", "separator",
    # ── richer (phase 3) ──
    "window", "table", "tabs", "list", "menubar", "breadcrumb", "alert",
    "accordion", "scrollbar", "tooltip", "note",
]


class Widget(BaseModel):
    id: str
    type: str                                     # one of WIDGET_TYPES
    x: float = 0
    y: float = 0
    w: float = 120
    h: float = 32
    z: int = 0                                     # stacking order
    props: dict = Field(default_factory=dict)      # schema-less: text, checked, items[], variant…
    link: str = ""                                # target screen id (flow edge); "" = none


class Screen(BaseModel):
    id: str
    project_id: str = ""
    name: str
    order: int = 0
    width: int = 1024
    height: int = 768
    start: bool = False                            # entry screen for the click-through preview
    flow_x: float = 0                              # node position in the flow view
    flow_y: float = 0
    widgets: list[Widget] = Field(default_factory=list)


class MockupProject(BaseModel):
    id: str
    name: str
    description: str = ""
    order: int = 0


class MockupConfig(BaseModel):
    grid: int = 8                                  # snap grid size (px)
    snap: bool = True
    default_width: int = 1024
    default_height: int = 768
