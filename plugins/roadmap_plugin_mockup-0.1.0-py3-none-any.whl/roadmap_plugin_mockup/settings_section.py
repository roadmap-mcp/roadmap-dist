"""The Mockups settings section (the ``mockup`` config slice + defaults)."""

from roadmap_plugin_settings import SettingsSection

from .models import MockupConfig

MOCKUP_SECTION = SettingsSection(
    id="mockup",
    label="Mockups",
    order=55,
    group="Design",
    defaults=lambda: {"mockup": MockupConfig().model_dump()},
)
