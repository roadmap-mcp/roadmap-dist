"""Mock-UI designer plugin.

Create projects and screens, edit each screen in a Balsamiq-style wireframe editor,
and wire screens into click-through flows. Self-contained: JSON storage under
``<config_dir>/mockups/`` + a ``/api/mockups`` REST surface + a workbench page.
"""
