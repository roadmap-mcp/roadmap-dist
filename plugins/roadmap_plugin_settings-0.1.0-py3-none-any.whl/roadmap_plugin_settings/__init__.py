"""Settings plugin — declares the ``roadmap.settings.sections`` extension point
and serves ``/api/settings``.

Any plugin can contribute a :class:`SettingsSection` (a config tab with its
defaults); the full config document is assembled from every contributed section,
so the settings UI is composed at runtime rather than hard-coded.
"""

from .contracts import SettingsSection, SETTINGS_SECTIONS_POINT

__all__ = ["SettingsSection", "SETTINGS_SECTIONS_POINT"]
