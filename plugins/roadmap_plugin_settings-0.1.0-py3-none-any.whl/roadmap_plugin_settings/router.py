"""The ``/api/settings`` router — assembles and persists the composed config.

Other plugins mount their own routes under ``/api/settings`` too (e.g. the Jira
plugin's ``/api/settings/test-atlassian``); FastAPI happily serves multiple
routers sharing a prefix.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from roadmap_framework import ExtensionRegistry, ConfigStore, session

from .contracts import SETTINGS_SECTIONS_POINT, SettingsSection


def _deep_merge(base: dict, overlay: dict) -> dict:
    out = dict(base)
    for k, v in overlay.items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def create_settings_router(extensions: ExtensionRegistry,
                           config: ConfigStore) -> APIRouter:
    router = APIRouter(prefix="/api/settings", tags=["settings"])

    def require_unlocked():
        if config.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    def _sections() -> list[SettingsSection]:
        secs = list(extensions.get(SETTINGS_SECTIONS_POINT))
        secs.sort(key=lambda s: (s.order, s.label))
        return secs

    def _composed_defaults() -> dict:
        doc: dict = {}
        for sec in _sections():
            if sec.defaults:
                doc = _deep_merge(doc, sec.defaults())
        return doc

    @router.get("/sections")
    def list_sections():
        """Tab metadata for the dynamic settings UI."""
        return [s.meta() for s in _sections()]

    @router.get("")
    def get_settings():
        require_unlocked()
        # composed defaults (from every contributed section) <- stored values
        return _deep_merge(_composed_defaults(), config.load_decrypted())

    @router.put("")
    def update_settings(body: dict):
        require_unlocked()
        config.save(body)
        return _deep_merge(_composed_defaults(), config.load_decrypted())

    return router
