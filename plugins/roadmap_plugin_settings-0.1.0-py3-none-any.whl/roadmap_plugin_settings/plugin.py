"""Settings plugin activator."""

from roadmap_framework import Plugin, PluginContext

from .contracts import SETTINGS_SECTIONS_POINT, SettingsSection
from .router import create_settings_router


class SettingsPlugin(Plugin):
    id = "roadmap.settings"
    name = "Settings"

    def activate(self, ctx: PluginContext) -> None:
        ctx.define_point(
            SETTINGS_SECTIONS_POINT,
            contract=SettingsSection,
            description="A configuration tab contributed by a plugin.",
        )
        ctx.add_router(create_settings_router(ctx.extensions, ctx.config))
