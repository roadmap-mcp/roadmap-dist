"""Contract for the settings extension point."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

#: Extension-point id that plugins contribute :class:`SettingsSection`s to.
SETTINGS_SECTIONS_POINT = "roadmap.settings.sections"


@dataclass
class SettingsSection:
    """A configuration tab contributed by a plugin.

    ``defaults`` returns the partial config document this section owns (e.g. the
    Jira plugin's section returns ``{"atlassian": {...defaults...}}``). The
    settings router deep-merges every section's defaults under the stored config
    so the UI always receives a fully-populated document.

    The matching *frontend* tab component is registered separately on the
    frontend ``SettingsTabRegistry`` under the same ``id``.

    ``group`` is an optional first-level heading the tab is nested under (e.g.
    ``"AI"``). Sections sharing a group label are shown together; a group's
    position is the smallest ``order`` among its members, so a later contribution
    to an existing group simply appends to the end of it. Empty ``group`` means
    the tab renders top-level (no heading).
    """

    id: str
    label: str
    order: int = 100
    group: str = ""
    defaults: Callable[[], dict] | None = None
    #: dotted sensitive paths this section owns (informational; the contributing
    #: plugin still registers them with the config store during activate).
    sensitive_fields: list[str] = field(default_factory=list)

    def meta(self) -> dict:
        return {"id": self.id, "label": self.label, "order": self.order,
                "group": self.group}
