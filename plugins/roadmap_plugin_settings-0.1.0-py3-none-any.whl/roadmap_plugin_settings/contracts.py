"""Contract for the settings extension point."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Callable

#: Extension-point id that plugins contribute :class:`SettingsSection`s to.
SETTINGS_SECTIONS_POINT = "roadmap.settings.sections"


@dataclass
class SettingsSection:
    """A configuration tab contributed by a plugin.

    ``defaults`` returns the partial config document this section owns (e.g. the
    Jira plugin's section returns ``{"atlassian": {...defaults...}}``). The
    settings router deep-merges every section's defaults under the stored config
    so the UI always receives a fully-populated document.

    The matching *frontend* tab component is registered separately on the
    frontend ``SettingsTabRegistry`` under the same ``id``.
    """

    id: str
    label: str
    order: int = 100
    defaults: Callable[[], dict] | None = None
    #: dotted sensitive paths this section owns (informational; the contributing
    #: plugin still registers them with the config store during activate).
    sensitive_fields: list[str] = field(default_factory=list)

    def meta(self) -> dict:
        return {"id": self.id, "label": self.label, "order": self.order}
