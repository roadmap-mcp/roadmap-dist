"""Branches of the knowledge base: a view in which new work is written first.

The knowledge base describes the application as it is (it was built from the
main line of its code). A new feature is analysed, designed and built before it
is part of that: while it is, what is written about it belongs to a **branch**,
much like a branch in git. A branch is opened for one unit of work (the
feature's work item), and everything written *in* it goes to the branch's
overlay instead of the knowledge base itself:

* reading in a branch sees the knowledge base **plus** the branch: a topic the
  branch added is there, one it changed reads as changed, one it removed is gone;
* reading without a branch (``main``) sees none of it;
* when the work is done the branch is **merged**: its changes are applied to
  the knowledge base and the overlay is emptied. Or it is **abandoned**.

The overlay lives in the workspace's store (``branch_nodes`` / ``branch_links``,
see :mod:`.store`). Which view a call reads and writes is the
:data:`current_branch` context variable: the HTTP API sets it from the
``X-Roadmap-KB-Branch`` header (or ``?branch=``), the MCP tools from their
``branch`` argument. Empty is main.

The work breakdown itself stays shared: moving a work item to another state is
written where the item lives, so a feature's progress shows on main while its
content is still in the branch.
"""

from __future__ import annotations

import contextvars
import difflib
import re
from contextlib import contextmanager
from typing import Iterator

from .models import DIAGRAMS, DocSection, document_markdown, slugify, utc_now

#: the branch the current call reads and writes; empty is main
current_branch: contextvars.ContextVar[str] = contextvars.ContextVar(
    "kb_branch", default="")

#: the HTTP header (and query parameter ``branch``) that selects a branch
BRANCH_HEADER = "X-Roadmap-KB-Branch"

_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")


@contextmanager
def on_branch(branch: str) -> Iterator[None]:
    """Run the block in ``branch`` (``""`` is main)."""
    token = current_branch.set(branch or "")
    try:
        yield
    finally:
        current_branch.reset(token)


class Branches:
    """The branches of the current workspace, over the knowledge base's store."""

    def __init__(self, kb) -> None:
        self.kb = kb

    # ── reading ───────────────────────────────────────────────────────────────

    def list(self, status: str = "") -> list[dict]:
        return [self._describe(b) for b in self.kb.store.branches(status)]

    def get(self, branch_id: str) -> dict:
        return self._describe(self._require(branch_id))

    def check(self, branch_id: str) -> str:
        """``branch_id`` if it names a branch, for a caller about to view it."""
        if branch_id:
            self._require(branch_id)
        return branch_id or ""

    def diff(self, branch_id: str) -> dict:
        """What the branch changes, node by node: added, changed, removed."""
        self._require(branch_id)
        return self.kb.store.branch_diff(branch_id)

    def context(self, branch_id: str, personas: list[str] | None = None) -> str:
        """The branch as **as is → to be**: what an agent that builds the
        feature needs, and only that.

        Every topic the branch touches, grouped by persona: a new one in full
        (to be), a changed one as a diff against main (as is → to be), a
        removed one named. ``personas`` narrows it to the ones a reader needs
        (a backend developer: analysis, architecture, backend); topics of a
        type no persona owns are always in. Units of work are left out: they
        are the tracking, not the content.
        """
        b = self._require(branch_id)
        wanted = {p for p in (personas or []) if p}
        order = {p.id: i for i, p in enumerate(self.kb.personas())}
        names = {p.id: p.name or p.id for p in self.kb.personas()}
        d = self.kb.store.branch_diff(branch_id)
        entries = []
        for change in ("added", "changed", "removed"):
            for e in d[change]:
                t = self.kb.node_type(e["kind"])
                if t is not None and t.category == "work":
                    continue
                persona = t.persona if t else ""
                if wanted and persona and persona not in wanted:
                    continue
                entries.append((order.get(persona, len(order)), persona, change, e))
        entries.sort(key=lambda x: (x[0], x[3]["kind"], x[3]["title"]))

        out = [f"# {b['name']}: as is → to be", ""]
        if b.get("description"):
            out += [b["description"], ""]
        facts = [f"knowledge-base branch `{b['id']}`"]
        if b.get("work_item"):
            facts.append(f"work item `{b['work_item']}`")
        if b.get("git_branch"):
            facts.append(f"git branch `{b['git_branch']}`")
        out += ["; ".join(facts).capitalize() + ".", "",
                "Below is every topic this feature adds, changes or removes in the knowledge "
                "base, which describes the application. **As is** is the application today "
                "(main); **to be** is what it will be with the feature. A changed topic is "
                "shown as a diff: `-` lines are as is, `+` lines are to be. A new topic is "
                "shown in full. Read the rest of the knowledge base for what does not "
                f'change, with kb_read(..., branch="{b["id"]}").', ""]
        if wanted:
            out += ["Personas: " + ", ".join(names.get(p, p) for p in sorted(wanted, key=lambda p: order.get(p, 99)))
                    + " (and shared types).", ""]
        if not entries:
            return "\n".join(out + ["Nothing in this branch yet" + (" for these personas." if wanted else ".")])
        current = None
        for _, persona, change, e in entries:
            if persona != current:
                current = persona
                out += [f"## {names.get(persona, 'Shared') if persona else 'Shared'}", ""]
            label = {"added": "new", "changed": "changed", "removed": "removed"}[change]
            out += [f"### {e['title']} · {e['kind']} · {label}", f"`{e['ref']}`", ""]
            if change == "removed":
                out += ["This topic is gone in the to-be situation.", ""]
                continue
            c = self.compare(branch_id, e["ref"])
            if change == "added":
                # its own headings under the context's: ``###`` is the topic
                text = self._text(self._node_in(branch_id, e["ref"]), level=4)
                out += [text.split("\n", 1)[1].strip() if "\n" in text else "", ""]
            else:
                out += ["```diff"] + _hunks(c["lines"]) + ["```", ""]
        return "\n".join(out)

    def _node_in(self, branch_id: str, ref: str):
        with on_branch(branch_id):
            return self.kb.store.get_node(*ref.split("/", 2))

    def compare(self, branch_id: str, ref: str) -> dict:
        """One node on main beside the same node in the branch.

        ``lines`` is a line diff of the two as text (title, fields, body, the
        document as markdown, diagrams as their source): ``" "`` same, ``"-"``
        only on main, ``"+"`` only in the branch. ``diagrams`` pairs every
        diagram or sketch that differs, by section, so a viewer can draw the
        two side by side instead of diffing their source.
        """
        self._require(branch_id)
        ref = self.kb.ref(ref)
        parts = ref.split("/", 2)
        if len(parts) != 3 or not all(parts):
            raise ValueError(f"`{ref}` is not a node ref (source/kind/id).")
        with on_branch(""):
            main = self.kb.store.get_node(*parts)
        with on_branch(branch_id):
            mine = self.kb.store.get_node(*parts)
        if main is None and mine is None:
            raise LookupError(f"No node `{ref}` on main or in branch `{branch_id}`.")
        change = ("added" if main is None else "removed" if mine is None
                  else "changed" if mine.branch_change == "changed" else "")
        a, b = self._text(main), self._text(mine)
        return {
            "ref": ref, "branch": branch_id, "change": change,
            "main": main.model_dump() if main else None,
            "branch_node": mine.model_dump() if mine else None,
            "lines": _line_diff(a, b),
            "diagrams": _diagram_pairs(main, mine),
        }

    def _text(self, node, level: int = 2) -> str:
        """A node as the text a diff compares: what a reader would see."""
        if node is None:
            return ""
        out = [f"# {node.title or node.id}"]
        content = node.content
        if content is not None:
            t = self.kb.node_type(node.kind)
            labels = {f.name: (f.label or f.name) for f in (t.fields if t else [])}
            for k, v in content.fields.items():
                if str(v).strip():
                    out.append(f"- **{labels.get(k, k)}**: {v}")
            if content.body.strip():
                out += ["", content.body.strip()]
            if content.document:
                out += ["", document_markdown(content.document, level)]
        return "\n".join(out)

    def _require(self, branch_id: str) -> dict:
        b = self.kb.store.branch(branch_id)
        if b is None:
            known = ", ".join(x["id"] for x in self.kb.store.branches("open")) or "none open"
            raise LookupError(f"No branch `{branch_id}` ({known}).")
        return b

    def _describe(self, b: dict) -> dict:
        out = dict(b)
        out["changes"] = self.kb.store.branch_counts(b["id"])
        out["work_state"] = None
        ref = b.get("work_item") or ""
        if ref:
            with on_branch(""):
                out["work_state"] = self.kb.work_status().get(ref)
                node = self.kb.find_node(*ref.split("/", 2)) if ref.count("/") >= 2 else None
            out["work_item_title"] = (node.title or node.id) if node else ""
        return out

    # ── the lifecycle ─────────────────────────────────────────────────────────

    def open(self, *, name: str, description: str = "", work_item: str = "",
             chat: str = "", branch_id: str = "", git_branch: str = "") -> dict:
        """Open a branch for one unit of work. The work item lives on main (it is
        the work breakdown that tracks the branch), so it must exist there."""
        name = (name or "").strip()
        work_item = self.kb.ref(work_item)
        if not name:
            raise ValueError("A branch needs a name: the feature it is for.")
        bid = (branch_id or slugify(name))[:64].strip("-")
        if not _ID.match(bid):
            raise ValueError(f"`{bid}` is not a usable branch id: lowercase letters, "
                             "digits and dashes.")
        if self.kb.store.branch(bid) is not None:
            raise ValueError(f"There is already a branch `{bid}`. Pick another name, "
                             "or work in that one.")
        if work_item:
            self._require_work_item(work_item)
        self.kb.store.create_branch({
            "id": bid, "name": name, "description": description.strip(),
            "work_item": work_item, "git_branch": git_branch.strip(), "status": "open",
            "created_at": utc_now(),
        })
        if chat:
            self.kb.chats.set_branch(chat, bid)
        return self.get(bid)

    def update(self, branch_id: str, *, name: str | None = None,
               description: str | None = None, work_item: str | None = None,
               git_branch: str | None = None) -> dict:
        self._require(branch_id)
        if work_item:
            self._require_work_item(work_item)
        self.kb.store.update_branch(branch_id, **{k: v for k, v in (
            ("name", name), ("description", description), ("work_item", work_item),
            ("git_branch", git_branch)) if v is not None})
        return self.get(branch_id)

    def of_work_item(self, ref: str) -> dict | None:
        """The open branch for a unit of work, if there is one."""
        return next((b for b in self.kb.store.branches("open") if b["work_item"] == ref), None)

    #: how many reported commits a branch keeps
    COMMITS = 100

    def add_commit(self, branch_id: str, sha: str, message: str = "", **about) -> dict:
        """Record a commit made on the branch's git branch. A commit is how the
        code's progress shows on the branch: it marks a step of the work (the
        backend done, the frontend done), not a merge."""
        b = self._require_open(branch_id)
        sha = (sha or "").strip()
        if not sha:
            raise ValueError("Which commit? Pass its hash.")
        entry = {"sha": sha, "message": (message or "").strip()[:300], "at": utc_now(),
                 **{k: v for k, v in about.items() if v}}
        commits = [c for c in b.get("commits") or [] if c.get("sha") != sha] + [entry]
        self.kb.store.update_branch(branch_id, commits=commits[-self.COMMITS:])
        return entry

    def merge(self, branch_id: str, *, force: bool = False) -> dict:
        """Apply the branch to the knowledge base and close it.

        Refused while the branch's work item is not in its last state (the
        feature is not done yet), and while main changed something the branch
        changed too since the branch copied it; ``force`` merges anyway, the
        branch's version winning.
        """
        b = self._require_open(branch_id)
        if not force:
            state = self._describe(b).get("work_state")
            if state and state["index"] < state["count"] - 1:
                raise ValueError(
                    f"The work item is still `{state['label']}`: a branch is merged when "
                    "its work is done. Move the work item to its last state first, or "
                    "merge with force.")
            conflicts = self.kb.store.branch_conflicts(branch_id)
            if conflicts:
                raise ValueError(
                    "Main changed since the branch copied these: "
                    + ", ".join(conflicts[:20])
                    + ". Look at both, then merge with force (the branch's version wins).")
        result = self.kb.store.merge_branch(branch_id)
        self.kb.store.update_branch(branch_id, status="merged", closed_at=utc_now(),
                                    summary=result)
        return {**self.get(branch_id), "merged": result}

    def abandon(self, branch_id: str) -> dict:
        """Close without merging. The overlay is kept, so it can still be read."""
        self._require_open(branch_id)
        self.kb.store.update_branch(branch_id, status="abandoned", closed_at=utc_now())
        return self.get(branch_id)

    def reopen(self, branch_id: str) -> dict:
        b = self._require(branch_id)
        if b["status"] == "merged":
            raise ValueError("A merged branch is part of the knowledge base now; "
                             "open a new branch for further work.")
        self.kb.store.update_branch(branch_id, status="open", closed_at="")
        return self.get(branch_id)

    def _require_open(self, branch_id: str) -> dict:
        b = self._require(branch_id)
        if b["status"] != "open":
            raise ValueError(f"Branch `{branch_id}` is {b['status']}.")
        return b

    def _require_work_item(self, ref: str) -> None:
        parts = ref.split("/", 2)
        with on_branch(""):
            node = self.kb.find_node(*parts) if len(parts) == 3 and all(parts) else None
        if node is None:
            raise ValueError(f"No work item `{ref}` on main. Create it first (kb_write, "
                             "without a branch), then open the branch for it.")
        t = self.kb.node_type(node.kind)
        if t is None or t.category != "work":
            raise ValueError(f"`{ref}` is not a unit of work (its type `{node.kind}` is "
                             "not a work type).")


def _line_diff(a: str, b: str) -> list[dict]:
    """``[{"op": " "|"-"|"+", "text": line}]``: ``a`` (main) to ``b`` (the branch)."""
    old, new = a.splitlines(), b.splitlines()
    out: list[dict] = []
    for tag, i1, i2, j1, j2 in difflib.SequenceMatcher(None, old, new, autojunk=False).get_opcodes():
        if tag == "equal":
            out += [{"op": " ", "text": t} for t in old[i1:i2]]
            continue
        out += [{"op": "-", "text": t} for t in old[i1:i2]]
        out += [{"op": "+", "text": t} for t in new[j1:j2]]
    return out


def _diagrams(node) -> dict:
    """Every diagram of a node's document, keyed by where it is: the section
    path, its type, and which one of that type in the section it is."""
    out: dict = {}

    def walk(blocks, path):
        seen: dict = {}
        for blk in blocks:
            if isinstance(blk, DocSection):
                walk(blk.children, path + [blk.title])
            elif blk.type in DIAGRAMS and blk.text.strip():
                n = seen[blk.type] = seen.get(blk.type, 0) + 1
                out[(" › ".join(path), blk.type, n)] = blk.text.strip()

    if node is not None and node.content is not None:
        walk(node.content.document, [])
    return out


def _diagram_pairs(main, mine) -> list[dict]:
    """The diagrams that differ, main's source beside the branch's."""
    a, b = _diagrams(main), _diagrams(mine)
    keys = list(a) + [k for k in b if k not in a]
    return [{"section": k[0], "type": k[1], "main": a.get(k, ""), "branch": b.get(k, "")}
            for k in keys if a.get(k, "") != b.get(k, "")]


def _hunks(lines: list[dict], around: int = 2) -> list[str]:
    """A line diff as unified-diff lines: the changes with ``around`` lines of
    context, the long unchanged stretches between them folded to ``…``."""
    changed = [i for i, l in enumerate(lines) if l["op"] != " "]
    near = {j for i in changed for j in range(i - around, i + around + 1)}
    out: list[str] = []
    gap = False
    for i, l in enumerate(lines):
        if i in near:
            out.append(f"{l['op']} {l['text']}")
            gap = False
        elif not gap:
            out.append("  …")
            gap = True
    return out
