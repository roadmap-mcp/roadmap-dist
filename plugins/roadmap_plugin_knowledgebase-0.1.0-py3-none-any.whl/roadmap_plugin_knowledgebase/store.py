"""The ground layer's store — stdlib ``sqlite3``, one file per workspace.

Layer 1 is a graph: **nodes** (a ticket, a page, a commit, a file) and **links**
between them, plus a small **ingest_runs** log so the settings page can say when a
source was last read and how it went.

Deliberately boring: no ORM, no migrations, `CREATE TABLE IF NOT EXISTS` on every
open. Everything source-specific lives in a JSON ``details`` column, so a new
source never changes the schema. A prototype does not need more, and this can be
swapped behind a persistence extension point later the way gitmining does it.
"""

from __future__ import annotations

import json
import sqlite3
from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

from .branches import current_branch
from .spaces import LEGACY_SOURCE, current_id as current_space_id, current_space
from .models import (FlowRun, GroundLink, GroundNode, IngestRun, NodeContent,
                     OrchestrationInstance, utc_now)

_SCHEMA = """
CREATE TABLE IF NOT EXISTS nodes (
    source      TEXT NOT NULL,
    kind        TEXT NOT NULL,
    id          TEXT NOT NULL,
    title       TEXT,
    uri         TEXT,
    updated_at  TEXT,
    ingested_at TEXT,
    details     TEXT,
    content     TEXT,          -- json: what a *content* node owns; null for a pointer
    PRIMARY KEY (source, kind, id)
);
CREATE INDEX IF NOT EXISTS ix_nodes_source ON nodes (source, kind);

CREATE TABLE IF NOT EXISTS links (
    src_source TEXT NOT NULL, src_kind TEXT NOT NULL, src_id TEXT NOT NULL,
    dst_source TEXT NOT NULL, dst_kind TEXT NOT NULL, dst_id TEXT NOT NULL,
    kind       TEXT NOT NULL,
    attributes TEXT,
    PRIMARY KEY (src_source, src_kind, src_id, dst_source, dst_kind, dst_id, kind)
);
CREATE INDEX IF NOT EXISTS ix_links_src ON links (src_source, src_kind, src_id);
CREATE INDEX IF NOT EXISTS ix_links_dst ON links (dst_source, dst_kind, dst_id);

CREATE TABLE IF NOT EXISTS ingest_runs (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    source      TEXT NOT NULL,
    started_at  TEXT,
    finished_at TEXT,
    status      TEXT,
    nodes       INTEGER DEFAULT 0,
    links       INTEGER DEFAULT 0,
    message     TEXT
);
CREATE INDEX IF NOT EXISTS ix_runs_source ON ingest_runs (source, id DESC);

CREATE TABLE IF NOT EXISTS flow_runs (
    id            TEXT PRIMARY KEY,
    flow_id       TEXT NOT NULL,
    flow_version  INTEGER DEFAULT 0,
    prompt_version INTEGER DEFAULT 0,
    trigger       TEXT,           -- json: how it was started
    work_item     TEXT,
    source_position TEXT,
    progress      TEXT,           -- json: the stages reported, oldest first
    started_at    TEXT,
    finished_at   TEXT,
    status        TEXT,
    nodes         INTEGER DEFAULT 0,
    links         INTEGER DEFAULT 0,
    message       TEXT
);
CREATE INDEX IF NOT EXISTS ix_flow_runs ON flow_runs (flow_id, started_at DESC);

CREATE TABLE IF NOT EXISTS orchestration_instances (
    id            TEXT PRIMARY KEY,
    orchestration TEXT NOT NULL,
    subject       TEXT,           -- the unit of work (source/kind/id), or empty
    branch        TEXT,           -- the knowledge-base branch it works in
    state         TEXT,
    status        TEXT,
    run           TEXT,           -- the open run of the state's flow, if any
    message       TEXT,
    history       TEXT,           -- json: every state entered and signal received
    created_at    TEXT,
    updated_at    TEXT
);
CREATE INDEX IF NOT EXISTS ix_orch_instances ON orchestration_instances (orchestration, created_at);

CREATE TABLE IF NOT EXISTS chats (
    id          TEXT PRIMARY KEY,   -- the short code the AI joins with
    title       TEXT,
    focus       TEXT,               -- the node it was opened from, if any
    created_at  TEXT,
    ai_seen_at  TEXT,               -- the AI's last call: is it connected
    ai_cursor   INTEGER DEFAULT 0,  -- the last message the AI has been given
    ai_joined   INTEGER DEFAULT 0,
    closed      INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS chat_messages (
    chat   TEXT NOT NULL,
    seq    INTEGER NOT NULL,
    at     TEXT,
    role   TEXT,                    -- user | assistant | system
    text   TEXT,
    items  TEXT,                    -- json: the pieces of the knowledge base shown
    PRIMARY KEY (chat, seq)
);

CREATE TABLE IF NOT EXISTS branches (
    id          TEXT PRIMARY KEY,
    name        TEXT,
    description TEXT,
    work_item   TEXT,               -- the unit of work it is for (source/kind/id)
    git_branch  TEXT,               -- the branch of the code the work is done in
    commits     TEXT,               -- json: commits reported on it, oldest first
    status      TEXT,               -- open | merged | abandoned
    created_at  TEXT,
    closed_at   TEXT,
    summary     TEXT                -- json: what the merge applied
);
-- A branch's overlay: what was written in it. A row stands in for the node of
-- the same key on main (``base_at`` is when main's row was written, null if
-- main had none: the branch added it); ``deleted`` hides it in the branch.
CREATE TABLE IF NOT EXISTS branch_nodes (
    branch      TEXT NOT NULL,
    source      TEXT NOT NULL,
    kind        TEXT NOT NULL,
    id          TEXT NOT NULL,
    title       TEXT,
    uri         TEXT,
    updated_at  TEXT,
    ingested_at TEXT,
    details     TEXT,
    content     TEXT,
    deleted     INTEGER DEFAULT 0,
    base_at     TEXT,
    PRIMARY KEY (branch, source, kind, id)
);
CREATE TABLE IF NOT EXISTS branch_links (
    branch     TEXT NOT NULL,
    src_source TEXT NOT NULL, src_kind TEXT NOT NULL, src_id TEXT NOT NULL,
    dst_source TEXT NOT NULL, dst_kind TEXT NOT NULL, dst_id TEXT NOT NULL,
    kind       TEXT NOT NULL,
    attributes TEXT,
    deleted    INTEGER DEFAULT 0,
    PRIMARY KEY (branch, src_source, src_kind, src_id, dst_source, dst_kind, dst_id, kind)
);
"""

_NODE_COLS = "source, kind, id, title, uri, updated_at, ingested_at, details, content"
_LINK_COLS = "src_source, src_kind, src_id, dst_source, dst_kind, dst_id, kind, attributes"

#: What every read queries: ``v_nodes`` and ``v_links``, the graph as the current
#: view sees it, each row with a ``branch_change`` ('' on main, else ``added`` or
#: ``changed``). The branch is the connection's ``kb_branch()`` function, so the
#: same SQL serves main and every branch without threading parameters through.
_MAIN_VIEW = f"""WITH
v_nodes AS (SELECT {_NODE_COLS}, '' AS branch_change FROM nodes),
v_links AS (SELECT {_LINK_COLS}, '' AS branch_change FROM links)
"""
_BRANCH_VIEW = f"""WITH
dead AS (SELECT source, kind, id FROM branch_nodes WHERE branch = kb_branch() AND deleted = 1),
v_nodes AS (
  SELECT {_NODE_COLS}, CASE WHEN base_at IS NULL THEN 'added' ELSE 'changed' END AS branch_change
    FROM branch_nodes WHERE branch = kb_branch() AND deleted = 0
  UNION ALL
  SELECT {', '.join('n.' + c.strip() for c in _NODE_COLS.split(','))}, '' FROM nodes n
   WHERE NOT EXISTS (SELECT 1 FROM branch_nodes b WHERE b.branch = kb_branch()
                       AND b.source = n.source AND b.kind = n.kind AND b.id = n.id)),
v_links AS (
  SELECT {_LINK_COLS}, 'added' AS branch_change
    FROM branch_links WHERE branch = kb_branch() AND deleted = 0
  UNION ALL
  SELECT {', '.join('l.' + c.strip() for c in _LINK_COLS.split(','))}, '' FROM links l
   WHERE NOT EXISTS (SELECT 1 FROM branch_links b WHERE b.branch = kb_branch()
                       AND b.src_source = l.src_source AND b.src_kind = l.src_kind
                       AND b.src_id = l.src_id AND b.dst_source = l.dst_source
                       AND b.dst_kind = l.dst_kind AND b.dst_id = l.dst_id AND b.kind = l.kind)
     AND NOT EXISTS (SELECT 1 FROM dead d WHERE d.source = l.src_source
                       AND d.kind = l.src_kind AND d.id = l.src_id)
     AND NOT EXISTS (SELECT 1 FROM dead d WHERE d.source = l.dst_source
                       AND d.kind = l.dst_kind AND d.id = l.dst_id))
"""

_LINK_KEY = ("src_source", "src_kind", "src_id", "dst_source", "dst_kind", "dst_id", "kind")


def _dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _loads(text, default):
    if not text:
        return default
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default


class GroundStore:
    """The ground-truth graph for one workspace."""

    def __init__(self, path: Path) -> None:
        self._path = Path(path)

    @property
    def path(self) -> Path:
        return self._path

    @contextmanager
    def _open(self) -> Iterator[sqlite3.Connection]:
        """A connection that commits *and* closes.

        ``with sqlite3.connect(...) as conn`` only commits — it leaves the handle
        open, and on Windows an open handle keeps the file locked.
        """
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        branch = current_branch.get()
        conn.create_function("kb_branch", 0, lambda: branch, deterministic=True)
        try:
            with conn:
                yield conn
        finally:
            conn.close()

    def init(self) -> None:
        """Create the schema if it is not there, and add columns a newer version
        needs. Safe to call on every startup.

        ``CREATE TABLE IF NOT EXISTS`` does nothing to a table that already exists,
        so a column added later needs its own ``ALTER`` — cheaper than a migration
        framework, and enough while the shape is still moving.
        """
        with self._open() as conn:
            conn.executescript(_SCHEMA)
            have = {r["name"] for r in conn.execute("PRAGMA table_info(nodes)")}
            if "content" not in have:
                conn.execute("ALTER TABLE nodes ADD COLUMN content TEXT")
            runs = {r["name"] for r in conn.execute("PRAGMA table_info(flow_runs)")}
            if runs and "source_position" not in runs:
                conn.execute("ALTER TABLE flow_runs ADD COLUMN source_position TEXT")
            if runs and "progress" not in runs:
                conn.execute("ALTER TABLE flow_runs ADD COLUMN progress TEXT")
            for table, col in (("chats", "branch"), ("orchestration_instances", "branch"),
                               ("branches", "git_branch"), ("branches", "commits"),
                               *((t, "space") for t in self._SPACED)):
                cols = {r["name"] for r in conn.execute(f"PRAGMA table_info({table})")}
                if cols and col not in cols:
                    conn.execute(f"ALTER TABLE {table} ADD COLUMN {col} TEXT")

    #: the records that belong to one space (a flow's runs, an orchestration's
    #: instances, a branch, a chat); listing them lists the current space's
    _SPACED = ("flow_runs", "orchestration_instances", "branches", "chats")

    #: where a ref (``source/kind/id``) or a node's source is kept, for
    #: :meth:`adopt_legacy`: (table, column, whole value or a ref inside json)
    _REF_COLUMNS = (
        ("nodes", "source", "source"), ("links", "src_source", "source"),
        ("links", "dst_source", "source"), ("branch_nodes", "source", "source"),
        ("branch_links", "src_source", "source"), ("branch_links", "dst_source", "source"),
        ("ingest_runs", "source", "source"),
        ("flow_runs", "work_item", "ref"), ("orchestration_instances", "subject", "ref"),
        ("branches", "work_item", "ref"), ("chats", "focus", "ref"),
        ("nodes", "details", "json"), ("branch_nodes", "details", "json"),
        ("links", "attributes", "json"), ("branch_links", "attributes", "json"),
        ("flow_runs", "trigger", "json"), ("orchestration_instances", "history", "json"),
        ("chat_messages", "items", "json"),
    )

    def adopt_legacy(self, space: str) -> bool:
        """Move a knowledge base from before spaces into ``space``, once: what was
        written under ``manual`` (and every ref to it) becomes the space's, and
        the runs, instances, branches and chats that belong to no space yet
        become its too. True when there was anything to move."""
        prefix = LEGACY_SOURCE + "/"
        with self._open() as conn:
            legacy = conn.execute("SELECT 1 FROM nodes WHERE source = ? LIMIT 1",
                                  (LEGACY_SOURCE,)).fetchone() is not None
            unspaced = any(conn.execute(f"SELECT 1 FROM {t} WHERE space IS NULL "
                                        "OR space = '' LIMIT 1").fetchone()
                           for t in self._SPACED)
            if not legacy and not unspaced:
                return False
            if legacy:
                for table, col, how in self._REF_COLUMNS:
                    if how == "source":
                        conn.execute(f"UPDATE OR IGNORE {table} SET {col} = ? WHERE {col} = ?",
                                     (space, LEGACY_SOURCE))
                    elif how == "ref":
                        conn.execute(f"UPDATE {table} SET {col} = ? || substr({col}, ?) "
                                     f"WHERE {col} LIKE ?",
                                     (space + "/", len(prefix) + 1, prefix + "%"))
                    else:   # a ref as a json string value
                        conn.execute(f"UPDATE {table} SET {col} = replace({col}, ?, ?) "
                                     f"WHERE {col} LIKE ?",
                                     ('"' + prefix, '"' + space + "/", '%"' + prefix + "%"))
            for t in self._SPACED:
                conn.execute(f"UPDATE {t} SET space = ? WHERE space IS NULL OR space = ''",
                             (space,))
        return True

    @staticmethod
    def _space_filter() -> str:
        """The space a listing is for: the call's, when it names one. Background
        work (no request) names none and sees every space's, which is how an
        orchestration worker finds the instances of all of them."""
        return current_space.get()

    # ── the view ──────────────────────────────────────────────────────────────

    @staticmethod
    def _branch() -> str:
        return current_branch.get()

    def _view(self) -> str:
        """The ``WITH`` that defines ``v_nodes`` / ``v_links`` for the current view."""
        return _BRANCH_VIEW if self._branch() else _MAIN_VIEW

    def _writable(self, conn) -> str:
        """The branch a write goes to ('' for main), checked to be open."""
        branch = self._branch()
        if branch:
            row = conn.execute("SELECT status FROM branches WHERE id = ?", (branch,)).fetchone()
            if row is None:
                raise ValueError(f"No branch `{branch}`.")
            if row["status"] != "open":
                raise ValueError(f"Branch `{branch}` is {row['status']}: it cannot be "
                                 "written to. Reopen it, or write on main.")
        return branch

    # ── writing ───────────────────────────────────────────────────────────────

    def upsert_nodes(self, nodes: list[GroundNode]) -> int:
        """Insert or refresh nodes. Re-ingesting a source updates rows in place, so
        node ids stay stable and the links pointing at them keep working."""
        if not nodes:
            return 0
        now = utc_now()
        with self._open() as conn:
            branch = self._writable(conn)
            if branch:
                for n in nodes:
                    self._branch_put(conn, branch, n, now)
                return len(nodes)
            conn.executemany(
                """INSERT INTO nodes (source, kind, id, title, uri, updated_at,
                                      ingested_at, details, content)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT (source, kind, id) DO UPDATE SET
                     title=excluded.title, uri=excluded.uri,
                     updated_at=excluded.updated_at, ingested_at=excluded.ingested_at,
                     details=excluded.details,
                     -- a write that carries no content leaves what is stored alone,
                     -- so refreshing a node's label cannot wipe what someone wrote
                     content=COALESCE(excluded.content, nodes.content)""",
                [(n.source, n.kind, n.id, n.title, n.uri, n.updated_at, now,
                  _dumps(n.details),
                  _dumps(n.content.model_dump()) if n.content is not None else None)
                 for n in nodes],
            )
        return len(nodes)

    @staticmethod
    def _branch_put(conn, branch: str, n: GroundNode, now: str) -> None:
        """Write one node into a branch's overlay. Like main, a write without
        content keeps the content already there: the branch's, else main's."""
        key = (n.source, n.kind, n.id)
        mine = conn.execute("SELECT content, base_at, deleted FROM branch_nodes WHERE branch = ? "
                            "AND source = ? AND kind = ? AND id = ?", (branch, *key)).fetchone()
        main = conn.execute("SELECT content, ingested_at FROM nodes WHERE source = ? "
                            "AND kind = ? AND id = ?", key).fetchone()
        if n.content is not None:
            content = _dumps(n.content.model_dump())
        elif mine is not None and not mine["deleted"]:
            content = mine["content"]
        else:
            content = main["content"] if main is not None else None
        base = mine["base_at"] if mine is not None else (main["ingested_at"] if main else None)
        if base is None and main is not None:
            base = main["ingested_at"] or now
        conn.execute(
            f"""INSERT OR REPLACE INTO branch_nodes (branch, {_NODE_COLS}, deleted, base_at)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0, ?)""",
            (branch, *key, n.title, n.uri, n.updated_at, now, _dumps(n.details), content, base))

    def upsert_links(self, links: list[GroundLink]) -> int:
        if not links:
            return 0
        with self._open() as conn:
            branch = self._writable(conn)
            if branch:
                conn.executemany(
                    f"""INSERT INTO branch_links (branch, {_LINK_COLS}, deleted)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
                        ON CONFLICT (branch, {', '.join(_LINK_KEY)})
                        DO UPDATE SET attributes = excluded.attributes, deleted = 0""",
                    [(branch, *self._link_key(l), _dumps(l.attributes)) for l in links])
                return len(links)
            conn.executemany(
                """INSERT INTO links (src_source, src_kind, src_id,
                                      dst_source, dst_kind, dst_id, kind, attributes)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT (src_source, src_kind, src_id, dst_source, dst_kind, dst_id, kind)
                   DO UPDATE SET attributes=excluded.attributes""",
                [(l.src_source, l.src_kind, l.src_id,
                  l.dst_source, l.dst_kind, l.dst_id, l.kind, _dumps(l.attributes))
                 for l in links],
            )
        return len(links)

    def delete_node(self, source: str, kind: str, node_id: str) -> bool:
        """Remove one node and every link that touches it. A dangling link is worse
        than a missing one — it would cite something that is not there.

        In a branch the node is hidden there instead (main keeps it until the
        branch is merged), and so are the links touching it."""
        with self._open() as conn:
            branch = self._writable(conn)
            if branch:
                key = (source, kind, node_id)
                seen = conn.execute(self._view() + "SELECT 1 FROM v_nodes WHERE source = ? "
                                    "AND kind = ? AND id = ?", key).fetchone()
                main = conn.execute("SELECT ingested_at FROM nodes WHERE source = ? AND kind = ? "
                                    "AND id = ?", key).fetchone()
                conn.execute("DELETE FROM branch_nodes WHERE branch = ? AND source = ? "
                             "AND kind = ? AND id = ?", (branch, *key))
                if main is not None:
                    conn.execute(
                        "INSERT INTO branch_nodes (branch, source, kind, id, deleted, base_at, "
                        "ingested_at) VALUES (?, ?, ?, ?, 1, ?, ?)",
                        (branch, *key, main["ingested_at"] or utc_now(), utc_now()))
                conn.execute(
                    """DELETE FROM branch_links WHERE branch = ?
                         AND ((src_source = ? AND src_kind = ? AND src_id = ?)
                           OR (dst_source = ? AND dst_kind = ? AND dst_id = ?))""",
                    (branch, *key, *key))
                return seen is not None
            cur = conn.execute(
                "DELETE FROM nodes WHERE source = ? AND kind = ? AND id = ?",
                (source, kind, node_id))
            conn.execute(
                """DELETE FROM links
                    WHERE (src_source = ? AND src_kind = ? AND src_id = ?)
                       OR (dst_source = ? AND dst_kind = ? AND dst_id = ?)""",
                (source, kind, node_id, source, kind, node_id))
            return cur.rowcount > 0

    def get_node(self, source: str, kind: str, node_id: str) -> GroundNode | None:
        with self._open() as conn:
            row = conn.execute(
                self._view() + "SELECT * FROM v_nodes WHERE source = ? AND kind = ? AND id = ?",
                (source, kind, node_id)).fetchone()
        return self._node(row) if row else None

    def in_overlay(self, source: str, kind: str, node_id: str) -> bool:
        """Whether the current branch has its own row for this node."""
        branch = self._branch()
        if not branch:
            return False
        with self._open() as conn:
            return conn.execute("SELECT 1 FROM branch_nodes WHERE branch = ? AND source = ? "
                                "AND kind = ? AND id = ?",
                                (branch, source, kind, node_id)).fetchone() is not None

    def delete_links_of_run(self, run_id: str) -> int:
        """Remove the links one run stamped (see ``KnowledgeBaseService.add_links``)."""
        with self._open() as conn:
            branch = self._writable(conn)
            if branch:
                return conn.execute(
                    "DELETE FROM branch_links WHERE branch = ? "
                    "AND json_extract(attributes, '$.provenance.run') = ?",
                    (branch, run_id)).rowcount
            cur = conn.execute(
                "DELETE FROM links WHERE json_extract(attributes, '$.provenance.run') = ?",
                (run_id,))
            return cur.rowcount

    @staticmethod
    def _link_key(link: GroundLink) -> tuple:
        return (link.src_source, link.src_kind, link.src_id,
                link.dst_source, link.dst_kind, link.dst_id, link.kind)

    def delete_link(self, link: GroundLink) -> bool:
        """Remove one relation. The nodes stay — unlinking is not deleting."""
        with self._open() as conn:
            branch = self._writable(conn)
            if branch:
                key = self._link_key(link)
                where = " AND ".join(f"{c} = ?" for c in _LINK_KEY)
                seen = conn.execute(self._view() + f"SELECT 1 FROM v_links WHERE {where}",
                                    key).fetchone()
                conn.execute(f"DELETE FROM branch_links WHERE branch = ? AND {where}",
                             (branch, *key))
                if conn.execute(f"SELECT 1 FROM links WHERE {where}", key).fetchone():
                    conn.execute(f"INSERT INTO branch_links (branch, {_LINK_COLS}, deleted) "
                                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, 1)", (branch, *key))
                return seen is not None
            cur = conn.execute(
                """DELETE FROM links
                    WHERE src_source = ? AND src_kind = ? AND src_id = ?
                      AND dst_source = ? AND dst_kind = ? AND dst_id = ? AND kind = ?""",
                (link.src_source, link.src_kind, link.src_id,
                 link.dst_source, link.dst_kind, link.dst_id, link.kind),
            )
            return cur.rowcount > 0

    def clear_source(self, source: str) -> None:
        """Drop everything ingested from one source — for a full re-ingest, or when
        a source is removed from the settings list."""
        if self._branch():
            raise ValueError("A source is cleared on main, not in a branch.")
        with self._open() as conn:
            conn.execute("DELETE FROM nodes WHERE source = ?", (source,))
            conn.execute(
                "DELETE FROM links WHERE src_source = ? OR dst_source = ?", (source, source))

    # ── ingest runs ───────────────────────────────────────────────────────────

    def start_run(self, source: str) -> int:
        with self._open() as conn:
            cur = conn.execute(
                "INSERT INTO ingest_runs (source, started_at, status) VALUES (?, ?, 'running')",
                (source, utc_now()),
            )
            return int(cur.lastrowid or 0)

    def finish_run(self, run_id: int, *, status: str = "ok", nodes: int = 0,
                   links: int = 0, message: str = "") -> None:
        with self._open() as conn:
            conn.execute(
                """UPDATE ingest_runs
                      SET finished_at = ?, status = ?, nodes = ?, links = ?, message = ?
                    WHERE id = ?""",
                (utc_now(), status, nodes, links, message, run_id),
            )

    def recent_runs(self, limit: int = 20) -> list[IngestRun]:
        with self._open() as conn:
            rows = conn.execute(
                "SELECT * FROM ingest_runs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
        return [IngestRun(**dict(r)) for r in rows]

    # ── flow runs ─────────────────────────────────────────────────────────────
    #
    # A flow run is not an ingest run: it is keyed by a string id (so a brief can
    # hand the id to an external AI before anything is written), and it records
    # which flow and which prompt version produced what.

    def start_flow_run(self, run: FlowRun) -> FlowRun:
        with self._open() as conn:
            conn.execute(
                """INSERT INTO flow_runs (id, flow_id, flow_version, prompt_version,
                                          trigger, work_item, started_at, status, space)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run.id, run.flow_id, run.flow_version, run.prompt_version,
                 _dumps(run.trigger), run.work_item, run.started_at or utc_now(),
                 run.status or "briefed", run.space or current_space_id()),
            )
        run.space = run.space or current_space_id()
        return run

    def set_run_position(self, run_id: str, position: str) -> None:
        """Record where the source stood for this run, as soon as it is known —
        before the expensive part, so a run that fails afterwards still says
        which state of the source it was looking at."""
        with self._open() as conn:
            conn.execute("UPDATE flow_runs SET source_position = ? WHERE id = ?",
                         (position, run_id))

    def add_run_progress(self, run_id: str, entry: dict) -> None:
        """Append one reported stage to a run."""
        with self._open() as conn:
            row = conn.execute("SELECT progress FROM flow_runs WHERE id = ?",
                               (run_id,)).fetchone()
            if row is None:
                return
            log = _loads(row["progress"], []) + [entry]
            conn.execute("UPDATE flow_runs SET progress = ? WHERE id = ?",
                         (_dumps(log), run_id))

    def finish_flow_run(self, run_id: str, *, status: str = "ok",
                        message: str = "") -> None:
        """Close a run and count what it actually wrote.

        The counts are read back out of the graph rather than passed in: a brief
        is written by somebody else, one ``kb_write`` call at a time, so the only
        honest answer to "what did this run produce" is to go and look.
        """
        with self._open() as conn:
            # main and every branch: a run id is unique, and a run in a branch
            # wrote into its overlay
            n = sum(conn.execute(
                f"SELECT COUNT(*) AS n FROM {t} WHERE {cond} "
                "AND json_extract(details, '$.provenance.run') = ?", (run_id,),
            ).fetchone()["n"] for t, cond in (("nodes", "1"), ("branch_nodes", "deleted = 0")))
            l = sum(conn.execute(
                f"SELECT COUNT(*) AS n FROM {t} WHERE {cond} "
                "AND json_extract(attributes, '$.provenance.run') = ?", (run_id,),
            ).fetchone()["n"] for t, cond in (("links", "1"), ("branch_links", "deleted = 0")))
            conn.execute(
                """UPDATE flow_runs
                      SET finished_at = ?, status = ?, nodes = ?, links = ?, message = ?
                    WHERE id = ?""",
                (utc_now(), status, n, l, message, run_id),
            )

    def flow_run(self, run_id: str) -> FlowRun | None:
        with self._open() as conn:
            row = conn.execute(
                "SELECT * FROM flow_runs WHERE id = ?", (run_id,)).fetchone()
        return self._flow_run(row) if row else None

    def flow_runs(self, flow_id: str = "", limit: int = 20, *,
                  work_item: str = "") -> list[FlowRun]:
        sql = "SELECT * FROM flow_runs"
        where: list[str] = []
        args: list = []
        if flow_id:
            where.append("flow_id = ?")
            args.append(flow_id)
        if work_item:
            where.append("work_item = ?")
            args.append(work_item)
        if space := self._space_filter():
            where.append("space = ?")
            args.append(space)
        if where:
            sql += " WHERE " + " AND ".join(where)
        # rowid breaks ties: two runs started in the same second keep their order
        sql += " ORDER BY started_at DESC, rowid DESC LIMIT ?"
        args.append(limit)
        with self._open() as conn:
            rows = conn.execute(sql, args).fetchall()
        return [self._flow_run(r) for r in rows]

    def nodes_of_run(self, run_id: str, limit: int = 500) -> list[GroundNode]:
        """What one run wrote — the provenance stamp read back out of the JSON."""
        with self._open() as conn:
            rows = conn.execute(
                self._view() + "SELECT * FROM v_nodes "
                "WHERE json_extract(details, '$.provenance.run') = ? "
                "ORDER BY ingested_at DESC LIMIT ?", (run_id, limit),
            ).fetchall()
        return [self._node(r) for r in rows]

    @staticmethod
    def _flow_run(row) -> FlowRun:
        return FlowRun(
            id=row["id"], flow_id=row["flow_id"],
            flow_version=row["flow_version"] or 0,
            prompt_version=row["prompt_version"] or 0,
            trigger=_loads(row["trigger"], {}), work_item=row["work_item"] or "",
            source_position=(row["source_position"]
                             if "source_position" in row.keys() else "") or "",
            progress=_loads(row["progress"] if "progress" in row.keys() else None, []),
            started_at=row["started_at"] or "", finished_at=row["finished_at"] or "",
            status=row["status"] or "", nodes=row["nodes"] or 0,
            links=row["links"] or 0, message=row["message"] or "",
            space=(row["space"] if "space" in row.keys() else "") or "",
        )

    # ── orchestration instances ───────────────────────────────────────────────
    #
    # The state of a running state machine. Kept whole on every write: an
    # instance is small, and is only ever changed by one signal at a time.

    def save_instance(self, inst: OrchestrationInstance) -> OrchestrationInstance:
        inst.updated_at = utc_now()
        inst.created_at = inst.created_at or inst.updated_at
        with self._open() as conn:
            conn.execute(
                """INSERT OR REPLACE INTO orchestration_instances
                       (id, orchestration, subject, branch, state, status, run, message,
                        history, created_at, updated_at, space)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (inst.id, inst.orchestration, inst.subject, inst.branch, inst.state, inst.status,
                 inst.run, inst.message, _dumps(inst.history), inst.created_at,
                 inst.updated_at, inst.space or current_space_id()),
            )
        inst.space = inst.space or current_space_id()
        return inst

    def instance(self, instance_id: str) -> OrchestrationInstance | None:
        with self._open() as conn:
            row = conn.execute("SELECT * FROM orchestration_instances WHERE id = ?",
                               (instance_id,)).fetchone()
        return self._instance(row) if row else None

    def instances(self, orchestration: str = "", *, status: str = "", subject: str = "",
                  run: str = "") -> list[OrchestrationInstance]:
        """Oldest first: that is the order a worker takes ready ones in."""
        where, args = [], []
        for col, val in (("orchestration", orchestration), ("status", status),
                         ("subject", subject), ("run", run), ("space", self._space_filter())):
            if val:
                where.append(f"{col} = ?")
                args.append(val)
        sql = "SELECT * FROM orchestration_instances"
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY created_at, rowid"
        with self._open() as conn:
            rows = conn.execute(sql, args).fetchall()
        return [self._instance(r) for r in rows]

    def delete_instances(self, orchestration: str) -> int:
        with self._open() as conn:
            return conn.execute("DELETE FROM orchestration_instances WHERE orchestration = ? "
                                "AND space = ?", (orchestration, current_space_id())).rowcount

    @staticmethod
    def _instance(row) -> OrchestrationInstance:
        return OrchestrationInstance(
            id=row["id"], orchestration=row["orchestration"], subject=row["subject"] or "",
            branch=(row["branch"] if "branch" in row.keys() else "") or "",
            state=row["state"] or "", status=row["status"] or "", run=row["run"] or "",
            message=row["message"] or "", history=_loads(row["history"], []),
            created_at=row["created_at"] or "", updated_at=row["updated_at"] or "",
            space=(row["space"] if "space" in row.keys() else "") or "",
        )

    # ── chats ─────────────────────────────────────────────────────────────────

    _CHAT_FIELDS = ("title", "focus", "ai_seen_at", "ai_cursor", "ai_joined", "closed",
                    "branch")

    def create_chat(self, chat: dict) -> None:
        with self._open() as conn:
            conn.execute("INSERT INTO chats (id, title, focus, created_at, space) "
                         "VALUES (?, ?, ?, ?, ?)",
                         (chat["id"], chat.get("title", ""), chat.get("focus", ""),
                          chat.get("created_at") or utc_now(), current_space_id()))

    def chat(self, chat_id: str) -> dict | None:
        with self._open() as conn:
            row = conn.execute("SELECT * FROM chats WHERE id = ?", (chat_id,)).fetchone()
        return dict(row) if row else None

    def update_chat(self, chat_id: str, **fields) -> None:
        cols = [k for k in fields if k in self._CHAT_FIELDS]
        if not cols:
            return
        with self._open() as conn:
            conn.execute(f"UPDATE chats SET {', '.join(c + ' = ?' for c in cols)} WHERE id = ?",
                         [fields[c] for c in cols] + [chat_id])

    def add_chat_message(self, chat_id: str, role: str, text: str, items: list) -> dict:
        with self._open() as conn:
            seq = conn.execute("SELECT COALESCE(MAX(seq), 0) + 1 AS n FROM chat_messages "
                               "WHERE chat = ?", (chat_id,)).fetchone()["n"]
            msg = {"seq": seq, "at": utc_now(), "role": role, "text": text, "items": items}
            conn.execute("INSERT INTO chat_messages (chat, seq, at, role, text, items) "
                         "VALUES (?, ?, ?, ?, ?, ?)",
                         (chat_id, seq, msg["at"], role, text, _dumps(items)))
        return msg

    def chat_messages(self, chat_id: str, since: int = 0) -> list[dict]:
        with self._open() as conn:
            rows = conn.execute("SELECT * FROM chat_messages WHERE chat = ? AND seq > ? "
                                "ORDER BY seq", (chat_id, since)).fetchall()
        return [{"seq": r["seq"], "at": r["at"] or "", "role": r["role"] or "",
                 "text": r["text"] or "", "items": _loads(r["items"], [])} for r in rows]

    # ── branches ──────────────────────────────────────────────────────────────
    #
    # The branch record, and its overlay read and applied as a whole. These work
    # on the branch they are given, whatever the current view is.

    _BRANCH_FIELDS = ("name", "description", "work_item", "git_branch", "commits", "status",
                      "closed_at", "summary")

    def create_branch(self, b: dict) -> None:
        with self._open() as conn:
            conn.execute("INSERT INTO branches (id, name, description, work_item, git_branch, "
                         "status, created_at, space) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                         (b["id"], b.get("name", ""), b.get("description", ""),
                          b.get("work_item", ""), b.get("git_branch", ""),
                          b.get("status", "open"), b.get("created_at") or utc_now(),
                          current_space_id()))

    def update_branch(self, branch_id: str, **fields) -> None:
        cols = [k for k in fields if k in self._BRANCH_FIELDS]
        if not cols:
            return
        values = [_dumps(fields[c]) if c in ("summary", "commits") else fields[c] for c in cols]
        with self._open() as conn:
            conn.execute(f"UPDATE branches SET {', '.join(c + ' = ?' for c in cols)} "
                         "WHERE id = ?", values + [branch_id])

    @staticmethod
    def _branch_row(row) -> dict:
        return {"id": row["id"], "name": row["name"] or row["id"],
                "description": row["description"] or "", "work_item": row["work_item"] or "",
                "git_branch": (row["git_branch"] if "git_branch" in row.keys() else "") or "",
                "commits": _loads(row["commits"] if "commits" in row.keys() else None, []),
                "status": row["status"] or "open", "created_at": row["created_at"] or "",
                "closed_at": row["closed_at"] or "", "summary": _loads(row["summary"], None),
                "space": (row["space"] if "space" in row.keys() else "") or ""}

    def branch(self, branch_id: str) -> dict | None:
        with self._open() as conn:
            row = conn.execute("SELECT * FROM branches WHERE id = ?", (branch_id,)).fetchone()
        return self._branch_row(row) if row else None

    def branches(self, status: str = "") -> list[dict]:
        where, args = [], []
        for col, val in (("status", status), ("space", self._space_filter())):
            if val:
                where.append(f"{col} = ?")
                args.append(val)
        sql = "SELECT * FROM branches" + (" WHERE " + " AND ".join(where) if where else "")
        with self._open() as conn:
            rows = conn.execute(sql + " ORDER BY created_at DESC, rowid DESC", args).fetchall()
        return [self._branch_row(r) for r in rows]

    def branch_counts(self, branch_id: str) -> dict:
        # a removal of a node main has since deleted too removes nothing
        with self._open() as conn:
            row = conn.execute(
                """SELECT SUM(b.deleted = 0 AND b.base_at IS NULL) AS added,
                          SUM(b.deleted = 0 AND b.base_at IS NOT NULL) AS changed,
                          SUM(b.deleted = 1 AND n.id IS NOT NULL) AS removed
                     FROM branch_nodes b LEFT JOIN nodes n
                       ON n.source = b.source AND n.kind = b.kind AND n.id = b.id
                    WHERE b.branch = ?""", (branch_id,)).fetchone()
            links = conn.execute(
                """SELECT SUM(deleted = 0) AS added, SUM(deleted = 1) AS removed
                     FROM branch_links WHERE branch = ?""", (branch_id,)).fetchone()
        return {"added": row["added"] or 0, "changed": row["changed"] or 0,
                "removed": row["removed"] or 0, "links_added": links["added"] or 0,
                "links_removed": links["removed"] or 0}

    def branch_diff(self, branch_id: str) -> dict:
        """The overlay, node by node, with main's title beside a change."""
        with self._open() as conn:
            rows = conn.execute(
                """SELECT b.source, b.kind, b.id, b.title, b.deleted, b.base_at,
                          b.ingested_at, n.id AS main_id, n.title AS main_title,
                          n.ingested_at AS main_at
                     FROM branch_nodes b LEFT JOIN nodes n
                       ON n.source = b.source AND n.kind = b.kind AND n.id = b.id
                    WHERE b.branch = ? ORDER BY b.ingested_at""", (branch_id,)).fetchall()
            links = conn.execute(f"SELECT {_LINK_COLS}, deleted FROM branch_links "
                                 "WHERE branch = ?", (branch_id,)).fetchall()
        out: dict = {"added": [], "changed": [], "removed": [], "links_added": [],
                     "links_removed": []}
        for r in rows:
            if r["deleted"] and r["main_id"] is None:
                continue          # main deleted it too: nothing left to remove
            entry = {"ref": f"{r['source']}/{r['kind']}/{r['id']}",
                     "title": r["title"] or r["main_title"] or r["id"], "kind": r["kind"],
                     "at": r["ingested_at"] or ""}
            if r["base_at"] is not None and r["main_at"] != r["base_at"]:
                entry["main_changed"] = True
            if r["base_at"] is None and r["main_at"] is not None:
                entry["main_changed"] = True
            out["removed" if r["deleted"] else "changed" if r["base_at"] else "added"].append(entry)
        for l in links:
            out["links_removed" if l["deleted"] else "links_added"].append({
                "src": f"{l['src_source']}/{l['src_kind']}/{l['src_id']}",
                "dst": f"{l['dst_source']}/{l['dst_kind']}/{l['dst_id']}", "kind": l["kind"]})
        return out

    def branch_conflicts(self, branch_id: str) -> list[str]:
        """Nodes main changed (or added) after the branch took its copy."""
        d = self.branch_diff(branch_id)
        return [e["ref"] for part in ("added", "changed", "removed") for e in d[part]
                if e.get("main_changed")]

    def merge_branch(self, branch_id: str) -> dict:
        """Apply a branch's overlay to main, in one transaction, and empty it."""
        now = utc_now()
        with self._open() as conn:
            rows = conn.execute("SELECT * FROM branch_nodes WHERE branch = ?",
                                (branch_id,)).fetchall()
            links = conn.execute("SELECT * FROM branch_links WHERE branch = ?",
                                 (branch_id,)).fetchall()
            done = {"added": 0, "changed": 0, "removed": 0, "links_added": 0,
                    "links_removed": 0, "nodes": []}
            for r in rows:
                key = (r["source"], r["kind"], r["id"])
                if r["deleted"]:
                    gone = conn.execute("DELETE FROM nodes WHERE source = ? AND kind = ? "
                                        "AND id = ?", key).rowcount
                    conn.execute("""DELETE FROM links
                                     WHERE (src_source = ? AND src_kind = ? AND src_id = ?)
                                        OR (dst_source = ? AND dst_kind = ? AND dst_id = ?)""",
                                 (*key, *key))
                    if gone:          # main may have deleted it already
                        done["nodes"].append("/".join(key))
                        done["removed"] += 1
                    continue
                done["nodes"].append("/".join(key))
                conn.execute(
                    f"INSERT OR REPLACE INTO nodes ({_NODE_COLS}) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)",
                    (*key, r["title"], r["uri"], r["updated_at"], now, r["details"], r["content"]))
                done["changed" if r["base_at"] else "added"] += 1
            for l in links:
                key = tuple(l[c] for c in _LINK_KEY)
                where = " AND ".join(f"{c} = ?" for c in _LINK_KEY)
                if l["deleted"]:
                    conn.execute(f"DELETE FROM links WHERE {where}", key)
                    done["links_removed"] += 1
                else:
                    conn.execute(f"INSERT OR REPLACE INTO links ({_LINK_COLS}) "
                                 "VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (*key, l["attributes"]))
                    done["links_added"] += 1
            conn.execute("DELETE FROM branch_nodes WHERE branch = ?", (branch_id,))
            conn.execute("DELETE FROM branch_links WHERE branch = ?", (branch_id,))
        done["nodes"] = done["nodes"][:200]
        return done

    # ── reading ───────────────────────────────────────────────────────────────

    def counts(self) -> dict:
        """Totals for the status panel, plus a per-source breakdown."""
        with self._open() as conn:
            v = self._view()
            nodes = conn.execute(v + "SELECT COUNT(*) AS n FROM v_nodes").fetchone()["n"]
            links = conn.execute(v + "SELECT COUNT(*) AS n FROM v_links").fetchone()["n"]
            per_source = [
                {"source": r["source"], "nodes": r["n"]}
                for r in conn.execute(
                    v + "SELECT source, COUNT(*) AS n FROM v_nodes GROUP BY source ORDER BY n DESC")
            ]
        return {"nodes": nodes, "links": links, "per_source": per_source}

    def nodes(self, *, source: str = "", kind: str = "", query: str = "",
              limit: int = 200, hide: tuple[str, ...] = ()) -> list[GroundNode]:
        """Newest first. ``limit`` 0 or less means every matching node. ``hide``
        leaves out the nodes of those sources (the other spaces)."""
        sql = self._view() + "SELECT * FROM v_nodes"
        where, args = [], []
        if source:
            where.append("source = ?")
            args.append(source)
        if hide:
            where.append(f"source NOT IN ({', '.join('?' * len(hide))})")
            args.extend(hide)
        if kind:
            where.append("kind = ?")
            args.append(kind)
        if query:
            # a prototype's "search": substring over the things a human would type
            where.append("(id LIKE ? OR title LIKE ? OR uri LIKE ? OR details LIKE ?)")
            args.extend([f"%{query}%"] * 4)
        if where:
            sql += " WHERE " + " AND ".join(where)
        sql += " ORDER BY ingested_at DESC"
        if limit > 0:
            sql += " LIMIT ?"
            args.append(limit)
        with self._open() as conn:
            rows = conn.execute(sql, args).fetchall()
        return [self._node(r) for r in rows]

    @staticmethod
    def _node(row) -> GroundNode:
        raw = _loads(row["content"], None) if "content" in row.keys() else None
        return GroundNode(
            source=row["source"], kind=row["kind"], id=row["id"], title=row["title"] or "",
            uri=row["uri"] or "", updated_at=row["updated_at"] or "",
            details=_loads(row["details"], {}),
            content=NodeContent(**raw) if isinstance(raw, dict) else None,
            branch_change=(row["branch_change"] if "branch_change" in row.keys() else "") or "",
        )

    def links(self, *, source: str = "", limit: int = 1000) -> list[GroundLink]:
        """Every link (optionally only those touching one source). The graph view
        then keeps the ones whose *both* ends are on screen. ``limit`` 0 or
        less means all of them."""
        sql = self._view() + "SELECT * FROM v_links"
        args: list = []
        if source:
            sql += " WHERE src_source = ? OR dst_source = ?"
            args.extend([source, source])
        if limit > 0:
            sql += " LIMIT ?"
            args.append(limit)
        with self._open() as conn:
            rows = conn.execute(sql, args).fetchall()
        return [self._link(r) for r in rows]

    def kinds(self) -> list[dict]:
        """Node kinds present, with counts — the graph view's filter chips."""
        with self._open() as conn:
            rows = conn.execute(
                self._view() + "SELECT kind, COUNT(*) AS n FROM v_nodes GROUP BY kind "
                "ORDER BY n DESC").fetchall()
        return [{"kind": r["kind"], "nodes": r["n"]} for r in rows]

    def links_of(self, source: str, kind: str, node_id: str) -> list[GroundLink]:
        with self._open() as conn:
            rows = conn.execute(
                self._view() + """SELECT * FROM v_links
                    WHERE (src_source = ? AND src_kind = ? AND src_id = ?)
                       OR (dst_source = ? AND dst_kind = ? AND dst_id = ?)""",
                (source, kind, node_id, source, kind, node_id),
            ).fetchall()
        return [self._link(r) for r in rows]

    @staticmethod
    def _link(row) -> GroundLink:
        return GroundLink(
            src_source=row["src_source"], src_kind=row["src_kind"], src_id=row["src_id"],
            dst_source=row["dst_source"], dst_kind=row["dst_kind"], dst_id=row["dst_id"],
            kind=row["kind"], attributes=_loads(row["attributes"], {}),
            branch_change=(row["branch_change"] if "branch_change" in row.keys() else "") or "",
        )
