"""Knowledge Base MCP tools — four tools, one per role.

* ``kb_read``   — navigate and query the graph (everyone).
* ``kb_write``  — change it: nodes and the links between them.
* ``kb_admin``  — administer it: the node types, and clearing a source.
* ``kb_flow``   — the configured paths into it: read one, take one on, report back.
* ``kb_orchestrate`` — the state machines that run flows from their outcomes:
  start one, take the next piece of work, signal a waiting state.
* ``kb_chat``   — host a chat about the knowledge base that a person opened in
  Roadmap: wait for their messages, answer, show small pieces of it.
* ``kb_branch`` — branches: open one for a new feature, see what it changes,
  merge it when the work is done. ``kb_read`` / ``kb_write`` / ``kb_flow`` take a
  ``branch`` argument to read and write in one.

Grouped by role rather than by verb so a client sees three tools instead of a
dozen, and so an agent that only needs to look things up never reads the
vocabulary for changing them. Each takes an ``action`` and the arguments that
action needs; the rest stay empty.

**A ground node is a pointer, not a copy.** Most nodes carry the minimum needed
to find the thing again in the system that owns it — source, kind, id — and
nothing else: Roadmap fetches the content from that system on demand, so the
graph cannot drift and an agent never has to read a ticket in order to record
it. The exception is a node whose ``kind`` is a configured **node type** (a
database, a web service, a test scenario). Nothing else owns those, so the
Knowledge Base does, and such a node carries its content.

No ``from __future__ import annotations`` — FastMCP introspects the real
annotations to build the tool schema.
"""

import inspect
import json

from roadmap_framework import Role, role_refusal

from . import packs, runtime
from .branches import _hunks as _branch_hunks, current_branch, on_branch
from .spaces import on_space
from .chat import GUIDE as _CHAT_GUIDE
from .models import (GroundLink, GroundNode, KbOrchestration, NodeContent, NodeType, WorkState,
                     Persona, slugify,
                     TypeField, document_markdown)


# ── argument helpers ─────────────────────────────────────────────────────────

def _obj(raw: str, arg: str) -> dict:
    """Parse a JSON-object argument, or explain what was wrong with it."""
    if not raw:
        return {}
    try:
        value = json.loads(raw)
    except json.JSONDecodeError as e:
        raise ValueError(f"{arg} is not valid JSON: {e}")
    if not isinstance(value, dict):
        raise ValueError(f"{arg} must be a JSON object")
    return value


def _need(action: str, **args) -> None:
    missing = [name for name, value in args.items() if not str(value or "").strip()]
    if missing:
        raise ValueError(f"'{action}' needs {', '.join(missing)}.")


def _unknown(action: str, actions) -> str:
    return (f"Unknown action '{action}'. Available: {', '.join(actions)}."
            if action else f"Pick an action: {', '.join(actions)}.")


# ── rendering ────────────────────────────────────────────────────────────────

def _line(node: GroundNode) -> str:
    mark = f" · {node.branch_change} in this branch" if node.branch_change else ""
    return f"- **{node.title or node.id}** (`{node.source}/{node.kind}/{node.id}`){mark}"


_BRANCH_DOC = """

``branch``: read and write in this branch of the knowledge base (see
``kb_branch``) instead of main: you see the knowledge base plus what the branch
added or changed, and what you write lands in the branch."""


def _in_branch(kb):
    """A decorator: the tool takes an optional ``branch`` and runs in it.

    Done once here rather than in every tool body. The signature FastMCP reads
    is the tool's own plus ``branch``, the way the workspace argument is added.
    """
    def wrap(fn):
        sig = inspect.signature(fn)
        param = inspect.Parameter("branch", inspect.Parameter.KEYWORD_ONLY,
                                  default="", annotation=str)

        def check(branch: str) -> str | None:
            try:
                kb.branches.check(branch)
            except LookupError as e:
                return f"Not done: {e}"
            return None

        if inspect.iscoroutinefunction(fn):
            async def wrapper(*args, branch: str = "", **kwargs):
                if err := check(branch):
                    return err
                with on_branch(branch):
                    return await fn(*args, **kwargs)
        else:
            def wrapper(*args, branch: str = "", **kwargs):
                if err := check(branch):
                    return err
                with on_branch(branch):
                    return fn(*args, **kwargs)
        wrapper.__name__, wrapper.__qualname__ = fn.__name__, fn.__qualname__
        wrapper.__module__ = fn.__module__
        wrapper.__doc__ = (fn.__doc__ or "").rstrip() + _BRANCH_DOC
        wrapper.__signature__ = sig.replace(  # type: ignore[attr-defined]
            parameters=[*sig.parameters.values(), param])
        return wrapper
    return wrap


_SPACE_DOC = """

``space``: the space of the knowledge base to work in (``kb_read("spaces")``
lists them); empty is the first, or the space of the run, branch, instance or
chat the call names. A space reads the others but writes only in its own."""


def _in_space(kb, infer=None):
    """A decorator: the tool takes an optional ``space`` and runs in it.

    ``infer(kwargs)`` gives the space when the call names none but names
    something that belongs to one (a run, a branch): what an AI was handed
    then works without it repeating the space on every call."""
    from . import runtime

    def wrap(fn):
        sig = inspect.signature(fn)
        param = inspect.Parameter("space", inspect.Parameter.KEYWORD_ONLY,
                                  default="", annotation=str)

        def resolve(space: str, kwargs: dict) -> tuple[str, str | None]:
            space = (space or "").strip()
            try:
                if not space and infer is not None:
                    space = infer(kwargs) or ""
                # any tool that works in a branch: the branch is its space's
                if not space and kwargs.get("branch"):
                    space = (kb.store.branch(kwargs["branch"]) or {}).get("space") or ""
            except Exception:   # an unknown id: the tool itself says so
                space = ""
            try:
                return runtime.require_space(space), None
            except LookupError as e:
                return "", f"Not done: {e}"

        if inspect.iscoroutinefunction(fn):
            async def wrapper(*args, space: str = "", **kwargs):
                space, err = resolve(space, kwargs)
                if err:
                    return err
                with on_space(space):
                    return await fn(*args, **kwargs)
        else:
            def wrapper(*args, space: str = "", **kwargs):
                space, err = resolve(space, kwargs)
                if err:
                    return err
                with on_space(space):
                    return fn(*args, **kwargs)
        wrapper.__name__, wrapper.__qualname__ = fn.__name__, fn.__qualname__
        wrapper.__module__ = fn.__module__
        wrapper.__doc__ = (fn.__doc__ or "").rstrip() + _SPACE_DOC
        wrapper.__signature__ = sig.replace(  # type: ignore[attr-defined]
            parameters=[*sig.parameters.values(), param])
        return wrapper
    return wrap


def _detail(node: GroundNode, kb) -> str:
    lines = [f"# {node.title or node.id}", "",
             f"`{node.source}/{node.kind}/{node.id}`"]
    if node.uri:
        lines.append(node.uri)
    if node.updated_at:
        lines.append(f"updated {node.updated_at}")

    node_type = kb.node_type(node.kind)
    content = node.content
    if node_type and content:
        lines += ["", f"## Content ({node_type.name or node_type.id})"]
        if content.body.strip():
            lines.append(content.body)
        for f in node_type.fields:
            value = content.fields.get(f.name, "")
            if str(value).strip():
                lines.append(f"- **{f.label or f.name}**: {value}")
        if content.document:
            lines += ["", document_markdown(content.document, level=3)]
    elif not node_type:
        lines += ["", "This node is a pointer — open or refresh it in Roadmap to read "
                  "what it points at; its content lives in the source system."]

    ref = {k: v for k, v in (node.details or {}).items() if k != "fetched_at"}
    if ref:
        lines += ["", "## Reference", json.dumps(ref, ensure_ascii=False)]
    return "\n".join(lines)


def _type_line(t: NodeType, kb) -> str:
    shape = (", ".join(f"{f.name}{'*' if f.required else ''}" for f in t.fields) or "no fields yet"
             if t.form == "structured" else
             ("has a template" if t.template.strip() else "free text"))
    return (f"- `{t.id}` — **{t.name or t.id}** · {t.form} ({shape}) · "
            f"{kb.count_of_kind(t.id)} node(s)")


def register_mcp_tools(mcp_service, kb) -> None:
    mcp = mcp_service.mcp

    # what a call names that belongs to one space, so it need not name the space
    def run_space(kw: dict) -> str:
        run = kw.get("run") or (kw.get("id") if str(kw.get("id") or "").startswith("run_")
                                else "")
        return kb.run_space(run) if run else ""

    def instance_space(kw: dict) -> str:
        inst = kb.store.instance(kw.get("id") or "") if kw.get("id") else None
        return inst.space if inst else ""

    def chat_space(kw: dict) -> str:
        chat = kb.store.chat(kw.get("id") or "") if kw.get("id") else None
        return (chat or {}).get("space") or ""

    def branch_space(kw: dict) -> str:
        b = kb.store.branch(kw.get("id") or "") if kw.get("id") else None
        return (b or {}).get("space") or ""

    # ── read ─────────────────────────────────────────────────────────────────

    READ = ("status", "spaces", "find", "get", "neighbours", "legacy")

    @mcp.tool()
    @_in_space(kb)
    @_in_branch(kb)
    def kb_read(action: str = "status", query: str = "", kind: str = "", source: str = "",
                id: str = "", relation: str = "", limit: int = 20,
                across: bool = False) -> str:
        """Navigate and query the Knowledge Base graph.

        Actions:

        * ``status``     — what the graph holds: counts, the sources that feed it,
          and the node types that may carry content. Start here.
        * ``spaces``     — the spaces of this knowledge base: each team's (or
          project's) own personas, node types and work breakdown, over shared
          sources.
        * ``find``       — search nodes. ``query`` matches id, title, uri and
          reference fields; narrow with ``kind`` and/or ``source``; ``limit``
          caps the result. This space's nodes and the shared sources'; with
          ``across`` the other spaces' too (read-only).
        * ``get``        — one node in full, with its content if it has any.
          Needs ``source``, ``kind``, ``id``.
        * ``neighbours`` — what a node is linked to, and how. Needs ``source``,
          ``kind``, ``id``; ``relation`` keeps only that kind of link.
        * ``legacy``     — content nodes whose long text is not in the document
          format yet (a body, or a long-text field value): what is left to
          convert. Narrow with ``kind``; ``limit`` caps the list, and the head
          line says how many there are in all.

        Nodes come back as `source/kind/id` — that triple is the address to pass
        to any other action.
        """
        try:
            if action == "status":
                st = kb.status()
                lines = [
                    "# Knowledge Base — ground layer", "",
                    f"{st['nodes']} nodes, {st['links']} links, "
                    f"{len(st['personas'])} persona(s).", "",
                ]
                if current_branch.get():
                    c = kb.branches.get(current_branch.get())["changes"]
                    lines[1:1] = ["", f"Viewing branch `{current_branch.get()}`: main plus "
                                  f"{c['added']} added, {c['changed']} changed, "
                                  f"{c['removed']} removed node(s)."]
                if len(kb.space_ids()) > 1:
                    lines[1:1] = ["", f"In space `{kb.MANUAL_SOURCE}`; "
                                  "kb_read(\"spaces\") lists the others."]
                lines += ["## Sources you can write to"]
                for s in st["sources"]:
                    lines.append(f"- `{s['id']}` — {s['label']} ({s['nodes']} nodes)")
                if not any(s["id"] == kb.MANUAL_SOURCE for s in st["sources"]):
                    lines.append(f"- `{kb.MANUAL_SOURCE}` — this space: written by hand / "
                                 "by an agent (0 nodes)")
                lines += ["", "## Node types (a node of these kinds carries content)"]
                lines += [_type_line(t, kb) for t in kb.node_types()] or ["- none configured"]
                lines += ["", "Any other kind is a pointer: give the source's own identifier "
                          "and nothing else — Roadmap fetches the content from the source."]
                return "\n".join(lines)

            if action == "spaces":
                here = kb.MANUAL_SOURCE
                per = {r["source"]: r["nodes"] for r in kb.store.counts()["per_source"]}
                lines = [f"{len(kb.space_ids())} space(s); this call is in `{here}`.", ""]
                for sp in runtime.kb_stored().spaces:
                    mark = " (this one)" if sp.id == here else ""
                    work = sum(1 for t in sp.node_types if t.category == "work")
                    lines.append(
                        f"- `{sp.id}` — **{sp.name}**{mark}: {len(sp.personas)} persona(s), "
                        f"{'a work breakdown' if work else 'no work breakdown'}, "
                        f"{per.get(sp.id, 0)} node(s)"
                        + (f" — {sp.description}" if sp.description else ""))
                lines += ["", "Pass `space=\"<id>\"` to read or write in another space; "
                          "`across=True` on find reads all of them."]
                return "\n".join(lines)

            if action == "find":
                nodes = kb.nodes(source=source, kind=kind, query=query, limit=limit,
                                 across=across)
                if not nodes:
                    where = f" in {source}" if source else ""
                    return (f"No nodes match '{query}'{where}. "
                            "kb_read(action='status') shows what the graph holds.")
                head = f"{len(nodes)} node(s)" + (f" matching '{query}'" if query else "")
                return "\n".join([head, ""] + [_line(n) for n in nodes])

            if action == "get":
                _need(action, source=source, kind=kind, id=id)
                source = kb.ref_source(source)
                node = kb.find_node(source, kind, id)
                if node is None:
                    return f"No node `{source}/{kind}/{id}`."
                if source != kb.MANUAL_SOURCE and source in kb.space_ids():
                    # another space's topic: its type is that space's; read, not written
                    with on_space(source):
                        return (_detail(node, kb) + f"\n\n(From the space `{source}`: "
                                "read-only from here; pass space=\"" + source
                                + "\" to change it.)")
                return _detail(node, kb)

            if action == "legacy":
                every = kb.legacy_nodes(kind=kind)
                if not every:
                    return ("Nothing left to convert: every content node"
                            + (f" of kind '{kind}'" if kind else "")
                            + " keeps its long text in the document format.")
                shown = every[:limit] if limit > 0 else every
                return "\n".join([f"{len(every)} node(s) still to convert"
                                  + (f", the first {len(shown)}:" if len(shown) < len(every)
                                     else ":"), ""] + [_line(n) for n in shown])

            if action == "neighbours":
                _need(action, source=source, kind=kind, id=id)
                source = kb.ref_source(source)
                if kb.find_node(source, kind, id) is None:
                    return f"No node `{source}/{kind}/{id}`."
                near = kb.neighbours(source, kind, id, relation)
                if not near:
                    return (f"`{source}/{kind}/{id}` is not linked to anything"
                            f"{f' by {relation}' if relation else ''} yet.")
                return "\n".join(
                    [f"{len(near)} link(s) from `{source}/{kind}/{id}`:", ""]
                    + [f"- {arrow} **{n.title or n.id}** (`{n.source}/{n.kind}/{n.id}`)"
                       for arrow, n in near])

            return _unknown(action, READ)
        except ValueError as e:
            return f"Not read: {e}"

    # ── write ────────────────────────────────────────────────────────────────

    WRITE = ("add_node", "update", "set_state", "delete_node", "link", "unlink")

    @mcp.tool()
    @_in_space(kb, run_space)
    @_in_branch(kb)
    def kb_write(action: str, kind: str = "", id: str = "", source: str = "",
                 title: str = "", ref_json: str = "", content_json: str = "",
                 dst_kind: str = "", dst_id: str = "", dst_source: str = "",
                 relation: str = "relates-to", run: str = "", state: str = "") -> str:
        """Change the Knowledge Base graph.

        Actions:

        * ``add_node``    — add or update a node. Needs ``kind`` and ``id``; re-using
          an id updates that node rather than adding a second one, replacing all
          of its content.
        * ``update``      — change part of a content node that already exists.
          Needs ``kind`` and ``id``; ``content_json`` holds only what changes —
          {"fields": {...}} is merged into the fields (a field set to null is
          removed), {"body": "..."} replaces the body, {"document": [...]}
          replaces the whole document — and ``title``
          replaces the title when given. Prefer it to
          ``add_node`` for a topic somebody else wrote.
        * ``set_state``   — move a unit of work to another state of its type's
          lifecycle (planned, in progress, … done — kb_admin get_type lists a
          type's states). Needs ``kind``, ``id`` and ``state``; one state at a
          time, forward or back. ``run`` records which run moved it. Flows move
          their work item themselves when a run starts and finishes, so this is
          for what they cannot know — a step found to be blocked, or done by hand.
        * ``delete_node`` — remove a node and every link that touches it. Needs
          ``source``, ``kind``, ``id``.
        * ``link``        — relate two nodes: ``kind``/``id``/``source`` is where the
          relation starts, ``dst_kind``/``dst_id``/``dst_source`` where it points,
          ``relation`` is what it is ('documented-in', 'implements', 'caused',
          'contradicts'). Both nodes should exist first.

          ``relation='contains'`` is the structural one: the source *holds* the
          destination, and it is what the explorer builds each persona's tree
          out of. Put a topic under its folder, and a unit of work under the one
          above it, with this.
        * ``unlink``      — remove that relation. The nodes stay.

        **Adding a node: identify it, do not describe it.** For anything that lives
        in another system — a ticket, a wiki page, a commit — pass the identifier
        that system uses (`kind='ticket', id='PAY-3187', source='atlassian'`) and
        stop. Do not copy across a description, a status, acceptance criteria or
        comments: Roadmap fetches those from the source, and a copy goes stale the
        moment somebody edits the original. ``ref_json`` is for extra *locating*
        fields only, e.g. {"space": "OPS"}.

        **Content nodes are the exception.** If ``kind`` is a configured node type
        (kb_read status lists them), nothing else owns the thing, so pass its
        content in ``content_json``: {"fields": {...}} for a structured type,
        {"body": "..."} for an unstructured one. The type's template is a good
        starting shape — kb_admin(action='get_type') returns it.

        **Long text goes in a document.** ``"document"`` in ``content_json`` is the
        topic as a tree a reader can find their way in: titled sections, and as
        leaves markdown fragments, e.g.
        [{"type": "section", "title": "Backend", "children": [
           {"type": "markdown", "text": "One feature package, `auth`."},
           {"type": "section", "title": "REST endpoints", "children": [
              {"type": "markdown", "text": "- POST /api/auth/sign-in ..."}]}]}]
        Every section has a title (the titles are the table of contents); write
        no headings inside a fragment — make a section instead; keep a fragment
        to a paragraph, a list or a table. A diagram is a fragment of its own,
        {"type": "plantuml", "text": "@startuml\\n...\\n@enduml"}: the whole
        source, drawn by the PlantUML server; or {"type": "mermaid", "text":
        "erDiagram\\n..."}: the source alone, no code fence, drawn in the
        browser; or {"type": "wireframe", "text": "{+\\n[Log in] | [Cancel]\\n}"}:
        a screen sketch in PlantUML Salt, drawn in the browser. Any content
        type may carry one; on a
        structured type, a long-text field may be written as a top-level section
        titled with the field's label instead of as a field value, which keeps
        the fields for the short values.

        A one-line finding or decision that exists nowhere else goes under this
        space (leave ``source`` empty) with a ``title``, linked to the ticket it
        came from. An empty ``source`` (or ``manual``) is always this space.

        **``run``** — when you are carrying out a flow (see ``kb_flow``), pass the
        run id it gave you on every ``add_node``, ``update`` and ``link`` call. It
        stamps what you write with which flow, which prompt version and what set
        the work off, which is what makes the result reviewable afterwards — and
        what lets a whole run be undone in one go if it went wrong: undo deletes
        what the run created, puts back the previous version of what it changed,
        and removes the links it made. It also links each node to the unit of
        work the run is about, so you never have to write that link yourself.
        Leave it empty for an ordinary write; ``unlink`` ignores it.
        """
        try:
            if action == "add_node":
                _need(action, kind=kind, id=id)
                content_raw = _obj(content_json, "content_json")
                node = GroundNode(
                    source=kb.ref_source(source), kind=kind, id=id, title=title,
                    details=_obj(ref_json, "ref_json"),
                    content=NodeContent(**content_raw) if content_raw else None,
                )
                provenance = kb.provenance_for(run) if run else None
                kb.add_nodes([node], provenance)
                # a node written under a run is about whatever that run is about;
                # making the writer repeat it per node would only be one more
                # thing to get wrong
                if run:
                    kb.link_run_output(run, [node])
                msg = (f"Added `{node.source}/{node.kind}/{node.id}`"
                       f"{' — ' + node.title if node.title else ''}.")
                if run and provenance is None:
                    msg += (f"\n\nNote: there is no run `{run}`, so this node carries "
                            "no provenance. Check the id kb_flow gave you.")
                bulky = [k for k, v in node.details.items()
                         if isinstance(v, str) and len(v) > 200]
                if bulky:
                    msg += ("\n\nNote: " + ", ".join(bulky) + " look like content rather "
                            "than locating fields. A pointer's content is fetched from its "
                            "source, so those can be left out.")
                elif (not kb.node_type(node.kind) and node.source != kb.MANUAL_SOURCE
                      and not kb.source_type(node.source)):
                    msg += (f"\n\nNote: '{node.source}' has no fetcher yet, so this node's "
                            "content cannot be refreshed from the source.")
                return msg

            if action == "update":
                _need(action, kind=kind, id=id)
                patch = _obj(content_json, "content_json")
                unknown = set(patch) - {"fields", "body", "document"}
                if unknown:
                    return ("Not written: content_json for update takes only "
                            "'fields', 'body' and 'document', not "
                            + ", ".join(sorted(unknown)) + ".")
                if not patch and not title:
                    return "Not written: nothing to update — pass content_json or title."
                stamp = kb.provenance_for(run) if run else None
                node = kb.update_node(kb.ref_source(source), kind, id, title=title,
                                      fields=patch.get("fields"), body=patch.get("body"),
                                      document=patch.get("document"),
                                      provenance=stamp)
                if run:
                    kb.link_run_output(run, [node])
                changed = sorted((patch.get("fields") or {}).keys())
                msg = (f"Updated `{node.source}/{node.kind}/{node.id}`"
                       + (f" — fields: {', '.join(changed)}" if changed else "")
                       + (" — body" if "body" in patch else "")
                       + (" — document" if "document" in patch else "")
                       + (" — title" if title else "") + ".")
                if run and stamp is None:
                    msg += (f"\n\nNote: there is no run `{run}`, so this change carries "
                            "no provenance. Check the id kb_flow gave you.")
                return msg

            if action == "set_state":
                _need(action, kind=kind, id=id, state=state)
                kb.set_state(kb.ref_source(source), kind, id, state,
                             by={"run": run} if run else {"by": "mcp"})
                st = kb.work_status().get(f"{kb.ref_source(source)}/{kind}/{id}", {})
                return (f"`{kind}/{id}` is now {st.get('label', state)}"
                        f" ({round(100 * st.get('progress', 0))}% along its lifecycle).")

            if action == "delete_node":
                _need(action, kind=kind, id=id)
                source = kb.ref_source(source)
                if not kb.delete_node(source, kind, id):
                    return f"No node `{source}/{kind}/{id}`."
                return f"Deleted `{source}/{kind}/{id}` and the links that touched it."

            if action in ("link", "unlink"):
                _need(action, kind=kind, id=id, dst_kind=dst_kind, dst_id=dst_id)
                link = GroundLink(
                    src_source=kb.ref_source(source), src_kind=kind, src_id=id,
                    dst_source=kb.ref_source(dst_source), dst_kind=dst_kind,
                    dst_id=dst_id, kind=relation or "relates-to",
                )
                if action == "link":
                    missing = [f"`{s}/{k}/{i}`" for s, k, i in (
                        (link.src_source, link.src_kind, link.src_id),
                        (link.dst_source, link.dst_kind, link.dst_id))
                        if kb.store.get_node(s, k, i) is None]
                    if missing:
                        return (f"Not written: no node {' or '.join(missing)}. Write both "
                                f"nodes first (add_node), then link them.")
                    stamp = kb.provenance_for(run) if run else None
                    kb.add_links([link], stamp)
                    msg = (f"Linked `{link.src_kind}/{link.src_id}` --{link.kind}--> "
                           f"`{link.dst_kind}/{link.dst_id}`.")
                    if run and stamp is None:
                        msg += (f"\n\nNote: there is no run `{run}`, so this link "
                                "carries no provenance. Check the id kb_flow gave you.")
                    return msg
                if not kb.remove_link(link):
                    return (f"No `{link.kind}` link from `{link.src_kind}/{link.src_id}` "
                            f"to `{link.dst_kind}/{link.dst_id}`.")
                return (f"Unlinked `{link.src_kind}/{link.src_id}` --{link.kind}--> "
                        f"`{link.dst_kind}/{link.dst_id}`. Both nodes stay.")

            return _unknown(action, WRITE)
        except ValueError as e:
            return f"Not written: {e}"

    # ── flows ────────────────────────────────────────────────────────────────

    FLOW = ("list", "describe", "brief", "progress", "get", "finish")

    @mcp.tool()
    @_in_space(kb, run_space)
    @_in_branch(kb)
    def kb_flow(action: str = "list", id: str = "", work_item: str = "",
                message: str = "", stage: str = "", outcome: str = "ok",
                commit: str = "") -> str:
        """Knowledge flows: the configured paths into the Knowledge Base.

        A flow says what gets read, who it is written for, and what may be
        written. Most are carried out **by you**: Roadmap hands over the prompt
        and the type contract, you do the analysis, and you write the result back
        with ``kb_write``.

        Actions:

        * ``list``     — the flows configured here.
        * ``describe`` — what one flow reads, who it writes for, which node types
          it may use, and anything that stops it running. Needs ``id`` (the flow).
        * ``brief``    — **take the flow on.** Opens a run and returns the full
          prompt: the instructions, every node type described in enough detail to
          write one, where the result goes, and the run id to stamp on it. Needs
          ``id``; ``work_item`` overrides the flow's default unit of work.
        * ``progress`` — report that the run has started one of its large
          stages: ``stage`` (one the brief lists, or a short label when it lists
          none) and a one-line ``message``. Needs ``id`` (the run). Shown,
          timestamped, on the unit of work the run is about.
        * ``get``      — what a run has produced so far. Needs ``id`` (the *run*).
        * ``finish``   — close a run you have finished, with its ``outcome``
          (``ok``, or ``failed`` when the work did not reach its goal — say what
          failed in ``message``). Needs ``id`` (the run).

        The normal sequence is ``describe`` → ``brief`` → for each stage,
        ``progress`` and write with ``kb_write`` (passing ``run``) → ``finish``.
        """
        try:
            if action == "list":
                flows = kb.flows()
                if not flows:
                    return ("No flows configured. They are set up under "
                            "Workspace settings -> Knowledge Base -> Flows.")
                lines = ["# Knowledge flows", ""]
                for f in flows:
                    issues = kb.flow_issues(f)
                    state = "ready" if not issues else f"{len(issues)} problem(s)"
                    if not f.enabled:
                        state = "disabled"
                    lines.append(f"- `{f.id}` — **{f.name or f.id}** · {f.kind} · {state}")
                    if f.description.strip():
                        lines.append(f"  {f.description.strip()}")
                lines += ["", "`kb_flow(\"describe\", id=...)` for one of them."]
                return "\n".join(lines)

            if action == "describe":
                _need(action, id=id)
                flow = kb.require_flow(id)
                auds = kb.flow_personas(flow)
                types = kb.flow_types(flow)
                lines = [f"# {flow.name or flow.id}", ""]
                if flow.description.strip():
                    lines += [flow.description.strip(), ""]
                lines += [
                    f"- **kind**: {flow.kind}",
                    f"- **reads**: {kb.flow_source_label(flow)}",
                    "- **writes for**: " + (", ".join(a.name for a in auds) or "nobody yet"),
                    "- **may write**: " + (", ".join(f"`{t.id}`" for t in types) or "nothing"),
                    f"- **about**: {flow.work_item.ref() or '(given per run)'}"
                    f" via a `{flow.work_item.relation}` link",
                    f"- **prompt version**: {flow.prompt.version}",
                    f"- **started by**: {', '.join(flow.triggers)}",
                ]
                issues = kb.flow_issues(flow)
                if issues:
                    lines += ["", "## Not ready", ""] + [f"- {i}" for i in issues]
                lines += ["", "`kb_flow(\"brief\", id=\"" + flow.id
                          + "\")` to take it on."]
                return "\n".join(lines)

            if action == "brief":
                _need(action, id=id)
                flow = kb.require_flow(id)
                if not flow.enabled:
                    return f"Flow `{flow.id}` is disabled."
                issues = kb.flow_issues(flow, work_item=work_item)
                if issues:
                    return ("Not ready:\n" + "\n".join(f"- {i}" for i in issues)
                            + "\n\nFix it under Workspace settings -> Knowledge Base -> Flows.")
                out = kb.brief(flow, {"mode": "mcp", "tool": "kb_flow"},
                               work_item=work_item)
                run_id = out["run"]["id"]
                return (f"Run `{run_id}` is open. Pass `run=\"{run_id}\"` on every "
                        f"kb_write add_node call, then `kb_flow(\"finish\", "
                        f"id=\"{run_id}\")`.\n\n---\n\n" + out["prompt"])

            if action == "progress":
                _need(action, id=id)
                entry = kb.report_progress(id, stage=stage, message=message)
                where = (f"stage {entry['index']}/{entry['count']} "
                         if entry["count"] else "")
                return (f"Noted at {entry['at']}: {where}**{entry['label'] or '…'}**"
                        + (f" — {message}" if message else "") + ".")

            if action == "get":
                _need(action, id=id)
                run = kb.store.flow_run(id)
                if run is None:
                    return f"No run `{id}`."
                nodes = kb.store.nodes_of_run(id)
                lines = [f"# Run `{run.id}`", "",
                         f"- **flow**: `{run.flow_id}` (v{run.flow_version}, "
                         f"prompt v{run.prompt_version})",
                         f"- **started**: {run.started_at} by {run.trigger.get('mode', '?')}",
                         f"- **status**: {run.status}",
                         f"- **about**: {run.work_item or '(nothing)'}",
                         f"- **wrote**: {len(nodes)} node(s)"]
                if run.message:
                    lines.append(f"- **note**: {run.message}")
                if run.progress:
                    lines += ["", "## Progress", ""] + [
                        f"- {p.get('at', '')} — {p.get('label') or p.get('stage') or '…'}"
                        + (f": {p['message']}" if p.get("message") else "")
                        for p in run.progress]
                if nodes:
                    lines += ["", "## Written", ""] + [_line(n) for n in nodes]
                return "\n".join(lines)

            if action == "finish":
                _need(action, id=id)
                if kb.store.flow_run(id) is None:
                    return f"No run `{id}`."
                if outcome not in ("ok", "failed"):
                    return "Not done: `outcome` is `ok` or `failed`."
                if outcome == "failed" and not message.strip():
                    return ("Not done: a failed run needs a `message` saying what "
                            "failed — the next run starts from it.")
                noted = ""
                if commit.strip():
                    # recorded before the run closes: closing it may move the
                    # machine on to a merge, which closes the branch
                    in_branch = kb.run_branch(id)
                    if in_branch:
                        run = kb.store.flow_run(id)
                        kb.branches.add_commit(in_branch, commit, message, run=id,
                                               flow=run.flow_id if run else "")
                        noted = f" Commit `{commit.strip()[:12]}` recorded on branch `{in_branch}`."
                    message = (message + f" (commit {commit.strip()[:12]})").strip()
                kb.finish_run(id, status=outcome, message=message)
                done = kb.store.flow_run(id)
                moved = ""
                parts = (done.work_item or "").split("/", 2)
                if len(parts) == 3 and all(parts):
                    node = kb.store.get_node(*parts)
                    state = ((node.details or {}).get("state") or {}).get("value") if node else ""
                    if state:
                        moved = f" `{done.work_item}` is now at `{state}`."
                # the instance has moved on (and let go of the run) by now, so
                # it is found from the run's trigger, not its current run
                iid = (done.trigger or {}).get("instance")
                i = kb.store.instance(iid) if iid else None
                orch = ""
                if i is not None:
                    orch = (f"\n\nOrchestration `{i.orchestration}`"
                            + (f" for `{i.subject}`" if i.subject else "")
                            + f" is now at `{i.state}` ({i.status})"
                            + (f": {i.message}" if i.message else "") + ". "
                            '`kb_orchestrate("next")` for the next piece of work.')
                return (f"Run `{id}` closed as {outcome} — {done.nodes} node(s) carry "
                        f"its provenance.{moved}{noted}{orch}")

            return _unknown(action, FLOW)
        except LookupError as e:
            return f"Not done: {e}"
        except ValueError as e:
            return f"Not done: {e}"

    # ── orchestration ────────────────────────────────────────────────────────

    ORCH = ("list", "describe", "save", "delete", "start", "next", "status",
            "signal", "retry", "cancel", "clear")

    def _inst_line(i) -> str:
        return (f"- `{i.id}` · {i.subject or '(project)'}"
                + (f" · branch `{i.branch}`" if i.branch else "")
                + f" · **{i.state}** · {i.status}"
                + (f" · run `{i.run}`" if i.run else "")
                + (f" — {i.message}" if i.message else ""))

    @mcp.tool()
    @_in_space(kb, instance_space)
    def kb_orchestrate(action: str = "list", id: str = "", subject: str = "",
                       signal: str = "", message: str = "",
                       orchestration_json: str = "", branch: str = "") -> str:
        """Orchestrations: state machines that run the knowledge flows from their
        outcomes. A flow ends ``ok`` or ``failed``; the orchestration decides what
        comes next ("testing failed: back to development"). ``single`` runs once
        for the project; ``each`` runs one instance per unit of work of a type.

        Actions:

        * ``list``     — the orchestrations, with how many instances are where.
        * ``describe`` — one in full: states (and the flow each runs),
          transitions, a Mermaid diagram, problems. Needs ``id``.
        * ``save``     — create or replace one from ``orchestration_json``:
          ``{"id", "name", "description", "mode": "single"|"each",
          "subject_type", "initial", "max_visits",
          "states": [{"id", "label", "flow", "final", "merge_branch"}],
          "transitions": [{"state", "on", "to"}]}``. ``on`` is ``ok``,
          ``failed``, ``error`` or a word for a waiting state; ``state`` ``*``
          matches every state.
        * ``delete``   — remove one (and its instances). Needs ``id``.
        * ``start``    — create instances in the initial state. Needs ``id``;
          ``subject`` (``source/kind/id``) for one unit of work. ``each`` without
          a subject starts every unit of work that has no instance yet. An
          instance works in the open knowledge-base branch of its unit of work
          (its runs read and write there, and name the branch's git branch);
          ``branch`` picks another one, ``branch="main"`` forces main. A state
          with ``merge_branch`` merges that branch into main on entry: make it
          the final state after the step that merged the code.
        * ``next``     — **take the next piece of work**: opens the run of the
          oldest ready instance's flow and returns its brief. Optional ``id``
          narrows it to one orchestration. Do the work, finish the run with
          ``kb_flow("finish", outcome=...)``, and call ``next`` again until it
          says nothing is ready.
        * ``status``   — the instances (optional ``id``): state, status, run.
        * ``signal``   — send ``signal`` (and ``message``) to instance ``id``,
          for a state that waits for a person or an agent.
        * ``retry``    — put a stuck instance back in its state. Needs ``id``.
        * ``cancel``   — stop instance ``id``.
        * ``clear``    — forget every instance of orchestration ``id``.
        """
        orch = kb.orchestrator
        try:
            if action == "list":
                found = orch.orchestrations()
                if not found:
                    return ("No orchestrations configured. Save one with "
                            '`kb_orchestrate("save", orchestration_json=...)` or '
                            "under Workspace settings -> Knowledge Base -> Orchestration.")
                lines = ["# Orchestrations", ""]
                for o in found:
                    sm = orch.summary(o)
                    issues = orch.issues(o)
                    state = ("disabled" if not o.enabled else
                             f"{len(issues)} problem(s)" if issues else "ready")
                    counts = ", ".join(f"{n} {k}" for k, n in sm["by_status"].items())
                    lines.append(f"- `{o.id}` — **{o.name or o.id}** · {o.mode}"
                                 + (f" over `{o.subject_type}`" if o.mode == "each" else "")
                                 + f" · {state} · instances: {counts or 'none'}")
                    if o.description.strip():
                        lines.append(f"  {o.description.strip()}")
                return "\n".join(lines)

            if action == "describe":
                _need(action, id=id)
                o = orch.require(id)
                lines = [f"# {o.name or o.id}", ""]
                if o.description.strip():
                    lines += [o.description.strip(), ""]
                lines += [f"- **mode**: {o.mode}"
                          + (f" over `{o.subject_type}`" if o.mode == "each" else ""),
                          f"- **starts in**: `{o.first_state()}`",
                          f"- **max visits per state**: {o.max_visits}", "",
                          "## States", ""]
                for st in o.states:
                    what = ("final" if st.final else
                            f"runs flow `{st.flow}`" if st.flow else "waits for a signal")
                    lines.append(f"- `{st.id}` {st.label} — {what}")
                lines += ["", "## Transitions", ""]
                lines += ([f"- `{t.state}` --{t.on}--> `{t.to}`" for t in o.transitions]
                          or ["- none"])
                lines += ["", "```mermaid", orch.mermaid(o), "```"]
                issues = orch.issues(o)
                if issues:
                    lines += ["", "## Not ready", ""] + [f"- {i}" for i in issues]
                warn = orch.unmirrored(o)
                if warn:
                    lines += ["", f"Note: {warn}"]
                return "\n".join(lines)

            if action in ("save", "delete") and (refused := role_refusal(Role.ADMIN)):
                return f"Not done: {refused}"   # orchestrations are configuration

            if action == "save":
                _need(action, orchestration_json=orchestration_json)
                o = KbOrchestration.model_validate(_obj(orchestration_json, "orchestration_json"))
                if not o.id:
                    return "Not done: the orchestration needs an `id`."
                cfg = runtime.kb_config()
                old = next((x for x in cfg.orchestrations if x.id == o.id), None)
                if old is not None:
                    o.version = old.version + 1
                    cfg.orchestrations = [o if x.id == o.id else x for x in cfg.orchestrations]
                else:
                    cfg.orchestrations.append(o)
                runtime.save_kb_config(cfg)
                kb.normalise()
                saved = orch.require(o.id)
                issues = orch.issues(saved)
                warn = orch.unmirrored(saved)
                return (f"Saved `{o.id}` (version {o.version})."
                        + ("\n\nNot ready yet:\n" + "\n".join(f"- {i}" for i in issues)
                           if issues else "")
                        + (f"\n\nNote: {warn}" if warn else ""))

            if action == "delete":
                _need(action, id=id)
                orch.require(id)
                cfg = runtime.kb_config()
                cfg.orchestrations = [x for x in cfg.orchestrations if x.id != id]
                runtime.save_kb_config(cfg)
                return f"Deleted `{id}` and {kb.store.delete_instances(id)} instance(s)."

            if action == "start":
                _need(action, id=id)
                made = orch.start(id, subject, None if not branch else
                                  "" if branch == "main" else branch)
                kind = subject.split("/", 2)[1] if subject.count("/") >= 2 else ""
                warn = orch.unmirrored(orch.require(id), kind)
                if not made:
                    return (f"Nothing to start: every unit of work already has an "
                            f"instance of `{id}`.")
                return (f"Started {len(made)} instance(s) of `{id}`:\n"
                        + "\n".join(_inst_line(i) for i in made)
                        + (f"\n\nNote: {warn}" if warn else "")
                        + '\n\n`kb_orchestrate("next")` for the first piece of work.')

            if action == "next":
                out = orch.next(id)
                if out is None:
                    open_ = [i for i in kb.store.instances(id)
                             if i.status not in ("done", "cancelled")]
                    if not open_:
                        return ("Nothing to do: no instance is open"
                                + (f" in `{id}`." if id else "."))
                    return ("Nothing is ready to take. Open instances:\n"
                            + "\n".join(_inst_line(i) for i in open_))
                inst, run_id = out["instance"], out["run"]["id"]
                return (f"Instance `{inst['id']}` of `{inst['orchestration']}`"
                        + (f" for `{inst['subject']}`" if inst["subject"] else "")
                        + f", state `{inst['state']}`. Run `{run_id}` is open. Pass "
                        + f'`run="{run_id}"`'
                        + (f' and `branch="{inst["branch"]}"`' if inst.get("branch") else "")
                        + ' on every kb_write call, then '
                        + f'`kb_flow("finish", id="{run_id}", outcome=...)`.\n\n---\n\n'
                        + out["prompt"])

            if action == "status":
                insts = kb.store.instances(id)
                if not insts:
                    return "No instances" + (f" of `{id}`." if id else ".")
                return "\n".join(["# Instances", ""] + [_inst_line(i) for i in insts])

            if action == "signal":
                _need(action, id=id, signal=signal)
                return "Done.\n" + _inst_line(orch.signal(id, signal, message, by="mcp"))

            if action == "retry":
                _need(action, id=id)
                return "Done.\n" + _inst_line(orch.retry(id))

            if action == "cancel":
                _need(action, id=id)
                return "Done.\n" + _inst_line(orch.cancel(id))

            if action == "clear":
                _need(action, id=id)
                return f"Forgot {kb.store.delete_instances(id)} instance(s) of `{id}`."

            return _unknown(action, ORCH)
        except LookupError as e:
            return f"Not done: {e}"
        except ValueError as e:
            return f"Not done: {e}"

    # ── chat ─────────────────────────────────────────────────────────────────

    CHAT = ("join", "wait", "say", "history", "branch")

    def _chat_branch(c: dict) -> str:
        b = c.get("branch") or ""
        return (f'This chat is on branch `{b}`: pass branch="{b}" to kb_read and '
                "kb_write." if b else "")

    def _chat_line(m: dict) -> str:
        who = {"user": "Person", "assistant": "You", "system": "—"}.get(m["role"], m["role"])
        shown = "".join(f"\n  [shown: {i['node']}" + (f" § {i.get('section_title')}" if i.get("section") else "")
                        + "]" for i in m.get("items") or [])
        return f"#{m['seq']} {who}: {m['text']}{shown}"

    @mcp.tool()
    @_in_space(kb, chat_space)
    async def kb_chat(action: str = "join", id: str = "", text: str = "",
                      show_json: str = "", timeout: int = 25) -> str:
        """Host a chat about the knowledge base: a person writes in a chat window
        in Roadmap, and you answer from the knowledge base, briefly, showing
        small pieces of it in the window. The person drives; ``join`` explains
        how to converse.

        Actions:

        * ``join``    — join chat ``id`` (a code like ``kbc-x7k2qa``, from the
          window's MCP button): what it is about, the conversation so far, and
          how to host it. Call it first.
        * ``wait``    — wait for the person's next message(s); returns after
          ``timeout`` seconds (at most 50) with nothing if none came: call it
          again. Needs ``id``.
        * ``say``     — reply: ``text`` (short, markdown) and ``show_json``, a
          list of pieces to show, each ``{"node": "source/kind/id",
          "section": "<title or number>"}`` (``section`` optional: the whole
          topic). At most 4. Needs ``id``.
        * ``history`` — the whole conversation. Needs ``id``.
        * ``branch``  — put the chat on branch ``text`` (empty: back on main), so
          what it shows is read in that branch. ``kb_branch("open", chat=...)``
          does this for a new branch. Needs ``id``.

        The loop: ``join`` → ``wait`` → answer with ``say`` → ``wait`` again.
        """
        chats = kb.chats
        try:
            if action == "join":
                _need(action, id=id)
                out = chats.join(id)
                c = out["chat"]
                lines = [f"# Chat `{c['id']}`: {c['title']}", ""]
                if c.get("focus"):
                    lines += [f"Opened from `{c['focus']}`: start there "
                              f'(kb_read("get", ...) on it).', ""]
                if c.get("closed"):
                    lines += ["This chat is closed.", ""]
                if c.get("branch"):
                    lines += [_chat_branch(c), ""]
                lines += [_CHAT_GUIDE, "## So far", ""]
                lines += [_chat_line(m) for m in out["messages"]] or ["(nothing yet)"]
                lines += ["", f'Next: kb_chat("wait", id="{c["id"]}").']
                return "\n".join(lines)

            if action == "wait":
                _need(action, id=id)
                got = await chats.wait(id, timeout)
                if not got:
                    c = chats.get(id)
                    if c.get("closed"):
                        return "The chat is closed. You can stop."
                    return f'No new message. Call kb_chat("wait", id="{id}") again.'
                note = _chat_branch(chats.get(id))
                return ("\n".join(_chat_line(m) for m in got)
                        + (f"\n\n{note}" if note else "")
                        + f'\n\nAnswer with kb_chat("say", id="{id}", text=..., show_json=...).')

            if action == "say":
                _need(action, id=id)
                raw = (show_json or "").strip()
                items = []
                if raw:
                    try:
                        items = json.loads(raw)
                    except json.JSONDecodeError as e:
                        return f"Not done: show_json is not valid JSON: {e}"
                    if isinstance(items, dict):
                        items = [items]
                    if not isinstance(items, list):
                        return "Not done: show_json is a list of {\"node\", \"section\"}."
                m = chats.say(id, text, items)
                return (f"Sent (#{m['seq']}"
                        + (f", showing {len(m['items'])} piece(s)" if m["items"] else "")
                        + f'). Now kb_chat("wait", id="{id}").')

            if action == "history":
                _need(action, id=id)
                return "\n".join(_chat_line(m) for m in chats.messages(id)) or "(nothing yet)"

            if action == "branch":
                _need(action, id=id)
                c = chats.set_branch(id, text.strip())
                return _chat_branch(c) or "The chat is back on main."

            return _unknown(action, CHAT)
        except LookupError as e:
            return f"Not done: {e}"
        except ValueError as e:
            return f"Not done: {e}"

    # ── branches ─────────────────────────────────────────────────────────────

    BRANCH = ("list", "get", "diff", "compare", "context", "open", "update", "commit", "merge", "abandon",
              "reopen")

    def _branch_text(b: dict) -> str:
        c = b["changes"]
        lines = [f"# Branch `{b['id']}`: {b['name']} ({b['status']})"]
        if b.get("description"):
            lines += ["", b["description"]]
        if b.get("work_item"):
            ws = b.get("work_state") or {}
            lines += ["", f"Work item: `{b['work_item']}` {b.get('work_item_title', '')}"
                      + (f", state **{ws.get('label')}** ({ws.get('index', 0) + 1}/"
                         f"{ws.get('count', 0)})" if ws else "")]
        if b.get("git_branch"):
            commits = b.get("commits") or []
            lines += ["", f"Code: git branch `{b['git_branch']}`, {len(commits)} commit(s) "
                      "reported" + (":" if commits else ".")]
            lines += [f"- `{x['sha'][:12]}` {x.get('message', '')}" for x in commits[-5:]]
        lines += ["", f"Changes: {c['added']} node(s) added, {c['changed']} changed, "
                  f"{c['removed']} removed; {c['links_added']} link(s) added, "
                  f"{c['links_removed']} removed."]
        if b["status"] == "open":
            lines += ["", f'Read and write in it with branch="{b["id"]}" on kb_read / '
                      "kb_write / kb_flow."]
        return "\n".join(lines)

    @mcp.tool()
    @_in_space(kb, branch_space)
    def kb_branch(action: str = "list", id: str = "", name: str = "",
                  description: str = "", work_item: str = "", chat: str = "",
                  git_branch: str = "", commit: str = "", message: str = "",
                  node: str = "", personas: str = "", force: bool = False) -> str:
        """Branches of the knowledge base, like branches in git.

        The knowledge base describes the application as it is. New work (a
        feature, a change) is written in a **branch** opened for its work item:
        reading in the branch sees the knowledge base plus what the branch
        added, changed or removed; main sees none of it until the branch is
        merged, which is done when the work is completely finished. Pass
        ``branch=<id>`` to kb_read / kb_write / kb_flow to work in one.

        Actions:

        * ``list``    — the branches, open ones first.
        * ``get``     — one branch (``id``): its work item and its state, and
          how much it changes.
        * ``diff``    — what branch ``id`` changes, node by node.
        * ``compare`` — one ``node`` (``source/kind/id``) on main beside the
          same node in branch ``id``: a unified diff of the two as text.
        * ``context`` — the branch as **as is → to be**: every topic it adds
          (in full), changes (as a diff against main) or removes, grouped by
          persona. What a developer agent building the feature should read
          first. ``personas`` (comma-separated ids) narrows it, e.g.
          ``analysis,architecture,backend`` for the backend developer.
        * ``open``    — open a branch: ``name`` (the feature), ``description``,
          ``work_item`` (``source/kind/id`` of a unit of work on main: create it
          first with kb_write, without a branch), ``chat`` (a chat code: puts that
          chat on the new branch), ``git_branch`` (the branch of the code the
          feature is built in), ``id`` (optional; from the name otherwise).
        * ``update``  — change ``name`` / ``description`` / ``work_item`` /
          ``git_branch``.
        * ``commit``  — record ``commit`` (a hash, with ``message``) made on
          the git branch: a commit marks a step of the work done, it is not a
          merge. ``kb_flow("finish", commit=...)`` does this for a run.
        * ``merge``   — apply branch ``id`` to the knowledge base and close it:
          after the code's git branch was merged into the main line.
          Refused while its work item is not in its last state, or when main
          changed something the branch changed too; ``force`` merges anyway.
        * ``abandon`` / ``reopen`` — close without merging; open again.
        """
        b = kb.branches
        try:
            if action == "list":
                rows = b.list()
                rows.sort(key=lambda r: r["status"] != "open")
                if not rows:
                    return ('No branches yet. Open one with kb_branch("open", name=..., '
                            'work_item=...).')
                return "\n".join(
                    f"- `{r['id']}` **{r['name']}** ({r['status']}) · work item "
                    f"`{r['work_item'] or '-'}`"
                    + (f" · {(r.get('work_state') or {}).get('label')}"
                       if r.get("work_state") else "")
                    + f" · +{r['changes']['added']} ~{r['changes']['changed']} "
                      f"-{r['changes']['removed']}"
                    for r in rows)
            if action == "get":
                _need(action, id=id)
                return _branch_text(b.get(id))
            if action == "diff":
                _need(action, id=id)
                d = b.diff(id)
                lines = [f"# What branch `{id}` changes"]
                for part, label in (("added", "Added"), ("changed", "Changed"),
                                    ("removed", "Removed")):
                    if d[part]:
                        lines += ["", f"## {label}"] + [
                            f"- `{e['ref']}` {e['title']}"
                            + (" (main changed it too)" if e.get("main_changed") else "")
                            for e in d[part]]
                lines += ["", f"{len(d['links_added'])} link(s) added, "
                          f"{len(d['links_removed'])} removed."]
                return "\n".join(lines)
            if action == "compare":
                _need(action, id=id, node=node)
                c = b.compare(id, node)
                lines = [f"# `{node}` on main → in branch `{id}` ({c['change'] or 'unchanged'})", ""]
                changed = any(l["op"] != " " for l in c["lines"])
                lines += (["```diff"] + _branch_hunks(c["lines"]) + ["```"]) if changed else ["No difference."]
                if c["diagrams"]:
                    lines += ["", f"{len(c['diagrams'])} diagram(s) differ: "
                              + ", ".join(f"{d['type']} in {d['section'] or 'the top'}"
                                          for d in c["diagrams"]) + "."]
                return "\n".join(lines)
            if action == "context":
                _need(action, id=id)
                return b.context(id, [p.strip() for p in personas.split(",") if p.strip()])
            if action == "open":
                return _branch_text(b.open(name=name, description=description,
                                           work_item=work_item, chat=chat, branch_id=id,
                                           git_branch=git_branch))
            if action == "update":
                _need(action, id=id)
                return _branch_text(b.update(id, name=name or None,
                                             description=description or None,
                                             work_item=work_item or None,
                                             git_branch=git_branch or None))
            if action == "commit":
                _need(action, id=id, commit=commit)
                c = b.add_commit(id, commit, message)
                return f"Recorded commit `{c['sha'][:12]}` on branch `{id}`."
            if action == "merge":
                _need(action, id=id)
                m = b.merge(id, force=force)["merged"]
                return (f"Merged `{id}` into the knowledge base: {m['added']} added, "
                        f"{m['changed']} changed, {m['removed']} removed, "
                        f"{m['links_added']} link(s) added, {m['links_removed']} removed.")
            if action == "abandon":
                _need(action, id=id)
                return _branch_text(b.abandon(id))
            if action == "reopen":
                _need(action, id=id)
                return _branch_text(b.reopen(id))
            return _unknown(action, BRANCH)
        except (LookupError, ValueError) as e:
            return f"Not done: {e}"

    # ── admin ────────────────────────────────────────────────────────────────

    ADMIN = ("list_types", "get_type", "save_type", "delete_type", "list_personas",
             "save_persona", "list_packs", "install_pack", "clear_source")
    ADMIN_ONLY = ("save_type", "delete_type", "save_persona", "install_pack", "clear_source")

    @mcp.tool()
    @_in_space(kb)
    def kb_admin(action: str = "list_types", id: str = "", name: str = "",
                 description: str = "", form: str = "", fields_json: str = "",
                 template: str = "", icon: str = "", source: str = "",
                 category: str = "", persona: str = "", parent_type: str = "",
                 states_json: str = "", items_json: str = "", force: bool = False) -> str:
        """Administer the Knowledge Base: the node types, and ingested data.

        A **node type** says what a node of that kind looks like when the Knowledge
        Base owns the thing itself — a database, a web service, a test scenario.
        One type per information type. A ``structured`` type has ``fields`` every
        instance answers; an ``unstructured`` one is free text with an optional
        ``template``.

        Actions:

        * ``list_types``  — every type, its form and how many nodes use it.
        * ``get_type``    — one type in full, including its template. Needs ``id``.
        * ``save_type``   — create or replace a type. Needs ``name`` (or ``id``) and
          ``form``. For structured, ``fields_json`` is a JSON object of
          {field_name: {"label": ..., "type": "text|long-text|plantuml|mermaid|wireframe|number|boolean|url|date",
          "required": true, "hint": ...}} — or simply {field_name: "label"}. For
          unstructured, pass ``template``. ``category`` is ``topic`` (the
          default), ``folder`` or ``work`` (a unit of work in the work breakdown);
          ``persona`` the persona a topic or folder type belongs to;
          ``parent_type`` the work type one level up (work types only);
          ``states_json`` a work type's lifecycle in order, a JSON list of
          ``{"id", "label"}`` (or plain ids), the last one meaning done. Left
          empty, these keep what an existing type has, and so do ``form``,
          ``fields_json`` and ``template`` (a new type is structured by default).
        * ``delete_type`` — remove a type. Refused while nodes still use it unless
          ``force`` is true, because those nodes would keep their content but stop
          validating.
        * ``list_personas`` — the personas (who topics are written for), in order.
        * ``save_persona`` — add a persona, or change one: ``name``, ``description``
          (who it is and what its topics cover), ``id`` (optional for a new one:
          from the name). A new persona goes at the end. Give its topic and folder
          types ``persona=<id>`` with ``save_type``.
        * ``list_packs``  — the packs in the pack registry: ready-made personas and
          node types (functional analysis, testing, a legacy migration...).
        * ``install_pack`` — install a registry pack, ``id`` = the pack id. The whole
          pack, or ``items_json`` = {"personas": [...], "node_types": [...]} for
          some of it; what a picked type needs (its persona, the work types above
          it) comes along. A persona or type this workspace already has is kept
          unless ``items_json`` names it in "replace": [...].
        * ``clear_source`` — drop every node and link ingested from one ``source``.
          A full re-ingest starts here. Destructive and not undoable.

        Changing a type does not rewrite the nodes already stored: a field removed
        here still sits in their content until they are written again.
        """
        try:
            # what changes the configuration, or drops ingested data, is an admin's
            # (as over HTTP); reading the types and packs is anyone's who has MCP
            if action in ADMIN_ONLY and (refused := role_refusal(Role.ADMIN)):
                return f"Not done: {refused}"
            # config.yaml may have been edited by hand (a persona deleted): answer
            # from the document as the settings page would leave it
            kb.normalise()
            if action == "list_types":
                types = kb.node_types()
                if not types:
                    return ("No node types yet. A node type is for something the Knowledge "
                            "Base owns itself — a database, a web service, a test scenario. "
                            "Everything that lives in another system stays a pointer and "
                            "needs no type. Create one with action='save_type'.")
                return "\n".join(["Node types:", ""] + [_type_line(t, kb) for t in types])

            if action == "get_type":
                _need(action, id=id)
                t = kb.node_type(id)
                if t is None:
                    return f"No node type '{id}'. kb_admin(action='list_types') shows them."
                return json.dumps(t.model_dump(), indent=2, ensure_ascii=False)

            if action == "save_type":
                if not (name or id):
                    raise ValueError("'save_type' needs name (or the id of an existing type).")
                # an existing type is found by its id, or by the name it was saved
                # under: a re-save by name is an edit, and keeps what it leaves out
                if id:
                    old = kb.node_type(id)
                else:
                    old = next((t for t in kb.node_types()
                                if t.name == name or t.id == slugify(name)), None)
                    if old is not None:
                        id = old.id
                # what is not given stays as the existing type has it: changing a
                # type's lifecycle must not wipe its form or its template
                form = form or (old.form if old else "structured")
                if form not in ("structured", "unstructured"):
                    raise ValueError("form must be 'structured' or 'unstructured'.")
                fields = []
                for field_name, spec in _obj(fields_json, "fields_json").items():
                    if isinstance(spec, str):
                        spec = {"label": spec}
                    if not isinstance(spec, dict):
                        raise ValueError(
                            f"fields_json['{field_name}'] must be a label or an object.")
                    fields.append(TypeField(name=field_name, **spec))
                if old is not None and old.form == form:
                    if not fields_json.strip():
                        fields = list(old.fields)
                    if not template.strip():
                        template = old.template
                if form == "structured" and template.strip():
                    raise ValueError("A structured type has fields, not a template.")
                if form == "unstructured" and fields:
                    raise ValueError("An unstructured type has a template, not fields.")
                if category and category not in ("topic", "folder", "work"):
                    raise ValueError("category must be 'topic', 'folder' or 'work'.")
                states = old.states if old else []
                if states_json.strip():
                    try:
                        raw = json.loads(states_json)
                    except json.JSONDecodeError as e:
                        raise ValueError(f"states_json is not valid JSON: {e}")
                    if not isinstance(raw, list):
                        raise ValueError("states_json is a list of {\"id\", \"label\"}.")
                    states = [WorkState(id=x, label=x.replace("-", " ").capitalize())
                              if isinstance(x, str) else WorkState(**x) for x in raw]
                saved = kb.save_node_type(NodeType(
                    id=id, name=name or (old.name if old else id),
                    description=description or (old.description if old else ""), form=form,
                    fields=fields, template=template, icon=icon or (old.icon if old else ""),
                    category=category or (old.category if old else "topic"),
                    persona=persona or (old.persona if old else ""),
                    parent_type=parent_type or (old.parent_type if old else ""),
                    states=states))
                return (f"Saved node type `{saved.id}` ({saved.form}). "
                        f"Nodes of kind `{saved.id}` may now carry content.")

            if action == "delete_type":
                _need(action, id=id)
                left = kb.delete_node_type(id, force=force)
                tail = (f" {left} node(s) keep their content but are now untyped."
                        if left else "")
                return f"Deleted node type `{id}`.{tail}"

            if action == "list_personas":
                ps = kb.personas()
                if not ps:
                    return "No personas yet. Add one with action='save_persona'."
                return "\n".join(["Personas:", ""] + [
                    f"- `{a.id}` — **{a.name or a.id}**: {a.description}" for a in ps])

            if action == "save_persona":
                if not (name or id):
                    raise ValueError("'save_persona' needs name (or the id of an existing persona).")
                cfg = runtime.kb_config()
                pid = id or slugify(name)
                at = next((i for i, a in enumerate(cfg.personas) if a.id == pid), None)
                if at is None:
                    cfg.personas.append(Persona(id=pid, name=name or pid,
                                                description=description.strip()))
                    verb = "Added"
                else:
                    old = cfg.personas[at]
                    cfg.personas[at] = Persona(id=pid, name=name or old.name,
                                               description=description.strip() or old.description)
                    verb = "Updated"
                runtime.save_kb_config(cfg)
                return (f"{verb} persona `{pid}`. Give its types persona=\"{pid}\" "
                        "(kb_admin save_type) so its topics get a lane of their own.")

            if action == "clear_source":
                _need(action, source=source)
                known = kb.source_ids()
                if source not in known:
                    raise ValueError(
                        f"Unknown source '{source}'. Known: {', '.join(sorted(known))}.")
                before = kb.status()["nodes"]
                kb.store.clear_source(kb.require_writable(source))
                after = kb.status()["nodes"]
                return f"Cleared `{source}` — {before - after} node(s) removed."

            if action == "list_packs":
                index = packs.fetch_index()
                if not index["packs"]:
                    return f"The pack registry ({index['registryUrl']}) has no packs."
                lines = [f"Packs ({index['registryUrl']}):", ""]
                for p in index["packs"]:
                    lines.append(
                        f"- `{p.get('id')}` {p.get('name', '')} {p.get('version', '')}: "
                        f"{p.get('description', '')} — {len(p.get('personas') or [])} "
                        f"persona(s), {len(p.get('node_types') or [])} node type(s)")
                lines.append("")
                lines.append("Install one with action='install_pack', id=<pack id>.")
                return "\n".join(lines)

            if action == "install_pack":
                _need(action, id=id)
                pick = _obj(items_json, "items_json")
                pack = packs.fetch_pack(id)
                whole = "personas" not in pick and "node_types" not in pick
                res = packs.install(pack, None if whole else pick.get("personas", []),
                                    None if whole else pick.get("node_types", []),
                                    pick.get("replace", []))
                kb.normalise()
                parts = [f"{k}: {', '.join(v)}" for k, v in res.items() if v]
                tail = ("" if not res["kept"] else
                        " Kept items differ from the pack; name them in "
                        "items_json \"replace\" to take the pack's version.")
                return (f"Pack `{pack.id}` (v{pack.version}): " + "; ".join(parts) + "." + tail)

            return _unknown(action, ADMIN)
        except LookupError as e:
            return f"Not done: {e}"
        except (ValueError, packs.PackError) as e:
            return f"Not done: {e}"
