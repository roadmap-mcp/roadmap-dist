"""Spaces: one team's (or one project's) part of a workspace's knowledge base.

A space has its own personas, its own node types (with at most one work
breakdown), its own flows and orchestrations, and its own branches. What the
teams have in common stays shared by the workspace: the information sources and
the layer-1 graph over them. See ``docs/kb-spaces-proposal.md``.

A layer-2 node belongs to the space it was written in: the space's id is the
node's ``source`` (``payments/use-case/checkout``), where a single knowledge base
used to write ``manual``. A call writes only in its own space and reads the
others.

Which space a call is in is the :data:`current_space` context variable, the way
:data:`.branches.current_branch` picks a branch: the HTTP API sets it from the
``X-Roadmap-KB-Space`` header (or ``?space=``), the MCP tools from their
``space`` argument. Empty is the workspace's first space, which is also what
background work (no request) gets unless it pins one.
"""

from __future__ import annotations

import contextvars
import re
from contextlib import contextmanager
from typing import Callable, Iterator

#: the space the current call reads and writes; empty is the first one
current_space: contextvars.ContextVar[str] = contextvars.ContextVar(
    "kb_space", default="")

#: the HTTP header (and query parameter ``space``) that selects a space
SPACE_HEADER = "X-Roadmap-KB-Space"

#: what a knowledge base from before spaces wrote layer-2 nodes under; still
#: accepted on writes, as "this space"
LEGACY_SOURCE = "manual"

#: the space an existing knowledge base becomes
FIRST_SPACE_ID = "general"
FIRST_SPACE_NAME = "General"

ID_PATTERN = re.compile(r"^[a-z0-9][a-z0-9-]{0,63}$")

#: the first space's id, for a call that names none (set by :mod:`.runtime`;
#: the store has no access to the configuration)
_first: Callable[[], str] = lambda: FIRST_SPACE_ID


def set_first_space_resolver(fn: Callable[[], str]) -> None:
    global _first
    _first = fn


def current_id() -> str:
    """The id of the space this call is in."""
    return current_space.get() or _first()


@contextmanager
def on_space(space: str) -> Iterator[None]:
    """Run the block in ``space`` (``""`` is the first one)."""
    token = current_space.set(space or "")
    try:
        yield
    finally:
        current_space.reset(token)
