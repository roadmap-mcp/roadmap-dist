"""The Knowledge Base config slice and the ground-layer record shapes.

Two kinds of model live here:

* **Config** (:class:`KnowledgeBaseConfig`) — what the settings tabs edit and the
  config store persists: which information sources feed the ground layer, and the
  personas the knowledge layer will write for.
* **Ground layer** (:class:`GroundNode`, :class:`GroundLink`, :class:`IngestRun`) —
  what ingestion writes into the SQLite store. Deliberately generic: everything
  source-specific goes in ``details`` as JSON, so adding a source never changes
  the schema.
"""

from __future__ import annotations

import re
from datetime import datetime, timezone

from typing import Annotated, ClassVar, Literal, Union

from pydantic import AliasChoices, BaseModel, ConfigDict, Field


def slugify(text: str) -> str:
    """``"Business Analysts"`` -> ``"business-analysts"``. Ids stay stable and
    URL-safe; a topic will reference its persona by this."""
    slug = re.sub(r"[^a-z0-9]+", "-", (text or "").strip().lower()).strip("-")
    return slug or "unnamed"


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


# ── config ───────────────────────────────────────────────────────────────────

class KbSource(BaseModel):
    """One information source wired into the ground layer.

    ``type`` is the id of an existing information source (the settings-section id
    it was added from: ``atlassian``, ``repos``, ``trello``, …). The Knowledge Base
    does not re-configure that source — it reads whatever that plugin is already
    set up with; this entry only says "ingest it, under this name".
    """

    id: str = ""
    type: str = ""
    label: str = ""
    enabled: bool = True
    added_at: str = ""


class Persona(BaseModel):
    """Who a topic is written for — a role (``"Architects"``, ``"Testers"``) or a
    specialism (``"PrimeNG specialist"``). Once called an *audience*, which fit
    the roles but not a specialism: a specialist is somebody the knowledge is
    *for* without being a reader group. Saved configs from before the rename are
    still read (see :data:`LEGACY_PERSONAS_KEY`).

    Layer 2 will keep one topic tree per persona; layer 1 only needs the list to
    exist so the trees have somewhere to hang.

    **Their order in the list is their order on screen.** There is no ``order``
    field and there should not be one: the settings overview reorders the list
    itself, and every view that shows personas shows them in that order, so the
    one thing to keep straight is that this list is sorted by intent rather than
    by name or by when somebody added it.
    """

    id: str = ""
    name: str = ""
    description: str = ""


#: the fragment types that are a diagram's source, and the field types that ask for one
DIAGRAMS = ("plantuml", "mermaid", "wireframe")


class TypeField(BaseModel):
    """One field of a *structured* node type.

    Deliberately a short list of primitive types: a prototype needs the shape of
    the idea, and anything richer (enums, references) is a later argument.
    """

    name: str = ""
    label: str = ""
    type: Literal["text", "long-text", "plantuml", "mermaid", "wireframe", "number",
                  "boolean", "url", "date"] = "text"
    required: bool = False
    hint: str = ""

    @property
    def is_section(self) -> bool:
        """Written as a section of the document, not as a value: long text, or a
        diagram (``plantuml``, ``mermaid``, ``wireframe`` — the section holds a
        fragment of that type)."""
        return self.type in ("long-text",) + DIAGRAMS


class WorkState(BaseModel):
    """One state in a unit of work's lifecycle — "Analysing", "Done".

    A work type's states are an ordered list, and the order is the state
    machine: an item steps forward or back one state at a time, and the last
    state means finished. Ordered rather than a free graph of transitions
    because a lifecycle somebody reads at a glance is a line, and a progress
    figure needs a line to be measured along.
    """

    id: str = ""
    label: str = ""


#: the pre-rename spelling of a persona reference — read, never written
LEGACY_PERSONA_KEY = "audience"
#: the pre-rename spelling of a list of personas — read, never written
LEGACY_PERSONAS_KEY = "audiences"


class NodeType(BaseModel):
    """One kind of thing the Knowledge Base holds *itself* — a database, a web
    service, a test scenario.

    This is the other half of the ground layer. Most nodes are **pointers**: a
    ticket, a page, a commit that lives in a system of record, fetched on demand
    (see ``fetchers.py``). A node of a configured type is a **content node**: it
    exists because somebody wrote it here, so the Knowledge Base *is* its system
    of record and its content is stored.

    A type is either:

    * ``structured``   — a small set of named ``fields``; every instance answers
      the same questions, so the set can later be rendered, diffed and queried.
    * ``unstructured`` — free text, optionally starting from a ``template`` so the
      tenth test scenario has the same headings as the first.

    One type covers one information type. "Database" and "Web service" are two
    types, not one "technical asset" type with a discriminator.

    :attr:`category` says which of the three kinds it is — a unit of work, a
    folder, or a topic — and decides which of :attr:`parent_type` and
    :attr:`persona` applies. All three are node types because all three are
    nodes in the same graph; the category is how they are read, not where they
    are kept.
    """

    model_config = ConfigDict(populate_by_name=True)

    id: str = ""
    name: str = ""
    description: str = ""
    form: Literal["structured", "unstructured"] = "unstructured"
    #: which of the three kinds of node this type describes.
    #:
    #: * ``work``   — a unit of work: a project, a phase, a sprint, an item.
    #:   These live *only* in the work breakdown, the one lane that is not an
    #:   persona's, and they carry :attr:`parent_type` instead of
    #:   :attr:`persona`. The breakdown cuts across the personas: a topic may
    #:   say which unit of work it was written under, which is what lets a
    #:   question about one piece of work collect what every persona knows
    #:   about it.
    #: * ``folder`` — groups other nodes under a persona. A persona's topics
    #:   are a graph, and a graph is hard for a person to read; the folders are
    #:   the tree it is browsed in, and every topic sits under one. A folder
    #:   carries content of its own as well — an "overview of services" standing
    #:   above the services it contains.
    #: * ``topic``  — a leaf: the thing somebody actually wanted to read.
    category: Literal["work", "folder", "topic"] = "topic"
    #: ``work`` types only: the work type one level up, by id. Empty means the
    #: top of the breakdown. This is what makes it a *structure* rather than a
    #: bag of units, and it is declared between the **types** so the shape is
    #: configuration rather than something each instance re-invents. Cleared by
    #: ``normalise()`` if it points at a type that is gone, at a type that is
    #: not ``work``, or at a cycle.
    parent_type: str = ""
    #: id of the :class:`Persona` this type belongs to; empty means every
    #: persona shares it. Never set on a ``work`` type: the work breakdown
    #: belongs to no single persona, which is the point of it. A test scenario is the tester's, a database structure
    #: is the architect's, and both stand on the same ground layer — ownership
    #: says who it is *for*, not where it is kept. Cleared by ``normalise()`` if
    #: the persona is deleted, so the reference can never dangle. Saved configs
    #: from before the rename spell it ``audience``, which is still read.
    persona: str = Field(
        default="", validation_alias=AliasChoices("persona", LEGACY_PERSONA_KEY))
    #: structured types only
    fields: list[TypeField] = Field(default_factory=list)
    #: unstructured types only — prefilled into a new node
    template: str = ""
    #: a bootstrap icon name, for the explorer's node chips
    icon: str = ""
    #: ``work`` types only: the lifecycle an item of this type goes through, in
    #: order — see :class:`WorkState`. Empty means the default lifecycle
    #: (planned, in progress, done).
    states: list[WorkState] = Field(default_factory=list)


class KbSpace(BaseModel):
    """One team's (or project's) part of the knowledge base: its personas, its
    node types (with at most one work breakdown), its flows and orchestrations.
    The sources are the workspace's, shared by every space. See :mod:`.spaces`.

    Ids inside a space are the space's own: two spaces may each have a
    ``feature`` type or an ``architects`` persona."""

    model_config = ConfigDict(populate_by_name=True)

    id: str = ""
    name: str = ""
    description: str = ""
    personas: list[Persona] = Field(
        default_factory=list,
        validation_alias=AliasChoices("personas", LEGACY_PERSONAS_KEY),
    )
    node_types: list[NodeType] = Field(
        default_factory=list,
        validation_alias=AliasChoices("node_types", "topic_types"),
    )
    flows: list["KbFlow"] = Field(default_factory=list)
    orchestrations: list["KbOrchestration"] = Field(default_factory=list)


class KnowledgeBaseConfig(BaseModel):
    """The ``knowledgebase`` config slice the settings tabs edit, as one space
    sees it.

    Stored, the slice is the workspace's ``sources`` and its ``spaces``.
    :func:`.runtime.kb_config` hands out a *view* of it: the sources, every
    space, and in ``personas`` / ``node_types`` / ``flows`` / ``orchestrations``
    the lists of the space the call is in (``space``). Code that reads or edits
    "the configuration" therefore reads and edits its own space's, and
    :func:`.runtime.save_kb_config` writes those lists back into that space.
    A slice from before spaces has those lists at the top and no ``spaces``; it
    is read as one space (:meth:`stored_form`).

    ``node_types`` briefly went out under the name ``topic_types``, while a topic
    type was thought to be the only kind there was. It is one of three (see
    :class:`NodeType`), so the umbrella keeps the general name. The interim key is
    still *read*, so nothing written in between is lost; ``normalise()`` rewrites
    it under the proper name on the first save, and ``model_dump()`` only ever
    emits that one.
    """

    model_config = ConfigDict(populate_by_name=True)

    #: the config key the ``node_types`` field also answers to
    LEGACY_TYPES_KEY: ClassVar[str] = "topic_types"

    sources: list[KbSource] = Field(default_factory=list)
    #: once ``audiences`` — see :class:`Persona`; the old key is still read
    personas: list[Persona] = Field(
        default_factory=list,
        validation_alias=AliasChoices("personas", LEGACY_PERSONAS_KEY),
    )
    node_types: list[NodeType] = Field(
        default_factory=list,
        validation_alias=AliasChoices("node_types", LEGACY_TYPES_KEY),
    )
    #: configured paths into the knowledge base — see the ``flows`` section below.
    #: Quoted because :class:`KbFlow` is declared after the ground-layer models;
    #: ``model_rebuild()`` at the foot of the module resolves it.
    flows: list["KbFlow"] = Field(default_factory=list)
    #: state machines that run the flows from their outcomes — see
    #: :class:`KbOrchestration`
    orchestrations: list["KbOrchestration"] = Field(default_factory=list)
    #: every space of the workspace, in order; the first is the default
    spaces: list[KbSpace] = Field(default_factory=list)
    #: the space the lists above are (a view only; never stored)
    space: str = ""

    def stored_form(self) -> dict:
        """The slice as it is stored: the sources and the spaces. A slice from
        before spaces (lists at the top, no ``spaces``) comes out as one space,
        the first one, holding those lists."""
        spaces = [s.model_copy(deep=True) for s in self.spaces]
        if not spaces:
            from .spaces import FIRST_SPACE_ID, FIRST_SPACE_NAME
            spaces = [KbSpace(id=FIRST_SPACE_ID, name=FIRST_SPACE_NAME,
                              personas=self.personas, node_types=self.node_types,
                              flows=self.flows, orchestrations=self.orchestrations)]
        return {"sources": [s.model_dump() for s in self.sources],
                "spaces": [s.model_dump() for s in spaces]}

    def space_of(self, space_id: str) -> KbSpace | None:
        return next((s for s in self.spaces if s.id == space_id), None)


# ── ground layer ─────────────────────────────────────────────────────────────

class DocFragment(BaseModel):
    """A leaf of a topic's document: one run of text in one format.

    ``markdown`` is text; the others are a diagram's source: ``plantuml``,
    ``@startuml`` to ``@enduml``, drawn by the PlantUML server the viewer plugin
    is configured with; ``mermaid``, drawn in the browser — an ``erDiagram``, a
    ``flowchart``; ``wireframe``, an abstract sketch of a screen in PlantUML Salt
    (``{`` … ``}``), drawn in the browser in a hand-drawn style. ``type`` keeps
    the container the same as more formats come.
    """

    type: Literal["markdown", "plantuml", "mermaid", "wireframe"] = "markdown"
    text: str = ""


class DocSection(BaseModel):
    """A titled section of a topic's document. Its ``children`` are fragments
    and subsections, in reading order — an introduction can stand before the
    subsections it introduces."""

    type: Literal["section"] = "section"
    title: str
    children: list[DocBlock] = Field(default_factory=list)


#: one entry of a document or a section: told apart by ``type``
DocBlock = Annotated[Union[DocSection, DocFragment], Field(discriminator="type")]


def document_outline(blocks: list, depth: int = 0) -> list[tuple[int, str]]:
    """``(depth, title)`` of every section, in reading order — the table of
    contents. Depth 0 is a top-level section."""
    out: list[tuple[int, str]] = []
    for b in blocks:
        if isinstance(b, DocSection):
            out.append((depth, b.title))
            out += document_outline(b.children, depth + 1)
    return out


def document_markdown(blocks: list, level: int = 2) -> str:
    """The document as one markdown text, a section's title a heading one level
    deeper than the section around it — what an agent reads."""
    parts: list[str] = []
    for b in blocks:
        if isinstance(b, DocSection):
            parts.append("#" * min(level, 6) + " " + b.title)
            inner = document_markdown(b.children, level + 1)
            if inner:
                parts.append(inner)
        elif b.type in DIAGRAMS and b.text.strip():
            parts.append("```" + b.type + "\n" + b.text.strip() + "\n```")
        elif b.text.strip():
            parts.append(b.text.strip())
    return "\n\n".join(parts)


class NodeContent(BaseModel):
    """What a *content* node owns, by the form of its type.

    Empty on a pointer node — there the content lives in the source system and is
    fetched, never stored.

    ``document`` is the readable shape of a topic's long text: a tree of titled
    sections whose leaves are fragments (markdown). The titles make the outline,
    so a reader gets a table of contents, and each fragment stays small. Any
    content type may carry one. On a structured type it takes the place of the
    long-text fields: such a field is written as a top-level section titled with
    the field's label, and the fields keep the short values (a name, a number, a
    reference).
    """

    #: unstructured: markdown, usually grown from the type's template
    body: str = ""
    #: structured: values keyed by :class:`TypeField` name
    fields: dict = Field(default_factory=dict)
    #: the topic as titled sections over markdown fragments
    document: list[DocBlock] = Field(default_factory=list)

    def is_empty(self) -> bool:
        return not self.body.strip() and not self.fields and not self.document


class GroundNode(BaseModel):
    """One node of the ground layer.

    Two shapes, one row. A **pointer** (a ticket, a wiki page, a commit) carries
    identity only — ``source``/``kind``/``id`` locate it in the system that owns
    it, and its content is fetched on demand. A **content node** is one whose
    ``kind`` is a configured :class:`NodeType`; it was written here, so it also
    carries ``content``.

    ``source``/``kind``/``id`` is the primary key either way, so re-writing the
    same thing updates one row rather than growing a second.
    """

    source: str
    kind: str
    id: str
    title: str = ""
    uri: str = ""
    updated_at: str = ""
    #: locating fields for a pointer (a Confluence space, a repo name); never content
    details: dict = Field(default_factory=dict)
    #: the content a typed node owns; ``None`` for a pointer
    content: NodeContent | None = None
    #: read in a branch: ``added`` or ``changed`` there; empty on main and for
    #: what the branch did not touch. Never stored: the view works it out.
    branch_change: str = ""


class GroundLink(BaseModel):
    """A link between two nodes — the part that makes this a graph rather than a
    pile of documents. ``kind`` is the relation ("documented-in", "implements",
    "caused"); nodes may live in different sources."""

    src_source: str
    src_kind: str
    src_id: str
    dst_source: str
    dst_kind: str
    dst_id: str
    kind: str = "relates-to"
    attributes: dict = Field(default_factory=dict)
    #: read in a branch: ``added`` when the branch made it (see GroundNode)
    branch_change: str = ""


class IngestRun(BaseModel):
    """One pass over one source, for the status panel and for debugging."""

    id: int = 0
    source: str = ""
    started_at: str = ""
    finished_at: str = ""
    status: str = "running"          # running | ok | failed
    nodes: int = 0
    links: int = 0
    message: str = ""


# ── flows ────────────────────────────────────────────────────────────────────
#
# A flow is a configured answer to "what gets read, who it is written for, and
# what produces it". It is configuration, so it lives in the config slice beside
# the sources and the node types rather than in the graph — see
# ``docs/knowledge-flows-proposal.md``.


class FlowSource(BaseModel):
    """What a flow reads.

    ``ref`` names the thing — a configured Git Repo, a configured KB source, a
    context path, the start URL of a website — and ``scope`` narrows it in whatever
    way that kind of source understands (``{"paths": ["src/**"]}`` for a repo, read
    from its working tree). The readers live in ``roadmap.knowledgebase.flows``.

    A ``web`` source is read by whoever carries out the brief: the agent fetches
    the pages itself, starting at ``ref`` (``{"paths": ["/docs/**"]}`` narrows
    it). No server-side reader exists for it yet, so such a flow runs as a
    brief, not on the server.
    """

    kind: Literal["repo", "kb_source", "context", "web"] = "repo"
    ref: str = ""
    scope: dict = Field(default_factory=dict)


class FlowTargets(BaseModel):
    """Who the flow writes for.

    ``node_types`` empty means *every type belonging to the named personas*,
    which is the rule that keeps a flow in step with the Node types tab: add a
    type for a persona and the flow that writes for that persona can use it,
    with no second edit here. Listing types narrows that set; a type outside the
    named personas is not reachable either way.
    """

    model_config = ConfigDict(populate_by_name=True)

    #: once ``audiences`` — the old key is still read
    personas: list[str] = Field(
        default_factory=list,
        validation_alias=AliasChoices("personas", LEGACY_PERSONAS_KEY),
    )
    node_types: list[str] = Field(default_factory=list)
    #: may the flow create folder nodes, or must it place topics in existing ones?
    allow_new_folders: bool = True


class WorkItemBinding(BaseModel):
    """Which unit of work the flow's output is *about*.

    A declared input with an optional default, rather than a fixed reference:
    set the default and the flow behaves as if it were welded to one item; leave
    it empty and each run supplies one. That is what keeps a flow reusable across
    sprints without cloning its prompt.

    :attr:`relation` is ``about`` and not ``contains`` on purpose. The explorer's
    lane trees are built strictly from ``contains``; a topic written *about* a
    sprint is not *held by* it, and writing one would make every lane sprout
    branches under units of work.
    """

    required: bool = False
    source: str = "manual"
    kind: str = ""
    id: str = ""
    relation: str = "about"
    #: the state the work item enters when a run of this flow starts, and the
    #: one it reaches when the run finishes well — by state id. Empty leaves the
    #: state alone. This is how running the flows moves the breakdown along.
    on_start: str = ""
    on_finish: str = ""
    #: the state it goes to when the run finishes with outcome ``failed`` — the
    #: work did not reach its goal (a test fails, a build does not pass). This
    #: is how a step goes back: testing that fails sends it to development.
    on_fail: str = ""

    def ref(self) -> str:
        """``source/kind/id``. A source of ``manual`` (or none) is the space the
        flow is in: a flow, and a pack that brings one, works in any space."""
        if not (self.kind and self.id):
            return ""
        from .spaces import LEGACY_SOURCE, current_id
        source = current_id() if self.source in ("", LEGACY_SOURCE) else self.source
        return f"{source}/{self.kind}/{self.id}"


class FlowStage(BaseModel):
    """One large block of a flow's execution — "Read the screen", "Write the
    design", "Run the tests".

    Coarse on purpose: a stage is what a person checking on a running flow
    wants to see go by, not every tool call. The worker reports each one as it
    starts it, and the report lands on the run and on the unit of work the run
    is about, which is how the breakdown shows what a flow is doing right now.
    """

    id: str = ""
    label: str = ""
    #: what happens in it — rendered into the brief next to the label
    description: str = ""


class FlowPrompt(BaseModel):
    """The part of the prompt a person owns.

    Only :attr:`instructions`. Everything that makes the answer machine-readable —
    the personas, the type contract, the reply format — is rendered by
    :meth:`~.service.KnowledgeBaseService.render_prompt` and shown read-only,
    because an output contract the user can edit is one that breaks silently.

    :attr:`version` is stamped onto every node the flow writes, so "which topics
    came from the old prompt" stays answerable after it is improved.
    """

    instructions: str = ""
    version: int = 1
    #: the run's large blocks, in order; empty for a flow that is one block
    stages: list[FlowStage] = Field(default_factory=list)


class FlowLimits(BaseModel):
    """Guard rails for a run that costs real money."""

    max_nodes: int = 200
    max_input_chars: int = 200_000


class KbFlow(BaseModel):
    """One configured path into the knowledge base.

    ``kind`` is ``analyse`` (an AI prompt in the middle) or ``ingest`` (an adapter
    in the middle). They share this record on purpose: the list of flows is meant
    to answer "what writes into this knowledge base, and when", and an ingest that
    lived somewhere else would make that list a half-truth.
    """

    id: str = ""
    name: str = ""
    description: str = ""
    enabled: bool = True
    #: bumped whenever the prompt or the targets change — stamped on what it writes
    version: int = 1

    #: ``analyse``: an AI writes knowledge from a source. ``ingest``: an adapter
    #: does. ``act``: an AI *does* something outside the knowledge base (builds,
    #: tests, merges a branch) and need not write anything here, so it has no
    #: personas, types or source to name; its outcome is what counts.
    kind: Literal["analyse", "ingest", "act"] = "analyse"

    source: FlowSource = Field(default_factory=FlowSource)
    targets: FlowTargets = Field(default_factory=FlowTargets)
    work_item: WorkItemBinding = Field(default_factory=WorkItemBinding)
    prompt: FlowPrompt = Field(default_factory=FlowPrompt)
    #: ``ingest`` only: the adapter that does the reading. None exist yet.
    adapter: str = ""
    triggers: list[Literal["manual", "source", "mcp"]] = Field(
        default_factory=lambda: ["manual", "mcp"])
    limits: FlowLimits = Field(default_factory=FlowLimits)


# ── orchestration ────────────────────────────────────────────────────────────
#
# A flow does one piece of work and says how it went: ``ok`` or ``failed``. What
# happens *next* is not the flow's business; it is an orchestration's. An
# orchestration is a state machine in config: each state may name the flow that
# does that state's work, and the run's outcome is the signal that moves the
# machine on. "Testing failed, back to development" is a transition here, not a
# field on the testing flow.

#: the signals a finished run sends: its outcome
RUN_SIGNALS = ("ok", "failed", "error")


class OrchestrationState(BaseModel):
    """One state of an orchestration's state machine.

    A state with a ``flow`` is *work*: entering it makes the flow's run ready for
    a worker to take, and the run's outcome is the signal that leaves it. A state
    without one *waits* for a signal from a person or an agent (a review, a
    go-ahead). A ``final`` state ends the machine.

    When the instance is about a unit of work whose type has a state with the
    same id, entering this state moves the unit of work there too, so the
    breakdown shows where each item is.
    """

    id: str = ""
    label: str = ""
    flow: str = ""
    final: bool = False
    #: entering this state merges the instance's knowledge-base branch into
    #: main (see ``branches.py``): the step after the code was merged, so the
    #: knowledge base describes the feature from the moment the code has it.
    #: A merge that is refused leaves the instance stuck, with the reason.
    merge_branch: bool = False


class OrchestrationTransition(BaseModel):
    """In ``state``, on signal ``on``, go to ``to``.

    ``on`` is a run outcome (``ok``, ``failed``, ``error``) or any other word a
    person or agent may send. ``state`` ``*`` matches every state. With no
    matching transition, ``error`` leaves the state as it is so the run can be
    retried (the run broke, which says nothing about the work); any other
    signal leaves the instance *stuck* for a person to look at.
    """

    state: str = ""
    on: str = "ok"
    to: str = ""


class KbOrchestration(BaseModel):
    """A state machine that drives flows from their outcomes.

    ``mode`` ``single`` runs the machine once (an overview of a whole project).
    ``each`` runs one instance per unit of work of ``subject_type``: every area
    an overview wrote, every step a plan wrote, each with its own state.
    """

    id: str = ""
    name: str = ""
    description: str = ""
    enabled: bool = True
    version: int = 1
    mode: Literal["single", "each"] = "single"
    #: ``each``: the work type whose items each get an instance
    subject_type: str = ""
    #: the state a new instance starts in; empty means the first one
    initial: str = ""
    states: list[OrchestrationState] = Field(default_factory=list)
    transitions: list[OrchestrationTransition] = Field(default_factory=list)
    #: how often an instance may enter the same state before it is stuck: the
    #: guard against a test that fails for ever sending a step round and round
    max_visits: int = 5

    def state(self, state_id: str) -> OrchestrationState | None:
        return next((s for s in self.states if s.id == state_id), None)

    def first_state(self) -> str:
        if self.initial and self.state(self.initial):
            return self.initial
        return next((s.id for s in self.states if s.id), "")

    def transition(self, state_id: str, signal: str) -> OrchestrationTransition | None:
        exact = [t for t in self.transitions if t.state == state_id and t.on == signal]
        anywhere = [t for t in self.transitions if t.state == "*" and t.on == signal]
        return (exact or anywhere or [None])[0]


class OrchestrationInstance(BaseModel):
    """One run of an orchestration's state machine: where it is, and how it got
    there. ``subject`` is the unit of work it is about (``source/kind/id``), or
    empty for a ``single`` orchestration that is about the whole project.

    ``status``: ``ready`` (its state's flow waits for a worker), ``running``
    (a run is open), ``waiting`` (a state without a flow, waiting for a signal),
    ``done`` (a final state), ``stuck`` (no transition, a flow that cannot run,
    or too many visits; see ``message``), ``cancelled``.
    """

    id: str = ""
    orchestration: str = ""
    subject: str = ""
    #: the knowledge-base branch the instance works in ('' for main): its
    #: runs read and write there
    branch: str = ""
    #: the space it runs in (its orchestration is that space's)
    space: str = ""
    state: str = ""
    status: str = "ready"
    run: str = ""
    message: str = ""
    history: list[dict] = Field(default_factory=list)
    created_at: str = ""
    updated_at: str = ""


class FlowRun(BaseModel):
    """One execution of a flow, however it was started.

    A run exists from the moment a flow is handed out or started, not from the
    moment something is written — that is what lets a brief handed to an external
    AI still appear in the history, and what gives the nodes it writes a run id to
    carry.
    """

    id: str = ""
    flow_id: str = ""
    flow_version: int = 0
    prompt_version: int = 0
    #: how it was started: ``{"mode": "manual"|"source"|"mcp", …}``
    trigger: dict = Field(default_factory=dict)
    work_item: str = ""
    #: where the source stood when this run read it — a commit for a repository.
    #: Recorded on *every* run, not only a source-triggered one, because that is
    #: what lets the scheduled scan tell "already analysed at this commit" from
    #: "never analysed", whichever way the earlier run was started.
    source_position: str = ""
    started_at: str = ""
    finished_at: str = ""
    #: the stages reported so far, oldest first: ``{"at", "stage", "label", "message"}``
    progress: list[dict] = Field(default_factory=list)
    #: briefed | running | ok | failed — a brief stays ``briefed`` until writes land
    status: str = "briefed"
    nodes: int = 0
    links: int = 0
    message: str = ""
    #: the space it was started in: its flow is that space's, and what it
    #: writes lands there
    space: str = ""


class Provenance(BaseModel):
    """How a node came to exist — stamped into ``GroundNode.details.provenance``.

    In ``details`` rather than in new columns because the model's own rule says
    everything that varies by origin goes there as JSON, so a new kind of origin
    never changes the schema.
    """

    #: the reserved key under ``details``
    KEY: ClassVar[str] = "provenance"

    flow: str = ""
    flow_version: int = 0
    prompt_version: int = 0
    run: str = ""
    trigger: dict = Field(default_factory=dict)
    #: the commit (or equivalent) the material came from, so a topic can be
    #: traced to the exact state of the source that produced it
    source_position: str = ""
    model: str = ""
    at: str = Field(default_factory=utc_now)


# :class:`KnowledgeBaseConfig` names :class:`KbFlow` before it exists, so that
# the config slice stays at the top of the file where it is read.
DocSection.model_rebuild()
KbSpace.model_rebuild()
KnowledgeBaseConfig.model_rebuild()
