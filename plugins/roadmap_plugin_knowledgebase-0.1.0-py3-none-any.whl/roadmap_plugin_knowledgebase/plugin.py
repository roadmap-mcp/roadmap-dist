"""Knowledge Base plugin activator (layer 1).

Wires the runtime, publishes the ``knowledgebase`` service, mounts
``/api/knowledgebase``, registers the ``kb_*`` MCP tools on the shared server, and
contributes the settings tabs.

The service deliberately opens no store here: activation happens outside any
request, so the workspace is not known yet. Each call resolves its own tenant's
SQLite file (one per workspace) through ``current_workspace``.

Nothing here touches ``roadmap.brain``: the Company Brain is being retired and
this plugin is its replacement, so the two are independent — you can install
either, both, or neither.

Next phases: ingestion adapters per information source (writing nodes + links
into the store), then layer 2 — agents maintaining persona topic trees.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .mcp_tools import register_mcp_tools
from .router import create_knowledgebase_router
from .service import KnowledgeBaseService
from .settings_section import KB_SECTIONS


class KnowledgeBasePlugin(Plugin):
    id = "roadmap.knowledgebase"
    name = "Knowledge Base"
    requires = ["roadmap.settings", "roadmap.mcp"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)

        for section in KB_SECTIONS:
            ctx.extend(SETTINGS_SECTIONS_POINT, section)

        kb = KnowledgeBaseService()          # per-workspace stores, opened on use
        ctx.services.register("knowledgebase", kb)
        ctx.add_router(create_knowledgebase_router(kb))

        # the same ground-layer operations, reachable by an agent: the MCP server
        # plugin owns the shared server and makes every tool workspace-aware.
        register_mcp_tools(ctx.services.require("mcp"), kb)
