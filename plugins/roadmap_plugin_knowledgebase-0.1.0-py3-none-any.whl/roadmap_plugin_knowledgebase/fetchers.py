"""Fetching a node's content from the system it points at.

A ground node is a **pointer, not a copy**: it stores just enough to find the
thing again (source + kind + id, plus any extra locating field) and nothing
else. Content is fetched on demand, here — so the graph cannot drift from the
system of record, and nobody (agent or human) has to paste anything in.

What a refresh writes back is only the node's *label*: title, uri, and the
source's own ``updated_at``. The body it returns is **not stored** — it is for
the panel the user is looking at, and it will be different next time.

Phase 1 can fetch from Atlassian, because that datasource service is already in
the app. Other sources arrive with their ingestion adapters; until then a
refresh says so plainly instead of pretending.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from . import runtime


class NoFetcher(Exception):
    """No way to fetch this node's source (yet)."""


class FetchFailed(Exception):
    """The source was reachable in principle but did not return the thing."""


@dataclass
class Fetched:
    """A live view of what a node points at."""

    title: str = ""
    uri: str = ""
    updated_at: str = ""
    #: Live fields for display only — deliberately not persisted on the node.
    fields: dict = field(default_factory=dict)


def _excerpt(text: str, limit: int = 600) -> str:
    text = (text or "").strip()
    return text if len(text) <= limit else text[: limit - 1] + "…"


def _atlassian(node, kind: str) -> Fetched:
    atl = runtime.services().get("atlassian")
    if atl is None:
        raise NoFetcher("The Atlassian plugin is not installed in this edition.")
    base = (atl.config().base_url or "").rstrip("/")

    if kind in {"ticket", "issue", "jira_issue"}:
        issue = atl.get_issue(node.id)
        if not issue:
            raise FetchFailed(
                f"Jira did not return {node.id}. Check the key, and that the project is "
                "configured on the Atlassian tab.")
        return Fetched(
            title=issue.get("summary", ""),
            uri=f"{base}/browse/{node.id}" if base else "",
            updated_at=issue.get("updated", ""),
            fields={
                "status": issue.get("status", ""),
                "type": issue.get("issuetype", ""),
                "priority": issue.get("priority", ""),
                "assignee": issue.get("assignee", ""),
                "labels": ", ".join(issue.get("labels", []) or []),
                "description": _excerpt(issue.get("description", "")),
            },
        )

    if kind in {"page", "confluence_page"}:
        page = atl.get_page(node.id)
        if not page:
            raise FetchFailed(f"Confluence did not return page {node.id}.")
        return Fetched(
            title=page.get("title", ""),
            uri=page.get("url", "") or (f"{base}/pages/{node.id}" if base else ""),
            updated_at=page.get("updated", "") or page.get("version_when", ""),
            fields={
                "space": page.get("space_key", ""),
                "body": _excerpt(page.get("body_markdown", "")),
            },
        )

    raise NoFetcher(
        f"Atlassian has no fetcher for kind '{kind}' — try 'ticket' or 'page'.")


#: Fetchers by *source type* (the information source a KB source was added from).
_BY_TYPE = {"atlassian": _atlassian}


def fetch(node, source_type: str) -> Fetched:
    """Fetch what ``node`` points at. Raises :class:`NoFetcher` when this source
    cannot be fetched yet, :class:`FetchFailed` when it could not be read."""
    fetcher = _BY_TYPE.get(source_type)
    if fetcher is None:
        raise NoFetcher(
            f"No fetcher for source type '{source_type or 'manual'}' yet. Ingestion "
            "adapters land in the next phase; until then only Atlassian nodes refresh.")
    return fetcher(node, node.kind)
