"""The Knowledge Base settings group — three tabs over one config slice.

Every section owns part of the same ``knowledgebase`` document, so only the first
declares ``defaults``: the settings router deep-merges every section's defaults,
and declaring the slice twice would just merge it with itself.

``group="Knowledge Base"`` puts them under their own heading in the settings nav,
next to (not inside) *Information Sources* — the Knowledge Base consumes those
sources, it is not one of them.
"""

from roadmap_plugin_settings import SettingsSection

from .models import KnowledgeBaseConfig

KB_GROUP = "Knowledge Base"

KB_SOURCES_SECTION = SettingsSection(
    id="kb-sources",
    label="Layer 1",
    order=60,
    group=KB_GROUP,
    defaults=lambda: {"knowledgebase": KnowledgeBaseConfig().model_dump()},
)

# personas and the node types written for them, as one tree
KB_LAYER2_SECTION = SettingsSection(
    id="kb-layer-2",
    label="Layer 2",
    order=61,
    group=KB_GROUP,
)

KB_FLOWS_SECTION = SettingsSection(
    id="kb-flows",
    label="Flows",
    order=63,
    group=KB_GROUP,
)

KB_ORCHESTRATION_SECTION = SettingsSection(
    id="kb-orchestration",
    label="Orchestration",
    order=64,
    group=KB_GROUP,
)

KB_SECTIONS = [KB_SOURCES_SECTION, KB_LAYER2_SECTION, KB_FLOWS_SECTION,
               KB_ORCHESTRATION_SECTION]
