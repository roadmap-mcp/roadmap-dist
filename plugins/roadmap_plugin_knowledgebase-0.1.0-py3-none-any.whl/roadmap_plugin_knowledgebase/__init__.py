"""AI-backed Knowledge Base — layer 1 (the ground-truth graph) + personas.

Public surface for other plugins: the config/record models and the service type.
Everything else (store, router, runtime) is internal.
"""

from .models import (
    Persona,
    GroundLink,
    GroundNode,
    IngestRun,
    KbSource,
    KnowledgeBaseConfig,
    slugify,
)
from .service import KnowledgeBaseService
from .store import GroundStore

__all__ = [
    "Persona",
    "GroundLink",
    "GroundNode",
    "GroundStore",
    "IngestRun",
    "KbSource",
    "KnowledgeBaseConfig",
    "KnowledgeBaseService",
    "slugify",
]
