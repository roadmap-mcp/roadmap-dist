"""The orchestrator: runs the flows of a state machine from their outcomes.

A flow does one piece of work and ends ``ok`` or ``failed``; it does not know
what comes next. An orchestration (:class:`~.models.KbOrchestration`) does: its
states name the flow that does each state's work, and its transitions say where
an outcome leads. Each *instance* of it walks that machine, for the whole
project (``single``) or for one unit of work (``each``).

The worker can be anyone. An external AI over MCP asks for the next piece of
work (:meth:`Orchestrator.next`), gets an ordinary flow brief, does the work and
finishes the run; :meth:`KnowledgeBaseService.finish_run` hands the outcome back
here as the signal, and the instance moves on. Nothing in the flow's own config
decides that move.
"""

from __future__ import annotations

import re
import uuid

from . import runtime
from .branches import on_branch
from .spaces import on_space
from .models import (
    FlowRun, KbOrchestration, OrchestrationInstance, RUN_SIGNALS, utc_now,
)

#: statuses an instance never leaves by itself
CLOSED = ("done", "cancelled")


class Orchestrator:
    """Stateless over the service: the config is read from the knowledge base's
    slice and the instances from its store, both per workspace, on every call."""

    def __init__(self, kb) -> None:
        self.kb = kb

    # ── config ────────────────────────────────────────────────────────────────

    def orchestrations(self) -> list[KbOrchestration]:
        return runtime.kb_config().orchestrations

    def orchestration(self, orch_id: str) -> KbOrchestration | None:
        return next((o for o in self.orchestrations() if o.id == orch_id), None)

    def require(self, orch_id: str) -> KbOrchestration:
        found = self.orchestration(orch_id)
        if found is None:
            known = ", ".join(o.id for o in self.orchestrations()) or "none configured"
            raise LookupError(f"No orchestration `{orch_id}` (known: {known}).")
        return found

    def issues(self, o: KbOrchestration) -> list[str]:
        """What stops this machine from running, in words a person can act on."""
        out: list[str] = []
        ids = [s.id for s in o.states if s.id]
        if not ids:
            return ["It has no states."]
        dupes = sorted({i for i in ids if ids.count(i) > 1})
        if dupes:
            out.append("State ids used twice: " + ", ".join(f"`{d}`" for d in dupes) + ".")
        if o.initial and o.initial not in ids:
            out.append(f"The initial state `{o.initial}` is not one of its states.")
        flows = {f.id for f in self.kb.flows()}
        for s in o.states:
            if s.flow and s.flow not in flows:
                out.append(f"State `{s.id}` runs flow `{s.flow}`, which does not exist.")
            if s.final and s.flow:
                out.append(f"State `{s.id}` is final, so its flow would never run.")
            if s.merge_branch and s.flow:
                out.append(f"State `{s.id}` merges the branch on entry; give its flow "
                           "to the state before it.")
        for t in o.transitions:
            if t.state != "*" and t.state not in ids:
                out.append(f"A transition leaves `{t.state}`, which is not a state.")
            if t.to not in ids:
                out.append(f"A transition goes to `{t.to}`, which is not a state.")
            if not t.on:
                out.append(f"A transition from `{t.state}` has no signal.")
        if not any(s.final for s in o.states):
            out.append("No state is final, so an instance can never be done.")
        if o.mode == "each":
            t = self.kb.node_type(o.subject_type) if o.subject_type else None
            if t is None or t.category != "work":
                out.append("Mode `each` needs `subject_type`: the work type whose "
                           "items each get an instance.")
        return out

    def unmirrored(self, o: KbOrchestration, kind: str = "") -> str:
        """A warning, not a problem: the states the unit of work cannot follow.

        Entering a state moves the work item to the state of the same id, so a
        state its work type does not have leaves the item where it was, and the
        breakdown stops showing where the work is. ``kind`` is the work type
        (``each``: the subject type; ``single``: the subject's kind)."""
        kind = kind or (o.subject_type if o.mode == "each" else "")
        t = self.kb.node_type(kind) if kind else None
        if t is None or t.category != "work":
            return ""
        have = {s.id for s in self.kb.work_states(t)}
        missing = [s.id for s in o.states if s.id and s.id not in have]
        if not missing:
            return ""
        return (f"The work type `{t.id}` has no state " + ", ".join(f"`{m}`" for m in missing)
                + ": while the instance is there, the work item stays where it was. Its states "
                "are " + ", ".join(f"`{s}`" for s in sorted(have)) + ".")

    # ── starting ──────────────────────────────────────────────────────────────

    def subjects(self, o: KbOrchestration) -> list[str]:
        """The units of work an ``each`` orchestration runs over, as refs."""
        # oldest first: the order the flow that planned them wrote them in
        nodes = list(reversed(self.kb.store.nodes(kind=o.subject_type, limit=0)))
        return [f"{n.source}/{n.kind}/{n.id}" for n in nodes]

    def start(self, orch_id: str, subject: str = "",
              branch: str | None = None) -> list[OrchestrationInstance]:
        """Create instances in the initial state. ``single``: one (about
        ``subject`` if given). ``each``: one per unit of work of the subject type
        that has none yet, so starting again picks up items written since.

        An instance works in ``branch``; left ``None``, in the open branch of
        its unit of work if it has one (a feature's work goes where its
        knowledge does), else on main."""
        o = self.require(orch_id)
        subject = self.kb.ref(subject)
        if not o.enabled:
            raise ValueError(f"Orchestration `{o.id}` is disabled.")
        issues = self.issues(o)
        if issues:
            raise ValueError("Not ready: " + " ".join(issues))
        existing = [i for i in self.kb.store.instances(o.id) if i.status != "cancelled"]
        if o.mode == "single":
            if subject:
                self._check_subject(subject)
            if any(i.subject == subject and i.status not in CLOSED for i in existing):
                raise ValueError(f"`{o.id}` is already running"
                                 + (f" for `{subject}`" if subject else "") + ".")
            wanted = [subject]
        else:
            if subject:
                self._check_subject(subject, o.subject_type)
                wanted = [subject]
            else:
                wanted = self.subjects(o)
            have = {i.subject for i in existing}
            wanted = [s for s in wanted if s not in have]
        made = []
        for subj in wanted:
            if branch is not None:
                in_branch = self.kb.branches.check(branch)
            else:
                found = self.kb.branches.of_work_item(subj) if subj else None
                in_branch = found["id"] if found else ""
            inst = OrchestrationInstance(id="orc_" + uuid.uuid4().hex[:12],
                                         orchestration=o.id, subject=subj, branch=in_branch)
            self._log(inst, "started")
            self._enter(o, inst, o.first_state(), note="started")
            made.append(inst)
        return made

    def _check_subject(self, subject: str, kind: str = "") -> None:
        subject = self.kb.ref(subject)
        parts = subject.split("/", 2)
        if len(parts) != 3 or not all(parts):
            raise ValueError(f"`{subject}` is not a node ref (source/kind/id).")
        if kind and parts[1] != kind:
            raise ValueError(f"`{subject}` is not a `{kind}`.")
        if self.kb.store.get_node(*parts) is None:
            raise ValueError(f"No node `{subject}`.")

    # ── handing out work ──────────────────────────────────────────────────────

    def next(self, orch_id: str = "") -> dict | None:
        """Take the oldest ready instance and open its state's flow run.

        Returns ``{instance, run, prompt}``, or ``None`` when nothing is ready.
        An instance whose flow cannot run (disabled, not ready) is set stuck on
        the way past, so one broken flow does not hold up the rest.
        """
        enabled = {o.id: o for o in self.orchestrations() if o.enabled}
        if orch_id:
            enabled = {orch_id: self.require(orch_id)} if orch_id in enabled else {}
        for inst in self.kb.store.instances(orch_id, status="ready"):
            o = enabled.get(inst.orchestration)
            if o is None:
                continue
            st = o.state(inst.state)
            flow = self.kb.flow(st.flow) if st and st.flow else None
            if flow is None or not flow.enabled:
                self._stuck(inst, f"State `{inst.state}` has no runnable flow"
                            + (f" (`{flow.id}` is disabled)" if flow is not None else "") + ".")
                continue
            problems = self.kb.flow_issues(flow, work_item=inst.subject or None)
            if problems:
                self._stuck(inst, f"Flow `{flow.id}` is not ready: " + " ".join(problems))
                continue
            # the flow's own state moves are not used: this machine decides
            worker = flow.model_copy(deep=True)
            worker.work_item.on_start = worker.work_item.on_finish = worker.work_item.on_fail = ""
            with on_branch(inst.branch):
                out = self.kb.brief(worker, {"mode": "orchestration", "orchestration": o.id,
                                             "instance": inst.id},
                                    work_item=inst.subject)
            inst.run, inst.status, inst.message = out["run"]["id"], "running", ""
            self._log(inst, "dispatched", run=inst.run, flow=flow.id)
            self.kb.store.save_instance(inst)
            out["instance"] = inst.model_dump()
            out["prompt"] += "\n\n" + self._outcome_note(o, inst)
            return out
        return None

    def _outcome_note(self, o: KbOrchestration, inst: OrchestrationInstance) -> str:
        moves = []
        for signal in ("ok", "failed"):
            t = o.transition(inst.state, signal)
            if t is not None:
                moves.append(f"`{signal}` goes to **{self._label(o, t.to)}**")
        code = ""
        if inst.branch:
            b = self.kb.store.branch(inst.branch) or {}
            if b.get("git_branch"):
                code = ("## Code\n\nThe code for this work lives in git branch `"
                        + b["git_branch"] + "`: work and commit there, never on the main "
                        "line. A commit marks this step done; it is not a merge. When you "
                        f'finish, pass the commit: `kb_flow("finish", ..., commit="<hash>", '
                        f'branch="{inst.branch}")`.\n\n')
        return (code + "## Orchestration\n\nThis run is the **" + self._label(o, inst.state)
                + f"** step of orchestration `{o.id}`"
                + (f", for `{inst.subject}`" if inst.subject else "") + ". "
                + ("Its outcome decides what happens next: " + "; ".join(moves) + "."
                   if moves else "Its outcome is passed to the orchestration.")
                + " When the run is finished, ask for the next piece of work with "
                  '`kb_orchestrate("next")`.')

    # ── signals ───────────────────────────────────────────────────────────────

    def on_run_finished(self, run: FlowRun, status: str,
                        message: str = "") -> OrchestrationInstance | None:
        """A run has ended: send its outcome to the instance it was working for.

        The instance is found from the run's trigger; a run somebody started by
        hand counts too, when it is the flow of the state an instance about the
        same unit of work is waiting in."""
        inst = None
        iid = (run.trigger or {}).get("instance")
        if iid:
            inst = self.kb.store.instance(iid)
        if inst is None:
            found = self.kb.store.instances(run=run.id)
            inst = found[0] if found else None
        if inst is None and run.work_item:
            for cand in self.kb.store.instances(subject=run.work_item, status="ready"):
                o = self.orchestration(cand.orchestration)
                st = o.state(cand.state) if o else None
                if st is not None and st.flow == run.flow_id:
                    inst = cand
                    break
        if inst is None or inst.status in CLOSED or (inst.run and inst.run != run.id):
            return None
        return self.signal(inst.id, status, message, run=run.id)

    def signal(self, instance_id: str, signal: str, message: str = "", *,
               run: str = "", by: str = "") -> OrchestrationInstance:
        """Move an instance on by ``signal``: a run's outcome, or a word a
        person or agent sends a waiting state ("approved")."""
        inst = self.kb.store.instance(instance_id)
        if inst is None:
            raise LookupError(f"No orchestration instance `{instance_id}`.")
        if inst.status in CLOSED:
            raise ValueError(f"Instance `{instance_id}` is {inst.status}.")
        # its orchestration, and the runs it starts, are its space's
        with on_space(inst.space):
            return self._signal(inst, signal, message, run=run, by=by)

    def _signal(self, inst: OrchestrationInstance, signal: str, message: str, *,
                run: str, by: str) -> OrchestrationInstance:
        o = self.require(inst.orchestration)
        signal = (signal or "").strip()
        if not signal:
            raise ValueError("Say which signal.")
        self._log(inst, "signal", signal=signal, message=message[:300], run=run, by=by)
        t = o.transition(inst.state, signal)
        if t is not None:
            self._enter(o, inst, t.to, note=f"{signal}" + (f": {message[:300]}" if message else ""))
        elif signal == "error":
            # the run broke, not the work: the same state, ready to be retried
            inst.status, inst.run, inst.message = "ready", "", message[:300]
            self.kb.store.save_instance(inst)
        else:
            self._stuck(inst, f"No transition from `{inst.state}` on `{signal}`.")
        return inst

    def cancel(self, instance_id: str) -> OrchestrationInstance:
        inst = self.kb.store.instance(instance_id)
        if inst is None:
            raise LookupError(f"No orchestration instance `{instance_id}`.")
        inst.status, inst.run = "cancelled", ""
        self._log(inst, "cancelled")
        return self.kb.store.save_instance(inst)

    def retry(self, instance_id: str) -> OrchestrationInstance:
        """Put a stuck instance back in its state, its visits forgiven."""
        inst = self.kb.store.instance(instance_id)
        if inst is None:
            raise LookupError(f"No orchestration instance `{instance_id}`.")
        if inst.status in CLOSED:
            raise ValueError(f"Instance `{instance_id}` is {inst.status}.")
        o = self.require(inst.orchestration)
        self._log(inst, "retried")
        self._enter(o, inst, inst.state, note="retried", count=False)
        return inst

    # ── the machine ───────────────────────────────────────────────────────────

    def _enter(self, o: KbOrchestration, inst: OrchestrationInstance, state_id: str, *,
               note: str = "", count: bool = True) -> None:
        st = o.state(state_id)
        if st is None:
            self._stuck(inst, f"State `{state_id}` does not exist.")
            return
        visits = sum(1 for h in inst.history
                     if h.get("event") == "enter" and h.get("state") == state_id)
        if count and visits >= max(o.max_visits, 1):
            self._stuck(inst, f"Entered `{state_id}` {visits} times already "
                              f"(max_visits {o.max_visits}).")
            return
        inst.state, inst.run, inst.message = state_id, "", ""
        inst.status = "done" if st.final else ("ready" if st.flow else "waiting")
        self._log(inst, "enter", state=state_id, note=note)
        self.kb.store.save_instance(inst)
        self._mirror(inst, state_id, note)
        if st.merge_branch:
            self._merge(o, inst)

    def _merge(self, o: KbOrchestration, inst: OrchestrationInstance) -> None:
        """Merge the instance's branch into main, now that the machine says the
        work is done. Refused (the work item not finished, main changed the
        same topics): the instance is stuck with the reason, for a person."""
        if not inst.branch:
            self._stuck(inst, f"State `{inst.state}` merges the branch, but this instance "
                              "works on main.")
            return
        try:
            result = self.kb.branches.merge(inst.branch)["merged"]
        except (LookupError, ValueError) as e:
            self._stuck(inst, f"Merging branch `{inst.branch}` was refused: {e}")
            return
        self._log(inst, "merged", branch=inst.branch,
                  message=f"{result['added']} added, {result['changed']} changed, "
                          f"{result['removed']} removed")
        self.kb.store.save_instance(inst)

    def _mirror(self, inst: OrchestrationInstance, state_id: str, note: str) -> None:
        """Show the machine's state on the unit of work, when its type has a
        state of the same id. Reporting only: never worth failing over."""
        parts = (inst.subject or "").split("/", 2)
        if len(parts) != 3 or not all(parts):
            return
        try:
            self.kb.set_state(*parts, state_id, one_step=False, note=note[:300],
                              by={"orchestration": inst.orchestration, "instance": inst.id})
        except ValueError:
            pass

    def _stuck(self, inst: OrchestrationInstance, why: str) -> None:
        inst.status, inst.message, inst.run = "stuck", why, ""
        self._log(inst, "stuck", message=why)
        self.kb.store.save_instance(inst)

    @staticmethod
    def _log(inst: OrchestrationInstance, event: str, **data) -> None:
        inst.history.append({"at": utc_now(), "event": event,
                             **{k: v for k, v in data.items() if v}})
        inst.history = inst.history[-200:]

    @staticmethod
    def _label(o: KbOrchestration, state_id: str) -> str:
        st = o.state(state_id)
        return (st.label or st.id) if st else state_id

    # ── reading ───────────────────────────────────────────────────────────────

    def summary(self, o: KbOrchestration) -> dict:
        """How many instances are where: per status and per state."""
        insts = self.kb.store.instances(o.id)
        by_status: dict[str, int] = {}
        by_state: dict[str, int] = {}
        for i in insts:
            by_status[i.status] = by_status.get(i.status, 0) + 1
            if i.status != "cancelled":
                by_state[i.state] = by_state.get(i.state, 0) + 1
        return {"instances": len(insts), "by_status": by_status, "by_state": by_state}

    @staticmethod
    def mermaid(o: KbOrchestration) -> str:
        """The machine as a Mermaid state diagram."""
        ids = {s.id: f"s{n}" for n, s in enumerate(o.states) if s.id}

        def label(text: str) -> str:
            return re.sub(r'["\n]', " ", text)

        lines = ["stateDiagram-v2"]
        for s in o.states:
            if s.id:
                text = (s.label or s.id) + (f" · {s.flow}" if s.flow else "")
                lines.append(f'    state "{label(text)}" as {ids[s.id]}')
        if o.first_state():
            lines.append(f"    [*] --> {ids[o.first_state()]}")
        for t in o.transitions:
            to = ids.get(t.to)
            if to is None:
                continue
            sources = list(ids.values()) if t.state == "*" else [ids.get(t.state)]
            for src in filter(None, sources):
                lines.append(f"    {src} --> {to} : {label(t.on)}")
        for s in o.states:
            if s.final and s.id:
                lines.append(f"    {ids[s.id]} --> [*]")
            if s.merge_branch and s.id:
                lines.append(f"    note right of {ids[s.id]} : merges the branch")
        return "\n".join(lines)


__all__ = ["Orchestrator", "RUN_SIGNALS"]
