"""``/api/knowledgebase`` — the ground-layer API.

Read *and* write: the graph is the one thing here that is not configuration, so
it has real endpoints rather than living in the settings document. The MCP tools
(``mcp_tools.py``) and the explorer page are both clients of this API — anything
an agent can do over MCP, a person can do with curl, and the other way round.

Which *sources* and *personas* exist is still settings: that is configuration,
saved by the settings page like every other tab.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

from roadmap_framework import session

from . import runtime
from .branches import BRANCH_HEADER, current_branch
from .fetchers import FetchFailed, NoFetcher
from .models import GroundLink, GroundNode, KbFlow
from .service import KnowledgeBaseService


class NodesBody(BaseModel):
    nodes: list[GroundNode] = Field(default_factory=list)
    links: list[GroundLink] = Field(default_factory=list)
    #: a flow run these nodes belong to, which stamps provenance on them —
    #: exactly what the ``run`` argument on the MCP ``kb_write`` tool does.
    #: Anything an agent can do over MCP a person can do with curl, and that
    #: has to include being able to say where a node came from.
    run: str = ""


class LinksBody(BaseModel):
    links: list[GroundLink] = Field(default_factory=list)
    #: stamps the links with a flow run, so undoing the run removes them
    run: str = ""


class PreviewBody(BaseModel):
    """A flow to render, usually one being edited and not yet saved."""

    flow: KbFlow
    work_item: str = ""
    mode: str = "brief"


class BriefBody(BaseModel):
    work_item: str = ""


class StateBody(BaseModel):
    """Move a unit of work one state forward or back."""

    to: str
    note: str = ""


class StartBody(BaseModel):
    """Start an orchestration: for one unit of work, or (``each``) all of them."""

    subject: str = ""


class NextBody(BaseModel):
    orchestration: str = ""


class SignalBody(BaseModel):
    """A signal to an orchestration instance: an outcome, or a word such as
    ``approved`` that a waiting state has a transition for."""

    signal: str
    message: str = ""


class ChatBody(BaseModel):
    """Open a chat: about the whole knowledge base, or about one node."""

    title: str = ""
    focus: str = ""


class ChatMessageBody(BaseModel):
    text: str


class ChatBranchBody(BaseModel):
    """Put a chat on a branch; empty is main."""

    branch: str = ""


class BranchBody(BaseModel):
    """Open a branch for one unit of work (``source/kind/id`` on main)."""

    name: str
    description: str = ""
    work_item: str = ""
    chat: str = ""
    id: str = ""
    git_branch: str = ""


class MergeBody(BaseModel):
    force: bool = False


class ProgressBody(BaseModel):
    """A run says which of its stages it has started."""

    stage: str = ""
    message: str = ""


def create_knowledgebase_router(kb: KnowledgeBaseService) -> APIRouter:
    async def in_branch(request: Request):
        """Every route reads and writes in the branch the request names (the
        ``X-Roadmap-KB-Branch`` header, or ``?branch=``); none is main."""
        branch = (request.headers.get(BRANCH_HEADER)
                  or request.query_params.get("branch") or "").strip()
        if branch:
            try:
                kb.branches.check(branch)
            except LookupError as e:
                raise HTTPException(status_code=404, detail=str(e))
        token = current_branch.set(branch)
        try:
            yield
        finally:
            current_branch.reset(token)

    router = APIRouter(prefix="/api/knowledgebase", tags=["knowledgebase"],
                       dependencies=[Depends(in_branch)])

    def require_unlocked():
        if runtime.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    # ── configuration (read-only here) ───────────────────────────────────────

    @router.get("/available-sources")
    def available_sources():
        """Information sources that can still be added (the ones already wired in
        are filtered out, so the Add button only offers new ones)."""
        require_unlocked()
        return {"sources": kb.available_sources()}

    @router.get("/node-types")
    def node_types():
        """The configured content types — what a node of this kind must look like.

        The settings page edits these in the config document; the explorer needs
        them here, where it has no config document to read.
        """
        require_unlocked()
        return {"node_types": [t.model_dump() for t in kb.node_types()]}

    @router.get("/status")
    def status():
        """What the ground layer holds: per-source node counts and recent runs."""
        require_unlocked()
        kb.normalise()
        return kb.status()

    # ── the graph ────────────────────────────────────────────────────────────

    @router.get("/graph")
    def graph(source: str = "", kind: str = "", query: str = "", limit: int = 200):
        """Nodes plus the links among them — what the explorer page draws.
        ``limit=0`` returns the whole graph, which is what the explorer asks for."""
        require_unlocked()
        return kb.graph(source=source, kind=kind, query=query, limit=limit)

    @router.get("/nodes")
    def nodes(source: str = "", kind: str = "", query: str = "", limit: int = 200):
        require_unlocked()
        return {"nodes": [n.model_dump() for n in
                          kb.store.nodes(source=source, kind=kind, query=query, limit=limit)]}

    @router.get("/nodes/{source}/{kind}/{node_id:path}")
    def node(source: str, kind: str, node_id: str):
        """One node with the links that touch it — the explorer's detail pane."""
        require_unlocked()
        found = [n for n in kb.store.nodes(source=source, kind=kind, limit=1000)
                 if n.id == node_id]
        if not found:
            raise HTTPException(status_code=404, detail=f"No node {source}/{kind}/{node_id}")
        return {
            "node": found[0].model_dump(),
            "links": [l.model_dump() for l in kb.store.links_of(source, kind, node_id)],
        }

    @router.post("/nodes/{source}/{kind}/{node_id:path}/refresh")
    def refresh_node(source: str, kind: str, node_id: str):
        """Re-read this node from the system it points at.

        A node stores identity, not content — this is how the content gets seen.
        Only the label (title, uri, updated_at) is written back; the body in
        ``live`` is for display and is deliberately not stored.
        """
        require_unlocked()
        try:
            return kb.refresh(source, kind, node_id)
        except LookupError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except NoFetcher as e:
            raise HTTPException(status_code=501, detail=str(e))
        except FetchFailed as e:
            raise HTTPException(status_code=502, detail=str(e))

    @router.post("/nodes")
    def add_nodes(body: NodesBody):
        """Upsert nodes (and optionally links in the same call).

        Re-posting the same ids updates them in place, so an ingest — or an agent
        correcting itself — never duplicates.
        """
        require_unlocked()
        try:
            stamp = kb.provenance_for(body.run) if body.run else None
            n = kb.add_nodes(body.nodes, stamp)
            l = kb.add_links(body.links, stamp)
            if body.run:
                l += kb.link_run_output(body.run, body.nodes)
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))
        return {"nodes": n, "links": l}

    @router.post("/links")
    def add_links(body: LinksBody):
        require_unlocked()
        try:
            return {"links": kb.add_links(
                body.links, kb.provenance_for(body.run) if body.run else None)}
        except ValueError as e:
            raise HTTPException(status_code=400, detail=str(e))

    @router.delete("/nodes/{source}/{kind}/{node_id:path}")
    def delete_node(source: str, kind: str, node_id: str):
        """Remove a node and the links that touch it."""
        require_unlocked()
        if not kb.store.delete_node(source, kind, node_id):
            raise HTTPException(status_code=404, detail=f"No node {source}/{kind}/{node_id}")
        return {"deleted": 1}

    # ── flows ────────────────────────────────────────────────────────────────
    #
    # The flows themselves are configuration, edited and saved by the settings
    # page like the sources and the node types — so there is no CRUD here. What
    # needs a server is the part that is *derived*: the rendered prompt, whether
    # a flow is runnable, and the runs.

    # ── the state of the work breakdown ────────────────────────────────────────

    @router.get("/work-status")
    def work_status():
        """Every unit of work's state, progress and running flows, by
        ``source/kind/id`` — what the explorer's breakdown lane draws."""
        require_unlocked()
        return {"items": kb.work_status()}

    @router.post("/nodes/{source}/{kind}/{node_id:path}/state")
    def set_state(source: str, kind: str, node_id: str, body: StateBody):
        require_unlocked()
        try:
            kb.set_state(source, kind, node_id, body.to, by={"by": "user"}, note=body.note)
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))
        return {"items": kb.work_status()}

    @router.get("/flows")
    def flows():
        """The configured flows, each with what stops it running.

        Normalises first, like ``/status``: a flow saved without an id — by hand,
        or over the API — has none until something assigns it, and until then
        every call that takes one cannot find it.
        """
        require_unlocked()
        kb.normalise()
        return {
            # whether server-side execution is installed at all, so the page can
            # offer Run or stay with briefs rather than showing a button that
            # always fails
            "can_run": kb.can_run(),
            "flows": [{"flow": f.model_dump(), "issues": kb.flow_issues(f)}
                      for f in kb.flows()],
        }

    @router.post("/flows/preview")
    def preview_flow(body: PreviewBody):
        """Render a flow's prompt without saving it.

        Takes the flow in the body rather than by id so the settings tab can show
        what it would ask while it is being written — a preview you have to save
        to see is one nobody looks at. Personas and node types still come from
        the saved config, since those are what the writer will be held to.
        """
        require_unlocked()
        return {
            "prompt": kb.render_prompt(body.flow, work_item=body.work_item,
                                       mode=body.mode),
            "issues": kb.flow_issues(body.flow),
            "personas": [a.model_dump() for a in kb.flow_personas(body.flow)],
            "node_types": [t.model_dump() for t in kb.flow_types(body.flow)],
        }

    @router.post("/flows/{flow_id}/brief")
    def brief_flow(flow_id: str, body: BriefBody):
        """Open a run and hand back the prompt for somebody else to carry out.

        The same thing the ``kb_flow`` MCP tool returns: the UI's Copy brief
        button and an external AI are doing the identical thing, and a run shows
        up in the history either way.
        """
        require_unlocked()
        kb.normalise()
        try:
            flow = kb.require_flow(flow_id)
        except LookupError as e:
            raise HTTPException(status_code=404, detail=str(e))
        if not flow.enabled:
            raise HTTPException(status_code=409, detail=f"Flow '{flow.id}' is disabled.")
        issues = kb.flow_issues(flow, work_item=body.work_item)
        if issues:
            raise HTTPException(status_code=409,
                                detail="Not ready: " + " ".join(issues))
        return kb.brief(flow, {"mode": "manual", "via": "settings"},
                        work_item=body.work_item)

    @router.post("/flows/{flow_id}/run")
    def run_flow(flow_id: str, body: BriefBody):
        """Run the flow here, on the server, as a background job.

        The same run record a brief opens, except Roadmap does the thinking and
        pays for it. 501 when the runner satellite is not installed, because
        that is a true statement about this deployment rather than an error the
        user did something to cause.
        """
        require_unlocked()
        kb.normalise()
        runner = kb.runner()
        if runner is None:
            raise HTTPException(
                status_code=501,
                detail="Server-side execution is not installed. Use Brief, or "
                       "install the roadmap.knowledgebase.flows plugin.")
        try:
            flow = kb.require_flow(flow_id)
        except LookupError as e:
            raise HTTPException(status_code=404, detail=str(e))
        if not flow.enabled:
            raise HTTPException(status_code=409, detail=f"Flow '{flow.id}' is disabled.")
        issues = kb.flow_issues(flow, work_item=body.work_item)
        if issues:
            raise HTTPException(status_code=409, detail="Not ready: " + " ".join(issues))
        try:
            return runner.start(flow, {"mode": "manual", "via": "settings"},
                                work_item=body.work_item)
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))

    @router.get("/flows/runs")
    def flow_runs(flow_id: str = "", limit: int = 20, work_item: str = ""):
        require_unlocked()
        return {"runs": [r.model_dump() for r in
                         kb.store.flow_runs(flow_id, limit=limit, work_item=work_item)]}

    @router.get("/flows/runs/{run_id}")
    def flow_run(run_id: str):
        """One run and what it wrote — the provenance stamp read back."""
        require_unlocked()
        run = kb.store.flow_run(run_id)
        if run is None:
            raise HTTPException(status_code=404, detail=f"No run {run_id}")
        return {"run": run.model_dump(),
                "nodes": [n.model_dump() for n in kb.store.nodes_of_run(run_id)]}

    @router.post("/flows/runs/{run_id}/progress")
    def flow_run_progress(run_id: str, body: ProgressBody):
        """A run reports the stage it has started (see ``report_progress``)."""
        require_unlocked()
        try:
            return kb.report_progress(run_id, stage=body.stage, message=body.message)
        except LookupError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))

    @router.post("/flows/runs/{run_id}/finish")
    def finish_flow_run(run_id: str, status: str = "ok", message: str = ""):
        require_unlocked()
        if status not in kb.RUN_OUTCOMES:
            raise HTTPException(status_code=422,
                                detail="status is one of " + ", ".join(kb.RUN_OUTCOMES))
        if kb.store.flow_run(run_id) is None:
            raise HTTPException(status_code=404, detail=f"No run {run_id}")
        return kb.finish_run(run_id, status=status, message=message).model_dump()

    @router.delete("/flows/runs/{run_id}/nodes")
    def undo_flow_run(run_id: str):
        """Take back everything one run wrote.

        This is what makes "write straight into the graph" a safe default: a run
        that went wrong is one identifier away from being taken back out. What it
        created is deleted, what it changed is put back as it was, and the links
        it made are removed (see ``KnowledgeBaseService.undo_run``).
        """
        require_unlocked()
        if kb.store.flow_run(run_id) is None:
            raise HTTPException(status_code=404, detail=f"No run {run_id}")
        return kb.undo_run(run_id)

    # ── orchestration ─────────────────────────────────────────────────────────
    #
    # The machines are configuration (the settings page saves them); their
    # instances are state, so they get endpoints. ``next`` is what a worker
    # loops on: it hands out the next piece of work as an ordinary flow brief,
    # and finishing that run is the signal that moves the machine on.

    def orch_errors(fn):
        try:
            return fn()
        except LookupError as e:
            raise HTTPException(status_code=404, detail=str(e))
        except ValueError as e:
            raise HTTPException(status_code=409, detail=str(e))

    @router.get("/orchestrations")
    def orchestrations():
        require_unlocked()
        orch = kb.orchestrator
        return {"orchestrations": [
            {**o.model_dump(), "issues": orch.issues(o), "summary": orch.summary(o),
             "diagram": orch.mermaid(o)} for o in orch.orchestrations()]}

    @router.get("/orchestrations/instances")
    def orchestration_instances(orchestration: str = "", status: str = "",
                                subject: str = ""):
        require_unlocked()
        return {"instances": [i.model_dump() for i in kb.store.instances(
            orchestration, status=status, subject=subject)]}

    @router.post("/orchestrations/next")
    def orchestration_next(body: NextBody):
        """The next piece of work: ``{instance, run, prompt}``, or 204 when
        nothing is ready."""
        require_unlocked()
        kb.normalise()
        out = orch_errors(lambda: kb.orchestrator.next(body.orchestration))
        if out is None:
            return Response(status_code=204)
        return out

    @router.post("/orchestrations/{orch_id}/start")
    def orchestration_start(orch_id: str, body: StartBody):
        require_unlocked()
        kb.normalise()
        made = orch_errors(lambda: kb.orchestrator.start(orch_id, body.subject))
        return {"instances": [i.model_dump() for i in made]}

    @router.post("/orchestrations/instances/{instance_id}/signal")
    def orchestration_signal(instance_id: str, body: SignalBody):
        require_unlocked()
        return orch_errors(lambda: kb.orchestrator.signal(
            instance_id, body.signal, body.message, by="manual")).model_dump()

    @router.post("/orchestrations/instances/{instance_id}/retry")
    def orchestration_retry(instance_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.orchestrator.retry(instance_id)).model_dump()

    @router.post("/orchestrations/instances/{instance_id}/cancel")
    def orchestration_cancel(instance_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.orchestrator.cancel(instance_id)).model_dump()

    @router.delete("/orchestrations/{orch_id}/instances")
    def orchestration_clear(orch_id: str):
        """Forget every instance of one orchestration (the work stays written)."""
        require_unlocked()
        return {"deleted": kb.store.delete_instances(orch_id)}

    # ── chats ─────────────────────────────────────────────────────────────────
    #
    # The window's side of a chat an external AI hosts over MCP (``kb_chat``).
    # The window polls ``GET /chats/{id}?since=`` for what is new.

    @router.post("/chats")
    def chat_create(body: ChatBody):
        require_unlocked()
        return orch_errors(lambda: kb.chats.create(title=body.title, focus=body.focus))

    @router.get("/chats/{chat_id}")
    def chat_get(chat_id: str, since: int = 0):
        require_unlocked()
        return orch_errors(lambda: {"chat": kb.chats.get(chat_id),
                                    "messages": kb.chats.messages(chat_id, since)})

    @router.post("/chats/{chat_id}/messages")
    def chat_post(chat_id: str, body: ChatMessageBody):
        require_unlocked()
        return orch_errors(lambda: kb.chats.post_user(chat_id, body.text))

    @router.post("/chats/{chat_id}/close")
    def chat_close(chat_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.chats.close(chat_id))

    @router.post("/chats/{chat_id}/reopen")
    def chat_reopen(chat_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.chats.reopen(chat_id))

    @router.post("/chats/{chat_id}/branch")
    def chat_branch(chat_id: str, body: ChatBranchBody):
        require_unlocked()
        return orch_errors(lambda: kb.chats.set_branch(chat_id, body.branch.strip()))

    # ── branches ──────────────────────────────────────────────────────────────
    #
    # These name the branch in the path, whatever view the request is in.

    @router.get("/branches")
    def branch_list(status: str = ""):
        require_unlocked()
        return {"branches": kb.branches.list(status)}

    @router.post("/branches")
    def branch_open(body: BranchBody):
        require_unlocked()
        return orch_errors(lambda: kb.branches.open(
            name=body.name, description=body.description, work_item=body.work_item,
            chat=body.chat, branch_id=body.id, git_branch=body.git_branch))

    @router.get("/branches/{branch_id}")
    def branch_get(branch_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.branches.get(branch_id))

    @router.get("/branches/{branch_id}/diff")
    def branch_diff(branch_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.branches.diff(branch_id))

    @router.get("/branches/{branch_id}/compare/{source}/{kind}/{node_id:path}")
    def branch_compare(branch_id: str, source: str, kind: str, node_id: str):
        """One node on main beside the same node in the branch: a line diff,
        and the diagrams that differ as source pairs."""
        require_unlocked()
        return orch_errors(lambda: kb.branches.compare(branch_id, f"{source}/{kind}/{node_id}"))

    @router.get("/branches/{branch_id}/context")
    def branch_context(branch_id: str, personas: str = ""):
        """The branch as "as is → to be" markdown, for an agent building it."""
        require_unlocked()
        return orch_errors(lambda: {"markdown": kb.branches.context(
            branch_id, [p.strip() for p in personas.split(",") if p.strip()])})

    @router.post("/branches/{branch_id}/merge")
    def branch_merge(branch_id: str, body: MergeBody):
        require_unlocked()
        return orch_errors(lambda: kb.branches.merge(branch_id, force=body.force))

    @router.post("/branches/{branch_id}/abandon")
    def branch_abandon(branch_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.branches.abandon(branch_id))

    @router.post("/branches/{branch_id}/reopen")
    def branch_reopen(branch_id: str):
        require_unlocked()
        return orch_errors(lambda: kb.branches.reopen(branch_id))

    @router.post("/sources/{source}/clear")
    def clear_source(source: str):
        """Drop everything ingested from one source — a full re-ingest starts here."""
        require_unlocked()
        kb.store.clear_source(source)
        return kb.status()

    return router
