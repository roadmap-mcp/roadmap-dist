"""The ``knowledgebase`` service — the facade other plugins (and the router) use.

Layer 1 only: what is configured, what has been ingested, and the store to write
into. The knowledge layer (agents writing persona topics) will hang off the same
service later; keeping the seam here means the router does not grow a second one.
"""

from __future__ import annotations

from contextlib import contextmanager
from pathlib import Path
from typing import Iterator

import re
import threading
import uuid

from . import fetchers, runtime, spaces
from .models import (
    DIAGRAMS, DocSection, Persona, FlowRun, GroundLink, GroundNode, KbFlow, KbSource, KbSpace,
    NodeContent, NodeType,
    Provenance, WorkState, document_outline, slugify, utc_now,
)
from .branches import Branches, current_branch, on_branch
from .spaces import on_space
from .chat import Chats
from .orchestration import Orchestrator
from .store import GroundStore


class KnowledgeBaseService:
    """One service instance, one knowledge base per workspace.

    The service is created once per process, but a workspace is resolved *per
    request*, so the store must not be opened in ``__init__``: activation runs
    outside any request, where ``current_workspace`` is still ``default``, and
    the path would be burned in for every tenant. :attr:`store` therefore
    resolves ``runtime.db_path()`` on each access, the way the gitmining and
    jobs services resolve theirs.
    """

    #: One :class:`GroundStore` per database file, keyed by resolved path, so the
    #: schema check runs once per workspace instead of once per call. The store
    #: holds no connection between calls (each opens and closes its own), so
    #: sharing an instance across request and worker threads is safe. The first
    #: build is under a lock: it migrates (adds columns, moves a knowledge base
    #: from before spaces), and two requests doing that at once trip over each
    #: other (the page's first reads after an upgrade arrive together).
    _stores: dict[Path, GroundStore] = {}
    _stores_lock = threading.Lock()

    @property
    def store(self) -> GroundStore:
        """The ground layer of the *current request's* workspace."""
        path = runtime.db_path()
        store = self._stores.get(path)
        if store is None:
            with self._stores_lock:
                store = self._stores.get(path)
                if store is None:
                    store = GroundStore(path)
                    store.init()
                    # a knowledge base from before spaces becomes the first space's
                    store.adopt_legacy(runtime.first_space_id())
                    self._stores[path] = store
        return store

    @property
    def chats(self) -> Chats:
        """Chats about the knowledge base, hosted by an external AI over MCP."""
        return Chats(self)

    @property
    def branches(self) -> Branches:
        """Branches: views in which new work is written before it is merged."""
        return Branches(self)

    @property
    def orchestrator(self) -> Orchestrator:
        """The state machines that run flows from their outcomes."""
        return Orchestrator(self)

    # ── what is configured ────────────────────────────────────────────────────

    def sources(self) -> list[KbSource]:
        return runtime.kb_config().sources

    def personas(self) -> list[Persona]:
        return runtime.kb_config().personas

    def node_types(self) -> list[NodeType]:
        return runtime.kb_config().node_types

    def node_type(self, type_id: str) -> NodeType | None:
        return next((t for t in self.node_types() if t.id == type_id), None)

    @property
    def MANUAL_SOURCE(self) -> str:
        """Nodes written by hand or by an agent belong to the space they were
        written in: its id is their source (it was ``manual`` before spaces). It
        is always writable: an agent should be able to record something it
        worked out without an administrator adding a source first."""
        return spaces.current_id()

    def space_ids(self) -> list[str]:
        return runtime.space_ids()

    def source_ids(self) -> set[str]:
        return {s.id for s in self.sources() if s.id} | set(self.space_ids())

    def ref_source(self, source: str) -> str:
        """``source`` as stored: empty or ``manual`` (a ref from before spaces) is
        the current space."""
        source = (source or "").strip()
        return self.MANUAL_SOURCE if source in ("", spaces.LEGACY_SOURCE) else source

    def ref(self, ref: str) -> str:
        """A node ref (``source/kind/id``) as stored: one from before spaces
        (``manual/...``) or with no source is the current space's."""
        ref = (ref or "").strip()
        if ref.count("/") < 2:
            return ref
        source, rest = ref.split("/", 1)
        return f"{self.ref_source(source)}/{rest}"

    def require_source(self, source: str) -> str:
        """Nodes must belong to a source that exists, or the graph fills up with
        orphans nobody can trace. Returns the id, raising ``ValueError`` if unknown."""
        source = self.ref_source(source)
        known = self.source_ids()
        if source not in known:
            raise ValueError(
                f"Unknown source '{source}'. Add it under Workspace settings → Knowledge "
                f"Base → Sources, or write in this space ('{self.MANUAL_SOURCE}'). "
                f"Known: {', '.join(sorted(known))}")
        return source

    def require_writable(self, source: str) -> str:
        """``require_source``, and not another space's: a space reads the others
        but writes only in its own."""
        source = self.require_source(source)
        if source != self.MANUAL_SOURCE and source in self.space_ids():
            raise ValueError(
                f"`{source}` is another space; this call is in space "
                f"`{self.MANUAL_SOURCE}`. Spaces read each other but write only in "
                f"their own: pass space=\"{source}\" to write there.")
        return source

    def delete_node(self, source: str, kind: str, node_id: str) -> bool:
        return self.store.delete_node(self.require_writable(source), kind, node_id)

    def other_spaces(self) -> tuple[str, ...]:
        """The spaces this call is not in: what a listing leaves out unless it
        reads across."""
        return tuple(s for s in self.space_ids() if s != self.MANUAL_SOURCE)

    def nodes(self, *, source: str = "", kind: str = "", query: str = "",
              limit: int = 200, across: bool = False) -> list[GroundNode]:
        """The nodes this space sees: its own, the shared layer 1, and (``across``
        or a ``source`` naming one) another space's."""
        source = self.ref_source(source) if source else ""
        hide = () if (across or source) else self.other_spaces()
        return self.store.nodes(source=source, kind=kind, query=query, limit=limit,
                                hide=hide)

    # ── writing (the ground-layer API, also reached over MCP) ────────────────

    def add_nodes(self, nodes: list[GroundNode],
                  provenance: Provenance | None = None, *,
                  strict: bool | None = None) -> int:
        """Upsert nodes, optionally stamping how they came to exist.

        A write under a run (``provenance``) is held to the document format —
        see :meth:`check_document_form`; ``strict`` overrides that, for a caller
        that has checked what it changes itself.

        The stamp goes under a reserved key in ``details`` and overwrites
        anything the caller put there: provenance is the server's account of what
        happened, and a writer that could forge it would make the record
        worthless.
        """
        for n in nodes:
            n.source = self.require_writable(n.source)
            self.check_content(n)
            if (provenance is not None) if strict is None else strict:
                self.check_document_form(n)
            self._keep_history(n, provenance)
        return self.store.upsert_nodes(nodes)

    #: where a node keeps the versions a run replaced, newest last
    HISTORY_KEY = "history"
    #: how many of them — enough to undo the last few runs over a shared topic
    HISTORY_DEPTH = 10

    def _keep_history(self, n: GroundNode, provenance: Provenance | None) -> None:
        """Stamp the node and keep what it replaces, so undoing a run can put a
        shared topic back instead of deleting it.

        The first write of a run to a node that already exists keeps the old
        version under ``details.history``; further writes by the same run only
        refine that run's own version. A write with no run is an ordinary edit:
        it carries over the stamp and history already there instead of dropping
        them, so the record of which run wrote a node survives a manual touch.
        """
        prior = self.store.get_node(n.source, n.kind, n.id)
        prior_details = dict(prior.details or {}) if prior else {}
        # a work item's state and progress log are kept by Roadmap, never by a write
        for key in (self.STATE_KEY, self.PROGRESS_KEY):
            n.details.pop(key, None)
            if prior_details.get(key):
                n.details[key] = prior_details[key]
        history = list(prior_details.get(self.HISTORY_KEY) or [])
        prev = prior_details.get(Provenance.KEY) or {}
        if provenance is None:
            if prev and Provenance.KEY not in n.details:
                n.details[Provenance.KEY] = prev
            if history:
                n.details[self.HISTORY_KEY] = history
            return
        if prior is not None and prev.get("run") != provenance.run:
            history.append({
                "title": prior.title, "uri": prior.uri,
                "content": prior.content.model_dump() if prior.content else None,
                "details": {k: v for k, v in prior_details.items() if k != self.HISTORY_KEY},
            })
            history = history[-self.HISTORY_DEPTH:]
        n.details[Provenance.KEY] = provenance.model_dump()
        if history:
            n.details[self.HISTORY_KEY] = history
        else:
            n.details.pop(self.HISTORY_KEY, None)

    def update_node(self, source: str, kind: str, node_id: str, *, title: str = "",
                    fields: dict | None = None, body: str | None = None,
                    document: list | None = None,
                    provenance: Provenance | None = None) -> GroundNode:
        """Change part of a content node — some fields, the body, the document,
        the title — and leave the rest as it is. A document is replaced whole;
        a field set to ``None`` is removed, which is how a long-text field moves
        into the document. Stamped and kept like any other write, so
        undoing the run that made the change puts the old values back."""
        prior = self.store.get_node(self.require_source(source), kind, node_id)
        if prior is None:
            raise ValueError(f"No node `{source}/{kind}/{node_id}` to update — "
                             "add it with add_node first.")
        if provenance is not None:
            # only what this write changes: a topic written before the
            # document format may still have its short fields updated
            self.check_document_form(GroundNode(
                source=prior.source, kind=kind, id=node_id,
                content=NodeContent(fields={k: v for k, v in (fields or {}).items()
                                            if v is not None}, body=body or "",
                                    document=document or [])))
        content = (prior.content or NodeContent()).model_copy(deep=True)
        if fields:
            merged = {**content.fields, **fields}
            content.fields = {k: v for k, v in merged.items() if v is not None}
        if body is not None:
            content.body = body
        if document is not None:
            content.document = NodeContent(document=document).document
        node = prior.model_copy(deep=True, update={"title": title or prior.title,
                                                   "content": content})
        self.add_nodes([node], provenance, strict=False)
        return node

    def undo_run(self, run_id: str) -> dict:
        """Take back everything one run wrote: delete what it created, put back
        what it changed, and remove the links it made. In the branch the run
        wrote in, whatever the current view is."""
        with self.in_run(run_id):
            return self._undo_run(run_id)

    def run_branch(self, run_id: str) -> str:
        """The branch a run was started in ('' for main)."""
        run = self.store.flow_run(run_id)
        return str(((run.trigger or {}).get("branch") if run else "") or "")

    def run_space(self, run_id: str) -> str:
        """The space a run was started in ('' if there is no such run)."""
        run = self.store.flow_run(run_id)
        return (run.space or "") if run else ""

    @contextmanager
    def in_run(self, run_id: str) -> Iterator[None]:
        """Run the block where the run works: its branch and its space, whatever
        the call's are (a job thread has neither)."""
        with on_branch(self.run_branch(run_id)), \
                on_space(self.run_space(run_id) or spaces.current_space.get()):
            yield

    def _undo_run(self, run_id: str) -> dict:
        deleted = restored = 0
        for n in self.store.nodes_of_run(run_id, limit=10_000):
            history = list((n.details or {}).get(self.HISTORY_KEY) or [])
            if not history:
                if self.store.delete_node(n.source, n.kind, n.id):
                    deleted += 1
                continue
            before = history.pop()
            details = dict(before.get("details") or {})
            if history:
                details[self.HISTORY_KEY] = history
            # the state and the progress log are not content: undoing a run's
            # writes leaves them where they are
            for key in (self.STATE_KEY, self.PROGRESS_KEY):
                details.pop(key, None)
                if (n.details or {}).get(key):
                    details[key] = n.details[key]
            content = before.get("content")
            self.store.upsert_nodes([n.model_copy(update={
                "title": before.get("title", ""), "uri": before.get("uri", ""),
                "details": details,
                # an empty content rather than None: None would keep what is stored
                "content": NodeContent(**content) if content else NodeContent(),
            })])
            restored += 1
        links = self.store.delete_links_of_run(run_id)
        message = f"{deleted} node(s) removed, {restored} restored, {links} link(s) removed"
        self.store.finish_flow_run(  # not finish_run: an undone run moves nothing
            run_id, status="undone", message=message)
        run = self.store.flow_run(run_id)
        if run is not None:
            self._log_work_item(run, {"event": "undone", "message": message})
        return {"deleted": deleted, "restored": restored, "links": links}

    def check_content(self, node: GroundNode) -> None:
        """A content node must match its type; a pointer must not carry content.

        The two shapes share a table, so this is the only thing keeping them from
        blurring — and the message is what an agent will read when it gets it
        wrong, so it says what to do instead.
        """
        node_type = self.node_type(node.kind)

        if node_type is None:
            if node.content is not None and not node.content.is_empty():
                known = ", ".join(t.id for t in self.node_types()) or "none configured"
                raise ValueError(
                    f"'{node.kind}' is not a configured node type, so it cannot carry "
                    f"content — a node of an unknown kind is a pointer, and pointers "
                    f"are fetched from their source. Node types: {known}. Add one under "
                    "Workspace settings → Knowledge Base → Layer 2.")
            return

        content = node.content
        if content is not None:
            self._check_document(node_type.id, content.document)
        if node_type.form == "structured":
            if content is not None and content.body.strip():
                raise ValueError(
                    f"Node type '{node_type.id}' is structured: put values in "
                    "'content.fields', not in 'content.body'.")
            values = dict(content.fields) if content else {}
            known = {f.name for f in node_type.fields}
            unknown = [k for k in values if k not in known]
            if unknown:
                raise ValueError(
                    f"Node type '{node_type.id}' has no field(s) {', '.join(sorted(unknown))}. "
                    f"Its fields are: {', '.join(sorted(known)) or '(none defined yet)'}.")
            # a long-text field may be written as a top-level section instead
            sections = {t.strip().lower() for d, t in
                        document_outline(content.document if content else []) if d == 0}
            missing = [f.name for f in node_type.fields
                       if f.required and not str(values.get(f.name, "")).strip()
                       and (f.label or f.name).strip().lower() not in sections
                       and f.name.lower() not in sections]
            if missing:
                raise ValueError(
                    f"Node type '{node_type.id}' requires {', '.join(missing)}.")
        else:
            if content is not None and content.fields:
                raise ValueError(
                    f"Node type '{node_type.id}' is unstructured: put the text in "
                    "'content.body'. Only a structured type has fields.")

    def check_document_form(self, node: GroundNode) -> None:
        """What a flow writes keeps its long text in ``content.document``.

        Held to on every write under a run, so a topic written by a flow is
        always one a person can read: no ``body``, no long-text field — each is
        a top-level section instead — and no headings inside a fragment, where
        they would be outside the outline. Writes by hand are not held to it,
        so what was written before the format stays valid until converted.
        """
        node_type = self.node_type(node.kind)
        content = node.content
        if node_type is None or content is None:
            return
        where = f"Node type '{node_type.id}'"
        if content.body.strip():
            raise ValueError(
                f"{where}: a flow writes its text in 'content.document', not in "
                "'content.body' — titled sections with markdown fragments as leaves; "
                "the body's headings become the sections.")
        long_text = [f for f in node_type.fields if f.is_section
                     and str(content.fields.get(f.name, "")).strip()]
        if long_text:
            raise ValueError(
                f"{where}: " + ", ".join(f"'{f.name}'" for f in long_text)
                + " is long text: write it as a top-level section of 'content.document' "
                "titled " + ", ".join(f"'{f.label or f.name}'" for f in long_text)
                + ", not as a field value. 'content.fields' keeps the short values.")
        top = {b.title.strip().lower(): b for b in content.document
               if isinstance(b, DocSection)}
        for f in node_type.fields:
            section = top.get((f.label or f.name).strip().lower()) or top.get(f.name.lower())
            if f.type in DIAGRAMS and section is not None and not any(
                    kind == f.type for _, kind, _ in _fragments(section.children)):
                raise ValueError(
                    f"{where}: section '{section.title}' is a diagram: give it a "
                    f"fragment of type '{f.type}' holding the source"
                    + (", @startuml to @enduml" if f.type == "plantuml" else "")
                    + " (markdown fragments may explain it).")
        for title, kind, text in _fragments(content.document):
            if kind == "markdown" and _has_heading(text):
                raise ValueError(
                    f"{where}: a fragment" + (f" in section '{title}'" if title else "")
                    + " contains a markdown heading. Make it a section of its own "
                    "('type': 'section' with a 'title'), so it is in the outline.")

    def is_legacy(self, node: GroundNode) -> bool:
        """A content node whose long text is not yet in the document format: a
        body, or a long-text field with a value."""
        node_type = self.node_type(node.kind)
        content = node.content
        if node_type is None or content is None:
            return False
        if content.body.strip():
            return True
        return any(f.is_section and str(content.fields.get(f.name, "")).strip()
                   for f in node_type.fields)

    def legacy_nodes(self, kind: str = "", limit: int = 0) -> list[GroundNode]:
        """Content nodes still to be converted to the document format."""
        out = [n for n in self.store.nodes(kind=kind, limit=0) if self.is_legacy(n)]
        return out[:limit] if limit > 0 else out

    @staticmethod
    def _check_document(type_id: str, blocks: list, path: str = "") -> None:
        """Every section has a title: the titles are the table of contents. A
        diagram is whole: its source opens with ``@start…`` and closes with
        ``@end…``, which is all the PlantUML server needs to draw it."""
        for i, b in enumerate(blocks, 1):
            if getattr(b, "type", "") == "plantuml":
                lines = [l.strip() for l in b.text.strip().splitlines()] or [""]
                if not (lines[0].startswith("@start") and lines[-1].startswith("@end")):
                    raise ValueError(
                        f"Node type '{type_id}': a 'plantuml' fragment"
                        + (f" in section {path.rstrip('.')}" if path else "")
                        + " must be one diagram's source, from '@startuml' on its "
                        "first line to '@enduml' on its last.")
            if getattr(b, "type", "") == "mermaid" and (
                    not b.text.strip() or b.text.strip().startswith("```")):
                raise ValueError(
                    f"Node type '{type_id}': a 'mermaid' fragment"
                    + (f" in section {path.rstrip('.')}" if path else "")
                    + " must be the diagram's source alone, starting with its kind "
                    "('erDiagram', 'flowchart LR', ...), without a code fence.")
            if getattr(b, "type", "") == "wireframe":
                body = "\n".join(l for l in b.text.strip().splitlines()
                                 if not l.strip().startswith(("@startsalt", "@endsalt", "!", "'")))
                if not body.strip().startswith("{") or body.count("{") != body.count("}"):
                    raise ValueError(
                        f"Node type '{type_id}': a 'wireframe' fragment"
                        + (f" in section {path.rstrip('.')}" if path else "")
                        + " must be a PlantUML Salt sketch: one '{' ... '}' block (braces "
                        "balanced), optionally between '@startsalt' and '@endsalt', "
                        "without a code fence.")
            if isinstance(b, DocSection):
                at = f"{path}{i}"
                if not b.title.strip():
                    raise ValueError(
                        f"Node type '{type_id}': section {at} of 'content.document' has "
                        "no title. Every section needs one — the titles are the table "
                        "of contents; put untitled text in a markdown fragment instead.")
                KnowledgeBaseService._check_document(type_id, b.children, at + ".")

    def add_links(self, links: list[GroundLink],
                  provenance: Provenance | None = None) -> int:
        """Upsert links; under a run, each is stamped with it in its attributes,
        so the run can show what it linked and undo takes the links back too."""
        for l in links:
            # a link from this space may point into another (read across)
            l.src_source = self.require_writable(l.src_source)
            l.dst_source = self.require_source(l.dst_source)
            if provenance is not None:
                l.attributes = {**(l.attributes or {}), Provenance.KEY: {
                    "run": provenance.run, "flow": provenance.flow, "at": provenance.at}}
        return self.store.upsert_links(links)

    def source_type(self, source_id: str) -> str:
        """The information source a KB source was added from — what decides how to
        fetch its nodes. The ``manual`` pseudo-source has none."""
        return next((s.type for s in self.sources() if s.id == source_id), "")

    def find_node(self, source: str, kind: str, node_id: str) -> GroundNode | None:
        return next((n for n in self.store.nodes(source=source, kind=kind, limit=5000)
                     if n.id == node_id), None)

    def refresh(self, source: str, kind: str, node_id: str) -> dict:
        """Re-read a node from the system it points at.

        Writes back only the node's *label* — title, uri, the source's own
        ``updated_at`` — and stamps ``fetched_at``. The body comes back for display
        and is deliberately **not** stored: a ground node is a pointer, and a copy
        would be stale the moment someone edits the original.
        """
        node = self.find_node(source, kind, node_id)
        if node is None:
            raise LookupError(f"No node {source}/{kind}/{node_id}")

        got = fetchers.fetch(node, self.source_type(source))
        node.title = got.title or node.title
        node.uri = got.uri or node.uri
        node.updated_at = got.updated_at or node.updated_at
        node.details = {**node.details, "fetched_at": utc_now()}
        self.store.upsert_nodes([node])
        return {"node": node.model_dump(), "live": got.fields}

    def remove_link(self, link: GroundLink) -> bool:
        link.src_source = self.require_writable(link.src_source)
        link.dst_source = self.ref_source(link.dst_source)
        return self.store.delete_link(link)

    def neighbours(self, source: str, kind: str, node_id: str,
                   relation: str = "") -> list[tuple[str, GroundNode]]:
        """The nodes one hop away, each with the relation that got us there.

        Reading a graph is walking it; a tool that can only list nodes makes the
        links invisible, which is the one thing this layer has that a list does
        not.
        """
        me = (source, kind, node_id)
        out: list[tuple[str, GroundNode]] = []
        for link in self.store.links_of(source, kind, node_id):
            if relation and link.kind != relation:
                continue
            src = (link.src_source, link.src_kind, link.src_id)
            other = (link.dst_source, link.dst_kind, link.dst_id) if src == me else src
            node = self.find_node(*other)
            if node is not None:
                arrow = f"{link.kind} →" if src == me else f"← {link.kind}"
                out.append((arrow, node))
        return out

    # ── administering the node types ─────────────────────────────────────────

    def save_node_type(self, node_type: NodeType) -> NodeType:
        """Create or replace a node type. Its id is slugified from the name once
        and then left alone, because nodes are keyed by it."""
        cfg = runtime.kb_config()
        node_type.id = node_type.id or slugify(node_type.name)
        # what normalise() would quietly undo is refused here, with the reason
        if node_type.category == "work":
            if node_type.persona:
                raise ValueError("A unit-of-work type belongs to no persona: the work "
                                 "breakdown is shared. Leave persona empty.")
            if node_type.parent_type:
                parents = {t.id for t in cfg.node_types if t.category == "work"}
                if node_type.parent_type not in parents - {node_type.id}:
                    raise ValueError(f"No unit-of-work type '{node_type.parent_type}' to be "
                                     f"the parent. Work types: "
                                     f"{', '.join(sorted(parents)) or 'none yet'}.")
        elif node_type.parent_type:
            raise ValueError("Only unit-of-work types have a parent_type.")
        if node_type.persona:
            personas = {p.id for p in cfg.personas if p.id}
            if node_type.persona not in personas:
                raise ValueError(f"No persona '{node_type.persona}'. Personas: "
                                 f"{', '.join(sorted(personas)) or 'none yet'}.")
        for f in node_type.fields:
            f.name = f.name or slugify(f.label).replace("-", "_")
            f.label = f.label or f.name.replace("_", " ").capitalize()
        existing = next((i for i, t in enumerate(cfg.node_types) if t.id == node_type.id), None)
        if existing is None:
            cfg.node_types.append(node_type)
        else:
            cfg.node_types[existing] = node_type
        runtime.save_kb_config(cfg)
        return node_type

    def delete_node_type(self, type_id: str, *, force: bool = False) -> int:
        """Remove a type. Refuses while nodes still use it unless forced — those
        nodes would keep their content but stop validating, which is a worse state
        than either keeping the type or deleting them first.

        Returns how many nodes are of that type.
        """
        cfg = runtime.kb_config()
        if not any(t.id == type_id for t in cfg.node_types):
            raise LookupError(f"No node type '{type_id}'")
        in_use = self.count_of_kind(type_id)
        if in_use and not force:
            raise ValueError(
                f"{in_use} node(s) are of type '{type_id}'. Delete them first, or pass "
                "force=true to keep them as untyped nodes.")
        cfg.node_types = [t for t in cfg.node_types if t.id != type_id]
        runtime.save_kb_config(cfg)
        return in_use

    def count_of_kind(self, kind: str) -> int:
        return next((row["nodes"] for row in self.store.kinds() if row["kind"] == kind), 0)

    def graph(self, *, source: str = "", kind: str = "", query: str = "",
              limit: int = 200, across: bool = False) -> dict:
        """Nodes plus the links *among them* — a picture with no dangling ends.

        Links whose other end is filtered out are dropped rather than drawn into
        nowhere; the node count tells the caller whether it is seeing everything.
        ``limit`` 0 or less returns every matching node. The explorer asks for
        that: its lanes are trees, and a cut-off by recency silently drops
        whole branches (the oldest ones, usually the work breakdown).
        """
        nodes = self.nodes(source=source, kind=kind, query=query, limit=limit, across=across)
        source = self.ref_source(source) if source else ""
        keys = {(n.source, n.kind, n.id) for n in nodes}
        away = set(self.other_spaces()) if not across else set()

        def shown(s, k, i) -> bool:
            return (s, k, i) in keys

        links = [
            # every link: the filter below keeps only those among the nodes
            # shown, and a cap here would drop arbitrary ones from the picture --
            # and those from a node shown into another space, so its links say
            # what it points at there (the other end opens by reading across)
            l for l in self.store.links(source=source, limit=0)
            if (shown(l.src_source, l.src_kind, l.src_id)
                and (shown(l.dst_source, l.dst_kind, l.dst_id) or l.dst_source in away))
            or (shown(l.dst_source, l.dst_kind, l.dst_id) and l.src_source in away)
        ]
        return {
            "nodes": [n.model_dump() for n in nodes],
            "links": [l.model_dump() for l in links],
            "kinds": self.store.kinds(),
            # what this space sees in all: the other spaces' nodes are not missing
            "total": sum(r["nodes"] for r in self.store.counts()["per_source"]
                         if across or r["source"] not in self.other_spaces()),
        }

    def available_sources(self) -> list[dict]:
        """The information sources that could be added, minus the ones already in."""
        taken = {s.type for s in self.sources()}
        return [s for s in runtime.available_sources() if s["type"] not in taken]

    @staticmethod
    def _prune_work_parents(cfg) -> bool:
        """Clear a work type's ``parent_type`` when it cannot be a level.

        Three ways it goes wrong: it names a type that is gone, it names one that
        is not a work type, or it closes a loop. A loop is the interesting one —
        nothing rejects it on the way in, and a tree walk over it never
        terminates, so it is cut here rather than guarded at every reader.
        """
        work = {t.id: t for t in cfg.node_types if t.category == "work" and t.id}
        changed = False
        for t in work.values():
            if t.parent_type and t.parent_type not in work:
                t.parent_type, changed = "", True
        # walk each chain; the first id met twice is standing in a loop
        for t in work.values():
            seen, cur = {t.id}, work.get(t.parent_type)
            while cur is not None:
                if cur.id in seen:
                    t.parent_type, changed = "", True
                    break
                seen.add(cur.id)
                cur = work.get(cur.parent_type)
        return changed

    @staticmethod
    def _normalise_flows(cfg) -> bool:
        """Give flows ids, and drop target references that no longer resolve.

        A flow pointing at a deleted persona is worse than one pointing at
        nothing: it would quietly write for a persona that is not there. The
        reference is cleared and the flow stays, so the user sees a flow missing
        its target rather than a flow that vanished.
        """
        changed = False
        seen: set[str] = set()
        persona_ids = {a.id for a in cfg.personas if a.id}
        type_ids = {t.id for t in cfg.node_types if t.id}
        for flow in cfg.flows:
            if not flow.id and flow.name:
                base = slugify(flow.name)
                candidate, n = base, 2
                while candidate in seen:
                    candidate, n = f"{base}-{n}", n + 1
                flow.id, changed = candidate, True
            seen.add(flow.id)
            kept = [a for a in flow.targets.personas if a in persona_ids]
            if kept != flow.targets.personas:
                flow.targets.personas, changed = kept, True
            kept_types = [t for t in flow.targets.node_types if t in type_ids]
            if kept_types != flow.targets.node_types:
                flow.targets.node_types, changed = kept_types, True
        return changed

    @staticmethod
    def _normalise_orchestrations(cfg) -> bool:
        """Give orchestrations and their states ids, and drop a state's flow
        when that flow is gone (the state then waits for a signal, which a
        person sees, rather than pointing at nothing)."""
        changed = False
        flow_ids = {f.id for f in cfg.flows if f.id}
        for o in cfg.orchestrations:
            if not o.id and o.name:
                o.id, changed = slugify(o.name), True
            for st in o.states:
                if not st.id and st.label:
                    st.id, changed = slugify(st.label), True
                if st.flow and st.flow not in flow_ids:
                    st.flow, changed = "", True
        return changed

    @staticmethod
    def _drop_duplicates(items: list) -> bool:
        """Keep the first entry for each id, in place; True when one was dropped."""
        seen: set[str] = set()
        kept = []
        for it in items:
            if it.id and it.id in seen:
                continue
            seen.add(it.id)
            kept.append(it)
        if len(kept) == len(items):
            return False
        items[:] = kept
        return True

    def normalise(self) -> None:
        """Fill in ids/labels the UI did not set, and drop ground data for sources
        that are no longer configured.

        The settings page saves the whole config document, so rows arrive here
        however the tab left them; this is the one place that makes them
        well-formed rather than every reader coping.
        """
        stored = runtime.kb_stored()
        catalog = {s["type"]: s["label"] for s in runtime.available_sources()}
        # a source's id is a node's source, and so is a space's: never the same
        seen: set[str] = {sp.id for sp in stored.spaces if sp.id}
        # a config still using a renamed key (``topic_types``, ``audiences``), or
        # from before spaces, is rewritten by the save at the end of this method
        changed = runtime.has_legacy_keys() or runtime.stored_differs(stored)

        for src in stored.sources:
            if not src.id:
                base = slugify(src.type or src.label)
                candidate, n = base, 2
                while candidate in seen:
                    candidate, n = f"{base}-{n}", n + 1
                src.id, changed = candidate, True
            if not src.label:
                src.label, changed = catalog.get(src.type, src.type), True
            if not src.added_at:
                src.added_at, changed = utc_now(), True
            seen.add(src.id)

        if self._normalise_spaces(stored, {s.id for s in stored.sources}):
            changed = True
        for sp in stored.spaces:
            if self._normalise_space(sp):
                changed = True

        if changed:
            runtime.save_stored(stored)

        # a source removed from the list takes its ground data with it, and a
        # space removed takes its topics -- but what an agent wrote before spaces
        # (``manual``) is never an orphan; the store moves it into the first space
        keep = ({s.id for s in stored.sources} | {s.id for s in stored.spaces}
                | {spaces.LEGACY_SOURCE})
        for row in self.store.counts()["per_source"]:
            if row["source"] not in keep:
                self.store.clear_source(row["source"])
        # and a removed space's branches, runs, instances and chats
        self.store.forget_spaces({s.id for s in stored.spaces})

    @staticmethod
    def _normalise_spaces(stored, source_ids: set[str]) -> bool:
        """Give spaces ids and names. An id is unique, and is neither a source's
        (a node's source says which it belongs to) nor ``manual``: one written
        by hand that is gets a suffix; a second space of one id is dropped."""
        changed = False
        reserved = set(source_ids) | {spaces.LEGACY_SOURCE}
        taken = reserved | {sp.id for sp in stored.spaces if sp.id and sp.id not in reserved}
        for sp in stored.spaces:
            if not sp.id or sp.id in reserved:
                base = slugify(sp.id or sp.name or spaces.FIRST_SPACE_NAME)
                candidate, n = base, 2
                while candidate in taken:
                    candidate, n = f"{base}-{n}", n + 1
                sp.id, changed = candidate, True
                taken.add(sp.id)
            if not sp.name:
                sp.name, changed = sp.id.replace("-", " ").capitalize(), True
        kept, ids = [], set()
        for sp in stored.spaces:
            if sp.id in ids:
                changed = True
                continue
            ids.add(sp.id)
            kept.append(sp)
        if not kept:                 # a workspace always has a space
            kept, changed = [KbSpace(id=spaces.FIRST_SPACE_ID,
                                     name=spaces.FIRST_SPACE_NAME)], True
        stored.spaces[:] = kept
        return changed

    def _normalise_space(self, cfg) -> bool:
        """One space's personas, node types, flows and orchestrations made
        well-formed. ``cfg`` is the :class:`KbSpace`; the helpers read the same
        attribute names off it as off the configuration view."""
        changed = False
        for aud in cfg.personas:
            if not aud.id and aud.name:
                aud.id, changed = slugify(aud.name), True

        # the same persona or type added twice is kept once (the first): two
        # entries with one id would show twice and answer to the same name
        if self._drop_duplicates(cfg.personas):
            changed = True

        persona_ids = {a.id for a in cfg.personas if a.id}
        for nt in cfg.node_types:
            if not nt.id and nt.name:
                nt.id, changed = slugify(nt.name), True
        if self._drop_duplicates(cfg.node_types):
            changed = True
        for nt in cfg.node_types:
            # a persona that was deleted leaves its types shared rather than
            # pointing at nothing
            if nt.persona and nt.persona not in persona_ids:
                nt.persona, changed = "", True
            # the work breakdown belongs to no persona, and only it has levels
            if nt.category == "work":
                if nt.persona:
                    nt.persona, changed = "", True
                # a state with neither id nor label is none (a form's blank row)
                if any(not (s.id or s.label) for s in nt.states):
                    nt.states = [s for s in nt.states if s.id or s.label]
                    changed = True
            elif nt.parent_type:
                nt.parent_type, changed = "", True
            # a field needs both halves: the key it is stored under and the label
            # the form shows. Either one implies the other.
            for f in nt.fields:
                if not f.name and f.label:
                    f.name, changed = slugify(f.label).replace("-", "_"), True
                if not f.label and f.name:
                    f.label, changed = f.name.replace("_", " ").capitalize(), True

        if self._prune_work_parents(cfg):
            changed = True

        if self._normalise_flows(cfg):
            changed = True

        if self._normalise_orchestrations(cfg):
            changed = True
        # what a flow wrote as `manual` (before spaces, or from a pack) is this
        # space: say so, so settings shows the ref that is stored
        for flow in cfg.flows:
            if flow.work_item.source in ("", spaces.LEGACY_SOURCE) and flow.work_item.kind:
                flow.work_item.source, changed = cfg.id, True
            if flow.source.kind == "kb_source" and flow.source.ref == spaces.LEGACY_SOURCE:
                flow.source.ref, changed = cfg.id, True
        return changed

    # ── flows ─────────────────────────────────────────────────────────────────
    #
    # A flow is configuration, so it is read from the config slice like the
    # sources and the node types; only its *runs* live in the store. See
    # ``docs/knowledge-flows-proposal.md``.

    def flows(self) -> list[KbFlow]:
        return runtime.kb_config().flows

    def flow(self, flow_id: str) -> KbFlow | None:
        return next((f for f in self.flows() if f.id == flow_id), None)

    def require_flow(self, flow_id: str) -> KbFlow:
        found = self.flow(flow_id)
        if found is None:
            known = ", ".join(f.id for f in self.flows()) or "none configured"
            raise LookupError(f"No flow {flow_id!r}. Flows: {known}")
        return found

    def flow_personas(self, flow: KbFlow) -> list[Persona]:
        """The target personas, in configured order — that order is meaningful
        everywhere else, so a prompt should not list them in a third one."""
        wanted = set(flow.targets.personas)
        return [a for a in self.personas() if a.id in wanted]

    def flow_types(self, flow: KbFlow) -> list[NodeType]:
        """The types the flow may write.

        Empty ``targets.node_types`` means every type belonging to a target
        persona, plus the shared ones (a type with no persona is by definition
        available to all of them). That default is what keeps a flow in step with
        the Node types tab: add a type for a persona and the flow that writes
        for that persona can use it, with no second edit here.
        """
        auds = {a.id for a in self.flow_personas(flow)}
        picked = set(flow.targets.node_types)
        # A work type belongs to no persona, so the persona default can never
        # reach one; it is in scope only when the flow names it. That is what
        # lets a planning flow write the breakdown without every analysis flow
        # suddenly being allowed to add sprints.
        in_scope = [t for t in self.node_types()
                    if (t.category != "work" and (not t.persona or t.persona in auds))
                    or (t.category == "work" and t.id in picked)]
        if picked:
            in_scope = [t for t in in_scope if t.id in picked]
        if not flow.targets.allow_new_folders:
            in_scope = [t for t in in_scope if t.category != "folder"]
        return in_scope

    def flow_issues(self, flow: KbFlow, work_item: str | None = None) -> list[str]:
        """What stops this flow being runnable, in the words the user needs.

        ``work_item`` is the one a run is about to be given; leave it ``None``
        when describing the flow rather than starting it.

        Returned rather than raised: a half-configured flow is a normal state to
        be in while writing one, and the tab shows these next to the thing that
        is wrong.
        """
        if work_item is not None:
            work_item = self.ref(work_item)
        issues: list[str] = []
        if not flow.name.strip():
            issues.append("It has no name.")
        if flow.kind in ("analyse", "act") and not flow.prompt.instructions.strip():
            issues.append("The prompt has no instructions — there is nothing to ask.")
        if flow.kind == "ingest" and not flow.adapter:
            issues.append("No ingest adapter is set, and none exist yet — an "
                          "analysis flow is the only kind that can run today.")
        writes_work = any(t.category == "work" for t in self.flow_types(flow))
        acts = flow.kind == "act"
        if not flow.targets.personas and not acts:
            # the work breakdown is written for nobody in particular
            if not writes_work:
                issues.append("No target persona, so there is nobody to write for.")
        else:
            known = {a.id for a in self.personas()}
            gone = [a for a in flow.targets.personas if a not in known]
            if gone:
                issues.append("Persona(s) no longer configured: " + ", ".join(gone) + ".")
        if not self.flow_types(flow) and not acts:
            issues.append("No node types are in scope, so there is nothing it could "
                          "write. Give the target personas some types under Node types.")
        if not flow.source.ref and not acts:
            issues.append("No source is named, so there is nothing to read.")
        # A flow that needs a work item and has no default is not broken: it is
        # one that is run per item (from the work breakdown's menu). It only
        # cannot run when a run is asked for without one.
        if (flow.work_item.required and not flow.work_item.ref()
                and work_item is not None and not work_item):
            issues.append("This flow needs a unit of work for each run and none was "
                          "given. Start it from the work item's menu, or pass work_item.")
        return issues

    # ── the prompt ────────────────────────────────────────────────────────────

    def render_prompt(self, flow: KbFlow, *, work_item: str = "",
                      mode: str = "brief") -> str:
        """The whole prompt, as the AI will see it.

        The user owns ``flow.prompt.instructions``; everything else is generated,
        which is the point. The type contract and the reply format are what make
        an answer usable, and they have to track the Node types tab rather than a
        copy somebody pasted into the instructions months ago.

        ``mode`` changes only the closing section: a ``brief`` is carried out by
        an external AI that has the MCP tools in hand, while a ``run`` (not built
        yet) answers to the server with one JSON document.
        """
        out: list[str] = [f"# {flow.name or flow.id}", ""]
        if flow.description.strip():
            out += [flow.description.strip(), ""]
        if flow.prompt.instructions.strip():
            out += ["## What to do", "", flow.prompt.instructions.strip(), ""]

        out += ["## What you are reading", "", self._source_line(flow), ""]

        auds = self.flow_personas(flow)
        if auds:
            out += ["## Who this is for", ""]
            for a in auds:
                out.append("- **" + a.name + "**"
                           + (" — " + a.description if a.description else ""))
            out += ["",
                    "Write for these personas in their own language. The same "
                    "finding may be worth writing twice, differently, rather than "
                    "once in a way neither persona would have chosen.", ""]

        out += ["## What you may write", ""]
        types = self.flow_types(flow)
        if not types and flow.kind == "act":
            out += ["Nothing: this flow acts outside the knowledge base (it builds, tests "
                    "or merges). Its outcome is what counts: finish the run `ok` when the "
                    "work reached its goal, `failed` with what went wrong when it did not.",
                    ""]
        elif not types:
            out += ["(no node types are in scope, so nothing can be written)", ""]
        for t in types:
            out += self._type_block(t)
        if types:
            out += self._document_block()

        if types or flow.kind != "act":
            out += self._placement_block(flow, work_item)

        existing = self._existing_titles(flow)
        if existing:
            out += ["## Already written by this flow", "",
                    "Update these rather than writing a second copy — re-using an "
                    "id overwrites the node it belongs to.", ""]
            out += ["- `" + k + "/" + i + "` — " + t for k, i, t in existing]
            out.append("")

        out += self._stages_block(flow, mode)
        out += self._reply_block(flow, mode)
        return "\n".join(out).rstrip() + "\n"

    def _stages_block(self, flow: KbFlow, mode: str) -> list[str]:
        """The run's large blocks, and how to say which one it is in.

        Only a brief reports: it is carried out by somebody else, out of sight,
        and the report is the only way the breakdown learns where it stands.
        """
        if mode != "brief":
            return []
        stages = [st for st in flow.prompt.stages if st.id]
        out = ["## Reporting progress", ""]
        if stages:
            out += ["This flow runs in " + str(len(stages)) + " stages. When you "
                    "start one, report it — once per stage, not per step inside it:", ""]
            for i, st in enumerate(stages, 1):
                out.append(f"{i}. `{st.id}` — **{st.label or st.id}**"
                           + (" — " + st.description.strip() if st.description.strip() else ""))
            out += ["", "```",
                    'kb_flow("progress", id="<run id>", stage="' + stages[0].id + '",',
                    '        message="<one line: what you are about to do>")',
                    "```", ""]
        else:
            out += ["When the run moves on to a large new block of work, say so in "
                    "one line — a handful of reports for the whole run, not one per "
                    "step:", "", "```",
                    'kb_flow("progress", id="<run id>", stage="<short label>",',
                    '        message="<one line: what you are about to do>")',
                    "```", ""]
        out += ["The report is timestamped and shown on the unit of work this run is "
                "about, so a person can see what is happening without asking.", ""]
        out += self._outcome_block(flow)
        return out

    def _outcome_block(self, flow: KbFlow) -> list[str]:
        """How the run ends, and what each ending does to its unit of work.

        Said in the brief because the worker is the only one who knows whether
        the work reached its goal — and a run that always ends "ok" moves a step
        to done with a test still failing.
        """
        names = {s.id: s.label or s.id for t in self.node_types()
                 if t.id == flow.work_item.kind for s in self.work_states(t)}
        wi = flow.work_item
        out = ["## Finishing the run", "",
               "Close the run with its outcome:", "",
               "```",
               'kb_flow("finish", id="<run id>", outcome="ok", message="<what was done>")',
               'kb_flow("finish", id="<run id>", outcome="failed", message="<what failed, and why>")',
               "```", "",
               "`ok` means the work reached its goal as these instructions define it. "
               "`failed` means it was carried out but did not: say exactly what failed "
               "in `message` — that message is what the next run picks up. Do not "
               "finish `ok` with something you know is not working."]
        moves = []
        if wi.on_finish:
            moves.append(f"`ok` moves it to **{names.get(wi.on_finish, wi.on_finish)}**")
        if wi.on_fail:
            moves.append(f"`failed` moves it to **{names.get(wi.on_fail, wi.on_fail)}**")
        if moves:
            out += ["", "For the unit of work this run is about: " + "; ".join(moves) + "."]
        return out + [""]

    def flow_source_label(self, flow: KbFlow) -> str:
        """What this flow reads, in one line. Shared by the rendered prompt
        and the MCP description so the two can never drift apart."""
        return self._source_line(flow)

    def _source_line(self, flow: KbFlow) -> str:
        kinds = {"repo": "the git repository", "kb_source": "the knowledge-base source",
                 "context": "the context", "web": "the website"}
        what = kinds.get(flow.source.kind, flow.source.kind) + " `" + flow.source.ref + "`"
        bits = [k + ": " + self._scope_value(v) for k, v in flow.source.scope.items()
                if v not in ("", [], {}, None)]
        line = what + (" (" + ", ".join(bits) + ")" if bits else "") + "."
        if flow.source.kind == "repo":
            # an AI carrying out the brief works on its user's machine: say where
            # the repository is there (Workspace settings -> Information Sources -> Git Repos)
            git_repos = runtime.services().get("git_repos")
            repo = git_repos.find(flow.source.ref) if git_repos else None
            if repo is not None and repo.local_location:
                line += f" On your machine it is at {repo.local_location}."
        return line

    @staticmethod
    def _scope_value(value) -> str:
        """One scope entry, as a reader rather than a repr.

        A list of globs went in as ``['*.pas', '*.dpr']`` — Python's own
        punctuation, in the middle of a prompt that is otherwise written for a
        reader. It goes out as `` `*.pas`, `*.dpr` ``.
        """
        if isinstance(value, (list, tuple)):
            return ", ".join("`" + str(v) + "`" for v in value)
        return "`" + str(value) + "`"

    def _type_block(self, t: NodeType) -> list[str]:
        """One node type, described well enough to write an instance of it.

        This is where the Node types tab stops being documentation: what it says
        is the specification the AI answers to, so a type with no description
        produces topics with no shape.
        """
        who = "everyone" if not t.persona else next(
            (a.name for a in self.personas() if a.id == t.persona), t.persona)
        out = ["### " + (t.name or t.id), "",
               "`kind: " + t.id + "` · " + t.category + " · for " + who]
        if t.description.strip():
            out += ["", t.description.strip()]
        if t.form == "structured":
            short = [f for f in t.fields if not f.is_section]
            long = [f for f in t.fields if f.is_section]
            if short:
                out += ["", "Short values, in `content.fields`:", ""]
                for fld in short:
                    req = ", required" if fld.required else ""
                    hint = " — " + fld.hint if fld.hint else ""
                    out.append("- `" + fld.name + "` (" + fld.type + req + ")" + hint)
            if long:
                out += ["", "The long text, in `content.document` — one top-level "
                        "section each, titled exactly so, in this order (leave out "
                        "a section with nothing to say):", ""]
                for fld in long:
                    req = ", required" if fld.required else ""
                    hint = " — " + fld.hint if fld.hint else ""
                    what = {"plantuml": ", a PlantUML diagram",
                            "mermaid": ", a Mermaid diagram",
                            "wireframe": ", a wireframe sketch"}.get(fld.type, "")
                    out.append("- **" + (fld.label or fld.name) + "** (field `"
                               + fld.name + "`" + what + req + ")" + hint)
            if not t.fields:
                out.append("- (no fields defined — an instance would be a bare name)")
        else:
            out += ["", "The text goes in `content.document`."]
            if t.template.strip():
                out += ["", "Start from this outline — each heading is a section, "
                        "the text under it the fragments:", "",
                        "```", t.template.rstrip(), "```"]
        out.append("")
        return out

    def _document_block(self) -> list[str]:
        """The document format, said once for every type above."""
        return [
            "### The document format", "",
            "`content.document` is the topic as a tree a person can find their way "
            "in: titled sections, and as leaves markdown fragments. The section "
            "titles are its table of contents.", "",
            "```json",
            '[{"type": "section", "title": "Backend", "children": [',
            '   {"type": "markdown", "text": "One feature package, `auth`."},',
            '   {"type": "section", "title": "REST endpoints", "children": [',
            '      {"type": "markdown", "text": "- `POST /api/auth/sign-in` ..."}]}]}]',
            "```", "",
            "- Every section has a title; a section may hold fragments and "
            "subsections in any order — an introduction before its subsections.",
            "- No headings inside a fragment: a heading is a section. Where a text "
            "would say \"Rules:\" on a line of its own, that is a subsection "
            "titled \"Rules\".",
            "- Keep a fragment to one paragraph, list, table or code block; split "
            "a long text into subsections rather than one long fragment.",
            "- A diagram is a fragment of its own: `{\"type\": \"plantuml\", "
            "\"text\": \"@startuml\\n...\\n@enduml\"}` — the whole source, "
            "`@startuml` on the first line and `@enduml` on the last. A section "
            "marked *a PlantUML diagram* holds one, with markdown fragments around "
            "it to explain it.",
            "- A Mermaid diagram the same way: `{\"type\": \"mermaid\", "
            "\"text\": \"erDiagram\\n...\"}` — the source alone, starting with "
            "the diagram's kind (`erDiagram`, `flowchart LR`, `stateDiagram-v2`), "
            "no code fence. A section marked *a Mermaid diagram* holds one.",
            "- A screen as a sketch — abstract, not a screenshot: `{\"type\": "
            "\"wireframe\", \"text\": \"{+\\n  Email | \\\"you@x.com  \\\"\\n"
            "  [Log in] | [Cancel]\\n}\"}` — PlantUML Salt. Rows are lines, cells "
            "are split by `|`; `[Button]`, `\"input   \"` (the spaces set its width), "
            "`^Dropdown^`, `[ ] check` / `[X] checked`, `( ) radio` / `(X) chosen`, "
            "plain text (`<b>bold</b>`), `.` an empty cell, separator rows `--` `==` "
            "`..`; blocks nest: `{+` framed, `{#` a table, `{^\"Title\"` a group box, "
            "`{/ Tab A | Tab B }` tabs, `{* Home | Search }` a menu bar, `{T` a tree "
            "(`+ item`, `++ child`). Sketch what the screen holds and where, with "
            "realistic sample values; leave out styling. A section marked *a "
            "wireframe sketch* holds one.",
            "- Writes are checked: text in `content.body`, a long-text value in "
            "`content.fields` or a heading in a fragment is refused, with the reason.",
            "",
        ]

    def _placement_block(self, flow: KbFlow, work_item: str) -> list[str]:
        """Where what is written goes: its folder or the level above it, and the
        work it is about."""
        types = self.flow_types(flow)
        work = [t for t in types if t.category == "work"]
        out = ["## Where it goes", ""]
        if len(work) < len(types):
            out.append("Every topic sits in exactly one folder of its persona, linked "
                       "`folder --contains--> topic`. That link is what the explorer "
                       "builds each persona's tree from, so a topic without one is "
                       "written but not reachable.")
            if not flow.targets.allow_new_folders:
                out.append("Use the folders that already exist; do not create new ones.")
            out.append("")
        if work:
            # the breakdown is a tree like a persona's, built from the same
            # relation — only its shape comes from the declared levels
            names = {t.id: t.name or t.id for t in self.node_types()}
            out.append("A unit of work sits under the level above it, linked "
                       "`parent --contains--> item`. That is what the work breakdown "
                       "is drawn from, so an item without one is written but not "
                       "reachable:")
            for t in work:
                above = (f"a `{t.parent_type}` ({names.get(t.parent_type, t.parent_type)})"
                         if t.parent_type else "nothing — it is a top level")
                out.append(f"- a `{t.id}` ({t.name or t.id}) sits under {above}")
            out.append("")
        ref = work_item or flow.work_item.ref()
        rel = flow.work_item.relation or "about"
        if ref:
            # Stated, not asked for: Roadmap links the run's output itself (see
            # ``link_run_output``). Telling the writer to do it as well would be
            # one more thing for it to get wrong, and the link is the same either
            # way — but it still needs to know, because what it writes should be
            # about that unit of work.
            # units of work are placed with `contains` and get no `about` link
            # (see ``link_run_output``), so the sentence must not promise one
            if work and len(work) == len(types):
                about = ("Everything written under this run belongs to `" + ref + "`: "
                         "place the units of work under it as described above. Roadmap "
                         "adds no `" + rel + "` link to a unit of work — `contains` "
                         "already says where it sits.")
            else:
                about = ("Every topic written under this run is about `" + ref + "`. "
                         "Roadmap adds the `" + rel + "` link itself, so you do not have "
                         "to — but write with that unit of work in mind, and leave out "
                         "what does not belong to it."
                         + (" Units of work get no such link: `contains` already says "
                            "where they sit." if work else ""))
            out += ["## What it is about", "", about, ""]
        elif flow.work_item.required:
            out += ["## What it is about", "",
                    "This flow requires a unit of work and none was given for this "
                    "run. Ask for one before writing anything.", ""]
        return out

    def _existing_titles(self, flow: KbFlow, limit: int = 40) -> list[tuple]:
        """What this flow has written before, so a re-run updates in place
        instead of writing a parallel set under new ids."""
        seen: list[tuple] = []
        for run in self.store.flow_runs(flow.id, limit=10):
            for n in self.store.nodes_of_run(run.id, limit=limit):
                seen.append((n.kind, n.id, n.title or n.id))
                if len(seen) >= limit:
                    return seen
        return seen

    def _content_json_example(self, flow: KbFlow) -> str:
        """The `content_json` argument for a `kb_write` call, by the same rule as
        :meth:`_content_example`."""
        doc = '"document": [{"type": "section", "title": "...", "children": [...]}]'
        if self._forms(flow) == {"unstructured"}:
            return "{" + doc + "}"
        return '{"fields": {"<field>": "..."}, ' + doc + "}"

    def _content_example(self, flow: KbFlow) -> str:
        """The `content` a node of this flow's types actually takes.

        A skeleton showing `body` in front of a page that has just said "every
        instance answers exactly these, in `content.fields`" is a prompt arguing
        with itself, and the writer has to pick a side. So the example follows
        the types: fields, body, or both where the flow may write either.
        """
        return '"content": ' + self._content_json_example(flow) + "}],"

    def _forms(self, flow: KbFlow) -> set:
        return {t.form for t in self.flow_types(flow)}

    def _reply_block(self, flow: KbFlow, mode: str) -> list[str]:
        if mode == "brief":
            return [
                "## How to write your findings back", "",
                "Use the Roadmap MCP tools, one node at a time. They validate each "
                "node against the types above and say what is wrong, which a single "
                "large document cannot.", "",
                "```",
                'kb_write("add_node", kind="<type>", id="<slug>", title="...",',
                "         content_json='" + self._content_json_example(flow)
                + "', run=\"<run id>\")",
                'kb_write("link", kind="<folder type>", id="<folder>",',
                '         dst_kind="<type>", dst_id="<slug>", relation="contains")',
                "```", "",
                "Pass `run` on every `add_node`, `update` and `link` call. It records "
                "that this flow produced the node or the link, and it is how the "
                "whole run is reviewed — or undone — later: undo deletes what the run "
                "created, puts back what it changed, and removes the links it made. "
                "To change a topic that already exists, prefer `update` with only the "
                "fields you change over rewriting it with `add_node`.",
                "",
            ] + self._forms_note(flow) + [
                "Write at most " + str(flow.limits.max_nodes) + " nodes.", "",
            ]
        out = [
            "## How to reply", "",
            "One JSON object and nothing else:", "",
            "```json",
            '{"nodes": [{"kind": "...", "id": "...", "title": "...",',
            "            " + self._content_example(flow),
            ' "links": [{"src_kind": "...", "src_id": "...",',
            '            "dst_kind": "...", "dst_id": "...", "kind": "contains"}]}',
            "```", "",
        ]
        out += self._forms_note(flow)
        out += ["At most " + str(flow.limits.max_nodes) + " nodes.", ""]
        return out

    def _forms_note(self, flow: KbFlow) -> list[str]:
        """Said in prose, and only when the flow may write both forms.

        The skeleton above shows one shape. When a flow has a structured type and
        an unstructured one — a folder and the topics in it, which is the normal
        case — no single skeleton is right, and a comment inside a JSON fence
        would not be JSON.
        """
        if len(self._forms(flow)) < 2:
            return []
        return ["Only a structured type has `\"fields\"`; for the others leave "
                "it out, as their descriptions above say.", ""]

    # ── runs ──────────────────────────────────────────────────────────────────

    def start_flow_run(self, flow: KbFlow, trigger: dict, *,
                       work_item: str = "") -> FlowRun:
        """Open a run record. A brief gets one too — that is what makes work done
        by an external AI appear in the history alongside everything else."""
        work_item = self.ref(work_item)
        if current_branch.get():
            # what the run writes goes to the branch it was started in
            trigger = {**trigger, "branch": current_branch.get()}
        # ... and to the space (the flow is that space's)
        trigger = {**trigger, "space": self.MANUAL_SOURCE}
        run = FlowRun(
            id="run_" + uuid.uuid4().hex[:12],
            flow_id=flow.id, flow_version=flow.version,
            prompt_version=flow.prompt.version, trigger=trigger,
            work_item=work_item or flow.work_item.ref(),
            started_at=utc_now(), status="briefed",
        )
        run = self.store.start_flow_run(run)
        self._log_work_item(run, {"event": "started", "trigger": trigger.get("mode", "")})
        self._move_work_item(run, flow.work_item.on_start)
        return run

    #: how a run can end. ``failed`` is an outcome — the work was done and did
    #: not reach its goal, so the item moves to ``on_fail``; ``error`` is the run
    #: itself breaking (a provider down), which says nothing about the work and
    #: moves nothing.
    RUN_OUTCOMES = ("ok", "failed", "error")

    def finish_run(self, run_id: str, *, status: str = "ok", message: str = "") -> FlowRun | None:
        """Close a run and move its work item: to the flow's ``on_finish`` when
        it went well, to ``on_fail`` when its outcome is ``failed``. Every way a
        run ends comes through here — a brief's ``finish``, the HTTP route, the
        server-side runner — so the breakdown moves the same whichever way the
        work was done."""
        with on_space(self.run_space(run_id) or spaces.current_space.get()):
            return self._finish_run(run_id, status=status, message=message)

    def _finish_run(self, run_id: str, *, status: str, message: str) -> FlowRun | None:
        self.store.finish_flow_run(run_id, status=status, message=message)
        run = self.store.flow_run(run_id)
        if run is not None:
            self._log_work_item(run, {"event": "finished", "status": status,
                                      "message": message, "nodes": run.nodes,
                                      "links": run.links})
        # the outcome is a signal to the orchestration this run works for, if
        # any; then that machine decides where the work item goes, not the flow
        handled = run is not None and (
            self.orchestrator.on_run_finished(run, status, message) is not None
            or (run.trigger or {}).get("mode") == "orchestration")
        flow = self.flow(run.flow_id) if run is not None and not handled else None
        if run is not None and flow is not None:
            if status == "ok":
                self._move_work_item(run, flow.work_item.on_finish)
            elif status == "failed":
                # the reason goes with the move: the state log is where a person
                # looks for why a step went back
                self._move_work_item(run, flow.work_item.on_fail, note=message[:300])
        return run

    # ── what a running flow is doing ──────────────────────────────────────────

    #: where a unit of work keeps the coarse log of the flows run about it
    PROGRESS_KEY = "progress"
    #: how much of it — a few hundred lines is a long project, not a debug trace
    PROGRESS_DEPTH = 200

    def report_progress(self, run_id: str, stage: str = "", message: str = "") -> dict:
        """A run reports that it has started one of its stages.

        Written twice: onto the run, which is where the run's own story is read
        from, and onto the unit of work the run is about, which is what a person
        looking at the breakdown sees — "step-development, at *Write the
        backend* since 10:42". A flow that declares stages accepts only those;
        one that declares none takes a free-form label, so a long one-block run
        can still say where it is.
        """
        run = self.store.flow_run(run_id)
        if run is None:
            raise LookupError(f"No run `{run_id}`.")
        if run.finished_at:
            raise ValueError(f"Run `{run_id}` is already closed ({run.status}).")
        flow = self.flow(run.flow_id)
        stages = [st for st in (flow.prompt.stages if flow else []) if st.id]
        label = stage
        index = 0
        if stages:
            ids = [st.id for st in stages]
            if stage not in ids:
                raise ValueError(f"`{stage}` is not a stage of `{run.flow_id}`; its "
                                 "stages are " + ", ".join(f"`{i}`" for i in ids) + ".")
            label = stages[ids.index(stage)].label or stage
            index = ids.index(stage) + 1
        elif not stage and not message:
            raise ValueError("Say which stage, or what is happening, in `message`.")
        entry = {"at": utc_now(), "stage": stage, "label": label, "message": message,
                 "index": index, "count": len(stages)}
        self.store.add_run_progress(run_id, entry)
        self._log_work_item(run, {"event": "stage", **{k: v for k, v in entry.items()
                                                      if k != "at"}})
        return entry

    def _log_work_item(self, run: FlowRun, entry: dict) -> None:
        """Add one line to the progress log of the run's unit of work, if there
        is one. Like the state, the log is reporting: a run without a work item,
        or whose item is gone, is not worth failing over."""
        parts = (run.work_item or "").split("/", 2)
        if len(parts) != 3 or not all(parts):
            return
        node = self.store.get_node(*parts)
        if node is None:
            return
        flow = self.flow(run.flow_id)
        log = list((node.details or {}).get(self.PROGRESS_KEY) or [])
        log.append({"at": utc_now(), "run": run.id, "flow": run.flow_id,
                    "flow_name": (flow.name if flow else "") or run.flow_id, **entry})
        details = {**node.details, self.PROGRESS_KEY: log[-self.PROGRESS_DEPTH:]}
        # straight to the store, as a change of state is: reporting, not content
        self._write_work(node.model_copy(update={"details": details}))

    def _move_work_item(self, run: FlowRun, state: str, note: str = "") -> None:
        """Set the run's work item to ``state``, if both are there. A state the
        item's type does not have, or an item that is gone, is not worth failing
        a run over: the run is the work, the state only reports on it."""
        parts = (run.work_item or "").split("/", 2)
        if not state or len(parts) != 3 or not all(parts):
            return
        try:
            self.set_state(*parts, state, by={"run": run.id, "flow": run.flow_id},
                           note=note, one_step=False)
        except ValueError:
            pass

    # ── the state of the work breakdown ───────────────────────────────────────

    #: where a unit of work keeps its state and how it got there
    STATE_KEY = "state"
    #: the lifecycle of a work type that declares none
    DEFAULT_STATES = [WorkState(id="planned", label="Planned"),
                      WorkState(id="in-progress", label="In progress"),
                      WorkState(id="done", label="Done")]

    def work_states(self, t: NodeType) -> list[WorkState]:
        return [s for s in t.states if s.id] or self.DEFAULT_STATES

    def set_state(self, source: str, kind: str, node_id: str, to: str, *,
                  by: dict | None = None, note: str = "",
                  one_step: bool = True) -> GroundNode:
        """Move a unit of work to another state of its type's lifecycle.

        A person steps one state at a time, forward or back (``one_step``); a
        flow's ``on_start``/``on_finish`` may jump, because it knows what its run
        has just done. Every move is logged on the node with when, from where
        and by what.
        """
        source = self.require_writable(source)
        node = self.store.get_node(source, kind, node_id)
        if node is None:
            raise ValueError(f"No node `{source}/{kind}/{node_id}`.")
        t = self.node_type(kind)
        if t is None or t.category != "work":
            raise ValueError(f"`{kind}` is not a work type, so it has no states.")
        ids = [s.id for s in self.work_states(t)]
        if to not in ids:
            raise ValueError(f"`{to}` is not a state of `{kind}`; its states are "
                             + ", ".join(ids) + ".")
        current = (node.details.get(self.STATE_KEY) or {}).get("value") or ids[0]
        if current not in ids:
            current = ids[0]
        if one_step and abs(ids.index(to) - ids.index(current)) > 1:
            near = [ids[i] for i in (ids.index(current) - 1, ids.index(current) + 1)
                    if 0 <= i < len(ids)]
            raise ValueError(f"One state at a time: from `{current}` it can go to "
                             + " or ".join(f"`{s}`" for s in near) + ".")
        at = utc_now()
        state = dict(node.details.get(self.STATE_KEY) or {})
        log = list(state.get("log") or [])
        log.append({"to": to, "from": current, "at": at, "note": note, **(by or {})})
        details = {**node.details, self.STATE_KEY: {"value": to, "since": at, "log": log[-50:]}}
        node = node.model_copy(update={"details": details})
        # straight to the store: a change of state is not a change of content,
        # so it neither stamps provenance nor keeps a version for undo
        self._write_work(node)
        return node

    def _write_work(self, node: GroundNode) -> None:
        """Write a unit of work's state or log where the item lives: the work
        breakdown is shared, so an item on main moves on main even when the
        move comes from inside a branch."""
        here = not current_branch.get() or self.store.in_overlay(node.source, node.kind, node.id)
        with on_branch(current_branch.get() if here else ""):
            self.store.upsert_nodes([node])

    def work_status(self) -> dict:
        """State, progress and running flows of every unit of work, by key.

        A leaf's progress is how far along its lifecycle it is. An item with
        units of work under it (a project, a phase) is measured by them: its
        progress is theirs averaged, and its state follows — the first state
        while none has started, the last once all are finished, the second in
        between — so the whole breakdown moves as its leaves do.
        """
        types = {t.id: t for t in self.node_types() if t.category == "work"}
        nodes = {f"{n.source}/{n.kind}/{n.id}": n
                 for n in self.store.nodes(limit=100_000) if n.kind in types}
        kids: dict[str, list[str]] = {k: [] for k in nodes}
        for l in self.store.links(limit=1_000_000):
            src = f"{l.src_source}/{l.src_kind}/{l.src_id}"
            dst = f"{l.dst_source}/{l.dst_kind}/{l.dst_id}"
            if l.kind == "contains" and src in nodes and dst in nodes:
                kids[src].append(dst)
        flows = {f.id: f.name or f.id for f in self.flows()}
        running: dict[str, list[dict]] = {}
        #: the newest finished run per item — "it was sent back" shows from this
        last: dict[str, dict] = {}
        for r in self.store.flow_runs(limit=1000):
            # newest first, so on a tie in finished_at the later run already holds it
            if (r.finished_at and r.work_item in nodes
                    and r.finished_at > last.get(r.work_item, {}).get("finished_at", "")):
                last[r.work_item] = {"run": r.id, "flow": r.flow_id,
                                     "flow_name": flows.get(r.flow_id, r.flow_id),
                                     "status": r.status, "finished_at": r.finished_at,
                                     "message": (r.message or "")[:300]}
            if not r.finished_at and r.status in ("briefed", "running") and r.work_item in nodes:
                running.setdefault(r.work_item, []).append({
                    "run": r.id, "flow": r.flow_id, "flow_name": flows.get(r.flow_id, r.flow_id),
                    "started_at": r.started_at,
                    # where it is: the last stage it reported, if any
                    "stage": r.progress[-1] if r.progress else None})

        out: dict[str, dict] = {}

        def visit(key: str, path: frozenset) -> dict:
            if key in out:
                return out[key]
            n = nodes[key]
            states = self.work_states(types[n.kind])
            ids = [s.id for s in states]
            stored = n.details.get(self.STATE_KEY) or {}
            below = [visit(k, path | {key}) for k in kids[key] if k not in path]
            if below:
                progress = sum(b["progress"] for b in below) / len(below)
                started = progress > 0 or any(b["running"] or b["running_below"] for b in below)
                index = (len(ids) - 1 if progress >= 1
                         else min(1, len(ids) - 1) if started else 0)
            else:
                index = ids.index(stored.get("value")) if stored.get("value") in ids else 0
                progress = index / (len(ids) - 1) if len(ids) > 1 else 1.0
            out[key] = {
                "state": ids[index], "label": states[index].label or ids[index],
                "index": index, "count": len(ids), "progress": round(progress, 4),
                "derived": bool(below), "since": stored.get("since", ""),
                "children": len(below), "done_children": sum(1 for b in below if b["progress"] >= 1),
                "running": running.get(key, []),
                "last_run": last.get(key),
                "running_below": sum(len(b["running"]) + b["running_below"] for b in below),
                "states": [{"id": s.id, "label": s.label or s.id} for s in states],
            }
            return out[key]

        for k in nodes:
            visit(k, frozenset())
        return out

    def brief(self, flow: KbFlow, trigger: dict, *, work_item: str = "") -> dict:
        """Everything an external AI needs to carry out this flow itself.

        The expensive half of a one-shot analysis is the thinking, and an AI
        already connected over MCP has been paid for. So rather than Roadmap
        calling a provider, it hands over the rendered prompt and the run id to
        stamp on whatever comes back.
        """
        run = self.start_flow_run(flow, trigger, work_item=work_item)
        prompt = self.render_prompt(flow, work_item=run.work_item, mode="brief")
        branch = current_branch.get()
        if branch:
            prompt += ("\n\n## Branch\n\nThis run works in the knowledge base's branch "
                       f"`{branch}`: pass `branch=\"{branch}\"` to every kb_read and "
                       "kb_write call, so you read the branch's view and what you write "
                       "lands in the branch, not on main.\n\n"
                       "Start from what the branch changes: "
                       f'`kb_branch("context", id="{branch}")` gives every topic it adds, '
                       "changes or removes as **as is → to be** (narrow it with "
                       "`personas=\"analysis,architecture,backend\"` or the like).\n")
        if len(self.space_ids()) > 1:
            space = self.MANUAL_SOURCE
            prompt += ("\n\n## Space\n\nThis run works in the space "
                       f"`{space}`: pass `space=\"{space}\"` to every kb_read call (a "
                       "kb_write call that passes `run` is in the run's space anyway). "
                       "The other spaces can be read, not written.\n")
        return {
            "run": run.model_dump(),
            "prompt": prompt,
            "issues": self.flow_issues(flow, work_item=run.work_item),
        }

    def runner(self):
        """The server-side flow runner, if it is installed.

        Reading an AI provider and burning tokens is not the Knowledge Base's
        job, so execution lives in the ``roadmap.knowledgebase.flows`` satellite
        and registers itself here. ``None`` means briefs only — which is a
        complete way to use flows, not a broken install.
        """
        try:
            return runtime.services().get("knowledgebase.flows")
        except Exception:
            return None

    def can_run(self) -> bool:
        """Could a run actually start here, right now?

        Installed is not the same as ready — the satellite can be present with no
        AI provider bound to flows — and a flag called ``can_run`` that only means
        "installed" is a lie the UI would pass on.
        """
        runner = self.runner()
        if runner is None:
            return False
        ready = getattr(runner, "ready", None)
        return bool(ready()) if callable(ready) else True

    # ── writing a run's output ────────────────────────────────────────────────

    def apply_result(self, run_id: str, payload: dict, *, model: str = "") -> dict:
        """Write what a run produced: ``{"nodes": [...], "links": [...]}``.

        Validation is the whole point of going through here rather than writing
        the rows directly. Every node is checked against its type the same way a
        hand write is, so a run that misunderstood the contract fails with the
        reason instead of leaving a half-correct graph behind — and because the
        store keys on ``source/kind/id``, a corrected re-run overwrites rather
        than duplicating.
        """
        with self.in_run(run_id):
            return self._apply_result(run_id, payload, model=model)

    def _apply_result(self, run_id: str, payload: dict, *, model: str = "") -> dict:
        run = self.store.flow_run(run_id)
        if run is None:
            raise LookupError(f"No run {run_id!r}.")
        provenance = self.provenance_for(run_id, model=model)
        nodes = [GroundNode(**n) if isinstance(n, dict) else n
                 for n in (payload.get("nodes") or [])]
        for n in nodes:
            if not n.source:
                n.source = self.MANUAL_SOURCE
        links = [GroundLink(**l) if isinstance(l, dict) else l
                 for l in (payload.get("links") or [])]
        written = self.add_nodes(nodes, provenance)
        linked = self.add_links(links)
        about = self.link_run_output(run_id, nodes)
        return {"nodes": written, "links": linked, "about": about}

    def link_run_output(self, run_id: str, nodes: list[GroundNode]) -> int:
        """Link everything a run wrote to the unit of work the run is about.

        Done here rather than asked of the writer: the run already knows which
        work item it is for, so making an AI repeat it on every node is one more
        thing for it to get wrong for no gain.

        The relation is the flow's (``about`` by default) and deliberately not
        ``contains``: the explorer's persona trees are built strictly from
        ``contains``, so hanging topics off a unit of work that way would make
        every lane sprout branches under sprints. Work nodes themselves are
        skipped — a unit of work is not about itself.
        """
        run = self.store.flow_run(run_id)
        if run is None or not run.work_item:
            return 0
        parts = run.work_item.split("/", 2)
        if len(parts) != 3 or not all(parts):
            return 0
        w_source, w_kind, w_id = parts
        flow = self.flow(run.flow_id)
        relation = (flow.work_item.relation if flow else "") or "about"
        links = [
            GroundLink(src_source=n.source, src_kind=n.kind, src_id=n.id,
                       dst_source=w_source, dst_kind=w_kind, dst_id=w_id,
                       kind=relation)
            for n in nodes
            if not (n.source == w_source and n.kind == w_kind and n.id == w_id)
            and (self.node_type(n.kind) is None or self.node_type(n.kind).category != "work")
        ]
        # stamped with the run, so undoing it removes the `about` links it added
        return self.add_links(links, self.provenance_for(run_id)) if links else 0

    def provenance_for(self, run_id: str, *, model: str = "") -> Provenance | None:
        """The stamp for a write that names a run. An unknown id returns ``None``,
        so a bad reference loses the provenance rather than the write."""
        run = self.store.flow_run(run_id)
        if run is None:
            return None
        return Provenance(
            flow=run.flow_id, flow_version=run.flow_version,
            prompt_version=run.prompt_version, run=run.id,
            trigger=run.trigger, source_position=run.source_position, model=model,
        )

    # ── status ────────────────────────────────────────────────────────────────

    def status(self) -> dict:
        cfg = runtime.kb_config()
        counts = self.store.counts()
        per_source = {row["source"]: row["nodes"] for row in counts["per_source"]}
        per_kind = {row["kind"]: row["nodes"] for row in self.store.kinds()}
        return {
            "db_path": str(self.store.path),
            "nodes": counts["nodes"],
            "links": counts["links"],
            # the list, not a count: the order is configuration, and the views
            # that draw personas have to draw them in it
            "personas": [
                {"id": a.id, "name": a.name, "description": a.description}
                for a in cfg.personas
            ],
            "node_types": [
                {"id": t.id, "name": t.name, "form": t.form, "icon": t.icon,
                 "persona": t.persona, "category": t.category,
                 "parent_type": t.parent_type, "nodes": per_kind.get(t.id, 0)}
                for t in cfg.node_types
            ],
            "sources": [
                {
                    "id": s.id,
                    "type": s.type,
                    "label": s.label,
                    "enabled": s.enabled,
                    "nodes": per_source.get(s.id, 0),
                }
                for s in cfg.sources
            ] + ([
                {
                    "id": self.MANUAL_SOURCE,
                    "type": self.MANUAL_SOURCE,
                    "label": "This space (written by hand or by an agent)",
                    "enabled": True,
                    "nodes": per_source[self.MANUAL_SOURCE],
                }
            ] if per_source.get(self.MANUAL_SOURCE) else []),
            "recent_runs": [r.model_dump() for r in self.store.recent_runs(limit=10)],
            # the space this is, and the others (their topics read, not written)
            "space": self.MANUAL_SOURCE,
            "spaces": [{"id": sp.id, "name": sp.name, "description": sp.description}
                       for sp in runtime.kb_stored().spaces],
        }


def _fragments(blocks: list, title: str = ""):
    """``(section title, fragment type, text)`` of every fragment, depth first."""
    for b in blocks:
        if isinstance(b, DocSection):
            yield from _fragments(b.children, b.title)
        else:
            yield title, b.type, b.text


def _has_heading(text: str) -> bool:
    """A markdown ATX heading outside a code fence."""
    fence = False
    for line in text.split("\n"):
        if line.lstrip().startswith("```"):
            fence = not fence
        elif not fence and re.match(r"^#{1,6}\s", line):
            return True
    return False
