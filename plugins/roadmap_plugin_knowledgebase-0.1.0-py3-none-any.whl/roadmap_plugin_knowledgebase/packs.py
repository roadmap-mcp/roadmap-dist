"""Knowledge base packs: personas and node types, downloadable and installable.

A **pack** is a coherent set of personas and the node types written for them (and
the work-breakdown types that go with them), as one JSON document. Packs are
published in a **registry**, the way plugins are: an index listing them, next to
the pack files themselves. The settings page browses it, and installs a whole
pack or a few of its personas and types; anything a picked type needs (its
persona, the work types above it) comes along.

Installing never overwrites by accident: a persona or type whose id the
workspace already has is kept as it is unless that item is named in
``replace``. A pack can also come from a file, and a workspace's own personas and
types can be exported as one — which is also how registry packs are made.

The registry URL: ``ROADMAP_KB_PACK_REGISTRY_URL``, else roadmap-dist's
``kb-packs/index.json``. Packs are data only (no code), so fetching one is no
more than reading JSON.
"""

from __future__ import annotations

import json
import os
import urllib.request
from typing import Literal
from urllib.parse import urljoin

from pydantic import BaseModel, Field

from . import runtime
from .models import NodeType, Persona

DEFAULT_PACK_REGISTRY_URL = (
    "https://raw.githubusercontent.com/roadmap-mcp/roadmap-dist/main/kb-packs/index.json")

#: what installing would do to one persona or type
ItemStatus = Literal["new", "installed", "differs"]


class KbPack(BaseModel):
    """One pack: the personas and node types it carries, and what it is."""

    format: int = 1
    id: str = ""
    name: str = ""
    version: str = ""
    #: publication status, as for plugins: only ``published`` packs are in a registry
    status: str = "published"
    description: str = ""
    author: str = ""
    personas: list[Persona] = Field(default_factory=list)
    node_types: list[NodeType] = Field(default_factory=list)


class PackError(Exception):
    """A pack is not well-formed."""


class RegistryUnreachable(PackError):
    """The registry or a pack in it could not be fetched."""


# ── the registry ──────────────────────────────────────────────────────────────

def registry_url() -> str:
    return os.environ.get("ROADMAP_KB_PACK_REGISTRY_URL") or DEFAULT_PACK_REGISTRY_URL


def _get_json(url: str) -> dict:
    try:
        with urllib.request.urlopen(url, timeout=20) as resp:
            return json.loads(resp.read().decode("utf-8"))
    except Exception as e:  # noqa: BLE001 - network, HTTP and JSON errors alike
        raise RegistryUnreachable(f"Could not read {url}: {e}") from e


def fetch_index() -> dict:
    """The registry index: ``{"version": 1, "packs": [ {id, name, version,
    description, author, personas, node_types, url}, ... ]}``."""
    url = registry_url()
    index = _get_json(url)
    if not isinstance(index.get("packs"), list):
        raise RegistryUnreachable(f"{url} is not a pack registry (no 'packs' list).")
    return {"registryUrl": url, **index}


def fetch_pack(pack_id: str) -> KbPack:
    """One pack from the registry, by id."""
    index = fetch_index()
    entry = next((p for p in index["packs"] if p.get("id") == pack_id), None)
    if entry is None:
        known = ", ".join(p.get("id", "") for p in index["packs"]) or "none"
        raise LookupError(f"No pack '{pack_id}' in the registry. Packs: {known}.")
    return parse_pack(_get_json(urljoin(index["registryUrl"], entry.get("url") or f"{pack_id}.json")))


def parse_pack(raw: dict) -> KbPack:
    """A pack as a document says it; refuses one that is not well-formed."""
    if not isinstance(raw, dict):
        raise PackError("A pack is a JSON object.")
    try:
        pack = KbPack.model_validate(raw)
    except Exception as e:  # noqa: BLE001
        raise PackError(f"Not a valid pack: {e}") from e
    if pack.format != 1:
        raise PackError(f"Pack format {pack.format} is not supported (this app reads format 1).")
    persona_ids = {p.id for p in pack.personas}
    type_ids = {t.id for t in pack.node_types}
    if "" in persona_ids or "" in type_ids:
        raise PackError("Every persona and node type in a pack needs an id.")
    for t in pack.node_types:
        if t.persona and t.persona not in persona_ids:
            raise PackError(f"Type '{t.id}' is written for persona '{t.persona}', "
                            f"which the pack does not carry.")
        if t.parent_type and t.parent_type not in type_ids:
            raise PackError(f"Type '{t.id}' sits under '{t.parent_type}', "
                            f"which the pack does not carry.")
    return pack


# ── what installing would do ─────────────────────────────────────────────────

def _status(mine, theirs) -> ItemStatus:
    if mine is None:
        return "new"
    return "installed" if mine.model_dump() == theirs.model_dump() else "differs"


def item_status(pack: KbPack) -> dict:
    """For every persona and type in the pack: ``new`` (not in this workspace),
    ``installed`` (the same as here) or ``differs`` (here, but not the same —
    kept unless replaced)."""
    cfg = runtime.kb_config()
    personas = {p.id: p for p in cfg.personas}
    types = {t.id: t for t in cfg.node_types}
    return {
        "personas": {p.id: _status(personas.get(p.id), p) for p in pack.personas},
        "node_types": {t.id: _status(types.get(t.id), t) for t in pack.node_types},
    }


def _closure(pack: KbPack, persona_ids: set[str], type_ids: set[str]) -> tuple[set[str], set[str]]:
    """Add what the picked types need: the persona each is written for, and the
    work types above it."""
    by_id = {t.id: t for t in pack.node_types}
    personas, types = set(persona_ids), set(type_ids)
    todo = list(types)
    while todo:
        t = by_id.get(todo.pop())
        if t is None:
            continue
        if t.persona:
            personas.add(t.persona)
        if t.parent_type and t.parent_type not in types:
            types.add(t.parent_type)
            todo.append(t.parent_type)
    return personas, types


# ── install / export ──────────────────────────────────────────────────────────

def install(pack: KbPack, personas: list[str] | None = None,
            node_types: list[str] | None = None, replace: list[str] | None = None) -> dict:
    """Install a pack, or the picked personas and types of it (``None`` for both =
    the whole pack). What a picked type needs is installed with it. An item the
    workspace already has is kept unless its id is in ``replace``.

    Returns what happened: ``installed``, ``replaced``, ``kept`` (already here and
    not replaced; ``unchanged`` when identical) and ``needed`` (pulled in by
    another pick), each a list of ``"persona:<id>"`` / ``"type:<id>"``.
    """
    all_p = {p.id for p in pack.personas}
    all_t = {t.id for t in pack.node_types}
    if personas is None and node_types is None:
        want_p, want_t = all_p, all_t
    else:
        want_p, want_t = set(personas or []), set(node_types or [])
        unknown = (want_p - all_p) | (want_t - all_t)
        if unknown:
            raise LookupError(f"Not in pack '{pack.id}': {', '.join(sorted(unknown))}.")
    need_p, need_t = _closure(pack, want_p, want_t)
    replace_set = set(replace or [])

    cfg = runtime.kb_config()
    result: dict[str, list[str]] = {"installed": [], "replaced": [], "kept": [],
                                    "unchanged": [], "needed": []}
    groups: list[tuple[str, list, list, set[str], set[str]]] = [
        ("persona", cfg.personas, pack.personas, need_p, want_p),
        ("type", cfg.node_types, pack.node_types, need_t, want_t)]
    for label, mine_list, theirs, need, picked in groups:
        for item in theirs:
            if item.id not in need:
                continue
            key = f"{label}:{item.id}"
            if item.id not in picked:
                result["needed"].append(key)
            at = next((i for i, m in enumerate(mine_list) if m.id == item.id), None)
            if at is None:
                mine_list.append(item.model_copy(deep=True))
                result["installed"].append(key)
            elif mine_list[at].model_dump() == item.model_dump():
                result["unchanged"].append(key)
            elif item.id in replace_set:
                mine_list[at] = item.model_copy(deep=True)    # in place: order is kept
                result["replaced"].append(key)
            else:
                result["kept"].append(key)
    runtime.save_kb_config(cfg)
    return result


def export(persona_ids: list[str], type_ids: list[str], *, pack_id: str, name: str,
           version: str = "1.0.0", description: str = "", author: str = "") -> KbPack:
    """This workspace's picked personas and types as a pack, with what the types
    need (their personas, the work types above them) so it installs on its own."""
    cfg = runtime.kb_config()
    whole = KbPack(personas=cfg.personas, node_types=cfg.node_types)
    unknown = (set(persona_ids) - {p.id for p in cfg.personas}) | \
              (set(type_ids) - {t.id for t in cfg.node_types})
    if unknown:
        raise LookupError(f"Not in this workspace: {', '.join(sorted(unknown))}.")
    need_p, need_t = _closure(whole, set(persona_ids), set(type_ids))
    return KbPack(
        id=pack_id, name=name or pack_id, version=version, description=description,
        author=author,
        personas=[p for p in cfg.personas if p.id in need_p],
        node_types=[t for t in cfg.node_types if t.id in need_t])
