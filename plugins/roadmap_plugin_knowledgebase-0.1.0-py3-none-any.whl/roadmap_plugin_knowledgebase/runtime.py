"""Per-process runtime wiring for the Knowledge Base.

Stashes the framework handles at activate time so the store, the service and the
router can read config and enumerate extensions without threading the context
through every call. ``ConfigStore.path`` is already workspace-scoped, so
everything under :func:`kb_dir` is per-workspace automatically. Mirrors the
gitmining / workflow plugins' ``runtime``.
"""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from .models import LEGACY_PERSONA_KEY, LEGACY_PERSONAS_KEY, KnowledgeBaseConfig

#: The settings group every information source already files itself under. The
#: Knowledge Base offers exactly these as things you can ingest, so a new source
#: plugin shows up here with no change to this one.
INFORMATION_SOURCES_GROUP = "Information Sources"

#: Ids in that group that are not ingestable sources. The Company Brain is the
#: subsystem this plugin replaces — offering it as an input would be circular.
_NOT_A_SOURCE = {"brain", "brain-client"}

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def config_dir() -> Path:
    assert _store is not None, "knowledgebase runtime not initialised"
    return _store.path.parent


def kb_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/knowledgebase``). Created on demand."""
    d = config_dir() / "knowledgebase"
    d.mkdir(parents=True, exist_ok=True)
    return d


def db_path() -> Path:
    """The ground layer's SQLite file. One file per workspace; a prototype does not
    need a server."""
    return kb_dir() / "ground.db"


def kb_config() -> KnowledgeBaseConfig:
    assert _store is not None, "knowledgebase runtime not initialised"
    raw = _store.load_decrypted()
    return KnowledgeBaseConfig(**(raw.get("knowledgebase") or {}))


def has_legacy_keys() -> bool:
    """True while the stored slice still uses a key that has since been renamed:
    ``topic_types`` for ``node_types``, or ``audiences`` / ``audience`` for
    ``personas`` / ``persona`` (on the slice, on a node type, on a flow's
    targets).

    The models read the old keys either way, so nothing is broken by them -- but
    the settings page is handed the *raw* document, where old and new would sit
    side by side. :meth:`KnowledgeBaseService.normalise` uses this to force the
    save that drops the old ones.
    """
    assert _store is not None, "knowledgebase runtime not initialised"
    slice_ = _store.load_raw().get("knowledgebase") or {}
    if KnowledgeBaseConfig.LEGACY_TYPES_KEY in slice_ or LEGACY_PERSONAS_KEY in slice_:
        return True
    types = slice_.get("node_types") or slice_.get(KnowledgeBaseConfig.LEGACY_TYPES_KEY) or []
    if any(isinstance(t, dict) and LEGACY_PERSONA_KEY in t for t in types):
        return True
    return any(isinstance(f, dict) and LEGACY_PERSONAS_KEY in (f.get("targets") or {})
               for f in slice_.get("flows") or [])


def save_kb_config(cfg: KnowledgeBaseConfig) -> KnowledgeBaseConfig:
    """Persist the ``knowledgebase`` slice, leaving the rest of the document alone.

    The settings page saves the whole document, so this is only for server-side
    edits (seeding an id, recording an ingest timestamp).
    """
    assert _store is not None, "knowledgebase runtime not initialised"
    raw = _store.load_decrypted()
    # replaces the slice wholesale, so a legacy key (``topic_types``,
    # ``audiences``) does not survive alongside what model_dump() writes
    raw["knowledgebase"] = cfg.model_dump()
    _store.save(raw)
    return cfg


def has_encrypted_fields() -> bool:
    assert _store is not None, "knowledgebase runtime not initialised"
    return _store.has_encrypted_fields()


def services() -> ServiceRegistry:
    assert _services is not None, "knowledgebase runtime not initialised"
    return _services


def available_sources() -> list[dict]:
    """The information sources this installation already has.

    Read off the settings sections filed under *Information Sources* rather than a
    registry of our own: those tabs *are* the list of systems this deployment is
    connected to, and a newly installed source plugin appears here for free.
    """
    if _extensions is None:
        return []
    out = []
    for section in _extensions.get(SETTINGS_SECTIONS_POINT):
        if section.group != INFORMATION_SOURCES_GROUP or section.id in _NOT_A_SOURCE:
            continue
        out.append({"type": section.id, "label": section.label, "order": section.order})
    out.sort(key=lambda s: (s["order"], s["label"]))
    return out
