"""Chats about the knowledge base, hosted by an external AI.

A person opens a chat window from the Knowledge Base page ("chat about this").
Roadmap does not answer: the chat has a short code, and the window's MCP
button copies an instruction to paste into an AI console (a Claude terminal)
that is connected to Roadmap over MCP. That AI joins with ``kb_chat``, waits for
the person's messages, finds the answers with ``kb_read``, and replies, briefly,
showing **small pieces** of the knowledge base in the window: one section of a
topic, a diagram, a screen sketch, rather than pasting whole documents. The
person drives; the AI follows.

Nothing is long-lived: the window polls for new messages, and the AI's ``wait``
returns after a few seconds whether or not anything arrived, so a backend
reload does not break either side. Chats are kept in the workspace's store.
"""

from __future__ import annotations

import asyncio
import secrets
import string
import time
from datetime import datetime, timezone

from .branches import on_branch
from .models import DocSection, utc_now

#: how many pieces of the knowledge base one reply may show: small portions
MAX_ITEMS = 4
#: a reply's own text stays short; the knowledge goes in the pieces it shows
MAX_TEXT = 4000
#: the AI counts as connected while it has called within this many seconds
#: (longer than a ``wait``, so a waiting AI never looks gone)
CONNECTED_FOR = 75

GUIDE = """\
You are hosting a chat about this knowledge base. A person is in the chat window in
Roadmap and drives the conversation; you answer from the knowledge base.

How to converse:
- Keep every reply short: a few sentences. End with two or three concrete places the
  person could go next (as questions or options), and let them choose.
- Start broad and go deeper only where they ask. For someone new: a very short
  overview of the application first, then let them explore (areas, use cases,
  screens, flows, the data model, the design).
- Show, don't paste. Put pieces of the knowledge base in the window with `show`:
  a section of a topic (`{"node": "<source/kind/id>", "section": "<title or number>"}`)
  or a whole small topic (`{"node": "..."}`). At most %d per reply. A diagram or a
  screen sketch is shown whole: show the section that holds it. Do not copy long
  text into your reply; quote a line at most.
- Find things with `kb_read`: `status` for the shape, `find` to search, `get` for a
  topic (its outline shows the section titles), `neighbours` for what it links to.
- Say so when the knowledge base does not hold the answer; do not make it up.
- Answer in the language the person writes in.

Branches. The knowledge base describes the application as it is. When the person
wants to develop something new (a feature, a change), that work is written in a
**branch** of the knowledge base, opened for the feature's work item: open it with
`kb_branch("open", name=..., work_item=..., chat=<this chat>)`, after creating the
work item on main with kb_write if it does not exist yet (and, if no work type fits
a feature, a work type first: `kb_admin("save_type", category="work",
states_json=...)`, its states the feature's phases, the last one done). While the chat is on a
branch, pass `branch=<id>` to every kb_read and kb_write call: you then see the
knowledge base plus what the branch added or changed, and what you write lands in
the branch, not on main. The branch is merged (`kb_branch("merge")`) only when the
work is completely done; until then it stays open, whatever phase it is in.

The loop: `kb_chat("wait", id=...)` until a message arrives (it returns after a few
seconds with nothing if none did: call it again), read and answer with
`kb_chat("say", id=..., text=..., show_json=...)`, then `wait` again. Keep going
until the person says goodbye or the chat is closed.
""" % MAX_ITEMS


def _code() -> str:
    alphabet = string.ascii_lowercase + string.digits
    return "kbc-" + "".join(secrets.choice(alphabet) for _ in range(6))


def section_index(blocks: list, at: str = "") -> list[tuple[str, DocSection]]:
    """Every section with its number (``2``, ``2.1``), numbered the way the
    explorer's table of contents numbers them."""
    out: list[tuple[str, DocSection]] = []
    n = 0
    for b in blocks or []:
        if isinstance(b, DocSection):
            n += 1
            number = f"{at}{n}"
            out.append((number, b))
            out += section_index(b.children, number + ".")
    return out


class Chats:
    """The chats of the current workspace, over the knowledge base's store."""

    def __init__(self, kb) -> None:
        self.kb = kb

    # ── the window's side ─────────────────────────────────────────────────────

    def create(self, *, title: str = "", focus: str = "") -> dict:
        focus = self.kb.ref(focus)
        if focus:
            parts = focus.split("/", 2)
            node = self.kb.store.get_node(*parts) if len(parts) == 3 and all(parts) else None
            if node is None:
                raise ValueError(f"No node `{focus}`.")
            title = title or node.title or node.id
        chat = {"id": _code(), "title": title or "Knowledge base", "focus": focus,
                "created_at": utc_now()}
        self.kb.store.create_chat(chat)
        return self.get(chat["id"])

    def get(self, chat_id: str) -> dict:
        chat = self.kb.store.chat(chat_id)
        if chat is None:
            raise LookupError(f"No chat `{chat_id}`.")
        seen = chat.get("ai_seen_at") or ""
        chat["ai_connected"] = bool(seen) and _age(seen) < CONNECTED_FOR
        chat["branch"] = chat.get("branch") or ""
        return chat

    def set_branch(self, chat_id: str, branch: str) -> dict:
        """Put the chat on a branch (``""``: back on main). Said in the chat, so
        the person sees which view the answers come from."""
        self.get(chat_id)
        if branch:
            self.kb.branches.check(branch)
        self.kb.store.update_chat(chat_id, branch=branch or "")
        self.kb.store.add_chat_message(
            chat_id, "system",
            f"The chat is now on branch `{branch}`." if branch else "The chat is back on main.",
            [])
        return self.get(chat_id)

    def messages(self, chat_id: str, since: int = 0) -> list[dict]:
        self.get(chat_id)
        return self.kb.store.chat_messages(chat_id, since)

    def post_user(self, chat_id: str, text: str) -> dict:
        chat = self.get(chat_id)
        if chat.get("closed"):
            raise ValueError("This chat is closed.")
        text = (text or "").strip()
        if not text:
            raise ValueError("Say something.")
        return self.kb.store.add_chat_message(chat_id, "user", text[:MAX_TEXT], [])

    def close(self, chat_id: str) -> dict:
        self.get(chat_id)
        self.kb.store.update_chat(chat_id, closed=1)
        self.kb.store.add_chat_message(chat_id, "system", "The chat was closed.", [])
        return self.get(chat_id)

    def reopen(self, chat_id: str) -> dict:
        """Open a closed chat again; an AI that stopped has to join again."""
        self.get(chat_id)
        self.kb.store.update_chat(chat_id, closed=0)
        self.kb.store.add_chat_message(chat_id, "system", "The chat was reopened.", [])
        return self.get(chat_id)

    # ── the AI's side ─────────────────────────────────────────────────────────

    def join(self, chat_id: str) -> dict:
        chat = self.get(chat_id)
        self.kb.store.update_chat(chat_id, ai_seen_at=utc_now())
        if not chat.get("ai_joined"):
            self.kb.store.update_chat(chat_id, ai_joined=1)
            self.kb.store.add_chat_message(chat_id, "system", "An AI joined the chat.", [])
        return {"chat": self.get(chat_id), "messages": self.kb.store.chat_messages(chat_id, 0)}

    async def wait(self, chat_id: str, timeout: float = 25) -> list[dict]:
        """The person's messages the AI has not seen yet; waits up to
        ``timeout`` seconds for one. Polls the store, so it survives anything
        but the reload that ends the call."""
        timeout = max(1.0, min(float(timeout or 25), 50.0))
        end = time.monotonic() + timeout
        while True:
            chat = self.get(chat_id)
            self.kb.store.update_chat(chat_id, ai_seen_at=utc_now())
            cursor = int(chat.get("ai_cursor") or 0)
            new = [m for m in self.kb.store.chat_messages(chat_id, cursor)]
            if new:
                self.kb.store.update_chat(chat_id, ai_cursor=new[-1]["seq"])
                users = [m for m in new if m["role"] == "user"]
                if users or chat.get("closed"):
                    return users
            if chat.get("closed") or time.monotonic() >= end:
                return []
            await asyncio.sleep(1.0)

    def say(self, chat_id: str, text: str, items: list | None = None) -> dict:
        chat = self.get(chat_id)
        if chat.get("closed"):
            raise ValueError("This chat is closed.")
        text = (text or "").strip()
        items = list(items or [])
        if not text and not items:
            raise ValueError("Say something, or show something.")
        if len(text) > MAX_TEXT:
            raise ValueError(f"Keep the reply under {MAX_TEXT} characters; show the "
                             "knowledge base's own sections instead of copying them.")
        if len(items) > MAX_ITEMS:
            raise ValueError(f"Show at most {MAX_ITEMS} pieces per reply: small portions, "
                             "and let the person ask for more.")
        branch = chat.get("branch") or ""
        with on_branch(branch):
            # each piece remembers the view it was shown from, so it reads the
            # same later even when the chat has moved to another branch
            shown = [{**self._resolve(it), **({"branch": branch} if branch else {})}
                     for it in items]
        self.kb.store.update_chat(chat_id, ai_seen_at=utc_now())
        return self.kb.store.add_chat_message(chat_id, "assistant", text, shown)

    def _resolve(self, item) -> dict:
        """``{"node": "source/kind/id", "section": "<title or number>"}`` → the
        node and the section's number, checked to exist."""
        if isinstance(item, str):
            item = {"node": item}
        if not isinstance(item, dict) or not item.get("node"):
            raise ValueError('Each piece to show is {"node": "source/kind/id", "section": "..."}.')
        ref = self.kb.ref(str(item["node"]))
        parts = ref.split("/", 2)
        node = self.kb.store.get_node(*parts) if len(parts) == 3 and all(parts) else None
        if node is None:
            raise ValueError(f"No node `{ref}`: use a ref from kb_read (source/kind/id).")
        out = {"node": ref, "title": node.title or node.id, "kind": node.kind}
        want = str(item.get("section") or "").strip()
        if want:
            sections = section_index(node.content.document if node.content else [])
            match = next((s for s in sections if s[0] == want), None) or next(
                (s for s in sections if s[1].title.strip().lower() == want.lower()), None)
            if match is None:
                titles = ", ".join(f"{n} {s.title}" for n, s in sections[:30]) or "none"
                raise ValueError(f"`{ref}` has no section `{want}`. Its sections: {titles}.")
            out["section"], out["section_title"] = match[0], match[1].title
        return out


def _age(stamp: str) -> float:
    try:
        then = datetime.fromisoformat(stamp.replace("Z", "+00:00"))
        if then.tzinfo is None:
            then = then.replace(tzinfo=timezone.utc)
        return (datetime.now(timezone.utc) - then).total_seconds()
    except ValueError:
        return 1e9
