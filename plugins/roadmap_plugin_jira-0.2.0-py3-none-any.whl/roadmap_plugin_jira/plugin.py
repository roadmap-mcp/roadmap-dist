"""Jira context-item plugin — contributes the ``jira_issue`` / ``confluence_page``
context item types + previews + MCP tools, consuming the ``atlassian`` datasource
service. All config/client/cache now lives in ``roadmap-plugin-atlassian``.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT

from . import runtime
from .context_items import JIRA_ITEM_TYPES, JIRA_PREVIEWS
from .mcp_tools import register_mcp_tools


class JiraPlugin(Plugin):
    id = "roadmap.jira"
    name = "Jira / Confluence context items"
    requires = ["roadmap.atlassian", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_service(ctx.services.require("atlassian"))

        for it in JIRA_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, it)
        for pc in JIRA_PREVIEWS:
            ctx.extend(CONTEXT_PREVIEW_POINT, pc)

        register_mcp_tools(ctx.services.require("context"))
