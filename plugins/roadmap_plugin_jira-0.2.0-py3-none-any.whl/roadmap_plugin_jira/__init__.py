"""Jira / Atlassian plugin — implements the settings + context extension points
for Jira issues and Confluence pages, and mounts standalone Jira/Confluence APIs.
"""
