"""Per-process runtime for the jira context-item plugin.

Holds the ``atlassian`` datasource service (set at activation) so the item-type
render/resolve callables can reach it without importing the atlassian plugin.
"""

from __future__ import annotations

_service = None


def set_service(service) -> None:
    global _service
    _service = service


def atlassian():
    assert _service is not None, "jira runtime not initialised (atlassian service missing)"
    return _service
