"""The Selenium web driver — a :class:`roadmap_plugin_e2e.ports.Driver` adapter.

Maps the engine's structured actions onto Selenium calls and runs ``script`` steps
against the live ``driver`` in the engine's restricted namespace (plus ``By`` /
``WebDriverWait`` / ``EC`` for real snippets). Launches a local headless Chrome via
Selenium Manager (bundled chromedriver resolution — no webdriver-manager needed), or
connects to a remote WebDriver / Grid when ``e2e.remote_url`` is set.
"""

from __future__ import annotations

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.support.ui import Select, WebDriverWait
from selenium.common.exceptions import (
    NoSuchElementException, TimeoutException, ElementNotInteractableException,
    InvalidSelectorException, StaleElementReferenceException,
)

from roadmap_plugin_e2e import StepOutcome
from roadmap_plugin_e2e.snippet import run_snippet

# a step failure we report as status='failed' rather than a hard driver error
_STEP_ERRORS = (
    NoSuchElementException, TimeoutException, ElementNotInteractableException,
    InvalidSelectorException, StaleElementReferenceException, AssertionError,
)

_BY = {
    "css": By.CSS_SELECTOR,
    "id": By.ID,
    "name": By.NAME,
    "xpath": By.XPATH,
    "link_text": By.LINK_TEXT,
}

# Walk the DOM once and return visible interactive elements, each with a robust CSS
# selector — id > name > a :nth-of-type path. Runs entirely in the page so the
# assistant gets ready-to-use selectors without N WebDriver round-trips.
_SNAPSHOT_JS = r"""
const sel = 'button, a[href], input:not([type=hidden]), select, textarea,' +
            ' [role=button], [role=link], [role=tab], [onclick]';
function robust(el) {
  if (el.id) {
    const idsel = '#' + CSS.escape(el.id);
    try { if (document.querySelectorAll(idsel).length === 1) return idsel; } catch (e) {}
  }
  const name = el.getAttribute('name');
  if (name) {
    const c = el.tagName.toLowerCase() + '[name="' + name.replace(/"/g, '\\"') + '"]';
    if (document.querySelectorAll(c).length === 1) return c;
  }
  const parts = [];
  let node = el;
  while (node && node.nodeType === 1 && node.tagName.toLowerCase() !== 'html') {
    let part = node.tagName.toLowerCase();
    if (node.id) { parts.unshift('#' + CSS.escape(node.id)); break; }
    const parent = node.parentNode;
    if (parent) {
      const same = Array.from(parent.children).filter(c => c.tagName === node.tagName);
      if (same.length > 1) part += ':nth-of-type(' + (same.indexOf(node) + 1) + ')';
    }
    parts.unshift(part);
    node = node.parentNode;
  }
  return parts.join(' > ');
}
function label(el) {
  const t = (el.innerText || el.textContent || '').trim();
  if (t) return t;
  return el.getAttribute('aria-label') || el.getAttribute('placeholder') ||
         el.value || el.getAttribute('name') || el.getAttribute('title') || '';
}
const out = [];
document.querySelectorAll(sel).forEach(el => {
  const r = el.getBoundingClientRect();
  const visible = !!(el.offsetParent !== null || r.width || r.height);
  if (!visible) return;
  out.push({
    tag: el.tagName.toLowerCase(),
    type: el.getAttribute('type') || el.getAttribute('role') || '',
    text: label(el),
    selector: robust(el),
    visible: true,
  });
});
return out;
"""


def _locator(target: dict) -> tuple[str, str]:
    by = (target.get("by") or "css").lower()
    value = target.get("value", "")
    if by == "text":                                  # convenience: match visible text
        safe = value.replace('"', '\\"')
        return By.XPATH, f'//*[contains(normalize-space(text()), "{safe}")]'
    return _BY.get(by, By.CSS_SELECTOR), value


class SeleniumDriver:
    id = "selenium"

    def __init__(self, config):
        self._cfg = config
        self._driver = None

    # ── lifecycle ─────────────────────────────────────────────────────────────

    def start(self) -> None:
        cfg = self._cfg
        opts = webdriver.ChromeOptions()
        if cfg.headless:
            opts.add_argument("--headless=new")
        opts.add_argument("--no-sandbox")
        opts.add_argument("--disable-dev-shm-usage")
        opts.add_argument(f"--window-size={cfg.window_width},{cfg.window_height}")
        if cfg.remote_url:
            self._driver = webdriver.Remote(command_executor=cfg.remote_url, options=opts)
        else:
            self._driver = webdriver.Chrome(options=opts)
        self._driver.set_page_load_timeout(max(cfg.default_timeout * 3, 30))

    def close(self) -> None:
        if self._driver is not None:
            self._driver.quit()
            self._driver = None

    def screenshot(self):
        if self._driver is None:
            return None
        try:
            return self._driver.get_screenshot_as_png()
        except Exception:
            return None

    # ── live introspection (LiveDriver) ───────────────────────────────────────

    def url(self) -> str:
        return self._driver.current_url if self._driver is not None else ""

    def snapshot(self) -> list[dict]:
        """The page's visible interactive elements, each with a **robust CSS selector**
        (id → ``#id``; else ``tag[name=…]``; else a stable ``:nth-of-type`` path),
        computed in one ``execute_script`` pass so the assistant gets ready-to-use
        selectors rather than guessing them by hand."""
        if self._driver is None:
            return []
        try:
            raw = self._driver.execute_script(_SNAPSHOT_JS)
        except Exception:
            return []
        out = []
        for i, e in enumerate((raw or [])[:60]):
            out.append({
                "index": i,
                "tag": e.get("tag", ""),
                "type": e.get("type", ""),
                "text": (e.get("text", "") or "")[:120],
                "selector": e.get("selector", ""),
                "by": "css",
                "visible": bool(e.get("visible", True)),
            })
        return out

    # ── helpers ───────────────────────────────────────────────────────────────

    def _timeout(self, step: dict) -> float:
        t = step.get("timeout")
        return float(t) if t else float(self._cfg.default_timeout)

    def _find(self, target: dict, timeout: float, *, visible: bool = False):
        loc = _locator(target)
        cond = EC.visibility_of_element_located(loc) if visible \
            else EC.presence_of_element_located(loc)
        return WebDriverWait(self._driver, timeout).until(cond)

    # ── step dispatch ─────────────────────────────────────────────────────────

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        try:
            return self._dispatch(step, ctx)
        except _STEP_ERRORS as e:
            return StepOutcome(status="failed",
                               error=f"{type(e).__name__}: {getattr(e, 'msg', str(e))}")

    def _dispatch(self, step: dict, ctx: dict) -> StepOutcome:
        t = step.get("type", "")
        target = step.get("target") or {}
        value = step.get("value", "")
        timeout = self._timeout(step)

        if t == "navigate":
            # the engine already resolved this against the step's Site base URL
            self._driver.get(value)
            return StepOutcome(status="passed")

        if t == "click":
            el = self._find(target, timeout)
            el.click()
            return StepOutcome(status="passed")

        if t == "type":
            el = self._find(target, timeout)
            el.clear()
            el.send_keys(value)
            return StepOutcome(status="passed")

        if t == "select":
            el = self._find(target, timeout)
            Select(el).select_by_visible_text(value)
            return StepOutcome(status="passed")

        if t == "wait":
            if target.get("value"):
                self._find(target, timeout, visible=True)
            elif value:
                import time
                time.sleep(float(value))
            return StepOutcome(status="passed")

        if t == "assert_visible":
            el = self._find(target, timeout, visible=True)
            if not el.is_displayed():
                return StepOutcome(status="failed", error="Element is not visible.")
            return StepOutcome(status="passed")

        if t == "assert_text":
            el = self._find(target, timeout)
            have = el.text or el.get_attribute("value") or ""
            if value and value not in have:
                return StepOutcome(
                    status="failed",
                    error=f"Expected text '{value}' not found (got '{have[:200]}').")
            return StepOutcome(status="passed")

        if t == "capture":
            el = self._find(target, timeout)
            got = el.text or el.get_attribute("value") or ""
            key = step.get("capture_as") or target.get("value", "")
            return StepOutcome(status="passed", captured={key: got})

        if t == "script":
            try:
                run_snippet(step.get("snippet", ""), driver=self._driver, ctx=ctx,
                            extra={"By": By, "WebDriverWait": WebDriverWait, "EC": EC,
                                   "Select": Select})
                return StepOutcome(status="passed")
            except AssertionError as e:
                return StepOutcome(status="failed", error=f"Assertion failed: {e}")
            except Exception as e:
                return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        return StepOutcome(status="failed", error=f"Unknown step type: {t}")
