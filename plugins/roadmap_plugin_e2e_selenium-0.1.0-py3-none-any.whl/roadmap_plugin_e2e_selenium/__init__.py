"""Selenium web driver for the Roadmap E2E engine.

Contributes a ``selenium`` :class:`~roadmap_plugin_e2e.contracts.DriverProvider` to
the ``roadmap.e2e.drivers`` point. Select it with ``e2e.driver = "selenium"`` in the
Web Testing settings once this plugin is installed + enabled.
"""
