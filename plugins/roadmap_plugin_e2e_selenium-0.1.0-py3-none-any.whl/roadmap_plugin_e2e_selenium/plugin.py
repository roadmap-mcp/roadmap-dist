"""Selenium driver plugin activator.

Contributes the ``selenium`` driver provider to the engine's ``roadmap.e2e.drivers``
point. The provider builds a :class:`~.driver.SeleniumDriver` from the resolved
``e2e`` config when a run starts, so importing/activating this plugin never launches a
browser — only starting a run does.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_e2e import E2E_DRIVERS_POINT, DriverProvider

from .driver import SeleniumDriver

SELENIUM_PROVIDER = DriverProvider(
    id="selenium",
    label="Selenium (Chrome)",
    create=lambda env: SeleniumDriver(env.config),
)


class SeleniumDriverPlugin(Plugin):
    id = "roadmap.e2e.selenium"
    name = "Web Testing — Selenium driver"
    requires = ["roadmap.e2e"]

    def activate(self, ctx: PluginContext) -> None:
        ctx.extend(E2E_DRIVERS_POINT, SELENIUM_PROVIDER)
