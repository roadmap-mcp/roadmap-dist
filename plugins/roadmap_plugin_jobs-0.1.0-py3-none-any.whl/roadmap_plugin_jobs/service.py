"""The ``jobs`` service — create, update, and run background jobs.

The facade other plugins use. Beyond CRUD it provides :meth:`JobsService.run_async` — the
reusable "spawn a daemon thread, re-pin ``current_workspace``, mark running → completed/failed"
helper that gitmining (and the workflow engine) would otherwise each hand-roll. The work
function receives the ``job_id`` and uses :meth:`log` / :meth:`finish` to report progress; if it
returns without setting a terminal status the job is marked ``completed`` automatically.
"""

from __future__ import annotations

import threading
import uuid
from datetime import datetime
from typing import Callable

from roadmap_framework import current_workspace

from . import components, runtime
from .models import Job, JobLog


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


class JobsService:
    def store(self):
        """The active :class:`~.ports.JobStore` (built + ``init()``-ed from config)."""
        return components.build_store()

    def list_persistence(self) -> list[dict]:
        active = runtime.jobs_config().persistence
        return [
            {"id": p.id, "label": p.label, "icon": getattr(p, "icon", "bi-database"),
             "active": p.id == active}
            for p in runtime.persistence_providers()
        ]

    def set_persistence(self, provider_id: str) -> str:
        cfg = runtime.jobs_config()
        cfg.persistence = provider_id
        return runtime.save_jobs_config(cfg).persistence

    # ── CRUD ────────────────────────────────────────────────────────────────────
    def create(self, owner: str, kind: str = "", title: str = "",
               data: dict | None = None) -> Job:
        job = Job(id=f"job_{uuid.uuid4().hex[:8]}", owner=owner, kind=kind, title=title,
                  status="pending", started=_now(), data=data or {})
        self.store().save(job)
        return job

    def get(self, job_id: str) -> Job | None:
        return self.store().get(job_id)

    def list(self, owner: str = "", kind: str = "", limit: int = 100) -> list[Job]:
        return self.store().list(owner, kind, limit)

    def delete(self, job_id: str) -> bool:
        return self.store().delete(job_id)

    def prune(self, owner: str = "", keep: int = 200) -> int:
        return self.store().prune(owner, keep)

    def save(self, job: Job) -> Job:
        self.store().save(job)
        return job

    # ── incremental updates (safe from the worker thread) ──────────────────────
    def log(self, job_id: str, message: str, level: str = "info") -> None:
        store = self.store()
        job = store.get(job_id)
        if job is None:
            return
        job.log.append(JobLog(ts=_now(), level=level, message=message))
        store.save(job)

    def set_progress(self, job_id: str, progress: float) -> None:
        store = self.store()
        job = store.get(job_id)
        if job is None:
            return
        job.progress = progress
        store.save(job)

    def set_status(self, job_id: str, status: str, *, summary: str = "",
                   error: str = "") -> None:
        store = self.store()
        job = store.get(job_id)
        if job is None:
            return
        job.status = status
        if summary:
            job.summary = summary
        if error:
            job.error = error
        if status in ("completed", "failed", "cancelled"):
            job.finished = _now()
        store.save(job)

    def finish(self, job_id: str, summary: str = "") -> None:
        self.set_status(job_id, "completed", summary=summary)

    def fail(self, job_id: str, error: str) -> None:
        self.set_status(job_id, "failed", error=error)

    # ── the reusable async runner ───────────────────────────────────────────────
    def run_async(self, owner: str, kind: str, title: str,
                  fn: Callable[[str], None], data: dict | None = None) -> Job:
        """Create a job and run ``fn(job_id)`` on a daemon thread, re-pinning the current
        workspace (background threads don't inherit the contextvar). Marks the job
        ``running`` before and ``completed``/``failed`` after — ``fn`` may set its own
        terminal status/summary; an exception becomes ``failed`` with the message."""
        job = self.create(owner, kind, title, data)
        ws = current_workspace.get()

        def _worker() -> None:
            token = current_workspace.set(ws)
            try:
                self.set_status(job.id, "running")
                fn(job.id)
                current = self.get(job.id)
                if current and current.status == "running":
                    self.set_status(job.id, "completed")
            except Exception as ex:
                self.set_status(job.id, "failed", error=str(ex))
            finally:
                current_workspace.reset(token)

        threading.Thread(target=_worker, name=f"job-{job.id}", daemon=True).start()
        return job
