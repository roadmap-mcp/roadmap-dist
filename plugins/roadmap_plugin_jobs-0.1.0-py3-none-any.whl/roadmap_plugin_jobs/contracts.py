"""The jobs plugin's one extension point: swappable job persistence.

A :class:`JobStoreProvider` is a ``{id, label, create}`` descriptor whose ``create(env)`` lazily
builds a :class:`~.ports.JobStore`. The plugin contributes the built-in ``sql`` (SQLite) +
``filesystem`` providers; a satellite adds a Postgres/SQL-Server backend by depending on
``roadmap.jobs`` and extending this point. The active provider is chosen by config
(``jobs.persistence``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

JOBS_PERSISTENCE_POINT = "roadmap.jobs.persistence"


@dataclass
class JobStoreProvider:
    id: str
    label: str
    create: Callable[[Any], Any]          # create(env) -> JobStore
    icon: str = "bi-database"
