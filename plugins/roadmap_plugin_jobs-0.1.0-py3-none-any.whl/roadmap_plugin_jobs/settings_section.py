"""The Jobs settings section (the ``jobs`` config slice — the persistence selector)."""

from roadmap_plugin_settings import SettingsSection

from .models import JobsConfig

JOBS_SECTION = SettingsSection(
    id="jobs",
    label="Jobs",
    order=60,
    group="System",
    defaults=lambda: {"jobs": JobsConfig().model_dump()},
)
