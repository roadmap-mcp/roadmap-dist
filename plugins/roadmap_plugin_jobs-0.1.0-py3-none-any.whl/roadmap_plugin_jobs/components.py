"""Persistence factory — resolve and build the configured :class:`~.ports.JobStore`."""

from __future__ import annotations

from . import runtime
from .ports import JobStore


def _resolve(providers: list, wanted: str, default_id: str):
    by_id = {p.id: p for p in providers}
    if wanted in by_id:
        return by_id[wanted]
    if default_id in by_id:
        return by_id[default_id]
    if providers:
        return providers[0]
    raise RuntimeError("no jobs persistence provider is registered")


def build_store() -> JobStore:
    cfg = runtime.jobs_config()
    provider = _resolve(runtime.persistence_providers(), cfg.persistence, "sql")
    store = provider.create(runtime.component_env())
    store.init()
    return store
