"""Jobs plugin activator.

Declares the ``roadmap.jobs.persistence`` extension point, contributes the built-in SQLite
(default) + filesystem job stores, publishes the ``jobs`` service (CRUD + the reusable
``run_async`` helper), mounts ``/api/jobs``, and contributes a Jobs settings tab.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .contracts import JOBS_PERSISTENCE_POINT, JobStoreProvider
from .router import create_jobs_router
from .service import JobsService
from .settings_section import JOBS_SECTION
from .stores import BUILTIN_PERSISTENCE


class JobsPlugin(Plugin):
    id = "roadmap.jobs"
    name = "Jobs"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)

        ctx.define_point(JOBS_PERSISTENCE_POINT, JobStoreProvider,
                         "Persistence backends that store background job records.")
        for provider in BUILTIN_PERSISTENCE:
            ctx.extend(JOBS_PERSISTENCE_POINT, provider)

        ctx.extend(SETTINGS_SECTIONS_POINT, JOBS_SECTION)

        jobs = JobsService()
        ctx.services.register("jobs", jobs)
        ctx.add_router(create_jobs_router(jobs))
