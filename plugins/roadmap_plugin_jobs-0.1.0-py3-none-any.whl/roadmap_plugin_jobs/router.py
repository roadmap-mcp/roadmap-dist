"""HTTP surface: ``/api/jobs`` — list/get/delete jobs + the persistence selector.

A generic job monitor any plugin's UI can poll; owner/kind filters scope it to one plugin's
jobs (e.g. ``?owner=gitmining&kind=ingest``).
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel


class PersistenceRequest(BaseModel):
    provider: str


def create_jobs_router(jobs) -> APIRouter:
    router = APIRouter(prefix="/api/jobs", tags=["jobs"])

    @router.get("/persistence")
    def list_persistence():
        return {"providers": jobs.list_persistence()}

    @router.put("/persistence")
    def set_persistence(req: PersistenceRequest):
        return {"persistence": jobs.set_persistence(req.provider)}

    @router.get("")
    def list_jobs(owner: str = "", kind: str = "", limit: int = 100):
        return {"jobs": [j.model_dump() for j in jobs.list(owner, kind, limit)]}

    @router.get("/{job_id}")
    def get_job(job_id: str):
        j = jobs.get(job_id)
        if j is None:
            raise HTTPException(status_code=404, detail="Job not found.")
        return j.model_dump()

    @router.delete("/{job_id}")
    def delete_job(job_id: str):
        return {"deleted": jobs.delete(job_id)}

    return router
