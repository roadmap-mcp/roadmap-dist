"""Per-process runtime wiring for the jobs plugin (mirrors the mining/brain runtime)."""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import JOBS_PERSISTENCE_POINT
from .models import JobsConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def config_dir() -> Path:
    assert _store is not None, "jobs runtime not initialised"
    return _store.path.parent


def jobs_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/jobs``). Created on demand."""
    d = config_dir() / "jobs"
    d.mkdir(parents=True, exist_ok=True)
    return d


def jobs_config() -> JobsConfig:
    assert _store is not None, "jobs runtime not initialised"
    raw = _store.load_decrypted()
    return JobsConfig(**(raw.get("jobs") or {}))


def save_jobs_config(cfg: JobsConfig) -> JobsConfig:
    assert _store is not None, "jobs runtime not initialised"
    raw = _store.load_decrypted()
    raw["jobs"] = cfg.model_dump()
    _store.save(raw)
    return cfg


def persistence_providers() -> list:
    if _extensions is None:
        return []
    return list(_extensions.get(JOBS_PERSISTENCE_POINT))


def component_env() -> SimpleNamespace:
    return SimpleNamespace(config=jobs_config(), jobs_dir=jobs_dir())
