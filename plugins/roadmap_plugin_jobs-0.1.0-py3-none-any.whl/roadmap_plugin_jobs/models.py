"""Job models — a generic, durable background-work record reusable by any plugin.

A :class:`Job` is deliberately domain-neutral: ``owner`` (the plugin that created it) + ``kind``
tag it, ``data`` carries an arbitrary owner payload (e.g. a git-mining ingest stashes the repo
and branches), and ``log`` grows as the work runs so a UI can poll a live report. This replaces
each plugin hand-rolling its own run record; richer domain models (workflow invocations, e2e
runs) stay as they are and can reference a job by id if they want.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class JobLog(BaseModel):
    ts: str = ""
    level: str = "info"                    # info|warn|error
    message: str = ""


class Job(BaseModel):
    id: str
    owner: str = ""                        # creating plugin / logical owner, e.g. "gitmining"
    kind: str = ""                         # owner-defined, e.g. "ingest"
    title: str = ""
    status: str = "pending"                # pending|running|completed|failed|cancelled
    progress: float | None = None          # optional 0..1
    started: str = ""
    finished: str = ""
    summary: str = ""
    error: str = ""
    data: dict = Field(default_factory=dict)   # arbitrary owner payload
    log: list[JobLog] = Field(default_factory=list)


class JobsConfig(BaseModel):
    """The ``jobs`` config slice. ``persistence`` selects the active :class:`~.ports.JobStore`
    provider by id (``sql`` = SQLite default, ``filesystem``, or a satellite's id)."""

    persistence: str = "sql"
