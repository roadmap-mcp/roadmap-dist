"""The job-persistence port — the interface every job record goes through.

:class:`JobStore` is the whole abstraction the ``roadmap.jobs.persistence`` extension point
supplies; the service reads/writes jobs only through it, so the backend is swappable (built-in
SQLite + filesystem, or a satellite's Postgres/SQL-Server). A ``@runtime_checkable`` Protocol so
``ctx.extend`` validates a provider's product structurally — the same idiom as the mining and
brain stores.
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from .models import Job


@runtime_checkable
class JobStore(Protocol):
    id: str

    def init(self) -> None:
        """Create/upgrade the backing structure (idempotent; called once when built)."""
        ...

    def save(self, job: Job) -> None:
        """Insert-or-update a job by id (persisted incrementally so the UI can poll)."""
        ...

    def get(self, job_id: str) -> Job | None:
        ...

    def list(self, owner: str = "", kind: str = "", limit: int = 100) -> list[Job]:
        """Jobs newest first, optionally filtered by ``owner`` and/or ``kind``."""
        ...

    def delete(self, job_id: str) -> bool:
        ...

    def prune(self, owner: str = "", keep: int = 200) -> int:
        """Drop old finished jobs beyond the newest ``keep`` (per ``owner`` when given).
        Returns how many were removed."""
        ...
