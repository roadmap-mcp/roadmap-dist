"""Roadmap generic job registry.

A reusable, durable async-job facility any plugin can use instead of hand-rolling its own
background-work record: a :class:`Job` model, a :class:`JobsService` (CRUD + the
``run_async`` daemon-thread/workspace-repin helper), and mined-data-style swappable
persistence (``roadmap.jobs.persistence`` — built-in SQLite default + filesystem).

Re-exported so consumer plugins can ``from roadmap_plugin_jobs import JobsService, Job,
JOBS_PERSISTENCE_POINT, JobStoreProvider, JobStore``.
"""

from .contracts import JOBS_PERSISTENCE_POINT, JobStoreProvider
from .models import Job, JobLog
from .ports import JobStore
from .service import JobsService

__all__ = ["JOBS_PERSISTENCE_POINT", "JobStoreProvider", "JobStore",
           "Job", "JobLog", "JobsService"]
