"""Built-in job-persistence providers contributed to ``roadmap.jobs.persistence``."""

from __future__ import annotations

from ..contracts import JobStoreProvider
from .fs_store import FilesystemJobStore
from .sql_store import SqliteJobStore

SQL_PROVIDER = JobStoreProvider(
    id="sql",
    label="SQLite (built-in)",
    create=lambda env: SqliteJobStore(env.jobs_dir / "jobs.db"),
    icon="bi-database",
)

FILESYSTEM_PROVIDER = JobStoreProvider(
    id="filesystem",
    label="Filesystem (JSON files)",
    create=lambda env: FilesystemJobStore(env.jobs_dir / "data"),
    icon="bi-folder",
)

BUILTIN_PERSISTENCE = [SQL_PROVIDER, FILESYSTEM_PROVIDER]
