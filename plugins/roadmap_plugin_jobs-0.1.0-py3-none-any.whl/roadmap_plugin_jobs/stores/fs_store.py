"""Filesystem job store — a JSON-file-per-job :class:`~.ports.JobStore`.

The database-free alternative to SQLite: one file per job at ``<config_dir>/jobs/data/<id>.json``.
"""

from __future__ import annotations

import json
from pathlib import Path

from ..models import Job


def _read(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


class FilesystemJobStore:
    id = "filesystem"

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    def _path(self, job_id: str) -> Path:
        return self._root / f"{job_id}.json"

    def init(self) -> None:
        self._root.mkdir(parents=True, exist_ok=True)

    def save(self, job: Job) -> None:
        _write(self._path(job.id), job.model_dump())

    def get(self, job_id: str) -> Job | None:
        d = _read(self._path(job_id))
        return Job(**d) if d else None

    def _all(self) -> list[Job]:
        out = []
        for f in self._root.glob("*.json"):
            d = _read(f)
            if d:
                out.append(Job(**d))
        out.sort(key=lambda j: j.started, reverse=True)
        return out

    def list(self, owner: str = "", kind: str = "", limit: int = 100) -> list[Job]:
        out = [j for j in self._all()
               if (not owner or j.owner == owner) and (not kind or j.kind == kind)]
        return out[:limit]

    def delete(self, job_id: str) -> bool:
        p = self._path(job_id)
        if p.exists():
            p.unlink()
            return True
        return False

    def prune(self, owner: str = "", keep: int = 200) -> int:
        jobs = [j for j in self._all() if not owner or j.owner == owner]
        stale = jobs[keep:]
        for j in stale:
            self.delete(j.id)
        return len(stale)
