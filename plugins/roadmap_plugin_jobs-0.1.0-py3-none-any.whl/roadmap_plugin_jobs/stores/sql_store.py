"""SQLite job store — the default :class:`~.ports.JobStore` (stdlib ``sqlite3``).

One database file per workspace at ``<config_dir>/jobs/jobs.db``. The job's arbitrary
``data`` payload and its ``log`` are stored as JSON text. A short-lived connection per call, so
it is safe to use from the request thread and background worker threads alike.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from ..models import Job, JobLog

_SCHEMA = """
CREATE TABLE IF NOT EXISTS jobs (
    id       TEXT PRIMARY KEY,
    owner    TEXT,
    kind     TEXT,
    title    TEXT,
    status   TEXT,
    progress REAL,
    started  TEXT,
    finished TEXT,
    summary  TEXT,
    error    TEXT,
    data     TEXT,          -- json dict
    log      TEXT           -- json list of {ts, level, message}
);
CREATE INDEX IF NOT EXISTS ix_jobs_owner_started ON jobs (owner, started DESC);
CREATE INDEX IF NOT EXISTS ix_jobs_started ON jobs (started DESC);
"""


def _dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _loads(text, default):
    if not text:
        return default
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default


class SqliteJobStore:
    id = "sql"

    def __init__(self, db_path: Path) -> None:
        self._path = Path(db_path)

    def _conn(self) -> sqlite3.Connection:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    def init(self) -> None:
        with self._conn() as conn:
            conn.executescript(_SCHEMA)

    def save(self, job: Job) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO jobs
                       (id, owner, kind, title, status, progress, started, finished,
                        summary, error, data, log)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(id) DO UPDATE SET
                       owner=excluded.owner, kind=excluded.kind, title=excluded.title,
                       status=excluded.status, progress=excluded.progress,
                       started=excluded.started, finished=excluded.finished,
                       summary=excluded.summary, error=excluded.error,
                       data=excluded.data, log=excluded.log""",
                (job.id, job.owner, job.kind, job.title, job.status, job.progress,
                 job.started, job.finished, job.summary, job.error,
                 _dumps(job.data), _dumps([l.model_dump() for l in job.log])))

    def _row(self, row: sqlite3.Row) -> Job:
        return Job(
            id=row["id"], owner=row["owner"] or "", kind=row["kind"] or "",
            title=row["title"] or "", status=row["status"] or "pending",
            progress=row["progress"], started=row["started"] or "",
            finished=row["finished"] or "", summary=row["summary"] or "",
            error=row["error"] or "", data=_loads(row["data"], {}),
            log=[JobLog(**e) for e in _loads(row["log"], [])])

    def get(self, job_id: str) -> Job | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM jobs WHERE id = ?", (job_id,)).fetchone()
            return self._row(row) if row else None

    def list(self, owner: str = "", kind: str = "", limit: int = 100) -> list[Job]:
        clauses, params = [], []
        if owner:
            clauses.append("owner = ?"); params.append(owner)
        if kind:
            clauses.append("kind = ?"); params.append(kind)
        where = (" WHERE " + " AND ".join(clauses)) if clauses else ""
        params.append(limit)
        with self._conn() as conn:
            rows = conn.execute(
                f"SELECT * FROM jobs{where} ORDER BY started DESC LIMIT ?", params).fetchall()
            return [self._row(r) for r in rows]

    def delete(self, job_id: str) -> bool:
        with self._conn() as conn:
            cur = conn.execute("DELETE FROM jobs WHERE id = ?", (job_id,))
            return cur.rowcount > 0

    def prune(self, owner: str = "", keep: int = 200) -> int:
        with self._conn() as conn:
            if owner:
                rows = conn.execute(
                    "SELECT id FROM jobs WHERE owner = ? ORDER BY started DESC",
                    (owner,)).fetchall()
            else:
                rows = conn.execute(
                    "SELECT id FROM jobs ORDER BY started DESC").fetchall()
            stale = [r["id"] for r in rows[keep:]]
            for jid in stale:
                conn.execute("DELETE FROM jobs WHERE id = ?", (jid,))
            return len(stale)
