"""Per-process runtime wiring — stashes the config store at activate time so the
router can read ``scratch_base_dir`` without threading the store through calls."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore

_store: Optional[ConfigStore] = None

#: defaults so attribute access on the namespace view never blows up
DEFAULTS = {"scratch_base_dir": ""}


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def load_config():
    """Decrypted config as an attribute-accessible namespace (with defaults)."""
    assert _store is not None, "scratchdir runtime not initialised"
    return _store.load_ns(DEFAULTS)
