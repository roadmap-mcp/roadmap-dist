"""The ``scratch_dir`` context item type: resolve (add-time metadata) + render
(markdown for the AI / preview). Moved verbatim from the context plugin's
built-ins, adapted to the ``ContextItemType`` contribution signature."""

from __future__ import annotations

from pathlib import Path

from roadmap_plugin_context import ContextItemType


def _label(item: dict) -> str:
    return item.get("label", item.get("title", item.get("id", "")))


def _resolve_scratch_dir(path: str) -> dict:
    p = Path(path)
    p.mkdir(parents=True, exist_ok=True)
    return {
        "type": "scratch_dir",
        "id": path,
        "title": p.name,
        "label": p.name,
        "path": str(p),
    }


def _render_scratch_dir(path: str, label: str) -> str:
    """Render a scratch directory item."""
    return (
        f"## {label} (Scratch Directory)\n\n"
        f"**Path:** `{path}`\n\n"
        "This is a working directory for AI-generated files. "
        "When asked to generate documentation, diagrams, or scripts, "
        "write output files here, e.g.\n"
        "- **Markdown** (`.md`) — documentation, analysis reports\n"
        "- **PlantUML** (`.puml`) — sequence diagrams, class diagrams, component diagrams\n"
        "- **Python** (`.py`) — data processing scripts, analysis tools\n"
        "- **JSON/YAML** — configuration, data exports\n\n"
        "Create subdirectories as needed to organize output."
    )


SCRATCH_DIR_ITEM_TYPE = ContextItemType(
    "scratch_dir",
    resolve=lambda item_id, *, text=None, path=None: _resolve_scratch_dir(item_id),
    render=lambda item, cfg: _render_scratch_dir(item.get("id", ""), _label(item)),
    label="Scratch Dir",
    icon="bi-folder2-open",
)
