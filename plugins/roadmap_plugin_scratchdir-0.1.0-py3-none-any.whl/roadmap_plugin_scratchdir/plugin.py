"""Scratch-directory plugin activator — contributes the ``scratch_dir`` context
item type and serves ``/api/scratchdir``."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .item_type import SCRATCH_DIR_ITEM_TYPE
from .scratchdir_router import router as scratchdir_router

# The scratch-dir base directory setting lives with the plugin that owns scratch
# dirs (was an edition built-in). Keep id="context" so the edition's
# inline Settings tab and the scratch_base_dir config slice stay unchanged.
SCRATCH_SECTION = SettingsSection(
    id="context", label="Context", order=10, group="General",
    defaults=lambda: {"scratch_base_dir": ""},
)


class ScratchdirPlugin(Plugin):
    id = "roadmap.scratchdir"
    name = "Scratch Directories"
    requires = ["roadmap.context", "roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.extend(CONTEXT_ITEM_TYPES_POINT, SCRATCH_DIR_ITEM_TYPE)
        ctx.extend(SETTINGS_SECTIONS_POINT, SCRATCH_SECTION)
        ctx.add_router(scratchdir_router)
