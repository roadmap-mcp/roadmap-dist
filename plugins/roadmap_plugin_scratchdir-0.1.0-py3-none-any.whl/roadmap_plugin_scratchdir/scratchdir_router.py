"""``/api/scratchdir`` — the small HTTP surface the add-item UI needs."""

from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter

from .runtime import load_config

router = APIRouter(prefix="/api/scratchdir", tags=["scratchdir"])


@router.get("/default/{context_name}")
def default_scratch_dir(context_name: str):
    """The default scratch directory for a context: ``<scratch_base_dir>/<name>``.
    Returns ``configured: False`` when no base directory is set in config."""
    base = load_config().scratch_base_dir
    if not base:
        return {"path": "", "configured": False}
    return {"path": str(Path(base) / context_name), "configured": True}
