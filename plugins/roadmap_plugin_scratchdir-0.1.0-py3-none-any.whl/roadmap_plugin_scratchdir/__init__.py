"""Scratch-directory plugin.

Contributes the ``scratch_dir`` context item type to the
``roadmap.context.itemTypes`` extension point declared by the context plugin, and
serves ``/api/scratchdir`` (the default-path helper the add-item UI uses). This
was previously a built-in of the context plugin; it now lives on its own so the
scratch-directory feature is an installable, removable unit.
"""
