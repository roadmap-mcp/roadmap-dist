"""ActiveMQ executor plugin activator.

Contributes the self-describing ``activemq`` executor provider (icon + config-field schema)
to the engine's ``roadmap.workflow.executors`` point, so the ``activemq`` step kind and its
form appear in the workflow step editor with no change to the engine. The provider builds a
:class:`~.executor.ActiveMqExecutor` lazily when a run starts.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_workflow import (
    WORKFLOW_EXECUTORS_POINT, ExecutorField, ExecutorProvider,
)

from .executor import ActiveMqExecutor

ACTIVEMQ_PROVIDER = ExecutorProvider(
    id="activemq",
    label="ActiveMQ publish",
    icon="bi-send",
    create=lambda env: ActiveMqExecutor(env.config),
    fields=[
        ExecutorField(
            key="broker", label="Broker (web console URL)", type="text",
            placeholder="http://localhost:8161",
            hint="the /api/message REST endpoint is appended",
        ),
        ExecutorField(
            key="destination", label="Destination", type="text",
            placeholder="queue://MyQueue",
            hint="queue://Name or topic://Name",
        ),
        ExecutorField(
            key="properties", label="JMS properties / headers", type="headers",
            placeholder="JMSType: com.example.Event\nMyProperty: some-value",
            hint="each becomes a query param (reserved names like JMSType set that header)",
        ),
        ExecutorField(
            key="body", label="Message body", type="textarea",
            placeholder='{ "example": true }',
        ),
        ExecutorField(
            key="user", label="User", type="text", placeholder="{{vault.mq.username}}",
        ),
        ExecutorField(
            key="password", label="Password", type="text", placeholder="{{vault.mq.password}}",
        ),
        ExecutorField(
            key="content_type", label="Content-Type", type="text",
            placeholder="application/json",
        ),
    ],
)


class WorkflowActiveMqPlugin(Plugin):
    id = "roadmap.workflow.activemq"
    name = "Workflows — ActiveMQ executor"
    requires = ["roadmap.workflow"]

    def activate(self, ctx: PluginContext) -> None:
        ctx.extend(WORKFLOW_EXECUTORS_POINT, ACTIVEMQ_PROVIDER)
