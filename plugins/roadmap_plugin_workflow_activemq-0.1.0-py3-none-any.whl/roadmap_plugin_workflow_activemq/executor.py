"""The ``activemq`` executor — publish one message via ActiveMQ Classic's REST API.

ActiveMQ Classic exposes ``POST <console>/api/message`` where the body becomes the message
and **any non-reserved query parameter becomes a JMS string property** (and reserved ones
like ``JMSType`` set the corresponding JMS header). That is the only way to set custom JMS
properties that a consumer's selector filters on — the web console's send form can't. So
this executor is a thin, dependency-light HTTP POST (``httpx``), not a JMS/STOMP client.

``config`` fields (``${param}`` / ``{{vault…}}`` aware — resolved + redacted by the engine)::

    broker        web-console base URL, e.g. ``http://localhost:8161`` (``/api/message`` is
                  appended). Required.
    destination   ``queue://Name`` or ``topic://Name``. Required.
    properties    object of JMS properties / reserved headers (``JMSType``, custom string
                  props, …) — each becomes a query parameter.
    body          the message body (JSON or text).
    user/password Basic-auth login (optional) — reference the vault, e.g.
                  ``{{vault.mq.username}}`` / ``{{vault.mq.password}}``.
    content_type  request Content-Type (default ``application/json``).

A CSRF-priming GET runs first (harmless if CSRF is off) so any secret cookie is reused on
the POST. A non-2xx/3xx is an ordinary ``failed`` outcome, never a raise.
"""

from __future__ import annotations

import json

import httpx

from roadmap_plugin_workflow import StepOutcome

_BODY_HEAD = 2000


class ActiveMqExecutor:
    id = "activemq"

    def __init__(self, config):
        self._timeout = getattr(config, "default_timeout", 30.0)

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        c = step.get("config") or {}
        broker = (c.get("broker") or "").strip()
        destination = (c.get("destination") or "").strip()
        if not broker:
            return StepOutcome(status="failed",
                               error="activemq step needs config.broker (the web-console URL)")
        if not destination:
            return StepOutcome(status="failed",
                               error="activemq step needs config.destination "
                                     "(queue://Name or topic://Name)")

        base = broker.rstrip("/") + "/api/message"
        params: dict = {"destination": destination}
        for k, v in (c.get("properties") or {}).items():
            params[str(k)] = "" if v is None else str(v)

        body = c.get("body")
        if body is None:
            body = ""
        content = body if isinstance(body, str) else json.dumps(body)
        content_type = (c.get("content_type") or "application/json").strip()

        user = (c.get("user") or "").strip()
        password = c.get("password") or ""
        auth = (user, password) if user else None
        timeout = step.get("timeout") or self._timeout

        try:
            with httpx.Client(timeout=timeout, follow_redirects=True, auth=auth) as client:
                # prime any CSRF cookie (stored on the client, reused by the POST);
                # harmless if the broker has CSRF disabled.
                try:
                    client.get(base)
                except Exception:
                    pass
                resp = client.post(base, params=params, content=content,
                                   headers={"Content-Type": content_type})
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        out: dict = {
            "status": resp.status_code,
            "destination": destination,
            "body": resp.text[:_BODY_HEAD],
        }
        if not (200 <= resp.status_code < 400):
            return StepOutcome(status="failed", error=f"HTTP {resp.status_code}", output=out)
        return StepOutcome(status="passed", output=out)

    def close(self) -> None:
        return None
