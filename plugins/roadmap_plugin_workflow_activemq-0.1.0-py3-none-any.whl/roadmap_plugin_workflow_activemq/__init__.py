"""ActiveMQ executor plugin for the Roadmap workflow engine.

A satellite of ``roadmap.workflow`` (like the SQL executor): contributes a single
``activemq`` executor to the ``roadmap.workflow.executors`` point. It publishes a message
through **ActiveMQ Classic's REST API** (``/api/message`` on the web console) — an ordinary
HTTP POST, so there is no JMS/STOMP client to install. Activating the plugin does nothing
until a ``activemq`` step runs.
"""
