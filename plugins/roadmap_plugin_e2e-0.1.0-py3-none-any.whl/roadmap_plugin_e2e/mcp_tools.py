"""E2E MCP tools on the shared server.

* ``e2e_list_scenarios`` — list runnable scenarios (id + name + params).
* ``e2e_run_scenario``   — start a run (async); returns the run id to poll.
* ``e2e_get_run``        — the step-through report for a run id (markdown).
* ``e2e_pin_run``        — pin a finished run report into a context (an ``e2e_run`` item).

No ``from __future__ import annotations`` — FastMCP introspects the real annotations.

These are the seed for the future AI-assisted test design: an assistant enumerates
scenarios, kicks a run, reads the report, and pins it into a context for follow-up.
"""

import json

from . import storage


def register_mcp_tools(context, e2e) -> None:
    mcp = context.mcp

    @mcp.tool()
    def e2e_list_scenarios() -> str:
        """List the web-test scenarios that can be run, with their parameters."""
        scenarios = e2e.list_scenarios()
        if not scenarios:
            return "No scenarios defined. Create one in the Testing workbench first."
        lines = ["# Web-test scenarios", ""]
        for s in scenarios:
            params = ", ".join(p.name for p in s.params) or "none"
            lines.append(f"- `{s.id}` — {s.name} ({len(s.steps)} step(s); params: {params})")
        return "\n".join(lines)

    @mcp.tool()
    def e2e_run_scenario(scenario_id: str, context_json: str = "") -> str:
        """Start a web-test scenario run.

        The run executes in the background; use ``e2e_get_run`` with the returned run
        id to poll status and read the step-through report.

        Args:
            scenario_id:  the scenario's id (from e2e_list_scenarios).
            context_json: optional JSON object of parameter values, e.g.
                          '{"username": "alice"}'.
        """
        ctx = {}
        if context_json.strip():
            try:
                ctx = json.loads(context_json)
            except json.JSONDecodeError as ex:
                return f"Invalid context_json: {ex}"
        try:
            run = e2e.start_run(scenario_id, ctx)
        except ValueError as ex:
            return str(ex)
        return (f"Started run `{run.id}` for '{run.scenario_name}' (status: {run.status}). "
                f"Poll it with e2e_get_run('{run.id}').")

    @mcp.tool()
    def e2e_get_run(run_id: str) -> str:
        """The step-through report for a run id (status + per-step results + captured
        parameter values), as markdown."""
        run = e2e.get_run(run_id)
        if run is None:
            return f"Run '{run_id}' not found."
        return e2e.render_run(run_id)

    @mcp.tool()
    def e2e_pin_run(name: str, run_id: str, label: str = "") -> str:
        """Pin a finished run's report into a context as a snapshot.

        Args:
            name:   context path ('my-context' or 'parent/child').
            run_id: the run id (from e2e_run_scenario / e2e_get_run).
            label:  optional display label.
        """
        if storage.get_run(run_id) is None:
            return f"Run '{run_id}' not found."
        item = context.resolve_item("e2e_run", run_id, label or None)
        added, skipped = context.add_context_items(name, [item])
        if added:
            return f"Pinned run '{item.get('label')}' to context '{name}'."
        if skipped:
            return f"Run '{item.get('label')}' is already in context '{name}'."
        return f"Could not pin to context '{name}' (does it exist?)."
