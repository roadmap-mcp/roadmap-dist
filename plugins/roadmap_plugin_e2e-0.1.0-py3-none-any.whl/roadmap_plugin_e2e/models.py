"""The E2E domain + the ``e2e`` config slice.

Model shape (all persisted as JSON under ``<config_dir>/e2e/``):

* :class:`Step` — one reusable action. A *hybrid* step: common actions are
  structured (``type`` + ``target`` + ``value``), and a ``script`` step carries a raw
  Selenium Python ``snippet`` as an escape hatch.
* :class:`Component` — a page-object: a named, reusable group of actions that can
  also include other components (a ``page`` embeds a cookie ``popup`` + a ``table``).
* :class:`Scenario` — composes steps (by reference into a page's library, or inline)
  into a test, declaring the ``params`` it takes.
* :class:`TestRun` / :class:`StepResult` — one execution and its step-by-step report.
* :class:`E2EConfig` — the ``e2e`` config slice (driver selection + browser options).
"""

from __future__ import annotations

from pydantic import BaseModel, Field

# ── the reusable step ─────────────────────────────────────────────────────────

#: structured action types the drivers understand, plus the ``script`` escape hatch.
STEP_TYPES = [
    "navigate", "click", "type", "select", "wait",
    "assert_text", "assert_visible", "capture", "script",
]

#: locator strategies (mapped to Selenium ``By.*`` by the selenium driver).
BY_STRATEGIES = ["css", "id", "name", "xpath", "link_text", "text"]


class Target(BaseModel):
    """How to locate an element."""

    by: str = "css"                       # one of BY_STRATEGIES
    value: str = ""                       # selector / id / xpath (supports ${param})


class Step(BaseModel):
    """One reusable action. ``type`` selects which fields matter:

    | type            | uses                                   |
    |-----------------|----------------------------------------|
    | navigate        | ``value`` (url, absolute or base-relative) |
    | click           | ``target``                             |
    | type            | ``target`` + ``value`` (text to enter) |
    | select          | ``target`` + ``value`` (option)        |
    | wait            | ``target`` (until present) or ``value`` (seconds) |
    | assert_text     | ``target`` + ``value`` (expected substring) |
    | assert_visible  | ``target``                             |
    | capture         | ``target`` + ``capture_as`` (context key) |
    | script          | ``snippet`` (raw ``driver``/``ctx`` code) |
    """

    id: str
    type: str
    label: str = ""
    target: Target = Field(default_factory=Target)
    value: str = ""                       # supports ${param} interpolation
    capture_as: str = ""                  # for `capture`: context key to store into
    snippet: str = ""                     # for `script`
    params: list[str] = Field(default_factory=list)   # param names this step reads (UX)
    timeout: float | None = None          # per-step override (seconds)


class Site(BaseModel):
    """An application under test (e.g. one intranet app). Owns the base URL its
    components' relative navigations resolve against — a server can host tests for
    many sites, so the base URL lives here, not in global settings."""

    id: str
    name: str
    description: str = ""
    base_url: str = ""


#: component kinds (organizational only — drive an icon + grouping, no behaviour)
COMPONENT_KINDS = ["page", "popup", "menu", "section", "table", "other"]


class CompositeStep(BaseModel):
    """One ordered entry in a Component or Scenario. Exactly one of:

    * ``step`` — an inline action (a :class:`Step`, with its own id); or
    * ``ref`` — a reference to another component: ``"<component_id>"`` includes that
      whole component (all its entries, recursively), and ``"<component_id>/<step_id>"``
      reuses a single inline action from it.

    ``bindings`` overlay the run context for this entry (and, for a whole-component
    include, all of its nested entries) — ``{"username": "${admin_user}"}`` remaps a
    param, ``{"username": "root"}`` pins a constant."""

    ref: str = ""
    step: Step | None = None
    bindings: dict[str, str] = Field(default_factory=dict)


class Component(BaseModel):
    """A reusable page-object component: a named, ordered group of actions that can
    also **include other components** (a ``page`` embeds a cookie ``popup`` + a
    ``table``; the table's sort/filter actions live once and are reused wherever the
    table appears). Belongs to a Site. ``kind`` is organizational only."""

    id: str
    site_id: str = ""
    name: str
    kind: str = "page"                    # one of COMPONENT_KINDS (icon + grouping)
    description: str = ""
    steps: list[CompositeStep] = Field(default_factory=list)


# ── scenarios (compose components) ────────────────────────────────────────────

class ScenarioParam(BaseModel):
    """An input a scenario declares. Values are supplied per run (the run context)."""

    name: str
    label: str = ""
    default: str = ""
    required: bool = False


class Scenario(BaseModel):
    id: str
    name: str
    description: str = ""
    base_url: str = ""                    # base URL for inline (component-less) actions
    params: list[ScenarioParam] = Field(default_factory=list)
    steps: list[CompositeStep] = Field(default_factory=list)


# ── runs + report ─────────────────────────────────────────────────────────────

class StepResult(BaseModel):
    index: int
    ref: str = ""                         # "page/step" or "inline"
    type: str = ""
    label: str = ""
    status: str = "pending"               # pending|passed|failed|skipped
    started: str = ""
    finished: str = ""
    error: str = ""
    screenshot: str = ""                  # filename under runs/<id>/screenshots/
    captured: dict = Field(default_factory=dict)
    resolved: dict = Field(default_factory=dict)   # interpolated fields actually run


class TestRun(BaseModel):
    id: str
    scenario_id: str
    scenario_name: str = ""
    status: str = "running"               # running|passed|failed|error
    driver: str = ""
    snapshots: bool = True                # whether page snapshots were captured per step
    started: str = ""
    finished: str = ""
    context_in: dict = Field(default_factory=dict)
    context_out: dict = Field(default_factory=dict)
    step_results: list[StepResult] = Field(default_factory=list)
    error: str = ""


# ── config slice ──────────────────────────────────────────────────────────────

class E2EConfig(BaseModel):
    driver: str = "mock"                  # roadmap.e2e.drivers provider id (mock|selenium)
    browser: str = "chrome"
    headless: bool = True
    # note: no base_url here — a server hosts many sites, so the base URL is per-Site.
    remote_url: str = ""                  # optional remote WebDriver URL (Selenium Grid)
    capture_snapshots: bool = True        # default for taking a page snapshot per step
    default_timeout: float = 10.0         # seconds for waits / element lookups
    window_width: int = 1280
    window_height: int = 900
