"""Roadmap E2E testing engine (driver-agnostic).

Owns the test domain (pages / scenarios / runs), storage, the scenario compiler +
executor, the HTTP API, and the ``roadmap.e2e.drivers`` extension point. A *driver*
(e.g. the Selenium plugin) contributes a :class:`DriverProvider` that builds a
:class:`Driver` — the thing that actually performs a step against a real target.

Re-exported here so driver plugins can ``from roadmap_plugin_e2e import
E2E_DRIVERS_POINT, DriverProvider, Driver, StepOutcome`` without reaching into
submodules.
"""

from .contracts import E2E_DRIVERS_POINT, DriverProvider
from .ports import Driver, LiveDriver, StepOutcome

__all__ = ["E2E_DRIVERS_POINT", "DriverProvider", "Driver", "LiveDriver", "StepOutcome"]
