"""The Web Testing settings section (the ``e2e`` config slice + defaults)."""

from roadmap_plugin_settings import SettingsSection

from .models import E2EConfig

E2E_SECTION = SettingsSection(
    id="e2e",
    label="Web Testing",
    order=60,
    group="Testing",
    defaults=lambda: {"e2e": E2EConfig().model_dump()},
)
