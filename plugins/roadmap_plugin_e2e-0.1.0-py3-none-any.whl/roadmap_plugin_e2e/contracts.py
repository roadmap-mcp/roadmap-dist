"""The E2E engine's one extension point: pluggable test *drivers*.

A driver is what actually performs a step against a target — Selenium against a
browser today; an HTTP/API or mobile driver later. Drivers are supplied as a small
``{id, label, create}`` *provider* descriptor whose ``create(env)`` builds the
:class:`~.ports.Driver` when a run starts (a driver needs runtime context — the
resolved config — so it is built lazily, not registered as a pre-made singleton).

The engine declares this point and contributes a built-in ``mock`` driver (no
browser, for tests + previews). Any other plugin contributes an alternative by
depending on ``roadmap.e2e`` and extending :data:`E2E_DRIVERS_POINT`. Which driver a
run uses is chosen by config (``e2e.driver``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

E2E_DRIVERS_POINT = "roadmap.e2e.drivers"


@dataclass
class DriverProvider:
    """Registers a named :class:`~.ports.Driver` implementation."""

    id: str                               # "mock", "selenium", …
    label: str
    create: Callable[[Any], Any]          # create(env) -> Driver
