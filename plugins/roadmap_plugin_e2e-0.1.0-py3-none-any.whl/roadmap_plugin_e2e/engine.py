"""Scenario compiler + executor — the driver-agnostic heart of the engine.

* **compile** a :class:`~.models.Scenario` into a flat, ordered list of concrete
  steps: recursively expand each ``CompositeStep`` (an inline action, a
  ``component/step`` action reference, or a whole-``component`` include) and remember
  its per-step ``bindings``.
* **execute** that list through the configured :class:`~.ports.Driver`, one step at a
  time: overlay the step's bindings on the run context, interpolate ``${param}``
  placeholders, run the step, capture a screenshot, merge any captured values back
  into the context, and persist the growing report so the UI can poll progress.

Runs happen on a background daemon thread. Threads don't inherit request contextvars,
so the worker re-pins ``current_workspace`` (the same pattern the brain scheduler
uses) — otherwise storage would resolve the wrong tenant's dir.
"""

from __future__ import annotations

import re
import threading
import traceback
from datetime import datetime, timezone
from urllib.parse import urljoin

from roadmap_framework import current_workspace

from . import runtime, storage
from .models import Scenario, Step, StepResult, TestRun

_PLACEHOLDER = re.compile(r"\$\{([^}]+)\}")
_ABSOLUTE = ("http://", "https://", "file://", "about:")


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


def interp(text: str, ctx: dict) -> str:
    """Replace ``${key}`` with ``ctx[key]`` (missing keys collapse to empty)."""
    if not text or "${" not in text:
        return text
    return _PLACEHOLDER.sub(lambda m: str(ctx.get(m.group(1).strip(), "")), text)


def _join_url(base: str, value: str) -> str:
    """Resolve a (possibly relative) navigate URL against the site's base URL."""
    if not value or value.lower().startswith(_ABSOLUTE) or not base:
        return value
    return urljoin(base.rstrip("/") + "/", value.lstrip("/"))


def _resolve_step(step: Step, ctx: dict, base_url: str = "") -> dict:
    """A plain dict of the step with every string field ``${param}``-interpolated —
    what the driver actually executes, and what the report records as ``resolved``.
    ``navigate`` values are resolved against ``base_url`` (the step's Site)."""
    value = interp(step.value, ctx)
    if step.type == "navigate":
        value = _join_url(base_url, value)
    return {
        "type": step.type,
        "label": step.label,
        "target": {"by": step.target.by, "value": interp(step.target.value, ctx)},
        "value": value,
        "capture_as": step.capture_as,
        "snippet": step.snippet,          # snippets read ctx live; not pre-interpolated
        "timeout": step.timeout,
    }


def compile_scenario(scenario: Scenario) -> list[tuple[str, Step, dict, str]]:
    """Flatten a scenario to ``[(ref_label, Step, bindings, base_url), …]``.

    Recursively expands component references: a ``CompositeStep`` is an inline action,
    a single action of a component (``ref = "<component>/<step>"``), or a whole-component
    include (``ref = "<component>"``) whose entries expand in place — components can
    include components, so a ``page`` embeds a ``popup`` + a ``table``. Each atomic
    action's ``base_url`` is its owning component's Site base URL (inline scenario
    actions fall back to the scenario's ``base_url``); an include's ``bindings`` cascade
    onto every nested action. Cycles and dangling references become failed steps rather
    than blowing up the run.
    """
    out: list[tuple[str, Step, dict, str]] = []
    _expand(scenario.steps, None, scenario, set(), out, "", {})
    return out


def _site_base_url(component, scenario: Scenario) -> str:
    if component is None:
        return scenario.base_url
    site = storage.get_site(component.site_id) if component.site_id else None
    return site.base_url if site else scenario.base_url


def _broken(ref_label: str, reason: str) -> tuple[str, Step, dict, str]:
    return (ref_label, Step(id="missing", type="assert_visible", label=reason),
            {"__broken__": reason}, "")


def _find_action(component, step_id: str) -> Step | None:
    for cs in component.steps:
        if cs.step is not None and cs.step.id == step_id:
            return cs.step
    return None


def _expand(steps, owner, scenario: Scenario, visited: set, out: list,
            prefix: str, inherited: dict) -> None:
    for cs in steps:
        bindings = {**inherited, **cs.bindings}
        if cs.step is not None:                          # inline action
            label = f"{prefix}{cs.step.label or cs.step.id}"
            out.append((label, cs.step, bindings, _site_base_url(owner, scenario)))
            continue
        ref = cs.ref or ""
        comp_id, _, step_id = ref.partition("/")
        comp = storage.get_component(comp_id) if comp_id else None
        if comp is None:
            out.append(_broken(ref or "?", f"Unknown component reference: {ref or '(empty)'}"))
            continue
        if step_id:                                      # a single action of a component
            found = _find_action(comp, step_id)
            if found is None:
                out.append(_broken(ref, f"Unknown action in component: {ref}"))
                continue
            label = f"{prefix}{comp.name} / {found.label or found.id}"
            out.append((label, found, bindings, _site_base_url(comp, scenario)))
        elif comp.id in visited:                         # whole include, but a cycle
            out.append(_broken(ref, f"Circular include of component '{comp.name}'"))
        else:                                            # whole-component include (recurse)
            _expand(comp.steps, comp, scenario, visited | {comp.id}, out,
                    f"{prefix}{comp.name} / ", bindings)


def run_scenario(run_id: str) -> None:
    """Execute a run to completion, persisting after every step. Never raises — any
    failure is recorded on the run and the driver is always closed."""
    run = storage.get_run(run_id)
    if run is None:
        return
    scenario = storage.get_scenario(run.scenario_id)
    if scenario is None:
        run.status = "error"
        run.error = f"Scenario '{run.scenario_id}' not found."
        run.finished = _now()
        storage.save_run(run)
        return

    ctx: dict = dict(run.context_in)
    # seed declared-param defaults that the caller didn't supply
    for p in scenario.params:
        ctx.setdefault(p.name, p.default)

    steps = compile_scenario(scenario)
    driver = None
    try:
        driver = runtime.resolve_driver()
        run.driver = getattr(driver, "id", runtime.e2e_config().driver)
        storage.save_run(run)
        driver.start()

        for i, (ref, step, bindings, base_url) in enumerate(steps):
            result = _execute_step(run, i, ref, step, bindings, base_url, ctx, driver)
            run.step_results.append(result)
            run.context_out = dict(ctx)
            storage.save_run(run)                     # incremental — UI polls this
            if result.status == "failed":
                run.status = "failed"
                # mark the remaining steps skipped
                for j in range(i + 1, len(steps)):
                    ref_j, step_j, _, _ = steps[j]
                    run.step_results.append(StepResult(
                        index=j, ref=ref_j, type=step_j.type,
                        label=ref_j or step_j.label or step_j.id, status="skipped"))
                break
        else:
            run.status = "passed"
    except Exception as e:                            # driver start/other hard failure
        run.status = "error"
        run.error = f"{type(e).__name__}: {e}\n{traceback.format_exc()}"
    finally:
        if driver is not None:
            try:
                driver.close()
            except Exception:
                pass
        run.finished = _now()
        run.context_out = dict(ctx)
        storage.save_run(run)


def _execute_step(run: TestRun, index: int, ref: str, step: Step,
                  bindings: dict, base_url: str, ctx: dict, driver) -> StepResult:
    started = _now()
    # ``ref`` is the compiled path label (e.g. "Products / Cookie popup / Accept") —
    # the most informative name for a nested action; fall back to the step's own label.
    result = StepResult(index=index, ref=ref, type=step.type,
                        label=ref or step.label or step.id, status="running",
                        started=started)

    if "__broken__" in bindings:
        result.status = "failed"
        result.error = f"Unresolved step reference: {bindings['__broken__']}"
        result.finished = _now()
        return result

    # overlay this step's bindings on the run context (interpolated), then resolve
    eff_ctx = dict(ctx)
    for k, v in bindings.items():
        eff_ctx[k] = interp(v, ctx)
    resolved = _resolve_step(step, eff_ctx, base_url)
    result.resolved = resolved

    try:
        outcome = driver.run_step(resolved, ctx)
        result.status = outcome.status
        result.error = outcome.error
        if outcome.captured:
            result.captured = dict(outcome.captured)
            ctx.update(outcome.captured)
    except Exception as e:
        result.status = "failed"
        result.error = f"{type(e).__name__}: {e}"

    if run.snapshots:
        try:
            shot = driver.screenshot()
            if shot:
                result.screenshot = storage.save_screenshot(run.id, index, shot)
        except Exception:
            pass

    result.finished = _now()
    return result


# ── background launch ─────────────────────────────────────────────────────────

def start_async(run_id: str) -> None:
    """Run ``run_id`` on a daemon thread, re-pinning the current workspace inside it."""
    ws = current_workspace.get()

    def _worker() -> None:
        token = current_workspace.set(ws)
        try:
            run_scenario(run_id)
        finally:
            current_workspace.reset(token)

    threading.Thread(target=_worker, name=f"e2e-run-{run_id}", daemon=True).start()
