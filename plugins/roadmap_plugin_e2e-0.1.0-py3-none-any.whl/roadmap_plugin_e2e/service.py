"""The ``e2e`` service — the facade the router, MCP tools, and context item use.

Thin: CRUD over pages/scenarios/runs plus starting a run (which kicks the background
executor). Keeps a stable surface so the driver/executor internals can change without
touching callers.
"""

from __future__ import annotations

from datetime import datetime, timezone

from . import engine, runtime, storage
from .models import Component, Scenario, Site, StepResult, TestRun


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class E2EService:
    # ── sites ─────────────────────────────────────────────────────────────────
    def list_sites(self) -> list[Site]:
        return storage.list_sites()

    def get_site(self, site_id: str) -> Site | None:
        return storage.get_site(site_id)

    def save_site(self, site: Site) -> Site:
        return storage.save_site(site)

    def delete_site(self, site_id: str) -> bool:
        return storage.delete_site(site_id)

    # ── components (page-objects) ─────────────────────────────────────────────
    def list_components(self, site_id: str | None = None) -> list[Component]:
        return storage.list_components(site_id)

    def get_component(self, component_id: str) -> Component | None:
        return storage.get_component(component_id)

    def save_component(self, component: Component) -> Component:
        return storage.save_component(component)

    def delete_component(self, component_id: str) -> bool:
        return storage.delete_component(component_id)

    # ── scenarios ─────────────────────────────────────────────────────────────
    def list_scenarios(self) -> list[Scenario]:
        return storage.list_scenarios()

    def get_scenario(self, scenario_id: str) -> Scenario | None:
        return storage.get_scenario(scenario_id)

    def save_scenario(self, scenario: Scenario) -> Scenario:
        return storage.save_scenario(scenario)

    def delete_scenario(self, scenario_id: str) -> bool:
        return storage.delete_scenario(scenario_id)

    # ── runs ──────────────────────────────────────────────────────────────────
    def list_runs(self) -> list[TestRun]:
        return storage.list_runs()

    def get_run(self, run_id: str) -> TestRun | None:
        return storage.get_run(run_id)

    def delete_run(self, run_id: str) -> bool:
        return storage.delete_run(run_id)

    def start_run(self, scenario_id: str, context: dict | None = None,
                  snapshots: bool | None = None) -> TestRun:
        """Create a run, persist it as ``running``, launch the background executor,
        and return immediately. The caller polls ``get_run`` for progress.

        ``snapshots`` toggles per-step page screenshots for this run; ``None`` uses the
        ``e2e.capture_snapshots`` config default."""
        scenario = storage.get_scenario(scenario_id)
        if scenario is None:
            raise ValueError(f"Scenario '{scenario_id}' not found.")
        want_snaps = runtime.e2e_config().capture_snapshots if snapshots is None else snapshots
        run = TestRun(
            id=storage.new_id("run"),
            scenario_id=scenario_id,
            scenario_name=scenario.name,
            status="running",
            snapshots=want_snaps,
            started=_now(),
            context_in=dict(context or {}),
        )
        storage.save_run(run)
        engine.start_async(run.id)
        return run

    # ── run report as markdown (used by the e2e_run context item) ─────────────
    def render_run(self, run_id: str) -> str:
        run = storage.get_run(run_id)
        if run is None:
            return f"*E2E run `{run_id}` not found.*"
        return render_run_markdown(run)


def render_run_markdown(run: TestRun) -> str:
    icon = {"passed": "✓", "failed": "✗", "error": "!", "running": "…"}
    lines = [
        f"# Test run — {run.scenario_name or run.scenario_id}",
        "",
        f"- **Status:** {run.status}",
        f"- **Driver:** {run.driver or '—'}",
        f"- **Started:** {run.started}",
        f"- **Finished:** {run.finished or '—'}",
    ]
    if run.context_in:
        params = ", ".join(f"`{k}`={v!r}" for k, v in run.context_in.items())
        lines.append(f"- **Parameters:** {params}")
    if run.error:
        lines += ["", f"> **Error:** {run.error}"]
    lines += ["", "## Steps", ""]
    for r in run.step_results:
        _step_markdown(lines, r, icon)
    return "\n".join(lines)


def _step_markdown(lines: list[str], r: StepResult, icon: dict) -> None:
    mark = icon.get(r.status, "·")
    lines.append(f"{r.index + 1}. {mark} **{r.label or r.type}** "
                 f"(`{r.type}`) — {r.status}")
    if r.error:
        lines.append(f"   - error: {r.error}")
    if r.captured:
        caps = ", ".join(f"`{k}`={v!r}" for k, v in r.captured.items())
        lines.append(f"   - captured: {caps}")
