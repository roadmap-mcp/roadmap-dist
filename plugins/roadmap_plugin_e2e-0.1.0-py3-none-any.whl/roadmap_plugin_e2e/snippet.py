"""Restricted execution for ``script`` steps.

A ``script`` step is the escape hatch: raw Python run against the live ``driver`` and
run ``ctx``. This is, by design, code the test author wrote — arbitrary execution
with the backend's privileges. It is acceptable for a **self-hosted, single-operator
test-authoring tool**, and it's the literal "selenium snippets" the feature asks for.

This helper *scopes* that execution — a curated builtins set and only the names a
snippet legitimately needs (``driver``, ``ctx``, ``By``, ``assert_*`` helpers) — so an
accidental ``import os`` fails fast rather than silently working. **It is not a
sandbox**: a determined author can still escape it. Treat ``script`` steps as trusted
code and only let trusted authors write them.
"""

from __future__ import annotations

from typing import Any

# a deliberately small builtins surface — enough to write assertions and light logic,
# without file/network/import primitives.
def _build_safe_builtins() -> dict:
    b = __builtins__
    names = (
        "len", "range", "str", "int", "float", "bool", "list", "dict", "set",
        "tuple", "enumerate", "zip", "min", "max", "sum", "sorted", "abs", "any",
        "all", "isinstance", "print", "repr", "map", "filter", "round",
        "AssertionError", "Exception", "ValueError", "KeyError", "IndexError",
    )
    out: dict[str, Any] = {}
    for name in names:
        val = (b.get(name) if isinstance(b, dict) else getattr(b, name, None))
        if val is not None:
            out[name] = val
    return out


_SAFE_BUILTINS = _build_safe_builtins()


def assert_text(haystack: str, needle: str) -> None:
    if needle not in (haystack or ""):
        raise AssertionError(f"expected '{needle}' in '{haystack}'")


def run_snippet(code: str, *, driver: Any = None, ctx: dict | None = None,
                extra: dict | None = None) -> None:
    """Execute ``code`` with a scoped namespace. Raises on error (the caller maps a
    raised ``AssertionError`` to a failed step, anything else to an error)."""
    if ctx is None:
        ctx = {}
    namespace: dict[str, Any] = {
        "__builtins__": _SAFE_BUILTINS,
        "driver": driver,
        "ctx": ctx,
        "assert_text": assert_text,
    }
    if extra:
        namespace.update(extra)
    exec(compile(code, "<e2e-script>", "exec"), namespace, namespace)
