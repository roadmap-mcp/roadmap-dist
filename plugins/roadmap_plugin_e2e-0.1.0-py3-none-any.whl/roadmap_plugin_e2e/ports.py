"""The driver *port* — the interface a test driver implements.

The engine owns everything driver-agnostic: interpolating ``${param}`` values,
compiling scenarios, capturing screenshots, merging captured context, assembling the
report, and persisting it. A :class:`Driver` owns only the target-specific concern —
performing one already-resolved step and reporting what happened.

Steps reach the driver as plain dicts (a resolved :class:`~.models.Step`), so the
port stays free of the engine's pydantic models. Structured actions (``navigate`` /
``click`` / ``type`` / ``select`` / ``wait`` / ``assert_text`` / ``assert_visible`` /
``capture``) and the raw-code ``script`` escape hatch are all dispatched inside
``run_step`` on ``step["type"]``.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Optional, Protocol, runtime_checkable


@dataclass
class StepOutcome:
    """What a driver reports back for one step."""

    status: str                                   # "passed" | "failed"
    error: str = ""                               # message when status == "failed"
    captured: dict = field(default_factory=dict)  # context keys read this step
    screenshot: Optional[bytes] = None            # PNG bytes captured at/after the step


@runtime_checkable
class Driver(Protocol):
    id: str

    def start(self) -> None:
        """Open the session (launch the browser / connect the remote driver)."""
        ...

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        """Perform one resolved step against the target. ``ctx`` is the live run
        context (already ``${param}``-interpolated into ``step``); a ``script`` step
        may read/write it in place. Return an outcome; never raise for an ordinary
        assertion failure — set ``status='failed'`` instead."""
        ...

    def screenshot(self) -> Optional[bytes]:
        """Best-effort PNG of the current state, or ``None`` if unavailable."""
        ...

    def close(self) -> None:
        """Tear the session down (always called, even after a failure)."""
        ...


@runtime_checkable
class LiveDriver(Protocol):
    """A driver that also supports **interactive introspection** — used by the AI
    design assistant, which drives a long-lived session, "sees" the page, and records
    actions as it goes. A :class:`Driver` that additionally exposes the live URL and a
    snapshot of the page's interactive elements (each with a ready-to-use selector, so
    the assistant doesn't have to guess selectors by hand).

    ``snapshot`` returns a list of element dicts::

        {"index": int,          # position in this snapshot
         "tag": str,            # "button" | "a" | "input" | "select" | "textarea" | …
         "type": str,           # input type / role, best-effort
         "text": str,           # visible text / label / placeholder
         "selector": str,       # a robust CSS selector (id > name > stable path)
         "by": str,             # locator strategy for `selector` (usually "css"/"id")
         "visible": bool}
    """

    id: str

    def start(self) -> None: ...
    def run_step(self, step: dict, ctx: dict) -> StepOutcome: ...
    def screenshot(self) -> Optional[bytes]: ...
    def close(self) -> None: ...

    def url(self) -> str:
        """The URL currently loaded in the live session."""
        ...

    def snapshot(self) -> list[dict]:
        """The page's interactive elements, each with a robust selector."""
        ...
