"""Per-process runtime wiring for the E2E engine.

Stashes the framework handles at activate time so the storage/engine modules can
read config, resolve the on-disk data dir, and pick the configured driver without
threading the context through every call. Mirrors the brain plugin's ``runtime``.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import E2E_DRIVERS_POINT
from .models import E2EConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def config_dir() -> Path:
    assert _store is not None, "e2e runtime not initialised"
    return _store.path.parent


def e2e_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/e2e``). Created on demand."""
    d = config_dir() / "e2e"
    d.mkdir(parents=True, exist_ok=True)
    return d


def e2e_config() -> E2EConfig:
    assert _store is not None, "e2e runtime not initialised"
    raw = _store.load_decrypted()
    return E2EConfig(**(raw.get("e2e") or {}))


def services() -> ServiceRegistry:
    assert _services is not None, "e2e runtime not initialised"
    return _services


def _drivers() -> list:
    if _extensions is None:
        return []
    return list(_extensions.get(E2E_DRIVERS_POINT))


def component_env() -> SimpleNamespace:
    """Context handed to a driver provider's ``create(env)``: the resolved config
    and the data dir (a driver may want a place for downloads/profiles)."""
    return SimpleNamespace(config=e2e_config(), e2e_dir=e2e_dir())


def resolve_driver():
    """Build the driver selected by ``e2e.driver`` from its registered provider.

    Falls back to the first registered provider (so a fresh install with only the
    built-in ``mock`` driver still runs), and raises if none are registered at all —
    which means no driver plugin is enabled in this workspace.
    """
    want = e2e_config().driver
    providers = _drivers()
    if not providers:
        raise RuntimeError(
            "No E2E driver is enabled in this workspace. Enable the built-in engine "
            "or a driver plugin (e.g. roadmap.e2e.selenium).")
    chosen = next((p for p in providers if p.id == want), providers[0])
    return chosen.create(component_env())
