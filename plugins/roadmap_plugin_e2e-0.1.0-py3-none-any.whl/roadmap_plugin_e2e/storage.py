"""JSON persistence for pages, scenarios, and runs under ``<config_dir>/e2e/``.

Layout (workspace-aware, since ``config_dir`` is workspace-scoped)::

    e2e/
      pages/<id>.json
      scenarios/<id>.json
      runs/<id>.json
      runs/<id>/screenshots/<index>.png

No database — plain files, one per entity, matching how contexts and the brain index
are stored. Runs are persisted *incrementally* during execution so the UI can poll a
running report.
"""

from __future__ import annotations

import json
import uuid
from pathlib import Path

from . import runtime
from .models import Component, Scenario, Site, TestRun


# ── directories ───────────────────────────────────────────────────────────────

def _dir(name: str) -> Path:
    d = runtime.e2e_dir() / name
    d.mkdir(parents=True, exist_ok=True)
    return d


def _sites_dir() -> Path:
    return _dir("sites")


def _components_dir() -> Path:
    return _dir("components")


def _scenarios_dir() -> Path:
    return _dir("scenarios")


def _runs_dir() -> Path:
    return _dir("runs")


def new_id(prefix: str) -> str:
    return f"{prefix}_{uuid.uuid4().hex[:8]}"


def _read_json(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write_json(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


# ── sites ─────────────────────────────────────────────────────────────────────

def list_sites() -> list[Site]:
    out = []
    for f in sorted(_sites_dir().glob("*.json")):
        d = _read_json(f)
        if d:
            out.append(Site(**d))
    return sorted(out, key=lambda s: s.name.lower())


def get_site(site_id: str) -> Site | None:
    d = _read_json(_sites_dir() / f"{site_id}.json")
    return Site(**d) if d else None


def save_site(site: Site) -> Site:
    if not site.id:
        site.id = new_id("site")
    _write_json(_sites_dir() / f"{site.id}.json", site.model_dump())
    return site


def delete_site(site_id: str) -> bool:
    """Delete a site and cascade-delete its components (their steps go with them)."""
    f = _sites_dir() / f"{site_id}.json"
    existed = f.exists()
    if existed:
        f.unlink()
    for comp in list_components(site_id):
        delete_component(comp.id)
    return existed


# ── components (page-objects) ─────────────────────────────────────────────────

def list_components(site_id: str | None = None) -> list[Component]:
    out = []
    for f in sorted(_components_dir().glob("*.json")):
        d = _read_json(f)
        if d and (site_id is None or d.get("site_id") == site_id):
            out.append(Component(**d))
    return sorted(out, key=lambda c: c.name.lower())


def get_component(component_id: str) -> Component | None:
    d = _read_json(_components_dir() / f"{component_id}.json")
    return Component(**d) if d else None


def save_component(component: Component) -> Component:
    if not component.id:
        component.id = new_id("cmp")
    _write_json(_components_dir() / f"{component.id}.json", component.model_dump())
    return component


def delete_component(component_id: str) -> bool:
    f = _components_dir() / f"{component_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── scenarios ─────────────────────────────────────────────────────────────────

def list_scenarios() -> list[Scenario]:
    out = []
    for f in sorted(_scenarios_dir().glob("*.json")):
        d = _read_json(f)
        if d:
            out.append(Scenario(**d))
    return sorted(out, key=lambda s: s.name.lower())


def get_scenario(scenario_id: str) -> Scenario | None:
    d = _read_json(_scenarios_dir() / f"{scenario_id}.json")
    return Scenario(**d) if d else None


def save_scenario(scenario: Scenario) -> Scenario:
    if not scenario.id:
        scenario.id = new_id("sc")
    _write_json(_scenarios_dir() / f"{scenario.id}.json", scenario.model_dump())
    return scenario


def delete_scenario(scenario_id: str) -> bool:
    f = _scenarios_dir() / f"{scenario_id}.json"
    if f.exists():
        f.unlink()
        return True
    return False


# ── runs ──────────────────────────────────────────────────────────────────────

def list_runs() -> list[TestRun]:
    out = []
    for f in _runs_dir().glob("*.json"):
        d = _read_json(f)
        if d:
            out.append(TestRun(**d))
    # newest first (ids are time-sortable via the uuid suffix? no — sort by started)
    return sorted(out, key=lambda r: r.started, reverse=True)


def get_run(run_id: str) -> TestRun | None:
    d = _read_json(_runs_dir() / f"{run_id}.json")
    return TestRun(**d) if d else None


def save_run(run: TestRun) -> TestRun:
    _write_json(_runs_dir() / f"{run.id}.json", run.model_dump())
    return run


def delete_run(run_id: str) -> bool:
    f = _runs_dir() / f"{run_id}.json"
    existed = f.exists()
    if existed:
        f.unlink()
    shots = _runs_dir() / run_id
    if shots.is_dir():
        for s in shots.glob("**/*"):
            if s.is_file():
                s.unlink()
        try:
            (shots / "screenshots").rmdir()
            shots.rmdir()
        except OSError:
            pass
    return existed


def save_screenshot(run_id: str, index: int, data: bytes) -> str:
    """Persist a step screenshot; return its filename (relative to the run's dir)."""
    d = _runs_dir() / run_id / "screenshots"
    d.mkdir(parents=True, exist_ok=True)
    name = f"{index}.png"
    (d / name).write_bytes(data)
    return name


def screenshot_path(run_id: str, name: str) -> Path | None:
    # guard against path traversal in the filename segment
    if "/" in name or "\\" in name or ".." in name:
        return None
    p = _runs_dir() / run_id / "screenshots" / name
    return p if p.exists() else None
