"""HTTP surface: ``/api/e2e/{pages,scenarios,runs}``.

CRUD for the step library (pages) and scenarios, plus starting/polling runs and
serving per-step screenshots. A run is started with ``POST /runs`` and returns
immediately; the frontend polls ``GET /runs/{id}`` for the growing report.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException, Response
from pydantic import BaseModel

from .models import Component, Scenario, Site


class RunRequest(BaseModel):
    scenario_id: str
    context: dict = {}
    snapshots: bool | None = None         # None = use the e2e.capture_snapshots default


def create_e2e_router(e2e) -> APIRouter:
    router = APIRouter(prefix="/api/e2e", tags=["e2e"])

    # ── sites ─────────────────────────────────────────────────────────────────
    @router.get("/sites")
    def list_sites():
        return {"sites": [s.model_dump() for s in e2e.list_sites()]}

    @router.get("/sites/{site_id}")
    def get_site(site_id: str):
        s = e2e.get_site(site_id)
        if s is None:
            raise HTTPException(status_code=404, detail="Site not found.")
        return s.model_dump()

    @router.post("/sites")
    def create_site(site: Site):
        return e2e.save_site(site).model_dump()

    @router.put("/sites/{site_id}")
    def update_site(site_id: str, site: Site):
        site.id = site_id
        return e2e.save_site(site).model_dump()

    @router.delete("/sites/{site_id}")
    def delete_site(site_id: str):
        return {"deleted": e2e.delete_site(site_id)}

    # ── components (page-objects) ─────────────────────────────────────────────
    @router.get("/components")
    def list_components(site_id: str | None = None):
        return {"components": [c.model_dump() for c in e2e.list_components(site_id)]}

    @router.get("/components/{component_id}")
    def get_component(component_id: str):
        c = e2e.get_component(component_id)
        if c is None:
            raise HTTPException(status_code=404, detail="Component not found.")
        return c.model_dump()

    @router.post("/components")
    def create_component(component: Component):
        return e2e.save_component(component).model_dump()

    @router.put("/components/{component_id}")
    def update_component(component_id: str, component: Component):
        component.id = component_id
        return e2e.save_component(component).model_dump()

    @router.delete("/components/{component_id}")
    def delete_component(component_id: str):
        return {"deleted": e2e.delete_component(component_id)}

    # ── scenarios ─────────────────────────────────────────────────────────────
    @router.get("/scenarios")
    def list_scenarios():
        return {"scenarios": [s.model_dump() for s in e2e.list_scenarios()]}

    @router.get("/scenarios/{scenario_id}")
    def get_scenario(scenario_id: str):
        s = e2e.get_scenario(scenario_id)
        if s is None:
            raise HTTPException(status_code=404, detail="Scenario not found.")
        return s.model_dump()

    @router.post("/scenarios")
    def create_scenario(scenario: Scenario):
        return e2e.save_scenario(scenario).model_dump()

    @router.put("/scenarios/{scenario_id}")
    def update_scenario(scenario_id: str, scenario: Scenario):
        scenario.id = scenario_id
        return e2e.save_scenario(scenario).model_dump()

    @router.delete("/scenarios/{scenario_id}")
    def delete_scenario(scenario_id: str):
        return {"deleted": e2e.delete_scenario(scenario_id)}

    # ── runs ──────────────────────────────────────────────────────────────────
    @router.get("/runs")
    def list_runs():
        return {"runs": [r.model_dump() for r in e2e.list_runs()]}

    @router.post("/runs")
    def start_run(req: RunRequest):
        try:
            return e2e.start_run(req.scenario_id, req.context, req.snapshots).model_dump()
        except ValueError as ex:
            raise HTTPException(status_code=404, detail=str(ex))

    @router.get("/runs/{run_id}")
    def get_run(run_id: str):
        r = e2e.get_run(run_id)
        if r is None:
            raise HTTPException(status_code=404, detail="Run not found.")
        return r.model_dump()

    @router.delete("/runs/{run_id}")
    def delete_run(run_id: str):
        return {"deleted": e2e.delete_run(run_id)}

    @router.get("/runs/{run_id}/screenshots/{name}")
    def screenshot(run_id: str, name: str):
        from . import storage
        p = storage.screenshot_path(run_id, name)
        if p is None:
            raise HTTPException(status_code=404, detail="Screenshot not found.")
        return Response(content=p.read_bytes(), media_type="image/png")

    return router
