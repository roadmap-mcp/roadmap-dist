"""Built-in drivers shipped with the engine. Currently just the browser-free
``mock`` driver used for tests and previews; real drivers (Selenium) live in their
own plugins and contribute additional :class:`~..contracts.DriverProvider`s."""

from ..contracts import DriverProvider
from .mock import MockDriver

BUILTIN_DRIVERS = [
    DriverProvider(id="mock", label="Mock (no browser)",
                   create=lambda env: MockDriver()),
]

__all__ = ["BUILTIN_DRIVERS", "MockDriver"]
