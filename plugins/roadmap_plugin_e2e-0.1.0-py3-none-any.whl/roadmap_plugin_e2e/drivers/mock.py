"""A browser-free driver: a deterministic in-memory stand-in for a real target.

It lets the whole engine — compile, interpolate, run, capture, report, persist —
work and be tested without a browser, and backs UI previews. It keeps a tiny
simulated "form": ``type`` records a value at a target, ``capture`` reads it back (so
a typed value round-trips), and ``assert_text`` checks against it. ``script`` steps
run in the same restricted namespace shape the real drivers use, but with a fake
``driver`` object rather than Selenium.
"""

from __future__ import annotations

import base64

from ..ports import StepOutcome
from ..snippet import run_snippet

# a 1x1 transparent PNG so every step has a (valid, tiny) screenshot artifact
_BLANK_PNG = base64.b64decode(
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNk+M9QDwADhgGA"
    "WjR9awAAAABJRU5ErkJggg==")


class _MockElement:
    """The stand-in element a snippet's ``driver.find_element`` returns."""

    def __init__(self, store: dict, key: str):
        self._store, self._key = store, key

    def click(self):
        return None

    def send_keys(self, *parts):
        self._store[self._key] = self._store.get(self._key, "") + "".join(map(str, parts))

    def clear(self):
        self._store[self._key] = ""

    @property
    def text(self):
        return self._store.get(self._key, "")

    def get_attribute(self, name):
        if name == "value":
            return self._store.get(self._key, "")
        return f"mock:{name}"


class MockDriver:
    id = "mock"

    def __init__(self):
        self._fields: dict[str, str] = {}
        self._url = ""

    def start(self) -> None:
        self._fields.clear()
        self._url = ""

    def screenshot(self):
        return _BLANK_PNG

    def close(self) -> None:
        self._fields.clear()

    # ── live introspection (LiveDriver) — deterministic fakes for tests ───────

    def url(self) -> str:
        return self._url

    def snapshot(self) -> list[dict]:
        """A fixed little set of interactive elements, plus one per typed field, so the
        assistant flow is exercisable with no browser."""
        elems = [
            {"tag": "input", "type": "text", "text": "Username", "selector": "#username"},
            {"tag": "input", "type": "password", "text": "Password", "selector": "#password"},
            {"tag": "button", "type": "submit", "text": "Log in", "selector": "#submit"},
        ]
        for key in self._fields:
            if key not in ("username", "password", "submit"):
                elems.append({"tag": "input", "type": "text", "text": key, "selector": f"#{key}"})
        return [
            {"index": i, "tag": e["tag"], "type": e["type"], "text": e["text"],
             "selector": e["selector"], "by": "css", "visible": True}
            for i, e in enumerate(elems)
        ]

    # ── snippet host surface (mirrors the selenium driver's shape) ────────────

    def find_element(self, by, value):
        return _MockElement(self._fields, str(value))

    def get(self, url):
        self._url = url

    @property
    def current_url(self):
        return self._url

    # ── step dispatch ─────────────────────────────────────────────────────────

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        t = step.get("type", "")
        target = step.get("target") or {}
        key = str(target.get("value", ""))
        value = step.get("value", "")

        if t == "navigate":
            self._url = value
            return StepOutcome(status="passed")

        if t == "click":
            return StepOutcome(status="passed")

        if t == "type":
            self._fields[key] = value
            return StepOutcome(status="passed")

        if t == "select":
            self._fields[key] = value
            return StepOutcome(status="passed")

        if t == "wait":
            return StepOutcome(status="passed")

        if t == "assert_visible":
            return StepOutcome(status="passed")

        if t == "assert_text":
            have = self._fields.get(key, "")
            if value and value not in have:
                return StepOutcome(
                    status="failed",
                    error=f"Expected text '{value}' not found at '{key}' (got '{have}').")
            return StepOutcome(status="passed")

        if t == "capture":
            cap = step.get("capture_as") or key
            got = self._fields.get(key, f"mock:{key}")
            return StepOutcome(status="passed", captured={cap: got})

        if t == "script":
            snippet = step.get("snippet", "")
            try:
                run_snippet(snippet, driver=self, ctx=ctx)
                return StepOutcome(status="passed")
            except AssertionError as e:
                return StepOutcome(status="failed", error=f"Assertion failed: {e}")
            except Exception as e:
                return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")

        return StepOutcome(status="failed", error=f"Unknown step type: {t}")
