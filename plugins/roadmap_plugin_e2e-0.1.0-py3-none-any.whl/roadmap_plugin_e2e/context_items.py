"""E2E context contribution: ``e2e_run`` — pin a finished test-run report into a
Roadmap context.

``resolve`` snapshots the run's report markdown (status, per-step results, captured
params) at add-time so the pinned item is stable; ``render`` shows the snapshot. Runs
are immutable once finished, so a snapshot is the right model (unlike a live inquiry).
"""

from __future__ import annotations

from roadmap_plugin_context import ContextItemType

from . import storage
from .service import render_run_markdown


def resolve_e2e_run(item_id: str, *, text=None, path=None) -> dict:
    """``item_id`` is a run id; snapshot its report."""
    run = storage.get_run(item_id)
    if run is None:
        return {
            "type": "e2e_run", "id": item_id,
            "label": text or item_id,
            "markdown": f"*E2E run `{item_id}` not found.*",
        }
    label = text or f"{run.scenario_name or run.scenario_id} — {run.status}"
    return {
        "type": "e2e_run", "id": run.id, "label": label,
        "status": run.status, "markdown": render_run_markdown(run),
    }


def render_e2e_run(item: dict, config) -> str:
    return item.get("markdown") or f"*E2E run `{item.get('id', '')}` (no report).*"


E2E_RUN_TYPE = ContextItemType(
    type="e2e_run",
    resolve=resolve_e2e_run,
    render=render_e2e_run,
    label="Test run",
    icon="bi-clipboard-check",
)

E2E_ITEM_TYPES = [E2E_RUN_TYPE]
