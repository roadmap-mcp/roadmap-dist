"""E2E testing engine plugin activator (driver-agnostic).

Declares the ``roadmap.e2e.drivers`` extension point, contributes the built-in
browser-free ``mock`` driver, publishes the ``e2e`` service, mounts ``/api/e2e``, and
contributes a Web Testing settings tab. Real drivers (Selenium) and the context/MCP
surfaces are separate concerns wired by their own plugins / later phases.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT
from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT

from . import runtime
from .contracts import E2E_DRIVERS_POINT, DriverProvider
from .context_items import E2E_ITEM_TYPES
from .drivers import BUILTIN_DRIVERS
from .mcp_tools import register_mcp_tools
from .router import create_e2e_router
from .service import E2EService
from .settings_section import E2E_SECTION


class E2EPlugin(Plugin):
    id = "roadmap.e2e"
    name = "Web Testing"
    requires = ["roadmap.settings", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)

        # the one swappable component: the test driver (browser, API, …)
        ctx.define_point(E2E_DRIVERS_POINT, DriverProvider,
                         "Test drivers that perform a step against a target.")
        for d in BUILTIN_DRIVERS:
            ctx.extend(E2E_DRIVERS_POINT, d)

        ctx.extend(SETTINGS_SECTIONS_POINT, E2E_SECTION)
        for it in E2E_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, it)

        e2e = E2EService()
        ctx.services.register("e2e", e2e)
        ctx.add_router(create_e2e_router(e2e))
        register_mcp_tools(ctx.services.require("context"), e2e)
