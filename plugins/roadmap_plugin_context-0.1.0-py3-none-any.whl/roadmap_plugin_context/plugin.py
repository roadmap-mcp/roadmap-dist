"""Context plugin activator — declares the context extension points, contributes
the built-in item types, serves ``/api/contexts``, and mounts the MCP server.

It also publishes a ``context`` service: the facade other plugins (e.g. Jira) use
to register MCP tools, record inquiries, add items, and resolve item metadata.
"""

from roadmap_framework import Plugin, PluginContext

from . import runtime
from .contracts import (
    CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT,
    ContextItemType, PreviewContribution,
)
from .contexts_router import router as contexts_router, _resolve_item
from .mcp import (
    mcp, create_mcp_sse_app, render_context_sections,
    _upsert_inquiry, _add_context_items,
)
from .builtin_items import BUILTIN_ITEM_TYPES, BUILTIN_PREVIEWS


class ContextService:
    """Integration facade for context-aware plugins."""

    def __init__(self):
        #: the shared FastMCP server — add ``@mcp.tool()``s to it
        self.mcp = mcp

    def upsert_inquiry(self, name: str, inquiry_type: str, params: dict, label: str) -> None:
        _upsert_inquiry(name, inquiry_type, params, label)

    def add_context_items(self, name: str, items: list[dict]) -> tuple[int, int]:
        return _add_context_items(name, items)

    def resolve_item(self, item_type: str, item_id: str, text=None, path=None) -> dict:
        return _resolve_item(item_type, item_id, text, path)

    def render_sections(self, name: str) -> list[dict]:
        return render_context_sections(name)


class ContextPlugin(Plugin):
    id = "roadmap.context"
    name = "Contexts"

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.extensions, ctx.services)

        ctx.define_point(CONTEXT_ITEM_TYPES_POINT, ContextItemType,
                         "How to resolve + render a context item type.")
        ctx.define_point(CONTEXT_PREVIEW_POINT, PreviewContribution,
                         "Live preview/inquiry rendering for a kind.")

        for it in BUILTIN_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, it)
        for pc in BUILTIN_PREVIEWS:
            ctx.extend(CONTEXT_PREVIEW_POINT, pc)

        ctx.add_router(contexts_router)
        ctx.services.register("context", ContextService())

        # MCP SSE server (context tools registered at import; plugins add more).
        ctx.app.mount("/mcp", create_mcp_sse_app())
