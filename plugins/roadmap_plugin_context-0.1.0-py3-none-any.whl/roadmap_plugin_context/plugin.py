"""Context plugin activator — declares the context extension points, contributes
the built-in item types, serves ``/api/contexts``, and mounts the MCP server.

It also publishes a ``context`` service: the facade other plugins (e.g. Jira) use
to register MCP tools, record inquiries, add items, and resolve item metadata.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from . import runtime
from .contracts import (
    CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT,
    ContextItemType, PreviewContribution,
)
from .contexts_router import router as contexts_router, _resolve_item
from .mcp import (
    mcp, create_mcp_sse_app, render_context_sections,
    _upsert_inquiry, _add_context_items,
)
from .stateless_mcp import create_stateless_endpoint
from .workspace_mcp import WorkspaceScopedMCP, set_workspace_runtime
from .builtin_items import BUILTIN_ITEM_TYPES, BUILTIN_PREVIEWS

# The git-repositories setting lives with the context plugin — it owns the
# git_repo item type and reads `repositories` most (was an edition
# built-in). Keep id="repos" so the edition's inline Settings tab is undisturbed.
REPOS_SECTION = SettingsSection(
    id="repos", label="Git Repos", order=30, group="Information Sources",
    defaults=lambda: {"repositories": []},
)


class ContextService:
    """Integration facade for context-aware plugins."""

    def __init__(self):
        #: the shared MCP server — add ``@mcp.tool()``s to it. It is workspace-aware:
        #: every tool registered on it gains an optional ``workspace`` argument, so a
        #: contributing plugin never has to handle tenancy itself.
        self.mcp = mcp

    def upsert_inquiry(self, name: str, inquiry_type: str, params: dict, label: str) -> None:
        _upsert_inquiry(name, inquiry_type, params, label)

    def add_context_items(self, name: str, items: list[dict]) -> tuple[int, int]:
        return _add_context_items(name, items)

    def resolve_item(self, item_type: str, item_id: str, text=None, path=None) -> dict:
        return _resolve_item(item_type, item_id, text, path)

    def render_sections(self, name: str) -> list[dict]:
        return render_context_sections(name)


class ContextPlugin(Plugin):
    id = "roadmap.context"
    name = "Contexts"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.extensions, ctx.services)

        ctx.define_point(CONTEXT_ITEM_TYPES_POINT, ContextItemType,
                         "How to resolve + render a context item type.")
        ctx.define_point(CONTEXT_PREVIEW_POINT, PreviewContribution,
                         "Live preview/inquiry rendering for a kind.")

        for it in BUILTIN_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, it)
        for pc in BUILTIN_PREVIEWS:
            ctx.extend(CONTEXT_PREVIEW_POINT, pc)

        ctx.extend(SETTINGS_SECTIONS_POINT, REPOS_SECTION)

        ctx.add_router(contexts_router)
        ctx.services.register("context", ContextService())

        # MCP SSE server (context tools registered at import; plugins add more).
        # Two workspace layers: the mount picks the *connection* workspace
        # (/mcp/<workspace>/sse; /mcp/sse stays on default), and every tool takes an
        # optional `workspace` argument that overrides it for a single call.
        workspaces = ctx.services.get("workspaces")
        set_workspace_runtime(workspaces, ctx.app)
        ctx.app.mount("/mcp", WorkspaceScopedMCP(create_mcp_sse_app(), workspaces))
        # The stateless endpoint (one fixed `roadmap` tool; survives reloads). The mount
        # above serves /mcp/<workspace>; bare /mcp needs its own route (a mount only
        # matches below its path) and takes the workspace from the header or ?ws=.
        ctx.app.add_route("/mcp", create_stateless_endpoint(mcp), methods=["GET", "POST"])
