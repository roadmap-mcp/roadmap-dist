"""Contracts for the two context extension points.

* ``roadmap.context.itemTypes`` — a *context item type*: how to resolve an
  item's metadata at add-time and how to render it as text for the AI / preview.
  Built-in types (instructions, url, git_repo, …) are contributed by this
  plugin; the Jira plugin contributes ``jira_issue`` / ``confluence_page``.

* ``roadmap.context.previewContributions`` — a *preview contribution*: renders a
  live "inquiry" / detail preview for a given kind (e.g. a Jira issue, a
  Confluence child-page tree, a git repo). Used by the MCP inquiry renderer and
  the ``/api/contexts/meta/preview-item`` endpoint.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

CONTEXT_ITEM_TYPES_POINT = "roadmap.context.itemTypes"
CONTEXT_PREVIEW_POINT = "roadmap.context.previewContributions"


@dataclass
class ContextItemType:
    #: discriminator stored on items, e.g. "jira_issue"
    type: str
    #: resolve(item_id, *, text, path) -> item dict (add-time metadata)
    resolve: Callable[..., dict]
    #: render(item: dict, config) -> markdown string (config is a namespace view)
    render: Callable[[dict, Any], str]
    label: str = ""
    icon: str = ""


@dataclass
class PreviewContribution:
    #: inquiry/preview kind, e.g. "jira_issue", "confluence_children", "git_repo"
    kind: str
    #: render(params: dict, label: str, config) -> markdown string
    render: Callable[[dict, str, Any], str]
    label: str = ""
