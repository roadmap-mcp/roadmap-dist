"""Built-in (non-Jira) context item types + preview contributions.

These are contributed by the context plugin itself to its own extension points,
exercising the same contracts third-party plugins (Jira) use. The resolve/render
implementations still live in ``contexts_router`` / ``mcp`` (moved verbatim from
the monolith); here we only adapt them to the uniform contribution signatures.
"""

from __future__ import annotations

from .contracts import ContextItemType, PreviewContribution
from .contexts_router import (
    _resolve_instructions, _resolve_url, _resolve_git_repo,
    _resolve_repo_file, _resolve_commits, _resolve_scratch_dir, _resolve_mixin,
)
from .mcp import (
    _render_instructions, _render_url, _render_git_repo,
    _render_repo_file, _render_commits, _render_scratch_dir,
    _render_git_repo_detail,
)


def _label(item: dict) -> str:
    return item.get("label", item.get("title", item.get("id", "")))


BUILTIN_ITEM_TYPES = [
    ContextItemType(
        "instructions",
        resolve=lambda item_id, *, text=None, path=None: _resolve_instructions(item_id, text),
        render=lambda item, cfg: _render_instructions(_label(item), item.get("text", "")),
        label="Instructions",
    ),
    ContextItemType(
        "url",
        resolve=lambda item_id, *, text=None, path=None: _resolve_url(item_id, text),
        render=lambda item, cfg: _render_url(item),
        label="URL",
    ),
    ContextItemType(
        "git_repo",
        resolve=lambda item_id, *, text=None, path=None: _resolve_git_repo(item_id, path),
        render=lambda item, cfg: _render_git_repo(item.get("id", ""), _label(item), item.get("path", "")),
        label="Git Repo",
    ),
    ContextItemType(
        "repo_file",
        resolve=lambda item_id, *, text=None, path=None: _resolve_repo_file(item_id),
        render=lambda item, cfg: _render_repo_file(item, cfg),
        label="File",
    ),
    ContextItemType(
        "commits",
        resolve=lambda item_id, *, text=None, path=None: _resolve_commits(item_id),
        render=lambda item, cfg: _render_commits(item, cfg),
        label="Commits",
    ),
    ContextItemType(
        "scratch_dir",
        resolve=lambda item_id, *, text=None, path=None: _resolve_scratch_dir(item_id),
        render=lambda item, cfg: _render_scratch_dir(item.get("id", ""), _label(item)),
        label="Scratch Dir",
    ),
    ContextItemType(
        "mixin",
        resolve=lambda item_id, *, text=None, path=None: _resolve_mixin(item_id),
        # mixins are expanded by render_context_sections before item rendering
        render=lambda item, cfg: "",
        label="Mixin",
    ),
]


def _render_git_repo_inquiry(params: dict, label: str, config) -> str:
    repo_name = params.get("repo_name", "")
    repo = next((r for r in config.repositories if r.name == repo_name), None)
    if not repo:
        return f"## {label}\n\nRepository '{repo_name}' not found in config."
    return _render_git_repo_detail(repo_name, label, repo.path)


def _render_git_repos_list_inquiry(params: dict, label: str, config) -> str:
    lines = [f"## {label} (Available Git Repositories)"]
    for r in config.repositories:
        lines.append(f"- **{r.name}**: `{r.path}`")
    return "\n".join(lines)


BUILTIN_PREVIEWS = [
    PreviewContribution("git_repo", _render_git_repo_inquiry),
    PreviewContribution("git_repos_list", _render_git_repos_list_inquiry),
]
