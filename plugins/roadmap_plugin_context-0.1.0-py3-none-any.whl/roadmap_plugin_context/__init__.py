"""Context plugin — declares the ``roadmap.context.itemTypes`` and
``roadmap.context.previewContributions`` extension points and serves
``/api/contexts`` + the MCP server.

Plugin authors import the contracts from here::

    from roadmap_plugin_context import (
        ContextItemType, PreviewContribution,
        CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT,
    )
"""

from .contracts import (
    ContextItemType, PreviewContribution,
    CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT,
)

__all__ = [
    "ContextItemType", "PreviewContribution",
    "CONTEXT_ITEM_TYPES_POINT", "CONTEXT_PREVIEW_POINT",
]
