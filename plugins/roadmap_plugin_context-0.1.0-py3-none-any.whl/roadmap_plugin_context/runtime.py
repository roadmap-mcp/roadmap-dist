"""Per-process runtime wiring for the context plugin.

The router and MCP modules were extracted from the monolith and still use
module-level helpers (``load_config_decrypted``, ``contexts_dir``) the way the
original code did. ``set_runtime`` stashes the framework handles at activate
time so those helpers work without each function taking the config store as an
argument.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import (
    CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT,
    ContextItemType, PreviewContribution,
)

_store: Optional[ConfigStore] = None
_extensions: Optional[ExtensionRegistry] = None
_services: Optional[ServiceRegistry] = None

#: defaults so attribute access on the namespace view never blows up
_CONFIG_DEFAULTS = {"repositories": [], "scratch_base_dir": ""}


def set_runtime(config: ConfigStore, extensions: ExtensionRegistry,
                services: ServiceRegistry) -> None:
    global _store, _extensions, _services
    _store, _extensions, _services = config, extensions, services


def config_dir() -> Path:
    assert _store is not None, "context runtime not initialised"
    return _store.path.parent


def contexts_dir() -> Path:
    d = config_dir() / "contexts"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _ns(obj):
    if isinstance(obj, dict):
        return SimpleNamespace(**{k: _ns(v) for k, v in obj.items()})
    if isinstance(obj, list):
        return [_ns(v) for v in obj]
    return obj


def load_config_decrypted():
    """Decrypted config as an attribute-accessible namespace (drop-in for the
    old ``AppConfig``-returning helper used by the extracted code)."""
    assert _store is not None, "context runtime not initialised"
    raw = _store.load_decrypted()
    for k, v in _CONFIG_DEFAULTS.items():
        raw.setdefault(k, v)
    return _ns(raw)


# ── registry access ───────────────────────────────────────────────────────

def item_types() -> dict[str, ContextItemType]:
    if _extensions is None:
        return {}
    return {it.type: it for it in _extensions.get(CONTEXT_ITEM_TYPES_POINT)}


def preview_for(kind: str) -> Optional[PreviewContribution]:
    if _extensions is None:
        return None
    for pc in _extensions.get(CONTEXT_PREVIEW_POINT):
        if pc.kind == kind:
            return pc
    return None
