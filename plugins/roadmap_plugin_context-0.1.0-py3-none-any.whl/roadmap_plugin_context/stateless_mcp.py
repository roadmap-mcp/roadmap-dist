"""The stateless MCP endpoint: one fixed tool, ``roadmap``, that runs any registered tool.

``/mcp/sse`` (see :mod:`.mcp`) is a long-lived SSE session with one MCP tool per
registered tool. Both halves break whenever the backend reloads: the session dies with
the process (the client has to reconnect), and the client's cached tool list goes stale
as soon as a tool is added or its arguments change.

``/mcp`` avoids both, the same way ToonStack's MCP server does:

* **Stateless Streamable HTTP.** Every JSON-RPC message is one POST answered with plain
  JSON; there is no session id and no event stream (``GET`` is 405), so nothing outlives
  a request and a reload goes unnoticed by the client.
* **One tool whose shape never changes.** ``roadmap`` takes ``{"command", "args"}``; the
  commands are the tools registered on the shared server (by this plugin and by others
  through the ``context`` service), looked up at call time. ``help`` lists them with
  their arguments, and an unknown command answers with the closest names. A new or
  changed tool is usable as soon as the backend has reloaded.

Workspaces work as on ``/mcp/sse``: the connection workspace comes from the path
(``/mcp/<ws>``), else the ``X-Roadmap-Workspace`` header or ``?ws=``, else ``default``;
and every command takes the optional ``workspace`` argument for a single call.
"""

from __future__ import annotations

import difflib
import json
from typing import Any

from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from .workspace_mcp import _owner_plugin_id

PROTOCOL_VERSION = "2025-06-18"
TOOL_NAME = "roadmap"

INSTRUCTIONS = (
    "Roadmap: contexts (curated bundles of Jira issues, Confluence pages, repos and notes), "
    "the knowledge base, workflows and end-to-end tests, per workspace. Everything goes "
    "through the one tool `roadmap` with a command: start with `help`, then for example "
    "list_contexts or kb_read. Every command takes an optional `workspace` argument; "
    "list_workspaces names them."
)


def _tools(mcp) -> dict[str, Any]:
    """The registered tools, read live so a reload's new set is used at once."""
    return {t.name: t for t in mcp._tool_manager.list_tools()}


def _signature(tool) -> str:
    schema = tool.parameters or {}
    req = set(schema.get("required") or [])
    args = [a if a in req else a + "?" for a in (schema.get("properties") or {})
            if a != "workspace"]
    return f"{tool.name}({', '.join(args)})"


def _first_sentence(text: str) -> str:
    first = " ".join((text or "").strip().split("\n\n")[0].split())
    return first.split(". ")[0].rstrip(".")


def _grouped(mcp) -> list[tuple[str, list[Any]]]:
    """Commands grouped by the plugin that registered them."""
    groups: dict[str, list[Any]] = {}
    for tool in _tools(mcp).values():
        owner = _owner_plugin_id(getattr(tool.fn, "__module__", "")) or "other"
        groups.setdefault(owner, []).append(tool)
    return sorted(groups.items())


def _help(mcp, command: str = "") -> str:
    tools = _tools(mcp)
    if command:
        tool = tools.get(command)
        if tool is None:
            return f"No command {command!r}; send help without arguments for the list."
        schema = tool.parameters or {}
        return json.dumps({"command": tool.name, "description": tool.description,
                           "args": schema.get("properties") or {},
                           "required": schema.get("required") or []},
                          ensure_ascii=False, indent=1)
    lines = ['Commands (arg? = optional; every command also takes workspace?). '
             '{"command": "help", "args": {"command": "<name>"}} shows one in full.', ""]
    for owner, group in _grouped(mcp):
        lines.append(f"{owner}:")
        for tool in group:
            lines.append(f"  {_signature(tool)} — {_first_sentence(tool.description)}.")
        lines.append("")
    return "\n".join(lines).rstrip()


def _tool_spec(mcp) -> dict:
    """The one MCP tool. Its schema stays the same whatever the commands are; the
    description lists the current commands as a convenience (help is the authority)."""
    overview = "\n".join(f"- {owner}: {', '.join(t.name for t in group)}"
                         for owner, group in _grouped(mcp))
    return {
        "name": TOOL_NAME,
        "description": (
            "Read and change Roadmap: contexts, the knowledge base, workflows, end-to-end "
            "tests. Send one command per call: {\"command\": \"<name>\", \"args\": {...}}.\n"
            "The commands change over time: send {\"command\": \"help\"} for the current "
            "list with arguments, and {\"command\": \"help\", \"args\": {\"command\": "
            "\"<name>\"}} for one in full. Every command takes an optional `workspace` "
            "argument (list_workspaces names them).\n"
            f"Commands now:\n{overview}"
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "command": {"type": "string", "description": "the command name; \"help\" lists them"},
                "args": {"type": "object", "description": "the command's arguments (see help)",
                         "additionalProperties": True},
            },
            "required": ["command"],
            "additionalProperties": False,
        },
    }


def _text(value: Any) -> dict:
    return {"type": "text",
            "text": value if isinstance(value, str) else json.dumps(value, ensure_ascii=False, indent=1)}


def _failed(message: str) -> dict:
    return {"content": [_text(message)], "isError": True}


async def _run_command(mcp, name: str, args: Any) -> dict:
    if name == "help":
        return {"content": [_text(_help(mcp, (args or {}).get("command") or ""))], "isError": False}
    tools = _tools(mcp)
    tool = tools.get(name)
    if tool is None:
        close = difflib.get_close_matches(name, list(tools), n=3, cutoff=0.6)
        hint = f" Did you mean {', '.join(close)}?" if close else ""
        return _failed(f"Unknown command {name!r}.{hint} Send {{\"command\": \"help\"}} for the list.")
    if not isinstance(args, dict):
        return _failed("args must be an object")
    schema = tool.parameters or {}
    extra = set(args) - set(schema.get("properties") or {})
    missing = [k for k in schema.get("required") or [] if k not in args]
    if extra or missing:
        msg = "; ".join(filter(None, [
            f"unknown argument(s) {', '.join(sorted(extra))}" if extra else "",
            f"missing {', '.join(missing)}" if missing else ""]))
        return _failed(f"{msg}. Usage: {_signature(tool)}")
    try:
        out = await mcp.call_tool(name, args)
    except Exception as exc:                 # ToolError wraps the tool's own exception
        return _failed(str(exc))
    if isinstance(out, tuple):               # (content, structured output)
        out = out[0]
    if isinstance(out, dict):
        return {"content": [_text(out)], "isError": False}
    return {"content": [b.model_dump(mode="json", by_alias=True, exclude_none=True) for b in out],
            "isError": False}


def _result(rid, result):
    return {"jsonrpc": "2.0", "id": rid, "result": result}


def _error(rid, code, message):
    return {"jsonrpc": "2.0", "id": rid, "error": {"code": code, "message": message}}


async def _handle(mcp, msg: Any) -> dict | None:
    if not isinstance(msg, dict) or msg.get("jsonrpc") != "2.0" or "method" not in msg:
        return _error(msg.get("id") if isinstance(msg, dict) else None, -32600, "invalid request")
    rid, method, params = msg.get("id"), msg["method"], msg.get("params") or {}
    if rid is None:                          # a notification (initialized, cancelled)
        return None
    if method == "initialize":
        return _result(rid, {"protocolVersion": params.get("protocolVersion") or PROTOCOL_VERSION,
                             "capabilities": {"tools": {"listChanged": False}},
                             "serverInfo": {"name": "roadmap", "version": "1.0.0"},
                             "instructions": INSTRUCTIONS})
    if method == "ping":
        return _result(rid, {})
    if method == "tools/list":
        return _result(rid, {"tools": [_tool_spec(mcp)]})
    if method == "tools/call":
        if params.get("name") != TOOL_NAME:
            return _result(rid, _failed(f"The only tool is {TOOL_NAME!r}."))
        a = params.get("arguments") or {}
        return _result(rid, await _run_command(mcp, a.get("command") or "", a.get("args") or {}))
    if method == "resources/list":
        return _result(rid, {"resources": []})
    if method == "prompts/list":
        return _result(rid, {"prompts": []})
    return _error(rid, -32601, f"method not found: {method}")


def create_stateless_endpoint(mcp):
    """The ``/mcp`` endpoint (a Starlette endpoint function) over the shared server."""

    async def endpoint(request: Request) -> Response:
        if request.method != "POST":
            # No server-to-client stream: a long-lived connection would hold up a
            # reload, and clients don't need one (the tool's shape never changes).
            return Response(status_code=405, headers={"Allow": "POST"})
        try:
            body = await request.json()
        except ValueError:
            return JSONResponse(_error(None, -32700, "parse error"), status_code=400)
        if isinstance(body, list):
            out = [r for r in [await _handle(mcp, m) for m in body] if r is not None]
            return JSONResponse(out) if out else Response(status_code=202)
        r = await _handle(mcp, body)
        return JSONResponse(r) if r is not None else Response(status_code=202)

    return endpoint
