"""Trello configuration schema."""

from pydantic import BaseModel, Field


class TrelloBoard(BaseModel):
    """A board the user has added in settings — used for lookup and browsing."""

    id: str = ""
    name: str = ""
    url: str = ""


class TrelloConfig(BaseModel):
    """Connection settings for the Trello REST API.

    Trello authenticates with an **API key plus a token**. The key is generated
    from a Power-Up at https://trello.com/apps/admin and is not secret; the token
    authorises access to a user's boards and is (so this stores it encrypted).

    Note: Atlassian has an open RFC to move Trello to OAuth 2.0 (3LO) with scopes
    and token expiry. Key+token is the current mechanism; all of it is confined to
    ``trello_client`` so that migration stays a contained change.
    """

    base_url: str = "https://api.trello.com/1"
    api_key: str = ""
    api_token: str = ""
    boards: list[TrelloBoard] = Field(default_factory=list)
    cache_dir: str = ""
    refresh_duration: int = 3600
