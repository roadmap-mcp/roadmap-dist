"""Trello interactive MCP tools.

Registered on the *shared* MCP server (obtained from the context service), so an
edition without the Trello plugin simply doesn't expose these tools.
"""

import re

from fastapi import HTTPException

from .context_items import render_trello_board_cards, render_trello_card


def register_mcp_tools(context) -> None:
    mcp = context.mcp

    @mcp.tool()
    def request_trello_card(name: str, card_id: str, label: str = "") -> str:
        """Fetch a Trello card by its id or URL and record the inquiry in the context."""
        label = label or f"Card {card_id}"
        context.upsert_inquiry(name, "trello_card", {"card_id": card_id}, label)
        return render_trello_card(card_id, label)

    @mcp.tool()
    def list_trello_cards(name: str, board_id: str, label: str = "") -> str:
        """List the open cards on a Trello board, grouped by list, as an inquiry."""
        label = label or f"Cards on board {board_id}"
        context.upsert_inquiry(name, "trello_board_cards", {"board_id": board_id}, label)
        return render_trello_board_cards(board_id, label)

    @mcp.tool()
    def add_trello_cards(name: str, card_ids: str, label_prefix: str = "") -> str:
        """Add one or more Trello cards to a context as permanent items."""
        ids = [c for c in re.split(r"[\s,]+", card_ids.strip()) if c]
        if not ids:
            return "No card ids provided."
        resolved, failed = [], []
        for card_id in ids:
            try:
                item = context.resolve_item("trello_card", card_id)
                if label_prefix:
                    item["label"] = f"{label_prefix}{item.get('label', '')}"
                resolved.append(item)
            except HTTPException as e:
                failed.append(f"{card_id} ({e.detail})")
            except Exception as e:
                failed.append(f"{card_id} ({e})")
        added, skipped = context.add_context_items(name, resolved)
        lines = [f"Added {added} Trello card(s) to context '{name}'."]
        if skipped:
            lines.append(f"{skipped} already present (skipped).")
        if failed:
            lines.append("Failed: " + "; ".join(failed))
        for it in resolved:
            lines.append(f"- {it['label']} ({it['id']})")
        return "\n".join(lines)
