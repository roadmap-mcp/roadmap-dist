"""Trello plugin activator."""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT
from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT

from . import runtime
from .context_items import TRELLO_ITEM_TYPES, TRELLO_PREVIEWS
from .mcp_tools import register_mcp_tools
from .settings_section import TRELLO_SECTION, create_trello_settings_router
from .trello_router import router as trello_router


class TrelloPlugin(Plugin):
    id = "roadmap.trello"
    name = "Trello"
    requires = ["roadmap.settings", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config)
        ctx.register_sensitive_path("trello.api_token")

        ctx.extend(SETTINGS_SECTIONS_POINT, TRELLO_SECTION)
        for item_type in TRELLO_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, item_type)
        for preview in TRELLO_PREVIEWS:
            ctx.extend(CONTEXT_PREVIEW_POINT, preview)

        ctx.add_router(trello_router)
        ctx.add_router(create_trello_settings_router())

        # Interactive Trello tools on the shared MCP server.
        register_mcp_tools(ctx.services.require("context"))
