"""HTTP client for the Trello REST API.

Auth is an API key + token. They are sent in the ``Authorization`` header rather
than as query parameters so the token never lands in a URL (and therefore never in
a log line or an exception message).
"""

from __future__ import annotations

import json
import re
import urllib.error
import urllib.parse
import urllib.request

from fastapi import HTTPException

from .models import TrelloConfig

#: A card URL (https://trello.com/c/<shortLink>/<n>-<slug>) or a bare id/shortLink.
#: Matched as a *prefix*: everything after the shortLink (Trello's `/<n>-<slug>`, a
#: query, a fragment) is decoration. The frontend's hint mirrors this — see
#: ``frontend/src/card-ref.ts``.
_CARD_URL_RE = re.compile(r"https?://(?:www\.)?trello\.com/c/(?P<short>[A-Za-z0-9]+)")

#: A board URL (https://trello.com/b/<shortLink>/<slug>) or a bare id/shortLink.
_BOARD_URL_RE = re.compile(r"https?://(?:www\.)?trello\.com/b/(?P<short>[A-Za-z0-9]+)")

#: Any bare id we are willing to hand to the API. Deliberately not length-bounded:
#: Trello short links are 8 chars and full ids 24, but guessing exact lengths here
#: only risks rejecting references the API would happily resolve. Let Trello decide.
_BARE_ID_RE = re.compile(r"^[A-Za-z0-9]+$")

_CARD_HELP = ("Paste the card URL (https://trello.com/c/<id>/...) or its id — the "
              "8-character code in that URL.")
_CARD_NUMBER_HELP = (
    "That looks like a card *number* (the '#7' shown on a card), which is only "
    "unique within its board, so it cannot identify a card on its own. " + _CARD_HELP)


def require_trello_configured(cfg: TrelloConfig) -> None:
    if not cfg.base_url:
        raise HTTPException(status_code=400, detail="Trello base URL is not configured.")
    if not cfg.api_key:
        raise HTTPException(
            status_code=400,
            detail="Trello API key is not configured. Generate one at "
                   "https://trello.com/apps/admin and add it in Workspace settings -> Trello.",
        )
    if not cfg.api_token:
        raise HTTPException(
            status_code=400,
            detail="Trello API token is not configured. Add one in Workspace settings -> Trello.",
        )


def parse_card_ref(ref: str) -> str:
    """Normalise a card URL or id to the id/shortLink the API addresses cards by."""
    ref = (ref or "").strip()
    if m := _CARD_URL_RE.match(ref):
        return m.group("short")
    if not ref:
        raise HTTPException(status_code=400, detail=f"No card given. {_CARD_HELP}")
    # A bare number is the per-board card number, not an id — call that out, since
    # it is the reference a user is most likely to reach for.
    if ref.isdigit():
        raise HTTPException(status_code=400, detail=_CARD_NUMBER_HELP)
    if _BARE_ID_RE.match(ref):
        return ref
    raise HTTPException(status_code=400,
                        detail=f"'{ref}' is not a Trello card reference. {_CARD_HELP}")


def parse_board_ref(ref: str) -> str:
    """Normalise a board URL or id to the id/shortLink the API addresses boards by."""
    ref = (ref or "").strip()
    if m := _BOARD_URL_RE.match(ref):
        return m.group("short")
    if ref and _BARE_ID_RE.match(ref):
        return ref
    raise HTTPException(
        status_code=400,
        detail=f"'{ref}' is not a Trello board reference. Paste the board URL "
               "(https://trello.com/b/<id>/...) or its id.",
    )


def trello_request(cfg: TrelloConfig, path: str, params: dict | None = None):
    """Authenticated GET against the Trello API. ``path`` is base-relative."""
    url = cfg.base_url.rstrip("/") + path
    if params:
        url += "?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={
        # Keeps the token out of the URL (and out of logs / error messages).
        "Authorization": f'OAuth oauth_consumer_key="{cfg.api_key}", '
                         f'oauth_token="{cfg.api_token}"',
        "Accept": "application/json",
    })
    try:
        with urllib.request.urlopen(req, timeout=15) as resp:
            return json.loads(resp.read().decode())
    except urllib.error.HTTPError as e:
        detail = e.read().decode(errors="replace")[:200].strip()
        if e.code in (401, 403):
            detail = (f"{detail or 'Unauthorized'} — check the API key and token in "
                      "Workspace settings -> Trello, and that the token grants access to this board.")
        elif e.code == 429:
            detail = ("Rate limited by Trello (300 requests/10s per key, 100/10s per "
                      "token). Try again shortly.")
        raise HTTPException(status_code=400, detail=f"Trello returned {e.code}: {detail}")
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))
