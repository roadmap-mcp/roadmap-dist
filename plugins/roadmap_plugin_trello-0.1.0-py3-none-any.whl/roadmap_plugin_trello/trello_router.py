"""Card lookup / refresh endpoints (``/api/trello``).

Used by the "add Trello card" UI to validate a card reference and prefill the
label before the item is added, and to force a refresh of a cached card.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from roadmap_framework import session

from . import runtime
from .trello_client import parse_card_ref, require_trello_configured

router = APIRouter(prefix="/api/trello", tags=["trello"])


class CardRefRequest(BaseModel):
    ref: str


def _require_unlocked():
    if runtime.has_encrypted_fields() and not session.is_unlocked():
        raise HTTPException(status_code=403,
                            detail="App is locked. Provide password to unlock.")


def _summary(data: dict) -> dict:
    return {
        "id": data.get("id", ""),
        "number": data.get("number"),
        "name": data.get("name", ""),
        "board": data.get("board", ""),
        "list": data.get("list", ""),
        "url": data.get("url", ""),
        "labels": data.get("labels", []),
        "members": data.get("members", []),
        "due": data.get("due", ""),
        "comment_count": len(data.get("comments", [])),
    }


@router.get("/card")
def lookup_card(ref: str):
    """Look up a card by URL or id (read-through cache)."""
    _require_unlocked()
    cfg = runtime.trello_config()
    require_trello_configured(cfg)
    card_id = parse_card_ref(ref)
    data = runtime.service().get_card(card_id)
    if not data:
        raise HTTPException(status_code=404,
                            detail=f"Trello card {card_id} could not be fetched.")
    return _summary(data)


@router.post("/card/refresh")
def refresh_card(req: CardRefRequest):
    """Force-refresh a card from the API, bypassing the cache."""
    _require_unlocked()
    cfg = runtime.trello_config()
    require_trello_configured(cfg)
    return _summary(runtime.service().fetch_card(parse_card_ref(req.ref)))
