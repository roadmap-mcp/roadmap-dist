"""Trello card fetching with read-through caching."""

from __future__ import annotations

import logging

from .cache import TrelloCache
from .models import TrelloConfig
from .trello_client import trello_request

log = logging.getLogger(__name__)

_COMMENT_LIMIT = 50

#: Pull the card plus the nested bits we render, in one round trip.
_CARD_PARAMS = {
    "fields": "name,desc,url,shortLink,idShort,closed,due,dueComplete,dateLastActivity,labels",
    "board": "true", "board_fields": "name",
    "list": "true", "list_fields": "name",
    "members": "true", "member_fields": "fullName",
    "checklists": "all",
}


def _build_comment(a: dict) -> dict:
    member = a.get("memberCreator", {}) or {}
    return {
        "author": member.get("fullName") or member.get("username", ""),
        "created": a.get("date", ""),
        "body": (a.get("data", {}) or {}).get("text", ""),
    }


def _build_checklists(card: dict) -> list[dict]:
    out = []
    for cl in card.get("checklists", []) or []:
        items = [{"name": i.get("name", ""), "done": i.get("state") == "complete"}
                 for i in cl.get("checkItems", []) or []]
        out.append({"name": cl.get("name", ""), "items": items})
    return out


def _build_card_result(card: dict, comments: list[dict]) -> dict:
    """Flatten a card + its comments into the shape we cache and render."""
    board = card.get("board", {}) or {}
    lst = card.get("list", {}) or {}
    return {
        "id": card.get("shortLink") or card.get("id", ""),
        "number": card.get("idShort"),
        "name": card.get("name", ""),
        "description": card.get("desc", ""),
        "url": card.get("url", ""),
        "board": board.get("name", ""),
        "list": lst.get("name", ""),
        "closed": bool(card.get("closed", False)),
        "due": card.get("due") or "",
        "due_complete": bool(card.get("dueComplete", False)),
        "last_activity": card.get("dateLastActivity", ""),
        "labels": [l.get("name") or l.get("color", "")
                   for l in card.get("labels", []) or []],
        "members": [m.get("fullName", "") for m in card.get("members", []) or []],
        "checklists": _build_checklists(card),
        "comments": [_build_comment(a) for a in comments],
    }


class TrelloService:
    def __init__(self, cfg: TrelloConfig, cache: TrelloCache):
        self.cfg = cfg
        self.cache = cache

    def fetch_card(self, card_id: str) -> dict:
        """Always hit the API and refresh the cache."""
        card = trello_request(self.cfg, f"/cards/{card_id}", _CARD_PARAMS)
        comments = self._fetch_comments(card_id)
        result = _build_card_result(card, comments)
        self.cache.write(self.cache.card_path(card_id), result)
        return result

    def get_card(self, card_id: str) -> dict | None:
        """Read-through cache: cached copy if fresh, else the API, else ``None``."""
        cached = self.cache.read(self.cache.card_path(card_id))
        if cached is not None:
            return cached
        try:
            return self.fetch_card(card_id)
        except Exception:
            log.warning("Failed to fetch Trello card %s", card_id)
            return None

    def list_board_cards(self, board_id: str) -> list[dict] | None:
        """Open cards on a board, grouped-friendly (id, name, list, url)."""
        path = self.cache.board_cards_path(board_id)
        cached = self.cache.read(path)
        if cached is not None:
            return cached.get("cards", [])
        try:
            cards = trello_request(self.cfg, f"/boards/{board_id}/cards", {
                "fields": "name,shortLink,idShort,url,closed",
                "list": "true", "list_fields": "name",
                "filter": "open",
            })
        except Exception:
            log.warning("Failed to list cards for Trello board %s", board_id)
            return None
        out = [{
            "id": c.get("shortLink") or c.get("id", ""),
            "number": c.get("idShort"),
            "name": c.get("name", ""),
            "list": (c.get("list", {}) or {}).get("name", ""),
            "url": c.get("url", ""),
        } for c in cards]
        self.cache.write(path, {"cards": out})
        return out

    def _fetch_comments(self, card_id: str) -> list[dict]:
        try:
            return trello_request(self.cfg, f"/cards/{card_id}/actions", {
                "filter": "commentCard", "limit": str(_COMMENT_LIMIT),
            })
        except Exception:
            return []
