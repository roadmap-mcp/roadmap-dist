"""Trello settings section + its connection test and board lookup."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from roadmap_framework import session
from roadmap_plugin_settings import SettingsSection

from . import runtime
from .models import TrelloConfig
from .trello_client import (parse_board_ref, require_trello_configured,
                            trello_request)


def _trello_defaults() -> dict:
    return {"trello": TrelloConfig().model_dump()}


TRELLO_SECTION = SettingsSection(
    id="trello",
    label="Trello",
    order=26,
    group="Information Sources",
    defaults=_trello_defaults,
    sensitive_fields=["trello.api_token"],
)


def create_trello_settings_router() -> APIRouter:
    router = APIRouter(prefix="/api/settings", tags=["settings", "trello"])

    def require_unlocked():
        if runtime.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    @router.post("/test-trello")
    def test_trello():
        """Verify the key/token pair by identifying the authorising member."""
        require_unlocked()
        cfg = runtime.trello_config()
        require_trello_configured(cfg)
        data = trello_request(cfg, "/members/me", {"fields": "fullName,username"})
        who = data.get("fullName") or data.get("username") or "Unknown"
        return {"status": "ok", "message": f"Connected as {who}"}

    @router.get("/trello/board")
    def lookup_board(ref: str):
        """Look up a board by URL or id — used to add it in settings."""
        require_unlocked()
        cfg = runtime.trello_config()
        require_trello_configured(cfg)
        board_id = parse_board_ref(ref)
        data = trello_request(cfg, f"/boards/{board_id}",
                              {"fields": "name,url,shortLink"})
        return {
            "id": data.get("shortLink") or data.get("id", board_id),
            "name": data.get("name", ""),
            "url": data.get("url", ""),
        }

    return router
