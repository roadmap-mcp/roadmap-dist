"""Trello plugin runtime — config + cache access."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

from roadmap_framework import ConfigStore

from .cache import TrelloCache
from .models import TrelloConfig

_store: Optional[ConfigStore] = None


def set_runtime(config: ConfigStore) -> None:
    global _store
    _store = config


def _require_store() -> ConfigStore:
    assert _store is not None, "trello runtime not initialised"
    return _store


def config_dir() -> Path:
    return _require_store().path.parent


def has_encrypted_fields() -> bool:
    return _require_store().has_encrypted_fields()


def trello_config() -> TrelloConfig:
    raw = _require_store().load_decrypted()
    return TrelloConfig(**(raw.get("trello") or {}))


def save_trello_config(cfg: TrelloConfig) -> None:
    raw = _require_store().load_decrypted()
    raw["trello"] = cfg.model_dump()
    _require_store().save(raw)


def cache() -> TrelloCache:
    cfg = trello_config()
    return TrelloCache(cfg.cache_dir or str(config_dir() / "cache"),
                       cfg.refresh_duration)


def service():
    """A :class:`TrelloService` bound to the current config + cache."""
    from .trello_service import TrelloService
    return TrelloService(trello_config(), cache())
