"""The ``trello_card`` context item type + preview contributions."""

from __future__ import annotations

from fastapi import HTTPException

from roadmap_plugin_context import ContextItemType, PreviewContribution

from . import runtime
from .trello_client import parse_board_ref, parse_card_ref

#: Comments rendered in full before the "and N more" tail.
_MAX_RENDERED_COMMENTS = 20


def resolve_trello_card(card_ref: str, *, text=None, path=None) -> dict:
    """Add-time metadata for a card. The item id is the card's shortLink."""
    card_id = parse_card_ref(card_ref)
    data = runtime.service().get_card(card_id)
    if not data:
        raise HTTPException(
            status_code=404,
            detail=f"Trello card {card_id} could not be fetched. Check the card "
                   "and your key/token in Workspace settings -> Trello.",
        )
    number = data.get("number")
    return {
        "type": "trello_card",
        "id": data.get("id") or card_id,
        "title": f"{data.get('board', '')}#{number}" if number else card_id,
        "label": data.get("name", f"Card {card_id}"),
    }


def render_trello_card(card_ref: str, label: str) -> str:
    """Render a card — metadata, description, checklists and comments — as markdown."""
    card_id = parse_card_ref(card_ref)
    data = runtime.service().get_card(card_id)
    if not data:
        return f"## {label} (Trello Card)\n\n(Card not found)"

    number = data.get("number")
    heading = f"{data.get('board', 'Trello')}#{number}" if number else card_id
    lines = [f"## {label} ({heading})"]

    meta = [f"**List:** {data.get('list') or '—'}"]
    if data.get("closed"):
        meta.append("**Archived:** yes")
    if members := data.get("members"):
        meta.append(f"**Members:** {', '.join(members)}")
    lines.append(" | ".join(meta))

    if labels := data.get("labels"):
        lines.append(f"**Labels:** {', '.join(l for l in labels if l)}")
    if due := data.get("due"):
        state = "done" if data.get("due_complete") else "open"
        lines.append(f"**Due:** {due[:10]} ({state})")
    if url := data.get("url"):
        lines.append(f"**URL:** {url}")

    if description := data.get("description"):
        lines.append(f"\n### Description\n{description}")

    for checklist in data.get("checklists", []):
        items = checklist.get("items", [])
        done = sum(1 for i in items if i.get("done"))
        lines.append(f"\n### Checklist: {checklist.get('name', '')} ({done}/{len(items)})")
        for item in items:
            lines.append(f"- [{'x' if item.get('done') else ' '}] {item.get('name', '')}")

    comments = data.get("comments", [])
    if comments:
        lines.append(f"\n### Comments ({len(comments)})")
        for c in comments[:_MAX_RENDERED_COMMENTS]:
            lines.append(
                f"\n**{c.get('author', 'Unknown')}** "
                f"({c.get('created', '')[:10]}):\n{c.get('body', '')}"
            )
        if len(comments) > _MAX_RENDERED_COMMENTS:
            lines.append(f"\n... and {len(comments) - _MAX_RENDERED_COMMENTS} more comments")

    return "\n".join(lines)


def render_trello_board_cards(board_ref: str, label: str) -> str:
    """Render the open cards on a board, grouped by list."""
    board_id = parse_board_ref(board_ref)
    cards = runtime.service().list_board_cards(board_id)
    if cards is None:
        return f"## {label} (Trello Board)\n\n(Board not found)"
    if not cards:
        return f"## {label} (Trello Board)\n\n(No open cards)"

    lines = [f"## {label} (Trello Board)", f"{len(cards)} open card(s)"]
    by_list: dict[str, list[dict]] = {}
    for card in cards:
        by_list.setdefault(card.get("list") or "(no list)", []).append(card)
    for list_name, group in by_list.items():
        lines.append(f"\n### {list_name} ({len(group)})")
        for card in group:
            number = f"#{card['number']} " if card.get("number") else ""
            lines.append(f"- {number}{card.get('name', '')} — `{card.get('id', '')}`")
    return "\n".join(lines)


TRELLO_ITEM_TYPES = [
    ContextItemType(
        "trello_card",
        resolve=resolve_trello_card,
        render=lambda item, cfg: render_trello_card(
            item.get("id", ""),
            item.get("label", item.get("title", "Untitled")),
        ),
        label="Trello Card",
        icon="bi-trello",
    ),
]

TRELLO_PREVIEWS = [
    PreviewContribution(
        "trello_card",
        lambda params, label, cfg: render_trello_card(params.get("card_id", ""), label),
        label="Trello Card",
    ),
    PreviewContribution(
        "trello_board_cards",
        lambda params, label, cfg: render_trello_board_cards(params.get("board_id", ""), label),
        label="Trello Board Cards",
    ),
]
