import { a as e, b as i, c as a, d as n, e as o, g as u, i as d, x as l, y as s } from "@nf-internal/chunk-EPGORQP5";
var C = class extends s {
    static { e(this, "CynefinTokenBuilder"); }
    constructor() { super(["cynefin-beta"]); }
}, f = { parser: { TokenBuilder: e(() => new C, "TokenBuilder"), ValueConverter: e(() => new l, "ValueConverter") } };
function m(c = o) { let r = n(a(c), u), t = n(i({ shared: r }), d, f); return r.ServiceRegistry.register(t), { shared: r, Cynefin: t }; }
e(m, "createCynefinServices");
export { f as a, m as b };
