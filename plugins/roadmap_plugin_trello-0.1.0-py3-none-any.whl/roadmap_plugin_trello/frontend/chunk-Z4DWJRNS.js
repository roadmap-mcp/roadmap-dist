import { H as l, M as o, ja as p, y as d } from "@nf-internal/chunk-LAIZNMCN";
import { Subject as n } from "rxjs";
import { tap as h, debounceTime as a, filter as _, map as c } from "rxjs/operators";
var I = 200, m = class {
    _letterKeyStream = new n;
    _items = [];
    _selectedItemIndex = -1;
    _pressedLetters = [];
    _skipPredicateFn;
    _selectedItem = new n;
    selectedItem = this._selectedItem;
    constructor(t, e) { let s = typeof e?.debounceInterval == "number" ? e.debounceInterval : I; e?.skipPredicate && (this._skipPredicateFn = e.skipPredicate), this.setItems(t), this._setupKeyHandler(s); }
    destroy() { this._pressedLetters = [], this._letterKeyStream.complete(), this._selectedItem.complete(); }
    setCurrentSelectedItemIndex(t) { this._selectedItemIndex = t; }
    setItems(t) { this._items = t; }
    handleKey(t) { let e = t.keyCode; t.key && t.key.length === 1 ? this._letterKeyStream.next(t.key.toLocaleUpperCase()) : (e >= 65 && e <= 90 || e >= 48 && e <= 57) && this._letterKeyStream.next(String.fromCharCode(e)); }
    isTyping() { return this._pressedLetters.length > 0; }
    reset() { this._pressedLetters = []; }
    _setupKeyHandler(t) { this._letterKeyStream.pipe(h(e => this._pressedLetters.push(e)), a(t), _(() => this._pressedLetters.length > 0), c(() => this._pressedLetters.join("").toLocaleUpperCase())).subscribe(e => { for (let s = 1; s < this._items.length + 1; s++) {
        let r = (this._selectedItemIndex + s) % this._items.length, i = this._items[r];
        if (!this._skipPredicateFn?.(i) && i.getLabel?.().toLocaleUpperCase().trim().indexOf(e) === 0) {
            this._selectedItem.next(i);
            break;
        }
    } this._pressedLetters = []; }); }
};
export { m as a };
