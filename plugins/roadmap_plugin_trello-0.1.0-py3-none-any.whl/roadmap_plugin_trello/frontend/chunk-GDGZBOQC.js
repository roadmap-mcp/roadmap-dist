import { a as i } from "@nf-internal/chunk-YUSHYV7C";
function $n(w) { return w && w.__esModule && Object.prototype.hasOwnProperty.call(w, "default") ? w.default : w; }
i($n, "getDefaultExportFromCjs");
var D = {}, Ye = {}, oe = {}, _n;
function ge() { if (_n)
    return oe; _n = 1; function w(d) { return typeof d > "u" || d === null; } i(w, "isNothing"); function E(d) { return typeof d == "object" && d !== null; } i(E, "isObject"); function _(d) { return Array.isArray(d) ? d : w(d) ? [] : [d]; } i(_, "toArray"); function O(d, p) { if (p) {
    let C = Object.keys(p);
    for (let o = 0, u = C.length; o < u; o += 1) {
        let T = C[o];
        d[T] = p[T];
    }
} return d; } i(O, "extend"); function h(d, p) { let C = ""; for (let o = 0; o < p; o += 1)
    C += d; return C; } i(h, "repeat"); function y(d) { return d === 0 && Number.NEGATIVE_INFINITY === 1 / d; } return i(y, "isNegativeZero"), oe.isNothing = w, oe.isObject = E, oe.toArray = _, oe.repeat = h, oe.isNegativeZero = y, oe.extend = O, oe; }
i(ge, "requireCommon");
var De, In;
function Ae() {
    if (In)
        return De;
    In = 1;
    function w(_, O) {
        let h = "", y = _.reason || "(unknown reason)";
        return _.mark ? (_.mark.name && (h += 'in "' + _.mark.name + '" '), h += "(" + (_.mark.line + 1) + ":" + (_.mark.column + 1) + ")", !O && _.mark.snippet && (h += `

` + _.mark.snippet), y + " " + h) : y;
    }
    i(w, "formatError");
    function E(_, O) { Error.call(this), this.name = "YAMLException", this.reason = _, this.mark = O, this.message = w(this, !1), Error.captureStackTrace ? Error.captureStackTrace(this, this.constructor) : this.stack = new Error().stack || ""; }
    return i(E, "YAMLException2"), E.prototype = Object.create(Error.prototype), E.prototype.constructor = E, E.prototype.toString = i(function (O) { return this.name + ": " + w(this, O); }, "toString"), De = E, De;
}
i(Ae, "requireException");
var Be, kn;
function Zn() {
    if (kn)
        return Be;
    kn = 1;
    let w = ge();
    function E(h, y, d, p, C) { let o = "", u = "", T = Math.floor(C / 2) - 1; return p - y > T && (o = " ... ", y = p - T + o.length), d - p > T && (u = " ...", d = p + T - u.length), { str: o + h.slice(y, d).replace(/\t/g, "\u2192") + u, pos: p - y + o.length }; }
    i(E, "getLine");
    function _(h, y) { return w.repeat(" ", y - h.length) + h; }
    i(_, "padStart");
    function O(h, y) {
        if (y = Object.create(y || null), !h.buffer)
            return null;
        y.maxLength || (y.maxLength = 79), typeof y.indent != "number" && (y.indent = 1), typeof y.linesBefore != "number" && (y.linesBefore = 3), typeof y.linesAfter != "number" && (y.linesAfter = 2);
        let d = /\r?\n|\r|\0/g, p = [0], C = [], o, u = -1;
        for (; o = d.exec(h.buffer);)
            C.push(o.index), p.push(o.index + o[0].length), h.position <= o.index && u < 0 && (u = p.length - 2);
        u < 0 && (u = p.length - 1);
        let T = "", v = Math.min(h.line + y.linesAfter, C.length).toString().length, M = y.maxLength - (y.indent + v + 3);
        for (let F = 1; F <= y.linesBefore && !(u - F < 0); F++) {
            let K = E(h.buffer, p[u - F], C[u - F], h.position - (p[u] - p[u - F]), M);
            T = w.repeat(" ", y.indent) + _((h.line - F + 1).toString(), v) + " | " + K.str + `
` + T;
        }
        let Z = E(h.buffer, p[u], C[u], h.position, M);
        T += w.repeat(" ", y.indent) + _((h.line + 1).toString(), v) + " | " + Z.str + `
`, T += w.repeat("-", y.indent + v + 3 + Z.pos) + `^
`;
        for (let F = 1; F <= y.linesAfter && !(u + F >= C.length); F++) {
            let K = E(h.buffer, p[u + F], C[u + F], h.position - (p[u] - p[u + F]), M);
            T += w.repeat(" ", y.indent) + _((h.line + F + 1).toString(), v) + " | " + K.str + `
`;
        }
        return T.replace(/\n$/, "");
    }
    return i(O, "makeSnippet"), Be = O, Be;
}
i(Zn, "requireSnippet");
var He, Ln;
function B() { if (Ln)
    return He; Ln = 1; let w = Ae(), E = ["kind", "multi", "resolve", "construct", "instanceOf", "predicate", "represent", "representName", "defaultStyle", "styleAliases"], _ = ["scalar", "sequence", "mapping"]; function O(y) { let d = {}; return y !== null && Object.keys(y).forEach(function (p) { y[p].forEach(function (C) { d[String(C)] = p; }); }), d; } i(O, "compileStyleAliases"); function h(y, d) { if (d = d || {}, Object.keys(d).forEach(function (p) { if (E.indexOf(p) === -1)
    throw new w('Unknown option "' + p + '" is met in definition of "' + y + '" YAML type.'); }), this.options = d, this.tag = y, this.kind = d.kind || null, this.resolve = d.resolve || function () { return !0; }, this.construct = d.construct || function (p) { return p; }, this.instanceOf = d.instanceOf || null, this.predicate = d.predicate || null, this.represent = d.represent || null, this.representName = d.representName || null, this.defaultStyle = d.defaultStyle || null, this.multi = d.multi || !1, this.styleAliases = O(d.styleAliases || null), _.indexOf(this.kind) === -1)
    throw new w('Unknown kind "' + this.kind + '" is specified for "' + y + '" YAML type.'); } return i(h, "Type2"), He = h, He; }
i(B, "requireType");
var je, On;
function un() { if (On)
    return je; On = 1; let w = Ae(), E = B(); function _(y, d) { let p = []; return y[d].forEach(function (C) { let o = p.length; p.forEach(function (u, T) { u.tag === C.tag && u.kind === C.kind && u.multi === C.multi && (o = T); }), p[o] = C; }), p; } i(_, "compileList"); function O() { let y = { scalar: {}, sequence: {}, mapping: {}, fallback: {}, multi: { scalar: [], sequence: [], mapping: [], fallback: [] } }; function d(p) { p.multi ? (y.multi[p.kind].push(p), y.multi.fallback.push(p)) : y[p.kind][p.tag] = y.fallback[p.tag] = p; } i(d, "collectType"); for (let p = 0, C = arguments.length; p < C; p += 1)
    arguments[p].forEach(d); return y; } i(O, "compileMap"); function h(y) { return this.extend(y); } return i(h, "Schema2"), h.prototype.extend = i(function (d) { let p = [], C = []; if (d instanceof E)
    C.push(d);
else if (Array.isArray(d))
    C = C.concat(d);
else if (d && (Array.isArray(d.implicit) || Array.isArray(d.explicit)))
    d.implicit && (p = p.concat(d.implicit)), d.explicit && (C = C.concat(d.explicit));
else
    throw new w("Schema.extend argument should be a Type, [ Type ], or a schema definition ({ implicit: [...], explicit: [...] })"); p.forEach(function (u) { if (!(u instanceof E))
    throw new w("Specified list of YAML types (or a single Type object) contains a non-Type object."); if (u.loadKind && u.loadKind !== "scalar")
    throw new w("There is a non-scalar type in the implicit list of a schema. Implicit resolving of such types is not supported."); if (u.multi)
    throw new w("There is a multi type in the implicit list of a schema. Multi tags can only be listed as explicit."); }), C.forEach(function (u) { if (!(u instanceof E))
    throw new w("Specified list of YAML types (or a single Type object) contains a non-Type object."); }); let o = Object.create(h.prototype); return o.implicit = (this.implicit || []).concat(p), o.explicit = (this.explicit || []).concat(C), o.compiledImplicit = _(o, "implicit"), o.compiledExplicit = _(o, "explicit"), o.compiledTypeMap = O(o.compiledImplicit, o.compiledExplicit), o; }, "extend"), je = h, je; }
i(un, "requireSchema");
var Ue, vn;
function fn() { if (vn)
    return Ue; vn = 1; let w = B(); return Ue = new w("tag:yaml.org,2002:str", { kind: "scalar", construct: i(function (E) { return E !== null ? E : ""; }, "construct") }), Ue; }
i(fn, "requireStr");
var Ke, Nn;
function an() { if (Nn)
    return Ke; Nn = 1; let w = B(); return Ke = new w("tag:yaml.org,2002:seq", { kind: "sequence", construct: i(function (E) { return E !== null ? E : []; }, "construct") }), Ke; }
i(an, "requireSeq");
var Ge, Mn;
function pn() { if (Mn)
    return Ge; Mn = 1; let w = B(); return Ge = new w("tag:yaml.org,2002:map", { kind: "mapping", construct: i(function (E) { return E !== null ? E : {}; }, "construct") }), Ge; }
i(pn, "requireMap");
var We, Rn;
function sn() { if (Rn)
    return We; Rn = 1; let w = un(); return We = new w({ explicit: [fn(), an(), pn()] }), We; }
i(sn, "requireFailsafe");
var Qe, qn;
function hn() { if (qn)
    return Qe; qn = 1; let w = B(); function E(h) { if (h === null)
    return !0; let y = h.length; return y === 1 && h === "~" || y === 4 && (h === "null" || h === "Null" || h === "NULL"); } i(E, "resolveYamlNull"); function _() { return null; } i(_, "constructYamlNull"); function O(h) { return h === null; } return i(O, "isNull"), Qe = new w("tag:yaml.org,2002:null", { kind: "scalar", resolve: E, construct: _, predicate: O, represent: { canonical: i(function () { return "~"; }, "canonical"), lowercase: i(function () { return "null"; }, "lowercase"), uppercase: i(function () { return "NULL"; }, "uppercase"), camelcase: i(function () { return "Null"; }, "camelcase"), empty: i(function () { return ""; }, "empty") }, defaultStyle: "lowercase" }), Qe; }
i(hn, "require_null");
var Ve, Fn;
function dn() { if (Fn)
    return Ve; Fn = 1; let w = B(); function E(h) { if (h === null)
    return !1; let y = h.length; return y === 4 && (h === "true" || h === "True" || h === "TRUE") || y === 5 && (h === "false" || h === "False" || h === "FALSE"); } i(E, "resolveYamlBoolean"); function _(h) { return h === "true" || h === "True" || h === "TRUE"; } i(_, "constructYamlBoolean"); function O(h) { return Object.prototype.toString.call(h) === "[object Boolean]"; } return i(O, "isBoolean"), Ve = new w("tag:yaml.org,2002:bool", { kind: "scalar", resolve: E, construct: _, predicate: O, represent: { lowercase: i(function (h) { return h ? "true" : "false"; }, "lowercase"), uppercase: i(function (h) { return h ? "TRUE" : "FALSE"; }, "uppercase"), camelcase: i(function (h) { return h ? "True" : "False"; }, "camelcase") }, defaultStyle: "lowercase" }), Ve; }
i(dn, "requireBool");
var Je, Yn;
function mn() { if (Yn)
    return Je; Yn = 1; let w = ge(), E = B(); function _(o) { return o >= 48 && o <= 57 || o >= 65 && o <= 70 || o >= 97 && o <= 102; } i(_, "isHexCode"); function O(o) { return o >= 48 && o <= 55; } i(O, "isOctCode"); function h(o) { return o >= 48 && o <= 57; } i(h, "isDecCode"); function y(o) { if (o === null)
    return !1; let u = o.length, T = 0, v = !1; if (!u)
    return !1; let M = o[T]; if ((M === "-" || M === "+") && (M = o[++T]), M === "0") {
    if (T + 1 === u)
        return !0;
    if (M = o[++T], M === "b") {
        for (T++; T < u; T++) {
            if (M = o[T], M !== "0" && M !== "1")
                return !1;
            v = !0;
        }
        return v && isFinite(d(o));
    }
    if (M === "x") {
        for (T++; T < u; T++) {
            if (!_(o.charCodeAt(T)))
                return !1;
            v = !0;
        }
        return v && isFinite(d(o));
    }
    if (M === "o") {
        for (T++; T < u; T++) {
            if (!O(o.charCodeAt(T)))
                return !1;
            v = !0;
        }
        return v && isFinite(d(o));
    }
} for (; T < u; T++) {
    if (!h(o.charCodeAt(T)))
        return !1;
    v = !0;
} return v ? isFinite(d(o)) : !1; } i(y, "resolveYamlInteger"); function d(o) { let u = o, T = 1, v = u[0]; if ((v === "-" || v === "+") && (v === "-" && (T = -1), u = u.slice(1), v = u[0]), u === "0")
    return 0; if (v === "0") {
    if (u[1] === "b")
        return T * parseInt(u.slice(2), 2);
    if (u[1] === "x")
        return T * parseInt(u.slice(2), 16);
    if (u[1] === "o")
        return T * parseInt(u.slice(2), 8);
} return T * parseInt(u, 10); } i(d, "parseYamlInteger"); function p(o) { return d(o); } i(p, "constructYamlInteger"); function C(o) { return Object.prototype.toString.call(o) === "[object Number]" && o % 1 === 0 && !w.isNegativeZero(o); } return i(C, "isInteger"), Je = new E("tag:yaml.org,2002:int", { kind: "scalar", resolve: y, construct: p, predicate: C, represent: { binary: i(function (o) { return o >= 0 ? "0b" + o.toString(2) : "-0b" + o.toString(2).slice(1); }, "binary"), octal: i(function (o) { return o >= 0 ? "0o" + o.toString(8) : "-0o" + o.toString(8).slice(1); }, "octal"), decimal: i(function (o) { return o.toString(10); }, "decimal"), hexadecimal: i(function (o) { return o >= 0 ? "0x" + o.toString(16).toUpperCase() : "-0x" + o.toString(16).toUpperCase().slice(1); }, "hexadecimal") }, defaultStyle: "decimal", styleAliases: { binary: [2, "bin"], octal: [8, "oct"], decimal: [10, "dec"], hexadecimal: [16, "hex"] } }), Je; }
i(mn, "requireInt");
var Xe, Pn;
function gn() { if (Pn)
    return Xe; Pn = 1; let w = ge(), E = B(), _ = new RegExp("^(?:[-+]?(?:[0-9]+)(?:\\.[0-9]*)?(?:[eE][-+]?[0-9]+)?|\\.[0-9]+(?:[eE][-+]?[0-9]+)?|[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"), O = new RegExp("^(?:[-+]?\\.(?:inf|Inf|INF)|\\.(?:nan|NaN|NAN))$"); function h(o) { return o === null || !_.test(o) ? !1 : isFinite(parseFloat(o, 10)) ? !0 : O.test(o); } i(h, "resolveYamlFloat"); function y(o) { let u = o.toLowerCase(), T = u[0] === "-" ? -1 : 1; return "+-".indexOf(u[0]) >= 0 && (u = u.slice(1)), u === ".inf" ? T === 1 ? Number.POSITIVE_INFINITY : Number.NEGATIVE_INFINITY : u === ".nan" ? NaN : T * parseFloat(u, 10); } i(y, "constructYamlFloat"); let d = /^[-+]?[0-9]+e/; function p(o, u) { if (isNaN(o))
    switch (u) {
        case "lowercase": return ".nan";
        case "uppercase": return ".NAN";
        case "camelcase": return ".NaN";
    }
else if (Number.POSITIVE_INFINITY === o)
    switch (u) {
        case "lowercase": return ".inf";
        case "uppercase": return ".INF";
        case "camelcase": return ".Inf";
    }
else if (Number.NEGATIVE_INFINITY === o)
    switch (u) {
        case "lowercase": return "-.inf";
        case "uppercase": return "-.INF";
        case "camelcase": return "-.Inf";
    }
else if (w.isNegativeZero(o))
    return "-0.0"; let T = o.toString(10); return d.test(T) ? T.replace("e", ".e") : T; } i(p, "representYamlFloat"); function C(o) { return Object.prototype.toString.call(o) === "[object Number]" && (o % 1 !== 0 || w.isNegativeZero(o)); } return i(C, "isFloat"), Xe = new E("tag:yaml.org,2002:float", { kind: "scalar", resolve: h, construct: y, predicate: C, represent: p, defaultStyle: "lowercase" }), Xe; }
i(gn, "requireFloat");
var $e, Dn;
function An() { return Dn || (Dn = 1, $e = sn().extend({ implicit: [hn(), dn(), mn(), gn()] })), $e; }
i(An, "requireJson");
var Ze, Bn;
function yn() { return Bn || (Bn = 1, Ze = An()), Ze; }
i(yn, "requireCore");
var ze, Hn;
function Sn() { if (Hn)
    return ze; Hn = 1; let w = B(), E = new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9])-([0-9][0-9])$"), _ = new RegExp("^([0-9][0-9][0-9][0-9])-([0-9][0-9]?)-([0-9][0-9]?)(?:[Tt]|[ \\t]+)([0-9][0-9]?):([0-9][0-9]):([0-9][0-9])(?:\\.([0-9]*))?(?:[ \\t]*(Z|([-+])([0-9][0-9]?)(?::([0-9][0-9]))?))?$"); function O(d) { return d === null ? !1 : E.exec(d) !== null || _.exec(d) !== null; } i(O, "resolveYamlTimestamp"); function h(d) { let p = 0, C = null, o = E.exec(d); if (o === null && (o = _.exec(d)), o === null)
    throw new Error("Date resolve error"); let u = +o[1], T = +o[2] - 1, v = +o[3]; if (!o[4])
    return new Date(Date.UTC(u, T, v)); let M = +o[4], Z = +o[5], F = +o[6]; if (o[7]) {
    for (p = o[7].slice(0, 3); p.length < 3;)
        p += "0";
    p = +p;
} if (o[9]) {
    let z = +o[10], H = +(o[11] || 0);
    C = (z * 60 + H) * 6e4, o[9] === "-" && (C = -C);
} let K = new Date(Date.UTC(u, T, v, M, Z, F, p)); return C && K.setTime(K.getTime() - C), K; } i(h, "constructYamlTimestamp"); function y(d) { return d.toISOString(); } return i(y, "representYamlTimestamp"), ze = new w("tag:yaml.org,2002:timestamp", { kind: "scalar", resolve: O, construct: h, instanceOf: Date, represent: y }), ze; }
i(Sn, "requireTimestamp");
var en, jn;
function Cn() { if (jn)
    return en; jn = 1; let w = B(); function E(_) { return _ === "<<" || _ === null; } return i(E, "resolveYamlMerge"), en = new w("tag:yaml.org,2002:merge", { kind: "scalar", resolve: E }), en; }
i(Cn, "requireMerge");
var nn, Un;
function Tn() {
    if (Un)
        return nn;
    Un = 1;
    let w = B(), E = `ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=
\r`;
    function _(d) { if (d === null)
        return !1; let p = 0, C = d.length, o = E; for (let u = 0; u < C; u++) {
        let T = o.indexOf(d.charAt(u));
        if (!(T > 64)) {
            if (T < 0)
                return !1;
            p += 6;
        }
    } return p % 8 === 0; }
    i(_, "resolveYamlBinary");
    function O(d) { let p = d.replace(/[\r\n=]/g, ""), C = p.length, o = E, u = 0, T = []; for (let M = 0; M < C; M++)
        M % 4 === 0 && M && (T.push(u >> 16 & 255), T.push(u >> 8 & 255), T.push(u & 255)), u = u << 6 | o.indexOf(p.charAt(M)); let v = C % 4 * 6; return v === 0 ? (T.push(u >> 16 & 255), T.push(u >> 8 & 255), T.push(u & 255)) : v === 18 ? (T.push(u >> 10 & 255), T.push(u >> 2 & 255)) : v === 12 && T.push(u >> 4 & 255), new Uint8Array(T); }
    i(O, "constructYamlBinary");
    function h(d) { let p = "", C = 0, o = d.length, u = E; for (let v = 0; v < o; v++)
        v % 3 === 0 && v && (p += u[C >> 18 & 63], p += u[C >> 12 & 63], p += u[C >> 6 & 63], p += u[C & 63]), C = (C << 8) + d[v]; let T = o % 3; return T === 0 ? (p += u[C >> 18 & 63], p += u[C >> 12 & 63], p += u[C >> 6 & 63], p += u[C & 63]) : T === 2 ? (p += u[C >> 10 & 63], p += u[C >> 4 & 63], p += u[C << 2 & 63], p += u[64]) : T === 1 && (p += u[C >> 2 & 63], p += u[C << 4 & 63], p += u[64], p += u[64]), p; }
    i(h, "representYamlBinary");
    function y(d) { return Object.prototype.toString.call(d) === "[object Uint8Array]"; }
    return i(y, "isBinary"), nn = new w("tag:yaml.org,2002:binary", { kind: "scalar", resolve: _, construct: O, predicate: y, represent: h }), nn;
}
i(Tn, "requireBinary");
var rn, Kn;
function wn() { if (Kn)
    return rn; Kn = 1; let w = B(), E = Object.prototype.hasOwnProperty, _ = Object.prototype.toString; function O(y) { if (y === null)
    return !0; let d = [], p = y; for (let C = 0, o = p.length; C < o; C += 1) {
    let u = p[C], T = !1;
    if (_.call(u) !== "[object Object]")
        return !1;
    let v;
    for (v in u)
        if (E.call(u, v))
            if (!T)
                T = !0;
            else
                return !1;
    if (!T)
        return !1;
    if (d.indexOf(v) === -1)
        d.push(v);
    else
        return !1;
} return !0; } i(O, "resolveYamlOmap"); function h(y) { return y !== null ? y : []; } return i(h, "constructYamlOmap"), rn = new w("tag:yaml.org,2002:omap", { kind: "sequence", resolve: O, construct: h }), rn; }
i(wn, "requireOmap");
var ln, Gn;
function xn() { if (Gn)
    return ln; Gn = 1; let w = B(), E = Object.prototype.toString; function _(h) { if (h === null)
    return !0; let y = h, d = new Array(y.length); for (let p = 0, C = y.length; p < C; p += 1) {
    let o = y[p];
    if (E.call(o) !== "[object Object]")
        return !1;
    let u = Object.keys(o);
    if (u.length !== 1)
        return !1;
    d[p] = [u[0], o[u[0]]];
} return !0; } i(_, "resolveYamlPairs"); function O(h) { if (h === null)
    return []; let y = h, d = new Array(y.length); for (let p = 0, C = y.length; p < C; p += 1) {
    let o = y[p], u = Object.keys(o);
    d[p] = [u[0], o[u[0]]];
} return d; } return i(O, "constructYamlPairs"), ln = new w("tag:yaml.org,2002:pairs", { kind: "sequence", resolve: _, construct: O }), ln; }
i(xn, "requirePairs");
var on, Wn;
function bn() { if (Wn)
    return on; Wn = 1; let w = B(), E = Object.prototype.hasOwnProperty; function _(h) { if (h === null)
    return !0; let y = h; for (let d in y)
    if (E.call(y, d) && y[d] !== null)
        return !1; return !0; } i(_, "resolveYamlSet"); function O(h) { return h !== null ? h : {}; } return i(O, "constructYamlSet"), on = new w("tag:yaml.org,2002:set", { kind: "mapping", resolve: _, construct: O }), on; }
i(bn, "requireSet");
var tn, Qn;
function Pe() { return Qn || (Qn = 1, tn = yn().extend({ implicit: [Sn(), Cn()], explicit: [Tn(), wn(), xn(), bn()] })), tn; }
i(Pe, "require_default");
var Vn;
function zn() {
    if (Vn)
        return Ye;
    Vn = 1;
    let w = ge(), E = Ae(), _ = Zn(), O = Pe(), h = Object.prototype.hasOwnProperty, y = 1, d = 2, p = 3, C = 4, o = 1, u = 2, T = 3, v = /[\x00-\x08\x0B\x0C\x0E-\x1F\x7F-\x84\x86-\x9F\uFFFE\uFFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])|(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]/, M = /[\x85\u2028\u2029]/, Z = /[,\[\]{}]/, F = /^(?:!|!!|![0-9A-Za-z-]+!)$/, K = /^(?:!|[^,\[\]{}])(?:%[0-9a-f]{2}|[0-9a-z\-#;/?:@&=+$,_.!~*'()\[\]])*$/i;
    function z(e) { return Object.prototype.toString.call(e); }
    i(z, "_class");
    function H(e) { return e === 10 || e === 13; }
    i(H, "isEol");
    function j(e) { return e === 9 || e === 32; }
    i(j, "isWhiteSpace");
    function P(e) { return e === 9 || e === 32 || e === 10 || e === 13; }
    i(P, "isWsOrEol");
    function $(e) { return e === 44 || e === 91 || e === 93 || e === 123 || e === 125; }
    i($, "isFlowIndicator");
    function Ne(e) { if (e >= 48 && e <= 57)
        return e - 48; let r = e | 32; return r >= 97 && r <= 102 ? r - 97 + 10 : -1; }
    i(Ne, "fromHexCode");
    function Me(e) { return e === 120 ? 2 : e === 117 ? 4 : e === 85 ? 8 : 0; }
    i(Me, "escapedHexLen");
    function ye(e) { return e >= 48 && e <= 57 ? e - 48 : -1; }
    i(ye, "fromDecimalCode");
    function ce(e) {
        switch (e) {
            case 48: return "\0";
            case 97: return "\x07";
            case 98: return "\b";
            case 116: return "	";
            case 9: return "	";
            case 110: return `
`;
            case 118: return "\v";
            case 102: return "\f";
            case 114: return "\r";
            case 101: return "\x1B";
            case 32: return " ";
            case 34: return '"';
            case 47: return "/";
            case 92: return "\\";
            case 78: return "\x85";
            case 95: return "\xA0";
            case 76: return "\u2028";
            case 80: return "\u2029";
            default: return "";
        }
    }
    i(ce, "simpleEscapeSequence");
    function Re(e) { return e <= 65535 ? String.fromCharCode(e) : String.fromCharCode((e - 65536 >> 10) + 55296, (e - 65536 & 1023) + 56320); }
    i(Re, "charFromCodepoint");
    function ue(e, r, c) { r === "__proto__" ? Object.defineProperty(e, r, { configurable: !0, enumerable: !0, writable: !0, value: c }) : e[r] = c; }
    i(ue, "setProperty");
    let qe = new Array(256), Se = new Array(256);
    for (let e = 0; e < 256; e++)
        qe[e] = ce(e) ? 1 : 0, Se[e] = ce(e);
    function Y(e, r) { this.input = e, this.filename = r.filename || null, this.schema = r.schema || O, this.onWarning = r.onWarning || null, this.legacy = r.legacy || !1, this.json = r.json || !1, this.listener = r.listener || null, this.maxDepth = typeof r.maxDepth == "number" ? r.maxDepth : 100, this.maxTotalMergeKeys = typeof r.maxTotalMergeKeys == "number" ? r.maxTotalMergeKeys : 1e4, this.implicitTypes = this.schema.compiledImplicit, this.typeMap = this.schema.compiledTypeMap, this.length = e.length, this.position = 0, this.line = 0, this.lineStart = 0, this.lineIndent = 0, this.depth = 0, this.totalMergeKeys = 0, this.firstTabInLine = -1, this.documents = [], this.anchorMapTransactions = []; }
    i(Y, "State");
    function Ce(e, r) { let c = { name: e.filename, buffer: e.input.slice(0, -1), position: e.position, line: e.line, column: e.position - e.lineStart }; return c.snippet = _(c), new E(r, c); }
    i(Ce, "generateError");
    function I(e, r) { throw Ce(e, r); }
    i(I, "throwError");
    function ee(e, r) { e.onWarning && e.onWarning.call(null, Ce(e, r)); }
    i(ee, "throwWarning");
    function G(e, r, c) { let s = e.anchorMapTransactions; if (s.length !== 0) {
        let t = s[s.length - 1];
        h.call(t, r) || (t[r] = { existed: h.call(e.anchorMap, r), value: e.anchorMap[r] });
    } e.anchorMap[r] = c; }
    i(G, "storeAnchor");
    function Fe(e) { e.anchorMapTransactions.push(Object.create(null)); }
    i(Fe, "beginAnchorTransaction");
    function ne(e) { let r = e.anchorMapTransactions.pop(), c = e.anchorMapTransactions; if (c.length === 0)
        return; let s = c[c.length - 1], t = Object.keys(r); for (let S = 0, n = t.length; S < n; S += 1) {
        let l = t[S];
        h.call(s, l) || (s[l] = r[l]);
    } }
    i(ne, "commitAnchorTransaction");
    function Te(e) { let r = e.anchorMapTransactions.pop(), c = Object.keys(r); for (let s = c.length - 1; s >= 0; s -= 1) {
        let t = r[c[s]];
        t.existed ? e.anchorMap[c[s]] = t.value : delete e.anchorMap[c[s]];
    } }
    i(Te, "rollbackAnchorTransaction");
    function te(e) { return { position: e.position, line: e.line, lineStart: e.lineStart, lineIndent: e.lineIndent, firstTabInLine: e.firstTabInLine, tag: e.tag, anchor: e.anchor, kind: e.kind, result: e.result }; }
    i(te, "snapshotState");
    function ie(e, r) { e.position = r.position, e.line = r.line, e.lineStart = r.lineStart, e.lineIndent = r.lineIndent, e.firstTabInLine = r.firstTabInLine, e.tag = r.tag, e.anchor = r.anchor, e.kind = r.kind, e.result = r.result; }
    i(ie, "restoreState");
    let we = { YAML: i(function (r, c, s) { r.version !== null && I(r, "duplication of %YAML directive"), s.length !== 1 && I(r, "YAML directive accepts exactly one argument"); let t = /^([0-9]+)\.([0-9]+)$/.exec(s[0]); t === null && I(r, "ill-formed argument of the YAML directive"); let S = parseInt(t[1], 10), n = parseInt(t[2], 10); S !== 1 && I(r, "unacceptable YAML version of the document"), r.version = s[0], r.checkLineBreaks = n < 2, n !== 1 && n !== 2 && ee(r, "unsupported YAML version of the document"); }, "handleYamlDirective"), TAG: i(function (r, c, s) { let t; s.length !== 2 && I(r, "TAG directive accepts exactly two arguments"); let S = s[0]; t = s[1], F.test(S) || I(r, "ill-formed tag handle (first argument) of the TAG directive"), h.call(r.tagMap, S) && I(r, 'there is a previously declared suffix for "' + S + '" tag handle'), K.test(t) || I(r, "ill-formed tag prefix (second argument) of the TAG directive"); try {
            t = decodeURIComponent(t);
        }
        catch {
            I(r, "tag prefix is malformed: " + t);
        } r.tagMap[S] = t; }, "handleTagDirective") };
    function U(e, r, c, s) { if (r < c) {
        let t = e.input.slice(r, c);
        if (s)
            for (let S = 0, n = t.length; S < n; S += 1) {
                let l = t.charCodeAt(S);
                l === 9 || l >= 32 && l <= 1114111 || I(e, "expected valid JSON character");
            }
        else
            v.test(t) && I(e, "the stream contains non-printable characters");
        e.result += t;
    } }
    i(U, "captureSegment");
    function J(e, r, c, s) { w.isObject(c) || I(e, "cannot merge mappings; the provided source object is unacceptable"); let t = Object.keys(c); for (let S = 0, n = t.length; S < n; S += 1) {
        let l = t[S];
        e.maxTotalMergeKeys !== -1 && ++e.totalMergeKeys > e.maxTotalMergeKeys && I(e, "merge keys exceeded maxTotalMergeKeys (" + e.maxTotalMergeKeys + ")"), h.call(r, l) || (ue(r, l, c[l]), s[l] = !0);
    } }
    i(J, "mergeMappings");
    function W(e, r, c, s, t, S, n, l, g) { if (Array.isArray(t)) {
        t = Array.prototype.slice.call(t);
        for (let f = 0, a = t.length; f < a; f += 1)
            Array.isArray(t[f]) && I(e, "nested arrays are not supported inside keys"), typeof t == "object" && z(t[f]) === "[object Object]" && (t[f] = "[object Object]");
    } if (typeof t == "object" && z(t) === "[object Object]" && (t = "[object Object]"), t = String(t), r === null && (r = {}), s === "tag:yaml.org,2002:merge")
        if (Array.isArray(S))
            for (let f = 0, a = S.length; f < a; f += 1)
                J(e, r, S[f], c);
        else
            J(e, r, S, c);
    else
        !e.json && !h.call(c, t) && h.call(r, t) && (e.line = n || e.line, e.lineStart = l || e.lineStart, e.position = g || e.position, I(e, "duplicated mapping key")), ue(r, t, S), delete c[t]; return r; }
    i(W, "storeMappingPair");
    function re(e) { let r = e.input.charCodeAt(e.position); r === 10 ? e.position++ : r === 13 ? (e.position++, e.input.charCodeAt(e.position) === 10 && e.position++) : I(e, "a line break is expected"), e.line += 1, e.lineStart = e.position, e.firstTabInLine = -1; }
    i(re, "readLineBreak");
    function q(e, r, c) { let s = 0, t = e.input.charCodeAt(e.position); for (; t !== 0;) {
        for (; j(t);)
            t === 9 && e.firstTabInLine === -1 && (e.firstTabInLine = e.position), t = e.input.charCodeAt(++e.position);
        if (r && t === 35)
            do
                t = e.input.charCodeAt(++e.position);
            while (t !== 10 && t !== 13 && t !== 0);
        if (H(t))
            for (re(e), t = e.input.charCodeAt(e.position), s++, e.lineIndent = 0; t === 32;)
                e.lineIndent++, t = e.input.charCodeAt(++e.position);
        else
            break;
    } return c !== -1 && s !== 0 && e.lineIndent < c && ee(e, "deficient indentation"), s; }
    i(q, "skipSeparationSpace");
    function le(e) { let r = e.position, c = e.input.charCodeAt(r); return !!((c === 45 || c === 46) && c === e.input.charCodeAt(r + 1) && c === e.input.charCodeAt(r + 2) && (r += 3, c = e.input.charCodeAt(r), c === 0 || P(c))); }
    i(le, "testDocumentSeparator");
    function Q(e, r) {
        r === 1 ? e.result += " " : r > 1 && (e.result += w.repeat(`
`, r - 1));
    }
    i(Q, "writeFoldedLines");
    function fe(e, r, c) { let s, t, S, n, l, g, f = e.kind, a = e.result, A = e.input.charCodeAt(e.position); if (P(A) || $(A) || A === 35 || A === 38 || A === 42 || A === 33 || A === 124 || A === 62 || A === 39 || A === 34 || A === 37 || A === 64 || A === 96)
        return !1; if (A === 63 || A === 45) {
        let m = e.input.charCodeAt(e.position + 1);
        if (P(m) || c && $(m))
            return !1;
    } for (e.kind = "scalar", e.result = "", s = t = e.position, S = !1; A !== 0;) {
        if (A === 58) {
            let m = e.input.charCodeAt(e.position + 1);
            if (P(m) || c && $(m))
                break;
        }
        else if (A === 35) {
            let m = e.input.charCodeAt(e.position - 1);
            if (P(m))
                break;
        }
        else {
            if (e.position === e.lineStart && le(e) || c && $(A))
                break;
            if (H(A))
                if (n = e.line, l = e.lineStart, g = e.lineIndent, q(e, !1, -1), e.lineIndent >= r) {
                    S = !0, A = e.input.charCodeAt(e.position);
                    continue;
                }
                else {
                    e.position = t, e.line = n, e.lineStart = l, e.lineIndent = g;
                    break;
                }
        }
        S && (U(e, s, t, !1), Q(e, e.line - n), s = t = e.position, S = !1), j(A) || (t = e.position + 1), A = e.input.charCodeAt(++e.position);
    } return U(e, s, t, !1), e.result ? !0 : (e.kind = f, e.result = a, !1); }
    i(fe, "readPlainScalar");
    function xe(e, r) { let c, s, t = e.input.charCodeAt(e.position); if (t !== 39)
        return !1; for (e.kind = "scalar", e.result = "", e.position++, c = s = e.position; (t = e.input.charCodeAt(e.position)) !== 0;)
        if (t === 39)
            if (U(e, c, e.position, !0), t = e.input.charCodeAt(++e.position), t === 39)
                c = e.position, e.position++, s = e.position;
            else
                return !0;
        else
            H(t) ? (U(e, c, s, !0), Q(e, q(e, !1, r)), c = s = e.position) : e.position === e.lineStart && le(e) ? I(e, "unexpected end of the document within a single quoted scalar") : (e.position++, j(t) || (s = e.position)); I(e, "unexpected end of the stream within a single quoted scalar"); }
    i(xe, "readSingleQuotedScalar");
    function ae(e, r) { let c, s, t, S = e.input.charCodeAt(e.position); if (S !== 34)
        return !1; for (e.kind = "scalar", e.result = "", e.position++, c = s = e.position; (S = e.input.charCodeAt(e.position)) !== 0;) {
        if (S === 34)
            return U(e, c, e.position, !0), e.position++, !0;
        if (S === 92) {
            if (U(e, c, e.position, !0), S = e.input.charCodeAt(++e.position), H(S))
                q(e, !1, r);
            else if (S < 256 && qe[S])
                e.result += Se[S], e.position++;
            else if ((t = Me(S)) > 0) {
                let n = t, l = 0;
                for (; n > 0; n--)
                    S = e.input.charCodeAt(++e.position), (t = Ne(S)) >= 0 ? l = (l << 4) + t : I(e, "expected hexadecimal character");
                e.result += Re(l), e.position++;
            }
            else
                I(e, "unknown escape sequence");
            c = s = e.position;
        }
        else
            H(S) ? (U(e, c, s, !0), Q(e, q(e, !1, r)), c = s = e.position) : e.position === e.lineStart && le(e) ? I(e, "unexpected end of the document within a double quoted scalar") : (e.position++, j(S) || (s = e.position));
    } I(e, "unexpected end of the stream within a double quoted scalar"); }
    i(ae, "readDoubleQuotedScalar");
    function be(e, r) { let c = !0, s, t, S, n = e.tag, l, g = e.anchor, f, a, A, m, b = Object.create(null), x, k, L, N = e.input.charCodeAt(e.position); if (N === 91)
        f = 93, m = !1, l = [];
    else if (N === 123)
        f = 125, m = !0, l = {};
    else
        return !1; for (e.anchor !== null && G(e, e.anchor, l), N = e.input.charCodeAt(++e.position); N !== 0;) {
        if (q(e, !0, r), N = e.input.charCodeAt(e.position), N === f)
            return e.position++, e.tag = n, e.anchor = g, e.kind = m ? "mapping" : "sequence", e.result = l, !0;
        if (c ? N === 44 && I(e, "expected the node content, but found ','") : I(e, "missed comma between flow collection entries"), k = x = L = null, a = A = !1, N === 63) {
            let R = e.input.charCodeAt(e.position + 1);
            P(R) && (a = A = !0, e.position++, q(e, !0, r));
        }
        s = e.line, t = e.lineStart, S = e.position, V(e, r, y, !1, !0), k = e.tag, x = e.result, q(e, !0, r), N = e.input.charCodeAt(e.position), (A || e.line === s) && N === 58 && (a = !0, N = e.input.charCodeAt(++e.position), q(e, !0, r), V(e, r, y, !1, !0), L = e.result), m ? W(e, l, b, k, x, L, s, t, S) : a ? l.push(W(e, null, b, k, x, L, s, t, S)) : l.push(x), q(e, !0, r), N = e.input.charCodeAt(e.position), N === 44 ? (c = !0, N = e.input.charCodeAt(++e.position)) : c = !1;
    } I(e, "unexpected end of the stream within a flow collection"); }
    i(be, "readFlowCollection");
    function Ee(e, r) {
        let c, s = o, t = !1, S = !1, n = r, l = 0, g = !1, f, a = e.input.charCodeAt(e.position);
        if (a === 124)
            c = !1;
        else if (a === 62)
            c = !0;
        else
            return !1;
        for (e.kind = "scalar", e.result = ""; a !== 0;)
            if (a = e.input.charCodeAt(++e.position), a === 43 || a === 45)
                o === s ? s = a === 43 ? T : u : I(e, "repeat of a chomping mode identifier");
            else if ((f = ye(a)) >= 0)
                f === 0 ? I(e, "bad explicit indentation width of a block scalar; it cannot be less than one") : S ? I(e, "repeat of an indentation width identifier") : (n = r + f - 1, S = !0);
            else
                break;
        if (j(a)) {
            do
                a = e.input.charCodeAt(++e.position);
            while (j(a));
            if (a === 35)
                do
                    a = e.input.charCodeAt(++e.position);
                while (!H(a) && a !== 0);
        }
        for (; a !== 0;) {
            for (re(e), e.lineIndent = 0, a = e.input.charCodeAt(e.position); (!S || e.lineIndent < n) && a === 32;)
                e.lineIndent++, a = e.input.charCodeAt(++e.position);
            if (!S && e.lineIndent > n && (n = e.lineIndent), H(a)) {
                l++;
                continue;
            }
            if (!S && n === 0 && I(e, "missing indentation for block scalar"), e.lineIndent < n) {
                s === T ? e.result += w.repeat(`
`, t ? 1 + l : l) : s === o && t && (e.result += `
`);
                break;
            }
            c ? j(a) ? (g = !0, e.result += w.repeat(`
`, t ? 1 + l : l)) : g ? (g = !1, e.result += w.repeat(`
`, l + 1)) : l === 0 ? t && (e.result += " ") : e.result += w.repeat(`
`, l) : e.result += w.repeat(`
`, t ? 1 + l : l), t = !0, S = !0, l = 0;
            let A = e.position;
            for (; !H(a) && a !== 0;)
                a = e.input.charCodeAt(++e.position);
            U(e, A, e.position, !1);
        }
        return !0;
    }
    i(Ee, "readBlockScalar");
    function X(e, r) { let c = e.tag, s = e.anchor, t = [], S = !1; if (e.firstTabInLine !== -1)
        return !1; e.anchor !== null && G(e, e.anchor, t); let n = e.input.charCodeAt(e.position); for (; n !== 0 && (e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, I(e, "tab characters must not be used in indentation")), n === 45);) {
        let l = e.input.charCodeAt(e.position + 1);
        if (!P(l))
            break;
        if (S = !0, e.position++, q(e, !0, -1) && e.lineIndent <= r) {
            t.push(null), n = e.input.charCodeAt(e.position);
            continue;
        }
        let g = e.line;
        if (V(e, r, p, !1, !0), t.push(e.result), q(e, !0, -1), n = e.input.charCodeAt(e.position), (e.line === g || e.lineIndent > r) && n !== 0)
            I(e, "bad indentation of a sequence entry");
        else if (e.lineIndent < r)
            break;
    } return S ? (e.tag = c, e.anchor = s, e.kind = "sequence", e.result = t, !0) : !1; }
    i(X, "readBlockSequence");
    function pe(e, r, c) { let s, t, S, n, l = e.tag, g = e.anchor, f = {}, a = Object.create(null), A = null, m = null, b = null, x = !1, k = !1; if (e.firstTabInLine !== -1)
        return !1; e.anchor !== null && G(e, e.anchor, f); let L = e.input.charCodeAt(e.position); for (; L !== 0;) {
        !x && e.firstTabInLine !== -1 && (e.position = e.firstTabInLine, I(e, "tab characters must not be used in indentation"));
        let N = e.input.charCodeAt(e.position + 1), R = e.line;
        if ((L === 63 || L === 58) && P(N))
            L === 63 ? (x && (W(e, f, a, A, m, null, t, S, n), A = m = b = null), k = !0, x = !0, s = !0) : x ? (x = !1, s = !0) : I(e, "incomplete explicit mapping pair; a key node is missed; or followed by a non-tabulated empty line"), e.position += 1, L = N;
        else {
            if (t = e.line, S = e.lineStart, n = e.position, !V(e, c, d, !1, !0))
                break;
            if (e.line === R) {
                for (L = e.input.charCodeAt(e.position); j(L);)
                    L = e.input.charCodeAt(++e.position);
                if (L === 58)
                    L = e.input.charCodeAt(++e.position), P(L) || I(e, "a whitespace character is expected after the key-value separator within a block mapping"), x && (W(e, f, a, A, m, null, t, S, n), A = m = b = null), k = !0, x = !1, s = !1, A = e.tag, m = e.result;
                else if (k)
                    I(e, "can not read an implicit mapping pair; a colon is missed");
                else
                    return e.tag = l, e.anchor = g, !0;
            }
            else if (k)
                I(e, "can not read a block mapping entry; a multiline key may not be an implicit key");
            else
                return e.tag = l, e.anchor = g, !0;
        }
        if ((e.line === R || e.lineIndent > r) && (x && (t = e.line, S = e.lineStart, n = e.position), V(e, r, C, !0, s) && (x ? m = e.result : b = e.result), x || (W(e, f, a, A, m, b, t, S, n), A = m = b = null), q(e, !0, -1), L = e.input.charCodeAt(e.position)), (e.line === R || e.lineIndent > r) && L !== 0)
            I(e, "bad indentation of a mapping entry");
        else if (e.lineIndent < r)
            break;
    } return x && W(e, f, a, A, m, null, t, S, n), k && (e.tag = l, e.anchor = g, e.kind = "mapping", e.result = f), k; }
    i(pe, "readBlockMapping");
    function _e(e) { let r = !1, c = !1, s, t, S = e.input.charCodeAt(e.position); if (S !== 33)
        return !1; e.tag !== null && I(e, "duplication of a tag property"), S = e.input.charCodeAt(++e.position), S === 60 ? (r = !0, S = e.input.charCodeAt(++e.position)) : S === 33 ? (c = !0, s = "!!", S = e.input.charCodeAt(++e.position)) : s = "!"; let n = e.position; if (r) {
        do
            S = e.input.charCodeAt(++e.position);
        while (S !== 0 && S !== 62);
        e.position < e.length ? (t = e.input.slice(n, e.position), S = e.input.charCodeAt(++e.position)) : I(e, "unexpected end of the stream within a verbatim tag");
    }
    else {
        for (; S !== 0 && !P(S);)
            S === 33 && (c ? I(e, "tag suffix cannot contain exclamation marks") : (s = e.input.slice(n - 1, e.position + 1), F.test(s) || I(e, "named tag handle cannot contain such characters"), c = !0, n = e.position + 1)), S = e.input.charCodeAt(++e.position);
        t = e.input.slice(n, e.position), Z.test(t) && I(e, "tag suffix cannot contain flow indicator characters");
    } t && !K.test(t) && I(e, "tag name cannot contain such characters: " + t); try {
        t = decodeURIComponent(t);
    }
    catch {
        I(e, "tag name is malformed: " + t);
    } return r ? e.tag = t : h.call(e.tagMap, s) ? e.tag = e.tagMap[s] + t : s === "!" ? e.tag = "!" + t : s === "!!" ? e.tag = "tag:yaml.org,2002:" + t : I(e, 'undeclared tag handle "' + s + '"'), !0; }
    i(_e, "readTagProperty");
    function se(e) { let r = e.input.charCodeAt(e.position); if (r !== 38)
        return !1; e.anchor !== null && I(e, "duplication of an anchor property"), r = e.input.charCodeAt(++e.position); let c = e.position; for (; r !== 0 && !P(r) && !$(r);)
        r = e.input.charCodeAt(++e.position); return e.position === c && I(e, "name of an anchor node must contain at least one character"), e.anchor = e.input.slice(c, e.position), !0; }
    i(se, "readAnchorProperty");
    function he(e) { let r = e.input.charCodeAt(e.position); if (r !== 42)
        return !1; r = e.input.charCodeAt(++e.position); let c = e.position; for (; r !== 0 && !P(r) && !$(r);)
        r = e.input.charCodeAt(++e.position); e.position === c && I(e, "name of an alias node must contain at least one character"); let s = e.input.slice(c, e.position); return h.call(e.anchorMap, s) || I(e, 'unidentified alias "' + s + '"'), e.result = e.anchorMap[s], q(e, !0, -1), !0; }
    i(he, "readAlias");
    function Ie(e, r, c, s) { let t = te(e); return Fe(e), ie(e, r), e.tag = null, e.anchor = null, e.kind = null, e.result = null, pe(e, c, s) && e.kind === "mapping" ? (ne(e), !0) : (Te(e), ie(e, t), !1); }
    i(Ie, "tryReadBlockMappingFromProperty");
    function V(e, r, c, s, t) { let S, n, l = 1, g = !1, f = !1, a = null, A, m, b; e.depth >= e.maxDepth && I(e, "nesting exceeded maxDepth (" + e.maxDepth + ")"), e.depth += 1, e.listener !== null && e.listener("open", e), e.tag = null, e.anchor = null, e.kind = null, e.result = null; let x = S = n = C === c || p === c; if (s && q(e, !0, -1) && (g = !0, e.lineIndent > r ? l = 1 : e.lineIndent === r ? l = 0 : e.lineIndent < r && (l = -1)), l === 1)
        for (;;) {
            let k = e.input.charCodeAt(e.position), L = te(e);
            if (g && (k === 33 && e.tag !== null || k === 38 && e.anchor !== null) || !_e(e) && !se(e))
                break;
            a === null && (a = L), q(e, !0, -1) ? (g = !0, n = x, e.lineIndent > r ? l = 1 : e.lineIndent === r ? l = 0 : e.lineIndent < r && (l = -1)) : n = !1;
        } if (n && (n = g || t), l === 1 || C === c)
        if (y === c || d === c ? m = r : m = r + 1, b = e.position - e.lineStart, l === 1)
            if (n && (X(e, b) || pe(e, b, m)) || be(e, m))
                f = !0;
            else {
                let k = e.input.charCodeAt(e.position);
                a !== null && x && !n && k !== 124 && k !== 62 && Ie(e, a, a.position - a.lineStart, m) || S && Ee(e, m) || xe(e, m) || ae(e, m) ? f = !0 : he(e) ? (f = !0, (e.tag !== null || e.anchor !== null) && I(e, "alias node should not have any properties")) : fe(e, m, y === c) && (f = !0, e.tag === null && (e.tag = "?")), e.anchor !== null && G(e, e.anchor, e.result);
            }
        else
            l === 0 && (f = n && X(e, b)); if (e.tag === null)
        e.anchor !== null && G(e, e.anchor, e.result);
    else if (e.tag === "?") {
        e.result !== null && e.kind !== "scalar" && I(e, 'unacceptable node kind for !<?> tag; it should be "scalar", not "' + e.kind + '"');
        for (let k = 0, L = e.implicitTypes.length; k < L; k += 1)
            if (A = e.implicitTypes[k], A.resolve(e.result)) {
                e.result = A.construct(e.result), e.tag = A.tag, e.anchor !== null && G(e, e.anchor, e.result);
                break;
            }
    }
    else if (e.tag !== "!") {
        if (h.call(e.typeMap[e.kind || "fallback"], e.tag))
            A = e.typeMap[e.kind || "fallback"][e.tag];
        else {
            A = null;
            let k = e.typeMap.multi[e.kind || "fallback"];
            for (let L = 0, N = k.length; L < N; L += 1)
                if (e.tag.slice(0, k[L].tag.length) === k[L].tag) {
                    A = k[L];
                    break;
                }
        }
        A || I(e, "unknown tag !<" + e.tag + ">"), e.result !== null && A.kind !== e.kind && I(e, "unacceptable node kind for !<" + e.tag + '> tag; it should be "' + A.kind + '", not "' + e.kind + '"'), A.resolve(e.result, e.tag) ? (e.result = A.construct(e.result, e.tag), e.anchor !== null && G(e, e.anchor, e.result)) : I(e, "cannot resolve a node with !<" + e.tag + "> explicit tag");
    } return e.listener !== null && e.listener("close", e), e.depth -= 1, e.tag !== null || e.anchor !== null || f; }
    i(V, "composeNode");
    function ke(e) { let r = e.position, c = !1, s; for (e.version = null, e.checkLineBreaks = e.legacy, e.tagMap = Object.create(null), e.anchorMap = Object.create(null); (s = e.input.charCodeAt(e.position)) !== 0 && (q(e, !0, -1), s = e.input.charCodeAt(e.position), !(e.lineIndent > 0 || s !== 37));) {
        c = !0, s = e.input.charCodeAt(++e.position);
        let t = e.position;
        for (; s !== 0 && !P(s);)
            s = e.input.charCodeAt(++e.position);
        let S = e.input.slice(t, e.position), n = [];
        for (S.length < 1 && I(e, "directive name must not be less than one character in length"); s !== 0;) {
            for (; j(s);)
                s = e.input.charCodeAt(++e.position);
            if (s === 35) {
                do
                    s = e.input.charCodeAt(++e.position);
                while (s !== 0 && !H(s));
                break;
            }
            if (H(s))
                break;
            for (t = e.position; s !== 0 && !P(s);)
                s = e.input.charCodeAt(++e.position);
            n.push(e.input.slice(t, e.position));
        }
        s !== 0 && re(e), h.call(we, S) ? we[S](e, S, n) : ee(e, 'unknown document directive "' + S + '"');
    } if (q(e, !0, -1), e.lineIndent === 0 && e.input.charCodeAt(e.position) === 45 && e.input.charCodeAt(e.position + 1) === 45 && e.input.charCodeAt(e.position + 2) === 45 ? (e.position += 3, q(e, !0, -1)) : c && I(e, "directives end mark is expected"), V(e, e.lineIndent - 1, C, !1, !0), q(e, !0, -1), e.checkLineBreaks && M.test(e.input.slice(r, e.position)) && ee(e, "non-ASCII line breaks are interpreted as content"), e.documents.push(e.result), e.position === e.lineStart && le(e)) {
        e.input.charCodeAt(e.position) === 46 && (e.position += 3, q(e, !0, -1));
        return;
    } e.position < e.length - 1 && I(e, "end of the stream or a document separator is expected"); }
    i(ke, "readDocument");
    function de(e, r) {
        e = String(e), r = r || {}, e.length !== 0 && (e.charCodeAt(e.length - 1) !== 10 && e.charCodeAt(e.length - 1) !== 13 && (e += `
`), e.charCodeAt(0) === 65279 && (e = e.slice(1)));
        let c = new Y(e, r), s = e.indexOf("\0");
        for (s !== -1 && (c.position = s, I(c, "null byte is not allowed in input")), c.input += "\0"; c.input.charCodeAt(c.position) === 32;)
            c.lineIndent += 1, c.position += 1;
        for (; c.position < c.length - 1;)
            ke(c);
        return c.documents;
    }
    i(de, "loadDocuments");
    function me(e, r, c) { r !== null && typeof r == "object" && typeof c > "u" && (c = r, r = null); let s = de(e, c); if (typeof r != "function")
        return s; for (let t = 0, S = s.length; t < S; t += 1)
        r(s[t]); }
    i(me, "loadAll2");
    function Le(e, r) { let c = de(e, r); if (c.length !== 0) {
        if (c.length === 1)
            return c[0];
        throw new E("expected a single document in the stream, but found more");
    } }
    return i(Le, "load2"), Ye.loadAll = me, Ye.load = Le, Ye;
}
i(zn, "requireLoader");
var cn = {}, Jn;
function ei() {
    if (Jn)
        return cn;
    Jn = 1;
    let w = ge(), E = Ae(), _ = Pe(), O = Object.prototype.toString, h = Object.prototype.hasOwnProperty, y = 65279, d = 9, p = 10, C = 13, o = 32, u = 33, T = 34, v = 35, M = 37, Z = 38, F = 39, K = 42, z = 44, H = 45, j = 58, P = 61, $ = 62, Ne = 63, Me = 64, ye = 91, ce = 93, Re = 96, ue = 123, qe = 124, Se = 125, Y = {};
    Y[0] = "\\0", Y[7] = "\\a", Y[8] = "\\b", Y[9] = "\\t", Y[10] = "\\n", Y[11] = "\\v", Y[12] = "\\f", Y[13] = "\\r", Y[27] = "\\e", Y[34] = '\\"', Y[92] = "\\\\", Y[133] = "\\N", Y[160] = "\\_", Y[8232] = "\\L", Y[8233] = "\\P";
    let Ce = ["y", "Y", "yes", "Yes", "YES", "on", "On", "ON", "n", "N", "no", "No", "NO", "off", "Off", "OFF"], I = /^[-+]?[0-9_]+(?::[0-9_]+)+(?:\.[0-9_]*)?$/;
    function ee(n, l) { if (l === null)
        return {}; let g = {}, f = Object.keys(l); for (let a = 0, A = f.length; a < A; a += 1) {
        let m = f[a], b = String(l[m]);
        m.slice(0, 2) === "!!" && (m = "tag:yaml.org,2002:" + m.slice(2));
        let x = n.compiledTypeMap.fallback[m];
        x && h.call(x.styleAliases, b) && (b = x.styleAliases[b]), g[m] = b;
    } return g; }
    i(ee, "compileStyleMap");
    function G(n) { let l, g, f = n.toString(16).toUpperCase(); if (n <= 255)
        l = "x", g = 2;
    else if (n <= 65535)
        l = "u", g = 4;
    else if (n <= 4294967295)
        l = "U", g = 8;
    else
        throw new E("code point within a string may not be greater than 0xFFFFFFFF"); return "\\" + l + w.repeat("0", g - f.length) + f; }
    i(G, "encodeHex");
    let Fe = 1, ne = 2;
    function Te(n) { this.schema = n.schema || _, this.indent = Math.max(1, n.indent || 2), this.noArrayIndent = n.noArrayIndent || !1, this.skipInvalid = n.skipInvalid || !1, this.flowLevel = w.isNothing(n.flowLevel) ? -1 : n.flowLevel, this.styleMap = ee(this.schema, n.styles || null), this.sortKeys = n.sortKeys || !1, this.lineWidth = n.lineWidth || 80, this.noRefs = n.noRefs || !1, this.noCompatMode = n.noCompatMode || !1, this.condenseFlow = n.condenseFlow || !1, this.quotingType = n.quotingType === '"' ? ne : Fe, this.forceQuotes = n.forceQuotes || !1, this.replacer = typeof n.replacer == "function" ? n.replacer : null, this.implicitTypes = this.schema.compiledImplicit, this.explicitTypes = this.schema.compiledExplicit, this.tag = null, this.result = "", this.duplicates = [], this.usedDuplicates = null; }
    i(Te, "State");
    function te(n, l) {
        let g = w.repeat(" ", l), f = 0, a = "", A = n.length;
        for (; f < A;) {
            let m, b = n.indexOf(`
`, f);
            b === -1 ? (m = n.slice(f), f = A) : (m = n.slice(f, b + 1), f = b + 1), m.length && m !== `
` && (a += g), a += m;
        }
        return a;
    }
    i(te, "indentString");
    function ie(n, l) {
        return `
` + w.repeat(" ", n.indent * l);
    }
    i(ie, "generateNextLine");
    function we(n, l) { for (let g = 0, f = n.implicitTypes.length; g < f; g += 1)
        if (n.implicitTypes[g].resolve(l))
            return !0; return !1; }
    i(we, "testImplicitResolving");
    function U(n) { return n === o || n === d; }
    i(U, "isWhitespace");
    function J(n) { return n >= 32 && n <= 126 || n >= 161 && n <= 55295 && n !== 8232 && n !== 8233 || n >= 57344 && n <= 65533 && n !== y || n >= 65536 && n <= 1114111; }
    i(J, "isPrintable");
    function W(n) { return J(n) && n !== y && n !== C && n !== p; }
    i(W, "isNsCharOrWhitespace");
    function re(n, l, g) { let f = W(n), a = f && !U(n); return (g ? f : f && n !== z && n !== ye && n !== ce && n !== ue && n !== Se) && n !== v && !(l === j && !a) || W(l) && !U(l) && n === v || l === j && a; }
    i(re, "isPlainSafe");
    function q(n) { return J(n) && n !== y && !U(n) && n !== H && n !== Ne && n !== j && n !== z && n !== ye && n !== ce && n !== ue && n !== Se && n !== v && n !== Z && n !== K && n !== u && n !== qe && n !== P && n !== $ && n !== F && n !== T && n !== M && n !== Me && n !== Re; }
    i(q, "isPlainSafeFirst");
    function le(n) { return !U(n) && n !== j; }
    i(le, "isPlainSafeLast");
    function Q(n, l) { let g = n.charCodeAt(l), f; return g >= 55296 && g <= 56319 && l + 1 < n.length && (f = n.charCodeAt(l + 1), f >= 56320 && f <= 57343) ? (g - 55296) * 1024 + f - 56320 + 65536 : g; }
    i(Q, "codePointAt");
    function fe(n) { return /^\n* /.test(n); }
    i(fe, "needIndentIndicator");
    let xe = 1, ae = 2, be = 3, Ee = 4, X = 5;
    function pe(n, l, g, f, a, A, m, b) { let x, k = 0, L = null, N = !1, R = !1, En = f !== -1, Oe = -1, ve = q(Q(n, 0)) && le(Q(n, n.length - 1)); if (l || m)
        for (x = 0; x < n.length; k >= 65536 ? x += 2 : x++) {
            if (k = Q(n, x), !J(k))
                return X;
            ve = ve && re(k, L, b), L = k;
        }
    else {
        for (x = 0; x < n.length; k >= 65536 ? x += 2 : x++) {
            if (k = Q(n, x), k === p)
                N = !0, En && (R = R || x - Oe - 1 > f && n[Oe + 1] !== " ", Oe = x);
            else if (!J(k))
                return X;
            ve = ve && re(k, L, b), L = k;
        }
        R = R || En && x - Oe - 1 > f && n[Oe + 1] !== " ";
    } return !N && !R ? ve && !m && !a(n) ? xe : A === ne ? X : ae : g > 9 && fe(n) ? X : m ? A === ne ? X : ae : R ? Ee : be; }
    i(pe, "chooseScalarStyle");
    function _e(n, l, g, f, a) { n.dump = (function () { if (l.length === 0)
        return n.quotingType === ne ? '""' : "''"; if (!n.noCompatMode && (Ce.indexOf(l) !== -1 || I.test(l)))
        return n.quotingType === ne ? '"' + l + '"' : "'" + l + "'"; let A = n.indent * Math.max(1, g), m = n.lineWidth === -1 ? -1 : Math.max(Math.min(n.lineWidth, 40), n.lineWidth - A), b = f || n.flowLevel > -1 && g >= n.flowLevel; function x(k) { return we(n, k); } switch (i(x, "testAmbiguity"), pe(l, b, n.indent, m, x, n.quotingType, n.forceQuotes && !f, a)) {
        case xe: return l;
        case ae: return "'" + l.replace(/'/g, "''") + "'";
        case be: return "|" + se(l, n.indent) + he(te(l, A));
        case Ee: return ">" + se(l, n.indent) + he(te(Ie(l, m), A));
        case X: return '"' + ke(l) + '"';
        default: throw new E("impossible error: invalid scalar style");
    } })(); }
    i(_e, "writeScalar");
    function se(n, l) {
        let g = fe(n) ? String(l) : "", f = n[n.length - 1] === `
`, A = f && (n[n.length - 2] === `
` || n === `
`) ? "+" : f ? "" : "-";
        return g + A + `
`;
    }
    i(se, "blockHeader");
    function he(n) {
        return n[n.length - 1] === `
` ? n.slice(0, -1) : n;
    }
    i(he, "dropEndingNewline");
    function Ie(n, l) {
        let g = /(\n+)([^\n]*)/g, f = (function () {
            let b = n.indexOf(`
`);
            return b = b !== -1 ? b : n.length, g.lastIndex = b, V(n.slice(0, b), l);
        })(), a = n[0] === `
` || n[0] === " ", A, m;
        for (; m = g.exec(n);) {
            let b = m[1], x = m[2];
            A = x[0] === " ", f += b + (!a && !A && x !== "" ? `
` : "") + V(x, l), a = A;
        }
        return f;
    }
    i(Ie, "foldString");
    function V(n, l) {
        if (n === "" || n[0] === " ")
            return n;
        let g = / [^ ]/g, f, a = 0, A, m = 0, b = 0, x = "";
        for (; f = g.exec(n);)
            b = f.index, b - a > l && (A = m > a ? m : b, x += `
` + n.slice(a, A), a = A + 1), m = b;
        return x += `
`, n.length - a > l && m > a ? x += n.slice(a, m) + `
` + n.slice(m + 1) : x += n.slice(a), x.slice(1);
    }
    i(V, "foldLine");
    function ke(n) { let l = "", g = 0; for (let f = 0; f < n.length; g >= 65536 ? f += 2 : f++) {
        g = Q(n, f);
        let a = Y[g];
        !a && J(g) ? (l += n[f], g >= 65536 && (l += n[f + 1])) : l += a || G(g);
    } return l; }
    i(ke, "escapeString");
    function de(n, l, g) { let f = "", a = n.tag; for (let A = 0, m = g.length; A < m; A += 1) {
        let b = g[A];
        n.replacer && (b = n.replacer.call(g, String(A), b)), (c(n, l, b, !1, !1) || typeof b > "u" && c(n, l, null, !1, !1)) && (f !== "" && (f += "," + (n.condenseFlow ? "" : " ")), f += n.dump);
    } n.tag = a, n.dump = "[" + f + "]"; }
    i(de, "writeFlowSequence");
    function me(n, l, g, f) { let a = "", A = n.tag; for (let m = 0, b = g.length; m < b; m += 1) {
        let x = g[m];
        n.replacer && (x = n.replacer.call(g, String(m), x)), (c(n, l + 1, x, !0, !0, !1, !0) || typeof x > "u" && c(n, l + 1, null, !0, !0, !1, !0)) && ((!f || a !== "") && (a += ie(n, l)), n.dump && p === n.dump.charCodeAt(0) ? a += "-" : a += "- ", a += n.dump);
    } n.tag = A, n.dump = a || "[]"; }
    i(me, "writeBlockSequence");
    function Le(n, l, g) { let f = "", a = n.tag, A = Object.keys(g); for (let m = 0, b = A.length; m < b; m += 1) {
        let x = "";
        f !== "" && (x += ", "), n.condenseFlow && (x += '"');
        let k = A[m], L = g[k];
        n.replacer && (L = n.replacer.call(g, k, L)), c(n, l, k, !1, !1) && (n.dump.length > 1024 && (x += "? "), x += n.dump + (n.condenseFlow ? '"' : "") + ":" + (n.condenseFlow ? "" : " "), c(n, l, L, !1, !1) && (x += n.dump, f += x));
    } n.tag = a, n.dump = "{" + f + "}"; }
    i(Le, "writeFlowMapping");
    function e(n, l, g, f) { let a = "", A = n.tag, m = Object.keys(g); if (n.sortKeys === !0)
        m.sort();
    else if (typeof n.sortKeys == "function")
        m.sort(n.sortKeys);
    else if (n.sortKeys)
        throw new E("sortKeys must be a boolean or a function"); for (let b = 0, x = m.length; b < x; b += 1) {
        let k = "";
        (!f || a !== "") && (k += ie(n, l));
        let L = m[b], N = g[L];
        if (n.replacer && (N = n.replacer.call(g, L, N)), !c(n, l + 1, L, !0, !0, !0))
            continue;
        let R = n.tag !== null && n.tag !== "?" || n.dump && n.dump.length > 1024;
        R && (n.dump && p === n.dump.charCodeAt(0) ? k += "?" : k += "? "), k += n.dump, R && (k += ie(n, l)), c(n, l + 1, N, !0, R) && (n.dump && p === n.dump.charCodeAt(0) ? k += ":" : k += ": ", k += n.dump, a += k);
    } n.tag = A, n.dump = a || "{}"; }
    i(e, "writeBlockMapping");
    function r(n, l, g) { let f = g ? n.explicitTypes : n.implicitTypes; for (let a = 0, A = f.length; a < A; a += 1) {
        let m = f[a];
        if ((m.instanceOf || m.predicate) && (!m.instanceOf || typeof l == "object" && l instanceof m.instanceOf) && (!m.predicate || m.predicate(l))) {
            if (g ? m.multi && m.representName ? n.tag = m.representName(l) : n.tag = m.tag : n.tag = "?", m.represent) {
                let b = n.styleMap[m.tag] || m.defaultStyle, x;
                if (O.call(m.represent) === "[object Function]")
                    x = m.represent(l, b);
                else if (h.call(m.represent, b))
                    x = m.represent[b](l, b);
                else
                    throw new E("!<" + m.tag + '> tag resolver accepts not "' + b + '" style');
                n.dump = x;
            }
            return !0;
        }
    } return !1; }
    i(r, "detectType");
    function c(n, l, g, f, a, A, m) { n.tag = null, n.dump = g, r(n, g, !1) || r(n, g, !0); let b = O.call(n.dump), x = f; f && (f = n.flowLevel < 0 || n.flowLevel > l); let k = b === "[object Object]" || b === "[object Array]", L, N; if (k && (L = n.duplicates.indexOf(g), N = L !== -1), (n.tag !== null && n.tag !== "?" || N || n.indent !== 2 && l > 0) && (a = !1), N && n.usedDuplicates[L])
        n.dump = "*ref_" + L;
    else {
        if (k && N && !n.usedDuplicates[L] && (n.usedDuplicates[L] = !0), b === "[object Object]")
            f && Object.keys(n.dump).length !== 0 ? (e(n, l, n.dump, a), N && (n.dump = "&ref_" + L + n.dump)) : (Le(n, l, n.dump), N && (n.dump = "&ref_" + L + " " + n.dump));
        else if (b === "[object Array]")
            f && n.dump.length !== 0 ? (n.noArrayIndent && !m && l > 0 ? me(n, l - 1, n.dump, a) : me(n, l, n.dump, a), N && (n.dump = "&ref_" + L + n.dump)) : (de(n, l, n.dump), N && (n.dump = "&ref_" + L + " " + n.dump));
        else if (b === "[object String]")
            n.tag !== "?" && _e(n, n.dump, l, A, x);
        else {
            if (b === "[object Undefined]")
                return !1;
            if (n.skipInvalid)
                return !1;
            throw new E("unacceptable kind of an object to dump " + b);
        }
        if (n.tag !== null && n.tag !== "?") {
            let R = encodeURI(n.tag[0] === "!" ? n.tag.slice(1) : n.tag).replace(/!/g, "%21");
            n.tag[0] === "!" ? R = "!" + R : R.slice(0, 18) === "tag:yaml.org,2002:" ? R = "!!" + R.slice(18) : R = "!<" + R + ">", n.dump = R + " " + n.dump;
        }
    } return !0; }
    i(c, "writeNode");
    function s(n, l) { let g = [], f = []; t(n, g, f); let a = f.length; for (let A = 0; A < a; A += 1)
        l.duplicates.push(g[f[A]]); l.usedDuplicates = new Array(a); }
    i(s, "getDuplicateReferences");
    function t(n, l, g) { if (n !== null && typeof n == "object") {
        let f = l.indexOf(n);
        if (f !== -1)
            g.indexOf(f) === -1 && g.push(f);
        else if (l.push(n), Array.isArray(n))
            for (let a = 0, A = n.length; a < A; a += 1)
                t(n[a], l, g);
        else {
            let a = Object.keys(n);
            for (let A = 0, m = a.length; A < m; A += 1)
                t(n[a[A]], l, g);
        }
    } }
    i(t, "inspectNode");
    function S(n, l) {
        l = l || {};
        let g = new Te(l);
        g.noRefs || s(n, g);
        let f = n;
        return g.replacer && (f = g.replacer.call({ "": f }, "", f)), c(g, 0, f, !0, !0) ? g.dump + `
` : "";
    }
    return i(S, "dump2"), cn.dump = S, cn;
}
i(ei, "requireDumper");
var Xn;
function ni() { if (Xn)
    return D; Xn = 1; let w = zn(), E = ei(); function _(O, h) { return function () { throw new Error("Function yaml." + O + " is removed in js-yaml 4. Use yaml." + h + " instead, which is now safe by default."); }; } return i(_, "renamed"), D.Type = B(), D.Schema = un(), D.FAILSAFE_SCHEMA = sn(), D.JSON_SCHEMA = An(), D.CORE_SCHEMA = yn(), D.DEFAULT_SCHEMA = Pe(), D.load = w.load, D.loadAll = w.loadAll, D.dump = E.dump, D.YAMLException = Ae(), D.types = { binary: Tn(), float: gn(), map: pn(), null: hn(), pairs: xn(), set: bn(), timestamp: Sn(), bool: dn(), int: mn(), merge: Cn(), omap: wn(), seq: an(), str: fn() }, D.safeLoad = _("safeLoad", "load"), D.safeLoadAll = _("safeLoadAll", "loadAll"), D.safeDump = _("safeDump", "dump"), D; }
i(ni, "requireJsYaml");
var ii = ni(), ri = $n(ii), { Type: oi, Schema: ti, FAILSAFE_SCHEMA: ci, JSON_SCHEMA: ui, CORE_SCHEMA: fi, DEFAULT_SCHEMA: ai, load: pi, loadAll: si, dump: hi, YAMLException: di, types: mi, safeLoad: gi, safeLoadAll: Ai, safeDump: yi } = ri;
export { ui as a, pi as b };
