import { a as e, b as r } from "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { e as TreemapModule, r as createTreemapServices };
