import { _ as s } from "@nf-internal/chunk-LEJRRF65";
import { h as e } from "@nf-internal/chunk-RZWXGGKD";
import { a as n } from "@nf-internal/chunk-YUSHYV7C";
var a = n(t => { let { securityLevel: c } = s(), o = e("body"); if (c === "sandbox") {
    let m = e(`#i${t}`).node()?.contentDocument ?? document;
    o = e(m.body);
} return o.select(`#${t}`); }, "selectSvgElement");
export { a };
