import { a as Be } from "@nf-internal/chunk-QP3MATMC";
import { C as ze } from "@nf-internal/chunk-LUZVEH3G";
import { f as Te, g as ve, h as Ce, i as Oe } from "@nf-internal/chunk-ST43FWUC";
import { b as le, e as Ie } from "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { a as De, f as Ne } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { N as Ee, O as we, T as _e, _ as oe, a as me, b as ye, u as K } from "@nf-internal/chunk-LEJRRF65";
import { b as m, h as j } from "@nf-internal/chunk-RZWXGGKD";
import { a as c } from "@nf-internal/chunk-YUSHYV7C";
import { a as W, b as V, f as R } from "@nf-internal/chunk-OSQMNGTH";
var he = (function () {
    var e = c(function (C, u, r, a) { for (r = r || {}, a = C.length; a--; r[C[a]] = u)
        ; return r; }, "o"), o = [1, 15], l = [1, 7], n = [1, 13], h = [1, 14], p = [1, 19], s = [1, 16], g = [1, 17], x = [1, 18], k = [8, 30], S = [8, 10, 21, 28, 29, 30, 31, 39, 43, 46], b = [1, 23], L = [1, 24], E = [8, 10, 15, 16, 21, 28, 29, 30, 31, 39, 43, 46], f = [8, 10, 15, 16, 21, 27, 28, 29, 30, 31, 39, 43, 46], _ = [1, 49], w = { trace: c(function () { }, "trace"), yy: {}, symbols_: { error: 2, spaceLines: 3, SPACELINE: 4, NL: 5, separator: 6, SPACE: 7, EOF: 8, start: 9, BLOCK_DIAGRAM_KEY: 10, document: 11, stop: 12, statement: 13, link: 14, LINK: 15, START_LINK: 16, LINK_LABEL: 17, STR: 18, nodeStatement: 19, columnsStatement: 20, SPACE_BLOCK: 21, blockStatement: 22, classDefStatement: 23, cssClassStatement: 24, styleStatement: 25, node: 26, SIZE: 27, COLUMNS: 28, "id-block": 29, end: 30, NODE_ID: 31, nodeShapeNLabel: 32, dirList: 33, DIR: 34, NODE_DSTART: 35, NODE_DEND: 36, BLOCK_ARROW_START: 37, BLOCK_ARROW_END: 38, classDef: 39, CLASSDEF_ID: 40, CLASSDEF_STYLEOPTS: 41, DEFAULT: 42, class: 43, CLASSENTITY_IDS: 44, STYLECLASS: 45, style: 46, STYLE_ENTITY_IDS: 47, STYLE_DEFINITION_DATA: 48, $accept: 0, $end: 1 }, terminals_: { 2: "error", 4: "SPACELINE", 5: "NL", 7: "SPACE", 8: "EOF", 10: "BLOCK_DIAGRAM_KEY", 15: "LINK", 16: "START_LINK", 17: "LINK_LABEL", 18: "STR", 21: "SPACE_BLOCK", 27: "SIZE", 28: "COLUMNS", 29: "id-block", 30: "end", 31: "NODE_ID", 34: "DIR", 35: "NODE_DSTART", 36: "NODE_DEND", 37: "BLOCK_ARROW_START", 38: "BLOCK_ARROW_END", 39: "classDef", 40: "CLASSDEF_ID", 41: "CLASSDEF_STYLEOPTS", 42: "DEFAULT", 43: "class", 44: "CLASSENTITY_IDS", 45: "STYLECLASS", 46: "style", 47: "STYLE_ENTITY_IDS", 48: "STYLE_DEFINITION_DATA" }, productions_: [0, [3, 1], [3, 2], [3, 2], [6, 1], [6, 1], [6, 1], [9, 3], [12, 1], [12, 1], [12, 2], [12, 2], [11, 1], [11, 2], [14, 1], [14, 4], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [13, 1], [19, 3], [19, 2], [19, 1], [20, 1], [22, 4], [22, 3], [26, 1], [26, 2], [33, 1], [33, 2], [32, 3], [32, 4], [23, 3], [23, 3], [24, 3], [25, 3]], performAction: c(function (u, r, a, d, y, t, Y) { var i = t.length - 1; switch (y) {
            case 4:
                d.getLogger().debug("Rule: separator (NL) ");
                break;
            case 5:
                d.getLogger().debug("Rule: separator (Space) ");
                break;
            case 6:
                d.getLogger().debug("Rule: separator (EOF) ");
                break;
            case 7:
                d.getLogger().debug("Rule: hierarchy: ", t[i - 1]), d.setHierarchy(t[i - 1]);
                break;
            case 8:
                d.getLogger().debug("Stop NL ");
                break;
            case 9:
                d.getLogger().debug("Stop EOF ");
                break;
            case 10:
                d.getLogger().debug("Stop NL2 ");
                break;
            case 11:
                d.getLogger().debug("Stop EOF2 ");
                break;
            case 12:
                d.getLogger().debug("Rule: statement: ", t[i]), typeof t[i].length == "number" ? this.$ = t[i] : this.$ = [t[i]];
                break;
            case 13:
                d.getLogger().debug("Rule: statement #2: ", t[i - 1]), this.$ = [t[i - 1]].concat(t[i]);
                break;
            case 14:
                d.getLogger().debug("Rule: link: ", t[i], u), this.$ = { edgeTypeStr: t[i], label: "" };
                break;
            case 15:
                d.getLogger().debug("Rule: LABEL link: ", t[i - 3], t[i - 1], t[i]), this.$ = { edgeTypeStr: t[i], label: t[i - 1] };
                break;
            case 18:
                let F = parseInt(t[i]), H = d.generateId();
                this.$ = { id: H, type: "space", label: "", width: F, children: [] };
                break;
            case 23:
                d.getLogger().debug("Rule: (nodeStatement link node) ", t[i - 2], t[i - 1], t[i], " typestr: ", t[i - 1].edgeTypeStr);
                let X = d.edgeStrToEdgeData(t[i - 1].edgeTypeStr), ee = d.edgeStrToEdgeStartData(t[i - 1].edgeTypeStr), G = d.edgeStrToThickness(t[i - 1].edgeTypeStr), te = d.edgeStrToPattern(t[i - 1].edgeTypeStr);
                this.$ = [{ id: t[i - 2].id, label: t[i - 2].label, type: t[i - 2].type, directions: t[i - 2].directions }, { id: t[i - 2].id + "-" + t[i].id, start: t[i - 2].id, end: t[i].id, label: t[i - 1].label, type: "edge", thickness: G, pattern: te, directions: t[i].directions, arrowTypeEnd: X, arrowTypeStart: ee }, { id: t[i].id, label: t[i].label, type: d.typeStr2Type(t[i].typeStr), directions: t[i].directions }];
                break;
            case 24:
                d.getLogger().debug("Rule: nodeStatement (abc88 node size) ", t[i - 1], t[i]), this.$ = { id: t[i - 1].id, label: t[i - 1].label, type: d.typeStr2Type(t[i - 1].typeStr), directions: t[i - 1].directions, widthInColumns: parseInt(t[i], 10) };
                break;
            case 25:
                d.getLogger().debug("Rule: nodeStatement (node) ", t[i]), this.$ = { id: t[i].id, label: t[i].label, type: d.typeStr2Type(t[i].typeStr), directions: t[i].directions, widthInColumns: 1 };
                break;
            case 26:
                d.getLogger().debug("APA123", this ? this : "na"), d.getLogger().debug("COLUMNS: ", t[i]), this.$ = { type: "column-setting", columns: t[i] === "auto" ? -1 : parseInt(t[i]) };
                break;
            case 27:
                d.getLogger().debug("Rule: id-block statement : ", t[i - 2], t[i - 1]);
                let D = d.generateId();
                this.$ = V(W({}, t[i - 2]), { type: "composite", children: t[i - 1] });
                break;
            case 28:
                d.getLogger().debug("Rule: blockStatement : ", t[i - 2], t[i - 1], t[i]);
                let B = d.generateId();
                this.$ = { id: B, type: "composite", label: "", children: t[i - 1] };
                break;
            case 29:
                d.getLogger().debug("Rule: node (NODE_ID separator): ", t[i]), this.$ = { id: t[i] };
                break;
            case 30:
                d.getLogger().debug("Rule: node (NODE_ID nodeShapeNLabel separator): ", t[i - 1], t[i]), this.$ = { id: t[i - 1], label: t[i].label, typeStr: t[i].typeStr, directions: t[i].directions };
                break;
            case 31:
                d.getLogger().debug("Rule: dirList: ", t[i]), this.$ = [t[i]];
                break;
            case 32:
                d.getLogger().debug("Rule: dirList: ", t[i - 1], t[i]), this.$ = [t[i - 1]].concat(t[i]);
                break;
            case 33:
                d.getLogger().debug("Rule: nodeShapeNLabel: ", t[i - 2], t[i - 1], t[i]), this.$ = { typeStr: t[i - 2] + t[i], label: t[i - 1] };
                break;
            case 34:
                d.getLogger().debug("Rule: BLOCK_ARROW nodeShapeNLabel: ", t[i - 3], t[i - 2], " #3:", t[i - 1], t[i]), this.$ = { typeStr: t[i - 3] + t[i], label: t[i - 2], directions: t[i - 1] };
                break;
            case 35:
            case 36:
                this.$ = { type: "classDef", id: t[i - 1].trim(), css: t[i].trim() };
                break;
            case 37:
                this.$ = { type: "applyClass", id: t[i - 1].trim(), styleClass: t[i].trim() };
                break;
            case 38:
                this.$ = { type: "applyStyles", id: t[i - 1].trim(), stylesStr: t[i].trim() };
                break;
        } }, "anonymous"), table: [{ 9: 1, 10: [1, 2] }, { 1: [3] }, { 10: o, 11: 3, 13: 4, 19: 5, 20: 6, 21: l, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: n, 29: h, 31: p, 39: s, 43: g, 46: x }, { 8: [1, 20] }, e(k, [2, 12], { 13: 4, 19: 5, 20: 6, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 11: 21, 10: o, 21: l, 28: n, 29: h, 31: p, 39: s, 43: g, 46: x }), e(S, [2, 16], { 14: 22, 15: b, 16: L }), e(S, [2, 17]), e(S, [2, 18]), e(S, [2, 19]), e(S, [2, 20]), e(S, [2, 21]), e(S, [2, 22]), e(E, [2, 25], { 27: [1, 25] }), e(S, [2, 26]), { 19: 26, 26: 12, 31: p }, { 10: o, 11: 27, 13: 4, 19: 5, 20: 6, 21: l, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: n, 29: h, 31: p, 39: s, 43: g, 46: x }, { 40: [1, 28], 42: [1, 29] }, { 44: [1, 30] }, { 47: [1, 31] }, e(f, [2, 29], { 32: 32, 35: [1, 33], 37: [1, 34] }), { 1: [2, 7] }, e(k, [2, 13]), { 26: 35, 31: p }, { 31: [2, 14] }, { 17: [1, 36] }, e(E, [2, 24]), { 10: o, 11: 37, 13: 4, 14: 22, 15: b, 16: L, 19: 5, 20: 6, 21: l, 22: 8, 23: 9, 24: 10, 25: 11, 26: 12, 28: n, 29: h, 31: p, 39: s, 43: g, 46: x }, { 30: [1, 38] }, { 41: [1, 39] }, { 41: [1, 40] }, { 45: [1, 41] }, { 48: [1, 42] }, e(f, [2, 30]), { 18: [1, 43] }, { 18: [1, 44] }, e(E, [2, 23]), { 18: [1, 45] }, { 30: [1, 46] }, e(S, [2, 28]), e(S, [2, 35]), e(S, [2, 36]), e(S, [2, 37]), e(S, [2, 38]), { 36: [1, 47] }, { 33: 48, 34: _ }, { 15: [1, 50] }, e(S, [2, 27]), e(f, [2, 33]), { 38: [1, 51] }, { 33: 52, 34: _, 38: [2, 31] }, { 31: [2, 15] }, e(f, [2, 34]), { 38: [2, 32] }], defaultActions: { 20: [2, 7], 23: [2, 14], 50: [2, 15], 52: [2, 32] }, parseError: c(function (u, r) { if (r.recoverable)
            this.trace(u);
        else {
            var a = new Error(u);
            throw a.hash = r, a;
        } }, "parseError"), parse: c(function (u) {
            var r = this, a = [0], d = [], y = [null], t = [], Y = this.table, i = "", F = 0, H = 0, X = 0, ee = 2, G = 1, te = t.slice.call(arguments, 1), D = Object.create(this.lexer), B = { yy: {} };
            for (var se in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, se) && (B.yy[se] = this.yy[se]);
            D.setInput(u, B.yy), B.yy.lexer = D, B.yy.parser = this, typeof D.yylloc > "u" && (D.yylloc = {});
            var re = D.yylloc;
            t.push(re);
            var Qe = D.options && D.options.ranges;
            typeof B.yy.parseError == "function" ? this.parseError = B.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function $e(T) { a.length = a.length - 2 * T, y.length = y.length - T, t.length = t.length - T; }
            c($e, "popStack");
            function Le() { var T; return T = d.pop() || D.lex() || G, typeof T != "number" && (T instanceof Array && (d = T, T = d.pop()), T = r.symbols_[T] || T), T; }
            c(Le, "lex");
            for (var I, ie, P, O, Nt, ae, M = {}, q, A, ke, J;;) {
                if (P = a[a.length - 1], this.defaultActions[P] ? O = this.defaultActions[P] : ((I === null || typeof I > "u") && (I = Le()), O = Y[P] && Y[P][I]), typeof O > "u" || !O.length || !O[0]) {
                    var ne = "";
                    J = [];
                    for (q in Y[P])
                        this.terminals_[q] && q > ee && J.push("'" + this.terminals_[q] + "'");
                    D.showPosition ? ne = "Parse error on line " + (F + 1) + `:
` + D.showPosition() + `
Expecting ` + J.join(", ") + ", got '" + (this.terminals_[I] || I) + "'" : ne = "Parse error on line " + (F + 1) + ": Unexpected " + (I == G ? "end of input" : "'" + (this.terminals_[I] || I) + "'"), this.parseError(ne, { text: D.match, token: this.terminals_[I] || I, line: D.yylineno, loc: re, expected: J });
                }
                if (O[0] instanceof Array && O.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + P + ", token: " + I);
                switch (O[0]) {
                    case 1:
                        a.push(I), y.push(D.yytext), t.push(D.yylloc), a.push(O[1]), I = null, ie ? (I = ie, ie = null) : (H = D.yyleng, i = D.yytext, F = D.yylineno, re = D.yylloc, X > 0 && X--);
                        break;
                    case 2:
                        if (A = this.productions_[O[1]][1], M.$ = y[y.length - A], M._$ = { first_line: t[t.length - (A || 1)].first_line, last_line: t[t.length - 1].last_line, first_column: t[t.length - (A || 1)].first_column, last_column: t[t.length - 1].last_column }, Qe && (M._$.range = [t[t.length - (A || 1)].range[0], t[t.length - 1].range[1]]), ae = this.performAction.apply(M, [i, H, F, B.yy, O[1], y, t].concat(te)), typeof ae < "u")
                            return ae;
                        A && (a = a.slice(0, -1 * A * 2), y = y.slice(0, -1 * A), t = t.slice(0, -1 * A)), a.push(this.productions_[O[1]][0]), y.push(M.$), t.push(M._$), ke = Y[a[a.length - 2]][a[a.length - 1]], a.push(ke);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, N = (function () {
        var C = { EOF: 1, parseError: c(function (r, a) { if (this.yy.parser)
                this.yy.parser.parseError(r, a);
            else
                throw new Error(r); }, "parseError"), setInput: c(function (u, r) { return this.yy = r || this.yy || {}, this._input = u, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: c(function () { var u = this._input[0]; this.yytext += u, this.yyleng++, this.offset++, this.match += u, this.matched += u; var r = u.match(/(?:\r\n?|\n).*/g); return r ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), u; }, "input"), unput: c(function (u) { var r = u.length, a = u.split(/(?:\r\n?|\n)/g); this._input = u + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - r), this.offset -= r; var d = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), a.length - 1 && (this.yylineno -= a.length - 1); var y = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: a ? (a.length === d.length ? this.yylloc.first_column : 0) + d[d.length - a.length].length - a[0].length : this.yylloc.first_column - r }, this.options.ranges && (this.yylloc.range = [y[0], y[0] + this.yyleng - r]), this.yyleng = this.yytext.length, this; }, "unput"), more: c(function () { return this._more = !0, this; }, "more"), reject: c(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: c(function (u) { this.unput(this.match.slice(u)); }, "less"), pastInput: c(function () { var u = this.matched.substr(0, this.matched.length - this.match.length); return (u.length > 20 ? "..." : "") + u.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: c(function () { var u = this.match; return u.length < 20 && (u += this._input.substr(0, 20 - u.length)), (u.substr(0, 20) + (u.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: c(function () {
                var u = this.pastInput(), r = new Array(u.length + 1).join("-");
                return u + this.upcomingInput() + `
` + r + "^";
            }, "showPosition"), test_match: c(function (u, r) { var a, d, y; if (this.options.backtrack_lexer && (y = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (y.yylloc.range = this.yylloc.range.slice(0))), d = u[0].match(/(?:\r\n?|\n).*/g), d && (this.yylineno += d.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: d ? d[d.length - 1].length - d[d.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + u[0].length }, this.yytext += u[0], this.match += u[0], this.matches = u, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(u[0].length), this.matched += u[0], a = this.performAction.call(this, this.yy, this, r, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), a)
                return a; if (this._backtrack) {
                for (var t in y)
                    this[t] = y[t];
                return !1;
            } return !1; }, "test_match"), next: c(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var u, r, a, d;
                this._more || (this.yytext = "", this.match = "");
                for (var y = this._currentRules(), t = 0; t < y.length; t++)
                    if (a = this._input.match(this.rules[y[t]]), a && (!r || a[0].length > r[0].length)) {
                        if (r = a, d = t, this.options.backtrack_lexer) {
                            if (u = this.test_match(a, y[t]), u !== !1)
                                return u;
                            if (this._backtrack) {
                                r = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return r ? (u = this.test_match(r, y[d]), u !== !1 ? u : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: c(function () { var r = this.next(); return r || this.lex(); }, "lex"), begin: c(function (r) { this.conditionStack.push(r); }, "begin"), popState: c(function () { var r = this.conditionStack.length - 1; return r > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: c(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: c(function (r) { return r = this.conditionStack.length - 1 - Math.abs(r || 0), r >= 0 ? this.conditionStack[r] : "INITIAL"; }, "topState"), pushState: c(function (r) { this.begin(r); }, "pushState"), stateStackSize: c(function () { return this.conditionStack.length; }, "stateStackSize"), options: {}, performAction: c(function (r, a, d, y) { var t = y; switch (d) {
                case 0:
                    return r.getLogger().debug("Found block-beta"), 10;
                    break;
                case 1:
                    return r.getLogger().debug("Found id-block"), 29;
                    break;
                case 2:
                    return r.getLogger().debug("Found block"), 10;
                    break;
                case 3:
                    r.getLogger().debug(".", a.yytext);
                    break;
                case 4:
                    r.getLogger().debug("_", a.yytext);
                    break;
                case 5: return 5;
                case 6:
                    return a.yytext = -1, 28;
                    break;
                case 7:
                    return a.yytext = a.yytext.replace(/columns\s+/, ""), r.getLogger().debug("COLUMNS (LEX)", a.yytext), 28;
                    break;
                case 8:
                    this.pushState("md_string");
                    break;
                case 9: return "MD_STR";
                case 10:
                    this.popState();
                    break;
                case 11:
                    this.pushState("string");
                    break;
                case 12:
                    r.getLogger().debug("LEX: POPPING STR:", a.yytext), this.popState();
                    break;
                case 13:
                    return r.getLogger().debug("LEX: STR end:", a.yytext), "STR";
                    break;
                case 14:
                    return a.yytext = a.yytext.replace(/space\:/, ""), r.getLogger().debug("SPACE NUM (LEX)", a.yytext), 21;
                    break;
                case 15:
                    return a.yytext = "1", r.getLogger().debug("COLUMNS (LEX)", a.yytext), 21;
                    break;
                case 16: return 42;
                case 17: return "LINKSTYLE";
                case 18: return "INTERPOLATE";
                case 19:
                    return this.pushState("CLASSDEF"), 39;
                    break;
                case 20:
                    return this.popState(), this.pushState("CLASSDEFID"), "DEFAULT_CLASSDEF_ID";
                    break;
                case 21:
                    return this.popState(), this.pushState("CLASSDEFID"), 40;
                    break;
                case 22:
                    return this.popState(), 41;
                    break;
                case 23:
                    return this.pushState("CLASS"), 43;
                    break;
                case 24:
                    return this.popState(), this.pushState("CLASS_STYLE"), 44;
                    break;
                case 25:
                    return this.popState(), 45;
                    break;
                case 26:
                    return this.pushState("STYLE_STMNT"), 46;
                    break;
                case 27:
                    return this.popState(), this.pushState("STYLE_DEFINITION"), 47;
                    break;
                case 28:
                    return this.popState(), 48;
                    break;
                case 29:
                    return this.pushState("acc_title"), "acc_title";
                    break;
                case 30:
                    return this.popState(), "acc_title_value";
                    break;
                case 31:
                    return this.pushState("acc_descr"), "acc_descr";
                    break;
                case 32:
                    return this.popState(), "acc_descr_value";
                    break;
                case 33:
                    this.pushState("acc_descr_multiline");
                    break;
                case 34:
                    this.popState();
                    break;
                case 35: return "acc_descr_multiline_value";
                case 36: return 30;
                case 37:
                    return this.popState(), r.getLogger().debug("Lex: (("), "NODE_DEND";
                    break;
                case 38:
                    return this.popState(), r.getLogger().debug("Lex: (("), "NODE_DEND";
                    break;
                case 39:
                    return this.popState(), r.getLogger().debug("Lex: ))"), "NODE_DEND";
                    break;
                case 40:
                    return this.popState(), r.getLogger().debug("Lex: (("), "NODE_DEND";
                    break;
                case 41:
                    return this.popState(), r.getLogger().debug("Lex: (("), "NODE_DEND";
                    break;
                case 42:
                    return this.popState(), r.getLogger().debug("Lex: (-"), "NODE_DEND";
                    break;
                case 43:
                    return this.popState(), r.getLogger().debug("Lex: -)"), "NODE_DEND";
                    break;
                case 44:
                    return this.popState(), r.getLogger().debug("Lex: (("), "NODE_DEND";
                    break;
                case 45:
                    return this.popState(), r.getLogger().debug("Lex: ]]"), "NODE_DEND";
                    break;
                case 46:
                    return this.popState(), r.getLogger().debug("Lex: ("), "NODE_DEND";
                    break;
                case 47:
                    return this.popState(), r.getLogger().debug("Lex: ])"), "NODE_DEND";
                    break;
                case 48:
                    return this.popState(), r.getLogger().debug("Lex: /]"), "NODE_DEND";
                    break;
                case 49:
                    return this.popState(), r.getLogger().debug("Lex: /]"), "NODE_DEND";
                    break;
                case 50:
                    return this.popState(), r.getLogger().debug("Lex: )]"), "NODE_DEND";
                    break;
                case 51:
                    return this.popState(), r.getLogger().debug("Lex: )"), "NODE_DEND";
                    break;
                case 52:
                    return this.popState(), r.getLogger().debug("Lex: ]>"), "NODE_DEND";
                    break;
                case 53:
                    return this.popState(), r.getLogger().debug("Lex: ]"), "NODE_DEND";
                    break;
                case 54:
                    return r.getLogger().debug("Lexa: -)"), this.pushState("NODE"), 35;
                    break;
                case 55:
                    return r.getLogger().debug("Lexa: (-"), this.pushState("NODE"), 35;
                    break;
                case 56:
                    return r.getLogger().debug("Lexa: ))"), this.pushState("NODE"), 35;
                    break;
                case 57:
                    return r.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
                    break;
                case 58:
                    return r.getLogger().debug("Lex: ((("), this.pushState("NODE"), 35;
                    break;
                case 59:
                    return r.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
                    break;
                case 60:
                    return r.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
                    break;
                case 61:
                    return r.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
                    break;
                case 62:
                    return r.getLogger().debug("Lexc: >"), this.pushState("NODE"), 35;
                    break;
                case 63:
                    return r.getLogger().debug("Lexa: (["), this.pushState("NODE"), 35;
                    break;
                case 64:
                    return r.getLogger().debug("Lexa: )"), this.pushState("NODE"), 35;
                    break;
                case 65:
                    return this.pushState("NODE"), 35;
                    break;
                case 66:
                    return this.pushState("NODE"), 35;
                    break;
                case 67:
                    return this.pushState("NODE"), 35;
                    break;
                case 68:
                    return this.pushState("NODE"), 35;
                    break;
                case 69:
                    return this.pushState("NODE"), 35;
                    break;
                case 70:
                    return this.pushState("NODE"), 35;
                    break;
                case 71:
                    return this.pushState("NODE"), 35;
                    break;
                case 72:
                    return r.getLogger().debug("Lexa: ["), this.pushState("NODE"), 35;
                    break;
                case 73:
                    return this.pushState("BLOCK_ARROW"), r.getLogger().debug("LEX ARR START"), 37;
                    break;
                case 74:
                    return r.getLogger().debug("Lex: NODE_ID", a.yytext), 31;
                    break;
                case 75:
                    return r.getLogger().debug("Lex: EOF", a.yytext), 8;
                    break;
                case 76:
                    this.pushState("md_string");
                    break;
                case 77:
                    this.pushState("md_string");
                    break;
                case 78: return "NODE_DESCR";
                case 79:
                    this.popState();
                    break;
                case 80:
                    r.getLogger().debug("Lex: Starting string"), this.pushState("string");
                    break;
                case 81:
                    r.getLogger().debug("LEX ARR: Starting string"), this.pushState("string");
                    break;
                case 82:
                    return r.getLogger().debug("LEX: NODE_DESCR:", a.yytext), "NODE_DESCR";
                    break;
                case 83:
                    r.getLogger().debug("LEX POPPING"), this.popState();
                    break;
                case 84:
                    r.getLogger().debug("Lex: =>BAE"), this.pushState("ARROW_DIR");
                    break;
                case 85:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (right): dir:", a.yytext), "DIR";
                    break;
                case 86:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (left):", a.yytext), "DIR";
                    break;
                case 87:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (x):", a.yytext), "DIR";
                    break;
                case 88:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (y):", a.yytext), "DIR";
                    break;
                case 89:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (up):", a.yytext), "DIR";
                    break;
                case 90:
                    return a.yytext = a.yytext.replace(/^,\s*/, ""), r.getLogger().debug("Lex (down):", a.yytext), "DIR";
                    break;
                case 91:
                    return a.yytext = "]>", r.getLogger().debug("Lex (ARROW_DIR end):", a.yytext), this.popState(), this.popState(), "BLOCK_ARROW_END";
                    break;
                case 92:
                    return r.getLogger().debug("Lex: LINK", "#" + a.yytext + "#"), 15;
                    break;
                case 93:
                    return r.getLogger().debug("Lex: LINK", a.yytext), 15;
                    break;
                case 94:
                    return r.getLogger().debug("Lex: LINK", a.yytext), 15;
                    break;
                case 95:
                    return r.getLogger().debug("Lex: LINK", a.yytext), 15;
                    break;
                case 96:
                    return r.getLogger().debug("Lex: START_LINK", a.yytext), this.pushState("LLABEL"), 16;
                    break;
                case 97:
                    return r.getLogger().debug("Lex: START_LINK", a.yytext), this.pushState("LLABEL"), 16;
                    break;
                case 98:
                    return r.getLogger().debug("Lex: START_LINK", a.yytext), this.pushState("LLABEL"), 16;
                    break;
                case 99:
                    this.pushState("md_string");
                    break;
                case 100:
                    return r.getLogger().debug("Lex: Starting string"), this.pushState("string"), "LINK_LABEL";
                    break;
                case 101:
                    return this.popState(), r.getLogger().debug("Lex: LINK", "#" + a.yytext + "#"), 15;
                    break;
                case 102:
                    return this.popState(), r.getLogger().debug("Lex: LINK", a.yytext), 15;
                    break;
                case 103:
                    return this.popState(), r.getLogger().debug("Lex: LINK", a.yytext), 15;
                    break;
                case 104:
                    return r.getLogger().debug("Lex: COLON", a.yytext), a.yytext = a.yytext.slice(1), 27;
                    break;
            } }, "anonymous"), rules: [/^(?:block-beta\b)/, /^(?:block:)/, /^(?:block\b)/, /^(?:[\s]+)/, /^(?:[\n]+)/, /^(?:((\u000D\u000A)|(\u000A)))/, /^(?:columns\s+auto\b)/, /^(?:columns\s+[\d]+)/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]*)/, /^(?:space[:]\d+)/, /^(?:space\b)/, /^(?:default\b)/, /^(?:linkStyle\b)/, /^(?:interpolate\b)/, /^(?:classDef\s+)/, /^(?:DEFAULT\s+)/, /^(?:\w+\s+)/, /^(?:[^\n]*)/, /^(?:class\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:style\s+)/, /^(?:(\w+)+((,\s*\w+)*))/, /^(?:[^\n]*)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:end\b\s*)/, /^(?:\(\(\()/, /^(?:\)\)\))/, /^(?:[\)]\))/, /^(?:\}\})/, /^(?:\})/, /^(?:\(-)/, /^(?:-\))/, /^(?:\(\()/, /^(?:\]\])/, /^(?:\()/, /^(?:\]\))/, /^(?:\\\])/, /^(?:\/\])/, /^(?:\)\])/, /^(?:[\)])/, /^(?:\]>)/, /^(?:[\]])/, /^(?:-\))/, /^(?:\(-)/, /^(?:\)\))/, /^(?:\))/, /^(?:\(\(\()/, /^(?:\(\()/, /^(?:\{\{)/, /^(?:\{)/, /^(?:>)/, /^(?:\(\[)/, /^(?:\()/, /^(?:\[\[)/, /^(?:\[\|)/, /^(?:\[\()/, /^(?:\)\)\))/, /^(?:\[\\)/, /^(?:\[\/)/, /^(?:\[\\)/, /^(?:\[)/, /^(?:<\[)/, /^(?:[^\(\[\n\-\)\{\}\s\<\>:=]+)/, /^(?:$)/, /^(?:["][`])/, /^(?:["][`])/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["])/, /^(?:["])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:\]>\s*\()/, /^(?:,?\s*right\s*)/, /^(?:,?\s*left\s*)/, /^(?:,?\s*x\s*)/, /^(?:,?\s*y\s*)/, /^(?:,?\s*up\s*)/, /^(?:,?\s*down\s*)/, /^(?:\)\s*)/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?:\s*~~[\~]+\s*)/, /^(?:\s*[xo<]?--\s*)/, /^(?:\s*[xo<]?==\s*)/, /^(?:\s*[xo<]?-\.\s*)/, /^(?:["][`])/, /^(?:["])/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?::\d+)/], conditions: { STYLE_DEFINITION: { rules: [28], inclusive: !1 }, STYLE_STMNT: { rules: [27], inclusive: !1 }, CLASSDEFID: { rules: [22], inclusive: !1 }, CLASSDEF: { rules: [20, 21], inclusive: !1 }, CLASS_STYLE: { rules: [25], inclusive: !1 }, CLASS: { rules: [24], inclusive: !1 }, LLABEL: { rules: [99, 100, 101, 102, 103], inclusive: !1 }, ARROW_DIR: { rules: [85, 86, 87, 88, 89, 90, 91], inclusive: !1 }, BLOCK_ARROW: { rules: [76, 81, 84], inclusive: !1 }, NODE: { rules: [37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 77, 80], inclusive: !1 }, md_string: { rules: [9, 10, 78, 79], inclusive: !1 }, space: { rules: [], inclusive: !1 }, string: { rules: [12, 13, 82, 83], inclusive: !1 }, acc_descr_multiline: { rules: [34, 35], inclusive: !1 }, acc_descr: { rules: [32], inclusive: !1 }, acc_title: { rules: [30], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 11, 14, 15, 16, 17, 18, 19, 23, 26, 29, 31, 33, 36, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 92, 93, 94, 95, 96, 97, 98, 104], inclusive: !0 } } };
        return C;
    })();
    w.lexer = N;
    function v() { this.yy = {}; }
    return c(v, "Parser"), v.prototype = w, w.Parser = v, new v;
})();
he.parser = he;
var et = he, z = new Map, de = [], ue = new Map, Ae = "color", Re = "fill", tt = "bgFill", Fe = ",", Z = new Map, pe = "", st = c(e => Ee.sanitizeText(e, oe()), "sanitizeText"), rt = c(function (e, o = "") { let l = Z.get(e); l || (l = { id: e, styles: [], textStyles: [] }, Z.set(e, l)), o?.split(Fe).forEach(n => { let h = n.replace(/([^;]*);/, "$1").trim(); if (RegExp(Ae).exec(n)) {
    let s = h.replace(Re, tt).replace(Ae, Re);
    l.textStyles.push(s);
} l.styles.push(h); }); }, "addStyleClass"), it = c(function (e, o = "") { let l = z.get(e); o != null && (l.styles = o.split(Fe)); }, "addStyle2Node"), at = c(function (e, o) { e.split(",").forEach(function (l) { let n = z.get(l); if (n === void 0) {
    let h = l.trim();
    n = { id: h, type: "na", children: [] }, z.set(h, n);
} n.classes || (n.classes = []), n.classes.push(o); }); }, "setCssClass"), Me = c((e, o) => { let l = e.flat(), n = [], p = l.find(s => s?.type === "column-setting")?.columns ?? -1; for (let s of l) {
    if (typeof p == "number" && p > 0 && s.type !== "column-setting" && typeof s.widthInColumns == "number" && s.widthInColumns > p && m.warn(`Block ${s.id} width ${s.widthInColumns} exceeds configured column width ${p}`), s.label && (s.label = st(s.label)), s.type === "classDef") {
        rt(s.id, s.css);
        continue;
    }
    if (s.type === "applyClass") {
        at(s.id, s?.styleClass ?? "");
        continue;
    }
    if (s.type === "applyStyles") {
        s?.stylesStr && it(s.id, s?.stylesStr);
        continue;
    }
    if (s.type === "column-setting")
        o.columns = s.columns ?? -1;
    else if (s.type === "edge") {
        let g = (ue.get(s.id) ?? 0) + 1;
        ue.set(s.id, g), s.id = g + "-" + s.id, de.push(s);
    }
    else {
        s.label || (s.type === "composite" ? s.label = "" : s.label = s.id);
        let g = z.get(s.id);
        if (g === void 0 ? z.set(s.id, s) : (s.type !== "na" && (g.type = s.type), s.label !== s.id && (g.label = s.label)), s.children && Me(s.children, s), s.type === "space") {
            let x = s.width ?? 1;
            for (let k = 0; k < x; k++) {
                let S = De(s);
                S.id = S.id + "-" + k, z.set(S.id, S), n.push(S);
            }
        }
        else
            g === void 0 && n.push(s);
    }
} o.children = n; }, "populateBlockDatabase"), be = [], U = { id: "root", type: "composite", children: [], columns: -1 }, nt = c(() => { m.debug("Clear called"), _e(), U = { id: "root", type: "composite", children: [], columns: -1 }, z = new Map([["root", U]]), be = [], Z = new Map, de = [], ue = new Map, pe = ""; }, "clear");
function Ke(e) { switch (m.debug("typeStr2Type", e), e) {
    case "[]": return "square";
    case "()": return m.debug("we have a round"), "round";
    case "(())": return "circle";
    case ">]": return "rect_left_inv_arrow";
    case "{}": return "diamond";
    case "{{}}": return "hexagon";
    case "([])": return "stadium";
    case "[[]]": return "subroutine";
    case "[()]": return "cylinder";
    case "((()))": return "doublecircle";
    case "[//]": return "lean_right";
    case "[\\\\]": return "lean_left";
    case "[/\\]": return "trapezoid";
    case "[\\/]": return "inv_trapezoid";
    case "<[]>": return "block_arrow";
    default: return "na";
} }
c(Ke, "typeStr2Type");
function Ye(e) { return m.debug("typeStr2Type", e), e === "==" ? "thick" : "normal"; }
c(Ye, "edgeTypeStr2Type");
function We(e) { switch (e.trim().slice(-1)) {
    case "x": return "arrow_cross";
    case "o": return "arrow_circle";
    case ">": return "arrow_point";
    default: return "";
} }
c(We, "edgeStrToEdgeData");
function Ve(e) { switch (e.trim().charAt(0)) {
    case "x": return "arrow_cross";
    case "o": return "arrow_circle";
    case "<": return "arrow_point";
    default: return "arrow_open";
} }
c(Ve, "edgeStrToEdgeStartData");
function je(e) { return e.includes("==") ? "thick" : "normal"; }
c(je, "edgeStrToThickness");
function Ue(e) { return e.includes(".-") ? "dotted" : "solid"; }
c(Ue, "edgeStrToPattern");
var Pe = 0, ot = c(() => (Pe++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + Pe), "generateId"), lt = c(e => { U.children = e, Me(e, U), be = U.children; }, "setHierarchy"), ct = c(e => { let o = z.get(e); return o ? o.columns ? o.columns : o.children ? o.children.length : -1 : -1; }, "getColumns"), ht = c(() => [...z.values()], "getBlocksFlat"), ut = c(() => be || [], "getBlocks"), gt = c(() => de, "getEdges"), dt = c(e => z.get(e), "getBlock"), pt = c(e => { z.set(e.id, e); }, "setBlock"), bt = c(e => { pe = e; }, "setDiagramId"), ft = c(() => pe, "getDiagramId"), St = c(() => m, "getLogger"), xt = c(function () { return Z; }, "getClasses"), Lt = { getConfig: c(() => K().block, "getConfig"), typeStr2Type: Ke, edgeTypeStr2Type: Ye, edgeStrToEdgeData: We, edgeStrToEdgeStartData: Ve, edgeStrToThickness: je, edgeStrToPattern: Ue, getLogger: St, getBlocksFlat: ht, getBlocks: ut, getEdges: gt, setHierarchy: lt, getBlock: dt, setBlock: pt, getColumns: ct, getClasses: xt, clear: nt, generateId: ot, setDiagramId: bt, getDiagramId: ft }, kt = Lt, ce = c((e, o) => { let l = ye, n = l(e, "r"), h = l(e, "g"), p = l(e, "b"); return me(n, h, p, o); }, "fade"), mt = c(e => `.label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .cluster-label text {
    fill: ${e.titleColor};
  }
  .cluster-label span {
    color: ${e.titleColor};
  }



  .label text,span {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: 1px;
  }
  .flowchart-label text {
    text-anchor: middle;
  }
  // .flowchart-label .text-outer-tspan {
  //   text-anchor: middle;
  // }
  // .flowchart-label .text-inner-tspan {
  //   text-anchor: start;
  // }

  .node .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }

  .arrowheadPath {
    fill: ${e.arrowheadColor};
  }

  .edgePaths .path {
    stroke: ${e.lineColor};
    stroke-width: 2.0px;
  }

  .flowchart-link {
    stroke: ${e.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${e.edgeLabelBackground};
    /*
     * This is for backward compatibility with existing code that didn't
     * add a \`<p>\` around edge labels.
     *
     * TODO: We should probably remove this in a future release.
     */
    p {
      margin: 0;
      padding: 0;
      display: inline;
    }
    rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${e.edgeLabelBackground};
  }

  .node .cluster {
    // fill: ${ce(e.mainBkg, .5)};
    fill: ${ce(e.clusterBkg, .5)};
    stroke: ${ce(e.clusterBorder, .2)};
    box-shadow: rgba(50, 50, 93, 0.25) 0px 13px 27px -5px, rgba(0, 0, 0, 0.3) 0px 8px 16px -8px;
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor};
  }

  .cluster span {
    color: ${e.titleColor};
  }
  /* .cluster div {
    color: ${e.titleColor};
  } */

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${e.fontFamily};
    font-size: 12px;
    background: ${e.tertiaryColor};
    border: 1px solid ${e.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }
  ${Be()}
`, "getStyles"), yt = mt;
function ge(e, o) { if (e === 0 || !Number.isInteger(e))
    throw new Error("Columns must be an integer !== 0."); if (o < 0 || !Number.isInteger(o))
    throw new Error("Position must be a non-negative integer." + o); if (e < 0)
    return { px: o, py: 0 }; if (e === 1)
    return { px: 0, py: o }; let l = o % e, n = Math.floor(o / e); return { px: l, py: n }; }
c(ge, "calculateBlockPosition");
var Et = c(e => { let o = 0, l = 0; for (let n of e.children) {
    let { width: h, height: p, x: s, y: g } = n.size ?? { width: 0, height: 0, x: 0, y: 0 };
    if (m.debug("getMaxChildSize abc95 child:", n.id, "width:", h, "height:", p, "x:", s, "y:", g, n.type), n.type === "space")
        continue;
    let x = h / (n.widthInColumns ?? 1);
    x > o && (o = x), p > l && (l = p);
} return { width: o, height: l }; }, "getMaxChildSize");
function Q(e, o, l = 0, n = 0, h = 8) { m.debug("setBlockSizes abc95 (start)", e.id, e?.size?.x, "block width =", e?.size, "siblingWidth", l), e?.size?.width || (e.size = { width: l, height: n, x: 0, y: 0 }); let p = 0, s = 0; if (e.children?.length > 0) {
    for (let f of e.children)
        Q(f, o, 0, 0, h);
    let g = Et(e);
    p = g.width, s = g.height, m.debug("setBlockSizes abc95 maxWidth of", e.id, ":s children is ", p, s);
    for (let f of e.children)
        f.size && (m.debug(`abc95 Setting size of children of ${e.id} id=${f.id} ${p} ${s} ${JSON.stringify(f.size)}`), f.size.width = p * (f.widthInColumns ?? 1) + h * ((f.widthInColumns ?? 1) - 1), f.size.height = s, f.size.x = 0, f.size.y = 0, m.debug(`abc95 updating size of ${e.id} children child:${f.id} maxWidth:${p} maxHeight:${s}`));
    for (let f of e.children)
        Q(f, o, p, s, h);
    let x = e.columns ?? -1, k = 0;
    for (let f of e.children)
        k += f.widthInColumns ?? 1;
    let S = e.children.length;
    x > 0 && x < k && (S = x);
    let b = Math.ceil(k / S), L = S * (p + h) + h, E = b * (s + h) + h;
    if (L < l) {
        m.debug(`Detected to small sibling: abc95 ${e.id} siblingWidth ${l} siblingHeight ${n} width ${L}`), L = l, E = n;
        let f = (l - S * h - h) / S, _ = (n - b * h - h) / b;
        m.debug("Size indata abc88", e.id, "childWidth", f, "maxWidth", p), m.debug("Size indata abc88", e.id, "childHeight", _, "maxHeight", s), m.debug("Size indata abc88 xSize", S, "padding", h);
        for (let w of e.children)
            w.size && (w.size.width = f, w.size.height = _, w.size.x = 0, w.size.y = 0);
    }
    if (m.debug(`abc95 (finale calc) ${e.id} xSize ${S} ySize ${b} columns ${x}${e.children.length} width=${Math.max(L, e.size?.width || 0)}`), L < (e?.size?.width || 0)) {
        L = e?.size?.width || 0;
        let f = x > 0 ? Math.min(e.children.length, x) : e.children.length;
        if (f > 0) {
            let _ = (L - f * h - h) / f;
            m.debug("abc95 (growing to fit) width", e.id, L, e.size?.width, _);
            for (let w of e.children)
                w.size && (w.size.width = _);
        }
    }
    e.size = { width: L, height: E, x: 0, y: 0 };
} m.debug("setBlockSizes abc94 (done)", e.id, e?.size?.x, e?.size?.width, e?.size?.y, e?.size?.height); }
c(Q, "setBlockSizes");
function fe(e, o, l = 8) { m.debug(`abc85 layout blocks (=>layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`); let n = e.columns ?? -1; if (m.debug("layoutBlocks columns abc95", e.id, "=>", n, e), e.children && e.children.length > 0) {
    let h = e?.children[0]?.size?.width ?? 0, p = e.children.length * h + (e.children.length - 1) * l;
    m.debug("widthOfChildren 88", p, "posX");
    let s = new Map;
    {
        let b = 0;
        for (let L of e.children) {
            if (!L.size)
                continue;
            let { py: E } = ge(n, b), f = s.get(E) ?? 0;
            L.size.height > f && s.set(E, L.size.height);
            let _ = L?.widthInColumns ?? 1;
            n > 0 && (_ = Math.min(_, n - b % n)), b += _;
        }
    }
    let g = new Map;
    {
        let b = 0, L = [...s.keys()].sort((E, f) => E - f);
        for (let E of L)
            g.set(E, b), b += (s.get(E) ?? 0) + l;
    }
    let x = 0;
    m.debug("abc91 block?.size?.x", e.id, e?.size?.x);
    let k = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -l, S = 0;
    for (let b of e.children) {
        let L = e;
        if (!b.size)
            continue;
        let { width: E, height: f } = b.size, { px: _, py: w } = ge(n, x);
        if (w != S && (S = w, k = e?.size?.x ? e?.size?.x + (-e?.size?.width / 2 || 0) : -l, m.debug("New row in layout for block", e.id, " and child ", b.id, S)), m.debug(`abc89 layout blocks (child) id: ${b.id} Pos: ${x} (px, py) ${_},${w} (${L?.size?.x},${L?.size?.y}) parent: ${L.id} width: ${E}${l}`), L.size) {
            let v = E / 2;
            b.size.x = k + l + v, m.debug(`abc91 layout blocks (calc) px, pyid:${b.id} startingPos=X${k} new startingPosX${b.size.x} ${v} padding=${l} width=${E} halfWidth=${v} => x:${b.size.x} y:${b.size.y} ${b.widthInColumns} (width * (child?.w || 1)) / 2 ${E * (b?.widthInColumns ?? 1) / 2}`), k = b.size.x + v;
            let C = g.get(w) ?? 0, u = s.get(w) ?? f;
            b.size.y = L.size.y - L.size.height / 2 + C + u / 2 + l, m.debug(`abc88 layout blocks (calc) px, pyid:${b.id}startingPosX${k}${l}${v}=>x:${b.size.x}y:${b.size.y}${b.widthInColumns}(width * (child?.w || 1)) / 2${E * (b?.widthInColumns ?? 1) / 2}`);
        }
        b.children && fe(b, o, l);
        let N = b?.widthInColumns ?? 1;
        n > 0 && (N = Math.min(N, n - x % n)), x += N, m.debug("abc88 columnsPos", b, x);
    }
} m.debug(`layout blocks (<==layoutBlocks) ${e.id} x: ${e?.size?.x} y: ${e?.size?.y} width: ${e?.size?.width}`); }
c(fe, "layoutBlocks");
function Se(e, { minX: o, minY: l, maxX: n, maxY: h } = { minX: 0, minY: 0, maxX: 0, maxY: 0 }) { if (e.size && e.id !== "root") {
    let { x: p, y: s, width: g, height: x } = e.size;
    p - g / 2 < o && (o = p - g / 2), s - x / 2 < l && (l = s - x / 2), p + g / 2 > n && (n = p + g / 2), s + x / 2 > h && (h = s + x / 2);
} if (e.children)
    for (let p of e.children)
        ({ minX: o, minY: l, maxX: n, maxY: h } = Se(p, { minX: o, minY: l, maxX: n, maxY: h })); return { minX: o, minY: l, maxX: n, maxY: h }; }
c(Se, "findBounds");
function He(e) { let o = e.getBlock("root"); if (!o)
    return; let l = oe()?.block?.padding ?? 8; Q(o, e, 0, 0, l), fe(o, e, l), m.debug("getBlocks", JSON.stringify(o, null, 2)); let { minX: n, minY: h, maxX: p, maxY: s } = Se(o), g = s - h, x = p - n; return { x: n, y: h, width: x, height: g }; }
c(He, "layout");
function xe(e, o, l = !1) { let n = e, h = "default"; (n?.classes?.length || 0) > 0 && (h = (n?.classes ?? []).join(" ")), h = h + " flowchart-label"; let p = (n?.classes ?? []).flatMap(f => o.getClasses().get(f)?.styles ?? []), s = 0, g = "rect", x; switch (n.type) {
    case "round":
        s = 5, g = "rect";
        break;
    case "composite":
        s = 0, g = "composite", x = 0;
        break;
    case "square":
        g = "rect";
        break;
    case "diamond":
        g = "question";
        break;
    case "hexagon":
        g = "hexagon";
        break;
    case "block_arrow":
        g = "block_arrow";
        break;
    case "odd":
        g = "rect_left_inv_arrow";
        break;
    case "lean_right":
        g = "lean_right";
        break;
    case "lean_left":
        g = "lean_left";
        break;
    case "trapezoid":
        g = "trapezoid";
        break;
    case "inv_trapezoid":
        g = "inv_trapezoid";
        break;
    case "rect_left_inv_arrow":
        g = "rect_left_inv_arrow";
        break;
    case "circle":
        g = "circle";
        break;
    case "ellipse":
        g = "ellipse";
        break;
    case "stadium":
        g = "stadium";
        break;
    case "subroutine":
        g = "subroutine";
        break;
    case "cylinder":
        g = "cylinder";
        break;
    case "group":
        g = "rect";
        break;
    case "doublecircle":
        g = "doublecircle";
        break;
    default: g = "rect";
} let k = Ne(n?.styles ?? []), S = n.label, b = n.size ?? { width: 0, height: 0, x: 0, y: 0 }, L = o.getDiagramId(); return { labelStyle: k.labelStyle, shape: g, label: S, labelText: S, rx: s, ry: s, class: h, cssClasses: h, cssStyles: n?.styles ?? [], cssCompiledStyles: p, style: k.style, id: n.id, domId: L ? `${L}-${n.id}` : n.id, isGroup: !1, directions: n.directions, width: b.width || void 0, height: b.height || void 0, wrappingWidth: b.width || Number.POSITIVE_INFINITY, x: b.x, y: b.y, positioned: l, intersect: void 0, padding: x ?? K()?.block?.padding ?? 0, widthInColumns: n.widthInColumns ?? 1 }; }
c(xe, "getNodeFromBlock");
function Xe(e, o, l) { return R(this, null, function* () { let n = xe(o, l, !1); if (o.type === "group")
    return; let h = K(), p = yield le(e, n, { config: h }), s = p.node()?.getBBox() ?? { width: 0, height: 0 }, g = l.getBlock(n.id); g.size = { width: s.width, height: s.height, x: 0, y: 0, node: p }, l.setBlock(g), p.remove(); }); }
c(Xe, "calculateBlockSize");
function Ge(e, o, l) { return R(this, null, function* () { let n = xe(o, l, !0); if (l.getBlock(n.id).type !== "space") {
    let p = K();
    yield le(e, n, { config: p }), o.intersect = n?.intersect, Ie(n);
} }); }
c(Ge, "insertBlockPositioned");
function $(e, o, l, n) { return R(this, null, function* () { for (let h of o)
    yield n(e, h, l), h.children && (yield $(e, h.children, l, n)); }); }
c($, "performOperations");
function qe(e, o, l) { return R(this, null, function* () { yield $(e, o, l, Xe); }); }
c(qe, "calculateBlockSizes");
function Je(e, o, l) { return R(this, null, function* () { yield $(e, o, l, Ge); }); }
c(Je, "insertBlocks");
function Ze(e, o, l, n, h) { return R(this, null, function* () { let p = new ze({ multigraph: !0, compound: !0 }); p.setGraph({ rankdir: "TB", nodesep: 10, ranksep: 10, marginx: 8, marginy: 8 }); for (let s of l)
    s.size && p.setNode(s.id, { width: s.size.width, height: s.size.height, intersect: s.intersect }); for (let s of o)
    if (s.start && s.end) {
        let g = n.getBlock(s.start), x = n.getBlock(s.end);
        if (g?.size && x?.size) {
            let k = g.size, S = x.size, b = [{ x: k.x, y: k.y }, { x: k.x + (S.x - k.x) / 2, y: k.y + (S.y - k.y) / 2 }, { x: S.x, y: S.y }], L = h ? `${h}-${s.id}` : s.id, E = s.thickness === "thick" ? "edge-thickness-thick" : "edge-thickness-normal", f = s.pattern === "dotted" ? "edge-pattern-dotted" : "edge-pattern-solid", _ = `${E} ${f} flowchart-link LS-a1 LE-b1`;
            Ce(e, V(W({}, s), { id: L, arrowTypeEnd: s.arrowTypeEnd, arrowTypeStart: s.arrowTypeStart, points: b, classes: _ }), {}, "block", p.node(s.start), p.node(s.end), h), s.label && (yield Te(e, V(W({}, s), { label: s.label, labelStyle: "stroke: #333; stroke-width: 1.5px;fill:none;", arrowTypeEnd: s.arrowTypeEnd, arrowTypeStart: s.arrowTypeStart, points: b, classes: _ })), ve(V(W({}, s), { x: b[1].x, y: b[1].y }), { originalPath: b }));
        }
    } }); }
c(Ze, "insertEdges");
var wt = c(function (e, o) { return o.db.getClasses(); }, "getClasses"), _t = c(function (e, o, l, n) { return R(this, null, function* () { let { securityLevel: h, block: p } = K(), s = n.db; s.setDiagramId(o); let g; h === "sandbox" && (g = j("#i" + o)); let x = h === "sandbox" ? j(g.nodes()[0].contentDocument.body) : j("body"), k = h === "sandbox" ? x.select(`[id="${o}"]`) : j(`[id="${o}"]`); Oe(k, ["point", "circle", "cross"], n.type, o); let b = s.getBlocks(), L = s.getBlocksFlat(), E = s.getEdges(), f = k.insert("g").attr("class", "block"); yield qe(f, b, s); let _ = He(s); yield Je(f, b, s), yield Ze(f, E, L, s, o); let w = f.node()?.getBBox(), N = w && Number.isFinite(w.width) && Number.isFinite(w.height) ? w : _; if (N) {
    let v = Math.max(1, Math.round(.125 * (N.width / N.height))), C = N.height + v + 10, u = N.width + 10, { useMaxWidth: r } = p;
    we(k, C, u, !!r), m.debug("Here Bounds", _, N), k.attr("viewBox", `${N.x - 5} ${N.y - 5} ${N.width + 10} ${N.height + 10}`);
} }); }, "draw"), Dt = { draw: _t, getClasses: wt }, Vt = { parser: et, db: kt, renderer: Dt, styles: yt };
export { Vt as diagram };
