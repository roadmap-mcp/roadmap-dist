import { a as r, b as e } from "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { r as GitGraphModule, e as createGitGraphServices };
