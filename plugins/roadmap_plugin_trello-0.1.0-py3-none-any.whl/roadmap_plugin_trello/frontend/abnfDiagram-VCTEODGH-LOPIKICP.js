import { a, b as u, c as f } from "@nf-internal/chunk-FAXKR3FL";
import { a as m } from "@nf-internal/chunk-CDENLQJG";
import { b as p } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import { b as l } from "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-YQ6X4GJP";
import "@nf-internal/chunk-LEJRRF65";
import { b as s } from "@nf-internal/chunk-RZWXGGKD";
import { a as t } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var v = l().RailroadAbnf.parser.LangiumParser, i = t(e => { let r = e.alternatives.map(g); return r.length === 1 ? r[0] : { type: "choice", alternatives: r }; }, "transformAlternation"), g = t(e => { let r = e.elements.map(y); return r.length === 1 ? r[0] : { type: "sequence", elements: r }; }, "transformConcatenation"), b = t(e => { if (e.includes("*")) {
    let [n, o] = e.split("*"), c = n ? parseInt(n, 10) : 0, d = o ? parseInt(o, 10) : 1 / 0;
    return { min: c, max: d };
} let r = parseInt(e, 10); return { min: r, max: r }; }, "parseRepeat"), y = t(e => { let r = A(e.primary); if (!e.repeat)
    return r; let { min: n, max: o } = b(e.repeat); return n === 0 && o === 1 ? { type: "optional", element: r } : { type: "repetition", element: r, min: n, max: o }; }, "transformElement"), A = t(e => { switch (e.$type) {
    case "AbnfStringLiteral": return { type: "terminal", value: e.value };
    case "AbnfNumVal": return { type: "terminal", value: e.value };
    case "AbnfRuleName": return { type: "nonterminal", name: e.name };
    case "AbnfGroup": return i(e.element);
    case "AbnfOptionalGroup": return { type: "optional", element: i(e.element) };
    default: throw new Error(`Unsupported ABNF primary node: ${e.$type}`);
} }, "transformPrimary"), P = t(e => ({ name: e.name, definition: i(e.definition) }), "transformRule"), h = t(e => { m(e, a), e.title && a.setTitle(e.title), e.rules.map(r => a.addRule(P(r))); }, "populateDb"), R = { parse: t(e => { a.clear(), s.debug("[ABNF Parser] Starting Langium parse"); let r = v.parse(e); if (r.lexerErrors.length > 0 || r.parserErrors.length > 0)
        throw new p(r); let n = r.value; s.debug("[ABNF Parser] Parsed rules:", n.rules.length), h(n), s.debug("[ABNF Parser] Parse complete"); }, "parse"), parser: { yy: a } }, I = { parser: R, db: a, renderer: f, styles: u };
export { I as diagram };
