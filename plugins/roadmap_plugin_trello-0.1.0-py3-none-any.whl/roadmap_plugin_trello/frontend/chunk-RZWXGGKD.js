import { a as Tt } from "@nf-internal/chunk-YUSHYV7C";
import { d as Js, e as js } from "@nf-internal/chunk-OSQMNGTH";
var ui = Js((nr, rr) => { (function (t, e) { typeof nr == "object" && typeof rr < "u" ? rr.exports = e() : typeof define == "function" && define.amd ? define(e) : (t = typeof globalThis < "u" ? globalThis : t || self).dayjs = e(); })(nr, function () {
    "use strict";
    var t = 1e3, e = 6e4, n = 36e5, r = "millisecond", i = "second", o = "minute", a = "hour", s = "day", f = "week", u = "month", c = "quarter", h = "year", l = "date", p = "Invalid Date", g = /^(\d{4})[-/]?(\d{1,2})?[-/]?(\d{0,2})[Tt\s]*(\d{1,2})?:?(\d{1,2})?:?(\d{1,2})?[.:]?(\d+)?$/, v = /\[([^\]]+)]|YYYY|YY|M{1,4}|D{1,2}|d{1,4}|H{1,2}|h{1,2}|a|A|m{1,2}|s{1,2}|Z{1,2}|SSS/g, T = { name: "en", weekdays: "Sunday_Monday_Tuesday_Wednesday_Thursday_Friday_Saturday".split("_"), months: "January_February_March_April_May_June_July_August_September_October_November_December".split("_"), ordinal: function (x) { var m = ["th", "st", "nd", "rd"], d = x % 100; return "[" + x + (m[(d - 20) % 10] || m[d] || m[0]) + "]"; } }, k = function (x, m, d) { var M = String(x); return !M || M.length >= m ? x : "" + Array(m + 1 - M.length).join(d) + x; }, $ = { s: k, z: function (x) { var m = -x.utcOffset(), d = Math.abs(m), M = Math.floor(d / 60), w = d % 60; return (m <= 0 ? "+" : "-") + k(M, 2, "0") + ":" + k(w, 2, "0"); }, m: function x(m, d) { if (m.date() < d.date())
            return -x(d, m); var M = 12 * (d.year() - m.year()) + (d.month() - m.month()), w = m.clone().add(M, u), C = d - w < 0, N = m.clone().add(M + (C ? -1 : 1), u); return +(-(M + (d - w) / (C ? w - N : N - w)) || 0); }, a: function (x) { return x < 0 ? Math.ceil(x) || 0 : Math.floor(x); }, p: function (x) { return { M: u, y: h, w: f, d: s, D: l, h: a, m: o, s: i, ms: r, Q: c }[x] || String(x || "").toLowerCase().replace(/s$/, ""); }, u: function (x) { return x === void 0; } }, A = "en", S = {};
    S[A] = T;
    var I = "$isDayjsObject", y = function (x) { return x instanceof B || !(!x || !x[I]); }, E = function x(m, d, M) { var w; if (!m)
        return A; if (typeof m == "string") {
        var C = m.toLowerCase();
        S[C] && (w = C), d && (S[C] = d, w = C);
        var N = m.split("-");
        if (!w && N.length > 1)
            return x(N[0]);
    }
    else {
        var P = m.name;
        S[P] = m, w = P;
    } return !M && w && (A = w), w || !M && A; }, Y = function (x, m) { if (y(x))
        return x.clone(); var d = typeof m == "object" ? m : {}; return d.date = x, d.args = arguments, new B(d); }, D = $;
    D.l = E, D.i = y, D.w = function (x, m) { return Y(x, { locale: m.$L, utc: m.$u, x: m.$x, $offset: m.$offset }); };
    var B = (function () { function x(d) { this.$L = E(d.locale, null, !0), this.parse(d), this.$x = this.$x || d.x || {}, this[I] = !0; } var m = x.prototype; return m.parse = function (d) { this.$d = (function (M) { var w = M.date, C = M.utc; if (w === null)
        return new Date(NaN); if (D.u(w))
        return new Date; if (w instanceof Date)
        return new Date(w); if (typeof w == "string" && !/Z$/i.test(w)) {
        var N = w.match(g);
        if (N) {
            var P = N[2] - 1 || 0, F = (N[7] || "0").substring(0, 3);
            return C ? new Date(Date.UTC(N[1], P, N[3] || 1, N[4] || 0, N[5] || 0, N[6] || 0, F)) : new Date(N[1], P, N[3] || 1, N[4] || 0, N[5] || 0, N[6] || 0, F);
        }
    } return new Date(w); })(d), this.init(); }, m.init = function () { var d = this.$d; this.$y = d.getFullYear(), this.$M = d.getMonth(), this.$D = d.getDate(), this.$W = d.getDay(), this.$H = d.getHours(), this.$m = d.getMinutes(), this.$s = d.getSeconds(), this.$ms = d.getMilliseconds(); }, m.$utils = function () { return D; }, m.isValid = function () { return this.$d.toString() !== p; }, m.isSame = function (d, M) { var w = Y(d); return this.startOf(M) <= w && w <= this.endOf(M); }, m.isAfter = function (d, M) { return Y(d) < this.startOf(M); }, m.isBefore = function (d, M) { return this.endOf(M) < Y(d); }, m.$g = function (d, M, w) { return D.u(d) ? this[M] : this.set(w, d); }, m.unix = function () { return Math.floor(this.valueOf() / 1e3); }, m.valueOf = function () { return this.$d.getTime(); }, m.startOf = function (d, M) { var w = this, C = !!D.u(M) || M, N = D.p(d), P = function (at, G) { var b = D.w(w.$u ? Date.UTC(w.$y, G, at) : new Date(w.$y, G, at), w); return C ? b : b.endOf(s); }, F = function (at, G) { return D.w(w.toDate()[at].apply(w.toDate("s"), (C ? [0, 0, 0, 0] : [23, 59, 59, 999]).slice(G)), w); }, q = this.$W, V = this.$M, K = this.$D, lt = "set" + (this.$u ? "UTC" : ""); switch (N) {
        case h: return C ? P(1, 0) : P(31, 11);
        case u: return C ? P(1, V) : P(0, V + 1);
        case f:
            var Z = this.$locale().weekStart || 0, mt = (q < Z ? q + 7 : q) - Z;
            return P(C ? K - mt : K + (6 - mt), V);
        case s:
        case l: return F(lt + "Hours", 0);
        case a: return F(lt + "Minutes", 1);
        case o: return F(lt + "Seconds", 2);
        case i: return F(lt + "Milliseconds", 3);
        default: return this.clone();
    } }, m.endOf = function (d) { return this.startOf(d, !1); }, m.$set = function (d, M) { var w, C = D.p(d), N = "set" + (this.$u ? "UTC" : ""), P = (w = {}, w[s] = N + "Date", w[l] = N + "Date", w[u] = N + "Month", w[h] = N + "FullYear", w[a] = N + "Hours", w[o] = N + "Minutes", w[i] = N + "Seconds", w[r] = N + "Milliseconds", w)[C], F = C === s ? this.$D + (M - this.$W) : M; if (C === u || C === h) {
        var q = this.clone().set(l, 1);
        q.$d[P](F), q.init(), this.$d = q.set(l, Math.min(this.$D, q.daysInMonth())).$d;
    }
    else
        P && this.$d[P](F); return this.init(), this; }, m.set = function (d, M) { return this.clone().$set(d, M); }, m.get = function (d) { return this[D.p(d)](); }, m.add = function (d, M) { var w, C = this; d = Number(d); var N = D.p(M), P = function (V) { var K = Y(C); return D.w(K.date(K.date() + Math.round(V * d)), C); }; if (N === u)
        return this.set(u, this.$M + d); if (N === h)
        return this.set(h, this.$y + d); if (N === s)
        return P(1); if (N === f)
        return P(7); var F = (w = {}, w[o] = e, w[a] = n, w[i] = t, w)[N] || 1, q = this.$d.getTime() + d * F; return D.w(q, this); }, m.subtract = function (d, M) { return this.add(-1 * d, M); }, m.format = function (d) { var M = this, w = this.$locale(); if (!this.isValid())
        return w.invalidDate || p; var C = d || "YYYY-MM-DDTHH:mm:ssZ", N = D.z(this), P = this.$H, F = this.$m, q = this.$M, V = w.weekdays, K = w.months, lt = w.meridiem, Z = function (G, b, O, R) { return G && (G[b] || G(M, C)) || O[b].slice(0, R); }, mt = function (G) { return D.s(P % 12 || 12, G, "0"); }, at = lt || function (G, b, O) { var R = G < 12 ? "AM" : "PM"; return O ? R.toLowerCase() : R; }; return C.replace(v, function (G, b) { return b || (function (O) { switch (O) {
        case "YY": return String(M.$y).slice(-2);
        case "YYYY": return D.s(M.$y, 4, "0");
        case "M": return q + 1;
        case "MM": return D.s(q + 1, 2, "0");
        case "MMM": return Z(w.monthsShort, q, K, 3);
        case "MMMM": return Z(K, q);
        case "D": return M.$D;
        case "DD": return D.s(M.$D, 2, "0");
        case "d": return String(M.$W);
        case "dd": return Z(w.weekdaysMin, M.$W, V, 2);
        case "ddd": return Z(w.weekdaysShort, M.$W, V, 3);
        case "dddd": return V[M.$W];
        case "H": return String(P);
        case "HH": return D.s(P, 2, "0");
        case "h": return mt(1);
        case "hh": return mt(2);
        case "a": return at(P, F, !0);
        case "A": return at(P, F, !1);
        case "m": return String(F);
        case "mm": return D.s(F, 2, "0");
        case "s": return String(M.$s);
        case "ss": return D.s(M.$s, 2, "0");
        case "SSS": return D.s(M.$ms, 3, "0");
        case "Z": return N;
    } return null; })(G) || N.replace(":", ""); }); }, m.utcOffset = function () { return 15 * -Math.round(this.$d.getTimezoneOffset() / 15); }, m.diff = function (d, M, w) { var C, N = this, P = D.p(M), F = Y(d), q = (F.utcOffset() - this.utcOffset()) * e, V = this - F, K = function () { return D.m(N, F); }; switch (P) {
        case h:
            C = K() / 12;
            break;
        case u:
            C = K();
            break;
        case c:
            C = K() / 3;
            break;
        case f:
            C = (V - q) / 6048e5;
            break;
        case s:
            C = (V - q) / 864e5;
            break;
        case a:
            C = V / n;
            break;
        case o:
            C = V / e;
            break;
        case i:
            C = V / t;
            break;
        default: C = V;
    } return w ? C : D.a(C); }, m.daysInMonth = function () { return this.endOf(u).$D; }, m.$locale = function () { return S[this.$L]; }, m.locale = function (d, M) { if (!d)
        return this.$L; var w = this.clone(), C = E(d, M, !0); return C && (w.$L = C), w; }, m.clone = function () { return D.w(this.$d, this); }, m.toDate = function () { return new Date(this.valueOf()); }, m.toJSON = function () { return this.isValid() ? this.toISOString() : null; }, m.toISOString = function () { return this.$d.toISOString(); }, m.toString = function () { return this.$d.toUTCString(); }, x; })(), L = B.prototype;
    return Y.prototype = L, [["$ms", r], ["$s", i], ["$m", o], ["$H", a], ["$W", s], ["$M", u], ["$y", h], ["$D", l]].forEach(function (x) { L[x[1]] = function (m) { return this.$g(m, x[0], x[1]); }; }), Y.extend = function (x, m) { return x.$i || (x(m, B, Y), x.$i = !0), Y; }, Y.locale = E, Y.isDayjs = y, Y.unix = function (x) { return Y(1e3 * x); }, Y.en = S[A], Y.Ls = S, Y.p = {}, Y;
}); });
var fi = js(ui(), 1), kt = { trace: 0, debug: 1, info: 2, warn: 3, error: 4, fatal: 5 }, ct = { trace: Tt((...t) => { }, "trace"), debug: Tt((...t) => { }, "debug"), info: Tt((...t) => { }, "info"), warn: Tt((...t) => { }, "warn"), error: Tt((...t) => { }, "error"), fatal: Tt((...t) => { }, "fatal") }, Wh = Tt(function (t = "fatal") { let e = kt.fatal; typeof t == "string" ? t.toLowerCase() in kt && (e = kt[t]) : typeof t == "number" && (e = t), ct.trace = () => { }, ct.debug = () => { }, ct.info = () => { }, ct.warn = () => { }, ct.error = () => { }, ct.fatal = () => { }, e <= kt.fatal && (ct.fatal = console.error ? console.error.bind(console, ht("FATAL"), "color: orange") : console.log.bind(console, "\x1B[35m", ht("FATAL"))), e <= kt.error && (ct.error = console.error ? console.error.bind(console, ht("ERROR"), "color: orange") : console.log.bind(console, "\x1B[31m", ht("ERROR"))), e <= kt.warn && (ct.warn = console.warn ? console.warn.bind(console, ht("WARN"), "color: orange") : console.log.bind(console, "\x1B[33m", ht("WARN"))), e <= kt.info && (ct.info = console.info ? console.info.bind(console, ht("INFO"), "color: lightblue") : console.log.bind(console, "\x1B[34m", ht("INFO"))), e <= kt.debug && (ct.debug = console.debug ? console.debug.bind(console, ht("DEBUG"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ht("DEBUG"))), e <= kt.trace && (ct.trace = console.debug ? console.debug.bind(console, ht("TRACE"), "color: lightgreen") : console.log.bind(console, "\x1B[32m", ht("TRACE"))); }, "setLogLevel"), ht = Tt(t => `%c${(0, fi.default)().format("ss.SSS")} : ${t} : `, "format");
function li(t, e) { let n; if (e === void 0)
    for (let r of t)
        r != null && (n < r || n === void 0 && r >= r) && (n = r);
else {
    let r = -1;
    for (let i of t)
        (i = e(i, ++r, t)) != null && (n < i || n === void 0 && i >= i) && (n = i);
} return n; }
function ci(t, e) { let n; if (e === void 0)
    for (let r of t)
        r != null && (n > r || n === void 0 && r >= r) && (n = r);
else {
    let r = -1;
    for (let i of t)
        (i = e(i, ++r, t)) != null && (n > i || n === void 0 && i >= i) && (n = i);
} return n; }
function Bt(t, e) { return t == null || e == null ? NaN : t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN; }
function ir(t, e) { return t == null || e == null ? NaN : e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN; }
function qt(t) { let e, n, r; t.length !== 2 ? (e = Bt, n = (s, f) => Bt(t(s), f), r = (s, f) => t(s) - f) : (e = t === Bt || t === ir ? t : tu, n = t, r = t); function i(s, f, u = 0, c = s.length) { if (u < c) {
    if (e(f, f) !== 0)
        return c;
    do {
        let h = u + c >>> 1;
        n(s[h], f) < 0 ? u = h + 1 : c = h;
    } while (u < c);
} return u; } function o(s, f, u = 0, c = s.length) { if (u < c) {
    if (e(f, f) !== 0)
        return c;
    do {
        let h = u + c >>> 1;
        n(s[h], f) <= 0 ? u = h + 1 : c = h;
    } while (u < c);
} return u; } function a(s, f, u = 0, c = s.length) { let h = i(s, f, u, c - 1); return h > u && r(s[h - 1], f) > -r(s[h], f) ? h - 1 : h; } return { left: i, center: a, right: o }; }
function tu() { return 0; }
function or(t) { return t === null ? NaN : +t; }
var hi = qt(Bt), pi = hi.right, eu = hi.left, nu = qt(or).center, ar = pi;
var ue = class extends Map {
    constructor(e, n = ou) { if (super(), Object.defineProperties(this, { _intern: { value: new Map }, _key: { value: n } }), e != null)
        for (let [r, i] of e)
            this.set(r, i); }
    get(e) { return super.get(mi(this, e)); }
    has(e) { return super.has(mi(this, e)); }
    set(e, n) { return super.set(ru(this, e), n); }
    delete(e) { return super.delete(iu(this, e)); }
};
function mi({ _intern: t, _key: e }, n) { let r = e(n); return t.has(r) ? t.get(r) : n; }
function ru({ _intern: t, _key: e }, n) { let r = e(n); return t.has(r) ? t.get(r) : (t.set(r, n), n); }
function iu({ _intern: t, _key: e }, n) { let r = e(n); return t.has(r) && (n = t.get(r), t.delete(r)), n; }
function ou(t) { return t !== null && typeof t == "object" ? t.valueOf() : t; }
var au = Math.sqrt(50), su = Math.sqrt(10), uu = Math.sqrt(2);
function on(t, e, n) { let r = (e - t) / Math.max(0, n), i = Math.floor(Math.log10(r)), o = r / Math.pow(10, i), a = o >= au ? 10 : o >= su ? 5 : o >= uu ? 2 : 1, s, f, u; return i < 0 ? (u = Math.pow(10, -i) / a, s = Math.round(t * u), f = Math.round(e * u), s / u < t && ++s, f / u > e && --f, u = -u) : (u = Math.pow(10, i) * a, s = Math.round(t / u), f = Math.round(e / u), s * u < t && ++s, f * u > e && --f), f < s && .5 <= n && n < 2 ? on(t, e, n * 2) : [s, f, u]; }
function an(t, e, n) { if (e = +e, t = +t, n = +n, !(n > 0))
    return []; if (t === e)
    return [t]; let r = e < t, [i, o, a] = r ? on(e, t, n) : on(t, e, n); if (!(o >= i))
    return []; let s = o - i + 1, f = new Array(s); if (r)
    if (a < 0)
        for (let u = 0; u < s; ++u)
            f[u] = (o - u) / -a;
    else
        for (let u = 0; u < s; ++u)
            f[u] = (o - u) * a;
else if (a < 0)
    for (let u = 0; u < s; ++u)
        f[u] = (i + u) / -a;
else
    for (let u = 0; u < s; ++u)
        f[u] = (i + u) * a; return f; }
function De(t, e, n) { return e = +e, t = +t, n = +n, on(t, e, n)[2]; }
function fe(t, e, n) { e = +e, t = +t, n = +n; let r = e < t, i = r ? De(e, t, n) : De(t, e, n); return (r ? -1 : 1) * (i < 0 ? 1 / -i : i); }
function sn(t, e, n) { t = +t, e = +e, n = (i = arguments.length) < 2 ? (e = t, t = 0, 1) : i < 3 ? 1 : +n; for (var r = -1, i = Math.max(0, Math.ceil((e - t) / n)) | 0, o = new Array(i); ++r < i;)
    o[r] = t + r * n; return o; }
function di(t) { return t; }
var fn = 1, sr = 2, ur = 3, un = 4, xi = 1e-6;
function fu(t) { return "translate(" + t + ",0)"; }
function lu(t) { return "translate(0," + t + ")"; }
function cu(t) { return e => +t(e); }
function hu(t, e) { return e = Math.max(0, t.bandwidth() - e * 2) / 2, t.round() && (e = Math.round(e)), n => +t(n) + e; }
function pu() { return !this.__axis; }
function _i(t, e) { var n = [], r = null, i = null, o = 6, a = 6, s = 3, f = typeof window < "u" && window.devicePixelRatio > 1 ? 0 : .5, u = t === fn || t === un ? -1 : 1, c = t === un || t === sr ? "x" : "y", h = t === fn || t === ur ? fu : lu; function l(p) { var g = r ?? (e.ticks ? e.ticks.apply(e, n) : e.domain()), v = i ?? (e.tickFormat ? e.tickFormat.apply(e, n) : di), T = Math.max(o, 0) + s, k = e.range(), $ = +k[0] + f, A = +k[k.length - 1] + f, S = (e.bandwidth ? hu : cu)(e.copy(), f), I = p.selection ? p.selection() : p, y = I.selectAll(".domain").data([null]), E = I.selectAll(".tick").data(g, e).order(), Y = E.exit(), D = E.enter().append("g").attr("class", "tick"), B = E.select("line"), L = E.select("text"); y = y.merge(y.enter().insert("path", ".tick").attr("class", "domain").attr("stroke", "currentColor")), E = E.merge(D), B = B.merge(D.append("line").attr("stroke", "currentColor").attr(c + "2", u * o)), L = L.merge(D.append("text").attr("fill", "currentColor").attr(c, u * T).attr("dy", t === fn ? "0em" : t === ur ? "0.71em" : "0.32em")), p !== I && (y = y.transition(p), E = E.transition(p), B = B.transition(p), L = L.transition(p), Y = Y.transition(p).attr("opacity", xi).attr("transform", function (x) { return isFinite(x = S(x)) ? h(x + f) : this.getAttribute("transform"); }), D.attr("opacity", xi).attr("transform", function (x) { var m = this.parentNode.__axis; return h((m && isFinite(m = m(x)) ? m : S(x)) + f); })), Y.remove(), y.attr("d", t === un || t === sr ? a ? "M" + u * a + "," + $ + "H" + f + "V" + A + "H" + u * a : "M" + f + "," + $ + "V" + A : a ? "M" + $ + "," + u * a + "V" + f + "H" + A + "V" + u * a : "M" + $ + "," + f + "H" + A), E.attr("opacity", 1).attr("transform", function (x) { return h(S(x) + f); }), B.attr(c + "2", u * o), L.attr(c, u * T).text(v), I.filter(pu).attr("fill", "none").attr("font-size", 10).attr("font-family", "sans-serif").attr("text-anchor", t === sr ? "start" : t === un ? "end" : "middle"), I.each(function () { this.__axis = S; }); } return l.scale = function (p) { return arguments.length ? (e = p, l) : e; }, l.ticks = function () { return n = Array.from(arguments), l; }, l.tickArguments = function (p) { return arguments.length ? (n = p == null ? [] : Array.from(p), l) : n.slice(); }, l.tickValues = function (p) { return arguments.length ? (r = p == null ? null : Array.from(p), l) : r && r.slice(); }, l.tickFormat = function (p) { return arguments.length ? (i = p, l) : i; }, l.tickSize = function (p) { return arguments.length ? (o = a = +p, l) : o; }, l.tickSizeInner = function (p) { return arguments.length ? (o = +p, l) : o; }, l.tickSizeOuter = function (p) { return arguments.length ? (a = +p, l) : a; }, l.tickPadding = function (p) { return arguments.length ? (s = +p, l) : s; }, l.offset = function (p) { return arguments.length ? (f = +p, l) : f; }, l; }
function mu(t) { return _i(fn, t); }
function du(t) { return _i(ur, t); }
function xu() { }
function Wt(t) { return t == null ? xu : function () { return this.querySelector(t); }; }
function gi(t) { typeof t != "function" && (t = Wt(t)); for (var e = this._groups, n = e.length, r = new Array(n), i = 0; i < n; ++i)
    for (var o = e[i], a = o.length, s = r[i] = new Array(a), f, u, c = 0; c < a; ++c)
        (f = o[c]) && (u = t.call(f, f.__data__, c, o)) && ("__data__" in f && (u.__data__ = f.__data__), s[c] = u); return new X(r, this._parents); }
function fr(t) { return t == null ? [] : Array.isArray(t) ? t : Array.from(t); }
function _u() { return []; }
function $e(t) { return t == null ? _u : function () { return this.querySelectorAll(t); }; }
function gu(t) { return function () { return fr(t.apply(this, arguments)); }; }
function yi(t) { typeof t == "function" ? t = gu(t) : t = $e(t); for (var e = this._groups, n = e.length, r = [], i = [], o = 0; o < n; ++o)
    for (var a = e[o], s = a.length, f, u = 0; u < s; ++u)
        (f = a[u]) && (r.push(t.call(f, f.__data__, u, a)), i.push(f)); return new X(r, i); }
function Oe(t) { return function () { return this.matches(t); }; }
function ln(t) { return function (e) { return e.matches(t); }; }
var yu = Array.prototype.find;
function vu(t) { return function () { return yu.call(this.children, t); }; }
function wu() { return this.firstElementChild; }
function vi(t) { return this.select(t == null ? wu : vu(typeof t == "function" ? t : ln(t))); }
var bu = Array.prototype.filter;
function Mu() { return Array.from(this.children); }
function Tu(t) { return function () { return bu.call(this.children, t); }; }
function wi(t) { return this.selectAll(t == null ? Mu : Tu(typeof t == "function" ? t : ln(t))); }
function bi(t) { typeof t != "function" && (t = Oe(t)); for (var e = this._groups, n = e.length, r = new Array(n), i = 0; i < n; ++i)
    for (var o = e[i], a = o.length, s = r[i] = [], f, u = 0; u < a; ++u)
        (f = o[u]) && t.call(f, f.__data__, u, o) && s.push(f); return new X(r, this._parents); }
function cn(t) { return new Array(t.length); }
function Mi() { return new X(this._enter || this._groups.map(cn), this._parents); }
function Ie(t, e) { this.ownerDocument = t.ownerDocument, this.namespaceURI = t.namespaceURI, this._next = null, this._parent = t, this.__data__ = e; }
Ie.prototype = { constructor: Ie, appendChild: function (t) { return this._parent.insertBefore(t, this._next); }, insertBefore: function (t, e) { return this._parent.insertBefore(t, e); }, querySelector: function (t) { return this._parent.querySelector(t); }, querySelectorAll: function (t) { return this._parent.querySelectorAll(t); } };
function Ti(t) { return function () { return t; }; }
function ku(t, e, n, r, i, o) { for (var a = 0, s, f = e.length, u = o.length; a < u; ++a)
    (s = e[a]) ? (s.__data__ = o[a], r[a] = s) : n[a] = new Ie(t, o[a]); for (; a < f; ++a)
    (s = e[a]) && (i[a] = s); }
function Su(t, e, n, r, i, o, a) { var s, f, u = new Map, c = e.length, h = o.length, l = new Array(c), p; for (s = 0; s < c; ++s)
    (f = e[s]) && (l[s] = p = a.call(f, f.__data__, s, e) + "", u.has(p) ? i[s] = f : u.set(p, f)); for (s = 0; s < h; ++s)
    p = a.call(t, o[s], s, o) + "", (f = u.get(p)) ? (r[s] = f, f.__data__ = o[s], u.delete(p)) : n[s] = new Ie(t, o[s]); for (s = 0; s < c; ++s)
    (f = e[s]) && u.get(l[s]) === f && (i[s] = f); }
function Cu(t) { return t.__data__; }
function ki(t, e) { if (!arguments.length)
    return Array.from(this, Cu); var n = e ? Su : ku, r = this._parents, i = this._groups; typeof t != "function" && (t = Ti(t)); for (var o = i.length, a = new Array(o), s = new Array(o), f = new Array(o), u = 0; u < o; ++u) {
    var c = r[u], h = i[u], l = h.length, p = Nu(t.call(c, c && c.__data__, u, r)), g = p.length, v = s[u] = new Array(g), T = a[u] = new Array(g), k = f[u] = new Array(l);
    n(c, h, v, T, k, p, e);
    for (var $ = 0, A = 0, S, I; $ < g; ++$)
        if (S = v[$]) {
            for ($ >= A && (A = $ + 1); !(I = T[A]) && ++A < g;)
                ;
            S._next = I || null;
        }
} return a = new X(a, r), a._enter = s, a._exit = f, a; }
function Nu(t) { return typeof t == "object" && "length" in t ? t : Array.from(t); }
function Si() { return new X(this._exit || this._groups.map(cn), this._parents); }
function Ci(t, e, n) { var r = this.enter(), i = this, o = this.exit(); return typeof t == "function" ? (r = t(r), r && (r = r.selection())) : r = r.append(t + ""), e != null && (i = e(i), i && (i = i.selection())), n == null ? o.remove() : n(o), r && i ? r.merge(i).order() : i; }
function Ni(t) { for (var e = t.selection ? t.selection() : t, n = this._groups, r = e._groups, i = n.length, o = r.length, a = Math.min(i, o), s = new Array(i), f = 0; f < a; ++f)
    for (var u = n[f], c = r[f], h = u.length, l = s[f] = new Array(h), p, g = 0; g < h; ++g)
        (p = u[g] || c[g]) && (l[g] = p); for (; f < i; ++f)
    s[f] = n[f]; return new X(s, this._parents); }
function Ai() { for (var t = this._groups, e = -1, n = t.length; ++e < n;)
    for (var r = t[e], i = r.length - 1, o = r[i], a; --i >= 0;)
        (a = r[i]) && (o && a.compareDocumentPosition(o) ^ 4 && o.parentNode.insertBefore(a, o), o = a); return this; }
function Di(t) { t || (t = Au); function e(h, l) { return h && l ? t(h.__data__, l.__data__) : !h - !l; } for (var n = this._groups, r = n.length, i = new Array(r), o = 0; o < r; ++o) {
    for (var a = n[o], s = a.length, f = i[o] = new Array(s), u, c = 0; c < s; ++c)
        (u = a[c]) && (f[c] = u);
    f.sort(e);
} return new X(i, this._parents).order(); }
function Au(t, e) { return t < e ? -1 : t > e ? 1 : t >= e ? 0 : NaN; }
function $i() { var t = arguments[0]; return arguments[0] = this, t.apply(null, arguments), this; }
function Oi() { return Array.from(this); }
function Ii() { for (var t = this._groups, e = 0, n = t.length; e < n; ++e)
    for (var r = t[e], i = 0, o = r.length; i < o; ++i) {
        var a = r[i];
        if (a)
            return a;
    } return null; }
function Ei() { let t = 0; for (let e of this)
    ++t; return t; }
function Ri() { return !this.node(); }
function Yi(t) { for (var e = this._groups, n = 0, r = e.length; n < r; ++n)
    for (var i = e[n], o = 0, a = i.length, s; o < a; ++o)
        (s = i[o]) && t.call(s, s.__data__, o, i); return this; }
var hn = "http://www.w3.org/1999/xhtml", lr = { svg: "http://www.w3.org/2000/svg", xhtml: hn, xlink: "http://www.w3.org/1999/xlink", xml: "http://www.w3.org/XML/1998/namespace", xmlns: "http://www.w3.org/2000/xmlns/" };
function St(t) { var e = t += "", n = e.indexOf(":"); return n >= 0 && (e = t.slice(0, n)) !== "xmlns" && (t = t.slice(n + 1)), lr.hasOwnProperty(e) ? { space: lr[e], local: t } : t; }
function Du(t) { return function () { this.removeAttribute(t); }; }
function $u(t) { return function () { this.removeAttributeNS(t.space, t.local); }; }
function Ou(t, e) { return function () { this.setAttribute(t, e); }; }
function Iu(t, e) { return function () { this.setAttributeNS(t.space, t.local, e); }; }
function Eu(t, e) { return function () { var n = e.apply(this, arguments); n == null ? this.removeAttribute(t) : this.setAttribute(t, n); }; }
function Ru(t, e) { return function () { var n = e.apply(this, arguments); n == null ? this.removeAttributeNS(t.space, t.local) : this.setAttributeNS(t.space, t.local, n); }; }
function Pi(t, e) { var n = St(t); if (arguments.length < 2) {
    var r = this.node();
    return n.local ? r.getAttributeNS(n.space, n.local) : r.getAttribute(n);
} return this.each((e == null ? n.local ? $u : Du : typeof e == "function" ? n.local ? Ru : Eu : n.local ? Iu : Ou)(n, e)); }
function pn(t) { return t.ownerDocument && t.ownerDocument.defaultView || t.document && t || t.defaultView; }
function Yu(t) { return function () { this.style.removeProperty(t); }; }
function Pu(t, e, n) { return function () { this.style.setProperty(t, e, n); }; }
function Fu(t, e, n) { return function () { var r = e.apply(this, arguments); r == null ? this.style.removeProperty(t) : this.style.setProperty(t, r, n); }; }
function Fi(t, e, n) { return arguments.length > 1 ? this.each((e == null ? Yu : typeof e == "function" ? Fu : Pu)(t, e, n ?? "")) : It(this.node(), t); }
function It(t, e) { return t.style.getPropertyValue(e) || pn(t).getComputedStyle(t, null).getPropertyValue(e); }
function Uu(t) { return function () { delete this[t]; }; }
function zu(t, e) { return function () { this[t] = e; }; }
function Lu(t, e) { return function () { var n = e.apply(this, arguments); n == null ? delete this[t] : this[t] = n; }; }
function Ui(t, e) { return arguments.length > 1 ? this.each((e == null ? Uu : typeof e == "function" ? Lu : zu)(t, e)) : this.node()[t]; }
function zi(t) { return t.trim().split(/^|\s+/); }
function cr(t) { return t.classList || new Li(t); }
function Li(t) { this._node = t, this._names = zi(t.getAttribute("class") || ""); }
Li.prototype = { add: function (t) { var e = this._names.indexOf(t); e < 0 && (this._names.push(t), this._node.setAttribute("class", this._names.join(" "))); }, remove: function (t) { var e = this._names.indexOf(t); e >= 0 && (this._names.splice(e, 1), this._node.setAttribute("class", this._names.join(" "))); }, contains: function (t) { return this._names.indexOf(t) >= 0; } };
function Hi(t, e) { for (var n = cr(t), r = -1, i = e.length; ++r < i;)
    n.add(e[r]); }
function Bi(t, e) { for (var n = cr(t), r = -1, i = e.length; ++r < i;)
    n.remove(e[r]); }
function Hu(t) { return function () { Hi(this, t); }; }
function Bu(t) { return function () { Bi(this, t); }; }
function qu(t, e) { return function () { (e.apply(this, arguments) ? Hi : Bi)(this, t); }; }
function qi(t, e) { var n = zi(t + ""); if (arguments.length < 2) {
    for (var r = cr(this.node()), i = -1, o = n.length; ++i < o;)
        if (!r.contains(n[i]))
            return !1;
    return !0;
} return this.each((typeof e == "function" ? qu : e ? Hu : Bu)(n, e)); }
function Wu() { this.textContent = ""; }
function Vu(t) { return function () { this.textContent = t; }; }
function Xu(t) { return function () { var e = t.apply(this, arguments); this.textContent = e ?? ""; }; }
function Wi(t) { return arguments.length ? this.each(t == null ? Wu : (typeof t == "function" ? Xu : Vu)(t)) : this.node().textContent; }
function Gu() { this.innerHTML = ""; }
function Zu(t) { return function () { this.innerHTML = t; }; }
function Qu(t) { return function () { var e = t.apply(this, arguments); this.innerHTML = e ?? ""; }; }
function Vi(t) { return arguments.length ? this.each(t == null ? Gu : (typeof t == "function" ? Qu : Zu)(t)) : this.node().innerHTML; }
function Ku() { this.nextSibling && this.parentNode.appendChild(this); }
function Xi() { return this.each(Ku); }
function Ju() { this.previousSibling && this.parentNode.insertBefore(this, this.parentNode.firstChild); }
function Gi() { return this.each(Ju); }
function ju(t) { return function () { var e = this.ownerDocument, n = this.namespaceURI; return n === hn && e.documentElement.namespaceURI === hn ? e.createElement(t) : e.createElementNS(n, t); }; }
function tf(t) { return function () { return this.ownerDocument.createElementNS(t.space, t.local); }; }
function mn(t) { var e = St(t); return (e.local ? tf : ju)(e); }
function Zi(t) { var e = typeof t == "function" ? t : mn(t); return this.select(function () { return this.appendChild(e.apply(this, arguments)); }); }
function ef() { return null; }
function Qi(t, e) { var n = typeof t == "function" ? t : mn(t), r = e == null ? ef : typeof e == "function" ? e : Wt(e); return this.select(function () { return this.insertBefore(n.apply(this, arguments), r.apply(this, arguments) || null); }); }
function nf() { var t = this.parentNode; t && t.removeChild(this); }
function Ki() { return this.each(nf); }
function rf() { var t = this.cloneNode(!1), e = this.parentNode; return e ? e.insertBefore(t, this.nextSibling) : t; }
function of() { var t = this.cloneNode(!0), e = this.parentNode; return e ? e.insertBefore(t, this.nextSibling) : t; }
function Ji(t) { return this.select(t ? of : rf); }
function ji(t) { return arguments.length ? this.property("__data__", t) : this.node().__data__; }
function af(t) { return function (e) { t.call(this, e, this.__data__); }; }
function sf(t) { return t.trim().split(/^|\s+/).map(function (e) { var n = "", r = e.indexOf("."); return r >= 0 && (n = e.slice(r + 1), e = e.slice(0, r)), { type: e, name: n }; }); }
function uf(t) { return function () { var e = this.__on; if (e) {
    for (var n = 0, r = -1, i = e.length, o; n < i; ++n)
        o = e[n], (!t.type || o.type === t.type) && o.name === t.name ? this.removeEventListener(o.type, o.listener, o.options) : e[++r] = o;
    ++r ? e.length = r : delete this.__on;
} }; }
function ff(t, e, n) { return function () { var r = this.__on, i, o = af(e); if (r) {
    for (var a = 0, s = r.length; a < s; ++a)
        if ((i = r[a]).type === t.type && i.name === t.name) {
            this.removeEventListener(i.type, i.listener, i.options), this.addEventListener(i.type, i.listener = o, i.options = n), i.value = e;
            return;
        }
} this.addEventListener(t.type, o, n), i = { type: t.type, name: t.name, value: e, listener: o, options: n }, r ? r.push(i) : this.__on = [i]; }; }
function to(t, e, n) { var r = sf(t + ""), i, o = r.length, a; if (arguments.length < 2) {
    var s = this.node().__on;
    if (s) {
        for (var f = 0, u = s.length, c; f < u; ++f)
            for (i = 0, c = s[f]; i < o; ++i)
                if ((a = r[i]).type === c.type && a.name === c.name)
                    return c.value;
    }
    return;
} for (s = e ? ff : uf, i = 0; i < o; ++i)
    this.each(s(r[i], e, n)); return this; }
function eo(t, e, n) { var r = pn(t), i = r.CustomEvent; typeof i == "function" ? i = new i(e, n) : (i = r.document.createEvent("Event"), n ? (i.initEvent(e, n.bubbles, n.cancelable), i.detail = n.detail) : i.initEvent(e, !1, !1)), t.dispatchEvent(i); }
function lf(t, e) { return function () { return eo(this, t, e); }; }
function cf(t, e) { return function () { return eo(this, t, e.apply(this, arguments)); }; }
function no(t, e) { return this.each((typeof e == "function" ? cf : lf)(t, e)); }
function* ro() { for (var t = this._groups, e = 0, n = t.length; e < n; ++e)
    for (var r = t[e], i = 0, o = r.length, a; i < o; ++i)
        (a = r[i]) && (yield a); }
var hr = [null];
function X(t, e) { this._groups = t, this._parents = e; }
function io() { return new X([[document.documentElement]], hr); }
function hf() { return this; }
X.prototype = io.prototype = { constructor: X, select: gi, selectAll: yi, selectChild: vi, selectChildren: wi, filter: bi, data: ki, enter: Mi, exit: Si, join: Ci, merge: Ni, selection: hf, order: Ai, sort: Di, call: $i, nodes: Oi, node: Ii, size: Ei, empty: Ri, each: Yi, attr: Pi, style: Fi, property: Ui, classed: qi, text: Wi, html: Vi, raise: Xi, lower: Gi, append: Zi, insert: Qi, remove: Ki, clone: Ji, datum: ji, on: to, dispatch: no, [Symbol.iterator]: ro };
var Ct = io;
function pf(t) { return typeof t == "string" ? new X([[document.querySelector(t)]], [document.documentElement]) : new X([[t]], hr); }
function Vt(t, e, n) { t.prototype = e.prototype = n, n.constructor = t; }
function le(t, e) { var n = Object.create(t.prototype); for (var r in e)
    n[r] = e[r]; return n; }
function Et() { }
var Ee = .7, _n = 1 / Ee, ce = "\\s*([+-]?\\d+)\\s*", Re = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)\\s*", yt = "\\s*([+-]?(?:\\d*\\.)?\\d+(?:[eE][+-]?\\d+)?)%\\s*", mf = /^#([0-9a-f]{3,8})$/, df = new RegExp(`^rgb\\(${ce},${ce},${ce}\\)$`), xf = new RegExp(`^rgb\\(${yt},${yt},${yt}\\)$`), _f = new RegExp(`^rgba\\(${ce},${ce},${ce},${Re}\\)$`), gf = new RegExp(`^rgba\\(${yt},${yt},${yt},${Re}\\)$`), yf = new RegExp(`^hsl\\(${Re},${yt},${yt}\\)$`), vf = new RegExp(`^hsla\\(${Re},${yt},${yt},${Re}\\)$`), oo = { aliceblue: 15792383, antiquewhite: 16444375, aqua: 65535, aquamarine: 8388564, azure: 15794175, beige: 16119260, bisque: 16770244, black: 0, blanchedalmond: 16772045, blue: 255, blueviolet: 9055202, brown: 10824234, burlywood: 14596231, cadetblue: 6266528, chartreuse: 8388352, chocolate: 13789470, coral: 16744272, cornflowerblue: 6591981, cornsilk: 16775388, crimson: 14423100, cyan: 65535, darkblue: 139, darkcyan: 35723, darkgoldenrod: 12092939, darkgray: 11119017, darkgreen: 25600, darkgrey: 11119017, darkkhaki: 12433259, darkmagenta: 9109643, darkolivegreen: 5597999, darkorange: 16747520, darkorchid: 10040012, darkred: 9109504, darksalmon: 15308410, darkseagreen: 9419919, darkslateblue: 4734347, darkslategray: 3100495, darkslategrey: 3100495, darkturquoise: 52945, darkviolet: 9699539, deeppink: 16716947, deepskyblue: 49151, dimgray: 6908265, dimgrey: 6908265, dodgerblue: 2003199, firebrick: 11674146, floralwhite: 16775920, forestgreen: 2263842, fuchsia: 16711935, gainsboro: 14474460, ghostwhite: 16316671, gold: 16766720, goldenrod: 14329120, gray: 8421504, green: 32768, greenyellow: 11403055, grey: 8421504, honeydew: 15794160, hotpink: 16738740, indianred: 13458524, indigo: 4915330, ivory: 16777200, khaki: 15787660, lavender: 15132410, lavenderblush: 16773365, lawngreen: 8190976, lemonchiffon: 16775885, lightblue: 11393254, lightcoral: 15761536, lightcyan: 14745599, lightgoldenrodyellow: 16448210, lightgray: 13882323, lightgreen: 9498256, lightgrey: 13882323, lightpink: 16758465, lightsalmon: 16752762, lightseagreen: 2142890, lightskyblue: 8900346, lightslategray: 7833753, lightslategrey: 7833753, lightsteelblue: 11584734, lightyellow: 16777184, lime: 65280, limegreen: 3329330, linen: 16445670, magenta: 16711935, maroon: 8388608, mediumaquamarine: 6737322, mediumblue: 205, mediumorchid: 12211667, mediumpurple: 9662683, mediumseagreen: 3978097, mediumslateblue: 8087790, mediumspringgreen: 64154, mediumturquoise: 4772300, mediumvioletred: 13047173, midnightblue: 1644912, mintcream: 16121850, mistyrose: 16770273, moccasin: 16770229, navajowhite: 16768685, navy: 128, oldlace: 16643558, olive: 8421376, olivedrab: 7048739, orange: 16753920, orangered: 16729344, orchid: 14315734, palegoldenrod: 15657130, palegreen: 10025880, paleturquoise: 11529966, palevioletred: 14381203, papayawhip: 16773077, peachpuff: 16767673, peru: 13468991, pink: 16761035, plum: 14524637, powderblue: 11591910, purple: 8388736, rebeccapurple: 6697881, red: 16711680, rosybrown: 12357519, royalblue: 4286945, saddlebrown: 9127187, salmon: 16416882, sandybrown: 16032864, seagreen: 3050327, seashell: 16774638, sienna: 10506797, silver: 12632256, skyblue: 8900331, slateblue: 6970061, slategray: 7372944, slategrey: 7372944, snow: 16775930, springgreen: 65407, steelblue: 4620980, tan: 13808780, teal: 32896, thistle: 14204888, tomato: 16737095, turquoise: 4251856, violet: 15631086, wheat: 16113331, white: 16777215, whitesmoke: 16119285, yellow: 16776960, yellowgreen: 10145074 };
Vt(Et, xt, { copy(t) { return Object.assign(new this.constructor, this, t); }, displayable() { return this.rgb().displayable(); }, hex: ao, formatHex: ao, formatHex8: wf, formatHsl: bf, formatRgb: so, toString: so });
function ao() { return this.rgb().formatHex(); }
function wf() { return this.rgb().formatHex8(); }
function bf() { return po(this).formatHsl(); }
function so() { return this.rgb().formatRgb(); }
function xt(t) { var e, n; return t = (t + "").trim().toLowerCase(), (e = mf.exec(t)) ? (n = e[1].length, e = parseInt(e[1], 16), n === 6 ? uo(e) : n === 3 ? new tt(e >> 8 & 15 | e >> 4 & 240, e >> 4 & 15 | e & 240, (e & 15) << 4 | e & 15, 1) : n === 8 ? dn(e >> 24 & 255, e >> 16 & 255, e >> 8 & 255, (e & 255) / 255) : n === 4 ? dn(e >> 12 & 15 | e >> 8 & 240, e >> 8 & 15 | e >> 4 & 240, e >> 4 & 15 | e & 240, ((e & 15) << 4 | e & 15) / 255) : null) : (e = df.exec(t)) ? new tt(e[1], e[2], e[3], 1) : (e = xf.exec(t)) ? new tt(e[1] * 255 / 100, e[2] * 255 / 100, e[3] * 255 / 100, 1) : (e = _f.exec(t)) ? dn(e[1], e[2], e[3], e[4]) : (e = gf.exec(t)) ? dn(e[1] * 255 / 100, e[2] * 255 / 100, e[3] * 255 / 100, e[4]) : (e = yf.exec(t)) ? co(e[1], e[2] / 100, e[3] / 100, 1) : (e = vf.exec(t)) ? co(e[1], e[2] / 100, e[3] / 100, e[4]) : oo.hasOwnProperty(t) ? uo(oo[t]) : t === "transparent" ? new tt(NaN, NaN, NaN, 0) : null; }
function uo(t) { return new tt(t >> 16 & 255, t >> 8 & 255, t & 255, 1); }
function dn(t, e, n, r) { return r <= 0 && (t = e = n = NaN), new tt(t, e, n, r); }
function mr(t) { return t instanceof Et || (t = xt(t)), t ? (t = t.rgb(), new tt(t.r, t.g, t.b, t.opacity)) : new tt; }
function he(t, e, n, r) { return arguments.length === 1 ? mr(t) : new tt(t, e, n, r ?? 1); }
function tt(t, e, n, r) { this.r = +t, this.g = +e, this.b = +n, this.opacity = +r; }
Vt(tt, he, le(Et, { brighter(t) { return t = t == null ? _n : Math.pow(_n, t), new tt(this.r * t, this.g * t, this.b * t, this.opacity); }, darker(t) { return t = t == null ? Ee : Math.pow(Ee, t), new tt(this.r * t, this.g * t, this.b * t, this.opacity); }, rgb() { return this; }, clamp() { return new tt(Gt(this.r), Gt(this.g), Gt(this.b), gn(this.opacity)); }, displayable() { return -.5 <= this.r && this.r < 255.5 && -.5 <= this.g && this.g < 255.5 && -.5 <= this.b && this.b < 255.5 && 0 <= this.opacity && this.opacity <= 1; }, hex: fo, formatHex: fo, formatHex8: Mf, formatRgb: lo, toString: lo }));
function fo() { return `#${Xt(this.r)}${Xt(this.g)}${Xt(this.b)}`; }
function Mf() { return `#${Xt(this.r)}${Xt(this.g)}${Xt(this.b)}${Xt((isNaN(this.opacity) ? 1 : this.opacity) * 255)}`; }
function lo() { let t = gn(this.opacity); return `${t === 1 ? "rgb(" : "rgba("}${Gt(this.r)}, ${Gt(this.g)}, ${Gt(this.b)}${t === 1 ? ")" : `, ${t})`}`; }
function gn(t) { return isNaN(t) ? 1 : Math.max(0, Math.min(1, t)); }
function Gt(t) { return Math.max(0, Math.min(255, Math.round(t) || 0)); }
function Xt(t) { return t = Gt(t), (t < 16 ? "0" : "") + t.toString(16); }
function co(t, e, n, r) { return r <= 0 ? t = e = n = NaN : n <= 0 || n >= 1 ? t = e = NaN : e <= 0 && (t = NaN), new dt(t, e, n, r); }
function po(t) { if (t instanceof dt)
    return new dt(t.h, t.s, t.l, t.opacity); if (t instanceof Et || (t = xt(t)), !t)
    return new dt; if (t instanceof dt)
    return t; t = t.rgb(); var e = t.r / 255, n = t.g / 255, r = t.b / 255, i = Math.min(e, n, r), o = Math.max(e, n, r), a = NaN, s = o - i, f = (o + i) / 2; return s ? (e === o ? a = (n - r) / s + (n < r) * 6 : n === o ? a = (r - e) / s + 2 : a = (e - n) / s + 4, s /= f < .5 ? o + i : 2 - o - i, a *= 60) : s = f > 0 && f < 1 ? 0 : a, new dt(a, s, f, t.opacity); }
function mo(t, e, n, r) { return arguments.length === 1 ? po(t) : new dt(t, e, n, r ?? 1); }
function dt(t, e, n, r) { this.h = +t, this.s = +e, this.l = +n, this.opacity = +r; }
Vt(dt, mo, le(Et, { brighter(t) { return t = t == null ? _n : Math.pow(_n, t), new dt(this.h, this.s, this.l * t, this.opacity); }, darker(t) { return t = t == null ? Ee : Math.pow(Ee, t), new dt(this.h, this.s, this.l * t, this.opacity); }, rgb() { var t = this.h % 360 + (this.h < 0) * 360, e = isNaN(t) || isNaN(this.s) ? 0 : this.s, n = this.l, r = n + (n < .5 ? n : 1 - n) * e, i = 2 * n - r; return new tt(pr(t >= 240 ? t - 240 : t + 120, i, r), pr(t, i, r), pr(t < 120 ? t + 240 : t - 120, i, r), this.opacity); }, clamp() { return new dt(ho(this.h), xn(this.s), xn(this.l), gn(this.opacity)); }, displayable() { return (0 <= this.s && this.s <= 1 || isNaN(this.s)) && 0 <= this.l && this.l <= 1 && 0 <= this.opacity && this.opacity <= 1; }, formatHsl() { let t = gn(this.opacity); return `${t === 1 ? "hsl(" : "hsla("}${ho(this.h)}, ${xn(this.s) * 100}%, ${xn(this.l) * 100}%${t === 1 ? ")" : `, ${t})`}`; } }));
function ho(t) { return t = (t || 0) % 360, t < 0 ? t + 360 : t; }
function xn(t) { return Math.max(0, Math.min(1, t || 0)); }
function pr(t, e, n) { return (t < 60 ? e + (n - e) * t / 60 : t < 180 ? n : t < 240 ? e + (n - e) * (240 - t) / 60 : e) * 255; }
var xo = Math.PI / 180, _o = 180 / Math.PI;
var yn = 18, go = .96422, yo = 1, vo = .82521, wo = 4 / 29, pe = 6 / 29, bo = 3 * pe * pe, Tf = pe * pe * pe;
function Mo(t) { if (t instanceof vt)
    return new vt(t.l, t.a, t.b, t.opacity); if (t instanceof Nt)
    return To(t); t instanceof tt || (t = mr(t)); var e = gr(t.r), n = gr(t.g), r = gr(t.b), i = dr((.2225045 * e + .7168786 * n + .0606169 * r) / yo), o, a; return e === n && n === r ? o = a = i : (o = dr((.4360747 * e + .3850649 * n + .1430804 * r) / go), a = dr((.0139322 * e + .0971045 * n + .7141733 * r) / vo)), new vt(116 * i - 16, 500 * (o - i), 200 * (i - a), t.opacity); }
function yr(t, e, n, r) { return arguments.length === 1 ? Mo(t) : new vt(t, e, n, r ?? 1); }
function vt(t, e, n, r) { this.l = +t, this.a = +e, this.b = +n, this.opacity = +r; }
Vt(vt, yr, le(Et, { brighter(t) { return new vt(this.l + yn * (t ?? 1), this.a, this.b, this.opacity); }, darker(t) { return new vt(this.l - yn * (t ?? 1), this.a, this.b, this.opacity); }, rgb() { var t = (this.l + 16) / 116, e = isNaN(this.a) ? t : t + this.a / 500, n = isNaN(this.b) ? t : t - this.b / 200; return e = go * xr(e), t = yo * xr(t), n = vo * xr(n), new tt(_r(3.1338561 * e - 1.6168667 * t - .4906146 * n), _r(-.9787684 * e + 1.9161415 * t + .033454 * n), _r(.0719453 * e - .2289914 * t + 1.4052427 * n), this.opacity); } }));
function dr(t) { return t > Tf ? Math.pow(t, 1 / 3) : t / bo + wo; }
function xr(t) { return t > pe ? t * t * t : bo * (t - wo); }
function _r(t) { return 255 * (t <= .0031308 ? 12.92 * t : 1.055 * Math.pow(t, 1 / 2.4) - .055); }
function gr(t) { return (t /= 255) <= .04045 ? t / 12.92 : Math.pow((t + .055) / 1.055, 2.4); }
function kf(t) { if (t instanceof Nt)
    return new Nt(t.h, t.c, t.l, t.opacity); if (t instanceof vt || (t = Mo(t)), t.a === 0 && t.b === 0)
    return new Nt(NaN, 0 < t.l && t.l < 100 ? 0 : NaN, t.l, t.opacity); var e = Math.atan2(t.b, t.a) * _o; return new Nt(e < 0 ? e + 360 : e, Math.sqrt(t.a * t.a + t.b * t.b), t.l, t.opacity); }
function Ye(t, e, n, r) { return arguments.length === 1 ? kf(t) : new Nt(t, e, n, r ?? 1); }
function Nt(t, e, n, r) { this.h = +t, this.c = +e, this.l = +n, this.opacity = +r; }
function To(t) { if (isNaN(t.h))
    return new vt(t.l, 0, 0, t.opacity); var e = t.h * xo; return new vt(t.l, Math.cos(e) * t.c, Math.sin(e) * t.c, t.opacity); }
Vt(Nt, Ye, le(Et, { brighter(t) { return new Nt(this.h, this.c, this.l + yn * (t ?? 1), this.opacity); }, darker(t) { return new Nt(this.h, this.c, this.l - yn * (t ?? 1), this.opacity); }, rgb() { return To(this).rgb(); } }));
var me = t => () => t;
function ko(t, e) { return function (n) { return t + n * e; }; }
function Sf(t, e, n) { return t = Math.pow(t, n), e = Math.pow(e, n) - t, n = 1 / n, function (r) { return Math.pow(t + r * e, n); }; }
function So(t, e) { var n = e - t; return n ? ko(t, n > 180 || n < -180 ? n - 360 * Math.round(n / 360) : n) : me(isNaN(t) ? e : t); }
function Co(t) { return (t = +t) == 1 ? At : function (e, n) { return n - e ? Sf(e, n, t) : me(isNaN(e) ? n : e); }; }
function At(t, e) { var n = e - t; return n ? ko(t, n) : me(isNaN(t) ? e : t); }
function No(t) { return function (e, n) { var r = t((e = Ye(e)).h, (n = Ye(n)).h), i = At(e.c, n.c), o = At(e.l, n.l), a = At(e.opacity, n.opacity); return function (s) { return e.h = r(s), e.c = i(s), e.l = o(s), e.opacity = a(s), e + ""; }; }; }
var Cf = No(So), Nf = No(At);
function vr(t, e, n, r, i) { var o = t * t, a = o * t; return ((1 - 3 * t + 3 * o - a) * e + (4 - 6 * o + 3 * a) * n + (1 + 3 * t + 3 * o - 3 * a) * r + a * i) / 6; }
function Ao(t) { var e = t.length - 1; return function (n) { var r = n <= 0 ? n = 0 : n >= 1 ? (n = 1, e - 1) : Math.floor(n * e), i = t[r], o = t[r + 1], a = r > 0 ? t[r - 1] : 2 * i - o, s = r < e - 1 ? t[r + 2] : 2 * o - i; return vr((n - r / e) * e, a, i, o, s); }; }
function Do(t) { var e = t.length; return function (n) { var r = Math.floor(((n %= 1) < 0 ? ++n : n) * e), i = t[(r + e - 1) % e], o = t[r % e], a = t[(r + 1) % e], s = t[(r + 2) % e]; return vr((n - r / e) * e, i, o, a, s); }; }
var Zt = (function t(e) { var n = Co(e); function r(i, o) { var a = n((i = he(i)).r, (o = he(o)).r), s = n(i.g, o.g), f = n(i.b, o.b), u = At(i.opacity, o.opacity); return function (c) { return i.r = a(c), i.g = s(c), i.b = f(c), i.opacity = u(c), i + ""; }; } return r.gamma = t, r; })(1);
function $o(t) { return function (e) { var n = e.length, r = new Array(n), i = new Array(n), o = new Array(n), a, s; for (a = 0; a < n; ++a)
    s = he(e[a]), r[a] = s.r || 0, i[a] = s.g || 0, o[a] = s.b || 0; return r = t(r), i = t(i), o = t(o), s.opacity = 1, function (f) { return s.r = r(f), s.g = i(f), s.b = o(f), s + ""; }; }; }
var Af = $o(Ao), Df = $o(Do);
function Oo(t, e) { e || (e = []); var n = t ? Math.min(e.length, t.length) : 0, r = e.slice(), i; return function (o) { for (i = 0; i < n; ++i)
    r[i] = t[i] * (1 - o) + e[i] * o; return r; }; }
function Io(t) { return ArrayBuffer.isView(t) && !(t instanceof DataView); }
function Eo(t, e) { var n = e ? e.length : 0, r = t ? Math.min(n, t.length) : 0, i = new Array(r), o = new Array(n), a; for (a = 0; a < r; ++a)
    i[a] = Qt(t[a], e[a]); for (; a < n; ++a)
    o[a] = e[a]; return function (s) { for (a = 0; a < r; ++a)
    o[a] = i[a](s); return o; }; }
function Ro(t, e) { var n = new Date; return t = +t, e = +e, function (r) { return n.setTime(t * (1 - r) + e * r), n; }; }
function et(t, e) { return t = +t, e = +e, function (n) { return t * (1 - n) + e * n; }; }
function Yo(t, e) { var n = {}, r = {}, i; (t === null || typeof t != "object") && (t = {}), (e === null || typeof e != "object") && (e = {}); for (i in e)
    i in t ? n[i] = Qt(t[i], e[i]) : r[i] = e[i]; return function (o) { for (i in n)
    r[i] = n[i](o); return r; }; }
var br = /[-+]?(?:\d+\.?\d*|\.?\d+)(?:[eE][-+]?\d+)?/g, wr = new RegExp(br.source, "g");
function $f(t) { return function () { return t; }; }
function Of(t) { return function (e) { return t(e) + ""; }; }
function Pe(t, e) { var n = br.lastIndex = wr.lastIndex = 0, r, i, o, a = -1, s = [], f = []; for (t = t + "", e = e + ""; (r = br.exec(t)) && (i = wr.exec(e));)
    (o = i.index) > n && (o = e.slice(n, o), s[a] ? s[a] += o : s[++a] = o), (r = r[0]) === (i = i[0]) ? s[a] ? s[a] += i : s[++a] = i : (s[++a] = null, f.push({ i: a, x: et(r, i) })), n = wr.lastIndex; return n < e.length && (o = e.slice(n), s[a] ? s[a] += o : s[++a] = o), s.length < 2 ? f[0] ? Of(f[0].x) : $f(e) : (e = f.length, function (u) { for (var c = 0, h; c < e; ++c)
    s[(h = f[c]).i] = h.x(u); return s.join(""); }); }
function Qt(t, e) { var n = typeof e, r; return e == null || n === "boolean" ? me(e) : (n === "number" ? et : n === "string" ? (r = xt(e)) ? (e = r, Zt) : Pe : e instanceof xt ? Zt : e instanceof Date ? Ro : Io(e) ? Oo : Array.isArray(e) ? Eo : typeof e.valueOf != "function" && typeof e.toString != "function" || isNaN(e) ? Yo : et)(t, e); }
function Mr(t, e) { return t = +t, e = +e, function (n) { return Math.round(t * (1 - n) + e * n); }; }
var Po = 180 / Math.PI, vn = { translateX: 0, translateY: 0, rotate: 0, skewX: 0, scaleX: 1, scaleY: 1 };
function Tr(t, e, n, r, i, o) { var a, s, f; return (a = Math.sqrt(t * t + e * e)) && (t /= a, e /= a), (f = t * n + e * r) && (n -= t * f, r -= e * f), (s = Math.sqrt(n * n + r * r)) && (n /= s, r /= s, f /= s), t * r < e * n && (t = -t, e = -e, f = -f, a = -a), { translateX: i, translateY: o, rotate: Math.atan2(e, t) * Po, skewX: Math.atan(f) * Po, scaleX: a, scaleY: s }; }
var wn;
function Fo(t) { let e = new (typeof DOMMatrix == "function" ? DOMMatrix : WebKitCSSMatrix)(t + ""); return e.isIdentity ? vn : Tr(e.a, e.b, e.c, e.d, e.e, e.f); }
function Uo(t) { return t == null ? vn : (wn || (wn = document.createElementNS("http://www.w3.org/2000/svg", "g")), wn.setAttribute("transform", t), (t = wn.transform.baseVal.consolidate()) ? (t = t.matrix, Tr(t.a, t.b, t.c, t.d, t.e, t.f)) : vn); }
function zo(t, e, n, r) { function i(u) { return u.length ? u.pop() + " " : ""; } function o(u, c, h, l, p, g) { if (u !== h || c !== l) {
    var v = p.push("translate(", null, e, null, n);
    g.push({ i: v - 4, x: et(u, h) }, { i: v - 2, x: et(c, l) });
}
else
    (h || l) && p.push("translate(" + h + e + l + n); } function a(u, c, h, l) { u !== c ? (u - c > 180 ? c += 360 : c - u > 180 && (u += 360), l.push({ i: h.push(i(h) + "rotate(", null, r) - 2, x: et(u, c) })) : c && h.push(i(h) + "rotate(" + c + r); } function s(u, c, h, l) { u !== c ? l.push({ i: h.push(i(h) + "skewX(", null, r) - 2, x: et(u, c) }) : c && h.push(i(h) + "skewX(" + c + r); } function f(u, c, h, l, p, g) { if (u !== h || c !== l) {
    var v = p.push(i(p) + "scale(", null, ",", null, ")");
    g.push({ i: v - 4, x: et(u, h) }, { i: v - 2, x: et(c, l) });
}
else
    (h !== 1 || l !== 1) && p.push(i(p) + "scale(" + h + "," + l + ")"); } return function (u, c) { var h = [], l = []; return u = t(u), c = t(c), o(u.translateX, u.translateY, c.translateX, c.translateY, h, l), a(u.rotate, c.rotate, h, l), s(u.skewX, c.skewX, h, l), f(u.scaleX, u.scaleY, c.scaleX, c.scaleY, h, l), u = c = null, function (p) { for (var g = -1, v = l.length, T; ++g < v;)
    h[(T = l[g]).i] = T.x(p); return h.join(""); }; }; }
var kr = zo(Fo, "px, ", "px)", "deg)"), Sr = zo(Uo, ", ", ")", ")");
function Lo(t) { return Math.abs(t = Math.round(t)) >= 1e21 ? t.toLocaleString("en").replace(/,/g, "") : t.toString(10); }
function Kt(t, e) { if (!isFinite(t) || t === 0)
    return null; var n = (t = e ? t.toExponential(e - 1) : t.toExponential()).indexOf("e"), r = t.slice(0, n); return [r.length > 1 ? r[0] + r.slice(2) : r, +t.slice(n + 1)]; }
function wt(t) { return t = Kt(Math.abs(t)), t ? t[1] : NaN; }
function Ho(t, e) { return function (n, r) { for (var i = n.length, o = [], a = 0, s = t[0], f = 0; i > 0 && s > 0 && (f + s + 1 > r && (s = Math.max(1, r - f)), o.push(n.substring(i -= s, i + s)), !((f += s + 1) > r));)
    s = t[a = (a + 1) % t.length]; return o.reverse().join(e); }; }
function Bo(t) { return function (e) { return e.replace(/[0-9]/g, function (n) { return t[+n]; }); }; }
var If = /^(?:(.)?([<>=^]))?([+\-( ])?([$#])?(0)?(\d+)?(,)?(\.\d+)?(~)?([a-z%])?$/i;
function Rt(t) { if (!(e = If.exec(t)))
    throw new Error("invalid format: " + t); var e; return new bn({ fill: e[1], align: e[2], sign: e[3], symbol: e[4], zero: e[5], width: e[6], comma: e[7], precision: e[8] && e[8].slice(1), trim: e[9], type: e[10] }); }
Rt.prototype = bn.prototype;
function bn(t) { this.fill = t.fill === void 0 ? " " : t.fill + "", this.align = t.align === void 0 ? ">" : t.align + "", this.sign = t.sign === void 0 ? "-" : t.sign + "", this.symbol = t.symbol === void 0 ? "" : t.symbol + "", this.zero = !!t.zero, this.width = t.width === void 0 ? void 0 : +t.width, this.comma = !!t.comma, this.precision = t.precision === void 0 ? void 0 : +t.precision, this.trim = !!t.trim, this.type = t.type === void 0 ? "" : t.type + ""; }
bn.prototype.toString = function () { return this.fill + this.align + this.sign + this.symbol + (this.zero ? "0" : "") + (this.width === void 0 ? "" : Math.max(1, this.width | 0)) + (this.comma ? "," : "") + (this.precision === void 0 ? "" : "." + Math.max(0, this.precision | 0)) + (this.trim ? "~" : "") + this.type; };
function qo(t) { t: for (var e = t.length, n = 1, r = -1, i; n < e; ++n)
    switch (t[n]) {
        case ".":
            r = i = n;
            break;
        case "0":
            r === 0 && (r = n), i = n;
            break;
        default:
            if (!+t[n])
                break t;
            r > 0 && (r = 0);
            break;
    } return r > 0 ? t.slice(0, r) + t.slice(i + 1) : t; }
var Fe;
function Wo(t, e) { var n = Kt(t, e); if (!n)
    return Fe = void 0, t.toPrecision(e); var r = n[0], i = n[1], o = i - (Fe = Math.max(-8, Math.min(8, Math.floor(i / 3))) * 3) + 1, a = r.length; return o === a ? r : o > a ? r + new Array(o - a + 1).join("0") : o > 0 ? r.slice(0, o) + "." + r.slice(o) : "0." + new Array(1 - o).join("0") + Kt(t, Math.max(0, e + o - 1))[0]; }
function Cr(t, e) { var n = Kt(t, e); if (!n)
    return t + ""; var r = n[0], i = n[1]; return i < 0 ? "0." + new Array(-i).join("0") + r : r.length > i + 1 ? r.slice(0, i + 1) + "." + r.slice(i + 1) : r + new Array(i - r.length + 2).join("0"); }
var Nr = { "%": (t, e) => (t * 100).toFixed(e), b: t => Math.round(t).toString(2), c: t => t + "", d: Lo, e: (t, e) => t.toExponential(e), f: (t, e) => t.toFixed(e), g: (t, e) => t.toPrecision(e), o: t => Math.round(t).toString(8), p: (t, e) => Cr(t * 100, e), r: Cr, s: Wo, X: t => Math.round(t).toString(16).toUpperCase(), x: t => Math.round(t).toString(16) };
function Ar(t) { return t; }
var Vo = Array.prototype.map, Xo = ["y", "z", "a", "f", "p", "n", "\xB5", "m", "", "k", "M", "G", "T", "P", "E", "Z", "Y"];
function Go(t) { var e = t.grouping === void 0 || t.thousands === void 0 ? Ar : Ho(Vo.call(t.grouping, Number), t.thousands + ""), n = t.currency === void 0 ? "" : t.currency[0] + "", r = t.currency === void 0 ? "" : t.currency[1] + "", i = t.decimal === void 0 ? "." : t.decimal + "", o = t.numerals === void 0 ? Ar : Bo(Vo.call(t.numerals, String)), a = t.percent === void 0 ? "%" : t.percent + "", s = t.minus === void 0 ? "\u2212" : t.minus + "", f = t.nan === void 0 ? "NaN" : t.nan + ""; function u(h, l) { h = Rt(h); var p = h.fill, g = h.align, v = h.sign, T = h.symbol, k = h.zero, $ = h.width, A = h.comma, S = h.precision, I = h.trim, y = h.type; y === "n" ? (A = !0, y = "g") : Nr[y] || (S === void 0 && (S = 12), I = !0, y = "g"), (k || p === "0" && g === "=") && (k = !0, p = "0", g = "="); var E = (l && l.prefix !== void 0 ? l.prefix : "") + (T === "$" ? n : T === "#" && /[boxX]/.test(y) ? "0" + y.toLowerCase() : ""), Y = (T === "$" ? r : /[%p]/.test(y) ? a : "") + (l && l.suffix !== void 0 ? l.suffix : ""), D = Nr[y], B = /[defgprs%]/.test(y); S = S === void 0 ? 6 : /[gprs]/.test(y) ? Math.max(1, Math.min(21, S)) : Math.max(0, Math.min(20, S)); function L(x) { var m = E, d = Y, M, w, C; if (y === "c")
    d = D(x) + d, x = "";
else {
    x = +x;
    var N = x < 0 || 1 / x < 0;
    if (x = isNaN(x) ? f : D(Math.abs(x), S), I && (x = qo(x)), N && +x == 0 && v !== "+" && (N = !1), m = (N ? v === "(" ? v : s : v === "-" || v === "(" ? "" : v) + m, d = (y === "s" && !isNaN(x) && Fe !== void 0 ? Xo[8 + Fe / 3] : "") + d + (N && v === "(" ? ")" : ""), B) {
        for (M = -1, w = x.length; ++M < w;)
            if (C = x.charCodeAt(M), 48 > C || C > 57) {
                d = (C === 46 ? i + x.slice(M + 1) : x.slice(M)) + d, x = x.slice(0, M);
                break;
            }
    }
} A && !k && (x = e(x, 1 / 0)); var P = m.length + x.length + d.length, F = P < $ ? new Array($ - P + 1).join(p) : ""; switch (A && k && (x = e(F + x, F.length ? $ - d.length : 1 / 0), F = ""), g) {
    case "<":
        x = m + x + d + F;
        break;
    case "=":
        x = m + F + x + d;
        break;
    case "^":
        x = F.slice(0, P = F.length >> 1) + m + x + d + F.slice(P);
        break;
    default:
        x = F + m + x + d;
        break;
} return o(x); } return L.toString = function () { return h + ""; }, L; } function c(h, l) { var p = Math.max(-8, Math.min(8, Math.floor(wt(l) / 3))) * 3, g = Math.pow(10, -p), v = u((h = Rt(h), h.type = "f", h), { suffix: Xo[8 + p / 3] }); return function (T) { return v(g * T); }; } return { format: u, formatPrefix: c }; }
var Mn, Tn, kn;
Dr({ thousands: ",", grouping: [3], currency: ["$", ""] });
function Dr(t) { return Mn = Go(t), Tn = Mn.format, kn = Mn.formatPrefix, Mn; }
function $r(t) { return Math.max(0, -wt(Math.abs(t))); }
function Or(t, e) { return Math.max(0, Math.max(-8, Math.min(8, Math.floor(wt(e) / 3))) * 3 - wt(Math.abs(t))); }
function Ir(t, e) { return t = Math.abs(t), e = Math.abs(e) - t, Math.max(0, wt(e) - wt(t)) + 1; }
function Ef(t) { var e = 0, n = t.children, r = n && n.length; if (!r)
    e = 1;
else
    for (; --r >= 0;)
        e += n[r].value; t.value = e; }
function Zo() { return this.eachAfter(Ef); }
function Qo(t, e) { let n = -1; for (let r of this)
    t.call(e, r, ++n, this); return this; }
function Ko(t, e) { for (var n = this, r = [n], i, o, a = -1; n = r.pop();)
    if (t.call(e, n, ++a, this), i = n.children)
        for (o = i.length - 1; o >= 0; --o)
            r.push(i[o]); return this; }
function Jo(t, e) { for (var n = this, r = [n], i = [], o, a, s, f = -1; n = r.pop();)
    if (i.push(n), o = n.children)
        for (a = 0, s = o.length; a < s; ++a)
            r.push(o[a]); for (; n = i.pop();)
    t.call(e, n, ++f, this); return this; }
function jo(t, e) { let n = -1; for (let r of this)
    if (t.call(e, r, ++n, this))
        return r; }
function ta(t) { return this.eachAfter(function (e) { for (var n = +t(e.data) || 0, r = e.children, i = r && r.length; --i >= 0;)
    n += r[i].value; e.value = n; }); }
function ea(t) { return this.eachBefore(function (e) { e.children && e.children.sort(t); }); }
function na(t) { for (var e = this, n = Rf(e, t), r = [e]; e !== n;)
    e = e.parent, r.push(e); for (var i = r.length; t !== n;)
    r.splice(i, 0, t), t = t.parent; return r; }
function Rf(t, e) { if (t === e)
    return t; var n = t.ancestors(), r = e.ancestors(), i = null; for (t = n.pop(), e = r.pop(); t === e;)
    i = t, t = n.pop(), e = r.pop(); return i; }
function ra() { for (var t = this, e = [t]; t = t.parent;)
    e.push(t); return e; }
function ia() { return Array.from(this); }
function oa() { var t = []; return this.eachBefore(function (e) { e.children || t.push(e); }), t; }
function aa() { var t = this, e = []; return t.each(function (n) { n !== t && e.push({ source: n.parent, target: n }); }), e; }
function* sa() { var t = this, e, n = [t], r, i, o; do
    for (e = n.reverse(), n = []; t = e.pop();)
        if (yield t, r = t.children)
            for (i = 0, o = r.length; i < o; ++i)
                n.push(r[i]);
while (n.length); }
function Sn(t, e) { t instanceof Map ? (t = [void 0, t], e === void 0 && (e = Ff)) : e === void 0 && (e = Pf); for (var n = new Ue(t), r, i = [n], o, a, s, f; r = i.pop();)
    if ((a = e(r.data)) && (f = (a = Array.from(a)).length))
        for (r.children = a, s = f - 1; s >= 0; --s)
            i.push(o = a[s] = new Ue(a[s])), o.parent = r, o.depth = r.depth + 1; return n.eachBefore(zf); }
function Yf() { return Sn(this).eachBefore(Uf); }
function Pf(t) { return t.children; }
function Ff(t) { return Array.isArray(t) ? t[1] : null; }
function Uf(t) { t.data.value !== void 0 && (t.value = t.data.value), t.data = t.data.data; }
function zf(t) { var e = 0; do
    t.height = e;
while ((t = t.parent) && t.height < ++e); }
function Ue(t) { this.data = t, this.depth = this.height = 0, this.parent = null; }
Ue.prototype = Sn.prototype = { constructor: Ue, count: Zo, each: Qo, eachAfter: Jo, eachBefore: Ko, find: jo, sum: ta, sort: ea, path: na, ancestors: ra, descendants: ia, leaves: oa, links: aa, copy: Yf, [Symbol.iterator]: sa };
function ua(t) { t.x0 = Math.round(t.x0), t.y0 = Math.round(t.y0), t.x1 = Math.round(t.x1), t.y1 = Math.round(t.y1); }
function fa(t, e, n, r, i) { for (var o = t.children, a, s = -1, f = o.length, u = t.value && (r - e) / t.value; ++s < f;)
    a = o[s], a.y0 = n, a.y1 = i, a.x0 = e, a.x1 = e += a.value * u; }
function la(t, e, n, r, i) { for (var o = t.children, a, s = -1, f = o.length, u = t.value && (i - n) / t.value; ++s < f;)
    a = o[s], a.x0 = e, a.x1 = r, a.y0 = n, a.y1 = n += a.value * u; }
var Lf = (1 + Math.sqrt(5)) / 2;
function Hf(t, e, n, r, i, o) { for (var a = [], s = e.children, f, u, c = 0, h = 0, l = s.length, p, g, v = e.value, T, k, $, A, S, I, y; c < l;) {
    p = i - n, g = o - r;
    do
        T = s[h++].value;
    while (!T && h < l);
    for (k = $ = T, I = Math.max(g / p, p / g) / (v * t), y = T * T * I, S = Math.max($ / y, y / k); h < l; ++h) {
        if (T += u = s[h].value, u < k && (k = u), u > $ && ($ = u), y = T * T * I, A = Math.max($ / y, y / k), A > S) {
            T -= u;
            break;
        }
        S = A;
    }
    a.push(f = { value: T, dice: p < g, children: s.slice(c, h) }), f.dice ? fa(f, n, r, i, v ? r += g * T / v : o) : la(f, n, r, v ? n += p * T / v : i, o), v -= T, c = h;
} return a; }
var ca = (function t(e) { function n(r, i, o, a, s) { Hf(e, r, i, o, a, s); } return n.ratio = function (r) { return t((r = +r) > 1 ? r : 1); }, n; })(Lf);
function ha(t) { if (typeof t != "function")
    throw new Error; return t; }
function de() { return 0; }
function xe(t) { return function () { return t; }; }
function Bf() { var t = ca, e = !1, n = 1, r = 1, i = [0], o = de, a = de, s = de, f = de, u = de; function c(l) { return l.x0 = l.y0 = 0, l.x1 = n, l.y1 = r, l.eachBefore(h), i = [0], e && l.eachBefore(ua), l; } function h(l) { var p = i[l.depth], g = l.x0 + p, v = l.y0 + p, T = l.x1 - p, k = l.y1 - p; T < g && (g = T = (g + T) / 2), k < v && (v = k = (v + k) / 2), l.x0 = g, l.y0 = v, l.x1 = T, l.y1 = k, l.children && (p = i[l.depth + 1] = o(l) / 2, g += u(l) - p, v += a(l) - p, T -= s(l) - p, k -= f(l) - p, T < g && (g = T = (g + T) / 2), k < v && (v = k = (v + k) / 2), t(l, g, v, T, k)); } return c.round = function (l) { return arguments.length ? (e = !!l, c) : e; }, c.size = function (l) { return arguments.length ? (n = +l[0], r = +l[1], c) : [n, r]; }, c.tile = function (l) { return arguments.length ? (t = ha(l), c) : t; }, c.padding = function (l) { return arguments.length ? c.paddingInner(l).paddingOuter(l) : c.paddingInner(); }, c.paddingInner = function (l) { return arguments.length ? (o = typeof l == "function" ? l : xe(+l), c) : o; }, c.paddingOuter = function (l) { return arguments.length ? c.paddingTop(l).paddingRight(l).paddingBottom(l).paddingLeft(l) : c.paddingTop(); }, c.paddingTop = function (l) { return arguments.length ? (a = typeof l == "function" ? l : xe(+l), c) : a; }, c.paddingRight = function (l) { return arguments.length ? (s = typeof l == "function" ? l : xe(+l), c) : s; }, c.paddingBottom = function (l) { return arguments.length ? (f = typeof l == "function" ? l : xe(+l), c) : f; }, c.paddingLeft = function (l) { return arguments.length ? (u = typeof l == "function" ? l : xe(+l), c) : u; }, c; }
function Yt(t, e) { switch (arguments.length) {
    case 0: break;
    case 1:
        this.range(t);
        break;
    default:
        this.range(e).domain(t);
        break;
} return this; }
var Er = Symbol("implicit");
function ze() { var t = new ue, e = [], n = [], r = Er; function i(o) { let a = t.get(o); if (a === void 0) {
    if (r !== Er)
        return r;
    t.set(o, a = e.push(o) - 1);
} return n[a % n.length]; } return i.domain = function (o) { if (!arguments.length)
    return e.slice(); e = [], t = new ue; for (let a of o)
    t.has(a) || t.set(a, e.push(a) - 1); return i; }, i.range = function (o) { return arguments.length ? (n = Array.from(o), i) : n.slice(); }, i.unknown = function (o) { return arguments.length ? (r = o, i) : r; }, i.copy = function () { return ze(e, n).unknown(r); }, Yt.apply(i, arguments), i; }
function Rr() { var t = ze().unknown(void 0), e = t.domain, n = t.range, r = 0, i = 1, o, a, s = !1, f = 0, u = 0, c = .5; delete t.unknown; function h() { var l = e().length, p = i < r, g = p ? i : r, v = p ? r : i; o = (v - g) / Math.max(1, l - f + u * 2), s && (o = Math.floor(o)), g += (v - g - o * (l - f)) * c, a = o * (1 - f), s && (g = Math.round(g), a = Math.round(a)); var T = sn(l).map(function (k) { return g + o * k; }); return n(p ? T.reverse() : T); } return t.domain = function (l) { return arguments.length ? (e(l), h()) : e(); }, t.range = function (l) { return arguments.length ? ([r, i] = l, r = +r, i = +i, h()) : [r, i]; }, t.rangeRound = function (l) { return [r, i] = l, r = +r, i = +i, s = !0, h(); }, t.bandwidth = function () { return a; }, t.step = function () { return o; }, t.round = function (l) { return arguments.length ? (s = !!l, h()) : s; }, t.padding = function (l) { return arguments.length ? (f = Math.min(1, u = +l), h()) : f; }, t.paddingInner = function (l) { return arguments.length ? (f = Math.min(1, l), h()) : f; }, t.paddingOuter = function (l) { return arguments.length ? (u = +l, h()) : u; }, t.align = function (l) { return arguments.length ? (c = Math.max(0, Math.min(1, l)), h()) : c; }, t.copy = function () { return Rr(e(), [r, i]).round(s).paddingInner(f).paddingOuter(u).align(c); }, Yt.apply(h(), arguments); }
function Yr(t) { return function () { return t; }; }
function Pr(t) { return +t; }
var pa = [0, 1];
function _e(t) { return t; }
function Fr(t, e) { return (e -= t = +t) ? function (n) { return (n - t) / e; } : Yr(isNaN(e) ? NaN : .5); }
function qf(t, e) { var n; return t > e && (n = t, t = e, e = n), function (r) { return Math.max(t, Math.min(e, r)); }; }
function Wf(t, e, n) { var r = t[0], i = t[1], o = e[0], a = e[1]; return i < r ? (r = Fr(i, r), o = n(a, o)) : (r = Fr(r, i), o = n(o, a)), function (s) { return o(r(s)); }; }
function Vf(t, e, n) { var r = Math.min(t.length, e.length) - 1, i = new Array(r), o = new Array(r), a = -1; for (t[r] < t[0] && (t = t.slice().reverse(), e = e.slice().reverse()); ++a < r;)
    i[a] = Fr(t[a], t[a + 1]), o[a] = n(e[a], e[a + 1]); return function (s) { var f = ar(t, s, 1, r) - 1; return o[f](i[f](s)); }; }
function Cn(t, e) { return e.domain(t.domain()).range(t.range()).interpolate(t.interpolate()).clamp(t.clamp()).unknown(t.unknown()); }
function Xf() { var t = pa, e = pa, n = Qt, r, i, o, a = _e, s, f, u; function c() { var l = Math.min(t.length, e.length); return a !== _e && (a = qf(t[0], t[l - 1])), s = l > 2 ? Vf : Wf, f = u = null, h; } function h(l) { return l == null || isNaN(l = +l) ? o : (f || (f = s(t.map(r), e, n)))(r(a(l))); } return h.invert = function (l) { return a(i((u || (u = s(e, t.map(r), et)))(l))); }, h.domain = function (l) { return arguments.length ? (t = Array.from(l, Pr), c()) : t.slice(); }, h.range = function (l) { return arguments.length ? (e = Array.from(l), c()) : e.slice(); }, h.rangeRound = function (l) { return e = Array.from(l), n = Mr, c(); }, h.clamp = function (l) { return arguments.length ? (a = l ? !0 : _e, c()) : a !== _e; }, h.interpolate = function (l) { return arguments.length ? (n = l, c()) : n; }, h.unknown = function (l) { return arguments.length ? (o = l, h) : o; }, function (l, p) { return r = l, i = p, c(); }; }
function Le() { return Xf()(_e, _e); }
function Ur(t, e, n, r) { var i = fe(t, e, n), o; switch (r = Rt(r ?? ",f"), r.type) {
    case "s": {
        var a = Math.max(Math.abs(t), Math.abs(e));
        return r.precision == null && !isNaN(o = Or(i, a)) && (r.precision = o), kn(r, a);
    }
    case "":
    case "e":
    case "g":
    case "p":
    case "r": {
        r.precision == null && !isNaN(o = Ir(i, Math.max(Math.abs(t), Math.abs(e)))) && (r.precision = o - (r.type === "e"));
        break;
    }
    case "f":
    case "%": {
        r.precision == null && !isNaN(o = $r(i)) && (r.precision = o - (r.type === "%") * 2);
        break;
    }
} return Tn(r); }
function Gf(t) { var e = t.domain; return t.ticks = function (n) { var r = e(); return an(r[0], r[r.length - 1], n ?? 10); }, t.tickFormat = function (n, r) { var i = e(); return Ur(i[0], i[i.length - 1], n ?? 10, r); }, t.nice = function (n) { n == null && (n = 10); var r = e(), i = 0, o = r.length - 1, a = r[i], s = r[o], f, u, c = 10; for (s < a && (u = a, a = s, s = u, u = i, i = o, o = u); c-- > 0;) {
    if (u = De(a, s, n), u === f)
        return r[i] = a, r[o] = s, e(r);
    if (u > 0)
        a = Math.floor(a / u) * u, s = Math.ceil(s / u) * u;
    else if (u < 0)
        a = Math.ceil(a * u) / u, s = Math.floor(s * u) / u;
    else
        break;
    f = u;
} return t; }, t; }
function zr() { var t = Le(); return t.copy = function () { return Cn(t, zr()); }, Yt.apply(t, arguments), Gf(t); }
var Lr = new Date, Hr = new Date;
function z(t, e, n, r) { function i(o) { return t(o = arguments.length === 0 ? new Date : new Date(+o)), o; } return i.floor = o => (t(o = new Date(+o)), o), i.ceil = o => (t(o = new Date(o - 1)), e(o, 1), t(o), o), i.round = o => { let a = i(o), s = i.ceil(o); return o - a < s - o ? a : s; }, i.offset = (o, a) => (e(o = new Date(+o), a == null ? 1 : Math.floor(a)), o), i.range = (o, a, s) => { let f = []; if (o = i.ceil(o), s = s == null ? 1 : Math.floor(s), !(o < a) || !(s > 0))
    return f; let u; do
    f.push(u = new Date(+o)), e(o, s), t(o);
while (u < o && o < a); return f; }, i.filter = o => z(a => { if (a >= a)
    for (; t(a), !o(a);)
        a.setTime(a - 1); }, (a, s) => { if (a >= a)
    if (s < 0)
        for (; ++s <= 0;)
            for (; e(a, -1), !o(a);)
                ;
    else
        for (; --s >= 0;)
            for (; e(a, 1), !o(a);)
                ; }), n && (i.count = (o, a) => (Lr.setTime(+o), Hr.setTime(+a), t(Lr), t(Hr), Math.floor(n(Lr, Hr))), i.every = o => (o = Math.floor(o), !isFinite(o) || !(o > 0) ? null : o > 1 ? i.filter(r ? a => r(a) % o === 0 : a => i.count(0, a) % o === 0) : i)), i; }
var Jt = z(() => { }, (t, e) => { t.setTime(+t + e); }, (t, e) => e - t);
Jt.every = t => (t = Math.floor(t), !isFinite(t) || !(t > 0) ? null : t > 1 ? z(e => { e.setTime(Math.floor(e / t) * t); }, (e, n) => { e.setTime(+e + n * t); }, (e, n) => (n - e) / t) : Jt);
var ma = Jt.range;
var bt = z(t => { t.setTime(t - t.getMilliseconds()); }, (t, e) => { t.setTime(+t + e * 1e3); }, (t, e) => (e - t) / 1e3, t => t.getUTCSeconds()), da = bt.range;
var ge = z(t => { t.setTime(t - t.getMilliseconds() - t.getSeconds() * 1e3); }, (t, e) => { t.setTime(+t + e * 6e4); }, (t, e) => (e - t) / 6e4, t => t.getMinutes()), Zf = ge.range, Nn = z(t => { t.setUTCSeconds(0, 0); }, (t, e) => { t.setTime(+t + e * 6e4); }, (t, e) => (e - t) / 6e4, t => t.getUTCMinutes()), Qf = Nn.range;
var ye = z(t => { t.setTime(t - t.getMilliseconds() - t.getSeconds() * 1e3 - t.getMinutes() * 6e4); }, (t, e) => { t.setTime(+t + e * 36e5); }, (t, e) => (e - t) / 36e5, t => t.getHours()), Kf = ye.range, An = z(t => { t.setUTCMinutes(0, 0, 0); }, (t, e) => { t.setTime(+t + e * 36e5); }, (t, e) => (e - t) / 36e5, t => t.getUTCHours()), Jf = An.range;
var Dt = z(t => t.setHours(0, 0, 0, 0), (t, e) => t.setDate(t.getDate() + e), (t, e) => (e - t - (e.getTimezoneOffset() - t.getTimezoneOffset()) * 6e4) / 864e5, t => t.getDate() - 1), jf = Dt.range, Be = z(t => { t.setUTCHours(0, 0, 0, 0); }, (t, e) => { t.setUTCDate(t.getUTCDate() + e); }, (t, e) => (e - t) / 864e5, t => t.getUTCDate() - 1), tl = Be.range, Dn = z(t => { t.setUTCHours(0, 0, 0, 0); }, (t, e) => { t.setUTCDate(t.getUTCDate() + e); }, (t, e) => (e - t) / 864e5, t => Math.floor(t / 864e5)), el = Dn.range;
function ee(t) { return z(e => { e.setDate(e.getDate() - (e.getDay() + 7 - t) % 7), e.setHours(0, 0, 0, 0); }, (e, n) => { e.setDate(e.getDate() + n * 7); }, (e, n) => (n - e - (n.getTimezoneOffset() - e.getTimezoneOffset()) * 6e4) / 6048e5); }
var $t = ee(0), ve = ee(1), _a = ee(2), ga = ee(3), Pt = ee(4), ya = ee(5), va = ee(6), wa = $t.range, nl = ve.range, rl = _a.range, il = ga.range, ol = Pt.range, al = ya.range, sl = va.range;
function ne(t) { return z(e => { e.setUTCDate(e.getUTCDate() - (e.getUTCDay() + 7 - t) % 7), e.setUTCHours(0, 0, 0, 0); }, (e, n) => { e.setUTCDate(e.getUTCDate() + n * 7); }, (e, n) => (n - e) / 6048e5); }
var re = ne(0), we = ne(1), ba = ne(2), Ma = ne(3), Ft = ne(4), Ta = ne(5), ka = ne(6), Sa = re.range, ul = we.range, fl = ba.range, ll = Ma.range, cl = Ft.range, hl = Ta.range, pl = ka.range;
var be = z(t => { t.setDate(1), t.setHours(0, 0, 0, 0); }, (t, e) => { t.setMonth(t.getMonth() + e); }, (t, e) => e.getMonth() - t.getMonth() + (e.getFullYear() - t.getFullYear()) * 12, t => t.getMonth()), ml = be.range, $n = z(t => { t.setUTCDate(1), t.setUTCHours(0, 0, 0, 0); }, (t, e) => { t.setUTCMonth(t.getUTCMonth() + e); }, (t, e) => e.getUTCMonth() - t.getUTCMonth() + (e.getUTCFullYear() - t.getUTCFullYear()) * 12, t => t.getUTCMonth()), dl = $n.range;
var ft = z(t => { t.setMonth(0, 1), t.setHours(0, 0, 0, 0); }, (t, e) => { t.setFullYear(t.getFullYear() + e); }, (t, e) => e.getFullYear() - t.getFullYear(), t => t.getFullYear());
ft.every = t => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : z(e => { e.setFullYear(Math.floor(e.getFullYear() / t) * t), e.setMonth(0, 1), e.setHours(0, 0, 0, 0); }, (e, n) => { e.setFullYear(e.getFullYear() + n * t); });
var xl = ft.range, _t = z(t => { t.setUTCMonth(0, 1), t.setUTCHours(0, 0, 0, 0); }, (t, e) => { t.setUTCFullYear(t.getUTCFullYear() + e); }, (t, e) => e.getUTCFullYear() - t.getUTCFullYear(), t => t.getUTCFullYear());
_t.every = t => !isFinite(t = Math.floor(t)) || !(t > 0) ? null : z(e => { e.setUTCFullYear(Math.floor(e.getUTCFullYear() / t) * t), e.setUTCMonth(0, 1), e.setUTCHours(0, 0, 0, 0); }, (e, n) => { e.setUTCFullYear(e.getUTCFullYear() + n * t); });
var _l = _t.range;
function Na(t, e, n, r, i, o) { let a = [[bt, 1, 1e3], [bt, 5, 5 * 1e3], [bt, 15, 15 * 1e3], [bt, 30, 30 * 1e3], [o, 1, 6e4], [o, 5, 5 * 6e4], [o, 15, 15 * 6e4], [o, 30, 30 * 6e4], [i, 1, 36e5], [i, 3, 3 * 36e5], [i, 6, 6 * 36e5], [i, 12, 12 * 36e5], [r, 1, 864e5], [r, 2, 2 * 864e5], [n, 1, 6048e5], [e, 1, 2592e6], [e, 3, 3 * 2592e6], [t, 1, 31536e6]]; function s(u, c, h) { let l = c < u; l && ([u, c] = [c, u]); let p = h && typeof h.range == "function" ? h : f(u, c, h), g = p ? p.range(u, +c + 1) : []; return l ? g.reverse() : g; } function f(u, c, h) { let l = Math.abs(c - u) / h, p = qt(([, , T]) => T).right(a, l); if (p === a.length)
    return t.every(fe(u / 31536e6, c / 31536e6, h)); if (p === 0)
    return Jt.every(Math.max(fe(u, c, h), 1)); let [g, v] = a[l / a[p - 1][2] < a[p][2] / l ? p - 1 : p]; return g.every(v); } return [s, f]; }
var [yl, vl] = Na(_t, $n, re, Dn, An, Nn), [Br, qr] = Na(ft, be, $t, Dt, ye, ge);
function Wr(t) { if (0 <= t.y && t.y < 100) {
    var e = new Date(-1, t.m, t.d, t.H, t.M, t.S, t.L);
    return e.setFullYear(t.y), e;
} return new Date(t.y, t.m, t.d, t.H, t.M, t.S, t.L); }
function Vr(t) { if (0 <= t.y && t.y < 100) {
    var e = new Date(Date.UTC(-1, t.m, t.d, t.H, t.M, t.S, t.L));
    return e.setUTCFullYear(t.y), e;
} return new Date(Date.UTC(t.y, t.m, t.d, t.H, t.M, t.S, t.L)); }
function qe(t, e, n) { return { y: t, m: e, d: n, H: 0, M: 0, S: 0, L: 0 }; }
function Xr(t) { var e = t.dateTime, n = t.date, r = t.time, i = t.periods, o = t.days, a = t.shortDays, s = t.months, f = t.shortMonths, u = We(i), c = Ve(i), h = We(o), l = Ve(o), p = We(a), g = Ve(a), v = We(s), T = Ve(s), k = We(f), $ = Ve(f), A = { a: C, A: N, b: P, B: F, c: null, d: Ea, e: Ea, f: Bl, g: jl, G: ec, H: zl, I: Ll, j: Hl, L: Ua, m: ql, M: Wl, p: q, q: V, Q: Pa, s: Fa, S: Vl, u: Xl, U: Gl, V: Zl, w: Ql, W: Kl, x: null, X: null, y: Jl, Y: tc, Z: nc, "%": Ya }, S = { a: K, A: lt, b: Z, B: mt, c: null, d: Ra, e: Ra, f: ac, g: xc, G: gc, H: rc, I: ic, j: oc, L: La, m: sc, M: uc, p: at, q: G, Q: Pa, s: Fa, S: fc, u: lc, U: cc, V: hc, w: pc, W: mc, x: null, X: null, y: dc, Y: _c, Z: yc, "%": Ya }, I = { a: B, A: L, b: x, B: m, c: d, d: Oa, e: Oa, f: Yl, g: $a, G: Da, H: Ia, I: Ia, j: Ol, L: Rl, m: $l, M: Il, p: D, q: Dl, Q: Fl, s: Ul, S: El, u: kl, U: Sl, V: Cl, w: Tl, W: Nl, x: M, X: w, y: $a, Y: Da, Z: Al, "%": Pl }; A.x = y(n, A), A.X = y(r, A), A.c = y(e, A), S.x = y(n, S), S.X = y(r, S), S.c = y(e, S); function y(b, O) { return function (R) { var _ = [], ot = -1, H = 0, st = b.length, ut, Ht, si; for (R instanceof Date || (R = new Date(+R)); ++ot < st;)
    b.charCodeAt(ot) === 37 && (_.push(b.slice(H, ot)), (Ht = Aa[ut = b.charAt(++ot)]) != null ? ut = b.charAt(++ot) : Ht = ut === "e" ? " " : "0", (si = O[ut]) && (ut = si(R, Ht)), _.push(ut), H = ot + 1); return _.push(b.slice(H, ot)), _.join(""); }; } function E(b, O) { return function (R) { var _ = qe(1900, void 0, 1), ot = Y(_, b, R += "", 0), H, st; if (ot != R.length)
    return null; if ("Q" in _)
    return new Date(_.Q); if ("s" in _)
    return new Date(_.s * 1e3 + ("L" in _ ? _.L : 0)); if (O && !("Z" in _) && (_.Z = 0), "p" in _ && (_.H = _.H % 12 + _.p * 12), _.m === void 0 && (_.m = "q" in _ ? _.q : 0), "V" in _) {
    if (_.V < 1 || _.V > 53)
        return null;
    "w" in _ || (_.w = 1), "Z" in _ ? (H = Vr(qe(_.y, 0, 1)), st = H.getUTCDay(), H = st > 4 || st === 0 ? we.ceil(H) : we(H), H = Be.offset(H, (_.V - 1) * 7), _.y = H.getUTCFullYear(), _.m = H.getUTCMonth(), _.d = H.getUTCDate() + (_.w + 6) % 7) : (H = Wr(qe(_.y, 0, 1)), st = H.getDay(), H = st > 4 || st === 0 ? ve.ceil(H) : ve(H), H = Dt.offset(H, (_.V - 1) * 7), _.y = H.getFullYear(), _.m = H.getMonth(), _.d = H.getDate() + (_.w + 6) % 7);
}
else
    ("W" in _ || "U" in _) && ("w" in _ || (_.w = "u" in _ ? _.u % 7 : "W" in _ ? 1 : 0), st = "Z" in _ ? Vr(qe(_.y, 0, 1)).getUTCDay() : Wr(qe(_.y, 0, 1)).getDay(), _.m = 0, _.d = "W" in _ ? (_.w + 6) % 7 + _.W * 7 - (st + 5) % 7 : _.w + _.U * 7 - (st + 6) % 7); return "Z" in _ ? (_.H += _.Z / 100 | 0, _.M += _.Z % 100, Vr(_)) : Wr(_); }; } function Y(b, O, R, _) { for (var ot = 0, H = O.length, st = R.length, ut, Ht; ot < H;) {
    if (_ >= st)
        return -1;
    if (ut = O.charCodeAt(ot++), ut === 37) {
        if (ut = O.charAt(ot++), Ht = I[ut in Aa ? O.charAt(ot++) : ut], !Ht || (_ = Ht(b, R, _)) < 0)
            return -1;
    }
    else if (ut != R.charCodeAt(_++))
        return -1;
} return _; } function D(b, O, R) { var _ = u.exec(O.slice(R)); return _ ? (b.p = c.get(_[0].toLowerCase()), R + _[0].length) : -1; } function B(b, O, R) { var _ = p.exec(O.slice(R)); return _ ? (b.w = g.get(_[0].toLowerCase()), R + _[0].length) : -1; } function L(b, O, R) { var _ = h.exec(O.slice(R)); return _ ? (b.w = l.get(_[0].toLowerCase()), R + _[0].length) : -1; } function x(b, O, R) { var _ = k.exec(O.slice(R)); return _ ? (b.m = $.get(_[0].toLowerCase()), R + _[0].length) : -1; } function m(b, O, R) { var _ = v.exec(O.slice(R)); return _ ? (b.m = T.get(_[0].toLowerCase()), R + _[0].length) : -1; } function d(b, O, R) { return Y(b, e, O, R); } function M(b, O, R) { return Y(b, n, O, R); } function w(b, O, R) { return Y(b, r, O, R); } function C(b) { return a[b.getDay()]; } function N(b) { return o[b.getDay()]; } function P(b) { return f[b.getMonth()]; } function F(b) { return s[b.getMonth()]; } function q(b) { return i[+(b.getHours() >= 12)]; } function V(b) { return 1 + ~~(b.getMonth() / 3); } function K(b) { return a[b.getUTCDay()]; } function lt(b) { return o[b.getUTCDay()]; } function Z(b) { return f[b.getUTCMonth()]; } function mt(b) { return s[b.getUTCMonth()]; } function at(b) { return i[+(b.getUTCHours() >= 12)]; } function G(b) { return 1 + ~~(b.getUTCMonth() / 3); } return { format: function (b) { var O = y(b += "", A); return O.toString = function () { return b; }, O; }, parse: function (b) { var O = E(b += "", !1); return O.toString = function () { return b; }, O; }, utcFormat: function (b) { var O = y(b += "", S); return O.toString = function () { return b; }, O; }, utcParse: function (b) { var O = E(b += "", !0); return O.toString = function () { return b; }, O; } }; }
var Aa = { "-": "", _: " ", 0: "0" }, J = /^\s*\d+/, wl = /^%/, bl = /[\\^$*+?|[\]().{}]/g;
function U(t, e, n) { var r = t < 0 ? "-" : "", i = (r ? -t : t) + "", o = i.length; return r + (o < n ? new Array(n - o + 1).join(e) + i : i); }
function Ml(t) { return t.replace(bl, "\\$&"); }
function We(t) { return new RegExp("^(?:" + t.map(Ml).join("|") + ")", "i"); }
function Ve(t) { return new Map(t.map((e, n) => [e.toLowerCase(), n])); }
function Tl(t, e, n) { var r = J.exec(e.slice(n, n + 1)); return r ? (t.w = +r[0], n + r[0].length) : -1; }
function kl(t, e, n) { var r = J.exec(e.slice(n, n + 1)); return r ? (t.u = +r[0], n + r[0].length) : -1; }
function Sl(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.U = +r[0], n + r[0].length) : -1; }
function Cl(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.V = +r[0], n + r[0].length) : -1; }
function Nl(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.W = +r[0], n + r[0].length) : -1; }
function Da(t, e, n) { var r = J.exec(e.slice(n, n + 4)); return r ? (t.y = +r[0], n + r[0].length) : -1; }
function $a(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.y = +r[0] + (+r[0] > 68 ? 1900 : 2e3), n + r[0].length) : -1; }
function Al(t, e, n) { var r = /^(Z)|([+-]\d\d)(?::?(\d\d))?/.exec(e.slice(n, n + 6)); return r ? (t.Z = r[1] ? 0 : -(r[2] + (r[3] || "00")), n + r[0].length) : -1; }
function Dl(t, e, n) { var r = J.exec(e.slice(n, n + 1)); return r ? (t.q = r[0] * 3 - 3, n + r[0].length) : -1; }
function $l(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.m = r[0] - 1, n + r[0].length) : -1; }
function Oa(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.d = +r[0], n + r[0].length) : -1; }
function Ol(t, e, n) { var r = J.exec(e.slice(n, n + 3)); return r ? (t.m = 0, t.d = +r[0], n + r[0].length) : -1; }
function Ia(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.H = +r[0], n + r[0].length) : -1; }
function Il(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.M = +r[0], n + r[0].length) : -1; }
function El(t, e, n) { var r = J.exec(e.slice(n, n + 2)); return r ? (t.S = +r[0], n + r[0].length) : -1; }
function Rl(t, e, n) { var r = J.exec(e.slice(n, n + 3)); return r ? (t.L = +r[0], n + r[0].length) : -1; }
function Yl(t, e, n) { var r = J.exec(e.slice(n, n + 6)); return r ? (t.L = Math.floor(r[0] / 1e3), n + r[0].length) : -1; }
function Pl(t, e, n) { var r = wl.exec(e.slice(n, n + 1)); return r ? n + r[0].length : -1; }
function Fl(t, e, n) { var r = J.exec(e.slice(n)); return r ? (t.Q = +r[0], n + r[0].length) : -1; }
function Ul(t, e, n) { var r = J.exec(e.slice(n)); return r ? (t.s = +r[0], n + r[0].length) : -1; }
function Ea(t, e) { return U(t.getDate(), e, 2); }
function zl(t, e) { return U(t.getHours(), e, 2); }
function Ll(t, e) { return U(t.getHours() % 12 || 12, e, 2); }
function Hl(t, e) { return U(1 + Dt.count(ft(t), t), e, 3); }
function Ua(t, e) { return U(t.getMilliseconds(), e, 3); }
function Bl(t, e) { return Ua(t, e) + "000"; }
function ql(t, e) { return U(t.getMonth() + 1, e, 2); }
function Wl(t, e) { return U(t.getMinutes(), e, 2); }
function Vl(t, e) { return U(t.getSeconds(), e, 2); }
function Xl(t) { var e = t.getDay(); return e === 0 ? 7 : e; }
function Gl(t, e) { return U($t.count(ft(t) - 1, t), e, 2); }
function za(t) { var e = t.getDay(); return e >= 4 || e === 0 ? Pt(t) : Pt.ceil(t); }
function Zl(t, e) { return t = za(t), U(Pt.count(ft(t), t) + (ft(t).getDay() === 4), e, 2); }
function Ql(t) { return t.getDay(); }
function Kl(t, e) { return U(ve.count(ft(t) - 1, t), e, 2); }
function Jl(t, e) { return U(t.getFullYear() % 100, e, 2); }
function jl(t, e) { return t = za(t), U(t.getFullYear() % 100, e, 2); }
function tc(t, e) { return U(t.getFullYear() % 1e4, e, 4); }
function ec(t, e) { var n = t.getDay(); return t = n >= 4 || n === 0 ? Pt(t) : Pt.ceil(t), U(t.getFullYear() % 1e4, e, 4); }
function nc(t) { var e = t.getTimezoneOffset(); return (e > 0 ? "-" : (e *= -1, "+")) + U(e / 60 | 0, "0", 2) + U(e % 60, "0", 2); }
function Ra(t, e) { return U(t.getUTCDate(), e, 2); }
function rc(t, e) { return U(t.getUTCHours(), e, 2); }
function ic(t, e) { return U(t.getUTCHours() % 12 || 12, e, 2); }
function oc(t, e) { return U(1 + Be.count(_t(t), t), e, 3); }
function La(t, e) { return U(t.getUTCMilliseconds(), e, 3); }
function ac(t, e) { return La(t, e) + "000"; }
function sc(t, e) { return U(t.getUTCMonth() + 1, e, 2); }
function uc(t, e) { return U(t.getUTCMinutes(), e, 2); }
function fc(t, e) { return U(t.getUTCSeconds(), e, 2); }
function lc(t) { var e = t.getUTCDay(); return e === 0 ? 7 : e; }
function cc(t, e) { return U(re.count(_t(t) - 1, t), e, 2); }
function Ha(t) { var e = t.getUTCDay(); return e >= 4 || e === 0 ? Ft(t) : Ft.ceil(t); }
function hc(t, e) { return t = Ha(t), U(Ft.count(_t(t), t) + (_t(t).getUTCDay() === 4), e, 2); }
function pc(t) { return t.getUTCDay(); }
function mc(t, e) { return U(we.count(_t(t) - 1, t), e, 2); }
function dc(t, e) { return U(t.getUTCFullYear() % 100, e, 2); }
function xc(t, e) { return t = Ha(t), U(t.getUTCFullYear() % 100, e, 2); }
function _c(t, e) { return U(t.getUTCFullYear() % 1e4, e, 4); }
function gc(t, e) { var n = t.getUTCDay(); return t = n >= 4 || n === 0 ? Ft(t) : Ft.ceil(t), U(t.getUTCFullYear() % 1e4, e, 4); }
function yc() { return "+0000"; }
function Ya() { return "%"; }
function Pa(t) { return +t; }
function Fa(t) { return Math.floor(+t / 1e3); }
var Me, On, Ba, qa, Wa;
Gr({ dateTime: "%x, %X", date: "%-m/%-d/%Y", time: "%-I:%M:%S %p", periods: ["AM", "PM"], days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], shortDays: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], months: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"], shortMonths: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"] });
function Gr(t) { return Me = Xr(t), On = Me.format, Ba = Me.parse, qa = Me.utcFormat, Wa = Me.utcParse, Me; }
function Zr(t, e) { t = t.slice(); var n = 0, r = t.length - 1, i = t[n], o = t[r], a; return o < i && (a = n, n = r, r = a, a = i, i = o, o = a), t[n] = e.floor(i), t[r] = e.ceil(o), t; }
function vc(t) { return new Date(t); }
function wc(t) { return t instanceof Date ? +t : +new Date(+t); }
function Va(t, e, n, r, i, o, a, s, f, u) { var c = Le(), h = c.invert, l = c.domain, p = u(".%L"), g = u(":%S"), v = u("%I:%M"), T = u("%I %p"), k = u("%a %d"), $ = u("%b %d"), A = u("%B"), S = u("%Y"); function I(y) { return (f(y) < y ? p : s(y) < y ? g : a(y) < y ? v : o(y) < y ? T : r(y) < y ? i(y) < y ? k : $ : n(y) < y ? A : S)(y); } return c.invert = function (y) { return new Date(h(y)); }, c.domain = function (y) { return arguments.length ? l(Array.from(y, wc)) : l().map(vc); }, c.ticks = function (y) { var E = l(); return t(E[0], E[E.length - 1], y ?? 10); }, c.tickFormat = function (y, E) { return E == null ? I : u(E); }, c.nice = function (y) { var E = l(); return (!y || typeof y.range != "function") && (y = e(E[0], E[E.length - 1], y ?? 10)), y ? l(Zr(E, y)) : c; }, c.copy = function () { return Cn(c, Va(t, e, n, r, i, o, a, s, f, u)); }, c; }
function Xa() { return Yt.apply(Va(Br, qr, ft, be, $t, Dt, ye, ge, bt, On).domain([new Date(2e3, 0, 1), new Date(2e3, 0, 2)]), arguments); }
function Ga(t) { for (var e = t.length / 6 | 0, n = new Array(e), r = 0; r < e;)
    n[r] = "#" + t.slice(r * 6, ++r * 6); return n; }
var bc = Ga("4e79a7f28e2ce1575976b7b259a14fedc949af7aa1ff9da79c755fbab0ab");
function W(t) { return function () { return t; }; }
var Qr = Math.abs, nt = Math.atan2, Ut = Math.cos, Za = Math.max, In = Math.min, gt = Math.sin, ie = Math.sqrt, j = 1e-12, Te = Math.PI, Xe = Te / 2, ke = 2 * Te;
function Qa(t) { return t > 1 ? 0 : t < -1 ? Te : Math.acos(t); }
function Kr(t) { return t >= 1 ? Xe : t <= -1 ? -Xe : Math.asin(t); }
var Jr = Math.PI, jr = 2 * Jr, oe = 1e-6, Mc = jr - oe;
function Ka(t) { this._ += t[0]; for (let e = 1, n = t.length; e < n; ++e)
    this._ += arguments[e] + t[e]; }
function Tc(t) { let e = Math.floor(t); if (!(e >= 0))
    throw new Error(`invalid digits: ${t}`); if (e > 15)
    return Ka; let n = 10 ** e; return function (r) { this._ += r[0]; for (let i = 1, o = r.length; i < o; ++i)
    this._ += Math.round(arguments[i] * n) / n + r[i]; }; }
var ae = class {
    constructor(e) { this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = "", this._append = e == null ? Ka : Tc(e); }
    moveTo(e, n) { this._append `M${this._x0 = this._x1 = +e},${this._y0 = this._y1 = +n}`; }
    closePath() { this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._append `Z`); }
    lineTo(e, n) { this._append `L${this._x1 = +e},${this._y1 = +n}`; }
    quadraticCurveTo(e, n, r, i) { this._append `Q${+e},${+n},${this._x1 = +r},${this._y1 = +i}`; }
    bezierCurveTo(e, n, r, i, o, a) { this._append `C${+e},${+n},${+r},${+i},${this._x1 = +o},${this._y1 = +a}`; }
    arcTo(e, n, r, i, o) { if (e = +e, n = +n, r = +r, i = +i, o = +o, o < 0)
        throw new Error(`negative radius: ${o}`); let a = this._x1, s = this._y1, f = r - e, u = i - n, c = a - e, h = s - n, l = c * c + h * h; if (this._x1 === null)
        this._append `M${this._x1 = e},${this._y1 = n}`;
    else if (l > oe)
        if (!(Math.abs(h * f - u * c) > oe) || !o)
            this._append `L${this._x1 = e},${this._y1 = n}`;
        else {
            let p = r - a, g = i - s, v = f * f + u * u, T = p * p + g * g, k = Math.sqrt(v), $ = Math.sqrt(l), A = o * Math.tan((Jr - Math.acos((v + l - T) / (2 * k * $))) / 2), S = A / $, I = A / k;
            Math.abs(S - 1) > oe && this._append `L${e + S * c},${n + S * h}`, this._append `A${o},${o},0,0,${+(h * p > c * g)},${this._x1 = e + I * f},${this._y1 = n + I * u}`;
        } }
    arc(e, n, r, i, o, a) { if (e = +e, n = +n, r = +r, a = !!a, r < 0)
        throw new Error(`negative radius: ${r}`); let s = r * Math.cos(i), f = r * Math.sin(i), u = e + s, c = n + f, h = 1 ^ a, l = a ? i - o : o - i; this._x1 === null ? this._append `M${u},${c}` : (Math.abs(this._x1 - u) > oe || Math.abs(this._y1 - c) > oe) && this._append `L${u},${c}`, r && (l < 0 && (l = l % jr + jr), l > Mc ? this._append `A${r},${r},0,1,${h},${e - s},${n - f}A${r},${r},0,1,${h},${this._x1 = u},${this._y1 = c}` : l > oe && this._append `A${r},${r},0,${+(l >= Jr)},${h},${this._x1 = e + r * Math.cos(o)},${this._y1 = n + r * Math.sin(o)}`); }
    rect(e, n, r, i) { this._append `M${this._x0 = this._x1 = +e},${this._y0 = this._y1 = +n}h${r = +r}v${+i}h${-r}Z`; }
    toString() { return this._; }
};
function Ja() { return new ae; }
Ja.prototype = ae.prototype;
function En(t) { let e = 3; return t.digits = function (n) { if (!arguments.length)
    return e; if (n == null)
    e = null;
else {
    let r = Math.floor(n);
    if (!(r >= 0))
        throw new RangeError(`invalid digits: ${n}`);
    e = r;
} return t; }, () => new ae(e); }
function kc(t) { return t.innerRadius; }
function Sc(t) { return t.outerRadius; }
function Cc(t) { return t.startAngle; }
function Nc(t) { return t.endAngle; }
function Ac(t) { return t && t.padAngle; }
function Dc(t, e, n, r, i, o, a, s) { var f = n - t, u = r - e, c = a - i, h = s - o, l = h * f - c * u; if (!(l * l < j))
    return l = (c * (e - o) - h * (t - i)) / l, [t + l * f, e + l * u]; }
function Rn(t, e, n, r, i, o, a) { var s = t - n, f = e - r, u = (a ? o : -o) / ie(s * s + f * f), c = u * f, h = -u * s, l = t + c, p = e + h, g = n + c, v = r + h, T = (l + g) / 2, k = (p + v) / 2, $ = g - l, A = v - p, S = $ * $ + A * A, I = i - o, y = l * v - g * p, E = (A < 0 ? -1 : 1) * ie(Za(0, I * I * S - y * y)), Y = (y * A - $ * E) / S, D = (-y * $ - A * E) / S, B = (y * A + $ * E) / S, L = (-y * $ + A * E) / S, x = Y - T, m = D - k, d = B - T, M = L - k; return x * x + m * m > d * d + M * M && (Y = B, D = L), { cx: Y, cy: D, x01: -c, y01: -h, x11: Y * (i / I - 1), y11: D * (i / I - 1) }; }
function $c() { var t = kc, e = Sc, n = W(0), r = null, i = Cc, o = Nc, a = Ac, s = null, f = En(u); function u() { var c, h, l = +t.apply(this, arguments), p = +e.apply(this, arguments), g = i.apply(this, arguments) - Xe, v = o.apply(this, arguments) - Xe, T = Qr(v - g), k = v > g; if (s || (s = c = f()), p < l && (h = p, p = l, l = h), !(p > j))
    s.moveTo(0, 0);
else if (T > ke - j)
    s.moveTo(p * Ut(g), p * gt(g)), s.arc(0, 0, p, g, v, !k), l > j && (s.moveTo(l * Ut(v), l * gt(v)), s.arc(0, 0, l, v, g, k));
else {
    var $ = g, A = v, S = g, I = v, y = T, E = T, Y = a.apply(this, arguments) / 2, D = Y > j && (r ? +r.apply(this, arguments) : ie(l * l + p * p)), B = In(Qr(p - l) / 2, +n.apply(this, arguments)), L = B, x = B, m, d;
    if (D > j) {
        var M = Kr(D / l * gt(Y)), w = Kr(D / p * gt(Y));
        (y -= M * 2) > j ? (M *= k ? 1 : -1, S += M, I -= M) : (y = 0, S = I = (g + v) / 2), (E -= w * 2) > j ? (w *= k ? 1 : -1, $ += w, A -= w) : (E = 0, $ = A = (g + v) / 2);
    }
    var C = p * Ut($), N = p * gt($), P = l * Ut(I), F = l * gt(I);
    if (B > j) {
        var q = p * Ut(A), V = p * gt(A), K = l * Ut(S), lt = l * gt(S), Z;
        if (T < Te)
            if (Z = Dc(C, N, K, lt, q, V, P, F)) {
                var mt = C - Z[0], at = N - Z[1], G = q - Z[0], b = V - Z[1], O = 1 / gt(Qa((mt * G + at * b) / (ie(mt * mt + at * at) * ie(G * G + b * b))) / 2), R = ie(Z[0] * Z[0] + Z[1] * Z[1]);
                L = In(B, (l - R) / (O - 1)), x = In(B, (p - R) / (O + 1));
            }
            else
                L = x = 0;
    }
    E > j ? x > j ? (m = Rn(K, lt, C, N, p, x, k), d = Rn(q, V, P, F, p, x, k), s.moveTo(m.cx + m.x01, m.cy + m.y01), x < B ? s.arc(m.cx, m.cy, x, nt(m.y01, m.x01), nt(d.y01, d.x01), !k) : (s.arc(m.cx, m.cy, x, nt(m.y01, m.x01), nt(m.y11, m.x11), !k), s.arc(0, 0, p, nt(m.cy + m.y11, m.cx + m.x11), nt(d.cy + d.y11, d.cx + d.x11), !k), s.arc(d.cx, d.cy, x, nt(d.y11, d.x11), nt(d.y01, d.x01), !k))) : (s.moveTo(C, N), s.arc(0, 0, p, $, A, !k)) : s.moveTo(C, N), !(l > j) || !(y > j) ? s.lineTo(P, F) : L > j ? (m = Rn(P, F, q, V, l, -L, k), d = Rn(C, N, K, lt, l, -L, k), s.lineTo(m.cx + m.x01, m.cy + m.y01), L < B ? s.arc(m.cx, m.cy, L, nt(m.y01, m.x01), nt(d.y01, d.x01), !k) : (s.arc(m.cx, m.cy, L, nt(m.y01, m.x01), nt(m.y11, m.x11), !k), s.arc(0, 0, l, nt(m.cy + m.y11, m.cx + m.x11), nt(d.cy + d.y11, d.cx + d.x11), k), s.arc(d.cx, d.cy, L, nt(d.y11, d.x11), nt(d.y01, d.x01), !k))) : s.arc(0, 0, l, I, S, k);
} if (s.closePath(), c)
    return s = null, c + "" || null; } return u.centroid = function () { var c = (+t.apply(this, arguments) + +e.apply(this, arguments)) / 2, h = (+i.apply(this, arguments) + +o.apply(this, arguments)) / 2 - Te / 2; return [Ut(h) * c, gt(h) * c]; }, u.innerRadius = function (c) { return arguments.length ? (t = typeof c == "function" ? c : W(+c), u) : t; }, u.outerRadius = function (c) { return arguments.length ? (e = typeof c == "function" ? c : W(+c), u) : e; }, u.cornerRadius = function (c) { return arguments.length ? (n = typeof c == "function" ? c : W(+c), u) : n; }, u.padRadius = function (c) { return arguments.length ? (r = c == null ? null : typeof c == "function" ? c : W(+c), u) : r; }, u.startAngle = function (c) { return arguments.length ? (i = typeof c == "function" ? c : W(+c), u) : i; }, u.endAngle = function (c) { return arguments.length ? (o = typeof c == "function" ? c : W(+c), u) : o; }, u.padAngle = function (c) { return arguments.length ? (a = typeof c == "function" ? c : W(+c), u) : a; }, u.context = function (c) { return arguments.length ? (s = c ?? null, u) : s; }, u; }
var ey = Array.prototype.slice;
function Yn(t) { return typeof t == "object" && "length" in t ? t : Array.from(t); }
function ja(t) { this._context = t; }
ja.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._point = 0; }, lineEnd: function () { (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
            break;
        case 1: this._point = 2;
        default:
            this._context.lineTo(t, e);
            break;
    } } };
function ti(t) { return new ja(t); }
function ts(t) { return t[0]; }
function es(t) { return t[1]; }
function Oc(t, e) { var n = W(!0), r = null, i = ti, o = null, a = En(s); t = typeof t == "function" ? t : t === void 0 ? ts : W(t), e = typeof e == "function" ? e : e === void 0 ? es : W(e); function s(f) { var u, c = (f = Yn(f)).length, h, l = !1, p; for (r == null && (o = i(p = a())), u = 0; u <= c; ++u)
    !(u < c && n(h = f[u], u, f)) === l && ((l = !l) ? o.lineStart() : o.lineEnd()), l && o.point(+t(h, u, f), +e(h, u, f)); if (p)
    return o = null, p + "" || null; } return s.x = function (f) { return arguments.length ? (t = typeof f == "function" ? f : W(+f), s) : t; }, s.y = function (f) { return arguments.length ? (e = typeof f == "function" ? f : W(+f), s) : e; }, s.defined = function (f) { return arguments.length ? (n = typeof f == "function" ? f : W(!!f), s) : n; }, s.curve = function (f) { return arguments.length ? (i = f, r != null && (o = i(r)), s) : i; }, s.context = function (f) { return arguments.length ? (f == null ? r = o = null : o = i(r = f), s) : r; }, s; }
function ns(t, e) { return e < t ? -1 : e > t ? 1 : e >= t ? 0 : NaN; }
function rs(t) { return t; }
function Ic() { var t = rs, e = ns, n = null, r = W(0), i = W(ke), o = W(0); function a(s) { var f, u = (s = Yn(s)).length, c, h, l = 0, p = new Array(u), g = new Array(u), v = +r.apply(this, arguments), T = Math.min(ke, Math.max(-ke, i.apply(this, arguments) - v)), k, $ = Math.min(Math.abs(T) / u, o.apply(this, arguments)), A = $ * (T < 0 ? -1 : 1), S; for (f = 0; f < u; ++f)
    (S = g[p[f] = f] = +t(s[f], f, s)) > 0 && (l += S); for (e != null ? p.sort(function (I, y) { return e(g[I], g[y]); }) : n != null && p.sort(function (I, y) { return n(s[I], s[y]); }), f = 0, h = l ? (T - u * A) / l : 0; f < u; ++f, v = k)
    c = p[f], S = g[c], k = v + (S > 0 ? S * h : 0) + A, g[c] = { data: s[c], index: f, value: S, startAngle: v, endAngle: k, padAngle: $ }; return g; } return a.value = function (s) { return arguments.length ? (t = typeof s == "function" ? s : W(+s), a) : t; }, a.sortValues = function (s) { return arguments.length ? (e = s, n = null, a) : e; }, a.sort = function (s) { return arguments.length ? (n = s, e = null, a) : n; }, a.startAngle = function (s) { return arguments.length ? (r = typeof s == "function" ? s : W(+s), a) : r; }, a.endAngle = function (s) { return arguments.length ? (i = typeof s == "function" ? s : W(+s), a) : i; }, a.padAngle = function (s) { return arguments.length ? (o = typeof s == "function" ? s : W(+s), a) : o; }, a; }
function Se(t, e, n) { t._context.bezierCurveTo((2 * t._x0 + t._x1) / 3, (2 * t._y0 + t._y1) / 3, (t._x0 + 2 * t._x1) / 3, (t._y0 + 2 * t._y1) / 3, (t._x0 + 4 * t._x1 + e) / 6, (t._y0 + 4 * t._y1 + n) / 6); }
function Ge(t) { this._context = t; }
Ge.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 3: Se(this, this._x1, this._y1);
        case 2:
            this._context.lineTo(this._x1, this._y1);
            break;
    } (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
            break;
        case 1:
            this._point = 2;
            break;
        case 2: this._point = 3, this._context.lineTo((5 * this._x0 + this._x1) / 6, (5 * this._y0 + this._y1) / 6);
        default:
            Se(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e; } };
function Ec(t) { return new Ge(t); }
var Pn = class {
    constructor(e, n) { this._context = e, this._x = n; }
    areaStart() { this._line = 0; }
    areaEnd() { this._line = NaN; }
    lineStart() { this._point = 0; }
    lineEnd() { (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }
    point(e, n) { switch (e = +e, n = +n, this._point) {
        case 0: {
            this._point = 1, this._line ? this._context.lineTo(e, n) : this._context.moveTo(e, n);
            break;
        }
        case 1: this._point = 2;
        default: {
            this._x ? this._context.bezierCurveTo(this._x0 = (this._x0 + e) / 2, this._y0, this._x0, n, e, n) : this._context.bezierCurveTo(this._x0, this._y0 = (this._y0 + n) / 2, e, this._y0, e, n);
            break;
        }
    } this._x0 = e, this._y0 = n; }
};
function Rc(t) { return new Pn(t, !0); }
function Yc(t) { return new Pn(t, !1); }
function pt() { }
function is(t) { this._context = t; }
is.prototype = { areaStart: pt, areaEnd: pt, lineStart: function () { this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = NaN, this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 1: {
            this._context.moveTo(this._x2, this._y2), this._context.closePath();
            break;
        }
        case 2: {
            this._context.moveTo((this._x2 + 2 * this._x3) / 3, (this._y2 + 2 * this._y3) / 3), this._context.lineTo((this._x3 + 2 * this._x2) / 3, (this._y3 + 2 * this._y2) / 3), this._context.closePath();
            break;
        }
        case 3: {
            this.point(this._x2, this._y2), this.point(this._x3, this._y3), this.point(this._x4, this._y4);
            break;
        }
    } }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._x2 = t, this._y2 = e;
            break;
        case 1:
            this._point = 2, this._x3 = t, this._y3 = e;
            break;
        case 2:
            this._point = 3, this._x4 = t, this._y4 = e, this._context.moveTo((this._x0 + 4 * this._x1 + t) / 6, (this._y0 + 4 * this._y1 + e) / 6);
            break;
        default:
            Se(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e; } };
function Pc(t) { return new is(t); }
function os(t) { this._context = t; }
os.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._y0 = this._y1 = NaN, this._point = 0; }, lineEnd: function () { (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1;
            break;
        case 1:
            this._point = 2;
            break;
        case 2:
            this._point = 3;
            var n = (this._x0 + 4 * this._x1 + t) / 6, r = (this._y0 + 4 * this._y1 + e) / 6;
            this._line ? this._context.lineTo(n, r) : this._context.moveTo(n, r);
            break;
        case 3: this._point = 4;
        default:
            Se(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e; } };
function Fc(t) { return new os(t); }
function as(t, e) { this._basis = new Ge(t), this._beta = e; }
as.prototype = { lineStart: function () { this._x = [], this._y = [], this._basis.lineStart(); }, lineEnd: function () { var t = this._x, e = this._y, n = t.length - 1; if (n > 0)
        for (var r = t[0], i = e[0], o = t[n] - r, a = e[n] - i, s = -1, f; ++s <= n;)
            f = s / n, this._basis.point(this._beta * t[s] + (1 - this._beta) * (r + f * o), this._beta * e[s] + (1 - this._beta) * (i + f * a)); this._x = this._y = null, this._basis.lineEnd(); }, point: function (t, e) { this._x.push(+t), this._y.push(+e); } };
var Uc = (function t(e) { function n(r) { return e === 1 ? new Ge(r) : new as(r, e); } return n.beta = function (r) { return t(+r); }, n; })(.85);
function Ce(t, e, n) { t._context.bezierCurveTo(t._x1 + t._k * (t._x2 - t._x0), t._y1 + t._k * (t._y2 - t._y0), t._x2 + t._k * (t._x1 - e), t._y2 + t._k * (t._y1 - n), t._x2, t._y2); }
function Fn(t, e) { this._context = t, this._k = (1 - e) / 6; }
Fn.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 2:
            this._context.lineTo(this._x2, this._y2);
            break;
        case 3:
            Ce(this, this._x1, this._y1);
            break;
    } (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
            break;
        case 1:
            this._point = 2, this._x1 = t, this._y1 = e;
            break;
        case 2: this._point = 3;
        default:
            Ce(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var zc = (function t(e) { function n(r) { return new Fn(r, e); } return n.tension = function (r) { return t(+r); }, n; })(0);
function Un(t, e) { this._context = t, this._k = (1 - e) / 6; }
Un.prototype = { areaStart: pt, areaEnd: pt, lineStart: function () { this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 1: {
            this._context.moveTo(this._x3, this._y3), this._context.closePath();
            break;
        }
        case 2: {
            this._context.lineTo(this._x3, this._y3), this._context.closePath();
            break;
        }
        case 3: {
            this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
            break;
        }
    } }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._x3 = t, this._y3 = e;
            break;
        case 1:
            this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = e);
            break;
        case 2:
            this._point = 3, this._x5 = t, this._y5 = e;
            break;
        default:
            Ce(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var Lc = (function t(e) { function n(r) { return new Un(r, e); } return n.tension = function (r) { return t(+r); }, n; })(0);
function zn(t, e) { this._context = t, this._k = (1 - e) / 6; }
zn.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._point = 0; }, lineEnd: function () { (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1;
            break;
        case 1:
            this._point = 2;
            break;
        case 2:
            this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
            break;
        case 3: this._point = 4;
        default:
            Ce(this, t, e);
            break;
    } this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var Hc = (function t(e) { function n(r) { return new zn(r, e); } return n.tension = function (r) { return t(+r); }, n; })(0);
function Ze(t, e, n) { var r = t._x1, i = t._y1, o = t._x2, a = t._y2; if (t._l01_a > j) {
    var s = 2 * t._l01_2a + 3 * t._l01_a * t._l12_a + t._l12_2a, f = 3 * t._l01_a * (t._l01_a + t._l12_a);
    r = (r * s - t._x0 * t._l12_2a + t._x2 * t._l01_2a) / f, i = (i * s - t._y0 * t._l12_2a + t._y2 * t._l01_2a) / f;
} if (t._l23_a > j) {
    var u = 2 * t._l23_2a + 3 * t._l23_a * t._l12_a + t._l12_2a, c = 3 * t._l23_a * (t._l23_a + t._l12_a);
    o = (o * u + t._x1 * t._l23_2a - e * t._l12_2a) / c, a = (a * u + t._y1 * t._l23_2a - n * t._l12_2a) / c;
} t._context.bezierCurveTo(r, i, o, a, t._x2, t._y2); }
function ss(t, e) { this._context = t, this._alpha = e; }
ss.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 2:
            this._context.lineTo(this._x2, this._y2);
            break;
        case 3:
            this.point(this._x2, this._y2);
            break;
    } (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { if (t = +t, e = +e, this._point) {
        var n = this._x2 - t, r = this._y2 - e;
        this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha));
    } switch (this._point) {
        case 0:
            this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
            break;
        case 1:
            this._point = 2;
            break;
        case 2: this._point = 3;
        default:
            Ze(this, t, e);
            break;
    } this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var Bc = (function t(e) { function n(r) { return e ? new ss(r, e) : new Fn(r, 0); } return n.alpha = function (r) { return t(+r); }, n; })(.5);
function us(t, e) { this._context = t, this._alpha = e; }
us.prototype = { areaStart: pt, areaEnd: pt, lineStart: function () { this._x0 = this._x1 = this._x2 = this._x3 = this._x4 = this._x5 = this._y0 = this._y1 = this._y2 = this._y3 = this._y4 = this._y5 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 1: {
            this._context.moveTo(this._x3, this._y3), this._context.closePath();
            break;
        }
        case 2: {
            this._context.lineTo(this._x3, this._y3), this._context.closePath();
            break;
        }
        case 3: {
            this.point(this._x3, this._y3), this.point(this._x4, this._y4), this.point(this._x5, this._y5);
            break;
        }
    } }, point: function (t, e) { if (t = +t, e = +e, this._point) {
        var n = this._x2 - t, r = this._y2 - e;
        this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha));
    } switch (this._point) {
        case 0:
            this._point = 1, this._x3 = t, this._y3 = e;
            break;
        case 1:
            this._point = 2, this._context.moveTo(this._x4 = t, this._y4 = e);
            break;
        case 2:
            this._point = 3, this._x5 = t, this._y5 = e;
            break;
        default:
            Ze(this, t, e);
            break;
    } this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var qc = (function t(e) { function n(r) { return e ? new us(r, e) : new Un(r, 0); } return n.alpha = function (r) { return t(+r); }, n; })(.5);
function fs(t, e) { this._context = t, this._alpha = e; }
fs.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._x2 = this._y0 = this._y1 = this._y2 = NaN, this._l01_a = this._l12_a = this._l23_a = this._l01_2a = this._l12_2a = this._l23_2a = this._point = 0; }, lineEnd: function () { (this._line || this._line !== 0 && this._point === 3) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { if (t = +t, e = +e, this._point) {
        var n = this._x2 - t, r = this._y2 - e;
        this._l23_a = Math.sqrt(this._l23_2a = Math.pow(n * n + r * r, this._alpha));
    } switch (this._point) {
        case 0:
            this._point = 1;
            break;
        case 1:
            this._point = 2;
            break;
        case 2:
            this._point = 3, this._line ? this._context.lineTo(this._x2, this._y2) : this._context.moveTo(this._x2, this._y2);
            break;
        case 3: this._point = 4;
        default:
            Ze(this, t, e);
            break;
    } this._l01_a = this._l12_a, this._l12_a = this._l23_a, this._l01_2a = this._l12_2a, this._l12_2a = this._l23_2a, this._x0 = this._x1, this._x1 = this._x2, this._x2 = t, this._y0 = this._y1, this._y1 = this._y2, this._y2 = e; } };
var Wc = (function t(e) { function n(r) { return e ? new fs(r, e) : new zn(r, 0); } return n.alpha = function (r) { return t(+r); }, n; })(.5);
function ls(t) { this._context = t; }
ls.prototype = { areaStart: pt, areaEnd: pt, lineStart: function () { this._point = 0; }, lineEnd: function () { this._point && this._context.closePath(); }, point: function (t, e) { t = +t, e = +e, this._point ? this._context.lineTo(t, e) : (this._point = 1, this._context.moveTo(t, e)); } };
function Vc(t) { return new ls(t); }
function cs(t) { return t < 0 ? -1 : 1; }
function hs(t, e, n) { var r = t._x1 - t._x0, i = e - t._x1, o = (t._y1 - t._y0) / (r || i < 0 && -0), a = (n - t._y1) / (i || r < 0 && -0), s = (o * i + a * r) / (r + i); return (cs(o) + cs(a)) * Math.min(Math.abs(o), Math.abs(a), .5 * Math.abs(s)) || 0; }
function ps(t, e) { var n = t._x1 - t._x0; return n ? (3 * (t._y1 - t._y0) / n - e) / 2 : e; }
function ei(t, e, n) { var r = t._x0, i = t._y0, o = t._x1, a = t._y1, s = (o - r) / 3; t._context.bezierCurveTo(r + s, i + s * e, o - s, a - s * n, o, a); }
function Ln(t) { this._context = t; }
Ln.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x0 = this._x1 = this._y0 = this._y1 = this._t0 = NaN, this._point = 0; }, lineEnd: function () { switch (this._point) {
        case 2:
            this._context.lineTo(this._x1, this._y1);
            break;
        case 3:
            ei(this, this._t0, ps(this, this._t0));
            break;
    } (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line = 1 - this._line; }, point: function (t, e) { var n = NaN; if (t = +t, e = +e, !(t === this._x1 && e === this._y1)) {
        switch (this._point) {
            case 0:
                this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
                break;
            case 1:
                this._point = 2;
                break;
            case 2:
                this._point = 3, ei(this, ps(this, n = hs(this, t, e)), n);
                break;
            default:
                ei(this, this._t0, n = hs(this, t, e));
                break;
        }
        this._x0 = this._x1, this._x1 = t, this._y0 = this._y1, this._y1 = e, this._t0 = n;
    } } };
function ms(t) { this._context = new ds(t); }
(ms.prototype = Object.create(Ln.prototype)).point = function (t, e) { Ln.prototype.point.call(this, e, t); };
function ds(t) { this._context = t; }
ds.prototype = { moveTo: function (t, e) { this._context.moveTo(e, t); }, closePath: function () { this._context.closePath(); }, lineTo: function (t, e) { this._context.lineTo(e, t); }, bezierCurveTo: function (t, e, n, r, i, o) { this._context.bezierCurveTo(e, t, r, n, o, i); } };
function Xc(t) { return new Ln(t); }
function Gc(t) { return new ms(t); }
function _s(t) { this._context = t; }
_s.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x = [], this._y = []; }, lineEnd: function () { var t = this._x, e = this._y, n = t.length; if (n)
        if (this._line ? this._context.lineTo(t[0], e[0]) : this._context.moveTo(t[0], e[0]), n === 2)
            this._context.lineTo(t[1], e[1]);
        else
            for (var r = xs(t), i = xs(e), o = 0, a = 1; a < n; ++o, ++a)
                this._context.bezierCurveTo(r[0][o], i[0][o], r[1][o], i[1][o], t[a], e[a]); (this._line || this._line !== 0 && n === 1) && this._context.closePath(), this._line = 1 - this._line, this._x = this._y = null; }, point: function (t, e) { this._x.push(+t), this._y.push(+e); } };
function xs(t) { var e, n = t.length - 1, r, i = new Array(n), o = new Array(n), a = new Array(n); for (i[0] = 0, o[0] = 2, a[0] = t[0] + 2 * t[1], e = 1; e < n - 1; ++e)
    i[e] = 1, o[e] = 4, a[e] = 4 * t[e] + 2 * t[e + 1]; for (i[n - 1] = 2, o[n - 1] = 7, a[n - 1] = 8 * t[n - 1] + t[n], e = 1; e < n; ++e)
    r = i[e] / o[e - 1], o[e] -= r, a[e] -= r * a[e - 1]; for (i[n - 1] = a[n - 1] / o[n - 1], e = n - 2; e >= 0; --e)
    i[e] = (a[e] - i[e + 1]) / o[e]; for (o[n - 1] = (t[n] + i[n - 1]) / 2, e = 0; e < n - 1; ++e)
    o[e] = 2 * t[e + 1] - i[e + 1]; return [i, o]; }
function Zc(t) { return new _s(t); }
function Hn(t, e) { this._context = t, this._t = e; }
Hn.prototype = { areaStart: function () { this._line = 0; }, areaEnd: function () { this._line = NaN; }, lineStart: function () { this._x = this._y = NaN, this._point = 0; }, lineEnd: function () { 0 < this._t && this._t < 1 && this._point === 2 && this._context.lineTo(this._x, this._y), (this._line || this._line !== 0 && this._point === 1) && this._context.closePath(), this._line >= 0 && (this._t = 1 - this._t, this._line = 1 - this._line); }, point: function (t, e) { switch (t = +t, e = +e, this._point) {
        case 0:
            this._point = 1, this._line ? this._context.lineTo(t, e) : this._context.moveTo(t, e);
            break;
        case 1: this._point = 2;
        default: {
            if (this._t <= 0)
                this._context.lineTo(this._x, e), this._context.lineTo(t, e);
            else {
                var n = this._x * (1 - this._t) + t * this._t;
                this._context.lineTo(n, this._y), this._context.lineTo(n, e);
            }
            break;
        }
    } this._x = t, this._y = e; } };
function Qc(t) { return new Hn(t, .5); }
function Kc(t) { return new Hn(t, 0); }
function Jc(t) { return new Hn(t, 1); }
var jc = { value: () => { } };
function ys() { for (var t = 0, e = arguments.length, n = {}, r; t < e; ++t) {
    if (!(r = arguments[t] + "") || r in n || /[\s.]/.test(r))
        throw new Error("illegal type: " + r);
    n[r] = [];
} return new Bn(n); }
function Bn(t) { this._ = t; }
function th(t, e) { return t.trim().split(/^|\s+/).map(function (n) { var r = "", i = n.indexOf("."); if (i >= 0 && (r = n.slice(i + 1), n = n.slice(0, i)), n && !e.hasOwnProperty(n))
    throw new Error("unknown type: " + n); return { type: n, name: r }; }); }
Bn.prototype = ys.prototype = { constructor: Bn, on: function (t, e) { var n = this._, r = th(t + "", n), i, o = -1, a = r.length; if (arguments.length < 2) {
        for (; ++o < a;)
            if ((i = (t = r[o]).type) && (i = eh(n[i], t.name)))
                return i;
        return;
    } if (e != null && typeof e != "function")
        throw new Error("invalid callback: " + e); for (; ++o < a;)
        if (i = (t = r[o]).type)
            n[i] = gs(n[i], t.name, e);
        else if (e == null)
            for (i in n)
                n[i] = gs(n[i], t.name, null); return this; }, copy: function () { var t = {}, e = this._; for (var n in e)
        t[n] = e[n].slice(); return new Bn(t); }, call: function (t, e) { if ((i = arguments.length - 2) > 0)
        for (var n = new Array(i), r = 0, i, o; r < i; ++r)
            n[r] = arguments[r + 2]; if (!this._.hasOwnProperty(t))
        throw new Error("unknown type: " + t); for (o = this._[t], r = 0, i = o.length; r < i; ++r)
        o[r].value.apply(e, n); }, apply: function (t, e, n) { if (!this._.hasOwnProperty(t))
        throw new Error("unknown type: " + t); for (var r = this._[t], i = 0, o = r.length; i < o; ++i)
        r[i].value.apply(e, n); } };
function eh(t, e) { for (var n = 0, r = t.length, i; n < r; ++n)
    if ((i = t[n]).name === e)
        return i.value; }
function gs(t, e, n) { for (var r = 0, i = t.length; r < i; ++r)
    if (t[r].name === e) {
        t[r] = jc, t = t.slice(0, r).concat(t.slice(r + 1));
        break;
    } return n != null && t.push({ name: e, value: n }), t; }
var ni = ys;
var Ne = 0, Ke = 0, Qe = 0, ws = 1e3, qn, Je, Wn = 0, se = 0, Vn = 0, je = typeof performance == "object" && performance.now ? performance : Date, bs = typeof window == "object" && window.requestAnimationFrame ? window.requestAnimationFrame.bind(window) : function (t) { setTimeout(t, 17); };
function en() { return se || (bs(nh), se = je.now() + Vn); }
function nh() { se = 0; }
function tn() { this._call = this._time = this._next = null; }
tn.prototype = Xn.prototype = { constructor: tn, restart: function (t, e, n) { if (typeof t != "function")
        throw new TypeError("callback is not a function"); n = (n == null ? en() : +n) + (e == null ? 0 : +e), !this._next && Je !== this && (Je ? Je._next = this : qn = this, Je = this), this._call = t, this._time = n, ri(); }, stop: function () { this._call && (this._call = null, this._time = 1 / 0, ri()); } };
function Xn(t, e, n) { var r = new tn; return r.restart(t, e, n), r; }
function Ms() { en(), ++Ne; for (var t = qn, e; t;)
    (e = se - t._time) >= 0 && t._call.call(void 0, e), t = t._next; --Ne; }
function vs() { se = (Wn = je.now()) + Vn, Ne = Ke = 0; try {
    Ms();
}
finally {
    Ne = 0, ih(), se = 0;
} }
function rh() { var t = je.now(), e = t - Wn; e > ws && (Vn -= e, Wn = t); }
function ih() { for (var t, e = qn, n, r = 1 / 0; e;)
    e._call ? (r > e._time && (r = e._time), t = e, e = e._next) : (n = e._next, e._next = null, e = t ? t._next = n : qn = n); Je = t, ri(r); }
function ri(t) { if (!Ne) {
    Ke && (Ke = clearTimeout(Ke));
    var e = t - se;
    e > 24 ? (t < 1 / 0 && (Ke = setTimeout(vs, t - je.now() - Vn)), Qe && (Qe = clearInterval(Qe))) : (Qe || (Wn = je.now(), Qe = setInterval(rh, ws)), Ne = 1, bs(vs));
} }
function Gn(t, e, n) { var r = new tn; return e = e == null ? 0 : +e, r.restart(i => { r.stop(), t(i + e); }, e, n), r; }
var oh = ni("start", "end", "cancel", "interrupt"), ah = [], Ss = 0, Ts = 1, Qn = 2, Zn = 3, ks = 4, Kn = 5, nn = 6;
function zt(t, e, n, r, i, o) { var a = t.__transition; if (!a)
    t.__transition = {};
else if (n in a)
    return; sh(t, n, { name: e, index: r, group: i, on: oh, tween: ah, time: o.time, delay: o.delay, duration: o.duration, ease: o.ease, timer: null, state: Ss }); }
function rn(t, e) { var n = Q(t, e); if (n.state > Ss)
    throw new Error("too late; already scheduled"); return n; }
function rt(t, e) { var n = Q(t, e); if (n.state > Zn)
    throw new Error("too late; already running"); return n; }
function Q(t, e) { var n = t.__transition; if (!n || !(n = n[e]))
    throw new Error("transition not found"); return n; }
function sh(t, e, n) { var r = t.__transition, i; r[e] = n, n.timer = Xn(o, 0, n.time); function o(u) { n.state = Ts, n.timer.restart(a, n.delay, n.time), n.delay <= u && a(u - n.delay); } function a(u) { var c, h, l, p; if (n.state !== Ts)
    return f(); for (c in r)
    if (p = r[c], p.name === n.name) {
        if (p.state === Zn)
            return Gn(a);
        p.state === ks ? (p.state = nn, p.timer.stop(), p.on.call("interrupt", t, t.__data__, p.index, p.group), delete r[c]) : +c < e && (p.state = nn, p.timer.stop(), p.on.call("cancel", t, t.__data__, p.index, p.group), delete r[c]);
    } if (Gn(function () { n.state === Zn && (n.state = ks, n.timer.restart(s, n.delay, n.time), s(u)); }), n.state = Qn, n.on.call("start", t, t.__data__, n.index, n.group), n.state === Qn) {
    for (n.state = Zn, i = new Array(l = n.tween.length), c = 0, h = -1; c < l; ++c)
        (p = n.tween[c].value.call(t, t.__data__, n.index, n.group)) && (i[++h] = p);
    i.length = h + 1;
} } function s(u) { for (var c = u < n.duration ? n.ease.call(null, u / n.duration) : (n.timer.restart(f), n.state = Kn, 1), h = -1, l = i.length; ++h < l;)
    i[h].call(t, c); n.state === Kn && (n.on.call("end", t, t.__data__, n.index, n.group), f()); } function f() { n.state = nn, n.timer.stop(), delete r[e]; for (var u in r)
    return; delete t.__transition; } }
function Jn(t, e) { var n = t.__transition, r, i, o = !0, a; if (n) {
    e = e == null ? null : e + "";
    for (a in n) {
        if ((r = n[a]).name !== e) {
            o = !1;
            continue;
        }
        i = r.state > Qn && r.state < Kn, r.state = nn, r.timer.stop(), r.on.call(i ? "interrupt" : "cancel", t, t.__data__, r.index, r.group), delete n[a];
    }
    o && delete t.__transition;
} }
function Cs(t) { return this.each(function () { Jn(this, t); }); }
function uh(t, e) { var n, r; return function () { var i = rt(this, t), o = i.tween; if (o !== n) {
    r = n = o;
    for (var a = 0, s = r.length; a < s; ++a)
        if (r[a].name === e) {
            r = r.slice(), r.splice(a, 1);
            break;
        }
} i.tween = r; }; }
function fh(t, e, n) { var r, i; if (typeof n != "function")
    throw new Error; return function () { var o = rt(this, t), a = o.tween; if (a !== r) {
    i = (r = a).slice();
    for (var s = { name: e, value: n }, f = 0, u = i.length; f < u; ++f)
        if (i[f].name === e) {
            i[f] = s;
            break;
        }
    f === u && i.push(s);
} o.tween = i; }; }
function Ns(t, e) { var n = this._id; if (t += "", arguments.length < 2) {
    for (var r = Q(this.node(), n).tween, i = 0, o = r.length, a; i < o; ++i)
        if ((a = r[i]).name === t)
            return a.value;
    return null;
} return this.each((e == null ? uh : fh)(n, t, e)); }
function Ae(t, e, n) { var r = t._id; return t.each(function () { var i = rt(this, r); (i.value || (i.value = {}))[e] = n.apply(this, arguments); }), function (i) { return Q(i, r).value[e]; }; }
function jn(t, e) { var n; return (typeof e == "number" ? et : e instanceof xt ? Zt : (n = xt(e)) ? (e = n, Zt) : Pe)(t, e); }
function lh(t) { return function () { this.removeAttribute(t); }; }
function ch(t) { return function () { this.removeAttributeNS(t.space, t.local); }; }
function hh(t, e, n) { var r, i = n + "", o; return function () { var a = this.getAttribute(t); return a === i ? null : a === r ? o : o = e(r = a, n); }; }
function ph(t, e, n) { var r, i = n + "", o; return function () { var a = this.getAttributeNS(t.space, t.local); return a === i ? null : a === r ? o : o = e(r = a, n); }; }
function mh(t, e, n) { var r, i, o; return function () { var a, s = n(this), f; return s == null ? void this.removeAttribute(t) : (a = this.getAttribute(t), f = s + "", a === f ? null : a === r && f === i ? o : (i = f, o = e(r = a, s))); }; }
function dh(t, e, n) { var r, i, o; return function () { var a, s = n(this), f; return s == null ? void this.removeAttributeNS(t.space, t.local) : (a = this.getAttributeNS(t.space, t.local), f = s + "", a === f ? null : a === r && f === i ? o : (i = f, o = e(r = a, s))); }; }
function As(t, e) { var n = St(t), r = n === "transform" ? Sr : jn; return this.attrTween(t, typeof e == "function" ? (n.local ? dh : mh)(n, r, Ae(this, "attr." + t, e)) : e == null ? (n.local ? ch : lh)(n) : (n.local ? ph : hh)(n, r, e)); }
function xh(t, e) { return function (n) { this.setAttribute(t, e.call(this, n)); }; }
function _h(t, e) { return function (n) { this.setAttributeNS(t.space, t.local, e.call(this, n)); }; }
function gh(t, e) { var n, r; function i() { var o = e.apply(this, arguments); return o !== r && (n = (r = o) && _h(t, o)), n; } return i._value = e, i; }
function yh(t, e) { var n, r; function i() { var o = e.apply(this, arguments); return o !== r && (n = (r = o) && xh(t, o)), n; } return i._value = e, i; }
function Ds(t, e) { var n = "attr." + t; if (arguments.length < 2)
    return (n = this.tween(n)) && n._value; if (e == null)
    return this.tween(n, null); if (typeof e != "function")
    throw new Error; var r = St(t); return this.tween(n, (r.local ? gh : yh)(r, e)); }
function vh(t, e) { return function () { rn(this, t).delay = +e.apply(this, arguments); }; }
function wh(t, e) { return e = +e, function () { rn(this, t).delay = e; }; }
function $s(t) { var e = this._id; return arguments.length ? this.each((typeof t == "function" ? vh : wh)(e, t)) : Q(this.node(), e).delay; }
function bh(t, e) { return function () { rt(this, t).duration = +e.apply(this, arguments); }; }
function Mh(t, e) { return e = +e, function () { rt(this, t).duration = e; }; }
function Os(t) { var e = this._id; return arguments.length ? this.each((typeof t == "function" ? bh : Mh)(e, t)) : Q(this.node(), e).duration; }
function Th(t, e) { if (typeof e != "function")
    throw new Error; return function () { rt(this, t).ease = e; }; }
function Is(t) { var e = this._id; return arguments.length ? this.each(Th(e, t)) : Q(this.node(), e).ease; }
function kh(t, e) { return function () { var n = e.apply(this, arguments); if (typeof n != "function")
    throw new Error; rt(this, t).ease = n; }; }
function Es(t) { if (typeof t != "function")
    throw new Error; return this.each(kh(this._id, t)); }
function Rs(t) { typeof t != "function" && (t = Oe(t)); for (var e = this._groups, n = e.length, r = new Array(n), i = 0; i < n; ++i)
    for (var o = e[i], a = o.length, s = r[i] = [], f, u = 0; u < a; ++u)
        (f = o[u]) && t.call(f, f.__data__, u, o) && s.push(f); return new it(r, this._parents, this._name, this._id); }
function Ys(t) { if (t._id !== this._id)
    throw new Error; for (var e = this._groups, n = t._groups, r = e.length, i = n.length, o = Math.min(r, i), a = new Array(r), s = 0; s < o; ++s)
    for (var f = e[s], u = n[s], c = f.length, h = a[s] = new Array(c), l, p = 0; p < c; ++p)
        (l = f[p] || u[p]) && (h[p] = l); for (; s < r; ++s)
    a[s] = e[s]; return new it(a, this._parents, this._name, this._id); }
function Sh(t) { return (t + "").trim().split(/^|\s+/).every(function (e) { var n = e.indexOf("."); return n >= 0 && (e = e.slice(0, n)), !e || e === "start"; }); }
function Ch(t, e, n) { var r, i, o = Sh(e) ? rn : rt; return function () { var a = o(this, t), s = a.on; s !== r && (i = (r = s).copy()).on(e, n), a.on = i; }; }
function Ps(t, e) { var n = this._id; return arguments.length < 2 ? Q(this.node(), n).on.on(t) : this.each(Ch(n, t, e)); }
function Nh(t) { return function () { var e = this.parentNode; for (var n in this.__transition)
    if (+n !== t)
        return; e && e.removeChild(this); }; }
function Fs() { return this.on("end.remove", Nh(this._id)); }
function Us(t) { var e = this._name, n = this._id; typeof t != "function" && (t = Wt(t)); for (var r = this._groups, i = r.length, o = new Array(i), a = 0; a < i; ++a)
    for (var s = r[a], f = s.length, u = o[a] = new Array(f), c, h, l = 0; l < f; ++l)
        (c = s[l]) && (h = t.call(c, c.__data__, l, s)) && ("__data__" in c && (h.__data__ = c.__data__), u[l] = h, zt(u[l], e, n, l, u, Q(c, n))); return new it(o, this._parents, e, n); }
function zs(t) { var e = this._name, n = this._id; typeof t != "function" && (t = $e(t)); for (var r = this._groups, i = r.length, o = [], a = [], s = 0; s < i; ++s)
    for (var f = r[s], u = f.length, c, h = 0; h < u; ++h)
        if (c = f[h]) {
            for (var l = t.call(c, c.__data__, h, f), p, g = Q(c, n), v = 0, T = l.length; v < T; ++v)
                (p = l[v]) && zt(p, e, n, v, l, g);
            o.push(l), a.push(c);
        } return new it(o, a, e, n); }
var Ah = Ct.prototype.constructor;
function Ls() { return new Ah(this._groups, this._parents); }
function Dh(t, e) { var n, r, i; return function () { var o = It(this, t), a = (this.style.removeProperty(t), It(this, t)); return o === a ? null : o === n && a === r ? i : i = e(n = o, r = a); }; }
function Hs(t) { return function () { this.style.removeProperty(t); }; }
function $h(t, e, n) { var r, i = n + "", o; return function () { var a = It(this, t); return a === i ? null : a === r ? o : o = e(r = a, n); }; }
function Oh(t, e, n) { var r, i, o; return function () { var a = It(this, t), s = n(this), f = s + ""; return s == null && (f = s = (this.style.removeProperty(t), It(this, t))), a === f ? null : a === r && f === i ? o : (i = f, o = e(r = a, s)); }; }
function Ih(t, e) { var n, r, i, o = "style." + e, a = "end." + o, s; return function () { var f = rt(this, t), u = f.on, c = f.value[o] == null ? s || (s = Hs(e)) : void 0; (u !== n || i !== c) && (r = (n = u).copy()).on(a, i = c), f.on = r; }; }
function Bs(t, e, n) { var r = (t += "") == "transform" ? kr : jn; return e == null ? this.styleTween(t, Dh(t, r)).on("end.style." + t, Hs(t)) : typeof e == "function" ? this.styleTween(t, Oh(t, r, Ae(this, "style." + t, e))).each(Ih(this._id, t)) : this.styleTween(t, $h(t, r, e), n).on("end.style." + t, null); }
function Eh(t, e, n) { return function (r) { this.style.setProperty(t, e.call(this, r), n); }; }
function Rh(t, e, n) { var r, i; function o() { var a = e.apply(this, arguments); return a !== i && (r = (i = a) && Eh(t, a, n)), r; } return o._value = e, o; }
function qs(t, e, n) { var r = "style." + (t += ""); if (arguments.length < 2)
    return (r = this.tween(r)) && r._value; if (e == null)
    return this.tween(r, null); if (typeof e != "function")
    throw new Error; return this.tween(r, Rh(t, e, n ?? "")); }
function Yh(t) { return function () { this.textContent = t; }; }
function Ph(t) { return function () { var e = t(this); this.textContent = e ?? ""; }; }
function Ws(t) { return this.tween("text", typeof t == "function" ? Ph(Ae(this, "text", t)) : Yh(t == null ? "" : t + "")); }
function Fh(t) { return function (e) { this.textContent = t.call(this, e); }; }
function Uh(t) { var e, n; function r() { var i = t.apply(this, arguments); return i !== n && (e = (n = i) && Fh(i)), e; } return r._value = t, r; }
function Vs(t) { var e = "text"; if (arguments.length < 1)
    return (e = this.tween(e)) && e._value; if (t == null)
    return this.tween(e, null); if (typeof t != "function")
    throw new Error; return this.tween(e, Uh(t)); }
function Xs() { for (var t = this._name, e = this._id, n = tr(), r = this._groups, i = r.length, o = 0; o < i; ++o)
    for (var a = r[o], s = a.length, f, u = 0; u < s; ++u)
        if (f = a[u]) {
            var c = Q(f, e);
            zt(f, t, n, u, a, { time: c.time + c.delay + c.duration, delay: 0, duration: c.duration, ease: c.ease });
        } return new it(r, this._parents, t, n); }
function Gs() { var t, e, n = this, r = n._id, i = n.size(); return new Promise(function (o, a) { var s = { value: a }, f = { value: function () { --i === 0 && o(); } }; n.each(function () { var u = rt(this, r), c = u.on; c !== t && (e = (t = c).copy(), e._.cancel.push(s), e._.interrupt.push(s), e._.end.push(f)), u.on = e; }), i === 0 && o(); }); }
var zh = 0;
function it(t, e, n, r) { this._groups = t, this._parents = e, this._name = n, this._id = r; }
function Zs(t) { return Ct().transition(t); }
function tr() { return ++zh; }
var Ot = Ct.prototype;
it.prototype = Zs.prototype = { constructor: it, select: Us, selectAll: zs, selectChild: Ot.selectChild, selectChildren: Ot.selectChildren, filter: Rs, merge: Ys, selection: Ls, transition: Xs, call: Ot.call, nodes: Ot.nodes, node: Ot.node, size: Ot.size, empty: Ot.empty, each: Ot.each, on: Ps, attr: As, attrTween: Ds, style: Bs, styleTween: qs, text: Ws, textTween: Vs, remove: Fs, tween: Ns, delay: $s, duration: Os, ease: Is, easeVarying: Es, end: Gs, [Symbol.iterator]: Ot[Symbol.iterator] };
function er(t) { return ((t *= 2) <= 1 ? t * t * t : (t -= 2) * t * t + 2) / 2; }
var Lh = { time: null, delay: 0, duration: 250, ease: er };
function Hh(t, e) { for (var n; !(n = t.__transition) || !(n = n[e]);)
    if (!(t = t.parentNode))
        throw new Error(`transition ${e} not found`); return n; }
function Qs(t) { var e, n; t instanceof it ? (e = t._id, t = t._name) : (e = tr(), (n = Lh).time = en(), t = t == null ? null : t + ""); for (var r = this._groups, i = r.length, o = 0; o < i; ++o)
    for (var a = r[o], s = a.length, f, u = 0; u < s; ++u)
        (f = a[u]) && zt(f, t, e, u, a, n || Hh(f, e)); return new it(r, this._parents, t, e); }
Ct.prototype.interrupt = Cs;
Ct.prototype.transition = Qs;
var { abs: kw, max: Sw, min: Cw } = Math;
function Ks(t) { return [+t[0], +t[1]]; }
function Bh(t) { return [Ks(t[0]), Ks(t[1])]; }
var Nw = { name: "x", handles: ["w", "e"].map(ii), input: function (t, e) { return t == null ? null : [[+t[0], e[0][1]], [+t[1], e[1][1]]]; }, output: function (t) { return t && [t[0][0], t[1][0]]; } }, Aw = { name: "y", handles: ["n", "s"].map(ii), input: function (t, e) { return t == null ? null : [[e[0][0], +t[0]], [e[1][0], +t[1]]]; }, output: function (t) { return t && [t[0][1], t[1][1]]; } }, Dw = { name: "xy", handles: ["n", "w", "e", "s", "nw", "ne", "sw", "se"].map(ii), input: function (t) { return t == null ? null : Bh(t); }, output: function (t) { return t; } };
function ii(t) { return { type: t }; }
function Lt(t, e, n) { this.k = t, this.x = e, this.y = n; }
Lt.prototype = { constructor: Lt, scale: function (t) { return t === 1 ? this : new Lt(this.k * t, this.x, this.y); }, translate: function (t, e) { return t === 0 & e === 0 ? this : new Lt(this.k, this.x + this.k * t, this.y + this.k * e); }, apply: function (t) { return [t[0] * this.k + this.x, t[1] * this.k + this.y]; }, applyX: function (t) { return t * this.k + this.x; }, applyY: function (t) { return t * this.k + this.y; }, invert: function (t) { return [(t[0] - this.x) / this.k, (t[1] - this.y) / this.k]; }, invertX: function (t) { return (t - this.x) / this.k; }, invertY: function (t) { return (t - this.y) / this.k; }, rescaleX: function (t) { return t.copy().domain(t.range().map(this.invertX, this).map(t.invert, t)); }, rescaleY: function (t) { return t.copy().domain(t.range().map(this.invertY, this).map(t.invert, t)); }, toString: function () { return "translate(" + this.x + "," + this.y + ") scale(" + this.k + ")"; } };
var oi = new Lt(1, 0, 0);
ai.prototype = Lt.prototype;
function ai(t) { for (; !t.__zoom;)
    if (!(t = t.parentNode))
        return oi; return t.__zoom; }
export { ui as a, ct as b, Wh as c, li as d, ci as e, mu as f, du as g, pf as h, Cf as i, Tn as j, Sn as k, Bf as l, ze as m, Rr as n, zr as o, Jt as p, bt as q, ge as r, ye as s, Dt as t, $t as u, ve as v, _a as w, ga as x, Pt as y, ya as z, va as A, be as B, On as C, Xa as D, bc as E, $c as F, ti as G, Oc as H, Ic as I, Rc as J, Yc as K, Ec as L, Pc as M, Fc as N, Uc as O, zc as P, Lc as Q, Hc as R, Bc as S, qc as T, Wc as U, Vc as V, Xc as W, Gc as X, Zc as Y, Qc as Z, Kc as _, Jc as $ };
