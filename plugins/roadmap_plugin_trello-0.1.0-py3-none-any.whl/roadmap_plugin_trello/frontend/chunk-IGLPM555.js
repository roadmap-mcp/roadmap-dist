import { a as b, b as z, f as C } from "@nf-internal/chunk-OSQMNGTH";
function N() { return { async: !1, breaks: !1, extensions: null, gfm: !0, hooks: null, pedantic: !1, renderer: null, silent: !1, tokenizer: null, walkTokens: null }; }
var T = N();
function oe(n) { T = n; }
var $ = { exec: () => null };
function p(n, e = "") { let r = typeof n == "string" ? n : n.source, s = { replace: (t, i) => { let l = typeof i == "string" ? i : i.source; return l = l.replace(x.caret, "$1"), r = r.replace(t, l), s; }, getRegex: () => new RegExp(r, e) }; return s; }
var me = (() => { try {
    return !!new RegExp("(?<=1)(?<!1)");
}
catch {
    return !1;
} })(), x = { codeRemoveIndent: /^(?: {1,4}| {0,3}\t)/gm, outputLinkReplace: /\\([\[\]])/g, indentCodeCompensation: /^(\s+)(?:```)/, beginningSpace: /^\s+/, endingHash: /#$/, startingSpaceChar: /^ /, endingSpaceChar: / $/, nonSpaceChar: /[^ ]/, newLineCharGlobal: /\n/g, tabCharGlobal: /\t/g, multipleSpaceGlobal: /\s+/g, blankLine: /^[ \t]*$/, doubleBlankLine: /\n[ \t]*\n[ \t]*$/, blockquoteStart: /^ {0,3}>/, blockquoteSetextReplace: /\n {0,3}((?:=+|-+) *)(?=\n|$)/g, blockquoteSetextReplace2: /^ {0,3}>[ \t]?/gm, listReplaceNesting: /^ {1,4}(?=( {4})*[^ ])/g, listIsTask: /^\[[ xX]\] +\S/, listReplaceTask: /^\[[ xX]\] +/, listTaskCheckbox: /\[[ xX]\]/, anyLine: /\n.*\n/, hrefBrackets: /^<(.*)>$/, tableDelimiter: /[:|]/, tableAlignChars: /^\||\| *$/g, tableRowBlankLine: /\n[ \t]*$/, tableAlignRight: /^ *-+: *$/, tableAlignCenter: /^ *:-+: *$/, tableAlignLeft: /^ *:-+ *$/, startATag: /^<a /i, endATag: /^<\/a>/i, startPreScriptTag: /^<(pre|code|kbd|script)(\s|>)/i, endPreScriptTag: /^<\/(pre|code|kbd|script)(\s|>)/i, startAngleBracket: /^</, endAngleBracket: />$/, pedanticHrefTitle: /^([^'"]*[^\s])\s+(['"])(.*)\2/, unicodeAlphaNumeric: /[\p{L}\p{N}]/u, escapeTest: /[&<>"']/, escapeReplace: /[&<>"']/g, escapeTestNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/, escapeReplaceNoEncode: /[<>"']|&(?!(#\d{1,7}|#[Xx][a-fA-F0-9]{1,6}|\w+);)/g, caret: /(^|[^\[])\^/g, percentDecode: /%25/g, findPipe: /\|/g, splitPipe: / \|/, slashPipe: /\\\|/g, carriageReturn: /\r\n|\r/g, spaceLine: /^ +$/gm, notSpaceStart: /^\S*/, endingNewline: /\n$/, listItemRegex: n => new RegExp(`^( {0,3}${n})((?:[	 ][^\\n]*)?(?:\\n|$))`), nextBulletRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}(?:[*+-]|\\d{1,9}[.)])((?:[ 	][^\\n]*)?(?:\\n|$))`), hrRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}((?:- *){3,}|(?:_ *){3,}|(?:\\* *){3,})(?:\\n+|$)`), fencesBeginRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}(?:\`\`\`|~~~)`), headingBeginRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}#`), htmlBeginRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}<(?:[a-z].*>|!--)`, "i"), blockquoteBeginRegex: n => new RegExp(`^ {0,${Math.min(3, n - 1)}}>`) }, ye = /^(?:[ \t]*(?:\n|$))+/, Re = /^((?: {4}| {0,3}\t)[^\n]+(?:\n(?:[ \t]*(?:\n|$))*)?)+/, $e = /^ {0,3}(`{3,}(?=[^`\n]*(?:\n|$))|~{3,})([^\n]*)(?:\n|$)(?:|([\s\S]*?)(?:\n|$))(?: {0,3}\1[~`]* *(?=\n|$)|$)/, B = /^ {0,3}((?:-[\t ]*){3,}|(?:_[ \t]*){3,}|(?:\*[ \t]*){3,})(?:\n+|$)/, Se = /^ {0,3}(#{1,6})(?=\s|$)(.*)(?:\n+|$)/, G = / {0,3}(?:[*+-]|\d{1,9}[.)])/, ce = /^(?!bull |blockCode|fences|blockquote|heading|html|table)((?:.|\n(?!\s*?\n|bull |blockCode|fences|blockquote|heading|html|table))+?)\n {0,3}(=+|-+) *(?:\n+|$)/, he = p(ce).replace(/bull/g, G).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/\|table/g, "").getRegex(), Te = p(ce).replace(/bull/g, G).replace(/blockCode/g, /(?: {4}| {0,3}\t)/).replace(/fences/g, / {0,3}(?:`{3,}|~{3,})/).replace(/blockquote/g, / {0,3}>/).replace(/heading/g, / {0,3}#{1,6}/).replace(/html/g, / {0,3}<[^\n>]+>\n/).replace(/table/g, / {0,3}\|?(?:[:\- ]*\|)+[\:\- ]*\n/).getRegex(), X = /^([^\n]+(?:\n(?!hr|heading|lheading|blockquote|fences|list|html|table| +\n)[^\n]+)*)/, ze = /^[^\n]+/, W = /(?!\s*\])(?:\\[\s\S]|[^\[\]\\])+/, Ae = p(/^ {0,3}\[(label)\]: *(?:\n[ \t]*)?([^<\s][^\s]*|<.*?>)(?:(?: +(?:\n[ \t]*)?| *\n[ \t]*)(title))? *(?:\n+|$)/).replace("label", W).replace("title", /(?:"(?:\\"?|[^"\\])*"|'[^'\n]*(?:\n[^'\n]+)*\n?'|\([^()]*\))/).getRegex(), Pe = p(/^(bull)([ \t][^\n]+?)?(?:\n|$)/).replace(/bull/g, G).getRegex(), D = "address|article|aside|base|basefont|blockquote|body|caption|center|col|colgroup|dd|details|dialog|dir|div|dl|dt|fieldset|figcaption|figure|footer|form|frame|frameset|h[1-6]|head|header|hr|html|iframe|legend|li|link|main|menu|menuitem|meta|nav|noframes|ol|optgroup|option|p|param|search|section|summary|table|tbody|td|tfoot|th|thead|title|tr|track|ul", F = /<!--(?:-?>|[\s\S]*?(?:-->|$))/, _e = p("^ {0,3}(?:<(script|pre|style|textarea)[\\s>][\\s\\S]*?(?:</\\1>[^\\n]*\\n+|$)|comment[^\\n]*(\\n+|$)|<\\?[\\s\\S]*?(?:\\?>\\n*|$)|<![A-Z][\\s\\S]*?(?:>\\n*|$)|<!\\[CDATA\\[[\\s\\S]*?(?:\\]\\]>\\n*|$)|</?(tag)(?: +|\\n|/?>)[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|<(?!script|pre|style|textarea)([a-z][\\w-]*)(?:attribute)*? */?>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$)|</(?!script|pre|style|textarea)[a-z][\\w-]*\\s*>(?=[ \\t]*(?:\\n|$))[\\s\\S]*?(?:(?:\\n[ 	]*)+\\n|$))", "i").replace("comment", F).replace("tag", D).replace("attribute", / +[a-zA-Z:_][\w.:-]*(?: *= *"[^"\n]*"| *= *'[^'\n]*'| *= *[^\s"'=<>`]+)?/).getRegex(), pe = p(X).replace("hr", B).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("|table", "").replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", D).getRegex(), Ie = p(/^( {0,3}> ?(paragraph|[^\n]*)(?:\n|$))+/).replace("paragraph", pe).getRegex(), U = { blockquote: Ie, code: Re, def: Ae, fences: $e, heading: Se, hr: B, html: _e, lheading: he, list: Pe, newline: ye, paragraph: pe, table: $, text: ze }, re = p("^ *([^\\n ].*)\\n {0,3}((?:\\| *)?:?-+:? *(?:\\| *:?-+:? *)*(?:\\| *)?)(?:\\n((?:(?! *\\n|hr|heading|blockquote|code|fences|list|html).*(?:\\n|$))*)\\n*|$)").replace("hr", B).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("blockquote", " {0,3}>").replace("code", "(?: {4}| {0,3}	)[^\\n]").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", D).getRegex(), Le = z(b({}, U), { lheading: Te, table: re, paragraph: p(X).replace("hr", B).replace("heading", " {0,3}#{1,6}(?:\\s|$)").replace("|lheading", "").replace("table", re).replace("blockquote", " {0,3}>").replace("fences", " {0,3}(?:`{3,}(?=[^`\\n]*\\n)|~{3,})[^\\n]*\\n").replace("list", " {0,3}(?:[*+-]|1[.)])[ \\t]").replace("html", "</?(?:tag)(?: +|\\n|/?>)|<(?:script|pre|style|textarea|!--)").replace("tag", D).getRegex() }), Be = z(b({}, U), { html: p(`^ *(?:comment *(?:\\n|\\s*$)|<(tag)[\\s\\S]+?</\\1> *(?:\\n{2,}|\\s*$)|<tag(?:"[^"]*"|'[^']*'|\\s[^'"/>\\s]*)*?/?> *(?:\\n{2,}|\\s*$))`).replace("comment", F).replace(/tag/g, "(?!(?:a|em|strong|small|s|cite|q|dfn|abbr|data|time|code|var|samp|kbd|sub|sup|i|b|u|mark|ruby|rt|rp|bdi|bdo|span|br|wbr|ins|del|img)\\b)\\w+(?!:|[^\\w\\s@]*@)\\b").getRegex(), def: /^ *\[([^\]]+)\]: *<?([^\s>]+)>?(?: +(["(][^\n]+[")]))? *(?:\n+|$)/, heading: /^(#{1,6})(.*)(?:\n+|$)/, fences: $, lheading: /^(.+?)\n {0,3}(=+|-+) *(?:\n+|$)/, paragraph: p(X).replace("hr", B).replace("heading", ` *#{1,6} *[^
]`).replace("lheading", he).replace("|table", "").replace("blockquote", " {0,3}>").replace("|fences", "").replace("|list", "").replace("|html", "").replace("|tag", "").getRegex() }), Ce = /^\\([!"#$%&'()*+,\-./:;<=>?@\[\]\\^_`{|}~])/, qe = /^(`+)([^`]|[^`][\s\S]*?[^`])\1(?!`)/, ue = /^( {2,}|\\)\n(?!\s*$)/, ve = /^(`+|[^`])(?:(?= {2,}\n)|[\s\S]*?(?:(?=[\\<!\[`*_]|\b_|$)|[^ ](?= {2,}\n)))/, A = /[\p{P}\p{S}]/u, M = /[\s\p{P}\p{S}]/u, J = /[^\s\p{P}\p{S}]/u, Ee = p(/^((?![*_])punctSpace)/, "u").replace(/punctSpace/g, M).getRegex(), ge = /(?!~)[\p{P}\p{S}]/u, Ze = /(?!~)[\s\p{P}\p{S}]/u, De = /(?:[^\s\p{P}\p{S}]|~)/u, Me = p(/link|precode-code|html/, "g").replace("link", /\[(?:[^\[\]`]|(?<a>`+)[^`]+\k<a>(?!`))*?\]\((?:\\[\s\S]|[^\\\(\)]|\((?:\\[\s\S]|[^\\\(\)])*\))*\)/).replace("precode-", me ? "(?<!`)()" : "(^^|[^`])").replace("code", /(?<b>`+)[^`]+\k<b>(?!`)/).replace("html", /<(?! )[^<>]*?>/).getRegex(), ke = /^(?:\*+(?:((?!\*)punct)|([^\s*]))?)|^_+(?:((?!_)punct)|([^\s_]))?/, Qe = p(ke, "u").replace(/punct/g, A).getRegex(), He = p(ke, "u").replace(/punct/g, ge).getRegex(), de = "^[^_*]*?__[^_*]*?\\*[^_*]*?(?=__)|[^*]+(?=[^*])|(?!\\*)punct(\\*+)(?=[\\s]|$)|notPunctSpace(\\*+)(?!\\*)(?=punctSpace|$)|(?!\\*)punctSpace(\\*+)(?=notPunctSpace)|[\\s](\\*+)(?!\\*)(?=punct)|(?!\\*)punct(\\*+)(?!\\*)(?=punct)|notPunctSpace(\\*+)(?=notPunctSpace)", Oe = p(de, "gu").replace(/notPunctSpace/g, J).replace(/punctSpace/g, M).replace(/punct/g, A).getRegex(), je = p(de, "gu").replace(/notPunctSpace/g, De).replace(/punctSpace/g, Ze).replace(/punct/g, ge).getRegex(), Ne = p("^[^_*]*?\\*\\*[^_*]*?_[^_*]*?(?=\\*\\*)|[^_]+(?=[^_])|(?!_)punct(_+)(?=[\\s]|$)|notPunctSpace(_+)(?!_)(?=punctSpace|$)|(?!_)punctSpace(_+)(?=notPunctSpace)|[\\s](_+)(?!_)(?=punct)|(?!_)punct(_+)(?!_)(?=punct)", "gu").replace(/notPunctSpace/g, J).replace(/punctSpace/g, M).replace(/punct/g, A).getRegex(), Ge = p(/^~~?(?:((?!~)punct)|[^\s~])/, "u").replace(/punct/g, A).getRegex(), Xe = "^[^~]+(?=[^~])|(?!~)punct(~~?)(?=[\\s]|$)|notPunctSpace(~~?)(?!~)(?=punctSpace|$)|(?!~)punctSpace(~~?)(?=notPunctSpace)|[\\s](~~?)(?!~)(?=punct)|(?!~)punct(~~?)(?!~)(?=punct)|notPunctSpace(~~?)(?=notPunctSpace)", We = p(Xe, "gu").replace(/notPunctSpace/g, J).replace(/punctSpace/g, M).replace(/punct/g, A).getRegex(), Fe = p(/\\(punct)/, "gu").replace(/punct/g, A).getRegex(), Ue = p(/^<(scheme:[^\s\x00-\x1f<>]*|email)>/).replace("scheme", /[a-zA-Z][a-zA-Z0-9+.-]{1,31}/).replace("email", /[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(@)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+(?![-_])/).getRegex(), Je = p(F).replace("(?:-->|$)", "-->").getRegex(), Ke = p("^comment|^</[a-zA-Z][\\w:-]*\\s*>|^<[a-zA-Z][\\w-]*(?:attribute)*?\\s*/?>|^<\\?[\\s\\S]*?\\?>|^<![a-zA-Z]+\\s[\\s\\S]*?>|^<!\\[CDATA\\[[\\s\\S]*?\\]\\]>").replace("comment", Je).replace("attribute", /\s+[a-zA-Z:_][\w.:-]*(?:\s*=\s*"[^"]*"|\s*=\s*'[^']*'|\s*=\s*[^\s"'=<>`]+)?/).getRegex(), v = /(?:\[(?:\\[\s\S]|[^\[\]\\])*\]|\\[\s\S]|`+(?!`)[^`]*?`+(?!`)|``+(?=\])|[^\[\]\\`])*?/, Ve = p(/^!?\[(label)\]\(\s*(href)(?:(?:[ \t]+(?:\n[ \t]*)?|\n[ \t]*)(title))?\s*\)/).replace("label", v).replace("href", /<(?:\\.|[^\n<>\\])+>|[^ \t\n\x00-\x1f]*/).replace("title", /"(?:\\"?|[^"\\])*"|'(?:\\'?|[^'\\])*'|\((?:\\\)?|[^)\\])*\)/).getRegex(), fe = p(/^!?\[(label)\]\[(ref)\]/).replace("label", v).replace("ref", W).getRegex(), xe = p(/^!?\[(ref)\](?:\[\])?/).replace("ref", W).getRegex(), Ye = p("reflink|nolink(?!\\()", "g").replace("reflink", fe).replace("nolink", xe).getRegex(), ne = /[hH][tT][tT][pP][sS]?|[fF][tT][pP]/, K = { _backpedal: $, anyPunctuation: Fe, autolink: Ue, blockSkip: Me, br: ue, code: qe, del: $, delLDelim: $, delRDelim: $, emStrongLDelim: Qe, emStrongRDelimAst: Oe, emStrongRDelimUnd: Ne, escape: Ce, link: Ve, nolink: xe, punctuation: Ee, reflink: fe, reflinkSearch: Ye, tag: Ke, text: ve, url: $ }, et = z(b({}, K), { link: p(/^!?\[(label)\]\((.*?)\)/).replace("label", v).getRegex(), reflink: p(/^!?\[(label)\]\s*\[([^\]]*)\]/).replace("label", v).getRegex() }), H = z(b({}, K), { emStrongRDelimAst: je, emStrongLDelim: He, delLDelim: Ge, delRDelim: We, url: p(/^((?:protocol):\/\/|www\.)(?:[a-zA-Z0-9\-]+\.?)+[^\s<]*|^email/).replace("protocol", ne).replace("email", /[A-Za-z0-9._+-]+(@)[a-zA-Z0-9-_]+(?:\.[a-zA-Z0-9-_]*[a-zA-Z0-9])+(?![-_])/).getRegex(), _backpedal: /(?:[^?!.,:;*_'"~()&]+|\([^)]*\)|&(?![a-zA-Z0-9]+;$)|[?!.,:;*_'"~)]+(?!$))+/, del: /^(~~?)(?=[^\s~])((?:\\[\s\S]|[^\\])*?(?:\\[\s\S]|[^\s~\\]))\1(?=[^~]|$)/, text: p(/^([`~]+|[^`~])(?:(?= {2,}\n)|(?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)|[\s\S]*?(?:(?=[\\<!\[`*~_]|\b_|protocol:\/\/|www\.|$)|[^ ](?= {2,}\n)|[^a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-](?=[a-zA-Z0-9.!#$%&'*+\/=?_`{\|}~-]+@)))/).replace("protocol", ne).getRegex() }), tt = z(b({}, H), { br: p(ue).replace("{2,}", "*").getRegex(), text: p(H.text).replace("\\b_", "\\b_| {2,}\\n").replace(/\{2,\}/g, "*").getRegex() }), q = { normal: U, gfm: Le, pedantic: Be }, _ = { normal: K, gfm: H, breaks: tt, pedantic: et }, rt = { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }, se = n => rt[n];
function y(n, e) { if (e) {
    if (x.escapeTest.test(n))
        return n.replace(x.escapeReplace, se);
}
else if (x.escapeTestNoEncode.test(n))
    return n.replace(x.escapeReplaceNoEncode, se); return n; }
function le(n) { try {
    n = encodeURI(n).replace(x.percentDecode, "%");
}
catch {
    return null;
} return n; }
function ie(n, e) { let r = n.replace(x.findPipe, (i, l, o) => { let a = !1, h = l; for (; --h >= 0 && o[h] === "\\";)
    a = !a; return a ? "|" : " |"; }), s = r.split(x.splitPipe), t = 0; if (s[0].trim() || s.shift(), s.length > 0 && !s.at(-1)?.trim() && s.pop(), e)
    if (s.length > e)
        s.splice(e);
    else
        for (; s.length < e;)
            s.push(""); for (; t < s.length; t++)
    s[t] = s[t].trim().replace(x.slashPipe, "|"); return s; }
function I(n, e, r) { let s = n.length; if (s === 0)
    return ""; let t = 0; for (; t < s;) {
    let i = n.charAt(s - t - 1);
    if (i === e && !r)
        t++;
    else if (i !== e && r)
        t++;
    else
        break;
} return n.slice(0, s - t); }
function nt(n, e) { if (n.indexOf(e[1]) === -1)
    return -1; let r = 0; for (let s = 0; s < n.length; s++)
    if (n[s] === "\\")
        s++;
    else if (n[s] === e[0])
        r++;
    else if (n[s] === e[1] && (r--, r < 0))
        return s; return r > 0 ? -2 : -1; }
function st(n, e = 0) { let r = e, s = ""; for (let t of n)
    if (t === "	") {
        let i = 4 - r % 4;
        s += " ".repeat(i), r += i;
    }
    else
        s += t, r++; return s; }
function ae(n, e, r, s, t) { let i = e.href, l = e.title || null, o = n[1].replace(t.other.outputLinkReplace, "$1"); s.state.inLink = !0; let a = { type: n[0].charAt(0) === "!" ? "image" : "link", raw: r, href: i, title: l, text: o, tokens: s.inlineTokens(o) }; return s.state.inLink = !1, a; }
function lt(n, e, r) {
    let s = n.match(r.other.indentCodeCompensation);
    if (s === null)
        return e;
    let t = s[1];
    return e.split(`
`).map(i => { let l = i.match(r.other.beginningSpace); if (l === null)
        return i; let [o] = l; return o.length >= t.length ? i.slice(t.length) : i; }).join(`
`);
}
var E = class {
    options;
    rules;
    lexer;
    constructor(n) { this.options = n || T; }
    space(n) { let e = this.rules.block.newline.exec(n); if (e && e[0].length > 0)
        return { type: "space", raw: e[0] }; }
    code(n) {
        let e = this.rules.block.code.exec(n);
        if (e) {
            let r = e[0].replace(this.rules.other.codeRemoveIndent, "");
            return { type: "code", raw: e[0], codeBlockStyle: "indented", text: this.options.pedantic ? r : I(r, `
`) };
        }
    }
    fences(n) { let e = this.rules.block.fences.exec(n); if (e) {
        let r = e[0], s = lt(r, e[3] || "", this.rules);
        return { type: "code", raw: r, lang: e[2] ? e[2].trim().replace(this.rules.inline.anyPunctuation, "$1") : e[2], text: s };
    } }
    heading(n) { let e = this.rules.block.heading.exec(n); if (e) {
        let r = e[2].trim();
        if (this.rules.other.endingHash.test(r)) {
            let s = I(r, "#");
            (this.options.pedantic || !s || this.rules.other.endingSpaceChar.test(s)) && (r = s.trim());
        }
        return { type: "heading", raw: e[0], depth: e[1].length, text: r, tokens: this.lexer.inline(r) };
    } }
    hr(n) {
        let e = this.rules.block.hr.exec(n);
        if (e)
            return { type: "hr", raw: I(e[0], `
`) };
    }
    blockquote(n) {
        let e = this.rules.block.blockquote.exec(n);
        if (e) {
            let r = I(e[0], `
`).split(`
`), s = "", t = "", i = [];
            for (; r.length > 0;) {
                let l = !1, o = [], a;
                for (a = 0; a < r.length; a++)
                    if (this.rules.other.blockquoteStart.test(r[a]))
                        o.push(r[a]), l = !0;
                    else if (!l)
                        o.push(r[a]);
                    else
                        break;
                r = r.slice(a);
                let h = o.join(`
`), c = h.replace(this.rules.other.blockquoteSetextReplace, `
    $1`).replace(this.rules.other.blockquoteSetextReplace2, "");
                s = s ? `${s}
${h}` : h, t = t ? `${t}
${c}` : c;
                let g = this.lexer.state.top;
                if (this.lexer.state.top = !0, this.lexer.blockTokens(c, i, !0), this.lexer.state.top = g, r.length === 0)
                    break;
                let u = i.at(-1);
                if (u?.type === "code")
                    break;
                if (u?.type === "blockquote") {
                    let f = u, d = f.raw + `
` + r.join(`
`), R = this.blockquote(d);
                    i[i.length - 1] = R, s = s.substring(0, s.length - f.raw.length) + R.raw, t = t.substring(0, t.length - f.text.length) + R.text;
                    break;
                }
                else if (u?.type === "list") {
                    let f = u, d = f.raw + `
` + r.join(`
`), R = this.list(d);
                    i[i.length - 1] = R, s = s.substring(0, s.length - u.raw.length) + R.raw, t = t.substring(0, t.length - f.raw.length) + R.raw, r = d.substring(i.at(-1).raw.length).split(`
`);
                    continue;
                }
            }
            return { type: "blockquote", raw: s, tokens: i, text: t };
        }
    }
    list(n) {
        let e = this.rules.block.list.exec(n);
        if (e) {
            let r = e[1].trim(), s = r.length > 1, t = { type: "list", raw: "", ordered: s, start: s ? +r.slice(0, -1) : "", loose: !1, items: [] };
            r = s ? `\\d{1,9}\\${r.slice(-1)}` : `\\${r}`, this.options.pedantic && (r = s ? r : "[*+-]");
            let i = this.rules.other.listItemRegex(r), l = !1;
            for (; n;) {
                let a = !1, h = "", c = "";
                if (!(e = i.exec(n)) || this.rules.block.hr.test(n))
                    break;
                h = e[0], n = n.substring(h.length);
                let g = st(e[2].split(`
`, 1)[0], e[1].length), u = n.split(`
`, 1)[0], f = !g.trim(), d = 0;
                if (this.options.pedantic ? (d = 2, c = g.trimStart()) : f ? d = e[1].length + 1 : (d = g.search(this.rules.other.nonSpaceChar), d = d > 4 ? 1 : d, c = g.slice(d), d += e[1].length), f && this.rules.other.blankLine.test(u) && (h += u + `
`, n = n.substring(u.length + 1), a = !0), !a) {
                    let R = this.rules.other.nextBulletRegex(d), Y = this.rules.other.hrRegex(d), ee = this.rules.other.fencesBeginRegex(d), te = this.rules.other.headingBeginRegex(d), be = this.rules.other.htmlBeginRegex(d), we = this.rules.other.blockquoteBeginRegex(d);
                    for (; n;) {
                        let Q = n.split(`
`, 1)[0], P;
                        if (u = Q, this.options.pedantic ? (u = u.replace(this.rules.other.listReplaceNesting, "  "), P = u) : P = u.replace(this.rules.other.tabCharGlobal, "    "), ee.test(u) || te.test(u) || be.test(u) || we.test(u) || R.test(u) || Y.test(u))
                            break;
                        if (P.search(this.rules.other.nonSpaceChar) >= d || !u.trim())
                            c += `
` + P.slice(d);
                        else {
                            if (f || g.replace(this.rules.other.tabCharGlobal, "    ").search(this.rules.other.nonSpaceChar) >= 4 || ee.test(g) || te.test(g) || Y.test(g))
                                break;
                            c += `
` + u;
                        }
                        f = !u.trim(), h += Q + `
`, n = n.substring(Q.length + 1), g = P.slice(d);
                    }
                }
                t.loose || (l ? t.loose = !0 : this.rules.other.doubleBlankLine.test(h) && (l = !0)), t.items.push({ type: "list_item", raw: h, task: !!this.options.gfm && this.rules.other.listIsTask.test(c), loose: !1, text: c, tokens: [] }), t.raw += h;
            }
            let o = t.items.at(-1);
            if (o)
                o.raw = o.raw.trimEnd(), o.text = o.text.trimEnd();
            else
                return;
            t.raw = t.raw.trimEnd();
            for (let a of t.items) {
                if (this.lexer.state.top = !1, a.tokens = this.lexer.blockTokens(a.text, []), a.task) {
                    if (a.text = a.text.replace(this.rules.other.listReplaceTask, ""), a.tokens[0]?.type === "text" || a.tokens[0]?.type === "paragraph") {
                        a.tokens[0].raw = a.tokens[0].raw.replace(this.rules.other.listReplaceTask, ""), a.tokens[0].text = a.tokens[0].text.replace(this.rules.other.listReplaceTask, "");
                        for (let c = this.lexer.inlineQueue.length - 1; c >= 0; c--)
                            if (this.rules.other.listIsTask.test(this.lexer.inlineQueue[c].src)) {
                                this.lexer.inlineQueue[c].src = this.lexer.inlineQueue[c].src.replace(this.rules.other.listReplaceTask, "");
                                break;
                            }
                    }
                    let h = this.rules.other.listTaskCheckbox.exec(a.raw);
                    if (h) {
                        let c = { type: "checkbox", raw: h[0] + " ", checked: h[0] !== "[ ]" };
                        a.checked = c.checked, t.loose ? a.tokens[0] && ["paragraph", "text"].includes(a.tokens[0].type) && "tokens" in a.tokens[0] && a.tokens[0].tokens ? (a.tokens[0].raw = c.raw + a.tokens[0].raw, a.tokens[0].text = c.raw + a.tokens[0].text, a.tokens[0].tokens.unshift(c)) : a.tokens.unshift({ type: "paragraph", raw: c.raw, text: c.raw, tokens: [c] }) : a.tokens.unshift(c);
                    }
                }
                if (!t.loose) {
                    let h = a.tokens.filter(g => g.type === "space"), c = h.length > 0 && h.some(g => this.rules.other.anyLine.test(g.raw));
                    t.loose = c;
                }
            }
            if (t.loose)
                for (let a of t.items) {
                    a.loose = !0;
                    for (let h of a.tokens)
                        h.type === "text" && (h.type = "paragraph");
                }
            return t;
        }
    }
    html(n) { let e = this.rules.block.html.exec(n); if (e)
        return { type: "html", block: !0, raw: e[0], pre: e[1] === "pre" || e[1] === "script" || e[1] === "style", text: e[0] }; }
    def(n) { let e = this.rules.block.def.exec(n); if (e) {
        let r = e[1].toLowerCase().replace(this.rules.other.multipleSpaceGlobal, " "), s = e[2] ? e[2].replace(this.rules.other.hrefBrackets, "$1").replace(this.rules.inline.anyPunctuation, "$1") : "", t = e[3] ? e[3].substring(1, e[3].length - 1).replace(this.rules.inline.anyPunctuation, "$1") : e[3];
        return { type: "def", tag: r, raw: e[0], href: s, title: t };
    } }
    table(n) {
        let e = this.rules.block.table.exec(n);
        if (!e || !this.rules.other.tableDelimiter.test(e[2]))
            return;
        let r = ie(e[1]), s = e[2].replace(this.rules.other.tableAlignChars, "").split("|"), t = e[3]?.trim() ? e[3].replace(this.rules.other.tableRowBlankLine, "").split(`
`) : [], i = { type: "table", raw: e[0], header: [], align: [], rows: [] };
        if (r.length === s.length) {
            for (let l of s)
                this.rules.other.tableAlignRight.test(l) ? i.align.push("right") : this.rules.other.tableAlignCenter.test(l) ? i.align.push("center") : this.rules.other.tableAlignLeft.test(l) ? i.align.push("left") : i.align.push(null);
            for (let l = 0; l < r.length; l++)
                i.header.push({ text: r[l], tokens: this.lexer.inline(r[l]), header: !0, align: i.align[l] });
            for (let l of t)
                i.rows.push(ie(l, i.header.length).map((o, a) => ({ text: o, tokens: this.lexer.inline(o), header: !1, align: i.align[a] })));
            return i;
        }
    }
    lheading(n) { let e = this.rules.block.lheading.exec(n); if (e) {
        let r = e[1].trim();
        return { type: "heading", raw: e[0], depth: e[2].charAt(0) === "=" ? 1 : 2, text: r, tokens: this.lexer.inline(r) };
    } }
    paragraph(n) {
        let e = this.rules.block.paragraph.exec(n);
        if (e) {
            let r = e[1].charAt(e[1].length - 1) === `
` ? e[1].slice(0, -1) : e[1];
            return { type: "paragraph", raw: e[0], text: r, tokens: this.lexer.inline(r) };
        }
    }
    text(n) { let e = this.rules.block.text.exec(n); if (e)
        return { type: "text", raw: e[0], text: e[0], tokens: this.lexer.inline(e[0]) }; }
    escape(n) { let e = this.rules.inline.escape.exec(n); if (e)
        return { type: "escape", raw: e[0], text: e[1] }; }
    tag(n) { let e = this.rules.inline.tag.exec(n); if (e)
        return !this.lexer.state.inLink && this.rules.other.startATag.test(e[0]) ? this.lexer.state.inLink = !0 : this.lexer.state.inLink && this.rules.other.endATag.test(e[0]) && (this.lexer.state.inLink = !1), !this.lexer.state.inRawBlock && this.rules.other.startPreScriptTag.test(e[0]) ? this.lexer.state.inRawBlock = !0 : this.lexer.state.inRawBlock && this.rules.other.endPreScriptTag.test(e[0]) && (this.lexer.state.inRawBlock = !1), { type: "html", raw: e[0], inLink: this.lexer.state.inLink, inRawBlock: this.lexer.state.inRawBlock, block: !1, text: e[0] }; }
    link(n) { let e = this.rules.inline.link.exec(n); if (e) {
        let r = e[2].trim();
        if (!this.options.pedantic && this.rules.other.startAngleBracket.test(r)) {
            if (!this.rules.other.endAngleBracket.test(r))
                return;
            let i = I(r.slice(0, -1), "\\");
            if ((r.length - i.length) % 2 === 0)
                return;
        }
        else {
            let i = nt(e[2], "()");
            if (i === -2)
                return;
            if (i > -1) {
                let l = (e[0].indexOf("!") === 0 ? 5 : 4) + e[1].length + i;
                e[2] = e[2].substring(0, i), e[0] = e[0].substring(0, l).trim(), e[3] = "";
            }
        }
        let s = e[2], t = "";
        if (this.options.pedantic) {
            let i = this.rules.other.pedanticHrefTitle.exec(s);
            i && (s = i[1], t = i[3]);
        }
        else
            t = e[3] ? e[3].slice(1, -1) : "";
        return s = s.trim(), this.rules.other.startAngleBracket.test(s) && (this.options.pedantic && !this.rules.other.endAngleBracket.test(r) ? s = s.slice(1) : s = s.slice(1, -1)), ae(e, { href: s && s.replace(this.rules.inline.anyPunctuation, "$1"), title: t && t.replace(this.rules.inline.anyPunctuation, "$1") }, e[0], this.lexer, this.rules);
    } }
    reflink(n, e) { let r; if ((r = this.rules.inline.reflink.exec(n)) || (r = this.rules.inline.nolink.exec(n))) {
        let s = (r[2] || r[1]).replace(this.rules.other.multipleSpaceGlobal, " "), t = e[s.toLowerCase()];
        if (!t) {
            let i = r[0].charAt(0);
            return { type: "text", raw: i, text: i };
        }
        return ae(r, t, r[0], this.lexer, this.rules);
    } }
    emStrong(n, e, r = "") { let s = this.rules.inline.emStrongLDelim.exec(n); if (!(!s || !s[1] && !s[2] && !s[3] && !s[4] || s[4] && r.match(this.rules.other.unicodeAlphaNumeric)) && (!(s[1] || s[3]) || !r || this.rules.inline.punctuation.exec(r))) {
        let t = [...s[0]].length - 1, i, l, o = t, a = 0, h = s[0][0] === "*" ? this.rules.inline.emStrongRDelimAst : this.rules.inline.emStrongRDelimUnd;
        for (h.lastIndex = 0, e = e.slice(-1 * n.length + t); (s = h.exec(e)) !== null;) {
            if (i = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !i)
                continue;
            if (l = [...i].length, s[3] || s[4]) {
                o += l;
                continue;
            }
            else if ((s[5] || s[6]) && t % 3 && !((t + l) % 3)) {
                a += l;
                continue;
            }
            if (o -= l, o > 0)
                continue;
            l = Math.min(l, l + o + a);
            let c = [...s[0]][0].length, g = n.slice(0, t + s.index + c + l);
            if (Math.min(t, l) % 2) {
                let f = g.slice(1, -1);
                return { type: "em", raw: g, text: f, tokens: this.lexer.inlineTokens(f) };
            }
            let u = g.slice(2, -2);
            return { type: "strong", raw: g, text: u, tokens: this.lexer.inlineTokens(u) };
        }
    } }
    codespan(n) { let e = this.rules.inline.code.exec(n); if (e) {
        let r = e[2].replace(this.rules.other.newLineCharGlobal, " "), s = this.rules.other.nonSpaceChar.test(r), t = this.rules.other.startingSpaceChar.test(r) && this.rules.other.endingSpaceChar.test(r);
        return s && t && (r = r.substring(1, r.length - 1)), { type: "codespan", raw: e[0], text: r };
    } }
    br(n) { let e = this.rules.inline.br.exec(n); if (e)
        return { type: "br", raw: e[0] }; }
    del(n, e, r = "") { let s = this.rules.inline.delLDelim.exec(n); if (s && (!s[1] || !r || this.rules.inline.punctuation.exec(r))) {
        let t = [...s[0]].length - 1, i, l, o = t, a = this.rules.inline.delRDelim;
        for (a.lastIndex = 0, e = e.slice(-1 * n.length + t); (s = a.exec(e)) !== null;) {
            if (i = s[1] || s[2] || s[3] || s[4] || s[5] || s[6], !i || (l = [...i].length, l !== t))
                continue;
            if (s[3] || s[4]) {
                o += l;
                continue;
            }
            if (o -= l, o > 0)
                continue;
            l = Math.min(l, l + o);
            let h = [...s[0]][0].length, c = n.slice(0, t + s.index + h + l), g = c.slice(t, -t);
            return { type: "del", raw: c, text: g, tokens: this.lexer.inlineTokens(g) };
        }
    } }
    autolink(n) { let e = this.rules.inline.autolink.exec(n); if (e) {
        let r, s;
        return e[2] === "@" ? (r = e[1], s = "mailto:" + r) : (r = e[1], s = r), { type: "link", raw: e[0], text: r, href: s, tokens: [{ type: "text", raw: r, text: r }] };
    } }
    url(n) { let e; if (e = this.rules.inline.url.exec(n)) {
        let r, s;
        if (e[2] === "@")
            r = e[0], s = "mailto:" + r;
        else {
            let t;
            do
                t = e[0], e[0] = this.rules.inline._backpedal.exec(e[0])?.[0] ?? "";
            while (t !== e[0]);
            r = e[0], e[1] === "www." ? s = "http://" + e[0] : s = e[0];
        }
        return { type: "link", raw: e[0], text: r, href: s, tokens: [{ type: "text", raw: r, text: r }] };
    } }
    inlineText(n) { let e = this.rules.inline.text.exec(n); if (e) {
        let r = this.lexer.state.inRawBlock;
        return { type: "text", raw: e[0], text: e[0], escaped: r };
    } }
}, w = class O {
    tokens;
    options;
    state;
    inlineQueue;
    tokenizer;
    constructor(e) { this.tokens = [], this.tokens.links = Object.create(null), this.options = e || T, this.options.tokenizer = this.options.tokenizer || new E, this.tokenizer = this.options.tokenizer, this.tokenizer.options = this.options, this.tokenizer.lexer = this, this.inlineQueue = [], this.state = { inLink: !1, inRawBlock: !1, top: !0 }; let r = { other: x, block: q.normal, inline: _.normal }; this.options.pedantic ? (r.block = q.pedantic, r.inline = _.pedantic) : this.options.gfm && (r.block = q.gfm, this.options.breaks ? r.inline = _.breaks : r.inline = _.gfm), this.tokenizer.rules = r; }
    static get rules() { return { block: q, inline: _ }; }
    static lex(e, r) { return new O(r).lex(e); }
    static lexInline(e, r) { return new O(r).inlineTokens(e); }
    lex(e) {
        e = e.replace(x.carriageReturn, `
`), this.blockTokens(e, this.tokens);
        for (let r = 0; r < this.inlineQueue.length; r++) {
            let s = this.inlineQueue[r];
            this.inlineTokens(s.src, s.tokens);
        }
        return this.inlineQueue = [], this.tokens;
    }
    blockTokens(e, r = [], s = !1) {
        for (this.tokenizer.lexer = this, this.options.pedantic && (e = e.replace(x.tabCharGlobal, "    ").replace(x.spaceLine, "")); e;) {
            let t;
            if (this.options.extensions?.block?.some(l => (t = l.call({ lexer: this }, e, r)) ? (e = e.substring(t.raw.length), r.push(t), !0) : !1))
                continue;
            if (t = this.tokenizer.space(e)) {
                e = e.substring(t.raw.length);
                let l = r.at(-1);
                t.raw.length === 1 && l !== void 0 ? l.raw += `
` : r.push(t);
                continue;
            }
            if (t = this.tokenizer.code(e)) {
                e = e.substring(t.raw.length);
                let l = r.at(-1);
                l?.type === "paragraph" || l?.type === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + t.raw, l.text += `
` + t.text, this.inlineQueue.at(-1).src = l.text) : r.push(t);
                continue;
            }
            if (t = this.tokenizer.fences(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.heading(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.hr(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.blockquote(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.list(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.html(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.def(e)) {
                e = e.substring(t.raw.length);
                let l = r.at(-1);
                l?.type === "paragraph" || l?.type === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + t.raw, l.text += `
` + t.raw, this.inlineQueue.at(-1).src = l.text) : this.tokens.links[t.tag] || (this.tokens.links[t.tag] = { href: t.href, title: t.title }, r.push(t));
                continue;
            }
            if (t = this.tokenizer.table(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            if (t = this.tokenizer.lheading(e)) {
                e = e.substring(t.raw.length), r.push(t);
                continue;
            }
            let i = e;
            if (this.options.extensions?.startBlock) {
                let l = 1 / 0, o = e.slice(1), a;
                this.options.extensions.startBlock.forEach(h => { a = h.call({ lexer: this }, o), typeof a == "number" && a >= 0 && (l = Math.min(l, a)); }), l < 1 / 0 && l >= 0 && (i = e.substring(0, l + 1));
            }
            if (this.state.top && (t = this.tokenizer.paragraph(i))) {
                let l = r.at(-1);
                s && l?.type === "paragraph" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + t.raw, l.text += `
` + t.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : r.push(t), s = i.length !== e.length, e = e.substring(t.raw.length);
                continue;
            }
            if (t = this.tokenizer.text(e)) {
                e = e.substring(t.raw.length);
                let l = r.at(-1);
                l?.type === "text" ? (l.raw += (l.raw.endsWith(`
`) ? "" : `
`) + t.raw, l.text += `
` + t.text, this.inlineQueue.pop(), this.inlineQueue.at(-1).src = l.text) : r.push(t);
                continue;
            }
            if (e) {
                let l = "Infinite loop on byte: " + e.charCodeAt(0);
                if (this.options.silent) {
                    console.error(l);
                    break;
                }
                else
                    throw new Error(l);
            }
        }
        return this.state.top = !0, r;
    }
    inline(e, r = []) { return this.inlineQueue.push({ src: e, tokens: r }), r; }
    inlineTokens(e, r = []) { this.tokenizer.lexer = this; let s = e, t = null; if (this.tokens.links) {
        let a = Object.keys(this.tokens.links);
        if (a.length > 0)
            for (; (t = this.tokenizer.rules.inline.reflinkSearch.exec(s)) !== null;)
                a.includes(t[0].slice(t[0].lastIndexOf("[") + 1, -1)) && (s = s.slice(0, t.index) + "[" + "a".repeat(t[0].length - 2) + "]" + s.slice(this.tokenizer.rules.inline.reflinkSearch.lastIndex));
    } for (; (t = this.tokenizer.rules.inline.anyPunctuation.exec(s)) !== null;)
        s = s.slice(0, t.index) + "++" + s.slice(this.tokenizer.rules.inline.anyPunctuation.lastIndex); let i; for (; (t = this.tokenizer.rules.inline.blockSkip.exec(s)) !== null;)
        i = t[2] ? t[2].length : 0, s = s.slice(0, t.index + i) + "[" + "a".repeat(t[0].length - i - 2) + "]" + s.slice(this.tokenizer.rules.inline.blockSkip.lastIndex); s = this.options.hooks?.emStrongMask?.call({ lexer: this }, s) ?? s; let l = !1, o = ""; for (; e;) {
        l || (o = ""), l = !1;
        let a;
        if (this.options.extensions?.inline?.some(c => (a = c.call({ lexer: this }, e, r)) ? (e = e.substring(a.raw.length), r.push(a), !0) : !1))
            continue;
        if (a = this.tokenizer.escape(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.tag(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.link(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.reflink(e, this.tokens.links)) {
            e = e.substring(a.raw.length);
            let c = r.at(-1);
            a.type === "text" && c?.type === "text" ? (c.raw += a.raw, c.text += a.text) : r.push(a);
            continue;
        }
        if (a = this.tokenizer.emStrong(e, s, o)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.codespan(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.br(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.del(e, s, o)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (a = this.tokenizer.autolink(e)) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        if (!this.state.inLink && (a = this.tokenizer.url(e))) {
            e = e.substring(a.raw.length), r.push(a);
            continue;
        }
        let h = e;
        if (this.options.extensions?.startInline) {
            let c = 1 / 0, g = e.slice(1), u;
            this.options.extensions.startInline.forEach(f => { u = f.call({ lexer: this }, g), typeof u == "number" && u >= 0 && (c = Math.min(c, u)); }), c < 1 / 0 && c >= 0 && (h = e.substring(0, c + 1));
        }
        if (a = this.tokenizer.inlineText(h)) {
            e = e.substring(a.raw.length), a.raw.slice(-1) !== "_" && (o = a.raw.slice(-1)), l = !0;
            let c = r.at(-1);
            c?.type === "text" ? (c.raw += a.raw, c.text += a.text) : r.push(a);
            continue;
        }
        if (e) {
            let c = "Infinite loop on byte: " + e.charCodeAt(0);
            if (this.options.silent) {
                console.error(c);
                break;
            }
            else
                throw new Error(c);
        }
    } return r; }
}, Z = class {
    options;
    parser;
    constructor(n) { this.options = n || T; }
    space(n) { return ""; }
    code({ text: n, lang: e, escaped: r }) {
        let s = (e || "").match(x.notSpaceStart)?.[0], t = n.replace(x.endingNewline, "") + `
`;
        return s ? '<pre><code class="language-' + y(s) + '">' + (r ? t : y(t, !0)) + `</code></pre>
` : "<pre><code>" + (r ? t : y(t, !0)) + `</code></pre>
`;
    }
    blockquote({ tokens: n }) {
        return `<blockquote>
${this.parser.parse(n)}</blockquote>
`;
    }
    html({ text: n }) { return n; }
    def(n) { return ""; }
    heading({ tokens: n, depth: e }) {
        return `<h${e}>${this.parser.parseInline(n)}</h${e}>
`;
    }
    hr(n) {
        return `<hr>
`;
    }
    list(n) {
        let e = n.ordered, r = n.start, s = "";
        for (let l = 0; l < n.items.length; l++) {
            let o = n.items[l];
            s += this.listitem(o);
        }
        let t = e ? "ol" : "ul", i = e && r !== 1 ? ' start="' + r + '"' : "";
        return "<" + t + i + `>
` + s + "</" + t + `>
`;
    }
    listitem(n) {
        return `<li>${this.parser.parse(n.tokens)}</li>
`;
    }
    checkbox({ checked: n }) { return "<input " + (n ? 'checked="" ' : "") + 'disabled="" type="checkbox"> '; }
    paragraph({ tokens: n }) {
        return `<p>${this.parser.parseInline(n)}</p>
`;
    }
    table(n) {
        let e = "", r = "";
        for (let t = 0; t < n.header.length; t++)
            r += this.tablecell(n.header[t]);
        e += this.tablerow({ text: r });
        let s = "";
        for (let t = 0; t < n.rows.length; t++) {
            let i = n.rows[t];
            r = "";
            for (let l = 0; l < i.length; l++)
                r += this.tablecell(i[l]);
            s += this.tablerow({ text: r });
        }
        return s && (s = `<tbody>${s}</tbody>`), `<table>
<thead>
` + e + `</thead>
` + s + `</table>
`;
    }
    tablerow({ text: n }) {
        return `<tr>
${n}</tr>
`;
    }
    tablecell(n) {
        let e = this.parser.parseInline(n.tokens), r = n.header ? "th" : "td";
        return (n.align ? `<${r} align="${n.align}">` : `<${r}>`) + e + `</${r}>
`;
    }
    strong({ tokens: n }) { return `<strong>${this.parser.parseInline(n)}</strong>`; }
    em({ tokens: n }) { return `<em>${this.parser.parseInline(n)}</em>`; }
    codespan({ text: n }) { return `<code>${y(n, !0)}</code>`; }
    br(n) { return "<br>"; }
    del({ tokens: n }) { return `<del>${this.parser.parseInline(n)}</del>`; }
    link({ href: n, title: e, tokens: r }) { let s = this.parser.parseInline(r), t = le(n); if (t === null)
        return s; n = t; let i = '<a href="' + n + '"'; return e && (i += ' title="' + y(e) + '"'), i += ">" + s + "</a>", i; }
    image({ href: n, title: e, text: r, tokens: s }) { s && (r = this.parser.parseInline(s, this.parser.textRenderer)); let t = le(n); if (t === null)
        return y(r); n = t; let i = `<img src="${n}" alt="${y(r)}"`; return e && (i += ` title="${y(e)}"`), i += ">", i; }
    text(n) { return "tokens" in n && n.tokens ? this.parser.parseInline(n.tokens) : "escaped" in n && n.escaped ? n.text : y(n.text); }
}, V = class {
    strong({ text: n }) { return n; }
    em({ text: n }) { return n; }
    codespan({ text: n }) { return n; }
    del({ text: n }) { return n; }
    html({ text: n }) { return n; }
    text({ text: n }) { return n; }
    link({ text: n }) { return "" + n; }
    image({ text: n }) { return "" + n; }
    br() { return ""; }
    checkbox({ raw: n }) { return n; }
}, m = class j {
    options;
    renderer;
    textRenderer;
    constructor(e) { this.options = e || T, this.options.renderer = this.options.renderer || new Z, this.renderer = this.options.renderer, this.renderer.options = this.options, this.renderer.parser = this, this.textRenderer = new V; }
    static parse(e, r) { return new j(r).parse(e); }
    static parseInline(e, r) { return new j(r).parseInline(e); }
    parse(e) { this.renderer.parser = this; let r = ""; for (let s = 0; s < e.length; s++) {
        let t = e[s];
        if (this.options.extensions?.renderers?.[t.type]) {
            let l = t, o = this.options.extensions.renderers[l.type].call({ parser: this }, l);
            if (o !== !1 || !["space", "hr", "heading", "code", "table", "blockquote", "list", "html", "def", "paragraph", "text"].includes(l.type)) {
                r += o || "";
                continue;
            }
        }
        let i = t;
        switch (i.type) {
            case "space": {
                r += this.renderer.space(i);
                break;
            }
            case "hr": {
                r += this.renderer.hr(i);
                break;
            }
            case "heading": {
                r += this.renderer.heading(i);
                break;
            }
            case "code": {
                r += this.renderer.code(i);
                break;
            }
            case "table": {
                r += this.renderer.table(i);
                break;
            }
            case "blockquote": {
                r += this.renderer.blockquote(i);
                break;
            }
            case "list": {
                r += this.renderer.list(i);
                break;
            }
            case "checkbox": {
                r += this.renderer.checkbox(i);
                break;
            }
            case "html": {
                r += this.renderer.html(i);
                break;
            }
            case "def": {
                r += this.renderer.def(i);
                break;
            }
            case "paragraph": {
                r += this.renderer.paragraph(i);
                break;
            }
            case "text": {
                r += this.renderer.text(i);
                break;
            }
            default: {
                let l = 'Token with "' + i.type + '" type was not found.';
                if (this.options.silent)
                    return console.error(l), "";
                throw new Error(l);
            }
        }
    } return r; }
    parseInline(e, r = this.renderer) { this.renderer.parser = this; let s = ""; for (let t = 0; t < e.length; t++) {
        let i = e[t];
        if (this.options.extensions?.renderers?.[i.type]) {
            let o = this.options.extensions.renderers[i.type].call({ parser: this }, i);
            if (o !== !1 || !["escape", "html", "link", "image", "strong", "em", "codespan", "br", "del", "text"].includes(i.type)) {
                s += o || "";
                continue;
            }
        }
        let l = i;
        switch (l.type) {
            case "escape": {
                s += r.text(l);
                break;
            }
            case "html": {
                s += r.html(l);
                break;
            }
            case "link": {
                s += r.link(l);
                break;
            }
            case "image": {
                s += r.image(l);
                break;
            }
            case "checkbox": {
                s += r.checkbox(l);
                break;
            }
            case "strong": {
                s += r.strong(l);
                break;
            }
            case "em": {
                s += r.em(l);
                break;
            }
            case "codespan": {
                s += r.codespan(l);
                break;
            }
            case "br": {
                s += r.br(l);
                break;
            }
            case "del": {
                s += r.del(l);
                break;
            }
            case "text": {
                s += r.text(l);
                break;
            }
            default: {
                let o = 'Token with "' + l.type + '" type was not found.';
                if (this.options.silent)
                    return console.error(o), "";
                throw new Error(o);
            }
        }
    } return s; }
}, L = class {
    options;
    block;
    constructor(n) { this.options = n || T; }
    static passThroughHooks = new Set(["preprocess", "postprocess", "processAllTokens", "emStrongMask"]);
    static passThroughHooksRespectAsync = new Set(["preprocess", "postprocess", "processAllTokens"]);
    preprocess(n) { return n; }
    postprocess(n) { return n; }
    processAllTokens(n) { return n; }
    emStrongMask(n) { return n; }
    provideLexer(n = this.block) { return n ? w.lex : w.lexInline; }
    provideParser(n = this.block) { return n ? m.parse : m.parseInline; }
}, it = class {
    defaults = N();
    options = this.setOptions;
    parse = this.parseMarkdown(!0);
    parseInline = this.parseMarkdown(!1);
    Parser = m;
    Renderer = Z;
    TextRenderer = V;
    Lexer = w;
    Tokenizer = E;
    Hooks = L;
    constructor(...n) { this.use(...n); }
    walkTokens(n, e) { let r = []; for (let s of n)
        switch (r = r.concat(e.call(this, s)), s.type) {
            case "table": {
                let t = s;
                for (let i of t.header)
                    r = r.concat(this.walkTokens(i.tokens, e));
                for (let i of t.rows)
                    for (let l of i)
                        r = r.concat(this.walkTokens(l.tokens, e));
                break;
            }
            case "list": {
                let t = s;
                r = r.concat(this.walkTokens(t.items, e));
                break;
            }
            default: {
                let t = s;
                this.defaults.extensions?.childTokens?.[t.type] ? this.defaults.extensions.childTokens[t.type].forEach(i => { let l = t[i].flat(1 / 0); r = r.concat(this.walkTokens(l, e)); }) : t.tokens && (r = r.concat(this.walkTokens(t.tokens, e)));
            }
        } return r; }
    use(...n) { let e = this.defaults.extensions || { renderers: {}, childTokens: {} }; return n.forEach(r => { let s = b({}, r); if (s.async = this.defaults.async || s.async || !1, r.extensions && (r.extensions.forEach(t => { if (!t.name)
        throw new Error("extension name required"); if ("renderer" in t) {
        let i = e.renderers[t.name];
        i ? e.renderers[t.name] = function (...l) { let o = t.renderer.apply(this, l); return o === !1 && (o = i.apply(this, l)), o; } : e.renderers[t.name] = t.renderer;
    } if ("tokenizer" in t) {
        if (!t.level || t.level !== "block" && t.level !== "inline")
            throw new Error("extension level must be 'block' or 'inline'");
        let i = e[t.level];
        i ? i.unshift(t.tokenizer) : e[t.level] = [t.tokenizer], t.start && (t.level === "block" ? e.startBlock ? e.startBlock.push(t.start) : e.startBlock = [t.start] : t.level === "inline" && (e.startInline ? e.startInline.push(t.start) : e.startInline = [t.start]));
    } "childTokens" in t && t.childTokens && (e.childTokens[t.name] = t.childTokens); }), s.extensions = e), r.renderer) {
        let t = this.defaults.renderer || new Z(this.defaults);
        for (let i in r.renderer) {
            if (!(i in t))
                throw new Error(`renderer '${i}' does not exist`);
            if (["options", "parser"].includes(i))
                continue;
            let l = i, o = r.renderer[l], a = t[l];
            t[l] = (...h) => { let c = o.apply(t, h); return c === !1 && (c = a.apply(t, h)), c || ""; };
        }
        s.renderer = t;
    } if (r.tokenizer) {
        let t = this.defaults.tokenizer || new E(this.defaults);
        for (let i in r.tokenizer) {
            if (!(i in t))
                throw new Error(`tokenizer '${i}' does not exist`);
            if (["options", "rules", "lexer"].includes(i))
                continue;
            let l = i, o = r.tokenizer[l], a = t[l];
            t[l] = (...h) => { let c = o.apply(t, h); return c === !1 && (c = a.apply(t, h)), c; };
        }
        s.tokenizer = t;
    } if (r.hooks) {
        let t = this.defaults.hooks || new L;
        for (let i in r.hooks) {
            if (!(i in t))
                throw new Error(`hook '${i}' does not exist`);
            if (["options", "block"].includes(i))
                continue;
            let l = i, o = r.hooks[l], a = t[l];
            L.passThroughHooks.has(i) ? t[l] = h => { if (this.defaults.async && L.passThroughHooksRespectAsync.has(i))
                return C(this, null, function* () { let g = yield o.call(t, h); return a.call(t, g); }); let c = o.call(t, h); return a.call(t, c); } : t[l] = (...h) => { if (this.defaults.async)
                return C(this, null, function* () { let g = yield o.apply(t, h); return g === !1 && (g = yield a.apply(t, h)), g; }); let c = o.apply(t, h); return c === !1 && (c = a.apply(t, h)), c; };
        }
        s.hooks = t;
    } if (r.walkTokens) {
        let t = this.defaults.walkTokens, i = r.walkTokens;
        s.walkTokens = function (l) { let o = []; return o.push(i.call(this, l)), t && (o = o.concat(t.call(this, l))), o; };
    } this.defaults = b(b({}, this.defaults), s); }), this; }
    setOptions(n) { return this.defaults = b(b({}, this.defaults), n), this; }
    lexer(n, e) { return w.lex(n, e ?? this.defaults); }
    parser(n, e) { return m.parse(n, e ?? this.defaults); }
    parseMarkdown(n) { return (e, r) => { let s = b({}, r), t = b(b({}, this.defaults), s), i = this.onError(!!t.silent, !!t.async); if (this.defaults.async === !0 && s.async === !1)
        return i(new Error("marked(): The async option was set to true by an extension. Remove async: false from the parse options object to return a Promise.")); if (typeof e > "u" || e === null)
        return i(new Error("marked(): input parameter is undefined or null")); if (typeof e != "string")
        return i(new Error("marked(): input parameter is of type " + Object.prototype.toString.call(e) + ", string expected")); if (t.hooks && (t.hooks.options = t, t.hooks.block = n), t.async)
        return C(this, null, function* () { let l = t.hooks ? yield t.hooks.preprocess(e) : e, o = yield (t.hooks ? yield t.hooks.provideLexer(n) : n ? w.lex : w.lexInline)(l, t), a = t.hooks ? yield t.hooks.processAllTokens(o) : o; t.walkTokens && (yield Promise.all(this.walkTokens(a, t.walkTokens))); let h = yield (t.hooks ? yield t.hooks.provideParser(n) : n ? m.parse : m.parseInline)(a, t); return t.hooks ? yield t.hooks.postprocess(h) : h; }).catch(i); try {
        t.hooks && (e = t.hooks.preprocess(e));
        let l = (t.hooks ? t.hooks.provideLexer(n) : n ? w.lex : w.lexInline)(e, t);
        t.hooks && (l = t.hooks.processAllTokens(l)), t.walkTokens && this.walkTokens(l, t.walkTokens);
        let o = (t.hooks ? t.hooks.provideParser(n) : n ? m.parse : m.parseInline)(l, t);
        return t.hooks && (o = t.hooks.postprocess(o)), o;
    }
    catch (l) {
        return i(l);
    } }; }
    onError(n, e) {
        return r => {
            if (r.message += `
Please report this to https://github.com/markedjs/marked.`, n) {
                let s = "<p>An error occurred:</p><pre>" + y(r.message + "", !0) + "</pre>";
                return e ? Promise.resolve(s) : s;
            }
            if (e)
                return Promise.reject(r);
            throw r;
        };
    }
}, S = new it;
function k(n, e) { return S.parse(n, e); }
k.options = k.setOptions = function (n) { return S.setOptions(n), k.defaults = S.defaults, oe(k.defaults), k; };
k.getDefaults = N;
k.defaults = T;
k.use = function (...n) { return S.use(...n), k.defaults = S.defaults, oe(k.defaults), k; };
k.walkTokens = function (n, e) { return S.walkTokens(n, e); };
k.parseInline = S.parseInline;
k.Parser = m;
k.parser = m.parse;
k.Renderer = Z;
k.TextRenderer = V;
k.Lexer = w;
k.lexer = w.lex;
k.Tokenizer = E;
k.Hooks = L;
k.parse = k;
var at = k.options, ot = k.setOptions, ct = k.use, ht = k.walkTokens, pt = k.parseInline, ut = k, gt = m.parse, kt = w.lex;
export { N as a, T as b, E as c, w as d, Z as e, V as f, m as g, L as h, it as i, k as j, at as k, ot as l, ct as m, ht as n, pt as o, ut as p, gt as q, kt as r };
