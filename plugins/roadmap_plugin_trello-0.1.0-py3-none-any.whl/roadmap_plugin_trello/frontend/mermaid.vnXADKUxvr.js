import { a as jr } from "@nf-internal/chunk-YQ6X4GJP";
import { a as Jr, b as re } from "@nf-internal/chunk-GDGZBOQC";
import { a as ee } from "@nf-internal/chunk-4PKWXC3U";
import { g as Rt, h as Lt, i as Mt, j as Ct } from "@nf-internal/chunk-BA5WCRNE";
import "@nf-internal/chunk-LUZVEH3G";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import { a as Zr } from "@nf-internal/chunk-3SXY7Q5B";
import { b as qr } from "@nf-internal/chunk-ZBOYDPPL";
import { b as Er, d as Wr, m as Dr, o as Xr, p as U, q as Kr, r as Qr } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { B as Gr, C as rr, D as xr, E as er, F as Hr, O as Br, Q as Sr, R as Yr, da as X, ea as tr, g as Cr, h as kr, j as J, m as Ir, n as wr, o as Fr, p as Or, q as $r, r as zr, s as br, t as Pr, u as V, v as Nr, w as W, y as Vr, z as Ur } from "@nf-internal/chunk-LEJRRF65";
import { b as g, c as yr, h as k } from "@nf-internal/chunk-RZWXGGKD";
import { a as t } from "@nf-internal/chunk-YUSHYV7C";
import { a as vr, b as hr, f as n } from "@nf-internal/chunk-OSQMNGTH";
var G = "comm", ar = "rule", ir = "decl";
var te = "@media", ae = "@import";
var ie = "@supports";
var oe = "@namespace", K = "@keyframes";
var or = "@layer", ne = "@scope";
var se = Math.abs, z = String.fromCharCode;
function nr(r) { return r.trim(); }
function Q(r, e, a) { return r.replace(e, a); }
function I(r, e) { return r.charCodeAt(e) | 0; }
function F(r, e, a) { return r.slice(e, a); }
function S(r) { return r.length; }
function sr(r) { return r.length; }
function H(r, e) { return e.push(r), r; }
var dr = 1, B = 1, de = 0, D = 0, y = 0, j = "";
function cr(r, e, a, i, o, d, c, s) { return { value: r, root: e, parent: a, type: i, props: o, children: d, line: dr, column: B, length: c, return: "", siblings: s }; }
function ce() { return y; }
function le() { return y = D > 0 ? I(j, --D) : 0, B--, y === 10 && (B = 1, dr--), y; }
function T() { return y = D < de ? I(j, D++) : 0, B++, y === 10 && (B = 1, dr++), y; }
function O() { return I(j, D); }
function Z() { return D; }
function lr(r, e) { return F(j, r, e); }
function Y(r) { switch (r) {
    case 0:
    case 9:
    case 10:
    case 13:
    case 32: return 5;
    case 33:
    case 43:
    case 44:
    case 47:
    case 62:
    case 64:
    case 126:
    case 59:
    case 123:
    case 125: return 4;
    case 58: return 3;
    case 34:
    case 39:
    case 40:
    case 91: return 2;
    case 41:
    case 93: return 1;
} return 0; }
function ue(r) { return dr = B = 1, de = S(j = r), D = 0, []; }
function me(r) { return j = "", r; }
function ur(r) { return nr(lr(D - 1, Tr(r === 91 ? r + 2 : r === 40 ? r + 1 : r))); }
function pe(r) { for (; (y = O()) && y < 33;)
    T(); return Y(r) > 2 || Y(y) > 3 ? "" : " "; }
function fe(r, e) { for (; --e && T() && !(y < 48 || y > 102 || y > 57 && y < 65 || y > 70 && y < 97);)
    ; return lr(r, Z() + (e < 6 && O() == 32 && T() == 32)); }
function Tr(r) { for (; T();)
    switch (y) {
        case r: return D;
        case 34:
        case 39:
            r !== 34 && r !== 39 && Tr(y);
            break;
        case 40:
            r === 41 && Tr(r);
            break;
        case 92:
            T();
            break;
    } return D; }
function ge(r, e) { for (; T() && r + y !== 57;)
    if (r + y === 84 && O() === 47)
        break; return "/*" + lr(e, D - 1) + "*" + z(r === 47 ? r : T()); }
function ve(r) { for (; !Y(O());)
    T(); return lr(r, D); }
function we(r) { return me(mr("", null, null, null, [""], r = ue(r), 0, [0], r)); }
function mr(r, e, a, i, o, d, c, s, l) { for (var p = 0, v = 0, m = c, b = 0, A = 0, _ = 0, f = 1, C = 1, R = 1, x = 0, h = 0, L = "", N = o, M = d, E = i, u = L; C;)
    switch (_ = h, h = T()) {
        case 40:
            _ != 108 && I(u, m - 1) == 58 ? (x++, u += "(") : u += ur(h);
            break;
        case 41:
            x--, u += ")";
            break;
        case 34:
        case 39:
        case 91:
            u += ur(h);
            break;
        case 9:
        case 10:
        case 13:
        case 32:
            if (x > 0) {
                u += z(h);
                break;
            }
            u += pe(_);
            break;
        case 92:
            u += fe(Z() - 1, 7);
            continue;
        case 47:
            switch (O()) {
                case 42:
                case 47:
                    H(It(ge(T(), Z()), e, a, l), l), (Y(_ || 1) == 5 || Y(O() || 1) == 5) && S(u) && F(u, -1, void 0) !== " " && (u += " ");
                    break;
                default: u += "/";
            }
            break;
        case 123 * f: s[p++] = S(u) * R;
        case 125 * f:
        case 59:
        case 0:
            if (x > 0 && h) {
                u += z(h);
                break;
            }
            switch (h) {
                case 0:
                case 125: C = 0;
                case 59 + v:
                    R == -1 && (u = Q(u, /\f/g, "")), A > 0 && (S(u) - m || f === 0) && H(A > 32 ? ye(u + ";", i, a, m - 1, l) : ye(Q(u, " ", "") + ";", i, a, m - 2, l), l);
                    break;
                case 59: u += ";";
                default: if (H(E = he(u, e, a, p, v, o, s, L, N = [], M = [], m, d), d), h === 123)
                    if (v === 0)
                        mr(u, e, E, E, N, d, m, s, M);
                    else {
                        switch (b) {
                            case 99: if (I(u, 3) === 110)
                                break;
                            case 108: if (I(u, 2) === 97)
                                break;
                            default: v = 0;
                            case 100:
                            case 109:
                            case 115:
                        }
                        v ? mr(r, E, E, i && H(he(r, E, E, 0, 0, o, s, L, o, N = [], m, M), M), o, M, m, s, i ? N : M) : mr(u, E, E, E, [""], M, 0, s, M);
                    }
            }
            p = v = A = 0, f = R = 1, L = u = "", m = c;
            break;
        case 58: m = 1 + S(u), A = _;
        default:
            if (f < 1) {
                if (h == 123)
                    --f;
                else if (h == 125 && f++ == 0 && le() == 125)
                    continue;
            }
            switch (u += z(h), h * f) {
                case 38:
                    R = v > 0 ? 1 : (u += "\f", -1);
                    break;
                case 44:
                    if (x > 0)
                        break;
                    s[p++] = (S(u) - 1) * R, R = 1;
                    break;
                case 64:
                    O() === 45 && (u += ur(T())), b = O(), v = m = S(L = u += ve(Z())), h++;
                    break;
                case 45: _ === 45 && S(u) == 2 && (f = 0);
            }
    } return d; }
function he(r, e, a, i, o, d, c, s, l, p, v, m) { for (var b = o - 1, A = o === 0 ? d : [""], _ = sr(A), f = 0, C = 0, R = 0; f < i; ++f)
    for (var x = 0, h = F(r, b + 1, b = se(C = c[f])), L = r; x < _; ++x)
        (L = nr(C > 0 ? A[x] + " " + h : Q(h, /&\f/g, A[x]))) && (l[R++] = L); return cr(r, e, a, o === 0 ? ar : s, l, p, v, m); }
function It(r, e, a, i) { return cr(r, e, a, G, z(ce()), F(r, 2, -2), 0, i); }
function ye(r, e, a, i, o) { return cr(r, e, a, ir, F(r, 0, i), F(r, i + 1, -1), i, o); }
function pr(r, e) { for (var a = "", i = 0; i < r.length; i++)
    a += e(r[i], i, r, e) || ""; return a; }
function be(r, e, a, i) { switch (r.type) {
    case or: if (r.children.length)
        break;
    case ae:
    case oe:
    case ir: return r.return = r.return || r.value;
    case G: return "";
    case K: return r.return = r.value + "{" + pr(r.children, i) + "}";
    case ar: if (!S(r.value = r.props.join(",")))
        return "";
} return S(a = pr(r.children, i)) ? r.return = r.value + "{" + a + "}" : ""; }
function xe(r) { var e = sr(r); return function (a, i, o, d) { for (var c = "", s = 0; s < e; s++)
    c += r[s](a, i, o, d) || ""; return c; }; }
var Ae = "c4", Ft = t(r => /^\s*C4Context|C4Container|C4Component|C4Dynamic|C4Deployment/.test(r), "detector"), Ot = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/c4Diagram-7LVT6UL2-TB2OJ4LV"); return { id: Ae, diagram: r }; }), "loader"), $t = { id: Ae, detector: Ft, loader: Ot }, zt = $t, _e = "flowchart", Pt = t((r, e) => e?.flowchart?.defaultRenderer === "dagre-wrapper" || e?.flowchart?.defaultRenderer === "elk" ? !1 : /^\s*graph/.test(r), "detector"), Nt = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/flowDiagram-HODETNUW-RPU3TW4L"); return { id: _e, diagram: r }; }), "loader"), Vt = { id: _e, detector: Pt, loader: Nt }, Ut = Vt, Re = "flowchart-v2", Gt = t((r, e) => e?.flowchart?.defaultRenderer === "dagre-d3" ? !1 : (e?.flowchart?.defaultRenderer === "elk" && (e.layout = "elk"), /^\s*graph/.test(r) && e?.flowchart?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*flowchart/.test(r)), "detector"), Ht = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/flowDiagram-HODETNUW-RPU3TW4L"); return { id: Re, diagram: r }; }), "loader"), Bt = { id: Re, detector: Gt, loader: Ht }, Yt = Bt, Le = "swimlane", jt = t(r => /^\s*swimlane-beta\b/.test(r), "detector"), qt = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/swimlanesDiagram-VR7AAH4N-EJMUWYNW"); return { id: Le, diagram: r }; }), "loader"), Wt = { id: Le, detector: jt, loader: qt }, Xt = Wt, Me = "er", Kt = t(r => /^\s*erDiagram/.test(r), "detector"), Qt = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/erDiagram-RLTQ6QDP-JVEZTSGG"); return { id: Me, diagram: r }; }), "loader"), Zt = { id: Me, detector: Kt, loader: Qt }, Jt = Zt, Ce = "gitGraph", ra = t(r => /^\s*gitGraph/.test(r), "detector"), ea = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/gitGraphDiagram-WWUBYQGX-3UKEET4Z"); return { id: Ce, diagram: r }; }), "loader"), ta = { id: Ce, detector: ra, loader: ea }, aa = ta, ke = "gantt", ia = t(r => /^\s*gantt/.test(r), "detector"), oa = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/ganttDiagram-EL5Y4UJY-523RJA7R"); return { id: ke, diagram: r }; }), "loader"), na = { id: ke, detector: ia, loader: oa }, sa = na, Ie = "info", da = t(r => /^\s*info/.test(r), "detector"), ca = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/infoDiagram-27XIBGKW-RDZNZDW3"); return { id: Ie, diagram: r }; }), "loader"), la = { id: Ie, detector: da, loader: ca }, Fe = "pie", ua = t(r => /^\s*pie/.test(r), "detector"), ma = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/pieDiagram-E7YTZNPT-ETXZPAIY"); return { id: Fe, diagram: r }; }), "loader"), pa = { id: Fe, detector: ua, loader: ma }, Oe = "quadrantChart", fa = t(r => /^\s*quadrantChart/.test(r), "detector"), ga = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/quadrantDiagram-AXDQQJYC-PMCHYQE7"); return { id: Oe, diagram: r }; }), "loader"), va = { id: Oe, detector: fa, loader: ga }, ha = va, $e = "xychart", ya = t(r => /^\s*xychart(-beta)?/.test(r), "detector"), wa = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/xychartDiagram-S5SC5T6Z-RIVW6F2B"); return { id: $e, diagram: r }; }), "loader"), ba = { id: $e, detector: ya, loader: wa }, xa = ba, ze = "requirement", Sa = t(r => /^\s*requirement(Diagram)?/.test(r), "detector"), Ea = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/requirementDiagram-BXWQKSXE-EWZOQSLZ"); return { id: ze, diagram: r }; }), "loader"), Da = { id: ze, detector: Sa, loader: Ea }, Ta = Da, Pe = "sequence", Aa = t(r => /^\s*sequenceDiagram/.test(r), "detector"), _a = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/sequenceDiagram-WJ2MYXX4-MOEUTNVO"); return { id: Pe, diagram: r }; }), "loader"), Ra = { id: Pe, detector: Aa, loader: _a }, La = Ra, Ne = "class", Ma = t((r, e) => e?.class?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*classDiagram/.test(r), "detector"), Ca = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/classDiagram-ZZMXUADV-3E4B64PW"); return { id: Ne, diagram: r }; }), "loader"), ka = { id: Ne, detector: Ma, loader: Ca }, Ia = ka, Ve = "classDiagram", Fa = t((r, e) => /^\s*classDiagram/.test(r) && e?.class?.defaultRenderer === "dagre-wrapper" ? !0 : /^\s*classDiagram-v2/.test(r), "detector"), Oa = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/classDiagram-v2-VYDZK3BY-H634XEF7"); return { id: Ve, diagram: r }; }), "loader"), $a = { id: Ve, detector: Fa, loader: Oa }, za = $a, Ue = "state", Pa = t((r, e) => e?.state?.defaultRenderer === "dagre-wrapper" ? !1 : /^\s*stateDiagram/.test(r), "detector"), Na = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/stateDiagram-D77RDMKH-VNQJHUC4"); return { id: Ue, diagram: r }; }), "loader"), Va = { id: Ue, detector: Pa, loader: Na }, Ua = Va, Ge = "stateDiagram", Ga = t((r, e) => !!(/^\s*stateDiagram-v2/.test(r) || /^\s*stateDiagram/.test(r) && e?.state?.defaultRenderer === "dagre-wrapper"), "detector"), Ha = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/stateDiagram-v2-MP3YSRHH-Q2WKOH2P"); return { id: Ge, diagram: r }; }), "loader"), Ba = { id: Ge, detector: Ga, loader: Ha }, Ya = Ba, He = "journey", ja = t(r => /^\s*journey/.test(r), "detector"), qa = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/journeyDiagram-3NMN7TZE-SPIGKVMK"); return { id: He, diagram: r }; }), "loader"), Wa = { id: He, detector: ja, loader: qa }, Xa = Wa, Ka = t((r, e, a) => {
    g.debug(`rendering svg for syntax error
`);
    let i = jr(e), o = i.append("g");
    i.attr("viewBox", "0 0 2412 512"), Br(i, 100, 512, !0), o.append("path").attr("class", "error-icon").attr("d", "m411.313,123.313c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32-9.375,9.375-20.688-20.688c-12.484-12.5-32.766-12.5-45.25,0l-16,16c-1.261,1.261-2.304,2.648-3.31,4.051-21.739-8.561-45.324-13.426-70.065-13.426-105.867,0-192,86.133-192,192s86.133,192 192,192 192-86.133 192-192c0-24.741-4.864-48.327-13.426-70.065 1.402-1.007 2.79-2.049 4.051-3.31l16-16c12.5-12.492 12.5-32.758 0-45.25l-20.688-20.688 9.375-9.375 32.001-31.999zm-219.313,100.687c-52.938,0-96,43.063-96,96 0,8.836-7.164,16-16,16s-16-7.164-16-16c0-70.578 57.422-128 128-128 8.836,0 16,7.164 16,16s-7.164,16-16,16z"), o.append("path").attr("class", "error-icon").attr("d", "m459.02,148.98c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l16,16c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16.001-16z"), o.append("path").attr("class", "error-icon").attr("d", "m340.395,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688 6.25-6.25 6.25-16.375 0-22.625l-16-16c-6.25-6.25-16.375-6.25-22.625,0s-6.25,16.375 0,22.625l15.999,16z"), o.append("path").attr("class", "error-icon").attr("d", "m400,64c8.844,0 16-7.164 16-16v-32c0-8.836-7.156-16-16-16-8.844,0-16,7.164-16,16v32c0,8.836 7.156,16 16,16z"), o.append("path").attr("class", "error-icon").attr("d", "m496,96.586h-32c-8.844,0-16,7.164-16,16 0,8.836 7.156,16 16,16h32c8.844,0 16-7.164 16-16 0-8.836-7.156-16-16-16z"), o.append("path").attr("class", "error-icon").attr("d", "m436.98,75.605c3.125,3.125 7.219,4.688 11.313,4.688 4.094,0 8.188-1.563 11.313-4.688l32-32c6.25-6.25 6.25-16.375 0-22.625s-16.375-6.25-22.625,0l-32,32c-6.251,6.25-6.251,16.375-0.001,22.625z"), o.append("text").attr("class", "error-text").attr("x", 1440).attr("y", 250).attr("font-size", "150px").style("text-anchor", "middle").text("Syntax error in text"), o.append("text").attr("class", "error-text").attr("x", 1250).attr("y", 400).attr("font-size", "100px").style("text-anchor", "middle").text(`mermaid version ${a}`);
}, "draw"), Be = { draw: Ka }, Qa = Be, Za = { db: {}, renderer: Be, parser: { parse: t(() => { }, "parse") } }, Ja = Za, Ye = "flowchart-elk", ri = t((r, e = {}) => /^\s*flowchart-elk/.test(r) || /^\s*(flowchart|graph)/.test(r) && e?.flowchart?.defaultRenderer === "elk" ? (e.layout = "elk", !0) : !1, "detector"), ei = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/flowDiagram-HODETNUW-RPU3TW4L"); return { id: Ye, diagram: r }; }), "loader"), ti = { id: Ye, detector: ri, loader: ei }, ai = ti, je = "timeline", ii = t(r => /^\s*timeline/.test(r), "detector"), oi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/timeline-definition-24CTP7MA-CVAMGECY"); return { id: je, diagram: r }; }), "loader"), ni = { id: je, detector: ii, loader: oi }, si = ni, qe = "mindmap", di = t(r => /^\s*mindmap/.test(r), "detector"), ci = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/mindmap-definition-YA3MSWOX-K546NP57"); return { id: qe, diagram: r }; }), "loader"), li = { id: qe, detector: di, loader: ci }, ui = li, We = "kanban", mi = t(r => /^\s*kanban/.test(r), "detector"), pi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/kanban-definition-UXKFOSKX-C2JPHKMX"); return { id: We, diagram: r }; }), "loader"), fi = { id: We, detector: mi, loader: pi }, gi = fi, Xe = "sankey", vi = t(r => /^\s*sankey(-beta)?/.test(r), "detector"), hi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/sankeyDiagram-P5KCCOFB-RICXLLGO"); return { id: Xe, diagram: r }; }), "loader"), yi = { id: Xe, detector: vi, loader: hi }, wi = yi, Ke = "packet", bi = t(r => /^\s*packet(-beta)?/.test(r), "detector"), xi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/diagram-Z3DM3KII-DL2WOWA6"); return { id: Ke, diagram: r }; }), "loader"), Si = { id: Ke, detector: bi, loader: xi }, Qe = "radar", Ei = t(r => /^\s*radar-beta/.test(r), "detector"), Di = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/diagram-UQ7AKVKN-H6UQCT42"); return { id: Qe, diagram: r }; }), "loader"), Ti = { id: Qe, detector: Ei, loader: Di }, Ze = "block", Ai = t(r => /^\s*block(-beta)?/.test(r), "detector"), _i = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/blockDiagram-I7D4REHJ-5ELXOA2O"); return { id: Ze, diagram: r }; }), "loader"), Ri = { id: Ze, detector: Ai, loader: _i }, Li = Ri, Je = "treeView", Mi = t(r => /^\s*treeView-beta/.test(r), "detector"), Ci = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/diagram-S7CK7UJ4-LKKQRIPL"); return { id: Je, diagram: r }; }), "loader"), ki = { id: Je, detector: Mi, loader: Ci }, Ii = ki, rt = "architecture", Fi = t(r => /^\s*architecture/.test(r), "detector"), Oi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/architectureDiagram-5GKGNRK7-KMBVUXRW"); return { id: rt, diagram: r }; }), "loader"), $i = { id: rt, detector: Fi, loader: Oi }, zi = $i, et = "eventmodeling", Pi = t(r => /^\s*eventmodeling/.test(r), "detector"), Ni = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/diagram-VSXAHHWV-R26CN363"); return { id: et, diagram: r }; }), "loader"), Vi = { id: et, detector: Pi, loader: Ni }, Ui = Vi, tt = "ishikawa", Gi = t(r => /^\s*ishikawa(-beta)?\b/i.test(r), "detector"), Hi = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/ishikawaDiagram-5VMMS53U-JNJWUS2D"); return { id: tt, diagram: r }; }), "loader"), Bi = { id: tt, detector: Gi, loader: Hi }, at = "venn", Yi = t(r => /^\s*venn-beta/.test(r), "detector"), ji = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/vennDiagram-4TSXK5OY-45TSAFKN"); return { id: at, diagram: r }; }), "loader"), qi = { id: at, detector: Yi, loader: ji }, Wi = qi, it = "treemap", Xi = t(r => /^\s*treemap/.test(r), "detector"), Ki = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/diagram-VX7I27RA-FEGPZZIZ"); return { id: it, diagram: r }; }), "loader"), Qi = { id: it, detector: Xi, loader: Ki }, ot = "wardley", Zi = t(r => /^\s*wardley-beta/i.test(r), "detector"), Ji = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/wardleyDiagram-VM6X3IG4-3XQ7C2A2"); return { id: ot, diagram: r }; }), "loader"), ro = { id: ot, detector: Zi, loader: Ji }, eo = ro, nt = "cynefin", to = t(r => /^\s*cynefin-beta(?:[\s:]|$)/.test(r), "detector"), ao = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/cynefinDiagram-5FMLGOSQ-2MX24WHG"); return { id: nt, diagram: r }; }), "loader"), io = { id: nt, detector: to, loader: ao }, st = "railroad", oo = t(r => /^\s*railroad-beta/i.test(r), "detector"), no = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/railroadDiagram-O6MQD6OU-2SU4SVYW"); return { id: st, diagram: r }; }), "loader"), so = { id: st, detector: oo, loader: no }, dt = "railroadEbnf", co = t(r => /^\s*railroad-ebnf-beta/i.test(r), "detector"), lo = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/ebnfDiagram-PWID7BFC-6IFKNLGZ"); return { id: dt, diagram: r }; }), "loader"), uo = { id: dt, detector: co, loader: lo }, ct = "railroadAbnf", mo = t(r => /^\s*railroad-abnf-beta/i.test(r), "detector"), po = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/abnfDiagram-VCTEODGH-LOPIKICP"); return { id: ct, diagram: r }; }), "loader"), fo = { id: ct, detector: mo, loader: po }, lt = "railroadPeg", go = t(r => /^\s*railroad-peg-beta/i.test(r), "detector"), vo = t(() => n(null, null, function* () { let { diagram: r } = yield import("@nf-internal/pegDiagram-XKGWAZYB-L7WFFUJ6"); return { id: lt, diagram: r }; }), "loader"), ho = { id: lt, detector: go, loader: vo }, Se = !1, gr = t(() => { Se || (Se = !0, X("error", Ja, r => r.toLowerCase().trim() === "error"), X("---", { db: { clear: t(() => { }, "clear") }, styles: {}, renderer: { draw: t(() => { }, "draw") }, parser: { parse: t(() => { throw new Error("Diagrams beginning with --- are not valid. If you were trying to use a YAML front-matter, please ensure that you've correctly opened and closed the YAML front-matter with un-indented `---` blocks"); }, "parse") }, init: t(() => null, "init") }, r => r.toLowerCase().trimStart().startsWith("---")), er(ai, ui, zi), er(zt, gi, za, Ia, Jt, sa, la, pa, Ta, La, Xt, Yt, Ut, si, aa, Ya, Ua, Xa, ha, wi, Si, xa, Li, Ui, Ii, Ti, Bi, Qi, so, uo, fo, ho, Wi, eo, io)); }, "addDiagrams"), yo = t(() => n(null, null, function* () { g.debug("Loading registered diagrams"); let e = (yield Promise.allSettled(Object.entries(rr).map(d => n(null, [d], function* ([a, { detector: i, loader: o }]) { if (o)
    try {
        tr(a);
    }
    catch {
        try {
            let { diagram: c, id: s } = yield o();
            X(s, c, i);
        }
        catch (c) {
            throw g.error(`Failed to load external diagram with key ${a}. Removing from detectors.`), delete rr[a], c;
        }
    } })))).filter(a => a.status === "rejected"); if (e.length > 0) {
    g.error(`Failed to load ${e.length} external diagrams`);
    for (let a of e)
        g.error(a);
    throw new Error(`Failed to load ${e.length} external diagrams`);
} }), "loadRegisteredDiagrams"), wo = "graphics-document document";
function ut(r, e) { r.attr("role", wo), e !== "" && r.attr("aria-roledescription", e); }
t(ut, "setA11yDiagramInfo");
function mt(r, e, a, i) { if (r.insert !== void 0) {
    if (a) {
        let o = `chart-desc-${i}`;
        r.attr("aria-describedby", o), r.insert("desc", ":first-child").attr("id", o).text(a);
    }
    if (e) {
        let o = `chart-title-${i}`;
        r.attr("aria-labelledby", o), r.insert("title", ":first-child").attr("id", o).text(e);
    }
} }
t(mt, "addSVGa11yTitleDescription");
var _r = class pt {
    constructor(e, a, i, o, d) { this.type = e, this.text = a, this.db = i, this.parser = o, this.renderer = d; }
    static { t(this, "Diagram"); }
    static fromText(i) {
        return n(this, arguments, function* (e, a = {}) {
            let o = V(), d = xr(e, o);
            e = Kr(e) + `
`;
            try {
                tr(d);
            }
            catch {
                let v = Hr(d);
                if (!v)
                    throw new Gr(`Diagram ${d} not found.`);
                let { id: m, diagram: b } = yield v();
                X(m, b);
            }
            let { db: c, parser: s, renderer: l, init: p } = tr(d);
            return s.parser && (s.parser.yy = c), c.clear?.(), p?.(o), a.title && c.setDiagramTitle?.(a.title), yield s.parse(e), new pt(d, e, c, s, l);
        });
    }
    render(e, a) { return n(this, null, function* () { yield this.renderer.draw(this.text, e, a, this); }); }
    getParser() { return this.parser; }
    getType() { return this.type; }
}, Ee = [], bo = t(() => { Ee.forEach(r => { r(); }), Ee = []; }, "attachFunctions"), xo = t(r => r.replace(/^\s*%%(?!{)[^\n]+\n?/gm, "").trimStart(), "cleanupComments");
function ft(r) {
    let e = r.match(Ur);
    if (!e)
        return { text: r, metadata: {} };
    let a = e[1], i = a ? e[2].split(`
`).map(c => c.startsWith(a) ? c.slice(a.length) : c).join(`
`) : e[2], o = re(i, { schema: Jr }) ?? {};
    o = typeof o == "object" && !Array.isArray(o) ? o : {};
    let d = {};
    return o.displayMode && (d.displayMode = o.displayMode.toString()), o.title && (d.title = o.title.toString()), o.config && (d.config = o.config), { text: r.slice(e[0].length), metadata: d };
}
t(ft, "extractFrontMatter");
var So = t(r => r.replace(/\r\n?/g, `
`).replace(/<(\w+)([^>]*)>/g, (e, a, i) => "<" + a + i.replace(/="([^"]*)"/g, "='$1'") + ">"), "cleanupText"), Eo = t(r => { let { text: e, metadata: a } = ft(r), { displayMode: i, title: o, config: d = {} } = a; return i && (d.gantt || (d.gantt = {}), d.gantt.displayMode = i), { title: o, config: d, text: e }; }, "processFrontmatter"), Do = t(r => { let e = U.detectInit(r) ?? {}, a = U.detectDirective(r, "wrap"); return Array.isArray(a) ? e.wrap = a.some(({ type: i }) => i === "wrap") : a?.type === "wrap" && (e.wrap = !0), { text: Wr(r), directive: e }; }, "processDirectives");
function Lr(r) { let e = So(r), a = Eo(e), i = Do(a.text), o = Xr(a.config, i.directive); return r = xo(i.text), { code: r, title: a.title, config: o }; }
t(Lr, "preprocessDiagram");
function gt(r) { let e = new TextEncoder().encode(r), a = Array.from(e, i => String.fromCodePoint(i)).join(""); return btoa(a); }
t(gt, "toBase64");
var To = 5e4, Ao = "graph TB;a[Maximum text size in diagram exceeded];style a fill:#faa", _o = "sandbox", Ro = "loose", Lo = "http://www.w3.org/2000/svg", Mo = "http://www.w3.org/1999/xlink", Co = "http://www.w3.org/1999/xhtml", ko = "100%", Io = "100%", Fo = "border:0;margin:0;", Oo = "margin:0", $o = "allow-top-navigation-by-user-activation allow-popups", zo = 'The "iframe" tag is not supported by your browser.', Po = ["foreignobject"], No = ["dominant-baseline"];
function Mr(r) { let e = Lr(r); return W(), Nr(e.config ?? {}), e; }
t(Mr, "processAndSetConfigs");
function vt(r, e) { return n(this, null, function* () { gr(); try {
    let { code: a, config: i } = Mr(r);
    return { diagramType: (yield yt(a)).type, config: i };
}
catch (a) {
    if (e?.suppressErrors)
        return !1;
    throw a;
} }); }
t(vt, "parse");
var De = t((r, e, a = []) => { let i = Ir(`{ ${a.join(" !important; ")} !important; }`); return `.${r} ${e} ${i}`; }, "cssImportantStyles"), Vo = t((r, e = new Map) => {
    let a = new CSSStyleSheet;
    if (r.fontFamily !== void 0 && a.insertRule(`:root { --mermaid-font-family: ${r.fontFamily}}`, a.cssRules.length), r.altFontFamily !== void 0 && a.insertRule(`:root { --mermaid-alt-font-family: ${r.altFontFamily}}`, a.cssRules.length), e instanceof Map) {
        let s = Vr(r) ? ["> *", "span"] : ["rect", "polygon", "ellipse", "circle", "path"];
        e.forEach(l => { Er(l.styles) || s.forEach(p => { a.insertRule(De(l.id, p, l.styles), a.cssRules.length); }), Er(l.textStyles) || a.insertRule(De(l.id, "tspan", (l?.textStyles || []).map(p => p.replace("color", "fill"))), a.cssRules.length); });
    }
    let i = "";
    if (r.themeCSS !== void 0)
        if (typeof a.replaceSync == "function") {
            let o = new CSSStyleSheet;
            o.replaceSync(r.themeCSS), i = Sr(o) + `
`;
        }
        else
            i += `${r.themeCSS}
`;
    return i + Sr(a);
}, "createCssStyles"), Uo = t((r, e) => pr(we(`${r}{${e}}`), xe([t(function (i, o, d, c) { if (i.type === "rule" && Array.isArray(i.props)) {
        if (i.parent && i.parent.type === K)
            return;
        i.props = i.props.map(s => s === r && Array.isArray(i.children) && i.children.every(p => p.type !== "decl" ? !1 : new Set(["font-family", "font-size", "fill"]).has(p.props)) || (s.startsWith(`${r} `) || s.startsWith(`${r}>`)) && !s.startsWith(`${r} ||`) ? s : `${r} ${s}`);
    }
    else
        i.type.startsWith("@") && ([...[te, ie, or, ne, "@container", "@starting-style"], K].includes(i.type) || (g.warn(`Removing unsupported at-rule ${i.type} from CSS`), i.type = G)); }, "addNamespace"), be])), "compileCSS"), Go = t((r, e, a, i) => { let o = Vo(r, a), d = Yr(e, o, hr(vr({}, r.themeVariables), { theme: r.theme, look: r.look }), i); return Uo(i, d); }, "createUserStyles"), Ho = t((r = "", e, a) => { let i = r; return !a && !e && (i = i.replace(/marker-end="url\([\d+./:=?A-Za-z-]*?#/g, 'marker-end="url(#')), i = Qr(i), i = i.replace(/<br>/g, "<br/>"), i; }, "cleanUpSvgCode"), Bo = t((r = "", e) => {
    let a = e?.viewBox?.baseVal?.height ? e.viewBox.baseVal.height + "px" : Io, i = gt(`<body style="${Oo}">${r}</body>`);
    return `<iframe style="width:${ko};height:${a};${Fo}" src="data:text/html;charset=UTF-8;base64,${i}" sandbox="${$o}">
  ${zo}
</iframe>`;
}, "putIntoIFrame"), Te = t((r, e, a, i, o) => { let d = r.append("div"); d.attr("id", a), i && d.attr("style", i); let c = d.append("svg").attr("id", e).attr("width", "100%").attr("xmlns", Lo); return o && c.attr("xmlns:xlink", o), c.append("g"), r; }, "appendDivSvgG");
function Rr(r, e) { return r.append("iframe").attr("id", e).attr("style", "width: 100%; height: 100%;").attr("sandbox", ""); }
t(Rr, "sandboxedIframe");
var Yo = t((r, e, a, i) => { r.getElementById(e)?.remove(), r.getElementById(a)?.remove(), r.getElementById(i)?.remove(); }, "removeExistingElements"), jo = t(function (r, e, a) { return n(this, null, function* () { gr(); let i = Mr(e); e = i.code; let o = V(); g.debug(o), e.length > (o?.maxTextSize ?? To) && (e = Ao); let d = `#${r}`, c = "i" + r, s = "#" + c, l = "d" + r, p = "#" + l, v = t(() => { let q = k(b ? s : p).node(); q && "remove" in q && q.remove(); }, "removeTempElements"), m = k(document.body), b = o.securityLevel === _o, A = o.securityLevel === Ro, _ = o.fontFamily; if (a !== void 0) {
    if (a && (a.innerHTML = ""), b) {
        let w = Rr(k(a), c);
        m = k(w.nodes()[0].contentDocument.body), m.node().style.margin = "0";
    }
    else
        m = k(a);
    Te(m, r, l, `font-family: ${_}`, Mo);
}
else {
    if (Yo(document, r, l, c), b) {
        let w = Rr(k(document.body), c);
        m = k(w.nodes()[0].contentDocument.body), m.node().style.margin = "0";
    }
    else
        m = k("body");
    Te(m, r, l);
} let f, C; try {
    f = yield _r.fromText(e, { title: i.title });
}
catch (w) {
    if (o.suppressErrorRendering)
        throw v(), w;
    f = yield _r.fromText("error"), C = w;
} let R = m.select(p).node(), x = f.type, h = R.firstChild, L = h.firstChild, N = f.renderer.getClasses?.(e, f), M = Go(o, x, N, d), E = document.createElement("style"); E.innerHTML = M, h.insertBefore(E, L); try {
    yield f.renderer.draw(e, r, "11.17.2", f);
}
catch (w) {
    throw o.suppressErrorRendering ? v() : Qa.draw(e, r, "11.17.2"), w;
} let u = m.select(`${p} svg`), Tt = f.db.getAccTitle?.(), At = f.db.getAccDescription?.(); wt(x, u, Tt, At); let _t = t(() => { m.select(`[id="${r}"]`).selectAll("foreignobject > *").attr("xmlns", Co); let w = m.select(p).node().innerHTML; if (g.debug("config.arrowMarkerAbsolute", o.arrowMarkerAbsolute), w = Ho(w, b, Fr(o.arrowMarkerAbsolute)), b) {
    let q = m.select(p + " svg").node();
    w = Bo(w, q);
}
else
    A || (w = Cr.sanitize(w, { ADD_TAGS: Po, ADD_ATTR: No, HTML_INTEGRATION_POINTS: { foreignobject: !0 } })); return bo(), w; }, "serializeSvg")(); if (C)
    throw C; return v(), { diagramType: x, svg: _t, bindFunctions: f.db.bindFunctions }; }); }, "render");
function ht(r = {}) { let e = kr({}, r); e?.fontFamily && !e.themeVariables?.fontFamily && (e.themeVariables || (e.themeVariables = {}), e.themeVariables.fontFamily = e.fontFamily), $r(e), e?.theme && e.theme in J ? e.themeVariables = J[e.theme].getThemeVariables(e.themeVariables) : e && (e.themeVariables = J.default.getThemeVariables(e.themeVariables)); let a = typeof e == "object" ? Or(e) : br(); yr(a.logLevel), gr(); }
t(ht, "initialize");
var yt = t((r, e = {}) => { let { code: a } = Lr(r); return _r.fromText(a, e); }, "getDiagramFromText");
function wt(r, e, a, i) { ut(e, r), mt(e, a, i, e.attr("id")); }
t(wt, "addA11yInfo");
var P = Object.freeze({ render: jo, parse: vt, getDiagramFromText: yt, initialize: ht, getConfig: V, setConfig: Pr, getSiteConfig: br, updateSiteConfig: zr, reset: t(() => { W(); }, "reset"), globalReset: t(() => { W(wr); }, "globalReset"), defaultConfig: wr });
yr(V().logLevel);
W(V());
var qo = t((r, e, a) => { g.warn(r), Dr(r) ? (a && a(r.str, r.hash), e.push(hr(vr({}, r), { message: r.str, error: r }))) : (a && a(r), r instanceof Error && e.push({ str: r.message, message: r.message, hash: r.name, error: r })); }, "handleError"), bt = t(function () { return n(this, arguments, function* (r = { querySelector: ".mermaid" }) { try {
    yield Wo(r);
}
catch (e) {
    if (Dr(e) && g.error(e.str), $.parseError && $.parseError(e), !r.suppressErrors)
        throw g.error("Use the suppressErrors option to suppress these errors"), e;
} }); }, "run"), Wo = t(function () { return n(this, arguments, function* ({ postRenderCallback: r, querySelector: e, nodes: a } = { querySelector: ".mermaid" }) { let i = P.getConfig(); g.debug(`${r ? "" : "No "}Callback function found`); let o; if (a)
    o = a;
else if (e)
    o = document.querySelectorAll(e);
else
    throw new Error("Nodes and querySelector are both undefined"); g.debug(`Found ${o.length} diagrams`), i?.startOnLoad !== void 0 && (g.debug("Start On Load: " + i?.startOnLoad), P.updateSiteConfig({ startOnLoad: i?.startOnLoad })); let d = new U.InitIDGenerator(i.deterministicIds, i.deterministicIDSeed), c, s = []; for (let l of Array.from(o)) {
    if (g.info("Rendering diagram: " + l.id), l.getAttribute("data-processed"))
        continue;
    l.setAttribute("data-processed", "true");
    let p = `mermaid-${d.next()}`;
    c = l.innerHTML, c = Zr(U.entityDecode(c)).trim().replace(/<br\s*\/?>/gi, "<br/>");
    let v = U.detectInit(c);
    v && g.debug("Detected early reinit: ", v);
    try {
        let { svg: m, bindFunctions: b } = yield Dt(p, c, l);
        l.innerHTML = m, r && (yield r(p)), b && b(l);
    }
    catch (m) {
        qo(m, s, $.parseError);
    }
} if (s.length > 0)
    throw s[0]; }); }, "runThrowsErrors"), xt = t(function (r) { P.initialize(r); }, "initialize"), Xo = t(function (r, e, a) { return n(this, null, function* () { g.warn("mermaid.init is deprecated. Please use run instead."), r && xt(r); let i = { postRenderCallback: a, querySelector: ".mermaid" }; typeof e == "string" ? i.querySelector = e : e && (e instanceof HTMLElement ? i.nodes = [e] : i.nodes = e), yield bt(i); }); }, "init"), Ko = t((a, ...i) => n(null, [a, ...i], function* (r, { lazyLoad: e = !0 } = {}) { gr(), er(...r), e === !1 && (yield yo()); }), "registerExternalDiagrams"), St = t(function () { if ($.startOnLoad) {
    let { startOnLoad: r } = P.getConfig();
    r && $.run().catch(e => g.error("Mermaid failed to initialize", e));
} }, "contentLoaded");
typeof document < "u" && window.addEventListener("load", St, !1);
var Qo = t(function (r) { $.parseError = r; }, "setParseErrorHandler"), fr = [], Ar = !1, Et = t(() => n(null, null, function* () { if (!Ar) {
    for (Ar = !0; fr.length > 0;) {
        let r = fr.shift();
        if (r)
            try {
                yield r();
            }
            catch (e) {
                g.error("Error executing queue", e);
            }
    }
    Ar = !1;
} }), "executeQueue"), Zo = t((r, e) => n(null, null, function* () { return new Promise((a, i) => { let o = t(() => new Promise((d, c) => { P.parse(r, e).then(s => { d(s), a(s); }, s => { g.error("Error parsing", s), $.parseError?.(s), c(s), i(s); }); }), "performCall"); fr.push(o), Et().catch(i); }); }), "parse"), Dt = t((r, e, a) => new Promise((i, o) => { let d = t(() => new Promise((c, s) => { P.render(r, e, a).then(l => { c(l), i(l); }, l => { g.error("Error parsing", l), $.parseError?.(l), s(l), o(l); }); }), "performCall"); fr.push(d), Et().catch(o); }), "render"), Jo = t(() => Object.keys(rr).map(r => ({ id: r })), "getRegisteredDiagramsMetadata"), $ = { startOnLoad: !0, mermaidAPI: P, parse: Zo, render: Dt, init: Xo, run: bt, registerExternalDiagrams: Ko, registerLayoutLoaders: ee, initialize: xt, parseError: void 0, contentLoaded: St, setParseErrorHandler: Qo, detectType: xr, registerIconPacks: qr, getRegisteredDiagramsMetadata: Jo }, Pn = $;
export { Lt as clearLayoutRenderState, Rt as createCommonLayoutRenderer, Pn as default, Mt as defaultMeasureLayout, Ct as paintLayoutData };
/*! Bundled license information:

mermaid/dist/mermaid.core.mjs:
  (*! Check if previously processed *)
  (*!
   * Wait for document loaded before starting the execution
   *)
*/
