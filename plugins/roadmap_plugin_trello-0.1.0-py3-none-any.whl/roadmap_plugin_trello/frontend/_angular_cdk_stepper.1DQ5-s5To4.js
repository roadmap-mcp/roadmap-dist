import { a as y } from "@nf-internal/chunk-TTLGK2TK";
import { c as m } from "@nf-internal/chunk-ZGWTKG5Z";
import "@nf-internal/chunk-RNULGOC3";
import "@nf-internal/chunk-Z4DWJRNS";
import { a as g } from "@nf-internal/chunk-SVIUGILY";
import { e as E, l as k } from "@nf-internal/chunk-LAIZNMCN";
import { a as I } from "@nf-internal/chunk-RMOXI6XO";
import { b } from "@nf-internal/chunk-5HDY5C2T";
import { c as v } from "@nf-internal/chunk-6QY5OUOO";
import "@nf-internal/chunk-OSQMNGTH";
import * as s from "@angular/core";
import { inject as o, ElementRef as M, TemplateRef as S, InjectionToken as x, signal as a, EventEmitter as _, computed as p, booleanAttribute as l, ChangeDetectorRef as O, QueryList as C, numberAttribute as N } from "@angular/core";
import { ControlContainer as A } from "@angular/forms";
import { Subject as R, of as w } from "rxjs";
import { startWith as h, takeUntil as u } from "rxjs/operators";
var T = ["*"];
function P(i, B) { i & 1 && s.\u0275\u0275projection(0); }
var F = (() => { class i {
    _elementRef = o(M);
    constructor() { }
    focus() { this._elementRef.nativeElement.focus(); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkStepHeader", ""]], hostAttrs: ["role", "tab"] });
} return i; })(), H = (() => { class i {
    template = o(S);
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkStepLabel", ""]] });
} return i; })(), D = class {
    selectedIndex;
    previouslySelectedIndex;
    selectedStep;
    previouslySelectedStep;
}, c = { NUMBER: "number", EDIT: "edit", DONE: "done", ERROR: "error" }, L = new x("STEPPER_GLOBAL_OPTIONS"), Q = (() => { class i {
    _stepperOptions;
    _stepper = o(f);
    _displayDefaultIndicatorType;
    stepLabel;
    _childForms;
    content;
    stepControl;
    get interacted() { return this._interacted(); }
    set interacted(e) { this._interacted.set(e); }
    _interacted = a(!1);
    interactedStream = new _;
    label;
    errorMessage;
    ariaLabel;
    ariaLabelledby;
    get state() { return this._state(); }
    set state(e) { this._state.set(e); }
    _state = a(void 0);
    get editable() { return this._editable(); }
    set editable(e) { this._editable.set(e); }
    _editable = a(!0);
    optional = !1;
    get completed() { let e = this._completedOverride(), t = this._interacted(); return e ?? (t && (!this.stepControl || this.stepControl.valid)); }
    set completed(e) { this._completedOverride.set(e); }
    _completedOverride = a(null);
    index = a(-1);
    isSelected = p(() => this._stepper.selectedIndex === this.index());
    indicatorType = p(() => { let e = this.isSelected(), t = this.completed, r = this._state() ?? c.NUMBER, n = this._editable(); return this._showError() && this.hasError && !e ? c.ERROR : this._displayDefaultIndicatorType ? !t || e ? c.NUMBER : n ? c.EDIT : c.DONE : t && !e ? c.DONE : t && e ? r : n && e ? c.EDIT : r; });
    isNavigable = p(() => { let e = this.isSelected(); return this.completed || e || !this._stepper.linear; });
    get hasError() { let e = this._customError(); return e ?? this._getDefaultError(); }
    set hasError(e) { this._customError.set(e); }
    _customError = a(null);
    _getDefaultError() { return this.interacted && !!this.stepControl?.invalid; }
    constructor() { let e = o(L, { optional: !0 }); this._stepperOptions = e || {}, this._displayDefaultIndicatorType = this._stepperOptions.displayDefaultIndicatorType !== !1; }
    select() { this._stepper.selected = this; }
    reset() { this._interacted.set(!1), this._completedOverride() != null && this._completedOverride.set(!1), this._customError() != null && this._customError.set(!1), this.stepControl && (this._childForms?.forEach(e => e.resetForm?.()), this.stepControl.reset()); }
    ngOnChanges() { this._stepper._stateChanged(); }
    _markAsInteracted() { this._interacted() || (this._interacted.set(!0), this.interactedStream.emit(this)); }
    _showError() { return this._stepperOptions.showError ?? this._customError() != null; }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-step"]], contentQueries: function (t, r, n) { if (t & 1 && s.\u0275\u0275contentQuery(n, H, 5)(n, A, 5), t & 2) {
            let d;
            s.\u0275\u0275queryRefresh(d = s.\u0275\u0275loadQuery()) && (r.stepLabel = d.first), s.\u0275\u0275queryRefresh(d = s.\u0275\u0275loadQuery()) && (r._childForms = d);
        } }, viewQuery: function (t, r) { if (t & 1 && s.\u0275\u0275viewQuery(S, 7), t & 2) {
            let n;
            s.\u0275\u0275queryRefresh(n = s.\u0275\u0275loadQuery()) && (r.content = n.first);
        } }, inputs: { stepControl: "stepControl", label: "label", errorMessage: "errorMessage", ariaLabel: [0, "aria-label", "ariaLabel"], ariaLabelledby: [0, "aria-labelledby", "ariaLabelledby"], state: "state", editable: [2, "editable", "editable", l], optional: [2, "optional", "optional", l], completed: [2, "completed", "completed", l], hasError: [2, "hasError", "hasError", l] }, outputs: { interactedStream: "interacted" }, exportAs: ["cdkStep"], features: [s.\u0275\u0275NgOnChangesFeature], ngContentSelectors: T, decls: 1, vars: 0, template: function (t, r) { t & 1 && (s.\u0275\u0275projectionDef(), s.\u0275\u0275domTemplate(0, P, 1, 0, "ng-template")); }, encapsulation: 2, changeDetection: 0 });
} return i; })(), f = (() => { class i {
    _dir = o(v, { optional: !0 });
    _changeDetectorRef = o(O);
    _elementRef = o(M);
    _destroyed = new R;
    _keyManager;
    _steps;
    steps = new C;
    _stepHeader;
    _sortedHeaders = new C;
    get linear() { return this._linear(); }
    set linear(e) { this._linear.set(e); }
    _linear = a(!1);
    get selectedIndex() { return this._selectedIndex(); }
    set selectedIndex(e) { this._steps ? (this._isValidIndex(e), this.selectedIndex !== e && (this.selected?._markAsInteracted(), !this._anyControlsInvalidOrPending(e) && (e >= this.selectedIndex || this.steps.toArray()[e].editable) && this._updateSelectedItemIndex(e))) : this._selectedIndex.set(e); }
    _selectedIndex = a(0);
    get selected() { return this.steps ? this.steps.toArray()[this.selectedIndex] : void 0; }
    set selected(e) { this.selectedIndex = e && this.steps ? this.steps.toArray().indexOf(e) : -1; }
    selectionChange = new _;
    selectedIndexChange = new _;
    _groupId = o(I).getId("cdk-stepper-");
    get orientation() { return this._orientation; }
    set orientation(e) { this._orientation = e, this._keyManager && this._keyManager.withVerticalOrientation(e === "vertical"); }
    _orientation = "horizontal";
    constructor() { }
    ngAfterContentInit() { this._steps.changes.pipe(h(this._steps), u(this._destroyed)).subscribe(e => { this.steps.reset(e.filter(t => t._stepper === this)), this.steps.forEach((t, r) => t.index.set(r)), this.steps.notifyOnChanges(); }); }
    ngAfterViewInit() { if (this._stepHeader.changes.pipe(h(this._stepHeader), u(this._destroyed)).subscribe(e => { this._sortedHeaders.reset(e.toArray().sort((t, r) => t._elementRef.nativeElement.compareDocumentPosition(r._elementRef.nativeElement) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1)), this._sortedHeaders.notifyOnChanges(); }), this._keyManager = new y(this._sortedHeaders).withWrap().withHomeAndEnd().withVerticalOrientation(this._orientation === "vertical"), this._keyManager.updateActiveItem(this.selectedIndex), (this._dir ? this._dir.change : w()).pipe(h(this._layoutDirection()), u(this._destroyed)).subscribe(e => this._keyManager?.withHorizontalOrientation(e)), this._keyManager.updateActiveItem(this.selectedIndex), this.steps.changes.subscribe(() => { this.selected || this._selectedIndex.set(Math.max(this.selectedIndex - 1, 0)); }), this._isValidIndex(this.selectedIndex) || this._selectedIndex.set(0), this.linear && this.selectedIndex > 0) {
        let e = this.steps.toArray().slice(0, this._selectedIndex());
        for (let t of e)
            t._markAsInteracted();
    } }
    ngOnDestroy() { this._keyManager?.destroy(), this.steps.destroy(), this._sortedHeaders.destroy(), this._destroyed.next(), this._destroyed.complete(); }
    next() { this.selectedIndex = Math.min(this._selectedIndex() + 1, this.steps.length - 1); }
    previous() { this.selectedIndex = Math.max(this._selectedIndex() - 1, 0); }
    reset() { this._updateSelectedItemIndex(0), this.steps.forEach(e => e.reset()), this._stateChanged(); }
    _getStepLabelId(e) { return `${this._groupId}-label-${e}`; }
    _getStepContentId(e) { return `${this._groupId}-content-${e}`; }
    _stateChanged() { this._changeDetectorRef.markForCheck(); }
    _getAnimationDirection(e) { let t = e - this._selectedIndex(); return t < 0 ? this._layoutDirection() === "rtl" ? "next" : "previous" : t > 0 ? this._layoutDirection() === "rtl" ? "previous" : "next" : "current"; }
    _getFocusIndex() { return this._keyManager ? this._keyManager.activeItemIndex : this._selectedIndex(); }
    _updateSelectedItemIndex(e) { let t = this.steps.toArray(), r = this._selectedIndex(); this.selectionChange.emit({ selectedIndex: e, previouslySelectedIndex: r, selectedStep: t[e], previouslySelectedStep: t[r] }), this._keyManager && (this._containsFocus() ? this._keyManager.setActiveItem(e) : this._keyManager.updateActiveItem(e)), this._selectedIndex.set(e), this.selectedIndexChange.emit(e), this._stateChanged(); }
    _onKeydown(e) { let t = g(e), r = e.keyCode, n = this._keyManager; n?.activeItemIndex != null && !t && (r === 32 || r === 13) ? (this.selectedIndex = n.activeItemIndex, e.preventDefault()) : n?.setFocusOrigin("keyboard").onKeydown(e); }
    _anyControlsInvalidOrPending(e) { return this.linear && e >= 0 ? this.steps.toArray().slice(0, e).some(t => { let r = t.stepControl; return (r ? r.invalid || r.pending || !t.interacted : !t.completed) && !t.optional && !t._completedOverride(); }) : !1; }
    _layoutDirection() { return this._dir && this._dir.value === "rtl" ? "rtl" : "ltr"; }
    _containsFocus() { let e = this._elementRef.nativeElement, t = m(); return e === t || e.contains(t); }
    _isValidIndex(e) { return e > -1 && (!this.steps || e < this.steps.length); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkStepper", ""]], contentQueries: function (t, r, n) { if (t & 1 && s.\u0275\u0275contentQuery(n, Q, 5)(n, F, 5), t & 2) {
            let d;
            s.\u0275\u0275queryRefresh(d = s.\u0275\u0275loadQuery()) && (r._steps = d), s.\u0275\u0275queryRefresh(d = s.\u0275\u0275loadQuery()) && (r._stepHeader = d);
        } }, inputs: { linear: [2, "linear", "linear", l], selectedIndex: [2, "selectedIndex", "selectedIndex", N], selected: "selected", orientation: "orientation" }, outputs: { selectionChange: "selectionChange", selectedIndexChange: "selectedIndexChange" }, exportAs: ["cdkStepper"] });
} return i; })(), de = (() => { class i {
    _stepper = o(f);
    type = "submit";
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["button", "cdkStepperNext", ""]], hostVars: 1, hostBindings: function (t, r) { t & 1 && s.\u0275\u0275listener("click", function () { return r._stepper.next(); }), t & 2 && s.\u0275\u0275domProperty("type", r.type); }, inputs: { type: "type" } });
} return i; })(), ae = (() => { class i {
    _stepper = o(f);
    type = "button";
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["button", "cdkStepperPrevious", ""]], hostVars: 1, hostBindings: function (t, r) { t & 1 && s.\u0275\u0275listener("click", function () { return r._stepper.previous(); }), t & 2 && s.\u0275\u0275domProperty("type", r.type); }, inputs: { type: "type" } });
} return i; })(), ce = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275mod = s.\u0275\u0275defineNgModule({ type: i });
    static \u0275inj = s.\u0275\u0275defineInjector({ imports: [b] });
} return i; })();
export { Q as CdkStep, F as CdkStepHeader, H as CdkStepLabel, f as CdkStepper, ce as CdkStepperModule, de as CdkStepperNext, ae as CdkStepperPrevious, L as STEPPER_GLOBAL_OPTIONS, c as STEP_STATE, D as StepperSelectionEvent };
