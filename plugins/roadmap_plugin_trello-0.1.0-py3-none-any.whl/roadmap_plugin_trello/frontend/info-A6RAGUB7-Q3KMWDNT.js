import { a as o, b as e } from "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { o as InfoModule, e as createInfoServices };
