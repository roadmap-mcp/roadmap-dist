import { H as z, u as $ } from "@nf-internal/chunk-LEJRRF65";
import { b as I } from "@nf-internal/chunk-RZWXGGKD";
import { a as d } from "@nf-internal/chunk-YUSHYV7C";
import { a, b as x, f as T } from "@nf-internal/chunk-OSQMNGTH";
var _ = Object.freeze({ left: 0, top: 0, width: 16, height: 16 }), g = Object.freeze({ rotate: 0, vFlip: !1, hFlip: !1 }), b = Object.freeze(a(a({}, _), g)), A = Object.freeze(x(a({}, b), { body: "", hidden: !1 }));
var Q = Object.freeze({ width: null, height: null }), U = Object.freeze(a(a({}, Q), g));
var j = (t, o, n, r = "") => { let e = t.split(":"); if (t.slice(0, 1) === "@") {
    if (e.length < 2 || e.length > 3)
        return null;
    r = e.shift().slice(1);
} if (e.length > 3 || !e.length)
    return null; if (e.length > 1) {
    let c = e.pop(), m = e.pop(), p = { provider: e.length > 0 ? e[0] : r, prefix: m, name: c };
    return o && !v(p) ? null : p;
} let s = e[0], i = s.split("-"); if (i.length > 1) {
    let c = { provider: r, prefix: i.shift(), name: i.join("-") };
    return o && !v(c) ? null : c;
} if (n && r === "") {
    let c = { provider: r, prefix: "", name: s };
    return o && !v(c, n) ? null : c;
} return null; }, v = (t, o) => t ? !!((o && t.prefix === "" || t.prefix) && t.name) : !1;
function q(t, o) { let n = {}; !t.hFlip != !o.hFlip && (n.hFlip = !0), !t.vFlip != !o.vFlip && (n.vFlip = !0); let r = ((t.rotate || 0) + (o.rotate || 0)) % 4; return r && (n.rotate = r), n; }
function D(t, o) { let n = q(t, o); for (let r in A)
    r in g ? r in t && !(r in n) && (n[r] = g[r]) : r in o ? n[r] = o[r] : r in t && (n[r] = t[r]); return n; }
function R(t, o) { let n = t.icons, r = t.aliases || Object.create(null), e = Object.create(null); function s(i) { if (n[i])
    return e[i] = []; if (!(i in e)) {
    e[i] = null;
    let c = r[i] && r[i].parent, m = c && s(c);
    m && (e[i] = [c].concat(m));
} return e[i]; } return (o || Object.keys(n).concat(Object.keys(r))).forEach(s), e; }
function L(t, o, n) { let r = t.icons, e = t.aliases || Object.create(null), s = {}; function i(c) { s = D(r[c] || e[c], s); } return i(o), n.forEach(i), D(t, s); }
function F(t, o) { if (t.icons[o])
    return L(t, o, []); let n = R(t, [o])[o]; return n ? L(t, o, n) : null; }
var J = /(-?[0-9.]*[0-9]+[0-9.]*)/g, X = /^-?[0-9.]*[0-9]+[0-9.]*$/g;
function C(t, o, n) { if (o === 1)
    return t; if (n = n || 100, typeof t == "number")
    return Math.ceil(t * o * n) / n; if (typeof t != "string")
    return t; let r = t.split(J); if (r === null || !r.length)
    return t; let e = [], s = r.shift(), i = X.test(s); for (;;) {
    if (i) {
        let c = parseFloat(s);
        isNaN(c) ? e.push(s) : e.push(Math.ceil(c * o * n) / n);
    }
    else
        e.push(s);
    if (s = r.shift(), s === void 0)
        return e.join("");
    i = !i;
} }
function Y(t, o = "defs") { let n = "", r = t.indexOf("<" + o); for (; r >= 0;) {
    let e = t.indexOf(">", r), s = t.indexOf("</" + o);
    if (e === -1 || s === -1)
        break;
    let i = t.indexOf(">", s);
    if (i === -1)
        break;
    n += t.slice(e + 1, s).trim(), t = t.slice(0, r).trim() + t.slice(i + 1);
} return { defs: n, content: t }; }
function Z(t, o) { return t ? "<defs>" + t + "</defs>" + o : o; }
function H(t, o, n) { let r = Y(t); return Z(r.defs, o + r.content + n); }
var tt = t => t === "unset" || t === "undefined" || t === "none";
function y(t, o) { let n = a(a({}, b), t), r = a(a({}, U), o), e = { left: n.left, top: n.top, width: n.width, height: n.height }, s = n.body; [n, r].forEach(h => { let f = [], W = h.hFlip, P = h.vFlip, u = h.rotate; W ? P ? u += 2 : (f.push("translate(" + (e.width + e.left).toString() + " " + (0 - e.top).toString() + ")"), f.push("scale(-1 1)"), e.top = e.left = 0) : P && (f.push("translate(" + (0 - e.left).toString() + " " + (e.height + e.top).toString() + ")"), f.push("scale(1 -1)"), e.top = e.left = 0); let l; switch (u < 0 && (u -= Math.floor(u / 4) * 4), u = u % 4, u) {
    case 1:
        l = e.height / 2 + e.top, f.unshift("rotate(90 " + l.toString() + " " + l.toString() + ")");
        break;
    case 2:
        f.unshift("rotate(180 " + (e.width / 2 + e.left).toString() + " " + (e.height / 2 + e.top).toString() + ")");
        break;
    case 3: l = e.width / 2 + e.left, f.unshift("rotate(-90 " + l.toString() + " " + l.toString() + ")");
} u % 2 === 1 && (e.left !== e.top && (l = e.left, e.left = e.top, e.top = l), e.width !== e.height && (l = e.width, e.width = e.height, e.height = l)), f.length && (s = H(s, '<g transform="' + f.join(" ") + '">', "</g>")); }); let i = r.width, c = r.height, m = e.width, p = e.height, S, w; i === null ? (w = c === null ? "1em" : c === "auto" ? p : c, S = C(w, m / p)) : (S = i === "auto" ? m : i, w = c === null ? C(S, p / m) : c === "auto" ? p : c); let E = {}, G = (h, f) => { tt(f) || (E[h] = f.toString()); }; G("width", S), G("height", w); let M = [e.left, e.top, m, p]; return E.viewBox = M.join(" "), { attributes: E, viewBox: M, body: s }; }
var et = /\sid="(\S+)"/g, N = new Map;
function ot(t) { t = t.replace(/[0-9]+$/, "") || "a"; let o = N.get(t) || 0; return N.set(t, o + 1), o ? `${t}${o}` : t; }
function O(t) { let o = [], n; for (; n = et.exec(t);)
    o.push(n[1]); if (!o.length)
    return t; let r = "suffix" + (Math.random() * 16777216 | Date.now()).toString(16); return o.forEach(e => { let s = ot(e), i = e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); t = t.replace(new RegExp('([#;"])(' + i + ')([")]|\\.[a-z])', "g"), "$1" + s + r + "$3"); }), t = t.replace(new RegExp(r, "g"), ""), t; }
function V(t, o) { let n = t.indexOf("xlink:") === -1 ? "" : ' xmlns:xlink="http://www.w3.org/1999/xlink"'; for (let r in o)
    n += " " + r + '="' + o[r] + '"'; return '<svg xmlns="http://www.w3.org/2000/svg"' + n + ">" + t + "</svg>"; }
var rt = { body: '<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/><text transform="translate(21.16 64.67)" style="fill: #fff; font-family: ArialMT, Arial; font-size: 67.75px;"><tspan x="0" y="0">?</tspan></text></g>', height: 80, width: 80 }, k = new Map, B = new Map, qt = d(t => { for (let o of t) {
    if (!o.name)
        throw new Error('Invalid icon loader. Must have a "name" property with non-empty string value.');
    if (I.debug("Registering icon pack:", o.name), "loader" in o)
        B.set(o.name, o.loader);
    else if ("icons" in o)
        k.set(o.name, o.icons);
    else
        throw I.error("Invalid icon loader:", o), new Error('Invalid icon loader. Must have either "icons" or "loader" property.');
} }, "registerIconPacks"), K = d((t, o) => T(null, null, function* () { let n = j(t, !0, o !== void 0); if (!n)
    throw new Error(`Invalid icon name: ${t}`); let r = n.prefix || o; if (!r)
    throw new Error(`Icon name must contain a prefix: ${t}`); let e = k.get(r); if (!e) {
    let i = B.get(r);
    if (!i)
        throw new Error(`Icon set not found: ${n.prefix}`);
    try {
        let c = yield i();
        e = x(a({}, c), { prefix: r }), k.set(r, e);
    }
    catch (c) {
        throw I.error(c), new Error(`Failed to load icon set: ${n.prefix}`);
    }
} let s = F(e, n.name); if (!s)
    throw new Error(`Icon not found: ${t}`); return s; }), "getRegisteredIconData"), Rt = d(t => T(null, null, function* () { try {
    return yield K(t), !0;
}
catch {
    return !1;
} }), "isIconAvailable"), Lt = d((t, o, n) => T(null, null, function* () { let r; try {
    r = yield K(t, o?.fallbackPrefix);
}
catch (i) {
    I.error(i), r = rt;
} let e = y(r, o), s = V(O(e.body), a(a({}, e.attributes), n)); return z(s, $()); }), "getIconSVG");
export { rt as a, qt as b, Rt as c, Lt as d };
