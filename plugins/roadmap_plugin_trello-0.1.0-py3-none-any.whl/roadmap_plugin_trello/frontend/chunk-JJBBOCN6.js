import { a as e, b as t, c as a, d as o, e as i, g as s, l as u, x as d, y as l } from "@nf-internal/chunk-EPGORQP5";
var f = class extends l {
    static { e(this, "InfoTokenBuilder"); }
    constructor() { super(["info", "showInfo"]); }
}, m = { parser: { TokenBuilder: e(() => new f, "TokenBuilder"), ValueConverter: e(() => new d, "ValueConverter") } };
function v(c = i) { let r = o(a(c), s), n = o(t({ shared: r }), u, m); return r.ServiceRegistry.register(n), { shared: r, Info: n }; }
e(v, "createInfoServices");
export { m as a, v as b };
