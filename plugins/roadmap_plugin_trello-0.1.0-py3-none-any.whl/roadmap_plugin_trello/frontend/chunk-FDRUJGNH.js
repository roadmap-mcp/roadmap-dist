import { a as ct } from "@nf-internal/chunk-2MBYSHM6";
import { A as E, D as hr, N, h as nr, l as dr } from "@nf-internal/chunk-LEJRRF65";
import { $ as zr, G as br, J as Ar, K as wr, L as Or, M as Br, N as Sr, O as Ir, P as Pr, Q as Mr, R as Wr, S as Er, T as Lr, U as Dr, V as $r, W as Rr, X as Nr, Y as Fr, Z as jr, _ as Tr, b as w, h as xr } from "@nf-internal/chunk-RZWXGGKD";
import { a } from "@nf-internal/chunk-YUSHYV7C";
import { a as or, e as pt } from "@nf-internal/chunk-OSQMNGTH";
function h(r) { return r == null || typeof r != "object" && typeof r != "function"; }
function d(r) { return r == null ? r === void 0 ? "[object Undefined]" : "[object Null]" : Object.prototype.toString.call(r); }
var F = "[object RegExp]", O = "[object String]", B = "[object Number]", S = "[object Boolean]", I = "[object Arguments]", j = "[object Symbol]", T = "[object Date]", z = "[object Map]", _ = "[object Set]", v = "[object Array]";
var U = "[object ArrayBuffer]", k = "[object Object]";
var H = "[object DataView]", q = "[object Uint8Array]", K = "[object Uint8ClampedArray]", V = "[object Uint16Array]", X = "[object Uint32Array]";
var Y = "[object Int8Array]", G = "[object Int16Array]", J = "[object Int32Array]";
var Z = "[object Float32Array]", Q = "[object Float64Array]";
function _r(r) { return Array.isArray(r); }
function P(r) { return ArrayBuffer.isView(r) && !(r instanceof DataView); }
function x(r) { return P(r); }
function ut(r) { if (h(r))
    return r; let t = d(r); if (!yt(r))
    return {}; if (_r(r)) {
    let e = Array.from(r);
    return r.length > 0 && typeof r[0] == "string" && Object.hasOwn(r, "index") && (e.index = r.index, e.input = r.input), e;
} if (x(r)) {
    let e = r, n = e.constructor;
    return new n(e.buffer, e.byteOffset, e.length);
} if (t === "[object ArrayBuffer]")
    return new ArrayBuffer(r.byteLength); if (t === "[object DataView]") {
    let e = r, n = e.buffer, m = e.byteOffset, o = e.byteLength, f = new ArrayBuffer(o), s = new Uint8Array(n, m, o);
    return new Uint8Array(f).set(s), new DataView(f);
} if (t === "[object Boolean]" || t === "[object Number]" || t === "[object String]") {
    let e = r.constructor, n = new e(r.valueOf());
    return t === "[object String]" ? gt(n, r) : mr(n, r), n;
} if (t === "[object Date]")
    return new Date(Number(r)); if (t === "[object RegExp]") {
    let e = r, n = new RegExp(e.source, e.flags);
    return n.lastIndex = e.lastIndex, n;
} if (t === "[object Symbol]")
    return Object(Symbol.prototype.valueOf.call(r)); if (t === "[object Map]") {
    let e = r, n = new Map;
    return e.forEach((m, o) => { n.set(o, m); }), n;
} if (t === "[object Set]") {
    let e = r, n = new Set;
    return e.forEach(m => { n.add(m); }), n;
} if (t === "[object Arguments]") {
    let e = r, n = {};
    return mr(n, e), n.length = e.length, n[Symbol.iterator] = e[Symbol.iterator], n;
} let i = {}; return dt(i, r), mr(i, r), lt(i, r), i; }
function yt(r) { switch (d(r)) {
    case I:
    case v:
    case U:
    case H:
    case S:
    case T:
    case Z:
    case Q:
    case Y:
    case G:
    case J:
    case z:
    case B:
    case k:
    case F:
    case _:
    case O:
    case j:
    case q:
    case K:
    case V:
    case X: return !0;
    default: return !1;
} }
function mr(r, t) { for (let i in t)
    Object.hasOwn(t, i) && (r[i] = t[i]); }
function lt(r, t) { let i = Object.getOwnPropertySymbols(t); for (let e = 0; e < i.length; e++) {
    let n = i[e];
    Object.prototype.propertyIsEnumerable.call(t, n) && (r[n] = t[n]);
} }
function gt(r, t) { let i = t.valueOf().length; for (let e in t)
    Object.hasOwn(t, e) && (Number.isNaN(Number(e)) || Number(e) >= i) && (r[e] = t[e]); }
function dt(r, t) { let i = Object.getPrototypeOf(t); i !== null && typeof t.constructor == "function" && Object.setPrototypeOf(r, i); }
var fr = typeof globalThis == "object" && globalThis || typeof window == "object" && window || typeof self == "object" && self || typeof global == "object" && global || (function () { return this; })();
function M(r) { return typeof fr.Buffer < "u" && fr.Buffer.isBuffer(r); }
function vr(r) { return Number.isSafeInteger(r) && r >= 0; }
function C(r) { return r != null && typeof r != "function" && vr(r.length); }
function L(r) { return r !== null && typeof r == "object" && d(r) === "[object Arguments]"; }
function Ur(r) { let t = r?.constructor; return r === (typeof t == "function" ? t.prototype : Object.prototype); }
function ht(r) { if (r == null)
    return !0; if (C(r))
    return typeof r.splice != "function" && typeof r != "string" && !M(r) && !x(r) && !L(r) ? !1 : r.length === 0; if (typeof r == "object" || typeof r == "function") {
    if (r instanceof Map || r instanceof Set)
        return r.size === 0;
    let t = Object.keys(r);
    return Ur(r) ? t.filter(i => i !== "constructor").length === 0 : t.length === 0;
} return !0; }
function rr(r) { if (typeof r != "object" || r == null)
    return !1; if (Object.getPrototypeOf(r) === null)
    return !0; if (Object.prototype.toString.call(r) !== "[object Object]") {
    let i = r[Symbol.toStringTag];
    return i == null || !Object.getOwnPropertyDescriptor(r, Symbol.toStringTag)?.writable ? !1 : r.toString() === `[object ${i}]`;
} let t = r; for (; Object.getPrototypeOf(t) !== null;)
    t = Object.getPrototypeOf(t); return Object.getPrototypeOf(r) === t; }
function kr() { }
function tr(r) { return Object.getOwnPropertySymbols(r).filter(t => Object.prototype.propertyIsEnumerable.call(r, t)); }
function Hr(r) { return r === "__proto__"; }
function qr(r, t) { return W(r, void 0, r, new Map, t); }
function W(r, t, i, e = new Map, n = void 0) { let m = n?.(r, t, i, e); if (m !== void 0)
    return m; if (h(r))
    return r; if (e.has(r))
    return e.get(r); if (Array.isArray(r)) {
    let o = new Array(r.length);
    e.set(r, o);
    for (let f = 0; f < r.length; f++)
        o[f] = W(r[f], f, i, e, n);
    return Object.hasOwn(r, "index") && (o.index = r.index), Object.hasOwn(r, "input") && (o.input = r.input), o;
} if (r instanceof Date)
    return new Date(r.getTime()); if (r instanceof RegExp) {
    let o = new RegExp(r.source, r.flags);
    return o.lastIndex = r.lastIndex, o;
} if (r instanceof Map) {
    let o = new Map;
    e.set(r, o);
    for (let [f, s] of r)
        o.set(f, W(s, f, i, e, n));
    return o;
} if (r instanceof Set) {
    let o = new Set;
    e.set(r, o);
    for (let f of r)
        o.add(W(f, void 0, i, e, n));
    return o;
} if (M(r))
    return r.subarray(); if (P(r)) {
    let o = new (Object.getPrototypeOf(r)).constructor(r.length);
    e.set(r, o);
    for (let f = 0; f < r.length; f++)
        o[f] = W(r[f], f, i, e, n);
    return o;
} if (r instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && r instanceof SharedArrayBuffer)
    return r.slice(0); if (r instanceof DataView) {
    let o = new DataView(r.buffer.slice(0), r.byteOffset, r.byteLength);
    return e.set(r, o), u(o, r, i, e, n), o;
} if (typeof File < "u" && r instanceof File) {
    let o = new File([r], r.name, { type: r.type });
    return e.set(r, o), u(o, r, i, e, n), o;
} if (typeof Blob < "u" && r instanceof Blob) {
    let o = new Blob([r], { type: r.type });
    return e.set(r, o), u(o, r, i, e, n), o;
} if (r instanceof Error) {
    let o = structuredClone(r);
    return e.set(r, o), o.message = r.message, o.name = r.name, o.stack = r.stack, o.cause = r.cause, o.constructor = r.constructor, u(o, r, i, e, n), o;
} if (r instanceof Boolean) {
    let o = new Boolean(r.valueOf());
    return e.set(r, o), u(o, r, i, e, n), o;
} if (r instanceof Number) {
    let o = new Number(r.valueOf());
    return e.set(r, o), u(o, r, i, e, n), o;
} if (r instanceof String) {
    let o = new String(r.valueOf());
    return e.set(r, o), u(o, r, i, e, n), o;
} if (typeof r == "object" && xt(r)) {
    let o = Object.create(Object.getPrototypeOf(r));
    return e.set(r, o), u(o, r, i, e, n), o;
} return r; }
function u(r, t, i = r, e, n) { let m = [...Object.keys(t), ...tr(t)]; for (let o = 0; o < m.length; o++) {
    let f = m[o], s = Object.getOwnPropertyDescriptor(r, f);
    (s == null || s.writable) && (r[f] = W(t[f], f, i, e, n));
} }
function xt(r) { switch (d(r)) {
    case I:
    case v:
    case U:
    case H:
    case S:
    case T:
    case Z:
    case Q:
    case Y:
    case G:
    case J:
    case z:
    case B:
    case k:
    case F:
    case _:
    case O:
    case j:
    case q:
    case K:
    case V:
    case X: return !0;
    default: return !1;
} }
function Kr(r, t) { return qr(r, (i, e, n, m) => { let o = t?.(i, e, n, m); if (o !== void 0)
    return o; if (typeof r == "object") {
    if (d(r) === "[object Object]" && typeof r.constructor != "function") {
        let f = {};
        return m.set(r, f), u(f, r, n, m), f;
    }
    switch (Object.prototype.toString.call(r)) {
        case B:
        case O:
        case S: {
            let f = new r.constructor(r?.valueOf());
            return u(f, r), f;
        }
        case I: {
            let f = {};
            return u(f, r), f.length = r.length, f[Symbol.iterator] = r[Symbol.iterator], f;
        }
        default: return;
    }
} }); }
function sr(r) { return Kr(r); }
function D(r) { return typeof r == "object" && r !== null; }
function Vr(r) { return D(r) && C(r); }
function b(r, t) { if (typeof r != "function" || t != null && typeof t != "function")
    throw new TypeError("Expected a function"); let i = function (...e) { let n = t ? t.apply(this, e) : e[0], m = i.cache; if (m.has(n))
    return m.get(n); let o = r.apply(this, e); return i.cache = m.set(n, o) || m, o; }; return i.cache = new (b.Cache || Map), i; }
b.Cache = Map;
function Xr(r) { if (h(r))
    return r; if (Array.isArray(r) || P(r) || r instanceof ArrayBuffer || typeof SharedArrayBuffer < "u" && r instanceof SharedArrayBuffer)
    return r.slice(0); let t = Object.getPrototypeOf(r); if (t == null)
    return Object.assign(Object.create(t), r); let i = t.constructor; if (r instanceof Date || r instanceof Map || r instanceof Set)
    return new i(r); if (r instanceof RegExp) {
    let e = new i(r);
    return e.lastIndex = r.lastIndex, e;
} if (r instanceof DataView)
    return new i(r.buffer.slice(0)); if (r instanceof Error) {
    let e;
    return r instanceof AggregateError ? e = new i(r.errors, r.message, { cause: r.cause }) : e = new i(r.message, { cause: r.cause }), e.stack = r.stack, Object.assign(e, r), e;
} return typeof File < "u" && r instanceof File ? new i([r], r.name, { type: r.type, lastModified: r.lastModified }) : typeof r == "object" ? Object.assign(Object.create(t), r) : r; }
function Yr(r, ...t) { let i = t.slice(0, -1), e = t[t.length - 1], n = r; for (let m = 0; m < i.length; m++) {
    let o = i[m];
    n = er(n, o, e, new Map);
} return n; }
function er(r, t, i, e) { if (h(r) && (r = Object(r)), t == null || typeof t != "object")
    return r; if (e.has(t))
    return Xr(e.get(t)); if (e.set(t, r), Array.isArray(t)) {
    t = t.slice();
    for (let m = 0; m < t.length; m++)
        m in t || (t[m] = void 0);
} let n = [...Object.keys(t), ...tr(t)]; for (let m = 0; m < n.length; m++) {
    let o = n[m];
    if (Hr(o))
        continue;
    let f = t[o], s = r[o];
    if (L(f) && (f = or({}, f)), L(s) && (s = or({}, s)), M(f) && (f = sr(f)), Array.isArray(f))
        if (Array.isArray(s)) {
            let y = [], c = Reflect.ownKeys(s);
            for (let g = 0; g < c.length; g++) {
                let l = c[g];
                y[l] = s[l];
            }
            s = y;
        }
        else if (Vr(s)) {
            let y = [];
            for (let c = 0; c < s.length; c++)
                y[c] = s[c];
            s = y;
        }
        else
            s = [];
    let p = i(s, f, o, r, t, e);
    p !== void 0 ? r[o] = p : Array.isArray(f) || D(s) && D(f) && (rr(s) || rr(f) || x(s) || x(f)) ? r[o] = er(s, f, i, e) : s == null && rr(f) ? r[o] = er({}, f, i, e) : s == null && x(f) ? r[o] = sr(f) : (s === void 0 || f !== void 0) && (r[o] = f);
} return r; }
function ar(r, ...t) { return Yr(r, ...t, kr); }
var Zr = pt(ct(), 1);
var bt = "\u200B", At = { curveBasis: Or, curveBasisClosed: Br, curveBasisOpen: Sr, curveBumpX: Ar, curveBumpY: wr, curveBundle: Ir, curveCardinalClosed: Mr, curveCardinalOpen: Wr, curveCardinal: Pr, curveCatmullRomClosed: Lr, curveCatmullRomOpen: Dr, curveCatmullRom: Er, curveLinear: br, curveLinearClosed: $r, curveMonotoneX: Rr, curveMonotoneY: Nr, curveNatural: Fr, curveStep: jr, curveStepAfter: zr, curveStepBefore: Tr }, wt = /\s*(?:(\w+)(?=:):|(\w+))\s*(?:(\w+)|((?:(?!}%{2}).|\r?\n)*))?\s*(?:}%{2})?/gi, Ot = a(function (r, t) { let i = Qr(r, /(?:init\b)|(?:initialize\b)/), e = {}; if (Array.isArray(i)) {
    let o = i.map(f => f.args);
    dr(o), e = nr(e, [...o]);
}
else
    e = i.args; if (!e)
    return; let n = hr(r, t), m = "config"; return e[m] !== void 0 && (n === "flowchart-v2" && (n = "flowchart"), e[n] = e[m], delete e[m]), e; }, "detectInit"), Qr = a(function (r, t = null) {
    try {
        let i = new RegExp(`[%]{2}(?![{]${wt.source})(?=[}][%]{2}).*
`, "ig");
        r = r.trim().replace(i, "").replace(/'/gm, '"'), w.debug(`Detecting diagram directive${t !== null ? " type:" + t : ""} based on the text:${r}`);
        let e, n = [];
        for (; (e = E.exec(r)) !== null;)
            if (e.index === E.lastIndex && E.lastIndex++, e && !t || t && e[1]?.match(t) || t && e[2]?.match(t)) {
                let m = e[1] ? e[1] : e[2], o = e[3] ? e[3].trim() : e[4] ? JSON.parse(e[4].trim()) : null;
                n.push({ type: m, args: o });
            }
        return n.length === 0 ? { type: r, args: null } : n.length === 1 ? n[0] : n;
    }
    catch (i) {
        return w.error(`ERROR: ${i.message} - Unable to parse directive type: '${t}' based on the text: '${r}'`), { type: void 0, args: null };
    }
}, "detectDirective"), si = a(function (r) { return r.replace(E, ""); }, "removeDirectives"), Bt = a(function (r, t) { for (let [i, e] of t.entries())
    if (e.match(r))
        return i; return -1; }, "isSubstringInArray");
function Cr(r, t) { if (!r)
    return t; let i = `curve${r.charAt(0).toUpperCase() + r.slice(1)}`; return At[i] ?? t; }
a(Cr, "interpolateToCurve");
function rt(r, t) { let i = r.trim(); if (i)
    return t.securityLevel !== "loose" ? (0, Zr.sanitizeUrl)(i) : i; }
a(rt, "formatUrl");
var St = a((r, ...t) => { let i = r.split("."), e = i.length - 1, n = i[e], m = window; for (let o = 0; o < e; o++)
    if (m = m[i[o]], !m) {
        w.error(`Function name: ${r} not found in window`);
        return;
    } m[n](...t); }, "runFunc");
function pr(r, t) { return !r || !t ? 0 : Math.sqrt(Math.pow(t.x - r.x, 2) + Math.pow(t.y - r.y, 2)); }
a(pr, "distance");
function tt(r) { let t, i = 0; r.forEach(n => { i += pr(n, t), t = n; }); let e = i / 2; return cr(r, e); }
a(tt, "traverseEdge");
function et(r) { return r.length === 1 ? r[0] : tt(r); }
a(et, "calcLabelPosition");
var Gr = a((r, t = 2) => { let i = Math.pow(10, t); return Math.round(r * i) / i; }, "roundNumber"), cr = a((r, t) => { let i, e = t; for (let n of r) {
    if (i) {
        let m = pr(n, i);
        if (m === 0)
            return i;
        if (m < e)
            e -= m;
        else {
            let o = e / m;
            if (o <= 0)
                return i;
            if (o >= 1)
                return { x: n.x, y: n.y };
            if (o > 0 && o < 1)
                return { x: Gr((1 - o) * i.x + o * n.x, 5), y: Gr((1 - o) * i.y + o * n.y, 5) };
        }
    }
    i = n;
} throw new Error("Could not find a suitable point for the given distance"); }, "calculatePoint"), It = a((r, t, i) => { w.info(`our points ${JSON.stringify(t)}`), t[0] !== i && (t = t.reverse()); let n = cr(t, 25), m = r ? 10 : 5, o = Math.atan2(t[0].y - n.y, t[0].x - n.x), f = { x: 0, y: 0 }; return f.x = Math.sin(o) * m + (t[0].x + n.x) / 2, f.y = -Math.cos(o) * m + (t[0].y + n.y) / 2, f; }, "calcCardinalityPosition");
function it(r, t, i) { let e = structuredClone(i); w.info("our points", e), t !== "start_left" && t !== "start_right" && e.reverse(); let n = 25 + r, m = cr(e, n), o = 10 + r * .5, f = Math.atan2(e[0].y - m.y, e[0].x - m.x), s = { x: 0, y: 0 }; return t === "start_left" ? (s.x = Math.sin(f + Math.PI) * o + (e[0].x + m.x) / 2, s.y = -Math.cos(f + Math.PI) * o + (e[0].y + m.y) / 2) : t === "end_right" ? (s.x = Math.sin(f - Math.PI) * o + (e[0].x + m.x) / 2 - 5, s.y = -Math.cos(f - Math.PI) * o + (e[0].y + m.y) / 2 - 5) : t === "end_left" ? (s.x = Math.sin(f) * o + (e[0].x + m.x) / 2 - 5, s.y = -Math.cos(f) * o + (e[0].y + m.y) / 2 - 5) : (s.x = Math.sin(f) * o + (e[0].x + m.x) / 2, s.y = -Math.cos(f) * o + (e[0].y + m.y) / 2), s; }
a(it, "calcTerminalLabelPosition");
function ot(r) { let t = "", i = ""; for (let e of r)
    e !== void 0 && (e.startsWith("color:") || e.startsWith("text-align:") ? i = i + e + ";" : t = t + e + ";"); return { style: t, labelStyle: i }; }
a(ot, "getStylesFromArray");
var Jr = 0, Pt = a(() => (Jr++, "id-" + Math.random().toString(36).substr(2, 12) + "-" + Jr), "generateId");
function nt(r) { let t = "", i = "0123456789abcdef", e = i.length; for (let n = 0; n < r; n++)
    t += i.charAt(Math.floor(Math.random() * e)); return t; }
a(nt, "makeRandomHex");
var Mt = a(r => nt(r.length), "random"), Wt = a(function () { return { x: 0, y: 0, fill: void 0, anchor: "start", style: "#666", width: 100, height: 100, textMargin: 0, rx: 0, ry: 0, valign: void 0, text: "" }; }, "getTextObj"), Et = a(function (r, t) { let i = t.text.replace(N.lineBreakRegex, " "), [, e] = yr(t.fontSize), n = r.append("text"); n.attr("x", t.x), n.attr("y", t.y), n.style("text-anchor", t.anchor), n.style("font-family", t.fontFamily), n.style("font-size", e), n.style("font-weight", t.fontWeight), n.attr("fill", t.fill), t.class !== void 0 && n.attr("class", t.class); let m = n.append("tspan"); return m.attr("x", t.x + t.textMargin * 2), m.attr("fill", t.fill), m.text(i), n; }, "drawSimpleText"), Lt = b((r, t, i) => { if (!r || (i = Object.assign({ fontSize: 12, fontWeight: 400, fontFamily: "Arial", joinWith: "<br/>" }, i), N.lineBreakRegex.test(r)))
    return r; let e = r.split(" ").filter(Boolean), n = [], m = ""; return e.forEach((o, f) => { let s = $(`${o} `, i), p = $(m, i); if (s > t) {
    let { hyphenatedStrings: g, remainingWord: l } = Dt(o, t, "-", i);
    n.push(m, ...g), m = l;
}
else
    p + s >= t ? (n.push(m), m = o) : m = [m, o].filter(Boolean).join(" "); f + 1 === e.length && n.push(m); }), n.filter(o => o !== "").join(i.joinWith); }, (r, t, i) => `${r}${t}${i.fontSize}${i.fontWeight}${i.fontFamily}${i.joinWith}`), Dt = b((r, t, i = "-", e) => { e = Object.assign({ fontSize: 12, fontWeight: 400, fontFamily: "Arial", margin: 0 }, e); let n = [...r], m = [], o = ""; return n.forEach((f, s) => { let p = `${o}${f}`; if ($(p, e) >= t) {
    let c = s + 1, g = n.length === c, l = `${p}${i}`;
    m.push(g ? p : l), o = "";
}
else
    o = p; }), { hyphenatedStrings: m, remainingWord: o }; }, (r, t, i = "-", e) => `${r}${t}${i}${e.fontSize}${e.fontWeight}${e.fontFamily}`);
function mt(r, t) { return ur(r, t).height; }
a(mt, "calculateTextHeight");
function $(r, t) { return ur(r, t).width; }
a($, "calculateTextWidth");
var ur = b((r, t) => { let { fontSize: i = 12, fontFamily: e = "Arial", fontWeight: n = 400 } = t; if (!r)
    return { width: 0, height: 0 }; let [, m] = yr(i), o = ["sans-serif", e], f = r.split(N.lineBreakRegex), s = [], p = xr("body"); if (!p.remove)
    return { width: 0, height: 0, lineHeight: 0 }; let y = p.append("svg"); for (let g of o) {
    let l = 0, A = { width: 0, height: 0, lineHeight: 0 };
    for (let at of f) {
        let lr = Wt();
        lr.text = at || bt;
        let gr = Et(y, lr).style("font-size", m).style("font-weight", n).style("font-family", g), R = (gr._groups || gr)[0][0].getBBox();
        if (R.width === 0 && R.height === 0)
            throw new Error("svg element not in render tree");
        A.width = Math.round(Math.max(A.width, R.width)), l = Math.round(R.height), A.height += l, A.lineHeight = Math.round(Math.max(A.lineHeight, l));
    }
    s.push(A);
} y.remove(); let c = isNaN(s[1].height) || isNaN(s[1].width) || isNaN(s[1].lineHeight) || s[0].height > s[1].height && s[0].width > s[1].width && s[0].lineHeight > s[1].lineHeight ? 0 : 1; return s[c]; }, (r, t) => `${r}${t.fontSize}${t.fontWeight}${t.fontFamily}`), $t = class {
    constructor(r = !1, t) { this.count = 0, this.count = t ? t.length : 0, this.next = r ? () => this.count++ : () => Date.now(); }
    static { a(this, "InitIDGenerator"); }
}, ir, Rt = a(function (r) { return ir = ir || document.createElement("div"), r = escape(r).replace(/%26/g, "&").replace(/%23/g, "#").replace(/%3B/g, ";"), ir.innerHTML = r, unescape(ir.textContent); }, "entityDecode");
function Nt(r) { return "str" in r; }
a(Nt, "isDetailedError");
var Ft = a((r, t, i, e) => { if (!e)
    return; let n = r.node()?.getBBox(); n && r.append("text").text(e).attr("text-anchor", "middle").attr("x", n.x + n.width / 2).attr("y", -i).attr("class", t); }, "insertTitle"), yr = a(r => { if (typeof r == "number")
    return [r, r + "px"]; let t = parseInt(r ?? "", 10); return Number.isNaN(t) ? [void 0, void 0] : r === String(t) ? [t, r + "px"] : [t, r]; }, "parseFontSize");
function ft(r, t) { return ar({}, r, t); }
a(ft, "cleanAndMerge");
var ai = { assignWithDepth: nr, wrapLabel: Lt, calculateTextHeight: mt, calculateTextWidth: $, calculateTextDimensions: ur, cleanAndMerge: ft, detectInit: Ot, detectDirective: Qr, isSubstringInArray: Bt, interpolateToCurve: Cr, calcLabelPosition: et, calcCardinalityPosition: It, calcTerminalLabelPosition: it, formatUrl: rt, getStylesFromArray: ot, generateId: Pt, random: Mt, runFunc: St, entityDecode: Rt, insertTitle: Ft, isLabelCoordinateInPath: st, parseFontSize: yr, InitIDGenerator: $t }, pi = a(function (r) { let t = r; return t = t.replace(/style.*:\S*#.*;/g, function (i) { return i.substring(0, i.length - 1); }), t = t.replace(/classDef.*:\S*#.*;/g, function (i) { return i.substring(0, i.length - 1); }), t = t.replace(/#\w+;/g, function (i) { let e = i.substring(1, i.length - 1); return /^\+?\d+$/.test(e) ? "\uFB02\xB0\xB0" + e + "\xB6\xDF" : "\uFB02\xB0" + e + "\xB6\xDF"; }), t; }, "encodeEntities"), ci = a(function (r) { return r.replace(/ﬂ°°/g, "&#").replace(/ﬂ°/g, "&").replace(/¶ß/g, ";"); }, "decodeEntities"), ui = a((r, t, { counter: i = 0, prefix: e, suffix: n }, m) => m || `${e ? `${e}_` : ""}${r}_${t}_${i}${n ? `_${n}` : ""}`, "getEdgeId");
function jt(r) { return r ?? null; }
a(jt, "handleUndefinedAttr");
function st(r, t) { let i = Math.round(r.x), e = Math.round(r.y), n = t.replace(/(\d+\.\d+)/g, m => Math.round(parseFloat(m)).toString()); return n.includes(i.toString()) || n.includes(e.toString()); }
a(st, "isLabelCoordinateInPath");
export { ut as a, ht as b, bt as c, si as d, Cr as e, ot as f, Pt as g, Mt as h, Lt as i, mt as j, $ as k, ur as l, Nt as m, yr as n, ft as o, ai as p, pi as q, ci as r, ui as s, jt as t };
