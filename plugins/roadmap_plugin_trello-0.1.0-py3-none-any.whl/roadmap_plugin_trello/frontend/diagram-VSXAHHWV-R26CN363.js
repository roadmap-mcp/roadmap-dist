import { a as Y } from "@nf-internal/chunk-CDENLQJG";
import { a as K } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import { f as z } from "@nf-internal/chunk-EPGORQP5";
import { i as P, l as X, o as j } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { H as y, T as O, U as I, V as W, W as H, X as U, Y as _, Z as G, _ as F, ca as L, k as C, u as w } from "@nf-internal/chunk-LEJRRF65";
import { b as f, h as V } from "@nf-internal/chunk-RZWXGGKD";
import { a as o } from "@nf-internal/chunk-YUSHYV7C";
import { a as b, b as v, f as N } from "@nf-internal/chunk-OSQMNGTH";
var q = "position frame", J = "frame positioned", B = "position relation", Q = "relation positioned", Se = o(function (e) { f.debug("options str", e); }, "setOptions"), Me = o(function () { return {}; }, "getOptions"), ke = o(function () { Z(), O(); }, "clear");
function Z() { R = {}; }
o(Z, "reset");
var Fe = C.eventmodeling, Be = o(() => j(b(b({}, Fe), w().eventmodeling)), "getConfig"), R = {};
function ee() { let e = Ee, { ast: n } = R, t = T(); if (!n)
    throw new Error("No data for EventModel"); return n.frames.forEach((i, r) => { let a = se(i, n.dataEntities, t); e = M(e, { $kind: q, index: r, frame: i, textProps: a }); let d; xe(i) ? (f.debug("source frame", i.sourceFrames), d = n.frames.filter(l => i.sourceFrames.some(c => c.$refText === l.name)), d.forEach(l => { e = M(e, { $kind: B, index: r, frame: i, sourceFrame: l }); })) : e = M(e, { $kind: B, index: r, frame: i }); }), e = v(b({}, e), { sortedSwimlanesArray: $(e.swimlanes) }), e; }
o(ee, "getState");
function te(e) { R.ast = e; }
o(te, "setAst");
var s = { swimlaneMinHeight: 70, swimlanePadding: 15, swimlaneGap: 10, boxPadding: 10, boxOverlap: 90, boxDefaultY: 0, boxMinWidth: 80, boxMaxWidth: 450, boxMinHeight: 80, boxMaxHeight: 750, contentStartX: 250, textMaxWidth: 430, boxTextFontWeight: "bold", boxTextPadding: 10, swimlaneTextFontWeight: "bold", labelUiAutomation: "UI/Automation", labelUiAutomationPrefix: "UI/A: ", labelCommandReadModel: "Command/Read Model", labelCommandReadModelPrefix: "C/RM: ", labelEvents: "Events", labelEventsPrefix: "Stream: " };
function T() { return s; }
o(T, "getDiagramProps");
var Ee = { boxes: [], swimlanes: {}, relations: [], maxR: 0, sortedSwimlanesArray: [] };
function ne(e) { let n = e.split("."); if (n.length === 2)
    return n[0]; }
o(ne, "extractNamespace");
function ie(e) { let n = e.split("."); return n.length === 2 ? n[1] : e; }
o(ie, "extractName");
function re(e, n) { if (!(!n || n.length === 0))
    return Object.values(e).find(t => t.namespace === n); }
o(re, "findSwimlaneByNamespace");
function S(e, n, t) { return Math.max(n, ...Object.keys(e).filter(i => { let r = Number.parseInt(i); return r > n && r < t; }).map(i => Number.parseInt(i))) + 1; }
o(S, "findNextAvailableIndex");
function ae(e, n) { let t = ne(e.entityIdentifier), i = re(n, t); switch (e.modelEntityType) {
    case "ui":
    case "pcr":
    case "processor": return i ? { index: i.index, label: i.namespace || s.labelUiAutomation } : t ? { index: S(n, 0, 100), label: s.labelUiAutomationPrefix + t } : { index: 0, label: s.labelUiAutomation };
    case "rmo":
    case "readmodel":
    case "cmd":
    case "command": return i ? { index: i.index, label: i.namespace || s.labelCommandReadModel } : t ? { index: S(n, 100, 200), label: s.labelCommandReadModelPrefix + t } : { index: 100, label: s.labelCommandReadModel };
    default: return i ? { index: i.index, label: i.namespace || s.labelEvents } : t ? { index: S(n, 200, 300), label: s.labelEventsPrefix + t } : { index: 200, label: s.labelEvents };
} }
o(ae, "calculateSwimlaneProps");
function oe(e) { let { themeVariables: n } = w(); switch (e.modelEntityType) {
    case "ui": return { fill: n.emUiFill ?? "white", stroke: n.emUiStroke ?? "#dbdada" };
    case "pcr":
    case "processor": return { fill: n.emProcessorFill ?? "#edb3f6", stroke: n.emProcessorStroke ?? "#b88cbf" };
    case "rmo":
    case "readmodel": return { fill: n.emReadModelFill ?? "#d3f1a2", stroke: n.emReadModelStroke ?? "#a3b732" };
    case "cmd":
    case "command": return { fill: n.emCommandFill ?? "#bcd6fe", stroke: n.emCommandStroke ?? "#679ac3" };
    case "evt":
    case "event": return { fill: n.emEventFill ?? "#ffb778", stroke: n.emEventStroke ?? "#c19a0f" };
    default: return { fill: "red", stroke: "black" };
} }
o(oe, "calculateEntityVisualProps");
function se(e, n, t) {
    let i = w(), r = y(ie(e.entityIdentifier) ?? "", i), a, d = { fontSize: 16, fontWeight: 700, fontFamily: '"trebuchet ms", verdana, arial, sans-serif', joinWith: "<br/>" }, c = `<b>${P(r, t.textMaxWidth, d)}</b>`;
    if (e.dataInlineValue && (a = e.dataInlineValue, a = a.substring(a.indexOf("{") + 1), a = a.substring(0, a.lastIndexOf("}") - 1), a = y(a, i), a = P(a, t.textMaxWidth, d), a = a.replaceAll(" ", "&nbsp;")), e.dataReference) {
        let p = n.find(k => k.name === e.dataReference?.$refText);
        p && (a = p.dataBlockValue, a = a.substring(a.indexOf(`{
`) + 2), a = a.substring(0, a.lastIndexOf("}") - 1), a = y(a, i), a = P(a, t.textMaxWidth, d), a = a.replaceAll(" ", "&nbsp;"), a += "<br/>");
    }
    let m = a !== void 0;
    m && (c += `<br/><br/><code style="text-align: left; display: block;max-width:${t.textMaxWidth}px">${a}</code>`);
    let x = { fontSize: d.fontSize, fontWeight: d.fontWeight, fontFamily: d.fontFamily }, u = X(c, x), h = m ? u.width / 3 : u.width, g = { content: c, width: h, height: u.height };
    return f.debug(`[${e.name}] ${e.entityIdentifier} text`, g), g;
}
o(se, "calculateTextProps");
function de(e, n) { let t = n, i = oe(t.frame), r = { width: t.textProps.width + 2 * s.boxTextPadding, height: t.textProps.height + 2 * s.boxTextPadding }; return [{ $kind: J, frame: t.frame, index: t.index, visual: i, dimension: r, textProps: t.textProps }]; }
o(de, "decidePositionFrame");
function le(e, n, t) { return n === void 0 ? s.contentStartX : n.index === e.index && e.r ? e.r + s.boxPadding : t === void 0 ? s.contentStartX : t.r - s.boxOverlap + s.boxPadding; }
o(le, "calculateX");
function ce(e, n) { let t = [...e.map(i => i.r), n]; return Math.max(...t); }
o(ce, "calculateMaxRight");
function $(e) { return Object.values(e).sort((n, t) => n.index - t.index); }
o($, "sortedSwimlanesArray");
function me(e, n) { let t = n, i = ae(t.frame, e.swimlanes), r; i.index in e.swimlanes ? r = e.swimlanes[i.index] : r = { index: i.index, label: i.label, r: 0, y: i.index * s.swimlaneMinHeight + s.swimlaneGap, height: s.swimlaneMinHeight, maxHeight: s.swimlaneMinHeight }; let a = e.boxes.length > 0 ? e.boxes[e.boxes.length - 1] : void 0, d = e.previousSwimlaneNumber !== void 0 ? e.swimlanes[e.previousSwimlaneNumber] : void 0, l = { width: Math.max(s.boxMinWidth, Math.min(s.boxMaxWidth, t.dimension.width)) + 2 * s.boxPadding, height: Math.max(s.boxMinHeight, Math.min(s.boxMaxHeight, t.dimension.height)) + 2 * s.boxPadding }, c = le(r, d, a), m = c + l.width + s.boxPadding, x = ce(Object.values(e.swimlanes), m); r.r = c + l.width, r.maxHeight = Math.max(r.maxHeight, l.height), r.height = Math.max(s.swimlaneMinHeight, r.maxHeight) + 2 * s.swimlanePadding; let u = { x: c, y: s.swimlanePadding + r.y, r: m, dimension: l, leftSibling: !1, swimlane: r, visual: t.visual, text: t.textProps.content, frame: t.frame, index: t.index }, h = v(b({}, e), { boxes: [...e.boxes, u], swimlanes: v(b({}, e.swimlanes), { [`${r.index}`]: r }), previousSwimlaneNumber: i.index, previousFrame: t.frame, maxR: x }), g = $(h.swimlanes); g.length > 0 && (g[0].y = 0); for (let p = 1; p < g.length; p++) {
    let k = g[p], D = g[p - 1];
    k.y = D.y + D.height + s.swimlaneGap;
} return h; }
o(me, "evolveFramePositioned");
function ue(e, n) { return e === 0 && n.sourceFrames.length === 0; }
o(ue, "isFirstFrame");
function xe(e) { return e.sourceFrames !== void 0 && e.sourceFrames !== null && e.sourceFrames.length > 0; }
o(xe, "hasSourceFrame");
function E(e, n) { if (n != null)
    return e.find(t => t.frame.name === n.name); }
o(E, "findBoxByFrame");
function fe(e, n, t) { if (!(t < 0))
    for (let i = t; i >= 0; i--) {
        let r = e[i];
        if (r.swimlane.index !== n)
            return r;
    } }
o(fe, "findBoxByLineIndex");
function ge(e, n) { let t = n; if (z(t.frame) || ue(t.index, t.frame))
    return []; let i = E(e.boxes, t.frame); if (i === void 0)
    throw new Error(`Target box not found for frame ${t.frame.name}`); let r; return t.sourceFrame ? r = E(e.boxes, t.sourceFrame) : r = fe(e.boxes, i.swimlane.index, t.index - 1), r === void 0 ? [] : [{ $kind: Q, frame: t.frame, index: t.index, sourceBox: r, targetBox: i }]; }
o(ge, "decidePositionRelation");
function he(e, n) { let t = n, i = { visual: { fill: "none", stroke: "#000" }, source: { x: t.sourceBox.x, y: t.sourceBox.y }, target: { x: t.targetBox.x, y: t.targetBox.y }, sourceBox: t.sourceBox, targetBox: t.targetBox }; return v(b({}, e), { relations: [...e.relations, i] }); }
o(he, "evolveRelationPositioned");
var Ae = { [q]: de, [B]: ge }, Re = { [J]: me, [Q]: he };
function pe(e, n) { let t = Ae[n.$kind]; if (t == null)
    return []; let i = t(e, n); return f.debug("decided events", i), i; }
o(pe, "decide");
function be(e, n) { let t = n.reduce((i, r) => { let a = Re[r.$kind]; return a == null ? i : a(i, r); }, e); return f.debug("evolve events", { state: e, newState: t, events: n }), t; }
o(be, "evolve");
function M(e, n) { let t = pe(e, n); return be(e, t); }
o(M, "dispatch");
var A = { getConfig: Be, setOptions: Se, getOptions: Me, clear: ke, setAccTitle: I, getAccTitle: W, getAccDescription: U, setAccDescription: H, setDiagramTitle: _, getDiagramTitle: G, setAst: te, getDiagramProps: T, getState: ee }, Te = { parse: o(e => N(null, null, function* () { let n = yield K("eventmodeling", e); f.debug(n), A.setAst(n), Y(n, A); }), "parse") }, $e = F(), De = $e?.eventmodeling;
function ve(e, n) { return t => { let i = t.swimlane.y + n.swimlanePadding, r = e.append("g").attr("class", "em-box"); r.append("rect").attr("x", t.x).attr("y", i).attr("rx", "3").attr("width", t.dimension.width).attr("height", t.dimension.height).attr("stroke", t.visual.stroke).attr("fill", t.visual.fill), r.append("foreignObject").attr("x", t.x + n.boxPadding).attr("y", i + 10).attr("width", t.dimension.width - 2 * n.boxPadding).attr("height", t.dimension.height - 2 * n.boxPadding).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%").append("span").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").html(t.text); }; }
o(ve, "renderD3Box");
function we(e, n) { return e > n; }
o(we, "dirUpwards");
function ye(e, n, t, i) { return r => { let a = r.sourceBox.swimlane.y + n.swimlanePadding, d = r.targetBox.swimlane.y + n.swimlanePadding, l = we(a, d), c = r.sourceBox.x + r.sourceBox.dimension.width * 2 / 3, m = r.targetBox.x + r.targetBox.dimension.width / 3, x, u; f.debug(`rendering relation up=${l} for `, { sourceBox: r.sourceBox, targetBox: r.targetBox }), l ? (x = a, u = d + r.targetBox.dimension.height) : (x = a + r.sourceBox.dimension.height, u = d); let h = i.emRelationStroke ?? r.visual.stroke; e.append("path").attr("class", "em-relation").attr("fill", r.visual.fill).attr("stroke", h).attr("stroke-width", "1").attr("marker-end", `url(#${t})`).attr("d", `M${c} ${x} L${m} ${u}`); }; }
o(ye, "renderD3Relation");
function Pe(e, n, t, i) { return r => { let a = e.append("g").attr("class", "em-swimlane"), d = i.emSwimlaneBackgroundOdd ?? "rgb(250,250,250)", l = i.emSwimlaneBackgroundStroke ?? "rgb(240,240,240)"; a.append("rect").attr("x", 0).attr("y", r.y).attr("rx", "3").attr("width", n + t.swimlanePadding).attr("height", r.height).attr("fill", d).attr("stroke", l), a.append("text").attr("font-weight", t.swimlaneTextFontWeight).attr("x", 30).attr("y", r.y + 30).text(r.label); }; }
o(Pe, "renderD3Swimlane");
var Ne = o(function (e, n, t, i) {
    if (f.debug("in eventmodeling renderer", e + `
`, "id:", n, t), !De)
        throw new Error("EventModeling config not found");
    let r = i.db, { themeVariables: a, eventmodeling: d } = F(), l = V(`[id="${n}"]`), c = r.getDiagramProps(), m = r.getState(), x = `em-arrowhead-${n}`, u = a.emArrowhead ?? "#000000";
    m.sortedSwimlanesArray.forEach(Pe(l, m.maxR, c, a)), m.boxes.forEach(ve(l, c)), m.relations.forEach(ye(l, c, x, a)), l.append("defs").append("marker").attr("id", x).attr("markerWidth", "10").attr("markerHeight", "7").attr("refX", "10").attr("refY", "3.5").attr("orient", "auto").append("polygon").attr("points", "0 0, 10 3.5, 0 7").attr("fill", u), L(void 0, l, d?.padding ?? 30, d?.useMaxWidth);
}, "draw"), Ce = { draw: Ne }, Oe = o(e => "", "getStyles"), Ie = Oe, je = { parser: Te, db: A, renderer: Ce, styles: Ie };
export { je as diagram };
