import { a as l } from "@nf-internal/chunk-JE6VEUSL";
import { a as s, b as i, c as u } from "@nf-internal/chunk-MQ6KVUBG";
import { a as f } from "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-OSQMNGTH";
import "@angular/core";
function p(r) { return r != null && `${r}` != "false"; }
function a(r, t = /\s+/) { let e = []; if (r != null) {
    let c = Array.isArray(r) ? r : `${r}`.split(t);
    for (let n of c) {
        let o = `${n}`.trim();
        o && e.push(o);
    }
} return e; }
export { i as _isNumberValue, f as coerceArray, p as coerceBooleanProperty, l as coerceCssPixelValue, u as coerceElement, s as coerceNumberProperty, a as coerceStringArray };
