import { a as ft } from "@nf-internal/chunk-CDENLQJG";
import { a as ht } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import { a as pt } from "@nf-internal/chunk-YQ6X4GJP";
import { o as Z } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { O as rt, T as ot, U as nt, V as st, W as it, X as dt, Y as lt, Z as ct, _ as G, i as et, u as at } from "@nf-internal/chunk-LEJRRF65";
import { b as _ } from "@nf-internal/chunk-RZWXGGKD";
import { a as u } from "@nf-internal/chunk-YUSHYV7C";
import { a as E, b as Q, f as tt } from "@nf-internal/chunk-OSQMNGTH";
var q = u((e, n) => { let r = e <= 1 ? e * 100 : e; if (r < 0 || r > 100)
    throw new Error(`${n} must be between 0-1 (decimal) or 0-100 (percentage). Received: ${e}`); return r; }, "toPercent"), A = u((e, n, r) => ({ x: q(n, `${r} evolution`), y: q(e, `${r} visibility`) }), "toCoordinates"), xt = u(e => { if (e) {
    if (e === "+<>")
        return "bidirectional";
    if (e === "+<")
        return "backward";
    if (e === "+>")
        return "forward";
} }, "getFlowFromPort"), Dt = u(e => { if (!e?.startsWith("+"))
    return {}; let r = /^\+'([^']*)'/.exec(e)?.[1]; return e.includes("<>") ? { flow: "bidirectional", label: r } : e.includes("<") ? { flow: "backward", label: r } : e.includes(">") ? { flow: "forward", label: r } : { label: r }; }, "extractFlowFromArrow"), Gt = u((e, n) => { if (ft(e, n), e.size && n.setSize(e.size.width, e.size.height), e.evolution) {
    let r = e.evolution.stages.map(a => a.secondName ? `${a.name.trim()} / ${a.secondName.trim()}` : a.name.trim()), x = e.evolution.stages.filter(a => a.boundary !== void 0).map(a => a.boundary);
    n.updateAxes({ stages: r, stageBoundaries: x });
} if (e.anchors.forEach(r => { let x = A(r.visibility, r.evolution, `Anchor "${r.name}"`); n.addNode(r.name, r.name, x.x, x.y, "anchor"); }), e.components.forEach(r => { let x = A(r.visibility, r.evolution, `Component "${r.name}"`), a = r.label ? (r.label.negX ? -1 : 1) * r.label.offsetX : void 0, d = r.label ? (r.label.negY ? -1 : 1) * r.label.offsetY : void 0, m = r.decorator?.strategy; n.addNode(r.name, r.name, x.x, x.y, "component", a, d, r.inertia, m); }), e.notes.forEach(r => { let x = A(r.visibility, r.evolution, `Note "${r.text}"`); n.addNote(r.text, x.x, x.y); }), e.pipelines.forEach(r => { let x = n.getNode(r.parent); if (!x || typeof x.y != "number")
    throw new Error(`Pipeline "${r.parent}" must reference an existing component with coordinates.`); let a = x.y; n.startPipeline(r.parent), r.components.forEach(d => { let m = `${r.parent}_${d.name}`, C = d.label ? (d.label.negX ? -1 : 1) * d.label.offsetX : void 0, g = d.label ? (d.label.negY ? -1 : 1) * d.label.offsetY : void 0, R = q(d.evolution, `Pipeline component "${d.name}" evolution`); n.addNode(m, d.name, R, a, "pipeline-component", C, g), n.addPipelineComponent(r.parent, m); }); }), e.links.forEach(r => { let x = !!r.arrow && (r.arrow.includes("-.->") || r.arrow.includes(".-.")), a = xt(r.fromPort) ?? xt(r.toPort), { flow: d, label: m } = Dt(r.arrow); !a && d && (a = d); let C = r.linkLabel, g = m ?? C; n.addLink(n.resolveNodeId(r.from), n.resolveNodeId(r.to), x, g, a); }), e.evolves.forEach(r => { let x = n.getNode(r.component); if (x?.y !== void 0) {
    let a = q(r.target, `Evolve target for "${r.component}"`);
    n.addTrend(r.component, a, x.y);
} }), e.annotations.length > 0) {
    let r = e.annotations[0], x = A(r.x, r.y, "Annotations box");
    n.setAnnotationsBox(x.x, x.y);
} e.annotation.forEach(r => { let x = A(r.x, r.y, `Annotation ${r.number}`); n.addAnnotation(r.number, [{ x: x.x, y: x.y }], r.text); }), e.accelerators.forEach(r => { let x = A(r.x, r.y, `Accelerator "${r.name}"`); n.addAccelerator(r.name, x.x, x.y); }), e.deaccelerators.forEach(r => { let x = A(r.x, r.y, `Deaccelerator "${r.name}"`); n.addDeaccelerator(r.name, x.x, x.y); }); }, "populateDb"), gt = { parser: { yy: void 0 }, parse: u(e => tt(null, null, function* () { let n = yield ht("wardley", e); _.debug(n); let r = gt.parser?.yy; if (!r || typeof r.addNode != "function")
        throw new Error("parser.parser?.yy was not a WardleyDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues."); Gt(n, r); }), "parse") }, qt = class {
    constructor() { this.nodes = new Map, this.links = [], this.trends = new Map, this.pipelines = new Map, this.annotations = [], this.notes = [], this.accelerators = [], this.deaccelerators = [], this.axes = {}; }
    static { u(this, "WardleyBuilder"); }
    addNode(e) { let n = this.nodes.get(e.id) ?? { id: e.id, label: e.label }, r = Q(E(E({}, n), e), { className: e.className ?? n.className, labelOffsetX: e.labelOffsetX ?? n.labelOffsetX, labelOffsetY: e.labelOffsetY ?? n.labelOffsetY }); this.nodes.set(e.id, r); }
    addLink(e) { this.links.push(e); }
    addTrend(e) { this.trends.set(e.nodeId, e); }
    startPipeline(e) { this.pipelines.set(e, { nodeId: e, componentIds: [] }); let n = this.nodes.get(e); n && (n.isPipelineParent = !0); }
    addPipelineComponent(e, n) { let r = this.pipelines.get(e); r && r.componentIds.push(n); let x = this.nodes.get(n); x && (x.inPipeline = !0); }
    addAnnotation(e) { this.annotations.push(e); }
    addNote(e) { this.notes.push(e); }
    addAccelerator(e) { this.accelerators.push(e); }
    addDeaccelerator(e) { this.deaccelerators.push(e); }
    setAnnotationsBox(e, n) { this.annotationsBox = { x: e, y: n }; }
    setAxes(e) { this.axes = E(E({}, this.axes), e); }
    setSize(e, n) { this.size = { width: e, height: n }; }
    getNode(e) { return this.nodes.get(e); }
    resolveNodeId(e) { if (this.nodes.has(e))
        return e; for (let [n, r] of this.nodes)
        if (r.label === e)
            return n; return e; }
    build() { let e = []; for (let n of this.nodes.values()) {
        if (typeof n.x != "number" || typeof n.y != "number")
            throw new Error(`Node "${n.label}" is missing coordinates`);
        e.push(n);
    } return { nodes: e, links: [...this.links], trends: [...this.trends.values()], pipelines: [...this.pipelines.values()], annotations: [...this.annotations], notes: [...this.notes], accelerators: [...this.accelerators], deaccelerators: [...this.deaccelerators], annotationsBox: this.annotationsBox, axes: E({}, this.axes), size: this.size }; }
    clear() { this.nodes.clear(), this.links = [], this.trends.clear(), this.pipelines.clear(), this.annotations = [], this.notes = [], this.accelerators = [], this.deaccelerators = [], this.annotationsBox = void 0, this.axes = {}, this.size = void 0; }
}, k = new qt;
function yt() { return G()["wardley-beta"]; }
u(yt, "getConfig");
function ut(e, n, r, x, a, d, m, C, g) { k.addNode({ id: e, label: n, x: r, y: x, className: a, labelOffsetX: d, labelOffsetY: m, inertia: C, sourceStrategy: g }); }
u(ut, "addNode");
function mt(e, n, r = !1, x, a) { k.addLink({ source: e, target: n, dashed: r, label: x, flow: a }); }
u(mt, "addLink");
function wt(e, n, r) { k.addTrend({ nodeId: e, targetX: n, targetY: r }); }
u(wt, "addTrend");
function kt(e, n, r) { k.addAnnotation({ number: e, coordinates: n, text: r }); }
u(kt, "addAnnotation");
function bt(e, n, r) { k.addNote({ text: e, x: n, y: r }); }
u(bt, "addNote");
function $t(e, n, r) { k.addAccelerator({ name: e, x: n, y: r }); }
u($t, "addAccelerator");
function vt(e, n, r) { k.addDeaccelerator({ name: e, x: n, y: r }); }
u(vt, "addDeaccelerator");
function Pt(e, n) { k.setAnnotationsBox(e, n); }
u(Pt, "setAnnotationsBox");
function Ct(e, n) { k.setSize(e, n); }
u(Ct, "setSize");
function St(e) { k.startPipeline(e); }
u(St, "startPipeline");
function Mt(e, n) { k.addPipelineComponent(e, n); }
u(Mt, "addPipelineComponent");
function Nt(e) { k.setAxes(e); }
u(Nt, "updateAxes");
function zt(e) { return k.getNode(e); }
u(zt, "getNode");
function Lt(e) { return k.resolveNodeId(e); }
u(Lt, "resolveNodeId");
function Tt() { return k.build(); }
u(Tt, "getWardleyData");
function At() { k.clear(), ot(); }
u(At, "clear");
var Ht = { getConfig: yt, addNode: ut, addLink: mt, addTrend: wt, addAnnotation: kt, addNote: bt, addAccelerator: $t, addDeaccelerator: vt, setAnnotationsBox: Pt, setSize: Ct, startPipeline: St, addPipelineComponent: Mt, updateAxes: Nt, getNode: zt, resolveNodeId: Lt, getWardleyData: Tt, clear: At, setAccTitle: nt, getAccTitle: st, setDiagramTitle: lt, getDiagramTitle: ct, getAccDescription: dt, setAccDescription: it }, jt = ["Genesis", "Custom Built", "Product", "Commodity"], Vt = u(() => { let { themeVariables: e } = G(); return { backgroundColor: e.wardley?.backgroundColor ?? e.background ?? "#fff", axisColor: e.wardley?.axisColor ?? "#000", axisTextColor: e.wardley?.axisTextColor ?? e.primaryTextColor ?? "#222", gridColor: e.wardley?.gridColor ?? "rgba(100, 100, 100, 0.2)", componentFill: e.wardley?.componentFill ?? "#fff", componentStroke: e.wardley?.componentStroke ?? "#000", componentLabelColor: e.wardley?.componentLabelColor ?? e.primaryTextColor ?? "#222", linkStroke: e.wardley?.linkStroke ?? "#000", evolutionStroke: e.wardley?.evolutionStroke ?? "#dc3545", annotationStroke: e.wardley?.annotationStroke ?? "#000", annotationTextColor: e.wardley?.annotationTextColor ?? e.primaryTextColor ?? "#222", annotationFill: e.wardley?.annotationFill ?? e.background ?? "#fff" }; }, "getTheme"), _t = u(() => { let e = G()["wardley-beta"]; return { width: e?.width ?? 900, height: e?.height ?? 600, padding: e?.padding ?? 48, nodeRadius: e?.nodeRadius ?? 6, nodeLabelOffset: e?.nodeLabelOffset ?? 8, axisFontSize: e?.axisFontSize ?? 12, labelFontSize: e?.labelFontSize ?? 10, showGrid: e?.showGrid ?? !1, useMaxWidth: e?.useMaxWidth ?? !0 }; }, "getConfigValues"), Zt = u((e, n, r, x) => {
    _.debug(`Rendering Wardley map
` + e);
    let a = _t(), d = Vt(), m = a.nodeRadius * 1.6, C = x.db, g = C.getWardleyData(), R = C.getDiagramTitle(), S = g.size?.width ?? a.width, b = g.size?.height ?? a.height, Y = pt(n);
    Y.selectAll("*").remove(), rt(Y, b, S, a.useMaxWidth), Y.attr("viewBox", `0 0 ${S} ${b}`);
    let v = Y.append("g").attr("class", "wardley-map"), H = Y.append("defs");
    H.append("marker").attr("id", `arrow-${n}`).attr("viewBox", "0 0 10 10").attr("refX", 9).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("fill", d.evolutionStroke).attr("stroke", "none"), H.append("marker").attr("id", `link-arrow-end-${n}`).attr("viewBox", "0 0 10 10").attr("refX", 9).attr("refY", 5).attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("fill", d.linkStroke).attr("stroke", "none"), H.append("marker").attr("id", `link-arrow-start-${n}`).attr("viewBox", "0 0 10 10").attr("refX", 1).attr("refY", 5).attr("markerWidth", 5).attr("markerHeight", 5).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 z").attr("fill", d.linkStroke).attr("stroke", "none"), v.append("rect").attr("class", "wardley-background").attr("width", S).attr("height", b).attr("fill", d.backgroundColor);
    let I = S - a.padding * 2, B = b - a.padding * 2;
    R && v.append("text").attr("class", "wardley-title").attr("x", S / 2).attr("y", a.padding / 2).attr("fill", d.axisTextColor).attr("font-size", a.axisFontSize * 1.05).attr("font-weight", "bold").attr("text-anchor", "middle").attr("dominant-baseline", "middle").text(R);
    let z = u(t => a.padding + t / 100 * I, "projectX"), L = u(t => b - a.padding - t / 100 * B, "projectY"), O = v.append("g").attr("class", "wardley-axes");
    O.append("line").attr("x1", a.padding).attr("x2", S - a.padding).attr("y1", b - a.padding).attr("y2", b - a.padding).attr("stroke", d.axisColor).attr("stroke-width", 1), O.append("line").attr("x1", a.padding).attr("x2", a.padding).attr("y1", a.padding).attr("y2", b - a.padding).attr("stroke", d.axisColor).attr("stroke-width", 1);
    let Xt = g.axes.xLabel ?? "Evolution", Et = g.axes.yLabel ?? "Visibility";
    O.append("text").attr("class", "wardley-axis-label wardley-axis-label-x").attr("x", a.padding + I / 2).attr("y", b - a.padding / 4).attr("fill", d.axisTextColor).attr("font-size", a.axisFontSize).attr("font-weight", "bold").attr("text-anchor", "middle").text(Xt), O.append("text").attr("class", "wardley-axis-label wardley-axis-label-y").attr("x", a.padding / 3).attr("y", a.padding + B / 2).attr("fill", d.axisTextColor).attr("font-size", a.axisFontSize).attr("font-weight", "bold").attr("text-anchor", "middle").attr("transform", `rotate(-90 ${a.padding / 3} ${a.padding + B / 2})`).text(Et);
    let F = g.axes.stages && g.axes.stages.length > 0 ? g.axes.stages : jt;
    if (F.length > 0) {
        let t = v.append("g").attr("class", "wardley-stages"), s = g.axes.stageBoundaries, o = [];
        if (s && s.length === F.length) {
            let i = 0;
            s.forEach(p => { o.push({ start: i, end: p }), i = p; });
        }
        else {
            let i = 1 / F.length;
            F.forEach((p, l) => { o.push({ start: l * i, end: (l + 1) * i }); });
        }
        F.forEach((i, p) => { let l = o[p], f = a.padding + l.start * I, h = a.padding + l.end * I, y = (f + h) / 2; p > 0 && t.append("line").attr("x1", f).attr("x2", f).attr("y1", a.padding).attr("y2", b - a.padding).attr("stroke", "#000").attr("stroke-width", 1).attr("stroke-dasharray", "5 5").attr("opacity", .8), t.append("text").attr("class", "wardley-stage-label").attr("x", y).attr("y", b - a.padding / 1.5).attr("fill", d.axisTextColor).attr("font-size", a.axisFontSize - 2).attr("text-anchor", "middle").text(i); });
    }
    if (a.showGrid) {
        let t = v.append("g").attr("class", "wardley-grid");
        for (let s = 1; s < 4; s++) {
            let o = s / 4, i = a.padding + I * o;
            t.append("line").attr("x1", i).attr("x2", i).attr("y1", a.padding).attr("y2", b - a.padding).attr("stroke", d.gridColor).attr("stroke-dasharray", "2 6"), t.append("line").attr("x1", a.padding).attr("x2", S - a.padding).attr("y1", b - a.padding - B * o).attr("y2", b - a.padding - B * o).attr("stroke", d.gridColor).attr("stroke-dasharray", "2 6");
        }
    }
    let c = new Map;
    if (g.nodes.forEach(t => { c.set(t.id, { x: z(t.x), y: L(t.y), node: t }); }), g.pipelines.length > 0) {
        let t = v.append("g").attr("class", "wardley-pipelines"), s = v.append("g").attr("class", "wardley-pipeline-links");
        g.pipelines.forEach(o => { if (o.componentIds.length === 0)
            return; let i = o.componentIds.map(h => ({ id: h, pos: c.get(h), node: g.nodes.find(y => y.id === h) })).filter(h => h.pos && h.node).sort((h, y) => h.node.x - y.node.x); for (let h = 0; h < i.length - 1; h++) {
            let y = i[h], w = i[h + 1];
            s.append("line").attr("class", "wardley-pipeline-evolution-link").attr("x1", y.pos.x).attr("y1", y.pos.y).attr("x2", w.pos.x).attr("y2", w.pos.y).attr("stroke", d.linkStroke).attr("stroke-width", 1).attr("stroke-dasharray", "4 4");
        } let p = 1 / 0, l = -1 / 0, f = 0; if (o.componentIds.forEach(h => { let y = c.get(h); y && (p = Math.min(p, y.x), l = Math.max(l, y.x), f = y.y); }), p !== 1 / 0 && l !== -1 / 0) {
            let y = a.nodeRadius * 4, w = f - y / 2, P = c.get(o.nodeId);
            if (P) {
                let N = (p + l) / 2;
                P.x = N, P.y = w - m / 6;
            }
            t.append("rect").attr("class", "wardley-pipeline-box").attr("x", p - 15).attr("y", w).attr("width", l - p + 30).attr("height", y).attr("fill", "none").attr("stroke", d.axisColor).attr("stroke-width", 1.5).attr("rx", 4).attr("ry", 4);
        } });
    }
    let U = v.append("g").attr("class", "wardley-links"), J = new Map;
    g.pipelines.forEach(t => { J.set(t.nodeId, new Set(t.componentIds)); });
    let K = g.links.filter(t => !(!c.has(t.source) || !c.has(t.target) || J.get(t.target)?.has(t.source)));
    U.selectAll("line").data(K).enter().append("line").attr("class", t => `wardley-link${t.dashed ? " wardley-link--dashed" : ""}`).attr("x1", t => { let s = c.get(t.source), o = c.get(t.target), p = g.nodes.find(y => y.id === t.source).isPipelineParent ? m / Math.sqrt(2) : a.nodeRadius, l = o.x - s.x, f = o.y - s.y, h = Math.sqrt(l * l + f * f); return s.x + l / h * p; }).attr("y1", t => { let s = c.get(t.source), o = c.get(t.target), p = g.nodes.find(y => y.id === t.source).isPipelineParent ? m / Math.sqrt(2) : a.nodeRadius, l = o.x - s.x, f = o.y - s.y, h = Math.sqrt(l * l + f * f); return s.y + f / h * p; }).attr("x2", t => { let s = c.get(t.source), o = c.get(t.target), p = g.nodes.find(y => y.id === t.target).isPipelineParent ? m / Math.sqrt(2) : a.nodeRadius, l = s.x - o.x, f = s.y - o.y, h = Math.sqrt(l * l + f * f); return o.x + l / h * p; }).attr("y2", t => { let s = c.get(t.source), o = c.get(t.target), p = g.nodes.find(y => y.id === t.target).isPipelineParent ? m / Math.sqrt(2) : a.nodeRadius, l = s.x - o.x, f = s.y - o.y, h = Math.sqrt(l * l + f * f); return o.y + f / h * p; }).attr("stroke", d.linkStroke).attr("stroke-width", 1).attr("stroke-dasharray", t => t.dashed ? "6 6" : null).attr("marker-end", t => t.flow === "forward" || t.flow === "bidirectional" ? `url(#link-arrow-end-${n})` : null).attr("marker-start", t => t.flow === "backward" || t.flow === "bidirectional" ? `url(#link-arrow-start-${n})` : null), U.selectAll("text").data(K.filter(t => t.label)).enter().append("text").attr("class", "wardley-link-label").attr("x", t => { let s = c.get(t.source), o = c.get(t.target), i = (s.x + o.x) / 2, p = o.y - s.y, l = o.x - s.x, f = Math.sqrt(l * l + p * p), h = 8, y = p / f; return i + y * h; }).attr("y", t => { let s = c.get(t.source), o = c.get(t.target), i = (s.y + o.y) / 2, p = o.x - s.x, l = o.y - s.y, f = Math.sqrt(p * p + l * l), h = 8, y = -p / f; return i + y * h; }).attr("fill", d.axisTextColor).attr("font-size", a.labelFontSize).attr("text-anchor", "middle").attr("dominant-baseline", "middle").attr("transform", t => { let s = c.get(t.source), o = c.get(t.target), i = (s.x + o.x) / 2, p = (s.y + o.y) / 2, l = o.x - s.x, f = o.y - s.y, h = Math.sqrt(l * l + f * f), y = 8, w = f / h, P = -l / h, N = i + w * y, W = p + P * y, X = Math.atan2(f, l) * 180 / Math.PI; return (X > 90 || X < -90) && (X += 180), `rotate(${X} ${N} ${W})`; }).text(t => t.label);
    let Yt = v.append("g").attr("class", "wardley-trends"), It = g.trends.map(t => { let s = c.get(t.nodeId); if (!s)
        return null; let o = z(t.targetX), i = L(t.targetY), p = o - s.x, l = i - s.y, f = Math.sqrt(p * p + l * l), h = a.nodeRadius + 2, y = f > h ? o - p / f * h : o, w = f > h ? i - l / f * h : i; return { origin: s, targetX: o, targetY: i, adjustedX2: y, adjustedY2: w }; }).filter(t => t !== null);
    Yt.selectAll("line").data(It).enter().append("line").attr("class", "wardley-trend").attr("x1", t => t.origin.x).attr("y1", t => t.origin.y).attr("x2", t => t.adjustedX2).attr("y2", t => t.adjustedY2).attr("stroke", d.evolutionStroke).attr("stroke-width", 1).attr("stroke-dasharray", "4 4").attr("marker-end", `url(#arrow-${n})`);
    let M = v.append("g").attr("class", "wardley-nodes").selectAll("g").data(g.nodes).enter().append("g").attr("class", t => ["wardley-node", t.className ? `wardley-node--${t.className}` : ""].filter(Boolean).join(" "));
    M.filter(t => t.sourceStrategy === "outsource").append("circle").attr("class", "wardley-outsource-overlay").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#666").attr("stroke", d.componentStroke).attr("stroke-width", 1), M.filter(t => t.sourceStrategy === "buy").append("circle").attr("class", "wardley-buy-overlay").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#ccc").attr("stroke", d.componentStroke).attr("stroke-width", 1), M.filter(t => t.sourceStrategy === "build").append("circle").attr("class", "wardley-build-overlay").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y).attr("r", a.nodeRadius * 2).attr("fill", "#eee").attr("stroke", "#000").attr("stroke-width", 1);
    let T = M.filter(t => t.sourceStrategy === "market");
    T.append("circle").attr("class", "wardley-market-overlay").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y).attr("r", a.nodeRadius * 2).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 1), M.filter(t => !t.isPipelineParent && t.sourceStrategy !== "market" && t.className !== "anchor").append("circle").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y).attr("r", a.nodeRadius).attr("fill", d.componentFill).attr("stroke", d.componentStroke).attr("stroke-width", 1);
    let j = a.nodeRadius * .7, $ = a.nodeRadius * 1.2;
    if (T.append("line").attr("class", "wardley-market-line").attr("x1", t => c.get(t.id).x).attr("y1", t => c.get(t.id).y - $).attr("x2", t => c.get(t.id).x - $ * Math.cos(Math.PI / 6)).attr("y2", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("stroke", d.componentStroke).attr("stroke-width", 1), T.append("line").attr("class", "wardley-market-line").attr("x1", t => c.get(t.id).x - $ * Math.cos(Math.PI / 6)).attr("y1", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("x2", t => c.get(t.id).x + $ * Math.cos(Math.PI / 6)).attr("y2", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("stroke", d.componentStroke).attr("stroke-width", 1), T.append("line").attr("class", "wardley-market-line").attr("x1", t => c.get(t.id).x + $ * Math.cos(Math.PI / 6)).attr("y1", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("x2", t => c.get(t.id).x).attr("y2", t => c.get(t.id).y - $).attr("stroke", d.componentStroke).attr("stroke-width", 1), T.append("circle").attr("class", "wardley-market-dot").attr("cx", t => c.get(t.id).x).attr("cy", t => c.get(t.id).y - $).attr("r", j).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 2), T.append("circle").attr("class", "wardley-market-dot").attr("cx", t => c.get(t.id).x - $ * Math.cos(Math.PI / 6)).attr("cy", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("r", j).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 2), T.append("circle").attr("class", "wardley-market-dot").attr("cx", t => c.get(t.id).x + $ * Math.cos(Math.PI / 6)).attr("cy", t => c.get(t.id).y + $ * Math.sin(Math.PI / 6)).attr("r", j).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 2), M.filter(t => t.isPipelineParent === !0).append("rect").attr("x", t => c.get(t.id).x - m / 2).attr("y", t => c.get(t.id).y - m / 2).attr("width", m).attr("height", m).attr("fill", d.componentFill).attr("stroke", d.componentStroke).attr("stroke-width", 1), M.filter(t => t.inertia === !0).append("line").attr("class", "wardley-inertia").attr("x1", t => { let s = c.get(t.id), o = t.isPipelineParent ? m / 2 + 15 : a.nodeRadius + 15; return t.sourceStrategy && (o += a.nodeRadius + 10), s.x + o; }).attr("y1", t => { let s = c.get(t.id), o = t.isPipelineParent ? m : a.nodeRadius * 2; return s.y - o / 2; }).attr("x2", t => { let s = c.get(t.id), o = t.isPipelineParent ? m / 2 + 15 : a.nodeRadius + 15; return t.sourceStrategy && (o += a.nodeRadius + 10), s.x + o; }).attr("y2", t => { let s = c.get(t.id), o = t.isPipelineParent ? m : a.nodeRadius * 2; return s.y + o / 2; }).attr("stroke", d.componentStroke).attr("stroke-width", 6), M.append("text").attr("x", t => { let s = c.get(t.id); if (t.className === "anchor")
        return t.labelOffsetX !== void 0 ? s.x + t.labelOffsetX : s.x; let o = a.nodeLabelOffset; t.sourceStrategy && t.labelOffsetX === void 0 && (o += 10); let i = t.labelOffsetX ?? o; return s.x + i; }).attr("y", t => { let s = c.get(t.id); if (t.className === "anchor")
        return t.labelOffsetY !== void 0 ? s.y + t.labelOffsetY : s.y - 3; let o = -a.nodeLabelOffset; t.sourceStrategy && t.labelOffsetY === void 0 && (o -= 10); let i = t.labelOffsetY ?? o; return s.y + i; }).attr("class", "wardley-node-label").attr("fill", t => t.className === "evolved" ? d.evolutionStroke : t.className === "anchor" ? "#000" : d.componentLabelColor).attr("font-size", a.labelFontSize).attr("font-weight", t => t.className === "anchor" ? "bold" : "normal").attr("text-anchor", t => t.className === "anchor" ? "middle" : "start").attr("dominant-baseline", t => t.className === "anchor" ? "middle" : "auto").text(t => t.label), g.annotations.length > 0) {
        let t = v.append("g").attr("class", "wardley-annotations");
        if (g.annotations.forEach(s => { let o = s.coordinates.map(i => ({ x: z(i.x), y: L(i.y) })); if (o.length > 1)
            for (let i = 0; i < o.length - 1; i++)
                t.append("line").attr("class", "wardley-annotation-line").attr("x1", o[i].x).attr("y1", o[i].y).attr("x2", o[i + 1].x).attr("y2", o[i + 1].y).attr("stroke", d.axisColor).attr("stroke-width", 1.5).attr("stroke-dasharray", "4 4"); o.forEach(i => { let p = t.append("g").attr("class", "wardley-annotation"); p.append("circle").attr("cx", i.x).attr("cy", i.y).attr("r", 10).attr("fill", "white").attr("stroke", d.axisColor).attr("stroke-width", 1.5), p.append("text").attr("x", i.x).attr("y", i.y).attr("text-anchor", "middle").attr("dominant-baseline", "central").attr("font-size", 10).attr("fill", d.axisTextColor).attr("font-weight", "bold").text(s.number); }); }), g.annotationsBox) {
            let s = z(g.annotationsBox.x), o = L(g.annotationsBox.y), i = 10, p = 16, l = 11, f = t.append("g").attr("class", "wardley-annotations-box"), h = [...g.annotations].filter(w => w.text).sort((w, P) => w.number - P.number), y = [];
            if (h.forEach((w, P) => { let N = f.append("text").attr("x", s + i).attr("y", o + i + (P + 1) * p).attr("font-size", l).attr("fill", d.axisTextColor).attr("text-anchor", "start").attr("dominant-baseline", "middle").text(`${w.number}. ${w.text}`); y.push(N); }), y.length > 0) {
                let w = 0, P = 0;
                y.forEach(V => { let D = V.node(), Ot = D.getComputedTextLength(); w = Math.max(w, Ot); let Wt = D.getBBox(); P = Math.max(P, Wt.height); });
                let N = w + i * 2 + 105, W = h.length * p + i * 2 + P / 2, X = a.padding, Bt = S - a.padding - N, Ft = a.padding, Rt = b - a.padding - W;
                s = Math.max(X, Math.min(s, Bt)), o = Math.max(Ft, Math.min(o, Rt)), y.forEach((V, D) => { V.attr("x", s + i).attr("y", o + i + (D + 1) * p); }), f.insert("rect", "text").attr("x", s).attr("y", o).attr("width", N).attr("height", W).attr("fill", "white").attr("stroke", d.axisColor).attr("stroke-width", 1.5).attr("rx", 4).attr("ry", 4);
            }
        }
    }
    if (g.notes.length > 0) {
        let t = v.append("g").attr("class", "wardley-notes");
        g.notes.forEach(s => { let o = z(s.x), i = L(s.y); t.append("text").attr("x", o).attr("y", i).attr("text-anchor", "start").attr("font-size", 11).attr("fill", d.axisTextColor).attr("font-weight", "bold").text(s.text); });
    }
    if (g.accelerators.length > 0) {
        let t = v.append("g").attr("class", "wardley-accelerators");
        g.accelerators.forEach(s => {
            let o = z(s.x), i = L(s.y), p = 60, l = 30, f = 20, h = `
        M ${o} ${i - l / 2}
        L ${o + p - f} ${i - l / 2}
        L ${o + p - f} ${i - l / 2 - 8}
        L ${o + p} ${i}
        L ${o + p - f} ${i + l / 2 + 8}
        L ${o + p - f} ${i + l / 2}
        L ${o} ${i + l / 2}
        Z
      `;
            t.append("path").attr("d", h).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 1), t.append("text").attr("x", o + p / 2).attr("y", i + l / 2 + 15).attr("text-anchor", "middle").attr("font-size", 10).attr("fill", d.axisTextColor).attr("font-weight", "bold").text(s.name);
        });
    }
    if (g.deaccelerators.length > 0) {
        let t = v.append("g").attr("class", "wardley-deaccelerators");
        g.deaccelerators.forEach(s => {
            let o = z(s.x), i = L(s.y), p = 60, l = 30, f = 20, h = `
        M ${o + p} ${i - l / 2}
        L ${o + f} ${i - l / 2}
        L ${o + f} ${i - l / 2 - 8}
        L ${o} ${i}
        L ${o + f} ${i + l / 2 + 8}
        L ${o + f} ${i + l / 2}
        L ${o + p} ${i + l / 2}
        Z
      `;
            t.append("path").attr("d", h).attr("fill", "white").attr("stroke", d.componentStroke).attr("stroke-width", 1), t.append("text").attr("x", o + p / 2).attr("y", i + l / 2 + 15).attr("text-anchor", "middle").attr("font-size", 10).attr("fill", d.axisTextColor).attr("font-weight", "bold").text(s.name);
        });
    }
}, "draw"), Ut = { draw: Zt }, Jt = u(({ wardley: e } = {}) => {
    let n = et(), r = at(), x = Z(n, r.themeVariables), a = Z(x.wardley, e);
    return `
  .wardley-background {
    fill: ${a.backgroundColor};
  }
  .wardley-axes line, .wardley-axes path {
    stroke: ${a.axisColor};
  }
  .wardley-axis-label {
    fill: ${a.axisTextColor};
  }
  .wardley-stage-label {
    fill: ${a.axisTextColor};
  }
  .wardley-grid line {
    stroke: ${a.gridColor};
  }
  .wardley-node circle {
    fill: ${a.componentFill};
    stroke: ${a.componentStroke};
  }
  .wardley-node-label {
    fill: ${a.componentLabelColor};
  }
  .wardley-link {
    stroke: ${a.linkStroke};
  }
  .wardley-link--dashed {
    stroke-dasharray: 4 4;
  }
  .wardley-link-label {
    fill: ${a.axisTextColor};
  }
  .wardley-trend line {
    stroke: ${a.evolutionStroke};
  }
  .wardley-annotation-line {
    stroke: ${a.annotationStroke};
  }
  .wardley-annotation circle {
    fill: ${a.annotationFill};
    stroke: ${a.annotationStroke};
  }
  .wardley-annotation text {
    fill: ${a.annotationTextColor};
  }
  .wardley-annotations-box rect {
    fill: ${a.annotationFill};
    stroke: ${a.annotationStroke};
  }
  .wardley-annotations-box text {
    fill: ${a.annotationTextColor};
  }
  .wardley-pipeline-box {
    stroke: ${a.componentStroke};
  }
  .wardley-notes text {
    fill: ${a.axisTextColor};
  }
  `;
}, "styles"), se = { parser: gt, db: Ht, renderer: Ut, styles: Jt };
export { se as diagram };
