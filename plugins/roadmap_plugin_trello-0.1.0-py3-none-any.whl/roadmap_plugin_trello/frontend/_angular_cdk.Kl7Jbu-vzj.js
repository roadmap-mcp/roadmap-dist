import "@nf-internal/chunk-OSQMNGTH";
import { Version as o } from "@angular/core";
var e = new o("21.2.14");
export { e as VERSION };
