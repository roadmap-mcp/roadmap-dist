import { a as r, b as d, c as l, d as o, e as s, g as n, v as u, w as i } from "@nf-internal/chunk-EPGORQP5";
var c = class extends i {
    static { r(this, "WardleyValueConverter"); }
    runCustomConverter(t, e, a) { if (t.name.toUpperCase() === "LINK_LABEL")
        return e.substring(1).trim(); }
}, m = { parser: { ValueConverter: r(() => new c, "ValueConverter") } };
function v(t = s) { let e = o(l(t), n), a = o(d({ shared: e }), u, m); return e.ServiceRegistry.register(a), { shared: e, Wardley: a }; }
r(v, "createWardleyServices");
export { m as a, v as b };
