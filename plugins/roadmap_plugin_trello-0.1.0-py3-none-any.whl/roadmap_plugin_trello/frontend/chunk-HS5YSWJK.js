import { a as o, b as d, c, d as i, e as l, g as u, q as f, w as E, y as m } from "@nf-internal/chunk-EPGORQP5";
var b = class extends m {
    static { o(this, "RailroadEbnfTokenBuilder"); }
    constructor() { super(["railroad-ebnf-beta"]); }
}, v = o(a => {
    let e = a.slice(1, -1), r = "";
    for (let t = 0; t < e.length; t++) {
        let n = e[t];
        if (n === "\\" && t + 1 < e.length) {
            t++;
            let s = e[t];
            switch (s) {
                case "n":
                    r += `
`;
                    break;
                case "r":
                    r += "\r";
                    break;
                case "t":
                    r += "	";
                    break;
                default: r += s;
            }
            continue;
        }
        r += n;
    }
    return r;
}, "decodeEscapedString"), h = class extends E {
    static { o(this, "RailroadEbnfValueConverter"); }
    runConverter(a, e, r) { let t = super.runConverter(a, e, r); if (a.name === "TITLE" && typeof t == "string") {
        let n = t.trim();
        if (n.startsWith('"') && n.endsWith('"') || n.startsWith("'") && n.endsWith("'"))
            return v(n);
    } return t; }
    runCustomConverter(a, e, r) { if (a.name === "EBNF_STRING")
        return v(e); if (a.name === "EBNF_SPECIAL_SEQUENCE")
        return e.slice(1, -1).trim(); }
}, C = { parser: { TokenBuilder: o(() => new b, "TokenBuilder"), ValueConverter: o(() => new h, "ValueConverter") } };
function R(a = l) { let e = i(c(a), u), r = i(d({ shared: e }), f, C); return e.ServiceRegistry.register(r), { shared: e, RailroadEbnf: r }; }
o(R, "createRailroadEbnfServices");
export { C as a, R as b };
