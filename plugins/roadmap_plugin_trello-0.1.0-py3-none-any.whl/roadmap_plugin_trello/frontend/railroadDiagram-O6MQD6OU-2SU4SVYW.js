import { a, b as p, c as u } from "@nf-internal/chunk-FAXKR3FL";
import { a as l } from "@nf-internal/chunk-CDENLQJG";
import { b as m } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import { b as s } from "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-YQ6X4GJP";
import "@nf-internal/chunk-LEJRRF65";
import { b as i } from "@nf-internal/chunk-RZWXGGKD";
import { a as n } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var d = s().Railroad.parser.LangiumParser, t = n(e => { switch (e.$type) {
    case "RailroadTerminalExpr": return { type: "terminal", value: e.value };
    case "RailroadNonTerminalExpr": return { type: "nonterminal", name: e.name };
    case "RailroadSpecialExpr": return { type: "special", text: e.text };
    case "RailroadSequenceExpr": {
        let r = e.elements.map(t);
        return r.length === 1 ? r[0] : { type: "sequence", elements: r };
    }
    case "RailroadChoiceExpr": {
        let r = e.alternatives.map(t);
        return r.length === 1 ? r[0] : { type: "choice", alternatives: r };
    }
    case "RailroadOptionalExpr": return { type: "optional", element: t(e.element) };
    case "RailroadOneOrMoreExpr": return { type: "repetition", element: t(e.element), min: 1, max: 1 / 0 };
    case "RailroadZeroOrMoreExpr": return { type: "repetition", element: t(e.element), min: 0, max: 1 / 0 };
    default: throw new Error(`Unsupported railroad expression: ${e.$type}`);
} }, "transformExpression"), c = n(e => ({ name: e.name, definition: t(e.definition) }), "transformRule"), f = n(e => { l(e, a), e.title && a.setTitle(e.title), e.rules.map(r => a.addRule(c(r))); }, "populateDb"), g = { parse: n(e => { a.clear(), i.debug("[Railroad Parser] Starting Langium parse"); let r = d.parse(e); if (r.lexerErrors.length > 0 || r.parserErrors.length > 0)
        throw new m(r); let o = r.value; i.debug("[Railroad Parser] Parsed rules:", o.rules.length), f(o), i.debug("[Railroad Parser] Parse complete"); }, "parse"), parser: { yy: a } }, y = { parser: g, db: a, renderer: u, styles: p }, w = y;
export { w as default, y as diagram };
