import { a as z } from "@nf-internal/chunk-ZB4R55K4";
import { b as Z, h as ot } from "@nf-internal/chunk-RZWXGGKD";
import { a as W } from "@nf-internal/chunk-YUSHYV7C";
import { a as B, b as K, d as q, e as yt, f as k } from "@nf-internal/chunk-OSQMNGTH";
var tt = q((Q, J) => { (function (R, y) { typeof Q == "object" && typeof J == "object" ? J.exports = y() : typeof define == "function" && define.amd ? define([], y) : typeof Q == "object" ? Q.layoutBase = y() : R.layoutBase = y(); })(Q, function () { return (function (N) { var R = {}; function y(n) { if (R[n])
    return R[n].exports; var e = R[n] = { i: n, l: !1, exports: {} }; return N[n].call(e.exports, e, e.exports, y), e.l = !0, e.exports; } return y.m = N, y.c = R, y.i = function (n) { return n; }, y.d = function (n, e, t) { y.o(n, e) || Object.defineProperty(n, e, { configurable: !1, enumerable: !0, get: t }); }, y.n = function (n) { var e = n && n.__esModule ? function () { return n.default; } : function () { return n; }; return y.d(e, "a", e), e; }, y.o = function (n, e) { return Object.prototype.hasOwnProperty.call(n, e); }, y.p = "", y(y.s = 26); })([(function (N, R, y) {
        "use strict";
        function n() { }
        n.QUALITY = 1, n.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, n.DEFAULT_INCREMENTAL = !1, n.DEFAULT_ANIMATION_ON_LAYOUT = !0, n.DEFAULT_ANIMATION_DURING_LAYOUT = !1, n.DEFAULT_ANIMATION_PERIOD = 50, n.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, n.DEFAULT_GRAPH_MARGIN = 15, n.NODE_DIMENSIONS_INCLUDE_LABELS = !1, n.SIMPLE_NODE_SIZE = 40, n.SIMPLE_NODE_HALF_SIZE = n.SIMPLE_NODE_SIZE / 2, n.EMPTY_COMPOUND_NODE_SIZE = 40, n.MIN_EDGE_LENGTH = 1, n.WORLD_BOUNDARY = 1e6, n.INITIAL_WORLD_BOUNDARY = n.WORLD_BOUNDARY / 1e3, n.WORLD_CENTER_X = 1200, n.WORLD_CENTER_Y = 900, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = y(2), e = y(8), t = y(9);
        function r(g, s, d) { n.call(this, d), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = d, this.bendpoints = [], this.source = g, this.target = s; }
        r.prototype = Object.create(n.prototype);
        for (var a in n)
            r[a] = n[a];
        r.prototype.getSource = function () { return this.source; }, r.prototype.getTarget = function () { return this.target; }, r.prototype.isInterGraph = function () { return this.isInterGraph; }, r.prototype.getLength = function () { return this.length; }, r.prototype.isOverlapingSourceAndTarget = function () { return this.isOverlapingSourceAndTarget; }, r.prototype.getBendpoints = function () { return this.bendpoints; }, r.prototype.getLca = function () { return this.lca; }, r.prototype.getSourceInLca = function () { return this.sourceInLca; }, r.prototype.getTargetInLca = function () { return this.targetInLca; }, r.prototype.getOtherEnd = function (g) { if (this.source === g)
            return this.target; if (this.target === g)
            return this.source; throw "Node is not incident with this edge"; }, r.prototype.getOtherEndInGraph = function (g, s) { for (var d = this.getOtherEnd(g), i = s.getGraphManager().getRoot();;) {
            if (d.getOwner() == s)
                return d;
            if (d.getOwner() == i)
                break;
            d = d.getOwner().getParent();
        } return null; }, r.prototype.updateLength = function () { var g = new Array(4); this.isOverlapingSourceAndTarget = e.getIntersection(this.target.getRect(), this.source.getRect(), g), this.isOverlapingSourceAndTarget || (this.lengthX = g[0] - g[2], this.lengthY = g[1] - g[3], Math.abs(this.lengthX) < 1 && (this.lengthX = t.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = t.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY)); }, r.prototype.updateLengthSimple = function () { this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = t.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = t.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY); }, N.exports = r;
    }), (function (N, R, y) {
        "use strict";
        function n(e) { this.vGraphObject = e; }
        N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = y(2), e = y(10), t = y(13), r = y(0), a = y(16), g = y(4);
        function s(i, h, l, p) { l == null && p == null && (p = h), n.call(this, p), i.graphManager != null && (i = i.graphManager), this.estimatedSize = e.MIN_VALUE, this.inclusionTreeDepth = e.MAX_VALUE, this.vGraphObject = p, this.edges = [], this.graphManager = i, l != null && h != null ? this.rect = new t(h.x, h.y, l.width, l.height) : this.rect = new t; }
        s.prototype = Object.create(n.prototype);
        for (var d in n)
            s[d] = n[d];
        s.prototype.getEdges = function () { return this.edges; }, s.prototype.getChild = function () { return this.child; }, s.prototype.getOwner = function () { return this.owner; }, s.prototype.getWidth = function () { return this.rect.width; }, s.prototype.setWidth = function (i) { this.rect.width = i; }, s.prototype.getHeight = function () { return this.rect.height; }, s.prototype.setHeight = function (i) { this.rect.height = i; }, s.prototype.getCenterX = function () { return this.rect.x + this.rect.width / 2; }, s.prototype.getCenterY = function () { return this.rect.y + this.rect.height / 2; }, s.prototype.getCenter = function () { return new g(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2); }, s.prototype.getLocation = function () { return new g(this.rect.x, this.rect.y); }, s.prototype.getRect = function () { return this.rect; }, s.prototype.getDiagonal = function () { return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height); }, s.prototype.getHalfTheDiagonal = function () { return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2; }, s.prototype.setRect = function (i, h) { this.rect.x = i.x, this.rect.y = i.y, this.rect.width = h.width, this.rect.height = h.height; }, s.prototype.setCenter = function (i, h) { this.rect.x = i - this.rect.width / 2, this.rect.y = h - this.rect.height / 2; }, s.prototype.setLocation = function (i, h) { this.rect.x = i, this.rect.y = h; }, s.prototype.moveBy = function (i, h) { this.rect.x += i, this.rect.y += h; }, s.prototype.getEdgeListToNode = function (i) { var h = [], l, p = this; return p.edges.forEach(function (v) { if (v.target == i) {
            if (v.source != p)
                throw "Incorrect edge source!";
            h.push(v);
        } }), h; }, s.prototype.getEdgesBetween = function (i) { var h = [], l, p = this; return p.edges.forEach(function (v) { if (!(v.source == p || v.target == p))
            throw "Incorrect edge source and/or target"; (v.target == i || v.source == i) && h.push(v); }), h; }, s.prototype.getNeighborsList = function () { var i = new Set, h = this; return h.edges.forEach(function (l) { if (l.source == h)
            i.add(l.target);
        else {
            if (l.target != h)
                throw "Incorrect incidency!";
            i.add(l.source);
        } }), i; }, s.prototype.withChildren = function () { var i = new Set, h, l; if (i.add(this), this.child != null)
            for (var p = this.child.getNodes(), v = 0; v < p.length; v++)
                h = p[v], l = h.withChildren(), l.forEach(function (L) { i.add(L); }); return i; }, s.prototype.getNoOfChildren = function () { var i = 0, h; if (this.child == null)
            i = 1;
        else
            for (var l = this.child.getNodes(), p = 0; p < l.length; p++)
                h = l[p], i += h.getNoOfChildren(); return i == 0 && (i = 1), i; }, s.prototype.getEstimatedSize = function () { if (this.estimatedSize == e.MIN_VALUE)
            throw "assert failed"; return this.estimatedSize; }, s.prototype.calcEstimatedSize = function () { return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize); }, s.prototype.scatter = function () { var i, h, l = -r.INITIAL_WORLD_BOUNDARY, p = r.INITIAL_WORLD_BOUNDARY; i = r.WORLD_CENTER_X + a.nextDouble() * (p - l) + l; var v = -r.INITIAL_WORLD_BOUNDARY, L = r.INITIAL_WORLD_BOUNDARY; h = r.WORLD_CENTER_Y + a.nextDouble() * (L - v) + v, this.rect.x = i, this.rect.y = h; }, s.prototype.updateBounds = function () { if (this.getChild() == null)
            throw "assert failed"; if (this.getChild().getNodes().length != 0) {
            var i = this.getChild();
            if (i.updateBounds(!0), this.rect.x = i.getLeft(), this.rect.y = i.getTop(), this.setWidth(i.getRight() - i.getLeft()), this.setHeight(i.getBottom() - i.getTop()), r.NODE_DIMENSIONS_INCLUDE_LABELS) {
                var h = i.getRight() - i.getLeft(), l = i.getBottom() - i.getTop();
                this.labelWidth > h && (this.rect.x -= (this.labelWidth - h) / 2, this.setWidth(this.labelWidth)), this.labelHeight > l && (this.labelPos == "center" ? this.rect.y -= (this.labelHeight - l) / 2 : this.labelPos == "top" && (this.rect.y -= this.labelHeight - l), this.setHeight(this.labelHeight));
            }
        } }, s.prototype.getInclusionTreeDepth = function () { if (this.inclusionTreeDepth == e.MAX_VALUE)
            throw "assert failed"; return this.inclusionTreeDepth; }, s.prototype.transform = function (i) { var h = this.rect.x; h > r.WORLD_BOUNDARY ? h = r.WORLD_BOUNDARY : h < -r.WORLD_BOUNDARY && (h = -r.WORLD_BOUNDARY); var l = this.rect.y; l > r.WORLD_BOUNDARY ? l = r.WORLD_BOUNDARY : l < -r.WORLD_BOUNDARY && (l = -r.WORLD_BOUNDARY); var p = new g(h, l), v = i.inverseTransformPoint(p); this.setLocation(v.x, v.y); }, s.prototype.getLeft = function () { return this.rect.x; }, s.prototype.getRight = function () { return this.rect.x + this.rect.width; }, s.prototype.getTop = function () { return this.rect.y; }, s.prototype.getBottom = function () { return this.rect.y + this.rect.height; }, s.prototype.getParent = function () { return this.owner == null ? null : this.owner.getParent(); }, N.exports = s;
    }), (function (N, R, y) {
        "use strict";
        function n(e, t) { e == null && t == null ? (this.x = 0, this.y = 0) : (this.x = e, this.y = t); }
        n.prototype.getX = function () { return this.x; }, n.prototype.getY = function () { return this.y; }, n.prototype.setX = function (e) { this.x = e; }, n.prototype.setY = function (e) { this.y = e; }, n.prototype.getDifference = function (e) { return new DimensionD(this.x - e.x, this.y - e.y); }, n.prototype.getCopy = function () { return new n(this.x, this.y); }, n.prototype.translate = function (e) { return this.x += e.width, this.y += e.height, this; }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = y(2), e = y(10), t = y(0), r = y(6), a = y(3), g = y(1), s = y(13), d = y(12), i = y(11);
        function h(p, v, L) { n.call(this, L), this.estimatedSize = e.MIN_VALUE, this.margin = t.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = p, v != null && v instanceof r ? this.graphManager = v : v != null && v instanceof Layout && (this.graphManager = v.graphManager); }
        h.prototype = Object.create(n.prototype);
        for (var l in n)
            h[l] = n[l];
        h.prototype.getNodes = function () { return this.nodes; }, h.prototype.getEdges = function () { return this.edges; }, h.prototype.getGraphManager = function () { return this.graphManager; }, h.prototype.getParent = function () { return this.parent; }, h.prototype.getLeft = function () { return this.left; }, h.prototype.getRight = function () { return this.right; }, h.prototype.getTop = function () { return this.top; }, h.prototype.getBottom = function () { return this.bottom; }, h.prototype.isConnected = function () { return this.isConnected; }, h.prototype.add = function (p, v, L) { if (v == null && L == null) {
            var c = p;
            if (this.graphManager == null)
                throw "Graph has no graph mgr!";
            if (this.getNodes().indexOf(c) > -1)
                throw "Node already in graph!";
            return c.owner = this, this.getNodes().push(c), c;
        }
        else {
            var A = p;
            if (!(this.getNodes().indexOf(v) > -1 && this.getNodes().indexOf(L) > -1))
                throw "Source or target not in graph!";
            if (!(v.owner == L.owner && v.owner == this))
                throw "Both owners must be this graph!";
            return v.owner != L.owner ? null : (A.source = v, A.target = L, A.isInterGraph = !1, this.getEdges().push(A), v.edges.push(A), L != v && L.edges.push(A), A);
        } }, h.prototype.remove = function (p) { var v = p; if (p instanceof a) {
            if (v == null)
                throw "Node is null!";
            if (!(v.owner != null && v.owner == this))
                throw "Owner graph is invalid!";
            if (this.graphManager == null)
                throw "Owner graph manager is invalid!";
            for (var L = v.edges.slice(), c, A = L.length, T = 0; T < A; T++)
                c = L[T], c.isInterGraph ? this.graphManager.remove(c) : c.source.owner.remove(c);
            var C = this.nodes.indexOf(v);
            if (C == -1)
                throw "Node not in owner node list!";
            this.nodes.splice(C, 1);
        }
        else if (p instanceof g) {
            var c = p;
            if (c == null)
                throw "Edge is null!";
            if (!(c.source != null && c.target != null))
                throw "Source and/or target is null!";
            if (!(c.source.owner != null && c.target.owner != null && c.source.owner == this && c.target.owner == this))
                throw "Source and/or target owner is invalid!";
            var o = c.source.edges.indexOf(c), f = c.target.edges.indexOf(c);
            if (!(o > -1 && f > -1))
                throw "Source and/or target doesn't know this edge!";
            c.source.edges.splice(o, 1), c.target != c.source && c.target.edges.splice(f, 1);
            var C = c.source.owner.getEdges().indexOf(c);
            if (C == -1)
                throw "Not in owner's edge list!";
            c.source.owner.getEdges().splice(C, 1);
        } }, h.prototype.updateLeftTop = function () { for (var p = e.MAX_VALUE, v = e.MAX_VALUE, L, c, A, T = this.getNodes(), C = T.length, o = 0; o < C; o++) {
            var f = T[o];
            L = f.getTop(), c = f.getLeft(), p > L && (p = L), v > c && (v = c);
        } return p == e.MAX_VALUE ? null : (T[0].getParent().paddingLeft != null ? A = T[0].getParent().paddingLeft : A = this.margin, this.left = v - A, this.top = p - A, new d(this.left, this.top)); }, h.prototype.updateBounds = function (p) { for (var v = e.MAX_VALUE, L = -e.MAX_VALUE, c = e.MAX_VALUE, A = -e.MAX_VALUE, T, C, o, f, u, E = this.nodes, D = E.length, O = 0; O < D; O++) {
            var m = E[O];
            p && m.child != null && m.updateBounds(), T = m.getLeft(), C = m.getRight(), o = m.getTop(), f = m.getBottom(), v > T && (v = T), L < C && (L = C), c > o && (c = o), A < f && (A = f);
        } var I = new s(v, c, L - v, A - c); v == e.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), E[0].getParent().paddingLeft != null ? u = E[0].getParent().paddingLeft : u = this.margin, this.left = I.x - u, this.right = I.x + I.width + u, this.top = I.y - u, this.bottom = I.y + I.height + u; }, h.calculateBounds = function (p) { for (var v = e.MAX_VALUE, L = -e.MAX_VALUE, c = e.MAX_VALUE, A = -e.MAX_VALUE, T, C, o, f, u = p.length, E = 0; E < u; E++) {
            var D = p[E];
            T = D.getLeft(), C = D.getRight(), o = D.getTop(), f = D.getBottom(), v > T && (v = T), L < C && (L = C), c > o && (c = o), A < f && (A = f);
        } var O = new s(v, c, L - v, A - c); return O; }, h.prototype.getInclusionTreeDepth = function () { return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth(); }, h.prototype.getEstimatedSize = function () { if (this.estimatedSize == e.MIN_VALUE)
            throw "assert failed"; return this.estimatedSize; }, h.prototype.calcEstimatedSize = function () { for (var p = 0, v = this.nodes, L = v.length, c = 0; c < L; c++) {
            var A = v[c];
            p += A.calcEstimatedSize();
        } return p == 0 ? this.estimatedSize = t.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = p / Math.sqrt(this.nodes.length), this.estimatedSize; }, h.prototype.updateConnected = function () { var p = this; if (this.nodes.length == 0) {
            this.isConnected = !0;
            return;
        } var v = new i, L = new Set, c = this.nodes[0], A, T, C = c.withChildren(); for (C.forEach(function (O) { v.push(O), L.add(O); }); v.length !== 0;) {
            c = v.shift(), A = c.getEdges();
            for (var o = A.length, f = 0; f < o; f++) {
                var u = A[f];
                if (T = u.getOtherEndInGraph(c, this), T != null && !L.has(T)) {
                    var E = T.withChildren();
                    E.forEach(function (O) { v.push(O), L.add(O); });
                }
            }
        } if (this.isConnected = !1, L.size >= this.nodes.length) {
            var D = 0;
            L.forEach(function (O) { O.owner == p && D++; }), D == this.nodes.length && (this.isConnected = !0);
        } }, N.exports = h;
    }), (function (N, R, y) {
        "use strict";
        var n, e = y(1);
        function t(r) { n = y(5), this.layout = r, this.graphs = [], this.edges = []; }
        t.prototype.addRoot = function () { var r = this.layout.newGraph(), a = this.layout.newNode(null), g = this.add(r, a); return this.setRootGraph(g), this.rootGraph; }, t.prototype.add = function (r, a, g, s, d) { if (g == null && s == null && d == null) {
            if (r == null)
                throw "Graph is null!";
            if (a == null)
                throw "Parent node is null!";
            if (this.graphs.indexOf(r) > -1)
                throw "Graph already in this graph mgr!";
            if (this.graphs.push(r), r.parent != null)
                throw "Already has a parent!";
            if (a.child != null)
                throw "Already has a child!";
            return r.parent = a, a.child = r, r;
        }
        else {
            d = g, s = a, g = r;
            var i = s.getOwner(), h = d.getOwner();
            if (!(i != null && i.getGraphManager() == this))
                throw "Source not in this graph mgr!";
            if (!(h != null && h.getGraphManager() == this))
                throw "Target not in this graph mgr!";
            if (i == h)
                return g.isInterGraph = !1, i.add(g, s, d);
            if (g.isInterGraph = !0, g.source = s, g.target = d, this.edges.indexOf(g) > -1)
                throw "Edge already in inter-graph edge list!";
            if (this.edges.push(g), !(g.source != null && g.target != null))
                throw "Edge source and/or target is null!";
            if (!(g.source.edges.indexOf(g) == -1 && g.target.edges.indexOf(g) == -1))
                throw "Edge already in source and/or target incidency list!";
            return g.source.edges.push(g), g.target.edges.push(g), g;
        } }, t.prototype.remove = function (r) { if (r instanceof n) {
            var a = r;
            if (a.getGraphManager() != this)
                throw "Graph not in this graph mgr";
            if (!(a == this.rootGraph || a.parent != null && a.parent.graphManager == this))
                throw "Invalid parent node!";
            var g = [];
            g = g.concat(a.getEdges());
            for (var s, d = g.length, i = 0; i < d; i++)
                s = g[i], a.remove(s);
            var h = [];
            h = h.concat(a.getNodes());
            var l;
            d = h.length;
            for (var i = 0; i < d; i++)
                l = h[i], a.remove(l);
            a == this.rootGraph && this.setRootGraph(null);
            var p = this.graphs.indexOf(a);
            this.graphs.splice(p, 1), a.parent = null;
        }
        else if (r instanceof e) {
            if (s = r, s == null)
                throw "Edge is null!";
            if (!s.isInterGraph)
                throw "Not an inter-graph edge!";
            if (!(s.source != null && s.target != null))
                throw "Source and/or target is null!";
            if (!(s.source.edges.indexOf(s) != -1 && s.target.edges.indexOf(s) != -1))
                throw "Source and/or target doesn't know this edge!";
            var p = s.source.edges.indexOf(s);
            if (s.source.edges.splice(p, 1), p = s.target.edges.indexOf(s), s.target.edges.splice(p, 1), !(s.source.owner != null && s.source.owner.getGraphManager() != null))
                throw "Edge owner graph or owner graph manager is null!";
            if (s.source.owner.getGraphManager().edges.indexOf(s) == -1)
                throw "Not in owner graph manager's edge list!";
            var p = s.source.owner.getGraphManager().edges.indexOf(s);
            s.source.owner.getGraphManager().edges.splice(p, 1);
        } }, t.prototype.updateBounds = function () { this.rootGraph.updateBounds(!0); }, t.prototype.getGraphs = function () { return this.graphs; }, t.prototype.getAllNodes = function () { if (this.allNodes == null) {
            for (var r = [], a = this.getGraphs(), g = a.length, s = 0; s < g; s++)
                r = r.concat(a[s].getNodes());
            this.allNodes = r;
        } return this.allNodes; }, t.prototype.resetAllNodes = function () { this.allNodes = null; }, t.prototype.resetAllEdges = function () { this.allEdges = null; }, t.prototype.resetAllNodesToApplyGravitation = function () { this.allNodesToApplyGravitation = null; }, t.prototype.getAllEdges = function () { if (this.allEdges == null) {
            for (var r = [], a = this.getGraphs(), g = a.length, s = 0; s < a.length; s++)
                r = r.concat(a[s].getEdges());
            r = r.concat(this.edges), this.allEdges = r;
        } return this.allEdges; }, t.prototype.getAllNodesToApplyGravitation = function () { return this.allNodesToApplyGravitation; }, t.prototype.setAllNodesToApplyGravitation = function (r) { if (this.allNodesToApplyGravitation != null)
            throw "assert failed"; this.allNodesToApplyGravitation = r; }, t.prototype.getRoot = function () { return this.rootGraph; }, t.prototype.setRootGraph = function (r) { if (r.getGraphManager() != this)
            throw "Root not in this graph mgr!"; this.rootGraph = r, r.parent == null && (r.parent = this.layout.newNode("Root node")); }, t.prototype.getLayout = function () { return this.layout; }, t.prototype.isOneAncestorOfOther = function (r, a) { if (!(r != null && a != null))
            throw "assert failed"; if (r == a)
            return !0; var g = r.getOwner(), s; do {
            if (s = g.getParent(), s == null)
                break;
            if (s == a)
                return !0;
            if (g = s.getOwner(), g == null)
                break;
        } while (!0); g = a.getOwner(); do {
            if (s = g.getParent(), s == null)
                break;
            if (s == r)
                return !0;
            if (g = s.getOwner(), g == null)
                break;
        } while (!0); return !1; }, t.prototype.calcLowestCommonAncestors = function () { for (var r, a, g, s, d, i = this.getAllEdges(), h = i.length, l = 0; l < h; l++) {
            if (r = i[l], a = r.source, g = r.target, r.lca = null, r.sourceInLca = a, r.targetInLca = g, a == g) {
                r.lca = a.getOwner();
                continue;
            }
            for (s = a.getOwner(); r.lca == null;) {
                for (r.targetInLca = g, d = g.getOwner(); r.lca == null;) {
                    if (d == s) {
                        r.lca = d;
                        break;
                    }
                    if (d == this.rootGraph)
                        break;
                    if (r.lca != null)
                        throw "assert failed";
                    r.targetInLca = d.getParent(), d = r.targetInLca.getOwner();
                }
                if (s == this.rootGraph)
                    break;
                r.lca == null && (r.sourceInLca = s.getParent(), s = r.sourceInLca.getOwner());
            }
            if (r.lca == null)
                throw "assert failed";
        } }, t.prototype.calcLowestCommonAncestor = function (r, a) { if (r == a)
            return r.getOwner(); var g = r.getOwner(); do {
            if (g == null)
                break;
            var s = a.getOwner();
            do {
                if (s == null)
                    break;
                if (s == g)
                    return s;
                s = s.getParent().getOwner();
            } while (!0);
            g = g.getParent().getOwner();
        } while (!0); return g; }, t.prototype.calcInclusionTreeDepths = function (r, a) { r == null && a == null && (r = this.rootGraph, a = 1); for (var g, s = r.getNodes(), d = s.length, i = 0; i < d; i++)
            g = s[i], g.inclusionTreeDepth = a, g.child != null && this.calcInclusionTreeDepths(g.child, a + 1); }, t.prototype.includesInvalidEdge = function () { for (var r, a = this.edges.length, g = 0; g < a; g++)
            if (r = this.edges[g], this.isOneAncestorOfOther(r.source, r.target))
                return !0; return !1; }, N.exports = t;
    }), (function (N, R, y) {
        "use strict";
        var n = y(0);
        function e() { }
        for (var t in n)
            e[t] = n[t];
        e.MAX_ITERATIONS = 2500, e.DEFAULT_EDGE_LENGTH = 50, e.DEFAULT_SPRING_STRENGTH = .45, e.DEFAULT_REPULSION_STRENGTH = 4500, e.DEFAULT_GRAVITY_STRENGTH = .4, e.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, e.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, e.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, e.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, e.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, e.DEFAULT_COOLING_FACTOR_INCREMENTAL = .3, e.COOLING_ADAPTATION_FACTOR = .33, e.ADAPTATION_LOWER_NODE_LIMIT = 1e3, e.ADAPTATION_UPPER_NODE_LIMIT = 5e3, e.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, e.MAX_NODE_DISPLACEMENT = e.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, e.MIN_REPULSION_DIST = e.DEFAULT_EDGE_LENGTH / 10, e.CONVERGENCE_CHECK_PERIOD = 100, e.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = .1, e.MIN_EDGE_LENGTH = 1, e.GRID_CALCULATION_CHECK_PERIOD = 10, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        var n = y(12);
        function e() { }
        e.calcSeparationAmount = function (t, r, a, g) { if (!t.intersects(r))
            throw "assert failed"; var s = new Array(2); this.decideDirectionsForOverlappingNodes(t, r, s), a[0] = Math.min(t.getRight(), r.getRight()) - Math.max(t.x, r.x), a[1] = Math.min(t.getBottom(), r.getBottom()) - Math.max(t.y, r.y), t.getX() <= r.getX() && t.getRight() >= r.getRight() ? a[0] += Math.min(r.getX() - t.getX(), t.getRight() - r.getRight()) : r.getX() <= t.getX() && r.getRight() >= t.getRight() && (a[0] += Math.min(t.getX() - r.getX(), r.getRight() - t.getRight())), t.getY() <= r.getY() && t.getBottom() >= r.getBottom() ? a[1] += Math.min(r.getY() - t.getY(), t.getBottom() - r.getBottom()) : r.getY() <= t.getY() && r.getBottom() >= t.getBottom() && (a[1] += Math.min(t.getY() - r.getY(), r.getBottom() - t.getBottom())); var d = Math.abs((r.getCenterY() - t.getCenterY()) / (r.getCenterX() - t.getCenterX())); r.getCenterY() === t.getCenterY() && r.getCenterX() === t.getCenterX() && (d = 1); var i = d * a[0], h = a[1] / d; a[0] < h ? h = a[0] : i = a[1], a[0] = -1 * s[0] * (h / 2 + g), a[1] = -1 * s[1] * (i / 2 + g); }, e.decideDirectionsForOverlappingNodes = function (t, r, a) { t.getCenterX() < r.getCenterX() ? a[0] = -1 : a[0] = 1, t.getCenterY() < r.getCenterY() ? a[1] = -1 : a[1] = 1; }, e.getIntersection2 = function (t, r, a) { var g = t.getCenterX(), s = t.getCenterY(), d = r.getCenterX(), i = r.getCenterY(); if (t.intersects(r))
            return a[0] = g, a[1] = s, a[2] = d, a[3] = i, !0; var h = t.getX(), l = t.getY(), p = t.getRight(), v = t.getX(), L = t.getBottom(), c = t.getRight(), A = t.getWidthHalf(), T = t.getHeightHalf(), C = r.getX(), o = r.getY(), f = r.getRight(), u = r.getX(), E = r.getBottom(), D = r.getRight(), O = r.getWidthHalf(), m = r.getHeightHalf(), I = !1, w = !1; if (g === d) {
            if (s > i)
                return a[0] = g, a[1] = l, a[2] = d, a[3] = E, !1;
            if (s < i)
                return a[0] = g, a[1] = L, a[2] = d, a[3] = o, !1;
        }
        else if (s === i) {
            if (g > d)
                return a[0] = h, a[1] = s, a[2] = f, a[3] = i, !1;
            if (g < d)
                return a[0] = p, a[1] = s, a[2] = C, a[3] = i, !1;
        }
        else {
            var F = t.height / t.width, Y = r.height / r.width, x = (i - s) / (d - g), M = void 0, G = void 0, S = void 0, P = void 0, _ = void 0, U = void 0;
            if (-F === x ? g > d ? (a[0] = v, a[1] = L, I = !0) : (a[0] = p, a[1] = l, I = !0) : F === x && (g > d ? (a[0] = h, a[1] = l, I = !0) : (a[0] = c, a[1] = L, I = !0)), -Y === x ? d > g ? (a[2] = u, a[3] = E, w = !0) : (a[2] = f, a[3] = o, w = !0) : Y === x && (d > g ? (a[2] = C, a[3] = o, w = !0) : (a[2] = D, a[3] = E, w = !0)), I && w)
                return !1;
            if (g > d ? s > i ? (M = this.getCardinalDirection(F, x, 4), G = this.getCardinalDirection(Y, x, 2)) : (M = this.getCardinalDirection(-F, x, 3), G = this.getCardinalDirection(-Y, x, 1)) : s > i ? (M = this.getCardinalDirection(-F, x, 1), G = this.getCardinalDirection(-Y, x, 3)) : (M = this.getCardinalDirection(F, x, 2), G = this.getCardinalDirection(Y, x, 4)), !I)
                switch (M) {
                    case 1:
                        P = l, S = g + -T / x, a[0] = S, a[1] = P;
                        break;
                    case 2:
                        S = c, P = s + A * x, a[0] = S, a[1] = P;
                        break;
                    case 3:
                        P = L, S = g + T / x, a[0] = S, a[1] = P;
                        break;
                    case 4:
                        S = v, P = s + -A * x, a[0] = S, a[1] = P;
                        break;
                }
            if (!w)
                switch (G) {
                    case 1:
                        U = o, _ = d + -m / x, a[2] = _, a[3] = U;
                        break;
                    case 2:
                        _ = D, U = i + O * x, a[2] = _, a[3] = U;
                        break;
                    case 3:
                        U = E, _ = d + m / x, a[2] = _, a[3] = U;
                        break;
                    case 4:
                        _ = u, U = i + -O * x, a[2] = _, a[3] = U;
                        break;
                }
        } return !1; }, e.getCardinalDirection = function (t, r, a) { return t > r ? a : 1 + a % 4; }, e.getIntersection = function (t, r, a, g) { if (g == null)
            return this.getIntersection2(t, r, a); var s = t.x, d = t.y, i = r.x, h = r.y, l = a.x, p = a.y, v = g.x, L = g.y, c = void 0, A = void 0, T = void 0, C = void 0, o = void 0, f = void 0, u = void 0, E = void 0, D = void 0; return T = h - d, o = s - i, u = i * d - s * h, C = L - p, f = l - v, E = v * p - l * L, D = T * f - C * o, D === 0 ? null : (c = (o * E - f * u) / D, A = (C * u - T * E) / D, new n(c, A)); }, e.angleOfVector = function (t, r, a, g) { var s = void 0; return t !== a ? (s = Math.atan((g - r) / (a - t)), a < t ? s += Math.PI : g < r && (s += this.TWO_PI)) : g < r ? s = this.ONE_AND_HALF_PI : s = this.HALF_PI, s; }, e.doIntersect = function (t, r, a, g) { var s = t.x, d = t.y, i = r.x, h = r.y, l = a.x, p = a.y, v = g.x, L = g.y, c = (i - s) * (L - p) - (v - l) * (h - d); if (c === 0)
            return !1; var A = ((L - p) * (v - s) + (l - v) * (L - d)) / c, T = ((d - h) * (v - s) + (i - s) * (L - d)) / c; return 0 < A && A < 1 && 0 < T && T < 1; }, e.HALF_PI = .5 * Math.PI, e.ONE_AND_HALF_PI = 1.5 * Math.PI, e.TWO_PI = 2 * Math.PI, e.THREE_PI = 3 * Math.PI, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        function n() { }
        n.sign = function (e) { return e > 0 ? 1 : e < 0 ? -1 : 0; }, n.floor = function (e) { return e < 0 ? Math.ceil(e) : Math.floor(e); }, n.ceil = function (e) { return e < 0 ? Math.floor(e) : Math.ceil(e); }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        function n() { }
        n.MAX_VALUE = 2147483647, n.MIN_VALUE = -2147483648, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = (function () { function s(d, i) { for (var h = 0; h < i.length; h++) {
            var l = i[h];
            l.enumerable = l.enumerable || !1, l.configurable = !0, "value" in l && (l.writable = !0), Object.defineProperty(d, l.key, l);
        } } return function (d, i, h) { return i && s(d.prototype, i), h && s(d, h), d; }; })();
        function e(s, d) { if (!(s instanceof d))
            throw new TypeError("Cannot call a class as a function"); }
        var t = function (d) { return { value: d, next: null, prev: null }; }, r = function (d, i, h, l) { return d !== null ? d.next = i : l.head = i, h !== null ? h.prev = i : l.tail = i, i.prev = d, i.next = h, l.length++, i; }, a = function (d, i) { var h = d.prev, l = d.next; return h !== null ? h.next = l : i.head = l, l !== null ? l.prev = h : i.tail = h, d.prev = d.next = null, i.length--, d; }, g = (function () { function s(d) { var i = this; e(this, s), this.length = 0, this.head = null, this.tail = null, d?.forEach(function (h) { return i.push(h); }); } return n(s, [{ key: "size", value: function () { return this.length; } }, { key: "insertBefore", value: function (i, h) { return r(h.prev, t(i), h, this); } }, { key: "insertAfter", value: function (i, h) { return r(h, t(i), h.next, this); } }, { key: "insertNodeBefore", value: function (i, h) { return r(h.prev, i, h, this); } }, { key: "insertNodeAfter", value: function (i, h) { return r(h, i, h.next, this); } }, { key: "push", value: function (i) { return r(this.tail, t(i), null, this); } }, { key: "unshift", value: function (i) { return r(null, t(i), this.head, this); } }, { key: "remove", value: function (i) { return a(i, this); } }, { key: "pop", value: function () { return a(this.tail, this).value; } }, { key: "popNode", value: function () { return a(this.tail, this); } }, { key: "shift", value: function () { return a(this.head, this).value; } }, { key: "shiftNode", value: function () { return a(this.head, this); } }, { key: "get_object_at", value: function (i) { if (i <= this.length()) {
                    for (var h = 1, l = this.head; h < i;)
                        l = l.next, h++;
                    return l.value;
                } } }, { key: "set_object_at", value: function (i, h) { if (i <= this.length()) {
                    for (var l = 1, p = this.head; l < i;)
                        p = p.next, l++;
                    p.value = h;
                } } }]), s; })();
        N.exports = g;
    }), (function (N, R, y) {
        "use strict";
        function n(e, t, r) { this.x = null, this.y = null, e == null && t == null && r == null ? (this.x = 0, this.y = 0) : typeof e == "number" && typeof t == "number" && r == null ? (this.x = e, this.y = t) : e.constructor.name == "Point" && t == null && r == null && (r = e, this.x = r.x, this.y = r.y); }
        n.prototype.getX = function () { return this.x; }, n.prototype.getY = function () { return this.y; }, n.prototype.getLocation = function () { return new n(this.x, this.y); }, n.prototype.setLocation = function (e, t, r) { e.constructor.name == "Point" && t == null && r == null ? (r = e, this.setLocation(r.x, r.y)) : typeof e == "number" && typeof t == "number" && r == null && (parseInt(e) == e && parseInt(t) == t ? this.move(e, t) : (this.x = Math.floor(e + .5), this.y = Math.floor(t + .5))); }, n.prototype.move = function (e, t) { this.x = e, this.y = t; }, n.prototype.translate = function (e, t) { this.x += e, this.y += t; }, n.prototype.equals = function (e) { if (e.constructor.name == "Point") {
            var t = e;
            return this.x == t.x && this.y == t.y;
        } return this == e; }, n.prototype.toString = function () { return new n().constructor.name + "[x=" + this.x + ",y=" + this.y + "]"; }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        function n(e, t, r, a) { this.x = 0, this.y = 0, this.width = 0, this.height = 0, e != null && t != null && r != null && a != null && (this.x = e, this.y = t, this.width = r, this.height = a); }
        n.prototype.getX = function () { return this.x; }, n.prototype.setX = function (e) { this.x = e; }, n.prototype.getY = function () { return this.y; }, n.prototype.setY = function (e) { this.y = e; }, n.prototype.getWidth = function () { return this.width; }, n.prototype.setWidth = function (e) { this.width = e; }, n.prototype.getHeight = function () { return this.height; }, n.prototype.setHeight = function (e) { this.height = e; }, n.prototype.getRight = function () { return this.x + this.width; }, n.prototype.getBottom = function () { return this.y + this.height; }, n.prototype.intersects = function (e) { return !(this.getRight() < e.x || this.getBottom() < e.y || e.getRight() < this.x || e.getBottom() < this.y); }, n.prototype.getCenterX = function () { return this.x + this.width / 2; }, n.prototype.getMinX = function () { return this.getX(); }, n.prototype.getMaxX = function () { return this.getX() + this.width; }, n.prototype.getCenterY = function () { return this.y + this.height / 2; }, n.prototype.getMinY = function () { return this.getY(); }, n.prototype.getMaxY = function () { return this.getY() + this.height; }, n.prototype.getWidthHalf = function () { return this.width / 2; }, n.prototype.getHeightHalf = function () { return this.height / 2; }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function (t) { return typeof t; } : function (t) { return t && typeof Symbol == "function" && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t; };
        function e() { }
        e.lastID = 0, e.createID = function (t) { return e.isPrimitive(t) ? t : (t.uniqueID != null || (t.uniqueID = e.getString(), e.lastID++), t.uniqueID); }, e.getString = function (t) { return t == null && (t = e.lastID), "Object#" + t; }, e.isPrimitive = function (t) { var r = typeof t > "u" ? "undefined" : n(t); return t == null || r != "object" && r != "function"; }, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        function n(l) { if (Array.isArray(l)) {
            for (var p = 0, v = Array(l.length); p < l.length; p++)
                v[p] = l[p];
            return v;
        }
        else
            return Array.from(l); }
        var e = y(0), t = y(6), r = y(3), a = y(1), g = y(5), s = y(4), d = y(17), i = y(27);
        function h(l) { i.call(this), this.layoutQuality = e.QUALITY, this.createBendsAsNeeded = e.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = e.DEFAULT_INCREMENTAL, this.animationOnLayout = e.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = e.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = e.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = e.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = new Map, this.graphManager = new t(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, l != null && (this.isRemoteUse = l); }
        h.RANDOM_SEED = 1, h.prototype = Object.create(i.prototype), h.prototype.getGraphManager = function () { return this.graphManager; }, h.prototype.getAllNodes = function () { return this.graphManager.getAllNodes(); }, h.prototype.getAllEdges = function () { return this.graphManager.getAllEdges(); }, h.prototype.getAllNodesToApplyGravitation = function () { return this.graphManager.getAllNodesToApplyGravitation(); }, h.prototype.newGraphManager = function () { var l = new t(this); return this.graphManager = l, l; }, h.prototype.newGraph = function (l) { return new g(null, this.graphManager, l); }, h.prototype.newNode = function (l) { return new r(this.graphManager, l); }, h.prototype.newEdge = function (l) { return new a(null, null, l); }, h.prototype.checkLayoutSuccess = function () { return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge(); }, h.prototype.runLayout = function () { this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters(); var l; return this.checkLayoutSuccess() ? l = !1 : l = this.layout(), e.ANIMATE === "during" ? !1 : (l && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, l); }, h.prototype.doPostLayout = function () { this.incremental || this.transform(), this.update(); }, h.prototype.update2 = function () { if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
            for (var l, p = this.graphManager.getAllEdges(), v = 0; v < p.length; v++)
                l = p[v];
            for (var L, c = this.graphManager.getRoot().getNodes(), v = 0; v < c.length; v++)
                L = c[v];
            this.update(this.graphManager.getRoot());
        } }, h.prototype.update = function (l) { if (l == null)
            this.update2();
        else if (l instanceof r) {
            var p = l;
            if (p.getChild() != null)
                for (var v = p.getChild().getNodes(), L = 0; L < v.length; L++)
                    update(v[L]);
            if (p.vGraphObject != null) {
                var c = p.vGraphObject;
                c.update(p);
            }
        }
        else if (l instanceof a) {
            var A = l;
            if (A.vGraphObject != null) {
                var T = A.vGraphObject;
                T.update(A);
            }
        }
        else if (l instanceof g) {
            var C = l;
            if (C.vGraphObject != null) {
                var o = C.vGraphObject;
                o.update(C);
            }
        } }, h.prototype.initParameters = function () { this.isSubLayout || (this.layoutQuality = e.QUALITY, this.animationDuringLayout = e.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = e.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = e.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = e.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = e.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = e.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1); }, h.prototype.transform = function (l) { if (l == null)
            this.transform(new s(0, 0));
        else {
            var p = new d, v = this.graphManager.getRoot().updateLeftTop();
            if (v != null) {
                p.setWorldOrgX(l.x), p.setWorldOrgY(l.y), p.setDeviceOrgX(v.x), p.setDeviceOrgY(v.y);
                for (var L = this.getAllNodes(), c, A = 0; A < L.length; A++)
                    c = L[A], c.transform(p);
            }
        } }, h.prototype.positionNodesRandomly = function (l) { if (l == null)
            this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
        else
            for (var p, v, L = l.getNodes(), c = 0; c < L.length; c++)
                p = L[c], v = p.getChild(), v == null || v.getNodes().length == 0 ? p.scatter() : (this.positionNodesRandomly(v), p.updateBounds()); }, h.prototype.getFlatForest = function () { for (var l = [], p = !0, v = this.graphManager.getRoot().getNodes(), L = !0, c = 0; c < v.length; c++)
            v[c].getChild() != null && (L = !1); if (!L)
            return l; var A = new Set, T = [], C = new Map, o = []; for (o = o.concat(v); o.length > 0 && p;) {
            for (T.push(o[0]); T.length > 0 && p;) {
                var f = T[0];
                T.splice(0, 1), A.add(f);
                for (var u = f.getEdges(), c = 0; c < u.length; c++) {
                    var E = u[c].getOtherEnd(f);
                    if (C.get(f) != E)
                        if (!A.has(E))
                            T.push(E), C.set(E, f);
                        else {
                            p = !1;
                            break;
                        }
                }
            }
            if (!p)
                l = [];
            else {
                var D = [].concat(n(A));
                l.push(D);
                for (var c = 0; c < D.length; c++) {
                    var O = D[c], m = o.indexOf(O);
                    m > -1 && o.splice(m, 1);
                }
                A = new Set, C = new Map;
            }
        } return l; }, h.prototype.createDummyNodesForBendpoints = function (l) { for (var p = [], v = l.source, L = this.graphManager.calcLowestCommonAncestor(l.source, l.target), c = 0; c < l.bendpoints.length; c++) {
            var A = this.newNode(null);
            A.setRect(new Point(0, 0), new Dimension(1, 1)), L.add(A);
            var T = this.newEdge(null);
            this.graphManager.add(T, v, A), p.add(A), v = A;
        } var T = this.newEdge(null); return this.graphManager.add(T, v, l.target), this.edgeToDummyNodes.set(l, p), l.isInterGraph() ? this.graphManager.remove(l) : L.remove(l), p; }, h.prototype.createBendpointsFromDummyNodes = function () { var l = []; l = l.concat(this.graphManager.getAllEdges()), l = [].concat(n(this.edgeToDummyNodes.keys())).concat(l); for (var p = 0; p < l.length; p++) {
            var v = l[p];
            if (v.bendpoints.length > 0) {
                for (var L = this.edgeToDummyNodes.get(v), c = 0; c < L.length; c++) {
                    var A = L[c], T = new s(A.getCenterX(), A.getCenterY()), C = v.bendpoints.get(c);
                    C.x = T.x, C.y = T.y, A.getOwner().remove(A);
                }
                this.graphManager.add(v, v.source, v.target);
            }
        } }, h.transform = function (l, p, v, L) { if (v != null && L != null) {
            var c = p;
            if (l <= 50) {
                var A = p / v;
                c -= (p - A) / 50 * (50 - l);
            }
            else {
                var T = p * L;
                c += (T - p) / 50 * (l - 50);
            }
            return c;
        }
        else {
            var C, o;
            return l <= 50 ? (C = 9 * p / 500, o = p / 10) : (C = 9 * p / 50, o = -8 * p), C * l + o;
        } }, h.findCenterOfTree = function (l) { var p = []; p = p.concat(l); var v = [], L = new Map, c = !1, A = null; (p.length == 1 || p.length == 2) && (c = !0, A = p[0]); for (var T = 0; T < p.length; T++) {
            var C = p[T], o = C.getNeighborsList().size;
            L.set(C, C.getNeighborsList().size), o == 1 && v.push(C);
        } var f = []; for (f = f.concat(v); !c;) {
            var u = [];
            u = u.concat(f), f = [];
            for (var T = 0; T < p.length; T++) {
                var C = p[T], E = p.indexOf(C);
                E >= 0 && p.splice(E, 1);
                var D = C.getNeighborsList();
                D.forEach(function (I) { if (v.indexOf(I) < 0) {
                    var w = L.get(I), F = w - 1;
                    F == 1 && f.push(I), L.set(I, F);
                } });
            }
            v = v.concat(f), (p.length == 1 || p.length == 2) && (c = !0, A = p[0]);
        } return A; }, h.prototype.setGraphManager = function (l) { this.graphManager = l; }, N.exports = h;
    }), (function (N, R, y) {
        "use strict";
        function n() { }
        n.seed = 1, n.x = 0, n.nextDouble = function () { return n.x = Math.sin(n.seed++) * 1e4, n.x - Math.floor(n.x); }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = y(4);
        function e(t, r) { this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1; }
        e.prototype.getWorldOrgX = function () { return this.lworldOrgX; }, e.prototype.setWorldOrgX = function (t) { this.lworldOrgX = t; }, e.prototype.getWorldOrgY = function () { return this.lworldOrgY; }, e.prototype.setWorldOrgY = function (t) { this.lworldOrgY = t; }, e.prototype.getWorldExtX = function () { return this.lworldExtX; }, e.prototype.setWorldExtX = function (t) { this.lworldExtX = t; }, e.prototype.getWorldExtY = function () { return this.lworldExtY; }, e.prototype.setWorldExtY = function (t) { this.lworldExtY = t; }, e.prototype.getDeviceOrgX = function () { return this.ldeviceOrgX; }, e.prototype.setDeviceOrgX = function (t) { this.ldeviceOrgX = t; }, e.prototype.getDeviceOrgY = function () { return this.ldeviceOrgY; }, e.prototype.setDeviceOrgY = function (t) { this.ldeviceOrgY = t; }, e.prototype.getDeviceExtX = function () { return this.ldeviceExtX; }, e.prototype.setDeviceExtX = function (t) { this.ldeviceExtX = t; }, e.prototype.getDeviceExtY = function () { return this.ldeviceExtY; }, e.prototype.setDeviceExtY = function (t) { this.ldeviceExtY = t; }, e.prototype.transformX = function (t) { var r = 0, a = this.lworldExtX; return a != 0 && (r = this.ldeviceOrgX + (t - this.lworldOrgX) * this.ldeviceExtX / a), r; }, e.prototype.transformY = function (t) { var r = 0, a = this.lworldExtY; return a != 0 && (r = this.ldeviceOrgY + (t - this.lworldOrgY) * this.ldeviceExtY / a), r; }, e.prototype.inverseTransformX = function (t) { var r = 0, a = this.ldeviceExtX; return a != 0 && (r = this.lworldOrgX + (t - this.ldeviceOrgX) * this.lworldExtX / a), r; }, e.prototype.inverseTransformY = function (t) { var r = 0, a = this.ldeviceExtY; return a != 0 && (r = this.lworldOrgY + (t - this.ldeviceOrgY) * this.lworldExtY / a), r; }, e.prototype.inverseTransformPoint = function (t) { var r = new n(this.inverseTransformX(t.x), this.inverseTransformY(t.y)); return r; }, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        function n(i) { if (Array.isArray(i)) {
            for (var h = 0, l = Array(i.length); h < i.length; h++)
                l[h] = i[h];
            return l;
        }
        else
            return Array.from(i); }
        var e = y(15), t = y(7), r = y(0), a = y(8), g = y(9);
        function s() { e.call(this), this.useSmartIdealEdgeLengthCalculation = t.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.idealEdgeLength = t.DEFAULT_EDGE_LENGTH, this.springConstant = t.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = t.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = t.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = t.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = t.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = t.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * t.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = t.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = t.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = t.MAX_ITERATIONS; }
        s.prototype = Object.create(e.prototype);
        for (var d in e)
            s[d] = e[d];
        s.prototype.initParameters = function () { e.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = t.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = []; }, s.prototype.calcIdealEdgeLengths = function () { for (var i, h, l, p, v, L, c = this.getGraphManager().getAllEdges(), A = 0; A < c.length; A++)
            i = c[A], i.idealLength = this.idealEdgeLength, i.isInterGraph && (l = i.getSource(), p = i.getTarget(), v = i.getSourceInLca().getEstimatedSize(), L = i.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (i.idealLength += v + L - 2 * r.SIMPLE_NODE_SIZE), h = i.getLca().getInclusionTreeDepth(), i.idealLength += t.DEFAULT_EDGE_LENGTH * t.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (l.getInclusionTreeDepth() + p.getInclusionTreeDepth() - 2 * h)); }, s.prototype.initSpringEmbedder = function () { var i = this.getAllNodes().length; this.incremental ? (i > t.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * t.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (i - t.ADAPTATION_LOWER_NODE_LIMIT) / (t.ADAPTATION_UPPER_NODE_LIMIT - t.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - t.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = t.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (i > t.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(t.COOLING_ADAPTATION_FACTOR, 1 - (i - t.ADAPTATION_LOWER_NODE_LIMIT) / (t.ADAPTATION_UPPER_NODE_LIMIT - t.ADAPTATION_LOWER_NODE_LIMIT) * (1 - t.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = t.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange(); }, s.prototype.calcSpringForces = function () { for (var i = this.getAllEdges(), h, l = 0; l < i.length; l++)
            h = i[l], this.calcSpringForce(h, h.idealLength); }, s.prototype.calcRepulsionForces = function () { var i = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, h = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, l, p, v, L, c = this.getAllNodes(), A; if (this.useFRGridVariant)
            for (this.totalIterations % t.GRID_CALCULATION_CHECK_PERIOD == 1 && i && this.updateGrid(), A = new Set, l = 0; l < c.length; l++)
                v = c[l], this.calculateRepulsionForceOfANode(v, A, i, h), A.add(v);
        else
            for (l = 0; l < c.length; l++)
                for (v = c[l], p = l + 1; p < c.length; p++)
                    L = c[p], v.getOwner() == L.getOwner() && this.calcRepulsionForce(v, L); }, s.prototype.calcGravitationalForces = function () { for (var i, h = this.getAllNodesToApplyGravitation(), l = 0; l < h.length; l++)
            i = h[l], this.calcGravitationalForce(i); }, s.prototype.moveNodes = function () { for (var i = this.getAllNodes(), h, l = 0; l < i.length; l++)
            h = i[l], h.move(); }, s.prototype.calcSpringForce = function (i, h) { var l = i.getSource(), p = i.getTarget(), v, L, c, A; if (this.uniformLeafNodeSizes && l.getChild() == null && p.getChild() == null)
            i.updateLengthSimple();
        else if (i.updateLength(), i.isOverlapingSourceAndTarget)
            return; v = i.getLength(), v != 0 && (L = this.springConstant * (v - h), c = L * (i.lengthX / v), A = L * (i.lengthY / v), l.springForceX += c, l.springForceY += A, p.springForceX -= c, p.springForceY -= A); }, s.prototype.calcRepulsionForce = function (i, h) { var l = i.getRect(), p = h.getRect(), v = new Array(2), L = new Array(4), c, A, T, C, o, f, u; if (l.intersects(p)) {
            a.calcSeparationAmount(l, p, v, t.DEFAULT_EDGE_LENGTH / 2), f = 2 * v[0], u = 2 * v[1];
            var E = i.noOfChildren * h.noOfChildren / (i.noOfChildren + h.noOfChildren);
            i.repulsionForceX -= E * f, i.repulsionForceY -= E * u, h.repulsionForceX += E * f, h.repulsionForceY += E * u;
        }
        else
            this.uniformLeafNodeSizes && i.getChild() == null && h.getChild() == null ? (c = p.getCenterX() - l.getCenterX(), A = p.getCenterY() - l.getCenterY()) : (a.getIntersection(l, p, L), c = L[2] - L[0], A = L[3] - L[1]), Math.abs(c) < t.MIN_REPULSION_DIST && (c = g.sign(c) * t.MIN_REPULSION_DIST), Math.abs(A) < t.MIN_REPULSION_DIST && (A = g.sign(A) * t.MIN_REPULSION_DIST), T = c * c + A * A, C = Math.sqrt(T), o = this.repulsionConstant * i.noOfChildren * h.noOfChildren / T, f = o * c / C, u = o * A / C, i.repulsionForceX -= f, i.repulsionForceY -= u, h.repulsionForceX += f, h.repulsionForceY += u; }, s.prototype.calcGravitationalForce = function (i) { var h, l, p, v, L, c, A, T; h = i.getOwner(), l = (h.getRight() + h.getLeft()) / 2, p = (h.getTop() + h.getBottom()) / 2, v = i.getCenterX() - l, L = i.getCenterY() - p, c = Math.abs(v) + i.getWidth() / 2, A = Math.abs(L) + i.getHeight() / 2, i.getOwner() == this.graphManager.getRoot() ? (T = h.getEstimatedSize() * this.gravityRangeFactor, (c > T || A > T) && (i.gravitationForceX = -this.gravityConstant * v, i.gravitationForceY = -this.gravityConstant * L)) : (T = h.getEstimatedSize() * this.compoundGravityRangeFactor, (c > T || A > T) && (i.gravitationForceX = -this.gravityConstant * v * this.compoundGravityConstant, i.gravitationForceY = -this.gravityConstant * L * this.compoundGravityConstant)); }, s.prototype.isConverged = function () { var i, h = !1; return this.totalIterations > this.maxIterations / 3 && (h = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), i = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, i || h; }, s.prototype.animate = function () { this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++); }, s.prototype.calcNoOfChildrenForAllNodes = function () { for (var i, h = this.graphManager.getAllNodes(), l = 0; l < h.length; l++)
            i = h[l], i.noOfChildren = i.getNoOfChildren(); }, s.prototype.calcGrid = function (i) { var h = 0, l = 0; h = parseInt(Math.ceil((i.getRight() - i.getLeft()) / this.repulsionRange)), l = parseInt(Math.ceil((i.getBottom() - i.getTop()) / this.repulsionRange)); for (var p = new Array(h), v = 0; v < h; v++)
            p[v] = new Array(l); for (var v = 0; v < h; v++)
            for (var L = 0; L < l; L++)
                p[v][L] = new Array; return p; }, s.prototype.addNodeToGrid = function (i, h, l) { var p = 0, v = 0, L = 0, c = 0; p = parseInt(Math.floor((i.getRect().x - h) / this.repulsionRange)), v = parseInt(Math.floor((i.getRect().width + i.getRect().x - h) / this.repulsionRange)), L = parseInt(Math.floor((i.getRect().y - l) / this.repulsionRange)), c = parseInt(Math.floor((i.getRect().height + i.getRect().y - l) / this.repulsionRange)); for (var A = p; A <= v; A++)
            for (var T = L; T <= c; T++)
                this.grid[A][T].push(i), i.setGridCoordinates(p, v, L, c); }, s.prototype.updateGrid = function () { var i, h, l = this.getAllNodes(); for (this.grid = this.calcGrid(this.graphManager.getRoot()), i = 0; i < l.length; i++)
            h = l[i], this.addNodeToGrid(h, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop()); }, s.prototype.calculateRepulsionForceOfANode = function (i, h, l, p) { if (this.totalIterations % t.GRID_CALCULATION_CHECK_PERIOD == 1 && l || p) {
            var v = new Set;
            i.surrounding = new Array;
            for (var L, c = this.grid, A = i.startX - 1; A < i.finishX + 2; A++)
                for (var T = i.startY - 1; T < i.finishY + 2; T++)
                    if (!(A < 0 || T < 0 || A >= c.length || T >= c[0].length)) {
                        for (var C = 0; C < c[A][T].length; C++)
                            if (L = c[A][T][C], !(i.getOwner() != L.getOwner() || i == L) && !h.has(L) && !v.has(L)) {
                                var o = Math.abs(i.getCenterX() - L.getCenterX()) - (i.getWidth() / 2 + L.getWidth() / 2), f = Math.abs(i.getCenterY() - L.getCenterY()) - (i.getHeight() / 2 + L.getHeight() / 2);
                                o <= this.repulsionRange && f <= this.repulsionRange && v.add(L);
                            }
                    }
            i.surrounding = [].concat(n(v));
        } for (A = 0; A < i.surrounding.length; A++)
            this.calcRepulsionForce(i, i.surrounding[A]); }, s.prototype.calcRepulsionRange = function () { return 0; }, N.exports = s;
    }), (function (N, R, y) {
        "use strict";
        var n = y(1), e = y(7);
        function t(a, g, s) { n.call(this, a, g, s), this.idealLength = e.DEFAULT_EDGE_LENGTH; }
        t.prototype = Object.create(n.prototype);
        for (var r in n)
            t[r] = n[r];
        N.exports = t;
    }), (function (N, R, y) {
        "use strict";
        var n = y(3);
        function e(r, a, g, s) { n.call(this, r, a, g, s), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = []; }
        e.prototype = Object.create(n.prototype);
        for (var t in n)
            e[t] = n[t];
        e.prototype.setGridCoordinates = function (r, a, g, s) { this.startX = r, this.finishX = a, this.startY = g, this.finishY = s; }, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        function n(e, t) { this.width = 0, this.height = 0, e !== null && t !== null && (this.height = t, this.width = e); }
        n.prototype.getWidth = function () { return this.width; }, n.prototype.setWidth = function (e) { this.width = e; }, n.prototype.getHeight = function () { return this.height; }, n.prototype.setHeight = function (e) { this.height = e; }, N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        var n = y(14);
        function e() { this.map = {}, this.keys = []; }
        e.prototype.put = function (t, r) { var a = n.createID(t); this.contains(a) || (this.map[a] = r, this.keys.push(t)); }, e.prototype.contains = function (t) { var r = n.createID(t); return this.map[t] != null; }, e.prototype.get = function (t) { var r = n.createID(t); return this.map[r]; }, e.prototype.keySet = function () { return this.keys; }, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        var n = y(14);
        function e() { this.set = {}; }
        e.prototype.add = function (t) { var r = n.createID(t); this.contains(r) || (this.set[r] = t); }, e.prototype.remove = function (t) { delete this.set[n.createID(t)]; }, e.prototype.clear = function () { this.set = {}; }, e.prototype.contains = function (t) { return this.set[n.createID(t)] == t; }, e.prototype.isEmpty = function () { return this.size() === 0; }, e.prototype.size = function () { return Object.keys(this.set).length; }, e.prototype.addAllTo = function (t) { for (var r = Object.keys(this.set), a = r.length, g = 0; g < a; g++)
            t.push(this.set[r[g]]); }, e.prototype.size = function () { return Object.keys(this.set).length; }, e.prototype.addAll = function (t) { for (var r = t.length, a = 0; a < r; a++) {
            var g = t[a];
            this.add(g);
        } }, N.exports = e;
    }), (function (N, R, y) {
        "use strict";
        var n = (function () { function a(g, s) { for (var d = 0; d < s.length; d++) {
            var i = s[d];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(g, i.key, i);
        } } return function (g, s, d) { return s && a(g.prototype, s), d && a(g, d), g; }; })();
        function e(a, g) { if (!(a instanceof g))
            throw new TypeError("Cannot call a class as a function"); }
        var t = y(11), r = (function () { function a(g, s) { e(this, a), (s !== null || s !== void 0) && (this.compareFunction = this._defaultCompareFunction); var d = void 0; g instanceof t ? d = g.size() : d = g.length, this._quicksort(g, 0, d - 1); } return n(a, [{ key: "_quicksort", value: function (s, d, i) { if (d < i) {
                    var h = this._partition(s, d, i);
                    this._quicksort(s, d, h), this._quicksort(s, h + 1, i);
                } } }, { key: "_partition", value: function (s, d, i) { for (var h = this._get(s, d), l = d, p = i;;) {
                    for (; this.compareFunction(h, this._get(s, p));)
                        p--;
                    for (; this.compareFunction(this._get(s, l), h);)
                        l++;
                    if (l < p)
                        this._swap(s, l, p), l++, p--;
                    else
                        return p;
                } } }, { key: "_get", value: function (s, d) { return s instanceof t ? s.get_object_at(d) : s[d]; } }, { key: "_set", value: function (s, d, i) { s instanceof t ? s.set_object_at(d, i) : s[d] = i; } }, { key: "_swap", value: function (s, d, i) { var h = this._get(s, d); this._set(s, d, this._get(s, i)), this._set(s, i, h); } }, { key: "_defaultCompareFunction", value: function (s, d) { return d > s; } }]), a; })();
        N.exports = r;
    }), (function (N, R, y) {
        "use strict";
        var n = (function () { function r(a, g) { for (var s = 0; s < g.length; s++) {
            var d = g[s];
            d.enumerable = d.enumerable || !1, d.configurable = !0, "value" in d && (d.writable = !0), Object.defineProperty(a, d.key, d);
        } } return function (a, g, s) { return g && r(a.prototype, g), s && r(a, s), a; }; })();
        function e(r, a) { if (!(r instanceof a))
            throw new TypeError("Cannot call a class as a function"); }
        var t = (function () { function r(a, g) { var s = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, d = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, i = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1; e(this, r), this.sequence1 = a, this.sequence2 = g, this.match_score = s, this.mismatch_penalty = d, this.gap_penalty = i, this.iMax = a.length + 1, this.jMax = g.length + 1, this.grid = new Array(this.iMax); for (var h = 0; h < this.iMax; h++) {
            this.grid[h] = new Array(this.jMax);
            for (var l = 0; l < this.jMax; l++)
                this.grid[h][l] = 0;
        } this.tracebackGrid = new Array(this.iMax); for (var p = 0; p < this.iMax; p++) {
            this.tracebackGrid[p] = new Array(this.jMax);
            for (var v = 0; v < this.jMax; v++)
                this.tracebackGrid[p][v] = [null, null, null];
        } this.alignments = [], this.score = -1, this.computeGrids(); } return n(r, [{ key: "getScore", value: function () { return this.score; } }, { key: "getAlignments", value: function () { return this.alignments; } }, { key: "computeGrids", value: function () { for (var g = 1; g < this.jMax; g++)
                    this.grid[0][g] = this.grid[0][g - 1] + this.gap_penalty, this.tracebackGrid[0][g] = [!1, !1, !0]; for (var s = 1; s < this.iMax; s++)
                    this.grid[s][0] = this.grid[s - 1][0] + this.gap_penalty, this.tracebackGrid[s][0] = [!1, !0, !1]; for (var d = 1; d < this.iMax; d++)
                    for (var i = 1; i < this.jMax; i++) {
                        var h = void 0;
                        this.sequence1[d - 1] === this.sequence2[i - 1] ? h = this.grid[d - 1][i - 1] + this.match_score : h = this.grid[d - 1][i - 1] + this.mismatch_penalty;
                        var l = this.grid[d - 1][i] + this.gap_penalty, p = this.grid[d][i - 1] + this.gap_penalty, v = [h, l, p], L = this.arrayAllMaxIndexes(v);
                        this.grid[d][i] = v[L[0]], this.tracebackGrid[d][i] = [L.includes(0), L.includes(1), L.includes(2)];
                    } this.score = this.grid[this.iMax - 1][this.jMax - 1]; } }, { key: "alignmentTraceback", value: function () { var g = []; for (g.push({ pos: [this.sequence1.length, this.sequence2.length], seq1: "", seq2: "" }); g[0];) {
                    var s = g[0], d = this.tracebackGrid[s.pos[0]][s.pos[1]];
                    d[0] && g.push({ pos: [s.pos[0] - 1, s.pos[1] - 1], seq1: this.sequence1[s.pos[0] - 1] + s.seq1, seq2: this.sequence2[s.pos[1] - 1] + s.seq2 }), d[1] && g.push({ pos: [s.pos[0] - 1, s.pos[1]], seq1: this.sequence1[s.pos[0] - 1] + s.seq1, seq2: "-" + s.seq2 }), d[2] && g.push({ pos: [s.pos[0], s.pos[1] - 1], seq1: "-" + s.seq1, seq2: this.sequence2[s.pos[1] - 1] + s.seq2 }), s.pos[0] === 0 && s.pos[1] === 0 && this.alignments.push({ sequence1: s.seq1, sequence2: s.seq2 }), g.shift();
                } return this.alignments; } }, { key: "getAllIndexes", value: function (g, s) { for (var d = [], i = -1; (i = g.indexOf(s, i + 1)) !== -1;)
                    d.push(i); return d; } }, { key: "arrayAllMaxIndexes", value: function (g) { return this.getAllIndexes(g, Math.max.apply(null, g)); } }]), r; })();
        N.exports = t;
    }), (function (N, R, y) {
        "use strict";
        var n = function () { };
        n.FDLayout = y(18), n.FDLayoutConstants = y(7), n.FDLayoutEdge = y(19), n.FDLayoutNode = y(20), n.DimensionD = y(21), n.HashMap = y(22), n.HashSet = y(23), n.IGeometry = y(8), n.IMath = y(9), n.Integer = y(10), n.Point = y(12), n.PointD = y(4), n.RandomSeed = y(16), n.RectangleD = y(13), n.Transform = y(17), n.UniqueIDGeneretor = y(14), n.Quicksort = y(24), n.LinkedList = y(11), n.LGraphObject = y(2), n.LGraph = y(5), n.LEdge = y(1), n.LGraphManager = y(6), n.LNode = y(3), n.Layout = y(15), n.LayoutConstants = y(0), n.NeedlemanWunsch = y(25), N.exports = n;
    }), (function (N, R, y) {
        "use strict";
        function n() { this.listeners = []; }
        var e = n.prototype;
        e.addListener = function (t, r) { this.listeners.push({ event: t, callback: r }); }, e.removeListener = function (t, r) { for (var a = this.listeners.length; a >= 0; a--) {
            var g = this.listeners[a];
            g.event === t && g.callback === r && this.listeners.splice(a, 1);
        } }, e.emit = function (t, r) { for (var a = 0; a < this.listeners.length; a++) {
            var g = this.listeners[a];
            t === g.event && g.callback(r);
        } }, N.exports = n;
    })]); }); });
var rt = q(($, et) => { (function (R, y) { typeof $ == "object" && typeof et == "object" ? et.exports = y(tt()) : typeof define == "function" && define.amd ? define(["layout-base"], y) : typeof $ == "object" ? $.coseBase = y(tt()) : R.coseBase = y(R.layoutBase); })($, function (N) { return (function (R) { var y = {}; function n(e) { if (y[e])
    return y[e].exports; var t = y[e] = { i: e, l: !1, exports: {} }; return R[e].call(t.exports, t, t.exports, n), t.l = !0, t.exports; } return n.m = R, n.c = y, n.i = function (e) { return e; }, n.d = function (e, t, r) { n.o(e, t) || Object.defineProperty(e, t, { configurable: !1, enumerable: !0, get: r }); }, n.n = function (e) { var t = e && e.__esModule ? function () { return e.default; } : function () { return e; }; return n.d(t, "a", t), t; }, n.o = function (e, t) { return Object.prototype.hasOwnProperty.call(e, t); }, n.p = "", n(n.s = 7); })([(function (R, y) { R.exports = N; }), (function (R, y, n) {
        "use strict";
        var e = n(0).FDLayoutConstants;
        function t() { }
        for (var r in e)
            t[r] = e[r];
        t.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, t.DEFAULT_RADIAL_SEPARATION = e.DEFAULT_EDGE_LENGTH, t.DEFAULT_COMPONENT_SEPERATION = 60, t.TILE = !0, t.TILING_PADDING_VERTICAL = 10, t.TILING_PADDING_HORIZONTAL = 10, t.TREE_REDUCTION_ON_INCREMENTAL = !1, R.exports = t;
    }), (function (R, y, n) {
        "use strict";
        var e = n(0).FDLayoutEdge;
        function t(a, g, s) { e.call(this, a, g, s); }
        t.prototype = Object.create(e.prototype);
        for (var r in e)
            t[r] = e[r];
        R.exports = t;
    }), (function (R, y, n) {
        "use strict";
        var e = n(0).LGraph;
        function t(a, g, s) { e.call(this, a, g, s); }
        t.prototype = Object.create(e.prototype);
        for (var r in e)
            t[r] = e[r];
        R.exports = t;
    }), (function (R, y, n) {
        "use strict";
        var e = n(0).LGraphManager;
        function t(a) { e.call(this, a); }
        t.prototype = Object.create(e.prototype);
        for (var r in e)
            t[r] = e[r];
        R.exports = t;
    }), (function (R, y, n) {
        "use strict";
        var e = n(0).FDLayoutNode, t = n(0).IMath;
        function r(g, s, d, i) { e.call(this, g, s, d, i); }
        r.prototype = Object.create(e.prototype);
        for (var a in e)
            r[a] = e[a];
        r.prototype.move = function () { var g = this.graphManager.getLayout(); this.displacementX = g.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY = g.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren, Math.abs(this.displacementX) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementX = g.coolingFactor * g.maxNodeDisplacement * t.sign(this.displacementX)), Math.abs(this.displacementY) > g.coolingFactor * g.maxNodeDisplacement && (this.displacementY = g.coolingFactor * g.maxNodeDisplacement * t.sign(this.displacementY)), this.child == null ? this.moveBy(this.displacementX, this.displacementY) : this.child.getNodes().length == 0 ? this.moveBy(this.displacementX, this.displacementY) : this.propogateDisplacementToChildren(this.displacementX, this.displacementY), g.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0; }, r.prototype.propogateDisplacementToChildren = function (g, s) { for (var d = this.getChild().getNodes(), i, h = 0; h < d.length; h++)
            i = d[h], i.getChild() == null ? (i.moveBy(g, s), i.displacementX += g, i.displacementY += s) : i.propogateDisplacementToChildren(g, s); }, r.prototype.setPred1 = function (g) { this.pred1 = g; }, r.prototype.getPred1 = function () { return pred1; }, r.prototype.getPred2 = function () { return pred2; }, r.prototype.setNext = function (g) { this.next = g; }, r.prototype.getNext = function () { return next; }, r.prototype.setProcessed = function (g) { this.processed = g; }, r.prototype.isProcessed = function () { return processed; }, R.exports = r;
    }), (function (R, y, n) {
        "use strict";
        var e = n(0).FDLayout, t = n(4), r = n(3), a = n(5), g = n(2), s = n(1), d = n(0).FDLayoutConstants, i = n(0).LayoutConstants, h = n(0).Point, l = n(0).PointD, p = n(0).Layout, v = n(0).Integer, L = n(0).IGeometry, c = n(0).LGraph, A = n(0).Transform;
        function T() { e.call(this), this.toBeTiled = {}; }
        T.prototype = Object.create(e.prototype);
        for (var C in e)
            T[C] = e[C];
        T.prototype.newGraphManager = function () { var o = new t(this); return this.graphManager = o, o; }, T.prototype.newGraph = function (o) { return new r(null, this.graphManager, o); }, T.prototype.newNode = function (o) { return new a(this.graphManager, o); }, T.prototype.newEdge = function (o) { return new g(null, null, o); }, T.prototype.initParameters = function () { e.prototype.initParameters.call(this, arguments), this.isSubLayout || (s.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = s.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = s.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.springConstant = d.DEFAULT_SPRING_STRENGTH, this.repulsionConstant = d.DEFAULT_REPULSION_STRENGTH, this.gravityConstant = d.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = d.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = d.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = d.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1, this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / d.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = d.CONVERGENCE_CHECK_PERIOD / this.maxIterations, this.coolingAdjuster = 1); }, T.prototype.layout = function () { var o = i.DEFAULT_CREATE_BENDS_AS_NEEDED; return o && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout(); }, T.prototype.classicLayout = function () { if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
            if (s.TREE_REDUCTION_ON_INCREMENTAL) {
                this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                var f = new Set(this.getAllNodes()), u = this.nodesWithGravity.filter(function (O) { return f.has(O); });
                this.graphManager.setAllNodesToApplyGravitation(u);
            }
        }
        else {
            var o = this.getFlatForest();
            if (o.length > 0)
                this.positionNodesRadially(o);
            else {
                this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                var f = new Set(this.getAllNodes()), u = this.nodesWithGravity.filter(function (E) { return f.has(E); });
                this.graphManager.setAllNodesToApplyGravitation(u), this.positionNodesRandomly();
            }
        } return this.initSpringEmbedder(), this.runSpringEmbedder(), !0; }, T.prototype.tick = function () { if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
            if (this.prunedNodesAll.length > 0)
                this.isTreeGrowing = !0;
            else
                return !0; if (this.totalIterations % d.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
            if (this.isConverged())
                if (this.prunedNodesAll.length > 0)
                    this.isTreeGrowing = !0;
                else
                    return !0;
            this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
        } if (this.isTreeGrowing) {
            if (this.growTreeIterations % 10 == 0)
                if (this.prunedNodesAll.length > 0) {
                    this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                    var o = new Set(this.getAllNodes()), f = this.nodesWithGravity.filter(function (D) { return o.has(D); });
                    this.graphManager.setAllNodesToApplyGravitation(f), this.graphManager.updateBounds(), this.updateGrid(), this.coolingFactor = d.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                }
                else
                    this.isTreeGrowing = !1, this.isGrowthFinished = !0;
            this.growTreeIterations++;
        } if (this.isGrowthFinished) {
            if (this.isConverged())
                return !0;
            this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), this.coolingFactor = d.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
        } var u = !this.isTreeGrowing && !this.isGrowthFinished, E = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished; return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(u, E), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1; }, T.prototype.getPositionsData = function () { for (var o = this.graphManager.getAllNodes(), f = {}, u = 0; u < o.length; u++) {
            var E = o[u].rect, D = o[u].id;
            f[D] = { id: D, x: E.getCenterX(), y: E.getCenterY(), w: E.width, h: E.height };
        } return f; }, T.prototype.runSpringEmbedder = function () { this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod; var o = !1; if (d.ANIMATE === "during")
            this.emit("layoutstarted");
        else {
            for (; !o;)
                o = this.tick();
            this.graphManager.updateBounds();
        } }, T.prototype.calculateNodesToApplyGravitationTo = function () { var o = [], f, u = this.graphManager.getGraphs(), E = u.length, D; for (D = 0; D < E; D++)
            f = u[D], f.updateConnected(), f.isConnected || (o = o.concat(f.getNodes())); return o; }, T.prototype.createBendpoints = function () { var o = []; o = o.concat(this.graphManager.getAllEdges()); var f = new Set, u; for (u = 0; u < o.length; u++) {
            var E = o[u];
            if (!f.has(E)) {
                var D = E.getSource(), O = E.getTarget();
                if (D == O)
                    E.getBendpoints().push(new l), E.getBendpoints().push(new l), this.createDummyNodesForBendpoints(E), f.add(E);
                else {
                    var m = [];
                    if (m = m.concat(D.getEdgeListToNode(O)), m = m.concat(O.getEdgeListToNode(D)), !f.has(m[0])) {
                        if (m.length > 1) {
                            var I;
                            for (I = 0; I < m.length; I++) {
                                var w = m[I];
                                w.getBendpoints().push(new l), this.createDummyNodesForBendpoints(w);
                            }
                        }
                        m.forEach(function (F) { f.add(F); });
                    }
                }
            }
            if (f.size == o.length)
                break;
        } }, T.prototype.positionNodesRadially = function (o) { for (var f = new h(0, 0), u = Math.ceil(Math.sqrt(o.length)), E = 0, D = 0, O = 0, m = new l(0, 0), I = 0; I < o.length; I++) {
            I % u == 0 && (O = 0, D = E, I != 0 && (D += s.DEFAULT_COMPONENT_SEPERATION), E = 0);
            var w = o[I], F = p.findCenterOfTree(w);
            f.x = O, f.y = D, m = T.radialLayout(w, F, f), m.y > E && (E = Math.floor(m.y)), O = Math.floor(m.x + s.DEFAULT_COMPONENT_SEPERATION);
        } this.transform(new l(i.WORLD_CENTER_X - m.x / 2, i.WORLD_CENTER_Y - m.y / 2)); }, T.radialLayout = function (o, f, u) { var E = Math.max(this.maxDiagonalInTree(o), s.DEFAULT_RADIAL_SEPARATION); T.branchRadialLayout(f, null, 0, 359, 0, E); var D = c.calculateBounds(o), O = new A; O.setDeviceOrgX(D.getMinX()), O.setDeviceOrgY(D.getMinY()), O.setWorldOrgX(u.x), O.setWorldOrgY(u.y); for (var m = 0; m < o.length; m++) {
            var I = o[m];
            I.transform(O);
        } var w = new l(D.getMaxX(), D.getMaxY()); return O.inverseTransformPoint(w); }, T.branchRadialLayout = function (o, f, u, E, D, O) { var m = (E - u + 1) / 2; m < 0 && (m += 180); var I = (m + u) % 360, w = I * L.TWO_PI / 360, F = Math.cos(w), Y = D * Math.cos(w), x = D * Math.sin(w); o.setCenter(Y, x); var M = []; M = M.concat(o.getEdges()); var G = M.length; f != null && G--; for (var S = 0, P = M.length, _, U = o.getEdgesBetween(f); U.length > 1;) {
            var X = U[0];
            U.splice(0, 1);
            var V = M.indexOf(X);
            V >= 0 && M.splice(V, 1), P--, G--;
        } f != null ? _ = (M.indexOf(U[0]) + 1) % P : _ = 0; for (var b = Math.abs(E - u) / G, H = _; S != G; H = ++H % P) {
            var nt = M[H].getOtherEnd(o);
            if (nt != f) {
                var st = (u + S * b) % 360, vt = (st + b) % 360;
                T.branchRadialLayout(nt, o, st, vt, D + O, O), S++;
            }
        } }, T.maxDiagonalInTree = function (o) { for (var f = v.MIN_VALUE, u = 0; u < o.length; u++) {
            var E = o[u], D = E.getDiagonal();
            D > f && (f = D);
        } return f; }, T.prototype.calcRepulsionRange = function () { return 2 * (this.level + 1) * this.idealEdgeLength; }, T.prototype.groupZeroDegreeMembers = function () { var o = this, f = {}; this.memberGroups = {}, this.idToDummyNode = {}; for (var u = [], E = this.graphManager.getAllNodes(), D = 0; D < E.length; D++) {
            var O = E[D], m = O.getParent();
            this.getNodeDegreeWithChildren(O) === 0 && (m.id == null || !this.getToBeTiled(m)) && u.push(O);
        } for (var D = 0; D < u.length; D++) {
            var O = u[D], I = O.getParent().id;
            typeof f[I] > "u" && (f[I] = []), f[I] = f[I].concat(O);
        } Object.keys(f).forEach(function (w) { if (f[w].length > 1) {
            var F = "DummyCompound_" + w;
            o.memberGroups[F] = f[w];
            var Y = f[w][0].getParent(), x = new a(o.graphManager);
            x.id = F, x.paddingLeft = Y.paddingLeft || 0, x.paddingRight = Y.paddingRight || 0, x.paddingBottom = Y.paddingBottom || 0, x.paddingTop = Y.paddingTop || 0, o.idToDummyNode[F] = x;
            var M = o.getGraphManager().add(o.newGraph(), x), G = Y.getChild();
            G.add(x);
            for (var S = 0; S < f[w].length; S++) {
                var P = f[w][S];
                G.remove(P), M.add(P);
            }
        } }); }, T.prototype.clearCompounds = function () { var o = {}, f = {}; this.performDFSOnCompounds(); for (var u = 0; u < this.compoundOrder.length; u++)
            f[this.compoundOrder[u].id] = this.compoundOrder[u], o[this.compoundOrder[u].id] = [].concat(this.compoundOrder[u].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[u].getChild()), this.compoundOrder[u].child = null; this.graphManager.resetAllNodes(), this.tileCompoundMembers(o, f); }, T.prototype.clearZeroDegreeMembers = function () { var o = this, f = this.tiledZeroDegreePack = []; Object.keys(this.memberGroups).forEach(function (u) { var E = o.idToDummyNode[u]; f[u] = o.tileNodes(o.memberGroups[u], E.paddingLeft + E.paddingRight), E.rect.width = f[u].width, E.rect.height = f[u].height; }); }, T.prototype.repopulateCompounds = function () { for (var o = this.compoundOrder.length - 1; o >= 0; o--) {
            var f = this.compoundOrder[o], u = f.id, E = f.paddingLeft, D = f.paddingTop;
            this.adjustLocations(this.tiledMemberPack[u], f.rect.x, f.rect.y, E, D);
        } }, T.prototype.repopulateZeroDegreeMembers = function () { var o = this, f = this.tiledZeroDegreePack; Object.keys(f).forEach(function (u) { var E = o.idToDummyNode[u], D = E.paddingLeft, O = E.paddingTop; o.adjustLocations(f[u], E.rect.x, E.rect.y, D, O); }); }, T.prototype.getToBeTiled = function (o) { var f = o.id; if (this.toBeTiled[f] != null)
            return this.toBeTiled[f]; var u = o.getChild(); if (u == null)
            return this.toBeTiled[f] = !1, !1; for (var E = u.getNodes(), D = 0; D < E.length; D++) {
            var O = E[D];
            if (this.getNodeDegree(O) > 0)
                return this.toBeTiled[f] = !1, !1;
            if (O.getChild() == null) {
                this.toBeTiled[O.id] = !1;
                continue;
            }
            if (!this.getToBeTiled(O))
                return this.toBeTiled[f] = !1, !1;
        } return this.toBeTiled[f] = !0, !0; }, T.prototype.getNodeDegree = function (o) { for (var f = o.id, u = o.getEdges(), E = 0, D = 0; D < u.length; D++) {
            var O = u[D];
            O.getSource().id !== O.getTarget().id && (E = E + 1);
        } return E; }, T.prototype.getNodeDegreeWithChildren = function (o) { var f = this.getNodeDegree(o); if (o.getChild() == null)
            return f; for (var u = o.getChild().getNodes(), E = 0; E < u.length; E++) {
            var D = u[E];
            f += this.getNodeDegreeWithChildren(D);
        } return f; }, T.prototype.performDFSOnCompounds = function () { this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes()); }, T.prototype.fillCompexOrderByDFS = function (o) { for (var f = 0; f < o.length; f++) {
            var u = o[f];
            u.getChild() != null && this.fillCompexOrderByDFS(u.getChild().getNodes()), this.getToBeTiled(u) && this.compoundOrder.push(u);
        } }, T.prototype.adjustLocations = function (o, f, u, E, D) { f += E, u += D; for (var O = f, m = 0; m < o.rows.length; m++) {
            var I = o.rows[m];
            f = O;
            for (var w = 0, F = 0; F < I.length; F++) {
                var Y = I[F];
                Y.rect.x = f, Y.rect.y = u, f += Y.rect.width + o.horizontalPadding, Y.rect.height > w && (w = Y.rect.height);
            }
            u += w + o.verticalPadding;
        } }, T.prototype.tileCompoundMembers = function (o, f) { var u = this; this.tiledMemberPack = [], Object.keys(o).forEach(function (E) { var D = f[E]; u.tiledMemberPack[E] = u.tileNodes(o[E], D.paddingLeft + D.paddingRight), D.rect.width = u.tiledMemberPack[E].width, D.rect.height = u.tiledMemberPack[E].height; }); }, T.prototype.tileNodes = function (o, f) { var u = s.TILING_PADDING_VERTICAL, E = s.TILING_PADDING_HORIZONTAL, D = { rows: [], rowWidth: [], rowHeight: [], width: 0, height: f, verticalPadding: u, horizontalPadding: E }; o.sort(function (I, w) { return I.rect.width * I.rect.height > w.rect.width * w.rect.height ? -1 : I.rect.width * I.rect.height < w.rect.width * w.rect.height ? 1 : 0; }); for (var O = 0; O < o.length; O++) {
            var m = o[O];
            D.rows.length == 0 ? this.insertNodeToRow(D, m, 0, f) : this.canAddHorizontal(D, m.rect.width, m.rect.height) ? this.insertNodeToRow(D, m, this.getShortestRowIndex(D), f) : this.insertNodeToRow(D, m, D.rows.length, f), this.shiftToLastRow(D);
        } return D; }, T.prototype.insertNodeToRow = function (o, f, u, E) { var D = E; if (u == o.rows.length) {
            var O = [];
            o.rows.push(O), o.rowWidth.push(D), o.rowHeight.push(0);
        } var m = o.rowWidth[u] + f.rect.width; o.rows[u].length > 0 && (m += o.horizontalPadding), o.rowWidth[u] = m, o.width < m && (o.width = m); var I = f.rect.height; u > 0 && (I += o.verticalPadding); var w = 0; I > o.rowHeight[u] && (w = o.rowHeight[u], o.rowHeight[u] = I, w = o.rowHeight[u] - w), o.height += w, o.rows[u].push(f); }, T.prototype.getShortestRowIndex = function (o) { for (var f = -1, u = Number.MAX_VALUE, E = 0; E < o.rows.length; E++)
            o.rowWidth[E] < u && (f = E, u = o.rowWidth[E]); return f; }, T.prototype.getLongestRowIndex = function (o) { for (var f = -1, u = Number.MIN_VALUE, E = 0; E < o.rows.length; E++)
            o.rowWidth[E] > u && (f = E, u = o.rowWidth[E]); return f; }, T.prototype.canAddHorizontal = function (o, f, u) { var E = this.getShortestRowIndex(o); if (E < 0)
            return !0; var D = o.rowWidth[E]; if (D + o.horizontalPadding + f <= o.width)
            return !0; var O = 0; o.rowHeight[E] < u && E > 0 && (O = u + o.verticalPadding - o.rowHeight[E]); var m; o.width - D >= f + o.horizontalPadding ? m = (o.height + O) / (D + f + o.horizontalPadding) : m = (o.height + O) / o.width, O = u + o.verticalPadding; var I; return o.width < f ? I = (o.height + O) / f : I = (o.height + O) / o.width, I < 1 && (I = 1 / I), m < 1 && (m = 1 / m), m < I; }, T.prototype.shiftToLastRow = function (o) { var f = this.getLongestRowIndex(o), u = o.rowWidth.length - 1, E = o.rows[f], D = E[E.length - 1], O = D.width + o.horizontalPadding; if (o.width - o.rowWidth[u] > O && f != u) {
            E.splice(-1, 1), o.rows[u].push(D), o.rowWidth[f] = o.rowWidth[f] - O, o.rowWidth[u] = o.rowWidth[u] + O, o.width = o.rowWidth[instance.getLongestRowIndex(o)];
            for (var m = Number.MIN_VALUE, I = 0; I < E.length; I++)
                E[I].height > m && (m = E[I].height);
            f > 0 && (m += o.verticalPadding);
            var w = o.rowHeight[f] + o.rowHeight[u];
            o.rowHeight[f] = m, o.rowHeight[u] < D.height + o.verticalPadding && (o.rowHeight[u] = D.height + o.verticalPadding);
            var F = o.rowHeight[f] + o.rowHeight[u];
            o.height += F - w, this.shiftToLastRow(o);
        } }, T.prototype.tilingPreLayout = function () { s.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers()); }, T.prototype.tilingPostLayout = function () { s.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds()); }, T.prototype.reduceTrees = function () { for (var o = [], f = !0, u; f;) {
            var E = this.graphManager.getAllNodes(), D = [];
            f = !1;
            for (var O = 0; O < E.length; O++)
                u = E[O], u.getEdges().length == 1 && !u.getEdges()[0].isInterGraph && u.getChild() == null && (D.push([u, u.getEdges()[0], u.getOwner()]), f = !0);
            if (f == !0) {
                for (var m = [], I = 0; I < D.length; I++)
                    D[I][0].getEdges().length == 1 && (m.push(D[I]), D[I][0].getOwner().remove(D[I][0]));
                o.push(m), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
            }
        } this.prunedNodesAll = o; }, T.prototype.growTree = function (o) { for (var f = o.length, u = o[f - 1], E, D = 0; D < u.length; D++)
            E = u[D], this.findPlaceforPrunedNode(E), E[2].add(E[0]), E[2].add(E[1], E[1].source, E[1].target); o.splice(o.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges(); }, T.prototype.findPlaceforPrunedNode = function (o) { var f, u, E = o[0]; E == o[1].source ? u = o[1].target : u = o[1].source; var D = u.startX, O = u.finishX, m = u.startY, I = u.finishY, w = 0, F = 0, Y = 0, x = 0, M = [w, Y, F, x]; if (m > 0)
            for (var G = D; G <= O; G++)
                M[0] += this.grid[G][m - 1].length + this.grid[G][m].length - 1; if (O < this.grid.length - 1)
            for (var G = m; G <= I; G++)
                M[1] += this.grid[O + 1][G].length + this.grid[O][G].length - 1; if (I < this.grid[0].length - 1)
            for (var G = D; G <= O; G++)
                M[2] += this.grid[G][I + 1].length + this.grid[G][I].length - 1; if (D > 0)
            for (var G = m; G <= I; G++)
                M[3] += this.grid[D - 1][G].length + this.grid[D][G].length - 1; for (var S = v.MAX_VALUE, P, _, U = 0; U < M.length; U++)
            M[U] < S ? (S = M[U], P = 1, _ = U) : M[U] == S && P++; if (P == 3 && S == 0)
            M[0] == 0 && M[1] == 0 && M[2] == 0 ? f = 1 : M[0] == 0 && M[1] == 0 && M[3] == 0 ? f = 0 : M[0] == 0 && M[2] == 0 && M[3] == 0 ? f = 3 : M[1] == 0 && M[2] == 0 && M[3] == 0 && (f = 2);
        else if (P == 2 && S == 0) {
            var X = Math.floor(Math.random() * 2);
            M[0] == 0 && M[1] == 0 ? X == 0 ? f = 0 : f = 1 : M[0] == 0 && M[2] == 0 ? X == 0 ? f = 0 : f = 2 : M[0] == 0 && M[3] == 0 ? X == 0 ? f = 0 : f = 3 : M[1] == 0 && M[2] == 0 ? X == 0 ? f = 1 : f = 2 : M[1] == 0 && M[3] == 0 ? X == 0 ? f = 1 : f = 3 : X == 0 ? f = 2 : f = 3;
        }
        else if (P == 4 && S == 0) {
            var X = Math.floor(Math.random() * 4);
            f = X;
        }
        else
            f = _; f == 0 ? E.setCenter(u.getCenterX(), u.getCenterY() - u.getHeight() / 2 - d.DEFAULT_EDGE_LENGTH - E.getHeight() / 2) : f == 1 ? E.setCenter(u.getCenterX() + u.getWidth() / 2 + d.DEFAULT_EDGE_LENGTH + E.getWidth() / 2, u.getCenterY()) : f == 2 ? E.setCenter(u.getCenterX(), u.getCenterY() + u.getHeight() / 2 + d.DEFAULT_EDGE_LENGTH + E.getHeight() / 2) : E.setCenter(u.getCenterX() - u.getWidth() / 2 - d.DEFAULT_EDGE_LENGTH - E.getWidth() / 2, u.getCenterY()); }, R.exports = T;
    }), (function (R, y, n) {
        "use strict";
        var e = {};
        e.layoutBase = n(0), e.CoSEConstants = n(1), e.CoSEEdge = n(2), e.CoSEGraph = n(3), e.CoSEGraphManager = n(4), e.CoSELayout = n(6), e.CoSENode = n(5), R.exports = e;
    })]); }); });
var at = q((j, it) => { (function (R, y) { typeof j == "object" && typeof it == "object" ? it.exports = y(rt()) : typeof define == "function" && define.amd ? define(["cose-base"], y) : typeof j == "object" ? j.cytoscapeCoseBilkent = y(rt()) : R.cytoscapeCoseBilkent = y(R.coseBase); })(j, function (N) { return (function (R) { var y = {}; function n(e) { if (y[e])
    return y[e].exports; var t = y[e] = { i: e, l: !1, exports: {} }; return R[e].call(t.exports, t, t.exports, n), t.l = !0, t.exports; } return n.m = R, n.c = y, n.i = function (e) { return e; }, n.d = function (e, t, r) { n.o(e, t) || Object.defineProperty(e, t, { configurable: !1, enumerable: !0, get: r }); }, n.n = function (e) { var t = e && e.__esModule ? function () { return e.default; } : function () { return e; }; return n.d(t, "a", t), t; }, n.o = function (e, t) { return Object.prototype.hasOwnProperty.call(e, t); }, n.p = "", n(n.s = 1); })([(function (R, y) { R.exports = N; }), (function (R, y, n) {
        "use strict";
        var e = n(0).layoutBase.LayoutConstants, t = n(0).layoutBase.FDLayoutConstants, r = n(0).CoSEConstants, a = n(0).CoSELayout, g = n(0).CoSENode, s = n(0).layoutBase.PointD, d = n(0).layoutBase.DimensionD, i = { ready: function () { }, stop: function () { }, quality: "default", nodeDimensionsIncludeLabels: !1, refresh: 30, fit: !0, padding: 10, randomize: !0, nodeRepulsion: 4500, idealEdgeLength: 50, edgeElasticity: .45, nestingFactor: .1, gravity: .25, numIter: 2500, tile: !0, animate: "end", animationDuration: 500, tilingPaddingVertical: 10, tilingPaddingHorizontal: 10, gravityRangeCompound: 1.5, gravityCompound: 1, gravityRange: 3.8, initialEnergyOnIncremental: .5 };
        function h(L, c) { var A = {}; for (var T in L)
            A[T] = L[T]; for (var T in c)
            A[T] = c[T]; return A; }
        function l(L) { this.options = h(i, L), p(this.options); }
        var p = function (c) { c.nodeRepulsion != null && (r.DEFAULT_REPULSION_STRENGTH = t.DEFAULT_REPULSION_STRENGTH = c.nodeRepulsion), c.idealEdgeLength != null && (r.DEFAULT_EDGE_LENGTH = t.DEFAULT_EDGE_LENGTH = c.idealEdgeLength), c.edgeElasticity != null && (r.DEFAULT_SPRING_STRENGTH = t.DEFAULT_SPRING_STRENGTH = c.edgeElasticity), c.nestingFactor != null && (r.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = t.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = c.nestingFactor), c.gravity != null && (r.DEFAULT_GRAVITY_STRENGTH = t.DEFAULT_GRAVITY_STRENGTH = c.gravity), c.numIter != null && (r.MAX_ITERATIONS = t.MAX_ITERATIONS = c.numIter), c.gravityRange != null && (r.DEFAULT_GRAVITY_RANGE_FACTOR = t.DEFAULT_GRAVITY_RANGE_FACTOR = c.gravityRange), c.gravityCompound != null && (r.DEFAULT_COMPOUND_GRAVITY_STRENGTH = t.DEFAULT_COMPOUND_GRAVITY_STRENGTH = c.gravityCompound), c.gravityRangeCompound != null && (r.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = t.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = c.gravityRangeCompound), c.initialEnergyOnIncremental != null && (r.DEFAULT_COOLING_FACTOR_INCREMENTAL = t.DEFAULT_COOLING_FACTOR_INCREMENTAL = c.initialEnergyOnIncremental), c.quality == "draft" ? e.QUALITY = 0 : c.quality == "proof" ? e.QUALITY = 2 : e.QUALITY = 1, r.NODE_DIMENSIONS_INCLUDE_LABELS = t.NODE_DIMENSIONS_INCLUDE_LABELS = e.NODE_DIMENSIONS_INCLUDE_LABELS = c.nodeDimensionsIncludeLabels, r.DEFAULT_INCREMENTAL = t.DEFAULT_INCREMENTAL = e.DEFAULT_INCREMENTAL = !c.randomize, r.ANIMATE = t.ANIMATE = e.ANIMATE = c.animate, r.TILE = c.tile, r.TILING_PADDING_VERTICAL = typeof c.tilingPaddingVertical == "function" ? c.tilingPaddingVertical.call() : c.tilingPaddingVertical, r.TILING_PADDING_HORIZONTAL = typeof c.tilingPaddingHorizontal == "function" ? c.tilingPaddingHorizontal.call() : c.tilingPaddingHorizontal; };
        l.prototype.run = function () { var L, c, A = this.options, T = this.idToLNode = {}, C = this.layout = new a, o = this; o.stopped = !1, this.cy = this.options.cy, this.cy.trigger({ type: "layoutstart", layout: this }); var f = C.newGraphManager(); this.gm = f; var u = this.options.eles.nodes(), E = this.options.eles.edges(); this.root = f.addRoot(), this.processChildrenList(this.root, this.getTopMostNodes(u), C); for (var D = 0; D < E.length; D++) {
            var O = E[D], m = this.idToLNode[O.data("source")], I = this.idToLNode[O.data("target")];
            if (m !== I && m.getEdgesBetween(I).length == 0) {
                var w = f.add(C.newEdge(), m, I);
                w.id = O.id();
            }
        } var F = function (M, G) { typeof M == "number" && (M = G); var S = M.data("id"), P = o.idToLNode[S]; return { x: P.getRect().getCenterX(), y: P.getRect().getCenterY() }; }, Y = function x() { for (var M = function () { A.fit && A.cy.fit(A.eles, A.padding), L || (L = !0, o.cy.one("layoutready", A.ready), o.cy.trigger({ type: "layoutready", layout: o })); }, G = o.options.refresh, S, P = 0; P < G && !S; P++)
            S = o.stopped || o.layout.tick(); if (S) {
            C.checkLayoutSuccess() && !C.isSubLayout && C.doPostLayout(), C.tilingPostLayout && C.tilingPostLayout(), C.isLayoutFinished = !0, o.options.eles.nodes().positions(F), M(), o.cy.one("layoutstop", o.options.stop), o.cy.trigger({ type: "layoutstop", layout: o }), c && cancelAnimationFrame(c), L = !1;
            return;
        } var _ = o.layout.getPositionsData(); A.eles.nodes().positions(function (U, X) { if (typeof U == "number" && (U = X), !U.isParent()) {
            for (var V = U.id(), b = _[V], H = U; b == null && (b = _[H.data("parent")] || _["DummyCompound_" + H.data("parent")], _[V] = b, H = H.parent()[0], H != null);)
                ;
            return b != null ? { x: b.x, y: b.y } : { x: U.position("x"), y: U.position("y") };
        } }), M(), c = requestAnimationFrame(x); }; return C.addListener("layoutstarted", function () { o.options.animate === "during" && (c = requestAnimationFrame(Y)); }), C.runLayout(), this.options.animate !== "during" && (o.options.eles.nodes().not(":parent").layoutPositions(o, o.options, F), L = !1), this; }, l.prototype.getTopMostNodes = function (L) { for (var c = {}, A = 0; A < L.length; A++)
            c[L[A].id()] = !0; var T = L.filter(function (C, o) { typeof C == "number" && (C = o); for (var f = C.parent()[0]; f != null;) {
            if (c[f.id()])
                return !1;
            f = f.parent()[0];
        } return !0; }); return T; }, l.prototype.processChildrenList = function (L, c, A) { for (var T = c.length, C = 0; C < T; C++) {
            var o = c[C], f = o.children(), u, E = o.layoutDimensions({ nodeDimensionsIncludeLabels: this.options.nodeDimensionsIncludeLabels });
            if (o.outerWidth() != null && o.outerHeight() != null ? u = L.add(new g(A.graphManager, new s(o.position("x") - E.w / 2, o.position("y") - E.h / 2), new d(parseFloat(E.w), parseFloat(E.h)))) : u = L.add(new g(this.graphManager)), u.id = o.data("id"), u.paddingLeft = parseInt(o.css("padding")), u.paddingTop = parseInt(o.css("padding")), u.paddingRight = parseInt(o.css("padding")), u.paddingBottom = parseInt(o.css("padding")), this.options.nodeDimensionsIncludeLabels && o.isParent()) {
                var D = o.boundingBox({ includeLabels: !0, includeNodes: !1 }).w, O = o.boundingBox({ includeLabels: !0, includeNodes: !1 }).h, m = o.css("text-halign");
                u.labelWidth = D, u.labelHeight = O, u.labelPos = m;
            }
            if (this.idToLNode[o.data("id")] = u, isNaN(u.rect.x) && (u.rect.x = 0), isNaN(u.rect.y) && (u.rect.y = 0), f != null && f.length > 0) {
                var I;
                I = A.getGraphManager().add(A.newGraph(), u), this.processChildrenList(I, f, A);
            }
        } }, l.prototype.stop = function () { return this.stopped = !0, this; };
        var v = function (c) { c("layout", "cose-bilkent", l); };
        typeof cytoscape < "u" && v(cytoscape), R.exports = v;
    })]); }); });
var ht = yt(at(), 1);
z.use(ht.default);
function lt(N, R) { N.forEach(y => { let n = { id: y.id, labelText: y.label, height: y.height, width: y.width, padding: y.padding ?? 0 }; Object.keys(y).forEach(e => { ["id", "label", "height", "width", "padding", "x", "y"].includes(e) || (n[e] = y[e]); }), R.add({ group: "nodes", data: n, position: { x: y.x ?? 0, y: y.y ?? 0 } }); }); }
W(lt, "addNodes");
function ut(N, R) { N.forEach(y => { let n = { id: y.id, source: y.start, target: y.end }; Object.keys(y).forEach(e => { ["id", "start", "end"].includes(e) || (n[e] = y[e]); }), R.add({ group: "edges", data: n }); }); }
W(ut, "addEdges");
function gt(N) { return new Promise(R => { let y = ot("body").append("div").attr("id", "cy").attr("style", "display:none"), n = z({ container: document.getElementById("cy"), style: [{ selector: "edge", style: { "curve-style": "bezier" } }] }); y.remove(), lt(N.nodes, n), ut(N.edges, n), n.nodes().forEach(function (t) { t.layoutDimensions = () => { let r = t.data(); return { w: r.width, h: r.height }; }; }); let e = { name: "cose-bilkent", quality: "proof", styleEnabled: !1, animate: !1 }; n.layout(e).run(), n.ready(t => { Z.info("Cytoscape ready", t), R(n); }); }); }
W(gt, "createCytoscapeInstance");
function ft(N) { return N.nodes().map(R => { let y = R.data(), n = R.position(), e = { id: y.id, x: n.x, y: n.y }; return Object.keys(y).forEach(t => { t !== "id" && (e[t] = y[t]); }), e; }); }
W(ft, "extractPositionedNodes");
function ct(N) { return N.edges().map(R => { let y = R.data(), n = R._private.rscratch, e = { id: y.id, source: y.source, target: y.target, startX: n.startX, startY: n.startY, midX: n.midX, midY: n.midY, endX: n.endX, endY: n.endY }; return Object.keys(y).forEach(t => { ["id", "source", "target"].includes(t) || (e[t] = y[t]); }), e; }); }
W(ct, "extractPositionedEdges");
function pt(N, R) { return k(this, null, function* () { Z.debug("Starting cose-bilkent layout algorithm"); try {
    dt(N);
    let y = yield gt(N), n = ft(y), e = ct(y);
    return Z.debug(`Layout completed: ${n.length} nodes, ${e.length} edges`), { nodes: n, edges: e };
}
catch (y) {
    throw Z.error("Error in cose-bilkent layout algorithm:", y), y;
} }); }
W(pt, "executeCoseBilkentLayout");
function dt(N) { if (!N)
    throw new Error("Layout data is required"); if (!N.config)
    throw new Error("Configuration is required in layout data"); if (!N.rootNode)
    throw new Error("Root node is required"); if (!N.nodes || !Array.isArray(N.nodes))
    throw new Error("No nodes found in layout data"); if (!Array.isArray(N.edges))
    throw new Error("Edges array is required in layout data"); return !0; }
W(dt, "validateLayoutData");
var Et = W((d, i, h, l) => k(null, [d, i, h, l], function* (N, R, { insertCluster: y, insertEdge: n, insertEdgeLabel: e, insertMarkers: t, insertNode: r, log: a, positionEdgeLabel: g }, { algorithm: s }) { let p = {}, v = {}, L = R.select("g"); t(L, N.markers, N.type, N.diagramId); let c = L.insert("g").attr("class", "subgraphs"), A = L.insert("g").attr("class", "edgePaths"), T = L.insert("g").attr("class", "edgeLabels"), C = L.insert("g").attr("class", "nodes"); a.debug("Inserting nodes into DOM for dimension calculation"), yield Promise.all(N.nodes.map(u => k(null, null, function* () { if (u.isGroup) {
    let E = B({}, u);
    v[u.id] = E, p[u.id] = E, yield y(c, u);
}
else {
    let E = B({}, u);
    p[u.id] = E;
    let D = yield r(C, u, { config: N.config, dir: N.direction || "TB" }), O = D.node().getBBox();
    E.width = O.width, E.height = O.height, E.domId = D, a.debug(`Node ${u.id} dimensions: ${O.width}x${O.height}`);
} }))), a.debug("Running cose-bilkent layout algorithm"); let o = K(B({}, N), { nodes: N.nodes.map(u => { let E = p[u.id]; return K(B({}, u), { width: E.width, height: E.height }); }) }), f = yield pt(o, N.config); a.debug("Positioning nodes based on layout results"), f.nodes.forEach(u => { let E = p[u.id]; E?.domId && (E.domId.attr("transform", `translate(${u.x}, ${u.y})`), E.x = u.x, E.y = u.y, a.debug(`Positioned node ${E.id} at center (${u.x}, ${u.y})`)); }), f.edges.forEach(u => { let E = N.edges.find(D => D.id === u.id); E && (E.points = [{ x: u.startX, y: u.startY }, { x: u.midX, y: u.midY }, { x: u.endX, y: u.endY }]); }), a.debug("Inserting and positioning edges"), yield Promise.all(N.edges.map(u => k(null, null, function* () { let E = yield e(T, u), D = p[u.start ?? ""], O = p[u.end ?? ""]; if (D && O) {
    let m = f.edges.find(I => I.id === u.id);
    if (m) {
        a.debug("APA01 positionedEdge", m);
        let I = B({}, u), w = n(A, I, v, N.type, D, O, N.diagramId);
        g(I, w);
    }
    else {
        let I = K(B({}, u), { points: [{ x: D.x || 0, y: D.y || 0 }, { x: O.x || 0, y: O.y || 0 }] }), w = n(A, I, v, N.type, D, O, N.diagramId);
        g(I, w);
    }
} }))), a.debug("Cose-bilkent rendering completed"); }), "render"), Nt = Et;
export { Nt as render };
