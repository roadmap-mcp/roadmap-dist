import { a as h } from "@nf-internal/chunk-7RHXFCZM";
import { a as u } from "@nf-internal/chunk-XID2BBVI";
import * as p from "@angular/core";
import { inject as m, CSP_NONCE as v, NgZone as y } from "@angular/core";
import { Subject as M, combineLatest as w, concat as g, Observable as j } from "rxjs";
import { take as S, skip as k, debounceTime as I, map as l, startWith as L, takeUntil as O } from "rxjs/operators";
var f = new Set, a, Q = (() => { class e {
    _platform = m(h);
    _nonce = m(v, { optional: !0 });
    _matchMedia;
    constructor() { this._matchMedia = this._platform.isBrowser && window.matchMedia ? window.matchMedia.bind(window) : E; }
    matchMedia(t) { return (this._platform.WEBKIT || this._platform.BLINK) && D(t, this._nonce), this._matchMedia(t); }
    static \u0275fac = function (r) { return new (r || e); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function D(e, i) { if (!f.has(e))
    try {
        a || (a = document.createElement("style"), i && a.setAttribute("nonce", i), a.setAttribute("type", "text/css"), document.head.appendChild(a)), a.sheet && (a.sheet.insertRule(`@media ${e} {body{ }}`, 0), f.add(e));
    }
    catch (t) {
        console.error(t);
    } }
function E(e) { return { matches: e === "all" || e === "", media: e, addListener: () => { }, removeListener: () => { } }; }
var F = (() => { class e {
    _mediaMatcher = m(Q);
    _zone = m(y);
    _queries = new Map;
    _destroySubject = new M;
    constructor() { }
    ngOnDestroy() { this._destroySubject.next(), this._destroySubject.complete(); }
    isMatched(t) { return b(u(t)).some(c => this._registerQuery(c).mql.matches); }
    observe(t) { let c = b(u(t)).map(s => this._registerQuery(s).observable), o = w(c); return o = g(o.pipe(S(1)), o.pipe(k(1), I(0))), o.pipe(l(s => { let n = { matches: !1, breakpoints: {} }; return s.forEach(({ matches: d, query: _ }) => { n.matches = n.matches || d, n.breakpoints[_] = d; }), n; })); }
    _registerQuery(t) { if (this._queries.has(t))
        return this._queries.get(t); let r = this._mediaMatcher.matchMedia(t), o = { observable: new j(s => { let n = d => this._zone.run(() => s.next(d)); return r.addListener(n), () => { r.removeListener(n); }; }).pipe(L(r), l(({ matches: s }) => ({ query: t, matches: s })), O(this._destroySubject)), mql: r }; return this._queries.set(t, o), o; }
    static \u0275fac = function (r) { return new (r || e); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function b(e) { return e.map(i => i.split(",")).reduce((i, t) => i.concat(t)).map(i => i.trim()); }
export { Q as a, F as b };
