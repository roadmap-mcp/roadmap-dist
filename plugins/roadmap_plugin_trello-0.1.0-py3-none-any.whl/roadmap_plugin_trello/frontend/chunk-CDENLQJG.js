import { a as i } from "@nf-internal/chunk-YUSHYV7C";
function t(c, e) { c.accDescr && e.setAccDescription?.(c.accDescr), c.accTitle && e.setAccTitle?.(c.accTitle), c.title && e.setDiagramTitle?.(c.title); }
i(t, "populateCommonDb");
export { t as a };
