import { a as r, b as o } from "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { r as RailroadEbnfModule, o as createRailroadEbnfServices };
