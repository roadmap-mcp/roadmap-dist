import { a, b as m, c as p } from "@nf-internal/chunk-FAXKR3FL";
import { a as s } from "@nf-internal/chunk-CDENLQJG";
import { b as l } from "@nf-internal/chunk-ZLCFE4AJ";
import { b as i } from "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-YQ6X4GJP";
import "@nf-internal/chunk-LEJRRF65";
import { b as n } from "@nf-internal/chunk-RZWXGGKD";
import { a as t } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var f = i().RailroadPeg.parser.LangiumParser, c = t(e => { let r = e.alternatives.map(d); return r.length === 1 ? r[0] : { type: "choice", alternatives: r }; }, "transformOrderedChoice"), d = t(e => { let r = e.elements.map(P); return r.length === 1 ? r[0] : { type: "sequence", elements: r }; }, "transformSequence"), P = t(e => { let r = g(e.suffix); return e.operator ? { type: "special", text: e.operator === "&" ? `&${u(r)}` : `!${u(r)}` } : r; }, "transformPrefix"), u = t(e => { switch (e.type) {
    case "terminal": return `"${e.value}"`;
    case "nonterminal": return e.name;
    case "special": return e.text;
    default: return "(...)";
} }, "nodeToLabel"), g = t(e => { let r = v(e.primary); if (!e.operator)
    return r; switch (e.operator) {
    case "?": return { type: "optional", element: r };
    case "*": return { type: "repetition", element: r, min: 0, max: 1 / 0 };
    case "+": return { type: "repetition", element: r, min: 1, max: 1 / 0 };
    default: throw new Error(`Unsupported PEG suffix operator: ${e.operator}`);
} }, "transformSuffix"), v = t(e => { switch (e.$type) {
    case "PegLiteral": return { type: "terminal", value: e.value };
    case "PegIdentifier": return { type: "nonterminal", name: e.name };
    case "PegGroup": return c(e.element);
    case "PegAny": return { type: "special", text: e.dot };
    default: throw new Error(`Unsupported PEG primary node: ${e.$type}`);
} }, "transformPrimary"), y = t(e => ({ name: e.name, definition: c(e.definition) }), "transformRule"), h = t(e => { s(e, a), e.title && a.setTitle(e.title), e.rules.map(r => a.addRule(y(r))); }, "populateDb"), b = { parse: t(e => { a.clear(), n.debug("[PEG Parser] Starting Langium parse"); let r = f.parse(e); if (r.lexerErrors.length > 0 || r.parserErrors.length > 0)
        throw new l(r); let o = r.value; n.debug("[PEG Parser] Parsed rules:", o.rules.length), h(o), n.debug("[PEG Parser] Parse complete"); }, "parse"), parser: { yy: a } }, R = { parser: b, db: a, renderer: p, styles: m };
export { R as diagram };
