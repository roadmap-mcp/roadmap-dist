import { a as it } from "@nf-internal/chunk-3UW5LP2A";
import { a as rt } from "@nf-internal/chunk-WVCFK4LD";
import { b as tt, c as st } from "@nf-internal/chunk-4PKWXC3U";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { p as et } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { T as We, U as je, V as Ge, W as ze, X as Xe, Y as Je, Z as Ze, _ as ye, u as Ce } from "@nf-internal/chunk-LEJRRF65";
import { b as ke } from "@nf-internal/chunk-RZWXGGKD";
import { a as u, b as Ke } from "@nf-internal/chunk-YUSHYV7C";
import { f as He } from "@nf-internal/chunk-OSQMNGTH";
var Ae = (function () {
    var e = u(function ($, r, n, l) { for (n = n || {}, l = $.length; l--; n[$[l]] = r)
        ; return n; }, "o"), f = [1, 3], h = [1, 4], o = [1, 5], i = [1, 6], c = [5, 6, 8, 9, 11, 13, 21, 22, 23, 24, 41, 42, 43, 44, 45, 46, 54, 72, 74, 77, 89, 90], k = [1, 22], E = [2, 7], R = [1, 26], _ = [1, 27], I = [1, 28], q = [1, 29], C = [1, 33], A = [1, 34], V = [1, 35], v = [1, 36], L = [1, 37], x = [1, 38], O = [1, 24], w = [1, 31], D = [1, 32], M = [1, 30], p = [1, 39], b = [1, 40], d = [5, 8, 9, 11, 13, 21, 22, 23, 24, 41, 42, 43, 44, 45, 46, 54, 72, 74, 77, 89, 90], P = [1, 61], X = [89, 90], Ve = [5, 8, 9, 11, 13, 21, 22, 23, 24, 27, 29, 41, 42, 43, 44, 45, 46, 54, 61, 63, 72, 74, 75, 76, 77, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90], de = [27, 29], ve = [1, 70], Le = [1, 71], xe = [1, 72], Oe = [1, 73], we = [1, 74], De = [1, 75], Me = [1, 76], Z = [1, 83], U = [1, 80], ee = [1, 84], te = [1, 85], se = [1, 86], ie = [1, 87], re = [1, 88], ne = [1, 89], ae = [1, 90], le = [1, 91], ce = [1, 92], Ee = [5, 8, 9, 11, 13, 21, 22, 23, 24, 27, 41, 42, 43, 44, 45, 46, 54, 72, 74, 75, 76, 77, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90], Y = [63, 64], Fe = [1, 101], $e = [5, 8, 9, 11, 13, 21, 22, 23, 24, 41, 42, 43, 44, 45, 46, 54, 72, 74, 76, 77, 89, 90], T = [5, 8, 9, 11, 13, 21, 22, 23, 24, 41, 42, 43, 44, 45, 46, 54, 72, 74, 75, 76, 77, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90], B = [1, 110], Q = [1, 106], H = [1, 107], K = [1, 108], W = [1, 109], j = [1, 111], oe = [1, 116], he = [1, 117], ue = [1, 114], fe = [1, 115], _e = { trace: u(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, directive: 4, NEWLINE: 5, RD: 6, diagram: 7, EOF: 8, acc_title: 9, acc_title_value: 10, acc_descr: 11, acc_descr_value: 12, acc_descr_multiline_value: 13, requirementDef: 14, elementDef: 15, relationshipDef: 16, direction: 17, styleStatement: 18, classDefStatement: 19, classStatement: 20, direction_tb: 21, direction_bt: 22, direction_rl: 23, direction_lr: 24, requirementType: 25, requirementName: 26, STRUCT_START: 27, requirementBody: 28, STYLE_SEPARATOR: 29, idList: 30, ID: 31, COLONSEP: 32, id: 33, TEXT: 34, text: 35, RISK: 36, riskLevel: 37, VERIFYMTHD: 38, verifyType: 39, STRUCT_STOP: 40, REQUIREMENT: 41, FUNCTIONAL_REQUIREMENT: 42, INTERFACE_REQUIREMENT: 43, PERFORMANCE_REQUIREMENT: 44, PHYSICAL_REQUIREMENT: 45, DESIGN_CONSTRAINT: 46, LOW_RISK: 47, MED_RISK: 48, HIGH_RISK: 49, VERIFY_ANALYSIS: 50, VERIFY_DEMONSTRATION: 51, VERIFY_INSPECTION: 52, VERIFY_TEST: 53, ELEMENT: 54, elementName: 55, elementBody: 56, TYPE: 57, type: 58, DOCREF: 59, ref: 60, END_ARROW_L: 61, relationship: 62, LINE: 63, END_ARROW_R: 64, CONTAINS: 65, COPIES: 66, DERIVES: 67, SATISFIES: 68, VERIFIES: 69, REFINES: 70, TRACES: 71, CLASSDEF: 72, stylesOpt: 73, CLASS: 74, ALPHA: 75, COMMA: 76, STYLE: 77, style: 78, styleComponent: 79, NUM: 80, COLON: 81, UNIT: 82, SPACE: 83, BRKT: 84, PCT: 85, MINUS: 86, LABEL: 87, SEMICOLON: 88, unqString: 89, qString: 90, $accept: 0, $end: 1 }, terminals_: { 2: "error", 5: "NEWLINE", 6: "RD", 8: "EOF", 9: "acc_title", 10: "acc_title_value", 11: "acc_descr", 12: "acc_descr_value", 13: "acc_descr_multiline_value", 21: "direction_tb", 22: "direction_bt", 23: "direction_rl", 24: "direction_lr", 27: "STRUCT_START", 29: "STYLE_SEPARATOR", 31: "ID", 32: "COLONSEP", 34: "TEXT", 36: "RISK", 38: "VERIFYMTHD", 40: "STRUCT_STOP", 41: "REQUIREMENT", 42: "FUNCTIONAL_REQUIREMENT", 43: "INTERFACE_REQUIREMENT", 44: "PERFORMANCE_REQUIREMENT", 45: "PHYSICAL_REQUIREMENT", 46: "DESIGN_CONSTRAINT", 47: "LOW_RISK", 48: "MED_RISK", 49: "HIGH_RISK", 50: "VERIFY_ANALYSIS", 51: "VERIFY_DEMONSTRATION", 52: "VERIFY_INSPECTION", 53: "VERIFY_TEST", 54: "ELEMENT", 57: "TYPE", 59: "DOCREF", 61: "END_ARROW_L", 63: "LINE", 64: "END_ARROW_R", 65: "CONTAINS", 66: "COPIES", 67: "DERIVES", 68: "SATISFIES", 69: "VERIFIES", 70: "REFINES", 71: "TRACES", 72: "CLASSDEF", 74: "CLASS", 75: "ALPHA", 76: "COMMA", 77: "STYLE", 80: "NUM", 81: "COLON", 82: "UNIT", 83: "SPACE", 84: "BRKT", 85: "PCT", 86: "MINUS", 87: "LABEL", 88: "SEMICOLON", 89: "unqString", 90: "qString" }, productions_: [0, [3, 3], [3, 2], [3, 4], [4, 2], [4, 2], [4, 1], [7, 0], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [17, 1], [17, 1], [17, 1], [17, 1], [14, 5], [14, 7], [28, 5], [28, 5], [28, 5], [28, 5], [28, 2], [28, 1], [25, 1], [25, 1], [25, 1], [25, 1], [25, 1], [25, 1], [37, 1], [37, 1], [37, 1], [39, 1], [39, 1], [39, 1], [39, 1], [15, 5], [15, 7], [56, 5], [56, 5], [56, 2], [56, 1], [16, 5], [16, 5], [62, 1], [62, 1], [62, 1], [62, 1], [62, 1], [62, 1], [62, 1], [19, 3], [20, 3], [20, 3], [30, 1], [30, 3], [30, 1], [30, 3], [18, 3], [73, 1], [73, 3], [78, 1], [78, 2], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [79, 1], [26, 1], [26, 1], [33, 1], [33, 1], [35, 1], [35, 1], [55, 1], [55, 1], [58, 1], [58, 1], [60, 1], [60, 1]], performAction: u(function (r, n, l, s, m, t, me) { var a = t.length - 1; switch (m) {
            case 4:
                this.$ = t[a].trim(), s.setAccTitle(this.$);
                break;
            case 5:
            case 6:
                this.$ = t[a].trim(), s.setAccDescription(this.$);
                break;
            case 7:
                this.$ = [];
                break;
            case 17:
                s.setDirection("TB");
                break;
            case 18:
                s.setDirection("BT");
                break;
            case 19:
                s.setDirection("RL");
                break;
            case 20:
                s.setDirection("LR");
                break;
            case 21:
                s.addRequirement(t[a - 3], t[a - 4]);
                break;
            case 22:
                s.addRequirement(t[a - 5], t[a - 6]), s.setClass([t[a - 5]], t[a - 3]);
                break;
            case 23:
                s.setNewReqId(t[a - 2]);
                break;
            case 24:
                s.setNewReqText(t[a - 2]);
                break;
            case 25:
                s.setNewReqRisk(t[a - 2]);
                break;
            case 26:
                s.setNewReqVerifyMethod(t[a - 2]);
                break;
            case 29:
                this.$ = s.RequirementType.REQUIREMENT;
                break;
            case 30:
                this.$ = s.RequirementType.FUNCTIONAL_REQUIREMENT;
                break;
            case 31:
                this.$ = s.RequirementType.INTERFACE_REQUIREMENT;
                break;
            case 32:
                this.$ = s.RequirementType.PERFORMANCE_REQUIREMENT;
                break;
            case 33:
                this.$ = s.RequirementType.PHYSICAL_REQUIREMENT;
                break;
            case 34:
                this.$ = s.RequirementType.DESIGN_CONSTRAINT;
                break;
            case 35:
                this.$ = s.RiskLevel.LOW_RISK;
                break;
            case 36:
                this.$ = s.RiskLevel.MED_RISK;
                break;
            case 37:
                this.$ = s.RiskLevel.HIGH_RISK;
                break;
            case 38:
                this.$ = s.VerifyType.VERIFY_ANALYSIS;
                break;
            case 39:
                this.$ = s.VerifyType.VERIFY_DEMONSTRATION;
                break;
            case 40:
                this.$ = s.VerifyType.VERIFY_INSPECTION;
                break;
            case 41:
                this.$ = s.VerifyType.VERIFY_TEST;
                break;
            case 42:
                s.addElement(t[a - 3]);
                break;
            case 43:
                s.addElement(t[a - 5]), s.setClass([t[a - 5]], t[a - 3]);
                break;
            case 44:
                s.setNewElementType(t[a - 2]);
                break;
            case 45:
                s.setNewElementDocRef(t[a - 2]);
                break;
            case 48:
                s.addRelationship(t[a - 2], t[a], t[a - 4]);
                break;
            case 49:
                s.addRelationship(t[a - 2], t[a - 4], t[a]);
                break;
            case 50:
                this.$ = s.Relationships.CONTAINS;
                break;
            case 51:
                this.$ = s.Relationships.COPIES;
                break;
            case 52:
                this.$ = s.Relationships.DERIVES;
                break;
            case 53:
                this.$ = s.Relationships.SATISFIES;
                break;
            case 54:
                this.$ = s.Relationships.VERIFIES;
                break;
            case 55:
                this.$ = s.Relationships.REFINES;
                break;
            case 56:
                this.$ = s.Relationships.TRACES;
                break;
            case 57:
                this.$ = t[a - 2], s.defineClass(t[a - 1], t[a]);
                break;
            case 58:
                s.setClass(t[a - 1], t[a]);
                break;
            case 59:
                s.setClass([t[a - 2]], t[a]);
                break;
            case 60:
            case 62:
                this.$ = [t[a]];
                break;
            case 61:
            case 63:
                this.$ = t[a - 2].concat([t[a]]);
                break;
            case 64:
                this.$ = t[a - 2], s.setCssStyle(t[a - 1], t[a]);
                break;
            case 65:
                this.$ = [t[a]];
                break;
            case 66:
                t[a - 2].push(t[a]), this.$ = t[a - 2];
                break;
            case 68:
                this.$ = t[a - 1] + t[a];
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 6: f, 9: h, 11: o, 13: i }, { 1: [3] }, { 3: 8, 4: 2, 5: [1, 7], 6: f, 9: h, 11: o, 13: i }, { 5: [1, 9] }, { 10: [1, 10] }, { 12: [1, 11] }, e(c, [2, 6]), { 3: 12, 4: 2, 6: f, 9: h, 11: o, 13: i }, { 1: [2, 2] }, { 4: 17, 5: k, 7: 13, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, e(c, [2, 4]), e(c, [2, 5]), { 1: [2, 1] }, { 8: [1, 41] }, { 4: 17, 5: k, 7: 42, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 43, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 44, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 45, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 46, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 47, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 48, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 49, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 4: 17, 5: k, 7: 50, 8: E, 9: h, 11: o, 13: i, 14: 14, 15: 15, 16: 16, 17: 18, 18: 19, 19: 20, 20: 21, 21: R, 22: _, 23: I, 24: q, 25: 23, 33: 25, 41: C, 42: A, 43: V, 44: v, 45: L, 46: x, 54: O, 72: w, 74: D, 77: M, 89: p, 90: b }, { 26: 51, 89: [1, 52], 90: [1, 53] }, { 55: 54, 89: [1, 55], 90: [1, 56] }, { 29: [1, 59], 61: [1, 57], 63: [1, 58] }, e(d, [2, 17]), e(d, [2, 18]), e(d, [2, 19]), e(d, [2, 20]), { 30: 60, 33: 62, 75: P, 89: p, 90: b }, { 30: 63, 33: 62, 75: P, 89: p, 90: b }, { 30: 64, 33: 62, 75: P, 89: p, 90: b }, e(X, [2, 29]), e(X, [2, 30]), e(X, [2, 31]), e(X, [2, 32]), e(X, [2, 33]), e(X, [2, 34]), e(Ve, [2, 81]), e(Ve, [2, 82]), { 1: [2, 3] }, { 8: [2, 8] }, { 8: [2, 9] }, { 8: [2, 10] }, { 8: [2, 11] }, { 8: [2, 12] }, { 8: [2, 13] }, { 8: [2, 14] }, { 8: [2, 15] }, { 8: [2, 16] }, { 27: [1, 65], 29: [1, 66] }, e(de, [2, 79]), e(de, [2, 80]), { 27: [1, 67], 29: [1, 68] }, e(de, [2, 85]), e(de, [2, 86]), { 62: 69, 65: ve, 66: Le, 67: xe, 68: Oe, 69: we, 70: De, 71: Me }, { 62: 77, 65: ve, 66: Le, 67: xe, 68: Oe, 69: we, 70: De, 71: Me }, { 30: 78, 33: 62, 75: P, 89: p, 90: b }, { 73: 79, 75: Z, 76: U, 78: 81, 79: 82, 80: ee, 81: te, 82: se, 83: ie, 84: re, 85: ne, 86: ae, 87: le, 88: ce }, e(Ee, [2, 60]), e(Ee, [2, 62]), { 73: 93, 75: Z, 76: U, 78: 81, 79: 82, 80: ee, 81: te, 82: se, 83: ie, 84: re, 85: ne, 86: ae, 87: le, 88: ce }, { 30: 94, 33: 62, 75: P, 76: U, 89: p, 90: b }, { 5: [1, 95] }, { 30: 96, 33: 62, 75: P, 89: p, 90: b }, { 5: [1, 97] }, { 30: 98, 33: 62, 75: P, 89: p, 90: b }, { 63: [1, 99] }, e(Y, [2, 50]), e(Y, [2, 51]), e(Y, [2, 52]), e(Y, [2, 53]), e(Y, [2, 54]), e(Y, [2, 55]), e(Y, [2, 56]), { 64: [1, 100] }, e(d, [2, 59], { 76: U }), e(d, [2, 64], { 76: Fe }), { 33: 103, 75: [1, 102], 89: p, 90: b }, e($e, [2, 65], { 79: 104, 75: Z, 80: ee, 81: te, 82: se, 83: ie, 84: re, 85: ne, 86: ae, 87: le, 88: ce }), e(T, [2, 67]), e(T, [2, 69]), e(T, [2, 70]), e(T, [2, 71]), e(T, [2, 72]), e(T, [2, 73]), e(T, [2, 74]), e(T, [2, 75]), e(T, [2, 76]), e(T, [2, 77]), e(T, [2, 78]), e(d, [2, 57], { 76: Fe }), e(d, [2, 58], { 76: U }), { 5: B, 28: 105, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 27: [1, 112], 76: U }, { 5: oe, 40: he, 56: 113, 57: ue, 59: fe }, { 27: [1, 118], 76: U }, { 33: 119, 89: p, 90: b }, { 33: 120, 89: p, 90: b }, { 75: Z, 78: 121, 79: 82, 80: ee, 81: te, 82: se, 83: ie, 84: re, 85: ne, 86: ae, 87: le, 88: ce }, e(Ee, [2, 61]), e(Ee, [2, 63]), e(T, [2, 68]), e(d, [2, 21]), { 32: [1, 122] }, { 32: [1, 123] }, { 32: [1, 124] }, { 32: [1, 125] }, { 5: B, 28: 126, 31: Q, 34: H, 36: K, 38: W, 40: j }, e(d, [2, 28]), { 5: [1, 127] }, e(d, [2, 42]), { 32: [1, 128] }, { 32: [1, 129] }, { 5: oe, 40: he, 56: 130, 57: ue, 59: fe }, e(d, [2, 47]), { 5: [1, 131] }, e(d, [2, 48]), e(d, [2, 49]), e($e, [2, 66], { 79: 104, 75: Z, 80: ee, 81: te, 82: se, 83: ie, 84: re, 85: ne, 86: ae, 87: le, 88: ce }), { 33: 132, 89: p, 90: b }, { 35: 133, 89: [1, 134], 90: [1, 135] }, { 37: 136, 47: [1, 137], 48: [1, 138], 49: [1, 139] }, { 39: 140, 50: [1, 141], 51: [1, 142], 52: [1, 143], 53: [1, 144] }, e(d, [2, 27]), { 5: B, 28: 145, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 58: 146, 89: [1, 147], 90: [1, 148] }, { 60: 149, 89: [1, 150], 90: [1, 151] }, e(d, [2, 46]), { 5: oe, 40: he, 56: 152, 57: ue, 59: fe }, { 5: [1, 153] }, { 5: [1, 154] }, { 5: [2, 83] }, { 5: [2, 84] }, { 5: [1, 155] }, { 5: [2, 35] }, { 5: [2, 36] }, { 5: [2, 37] }, { 5: [1, 156] }, { 5: [2, 38] }, { 5: [2, 39] }, { 5: [2, 40] }, { 5: [2, 41] }, e(d, [2, 22]), { 5: [1, 157] }, { 5: [2, 87] }, { 5: [2, 88] }, { 5: [1, 158] }, { 5: [2, 89] }, { 5: [2, 90] }, e(d, [2, 43]), { 5: B, 28: 159, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 5: B, 28: 160, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 5: B, 28: 161, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 5: B, 28: 162, 31: Q, 34: H, 36: K, 38: W, 40: j }, { 5: oe, 40: he, 56: 163, 57: ue, 59: fe }, { 5: oe, 40: he, 56: 164, 57: ue, 59: fe }, e(d, [2, 23]), e(d, [2, 24]), e(d, [2, 25]), e(d, [2, 26]), e(d, [2, 44]), e(d, [2, 45])], defaultActions: { 8: [2, 2], 12: [2, 1], 41: [2, 3], 42: [2, 8], 43: [2, 9], 44: [2, 10], 45: [2, 11], 46: [2, 12], 47: [2, 13], 48: [2, 14], 49: [2, 15], 50: [2, 16], 134: [2, 83], 135: [2, 84], 137: [2, 35], 138: [2, 36], 139: [2, 37], 141: [2, 38], 142: [2, 39], 143: [2, 40], 144: [2, 41], 147: [2, 87], 148: [2, 88], 150: [2, 89], 151: [2, 90] }, parseError: u(function (r, n) { if (n.recoverable)
            this.trace(r);
        else {
            var l = new Error(r);
            throw l.hash = n, l;
        } }, "parseError"), parse: u(function (r) {
            var n = this, l = [0], s = [], m = [null], t = [], me = this.table, a = "", be = 0, Pe = 0, Ue = 0, lt = 2, Ye = 1, ct = t.slice.call(arguments, 1), g = Object.create(this.lexer), G = { yy: {} };
            for (var Se in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, Se) && (G.yy[Se] = this.yy[Se]);
            g.setInput(r, G.yy), G.yy.lexer = g, G.yy.parser = this, typeof g.yylloc > "u" && (g.yylloc = {});
            var Ie = g.yylloc;
            t.push(Ie);
            var ot = g.options && g.options.ranges;
            typeof G.yy.parseError == "function" ? this.parseError = G.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function ht(S) { l.length = l.length - 2 * S, m.length = m.length - S, t.length = t.length - S; }
            u(ht, "popStack");
            function Be() { var S; return S = s.pop() || g.lex() || Ye, typeof S != "number" && (S instanceof Array && (s = S, S = s.pop()), S = n.symbols_[S] || S), S; }
            u(Be, "lex");
            for (var y, Te, z, N, bt, Ne, J = {}, Re, F, Qe, ge;;) {
                if (z = l[l.length - 1], this.defaultActions[z] ? N = this.defaultActions[z] : ((y === null || typeof y > "u") && (y = Be()), N = me[z] && me[z][y]), typeof N > "u" || !N.length || !N[0]) {
                    var qe = "";
                    ge = [];
                    for (Re in me[z])
                        this.terminals_[Re] && Re > lt && ge.push("'" + this.terminals_[Re] + "'");
                    g.showPosition ? qe = "Parse error on line " + (be + 1) + `:
` + g.showPosition() + `
Expecting ` + ge.join(", ") + ", got '" + (this.terminals_[y] || y) + "'" : qe = "Parse error on line " + (be + 1) + ": Unexpected " + (y == Ye ? "end of input" : "'" + (this.terminals_[y] || y) + "'"), this.parseError(qe, { text: g.match, token: this.terminals_[y] || y, line: g.yylineno, loc: Ie, expected: ge });
                }
                if (N[0] instanceof Array && N.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + z + ", token: " + y);
                switch (N[0]) {
                    case 1:
                        l.push(y), m.push(g.yytext), t.push(g.yylloc), l.push(N[1]), y = null, Te ? (y = Te, Te = null) : (Pe = g.yyleng, a = g.yytext, be = g.yylineno, Ie = g.yylloc, Ue > 0 && Ue--);
                        break;
                    case 2:
                        if (F = this.productions_[N[1]][1], J.$ = m[m.length - F], J._$ = { first_line: t[t.length - (F || 1)].first_line, last_line: t[t.length - 1].last_line, first_column: t[t.length - (F || 1)].first_column, last_column: t[t.length - 1].last_column }, ot && (J._$.range = [t[t.length - (F || 1)].range[0], t[t.length - 1].range[1]]), Ne = this.performAction.apply(J, [a, Pe, be, G.yy, N[1], m, t].concat(ct)), typeof Ne < "u")
                            return Ne;
                        F && (l = l.slice(0, -1 * F * 2), m = m.slice(0, -1 * F), t = t.slice(0, -1 * F)), l.push(this.productions_[N[1]][0]), m.push(J.$), t.push(J._$), Qe = me[l[l.length - 2]][l[l.length - 1]], l.push(Qe);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, at = (function () {
        var $ = { EOF: 1, parseError: u(function (n, l) { if (this.yy.parser)
                this.yy.parser.parseError(n, l);
            else
                throw new Error(n); }, "parseError"), setInput: u(function (r, n) { return this.yy = n || this.yy || {}, this._input = r, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: u(function () { var r = this._input[0]; this.yytext += r, this.yyleng++, this.offset++, this.match += r, this.matched += r; var n = r.match(/(?:\r\n?|\n).*/g); return n ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), r; }, "input"), unput: u(function (r) { var n = r.length, l = r.split(/(?:\r\n?|\n)/g); this._input = r + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - n), this.offset -= n; var s = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), l.length - 1 && (this.yylineno -= l.length - 1); var m = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: l ? (l.length === s.length ? this.yylloc.first_column : 0) + s[s.length - l.length].length - l[0].length : this.yylloc.first_column - n }, this.options.ranges && (this.yylloc.range = [m[0], m[0] + this.yyleng - n]), this.yyleng = this.yytext.length, this; }, "unput"), more: u(function () { return this._more = !0, this; }, "more"), reject: u(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: u(function (r) { this.unput(this.match.slice(r)); }, "less"), pastInput: u(function () { var r = this.matched.substr(0, this.matched.length - this.match.length); return (r.length > 20 ? "..." : "") + r.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: u(function () { var r = this.match; return r.length < 20 && (r += this._input.substr(0, 20 - r.length)), (r.substr(0, 20) + (r.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: u(function () {
                var r = this.pastInput(), n = new Array(r.length + 1).join("-");
                return r + this.upcomingInput() + `
` + n + "^";
            }, "showPosition"), test_match: u(function (r, n) { var l, s, m; if (this.options.backtrack_lexer && (m = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (m.yylloc.range = this.yylloc.range.slice(0))), s = r[0].match(/(?:\r\n?|\n).*/g), s && (this.yylineno += s.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: s ? s[s.length - 1].length - s[s.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + r[0].length }, this.yytext += r[0], this.match += r[0], this.matches = r, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(r[0].length), this.matched += r[0], l = this.performAction.call(this, this.yy, this, n, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), l)
                return l; if (this._backtrack) {
                for (var t in m)
                    this[t] = m[t];
                return !1;
            } return !1; }, "test_match"), next: u(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var r, n, l, s;
                this._more || (this.yytext = "", this.match = "");
                for (var m = this._currentRules(), t = 0; t < m.length; t++)
                    if (l = this._input.match(this.rules[m[t]]), l && (!n || l[0].length > n[0].length)) {
                        if (n = l, s = t, this.options.backtrack_lexer) {
                            if (r = this.test_match(l, m[t]), r !== !1)
                                return r;
                            if (this._backtrack) {
                                n = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return n ? (r = this.test_match(n, m[s]), r !== !1 ? r : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: u(function () { var n = this.next(); return n || this.lex(); }, "lex"), begin: u(function (n) { this.conditionStack.push(n); }, "begin"), popState: u(function () { var n = this.conditionStack.length - 1; return n > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: u(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: u(function (n) { return n = this.conditionStack.length - 1 - Math.abs(n || 0), n >= 0 ? this.conditionStack[n] : "INITIAL"; }, "topState"), pushState: u(function (n) { this.begin(n); }, "pushState"), stateStackSize: u(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: u(function (n, l, s, m) { var t = m; switch (s) {
                case 0: return "title";
                case 1:
                    return this.begin("acc_title"), 9;
                    break;
                case 2:
                    return this.popState(), "acc_title_value";
                    break;
                case 3:
                    return this.begin("acc_descr"), 11;
                    break;
                case 4:
                    return this.popState(), "acc_descr_value";
                    break;
                case 5:
                    this.begin("acc_descr_multiline");
                    break;
                case 6:
                    this.popState();
                    break;
                case 7: return "acc_descr_multiline_value";
                case 8: return 21;
                case 9: return 22;
                case 10: return 23;
                case 11: return 24;
                case 12: return 5;
                case 13: break;
                case 14: break;
                case 15: break;
                case 16: return 8;
                case 17: return 6;
                case 18: return 27;
                case 19: return 40;
                case 20: return 29;
                case 21: return 32;
                case 22: return 31;
                case 23: return 34;
                case 24: return 36;
                case 25: return 38;
                case 26: return 41;
                case 27: return 42;
                case 28: return 43;
                case 29: return 44;
                case 30: return 45;
                case 31: return 46;
                case 32: return 47;
                case 33: return 48;
                case 34: return 49;
                case 35: return 50;
                case 36: return 51;
                case 37: return 52;
                case 38: return 53;
                case 39: return 54;
                case 40: return 65;
                case 41: return 66;
                case 42: return 67;
                case 43: return 68;
                case 44: return 69;
                case 45: return 70;
                case 46: return 71;
                case 47: return 57;
                case 48: return 59;
                case 49:
                    return this.begin("style"), 77;
                    break;
                case 50: return 75;
                case 51: return 81;
                case 52: return 88;
                case 53: return "PERCENT";
                case 54: return 86;
                case 55: return 84;
                case 56: break;
                case 57:
                    this.begin("string");
                    break;
                case 58:
                    this.popState();
                    break;
                case 59:
                    return this.begin("style"), 72;
                    break;
                case 60:
                    return this.begin("style"), 74;
                    break;
                case 61: return 61;
                case 62: return 64;
                case 63: return 63;
                case 64:
                    this.begin("string");
                    break;
                case 65:
                    this.popState();
                    break;
                case 66: return "qString";
                case 67:
                    return l.yytext = l.yytext.trim(), 89;
                    break;
                case 68: return 75;
                case 69: return 80;
                case 70: return 76;
            } }, "anonymous"), rules: [/^(?:title\s[^#\n;]+)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:.*direction\s+TB[^\n]*)/i, /^(?:.*direction\s+BT[^\n]*)/i, /^(?:.*direction\s+RL[^\n]*)/i, /^(?:.*direction\s+LR[^\n]*)/i, /^(?:(\r?\n)+)/i, /^(?:\s+)/i, /^(?:#[^\n]*)/i, /^(?:%[^\n]*)/i, /^(?:$)/i, /^(?:requirementDiagram\b)/i, /^(?:\{)/i, /^(?:\})/i, /^(?::{3})/i, /^(?::)/i, /^(?:id\b)/i, /^(?:text\b)/i, /^(?:risk\b)/i, /^(?:verifyMethod\b)/i, /^(?:requirement\b)/i, /^(?:functionalRequirement\b)/i, /^(?:interfaceRequirement\b)/i, /^(?:performanceRequirement\b)/i, /^(?:physicalRequirement\b)/i, /^(?:designConstraint\b)/i, /^(?:low\b)/i, /^(?:medium\b)/i, /^(?:high\b)/i, /^(?:analysis\b)/i, /^(?:demonstration\b)/i, /^(?:inspection\b)/i, /^(?:test\b)/i, /^(?:element\b)/i, /^(?:contains\b)/i, /^(?:copies\b)/i, /^(?:derives\b)/i, /^(?:satisfies\b)/i, /^(?:verifies\b)/i, /^(?:refines\b)/i, /^(?:traces\b)/i, /^(?:type\b)/i, /^(?:docref\b)/i, /^(?:style\b)/i, /^(?:\w+)/i, /^(?::)/i, /^(?:;)/i, /^(?:%)/i, /^(?:-)/i, /^(?:#)/i, /^(?: )/i, /^(?:["])/i, /^(?:\n)/i, /^(?:classDef\b)/i, /^(?:class\b)/i, /^(?:<-)/i, /^(?:->)/i, /^(?:-)/i, /^(?:["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?:[\w][^:,\r\n\{\<\>\-\=]*)/i, /^(?:\w+)/i, /^(?:[0-9]+)/i, /^(?:,)/i], conditions: { acc_descr_multiline: { rules: [6, 7, 68, 69, 70], inclusive: !1 }, acc_descr: { rules: [4, 68, 69, 70], inclusive: !1 }, acc_title: { rules: [2, 68, 69, 70], inclusive: !1 }, style: { rules: [50, 51, 52, 53, 54, 55, 56, 57, 58, 68, 69, 70], inclusive: !1 }, unqString: { rules: [68, 69, 70], inclusive: !1 }, token: { rules: [68, 69, 70], inclusive: !1 }, string: { rules: [65, 66, 68, 69, 70], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 5, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 59, 60, 61, 62, 63, 64, 67, 68, 69, 70], inclusive: !0 } } };
        return $;
    })();
    _e.lexer = at;
    function pe() { this.yy = {}; }
    return u(pe, "Parser"), pe.prototype = _e, _e.Parser = pe, new pe;
})();
Ae.parser = Ae;
var ut = Ae, ft = class {
    constructor() { this.relations = [], this.latestRequirement = this.getInitialRequirement(), this.requirements = new Map, this.latestElement = this.getInitialElement(), this.elements = new Map, this.classes = new Map, this.direction = "TB", this.RequirementType = { REQUIREMENT: "Requirement", FUNCTIONAL_REQUIREMENT: "Functional Requirement", INTERFACE_REQUIREMENT: "Interface Requirement", PERFORMANCE_REQUIREMENT: "Performance Requirement", PHYSICAL_REQUIREMENT: "Physical Requirement", DESIGN_CONSTRAINT: "Design Constraint" }, this.RiskLevel = { LOW_RISK: "Low", MED_RISK: "Medium", HIGH_RISK: "High" }, this.VerifyType = { VERIFY_ANALYSIS: "Analysis", VERIFY_DEMONSTRATION: "Demonstration", VERIFY_INSPECTION: "Inspection", VERIFY_TEST: "Test" }, this.Relationships = { CONTAINS: "contains", COPIES: "copies", DERIVES: "derives", SATISFIES: "satisfies", VERIFIES: "verifies", REFINES: "refines", TRACES: "traces" }, this.setAccTitle = je, this.getAccTitle = Ge, this.setAccDescription = ze, this.getAccDescription = Xe, this.setDiagramTitle = Je, this.getDiagramTitle = Ze, this.getConfig = u(() => ye().requirement, "getConfig"), this.clear(), this.setDirection = this.setDirection.bind(this), this.addRequirement = this.addRequirement.bind(this), this.setNewReqId = this.setNewReqId.bind(this), this.setNewReqRisk = this.setNewReqRisk.bind(this), this.setNewReqText = this.setNewReqText.bind(this), this.setNewReqVerifyMethod = this.setNewReqVerifyMethod.bind(this), this.addElement = this.addElement.bind(this), this.setNewElementType = this.setNewElementType.bind(this), this.setNewElementDocRef = this.setNewElementDocRef.bind(this), this.addRelationship = this.addRelationship.bind(this), this.setCssStyle = this.setCssStyle.bind(this), this.setClass = this.setClass.bind(this), this.defineClass = this.defineClass.bind(this), this.setAccTitle = this.setAccTitle.bind(this), this.setAccDescription = this.setAccDescription.bind(this); }
    static { u(this, "RequirementDB"); }
    getDirection() { return this.direction; }
    setDirection(e) { this.direction = e; }
    resetLatestRequirement() { this.latestRequirement = this.getInitialRequirement(); }
    resetLatestElement() { this.latestElement = this.getInitialElement(); }
    getInitialRequirement() { return { requirementId: "", text: "", risk: "", verifyMethod: "", name: "", type: "", cssStyles: [], classes: ["default"] }; }
    getInitialElement() { return { name: "", type: "", docRef: "", cssStyles: [], classes: ["default"] }; }
    addRequirement(e, f) { return this.requirements.has(e) || this.requirements.set(e, { name: e, type: f, requirementId: this.latestRequirement.requirementId, text: this.latestRequirement.text, risk: this.latestRequirement.risk, verifyMethod: this.latestRequirement.verifyMethod, cssStyles: [], classes: ["default"] }), this.resetLatestRequirement(), this.requirements.get(e); }
    getRequirements() { return this.requirements; }
    setNewReqId(e) { this.latestRequirement !== void 0 && (this.latestRequirement.requirementId = e); }
    setNewReqText(e) { this.latestRequirement !== void 0 && (this.latestRequirement.text = e); }
    setNewReqRisk(e) { this.latestRequirement !== void 0 && (this.latestRequirement.risk = e); }
    setNewReqVerifyMethod(e) { this.latestRequirement !== void 0 && (this.latestRequirement.verifyMethod = e); }
    addElement(e) { return this.elements.has(e) || (this.elements.set(e, { name: e, type: this.latestElement.type, docRef: this.latestElement.docRef, cssStyles: [], classes: ["default"] }), ke.info("Added new element: ", e)), this.resetLatestElement(), this.elements.get(e); }
    getElements() { return this.elements; }
    setNewElementType(e) { this.latestElement !== void 0 && (this.latestElement.type = e); }
    setNewElementDocRef(e) { this.latestElement !== void 0 && (this.latestElement.docRef = e); }
    addRelationship(e, f, h) { this.relations.push({ type: e, src: f, dst: h }); }
    getRelationships() { return this.relations; }
    clear() { this.relations = [], this.resetLatestRequirement(), this.requirements = new Map, this.resetLatestElement(), this.elements = new Map, this.classes = new Map, We(); }
    setCssStyle(e, f) { for (let h of e) {
        let o = this.requirements.get(h) ?? this.elements.get(h);
        if (!f || !o)
            return;
        for (let i of f)
            i.includes(",") ? o.cssStyles.push(...i.split(",")) : o.cssStyles.push(i);
    } }
    setClass(e, f) { for (let h of e) {
        let o = this.requirements.get(h) ?? this.elements.get(h);
        if (o)
            for (let i of f) {
                o.classes.push(i);
                let c = this.classes.get(i)?.styles;
                c && o.cssStyles.push(...c);
            }
    } }
    defineClass(e, f) { for (let h of e) {
        let o = this.classes.get(h);
        o === void 0 && (o = { id: h, styles: [], textStyles: [] }, this.classes.set(h, o)), f && f.forEach(function (i) { if (/color/.exec(i)) {
            let c = i.replace("fill", "bgFill");
            o.textStyles.push(c);
        } o.styles.push(i); }), this.requirements.forEach(i => { i.classes.includes(h) && i.cssStyles.push(...f.flatMap(c => c.split(","))); }), this.elements.forEach(i => { i.classes.includes(h) && i.cssStyles.push(...f.flatMap(c => c.split(","))); });
    } }
    getClasses() { return this.classes; }
    getData() { let e = ye(), f = [], h = []; for (let i of this.requirements.values()) {
        let c = i;
        c.id = i.name, c.cssStyles = i.cssStyles, c.cssClasses = i.classes.join(" "), c.shape = "requirementBox", c.look = e.look, c.colorIndex = f.length, f.push(c);
    } for (let i of this.elements.values()) {
        let c = i;
        c.shape = "requirementBox", c.look = e.look, c.id = i.name, c.cssStyles = i.cssStyles, c.cssClasses = i.classes.join(" "), c.colorIndex = f.length, f.push(c);
    } let o = 0; for (let i of this.relations) {
        let c = i.type === this.Relationships.CONTAINS, k = { id: `${i.src}-${i.dst}-${o++}`, start: this.requirements.get(i.src)?.name ?? this.elements.get(i.src)?.name, end: this.requirements.get(i.dst)?.name ?? this.elements.get(i.dst)?.name, label: `&lt;&lt;${i.type}&gt;&gt;`, classes: "relationshipLine", style: ["fill:none", c ? "" : "stroke-dasharray: 10,7"], labelpos: "c", thickness: "normal", type: "normal", pattern: c ? "normal" : "dashed", arrowTypeStart: c ? "requirement_contains" : "", arrowTypeEnd: c ? "" : "requirement_arrow", look: e.look, labelType: "markdown" };
        h.push(k);
    } return { nodes: f, edges: h, other: {}, config: e, direction: this.getDirection() }; }
}, mt = u(e => {
    let f = Ce(), { themeVariables: h, look: o } = f, { bkgColorArray: i, borderColorArray: c } = h;
    if (!c?.length)
        return "";
    let k = "";
    for (let E = 0; E < e.THEME_COLOR_LIMIT; E++)
        k += `

    [data-look="${o}"][data-color-id="color-${E}"].node path {
    stroke: ${c[E]};
    fill: ${i?.length ? i[E] : ""};
    }

    [data-look="${o}"][data-color-id="color-${E}"].node  rect {
    stroke: ${c[E]};
    fill: ${i?.length ? i[E] : ""};
     }
    `;
    return k;
}, "genColor"), dt = u(e => {
    let f = Ce(), { look: h, themeVariables: o } = f, { requirementEdgeLabelBackground: i } = o;
    return `
  ${mt(e)}
  marker {
    fill: ${e.relationColor};
    stroke: ${e.relationColor};
  }

  marker.cross {
    stroke: ${e.lineColor};
  }

  svg {
    font-family: ${e.fontFamily};
    font-size: ${e.fontSize};
  }

  .reqBox {
    fill: ${e.requirementBackground};
    fill-opacity: 1.0;
    stroke: ${e.requirementBorderColor};
    stroke-width: ${e.requirementBorderSize};
  }
  
  .reqTitle, .reqLabel{
    fill:  ${e.requirementTextColor};
  }
  .reqLabelBox {
    fill: ${e.relationLabelBackground};
    fill-opacity: 1.0;
  }

  .req-title-line {
    stroke: ${e.requirementBorderColor};
    stroke-width: ${e.requirementBorderSize};
  }
  .relationshipLine {
    stroke: ${e.relationColor};
    stroke-width: ${h === "neo" ? e.strokeWidth : "1px"};
  }
  .relationshipLabel {
    fill: ${e.relationLabelColor};
  }
    .edgeLabel {
    background-color: ${e.edgeLabelBackground};
  }
  .edgeLabel .label rect {
    fill: ${e.edgeLabelBackground};
  }
  .edgeLabel .label text {
    fill: ${e.relationLabelColor};
  }
  .divider {
    stroke: ${e.nodeBorder};
    stroke-width: 1;
  }
  .label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .label text,span {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }
  .labelBkg {
    background-color: ${i ?? e.edgeLabelBackground};
  }

`;
}, "getStyles"), Et = dt, nt = {};
Ke(nt, { draw: () => pt });
var pt = u(function (e, f, h, o) { return He(this, null, function* () { ke.info("REF0:"), ke.info("Drawing requirement diagram (unified)", f); let { securityLevel: i, state: c, layout: k, look: E } = ye(), R = o.db.getData(), _ = it(f, i); R.type = o.type, R.layoutAlgorithm = st(k), R.nodeSpacing = c?.nodeSpacing ?? 50, R.rankSpacing = c?.rankSpacing ?? 50, R.markers = E === "neo" ? ["requirement_contains_neo", "requirement_arrow_neo"] : ["requirement_contains", "requirement_arrow"], R.diagramId = f, yield tt(R, _); let I = 8; et.insertTitle(_, "requirementDiagramTitleText", c?.titleTopMargin ?? 25, o.db.getDiagramTitle()), rt(_, I, "requirementDiagram", c?.useMaxWidth ?? !0); }); }, "draw"), Lt = { parser: ut, get db() { return new ft; }, renderer: nt, styles: Et };
export { Lt as diagram };
