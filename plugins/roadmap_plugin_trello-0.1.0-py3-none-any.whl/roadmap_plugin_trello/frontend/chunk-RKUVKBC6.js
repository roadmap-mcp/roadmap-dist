import { a as c1 } from "@nf-internal/chunk-QP3MATMC";
import { h as l1 } from "@nf-internal/chunk-X5ONEG5D";
import { a as h1 } from "@nf-internal/chunk-3UW5LP2A";
import { a as d1 } from "@nf-internal/chunk-WVCFK4LD";
import { a as a1, b as n1 } from "@nf-internal/chunk-GDGZBOQC";
import { b as u1, c as o1 } from "@nf-internal/chunk-4PKWXC3U";
import { g as r1 } from "@nf-internal/chunk-VEDGZ2C2";
import { p as Je, s as Ze } from "@nf-internal/chunk-FDRUJGNH";
import { $ as ut, N as Xt, T as Qt, U as Jt, V as Zt, W as $t, X as e1, Y as t1, Z as s1, _ as de, a as Kt, aa as i1, b as Yt, g as Ht, x as qt } from "@nf-internal/chunk-LEJRRF65";
import { b as Z, h as Qe } from "@nf-internal/chunk-RZWXGGKD";
import { a as A } from "@nf-internal/chunk-YUSHYV7C";
import { a as Oe, b as nt, f as jt } from "@nf-internal/chunk-OSQMNGTH";
var C1 = "flowchart-", D1 = class {
    constructor() { this.vertexCounter = 0, this.config = de(), this.diagramId = "", this.vertices = new Map, this.edges = [], this.classes = new Map, this.subGraphs = [], this.subGraphLookup = new Map, this.tooltips = new Map, this.subCount = 0, this.firstGraphFlag = !0, this.secCount = -1, this.posCrossRef = [], this.funs = [], this.setAccTitle = Jt, this.setAccDescription = $t, this.setDiagramTitle = t1, this.getAccTitle = Zt, this.getAccDescription = e1, this.getDiagramTitle = s1, this.funs.push(this.setupToolTips.bind(this)), this.addVertex = this.addVertex.bind(this), this.firstGraph = this.firstGraph.bind(this), this.setDirection = this.setDirection.bind(this), this.addSubGraph = this.addSubGraph.bind(this), this.addLink = this.addLink.bind(this), this.setLink = this.setLink.bind(this), this.updateLink = this.updateLink.bind(this), this.addClass = this.addClass.bind(this), this.setClass = this.setClass.bind(this), this.destructLink = this.destructLink.bind(this), this.setClickEvent = this.setClickEvent.bind(this), this.setTooltip = this.setTooltip.bind(this), this.updateLinkInterpolate = this.updateLinkInterpolate.bind(this), this.setClickFun = this.setClickFun.bind(this), this.bindFunctions = this.bindFunctions.bind(this), this.lex = { firstGraph: this.firstGraph.bind(this) }, this.clear(), this.setGen("gen-2"); }
    static { A(this, "FlowDB"); }
    sanitizeText(e) { return Xt.sanitizeText(e, this.config); }
    sanitizeNodeLabelType(e) { switch (e) {
        case "markdown":
        case "string":
        case "text": return e;
        default: return "markdown";
    } }
    setDiagramId(e) { this.diagramId = e; }
    lookUpDomId(e) { for (let i of this.vertices.values())
        if (i.id === e)
            return this.diagramId ? `${this.diagramId}-${i.domId}` : i.domId; return this.diagramId ? `${this.diagramId}-${e}` : e; }
    addVertex(e, i, r, a, u, f, l = {}, k) {
        if (!e || e.trim().length === 0)
            return;
        let h;
        if (k !== void 0) {
            let o;
            k.includes(`
`) ? o = k + `
` : o = `{
` + k + `
}`, h = n1(o, { schema: a1 });
        }
        let _ = this.subGraphLookup.get(e);
        if (_ && h) {
            _.metadata = Oe(Oe({}, _.metadata), h);
            return;
        }
        let y = this.edges.find(o => o.id === e);
        if (y) {
            let o = h;
            o?.animate !== void 0 && (y.animate = o.animate), o?.animation !== void 0 && (y.animation = o.animation), o?.curve !== void 0 && (y.interpolate = o.curve);
            return;
        }
        let L, g = this.vertices.get(e);
        if (g === void 0 && (i === void 0 && r === void 0 && a !== void 0 && a !== null && Z.warn(`Style applied to unknown node "${e}". This may indicate a typo. The node will be created automatically.`), g = { id: e, labelType: "text", domId: C1 + e + "-" + this.vertexCounter, styles: [], classes: [] }, this.vertices.set(e, g)), this.vertexCounter++, i !== void 0 ? (this.config = de(), L = this.sanitizeText(i.text.trim()), g.labelType = i.type, L.startsWith('"') && L.endsWith('"') && (L = L.substring(1, L.length - 1)), g.text = L) : g.text === void 0 && (g.text = e), r !== void 0 && (g.type = r), a?.forEach(o => { g.styles.push(o); }), u?.forEach(o => { g.classes.push(o); }), f !== void 0 && (g.dir = f), g.props === void 0 ? g.props = l : l !== void 0 && Object.assign(g.props, l), h !== void 0) {
            if (h.shape) {
                if (h.shape !== h.shape.toLowerCase() || h.shape.includes("_"))
                    throw new Error(`No such shape: ${h.shape}. Shape names should be lowercase.`);
                if (!r1(h.shape))
                    throw new Error(`No such shape: ${h.shape}.`);
                g.type = h?.shape;
            }
            h?.label && (g.text = h?.label, g.labelType = this.sanitizeNodeLabelType(h?.labelType)), h?.icon && (g.icon = h?.icon, !h.label?.trim() && g.text === e && (g.text = "")), h?.form && (g.form = h?.form), h?.pos && (g.pos = h?.pos), h?.img && (g.img = h?.img, !h.label?.trim() && g.text === e && (g.text = "")), h?.constraint && (g.constraint = h.constraint), h.w && (g.assetWidth = Number(h.w)), h.h && (g.assetHeight = Number(h.h));
        }
    }
    addSingleLink(e, i, r, a) {
        let l = { start: e, end: i, type: void 0, text: "", labelType: "text", classes: [], isUserDefinedId: !1, interpolate: this.edges.defaultInterpolate };
        Z.info("abc78 Got edge...", l);
        let k = r.text;
        if (k !== void 0 && (l.text = this.sanitizeText(k.text.trim()), l.text.startsWith('"') && l.text.endsWith('"') && (l.text = l.text.substring(1, l.text.length - 1)), l.labelType = this.sanitizeNodeLabelType(k.type)), r !== void 0 && (l.type = r.type, l.stroke = r.stroke, l.length = r.length > 10 ? 10 : r.length), a && !this.edges.some(h => h.id === a))
            l.id = a, l.isUserDefinedId = !0;
        else {
            let h = this.edges.filter(_ => _.start === l.start && _.end === l.end);
            h.length === 0 ? l.id = Ze(l.start, l.end, { counter: 0, prefix: "L" }) : l.id = Ze(l.start, l.end, { counter: h.length + 1, prefix: "L" });
        }
        if (this.edges.length < (this.config.maxEdges ?? 500))
            Z.info("Pushing edge..."), this.edges.push(l);
        else
            throw new Error(`Edge limit exceeded. ${this.edges.length} edges found, but the limit is ${this.config.maxEdges}.

Initialize mermaid with maxEdges set to a higher number to allow more edges.
You cannot set this config via configuration inside the diagram as it is a secure config.
You have to call mermaid.initialize.`);
    }
    isLinkData(e) { return e !== null && typeof e == "object" && "id" in e && typeof e.id == "string"; }
    addLink(e, i, r) { let a = this.isLinkData(r) ? r.id.replace("@", "") : void 0; Z.info("addLink", e, i, a); for (let u of e)
        for (let f of i) {
            let l = u === e[e.length - 1], k = f === i[0];
            l && k ? this.addSingleLink(u, f, r, a) : this.addSingleLink(u, f, r, void 0);
        } }
    updateLinkInterpolate(e, i) { e.forEach(r => { r === "default" ? this.edges.defaultInterpolate = i : this.edges[r].interpolate = i; }); }
    updateLink(e, i) { e.forEach(r => { if (typeof r == "number" && r >= this.edges.length)
        throw new Error(`The index ${r} for linkStyle is out of bounds. Valid indices for linkStyle are between 0 and ${this.edges.length - 1}. (Help: Ensure that the index is within the range of existing edges.)`); r === "default" ? this.edges.defaultStyle = i : (this.edges[r].style = i, (this.edges[r]?.style?.length ?? 0) > 0 && !this.edges[r]?.style?.some(a => a?.startsWith("fill")) && this.edges[r]?.style?.push("fill:none")); }); }
    addClass(e, i) { let r = i.join().replace(/\\,/g, "\xA7\xA7\xA7").replace(/,/g, ";").replace(/§§§/g, ",").split(";"); e.split(",").forEach(a => { let u = this.classes.get(a); u === void 0 && (u = { id: a, styles: [], textStyles: [] }, this.classes.set(a, u)), r?.forEach(f => { if (/color/.exec(f)) {
        let l = f.replace("fill", "bgFill");
        u.textStyles.push(l);
    } u.styles.push(f); }); }); }
    setDirection(e) { this.direction = e.trim(), /.*</.exec(this.direction) && (this.direction = "RL"), /.*\^/.exec(this.direction) && (this.direction = "BT"), /.*>/.exec(this.direction) && (this.direction = "LR"), /.*v/.exec(this.direction) && (this.direction = "TB"), this.direction === "TD" && (this.direction = "TB"); }
    setClass(e, i) { for (let r of e.split(",")) {
        let a = this.vertices.get(r);
        a && a.classes.push(i);
        let u = this.edges.find(l => l.id === r);
        u && u.classes.push(i);
        let f = this.subGraphLookup.get(r);
        f && f.classes.push(i);
    } }
    setTooltip(e, i) { if (i !== void 0) {
        i = this.sanitizeText(i);
        for (let r of e.split(","))
            this.tooltips.set(this.version === "gen-1" ? this.lookUpDomId(r) : r, i);
    } }
    setClickFun(e, i, r) { if (de().securityLevel !== "loose" || i === void 0)
        return; let a = []; if (typeof r == "string") {
        a = r.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
        for (let f = 0; f < a.length; f++) {
            let l = a[f].trim();
            l.startsWith('"') && l.endsWith('"') && (l = l.substr(1, l.length - 2)), a[f] = l;
        }
    } a.length === 0 && a.push(e); let u = this.vertices.get(e); u && (u.haveCallback = !0, this.funs.push(() => { let f = this.lookUpDomId(e), l = document.querySelector(`[id="${f}"]`); l !== null && l.addEventListener("click", () => { Je.runFunc(i, ...a); }, !1); })); }
    setLink(e, i, r) { e.split(",").forEach(a => { let u = this.vertices.get(a); u !== void 0 && (u.link = Je.formatUrl(i, this.config), u.linkTarget = r); }), this.setClass(e, "clickable"); }
    getTooltip(e) { return this.tooltips.get(e); }
    setClickEvent(e, i, r) { e.split(",").forEach(a => { this.setClickFun(a, i, r); }), this.setClass(e, "clickable"); }
    bindFunctions(e) { this.funs.forEach(i => { i(e); }); }
    getDirection() { return this.direction?.trim(); }
    getVertices() { return this.vertices; }
    getEdges() { return this.edges; }
    getClasses() { return this.classes; }
    setupToolTips(e) { let i = l1(); Qe(e).select("svg").selectAll("g.node").on("mouseover", u => { let f = Qe(u.currentTarget), l = f.attr("title"); if (l === null)
        return; let k = u.currentTarget?.getBoundingClientRect(); i.transition().duration(200).style("opacity", ".9"), i.text(f.attr("title")).style("left", window.scrollX + k.left + (k.right - k.left) / 2 + "px").style("top", window.scrollY + k.bottom + "px"), i.html(Ht.sanitize(l)), f.classed("hover", !0); }).on("mouseout", u => { i.transition().duration(500).style("opacity", 0), Qe(u.currentTarget).classed("hover", !1); }); }
    clear(e = "gen-2") { this.vertices = new Map, this.classes = new Map, this.edges = [], this.funs = [this.setupToolTips.bind(this)], this.diagramId = "", this.subGraphs = [], this.subGraphLookup = new Map, this.subCount = 0, this.tooltips = new Map, this.firstGraphFlag = !0, this.version = e, this.config = de(), Qt(); }
    setGen(e) { this.version = e || "gen-2"; }
    defaultStyle() { return "fill:#ffa;stroke: #f66; stroke-width: 3px; stroke-dasharray: 5, 5;fill:#ffa;stroke: #666;"; }
    addSubGraph(e, i, r) { let a = e.text.trim(), u = r.text; e === r && /\s/.exec(r.text) && (a = void 0); let l = A(L => { let g = { boolean: {}, number: {}, string: {} }, o = [], c; return { nodeList: L.filter(function (B) { let Q = typeof B; return B.stmt && B.stmt === "dir" ? (c = B.value, !1) : B.trim() === "" ? !1 : Q in g ? g[Q].hasOwnProperty(B) ? !1 : g[Q][B] = !0 : o.includes(B) ? !1 : o.push(B); }), dir: c }; }, "uniq")(i.flat()), k = l.nodeList, h = l.dir, _ = de().flowchart ?? {}; if (h = h ?? (_.inheritDir ? this.getDirection() ?? de().direction ?? void 0 : void 0), this.version === "gen-1")
        for (let L = 0; L < k.length; L++)
            k[L] = this.lookUpDomId(k[L]); a = a ?? "subGraph" + this.subCount, u = u || "", u = this.sanitizeText(u), this.subCount = this.subCount + 1; let y = { id: a, nodes: k, title: u.trim(), classes: [], dir: h, labelType: this.sanitizeNodeLabelType(r?.type) }; return Z.info("Adding", y.id, y.nodes, y.dir), y.nodes = this.makeUniq(y, this.subGraphs).nodes, this.subGraphs.push(y), this.subGraphLookup.set(a, y), a; }
    getPosForId(e) { for (let [i, r] of this.subGraphs.entries())
        if (r.id === e)
            return i; return -1; }
    indexNodes2(e, i) { let r = this.subGraphs[i].nodes; if (this.secCount = this.secCount + 1, this.secCount > 2e3)
        return { result: !1, count: 0 }; if (this.posCrossRef[this.secCount] = i, this.subGraphs[i].id === e)
        return { result: !0, count: 0 }; let a = 0, u = 1; for (; a < r.length;) {
        let f = this.getPosForId(r[a]);
        if (f >= 0) {
            let l = this.indexNodes2(e, f);
            if (l.result)
                return { result: !0, count: u + l.count };
            u = u + l.count;
        }
        a = a + 1;
    } return { result: !1, count: u }; }
    getDepthFirstPos(e) { return this.posCrossRef[e]; }
    indexNodes() { this.secCount = -1, this.subGraphs.length > 0 && this.indexNodes2("none", this.subGraphs.length - 1); }
    getSubGraphs() { return this.subGraphs; }
    firstGraph() { return this.firstGraphFlag ? (this.firstGraphFlag = !1, !0) : !1; }
    destructStartLink(e) { let i = e.trim(), r = "arrow_open"; switch (i[0]) {
        case "<":
            r = "arrow_point", i = i.slice(1);
            break;
        case "x":
            r = "arrow_cross", i = i.slice(1);
            break;
        case "o":
            r = "arrow_circle", i = i.slice(1);
            break;
    } let a = "normal"; return i.includes("=") && (a = "thick"), i.includes(".") && (a = "dotted"), { type: r, stroke: a }; }
    countChar(e, i) { let r = i.length, a = 0; for (let u = 0; u < r; ++u)
        i[u] === e && ++a; return a; }
    destructEndLink(e) { let i = e.trim(), r = i.slice(0, -1), a = "arrow_open"; switch (i.slice(-1)) {
        case "x":
            a = "arrow_cross", i.startsWith("x") && (a = "double_" + a, r = r.slice(1));
            break;
        case ">":
            a = "arrow_point", i.startsWith("<") && (a = "double_" + a, r = r.slice(1));
            break;
        case "o":
            a = "arrow_circle", i.startsWith("o") && (a = "double_" + a, r = r.slice(1));
            break;
    } let u = "normal", f = r.length - 1; r.startsWith("=") && (u = "thick"), r.startsWith("~") && (u = "invisible"); let l = this.countChar(".", r); return l && (u = "dotted", f = l), { type: a, stroke: u, length: f }; }
    destructLink(e, i) { let r = this.destructEndLink(e), a; if (i) {
        if (a = this.destructStartLink(i), a.stroke !== r.stroke)
            return { type: "INVALID", stroke: "INVALID" };
        if (a.type === "arrow_open")
            a.type = r.type;
        else {
            if (a.type !== r.type)
                return { type: "INVALID", stroke: "INVALID" };
            a.type = "double_" + a.type;
        }
        return a.type === "double_arrow" && (a.type = "double_arrow_point"), a.length = r.length, a;
    } return r; }
    exists(e, i) { for (let r of e)
        if (r.nodes.includes(i))
            return !0; return !1; }
    makeUniq(e, i) { let r = []; return e.nodes.forEach((a, u) => { this.exists(i, a) || r.push(e.nodes[u]); }), { nodes: r }; }
    getTypeFromVertex(e) { if (e.img)
        return "imageSquare"; if (e.icon)
        return e.form === "circle" ? "iconCircle" : e.form === "square" ? "iconSquare" : e.form === "rounded" ? "iconRounded" : "icon"; switch (e.type) {
        case "square":
        case void 0: return "squareRect";
        case "round": return "roundedRect";
        case "ellipse": return "ellipse";
        default: return e.type;
    } }
    findNode(e, i) { return e.find(r => r.id === i); }
    destructEdgeType(e) { let i = "none", r = "arrow_point"; switch (e) {
        case "arrow_point":
        case "arrow_circle":
        case "arrow_cross":
            r = e;
            break;
        case "double_arrow_point":
        case "double_arrow_circle":
        case "double_arrow_cross":
            i = e.replace("double_", ""), r = i;
            break;
    } return { arrowTypeStart: i, arrowTypeEnd: r }; }
    addNodeFromVertex(e, i, r, a, u, f) { let l = r.get(e.id), k = a.get(e.id) ?? !1, h = this.findNode(i, e.id); if (h)
        h.cssStyles = e.styles, h.cssCompiledStyles = this.getCompiledStyles(e.classes), h.cssClasses = e.classes.join(" ");
    else {
        let _ = { id: e.id, label: e.text, labelType: e.labelType, labelStyle: "", parentId: l, padding: u.flowchart?.padding || 8, cssStyles: e.styles, cssCompiledStyles: this.getCompiledStyles(["default", "node", ...e.classes]), cssClasses: "default " + e.classes.join(" "), dir: e.dir, domId: e.domId, look: f, link: e.link, linkTarget: e.linkTarget, tooltip: this.getTooltip(e.id), icon: e.icon, pos: e.pos, img: e.img, assetWidth: e.assetWidth, assetHeight: e.assetHeight, constraint: e.constraint };
        k ? i.push(nt(Oe({}, _), { isGroup: !0, shape: "rect" })) : i.push(nt(Oe({}, _), { isGroup: !1, shape: this.getTypeFromVertex(e) }));
    } }
    getCompiledStyles(e) { let i = []; for (let r of e) {
        let a = this.classes.get(r);
        a?.styles && (i = [...i, ...a.styles ?? []].map(u => u.trim())), a?.textStyles && (i = [...i, ...a.textStyles ?? []].map(u => u.trim()));
    } return i; }
    getData() { let e = de(), i = [], r = [], a = this.getSubGraphs(), u = new Map, f = new Map, l = new Map; for (let o of a)
        for (let c of o.nodes)
            this.subGraphLookup.has(c) && l.set(c, o.id); let k = A(o => this.subGraphLookup.get(o)?.metadata?.view === "collapsed", "isCollapsed"), h = A(o => { let c, E = new Set, B = o; for (; B !== void 0 && !E.has(B);)
        E.add(B), k(B) && (c = B), B = l.get(B); return c; }, "outermostCollapsed"), _ = new Set, y = new Map; for (let o of a) {
        let c = h(o.id);
        if (c !== void 0) {
            o.id !== c && (_.add(o.id), y.set(o.id, c));
            for (let E of o.nodes)
                E !== c && (_.add(E), y.set(E, c));
        }
    } for (let o = a.length - 1; o >= 0; o--) {
        let c = a[o];
        if (!_.has(c.id)) {
            c.nodes.length > 0 && f.set(c.id, !0);
            for (let E of c.nodes)
                u.set(E, c.id);
        }
    } for (let o = a.length - 1; o >= 0; o--) {
        let c = a[o];
        _.has(c.id) || (c.metadata?.view === "collapsed" ? i.push({ id: c.id, label: c.title, labelStyle: "", labelType: c.labelType, parentId: u.get(c.id), padding: 8, cssCompiledStyles: this.getCompiledStyles(c.classes), cssClasses: c.classes.join(" "), shape: "collapsedGroup", dir: c.dir, isGroup: !1, look: e.look }) : i.push({ id: c.id, label: c.title, labelStyle: "", labelType: c.labelType, parentId: u.get(c.id), padding: 8, cssCompiledStyles: this.getCompiledStyles(c.classes), cssClasses: c.classes.join(" "), shape: "rect", dir: c.dir, isGroup: !0, look: e.look }));
    } this.getVertices().forEach(o => { _.has(o.id) || this.addNodeFromVertex(o, i, u, f, e, e.look || "classic"); }); let g = this.getEdges(); return g.forEach((o, c) => { let { arrowTypeStart: E, arrowTypeEnd: B } = this.destructEdgeType(o.type), Q = [...g.defaultStyle ?? []], pe = y.get(o.start) ?? o.start, fe = y.get(o.end) ?? o.end; if (pe === fe && (y.has(o.start) || y.has(o.end)))
        return; o.style && Q.push(...o.style); let Te = { id: Ze(pe, fe, { counter: c, prefix: "L" }, o.id), isUserDefinedId: o.isUserDefinedId, start: pe, end: fe, type: o.type ?? "normal", label: o.text, labelType: o.labelType, labelpos: "c", thickness: o.stroke, minlen: o.length, classes: o?.stroke === "invisible" ? "" : "edge-thickness-normal edge-pattern-solid flowchart-link", arrowTypeStart: o?.stroke === "invisible" || o?.type === "arrow_open" ? "none" : E, arrowTypeEnd: o?.stroke === "invisible" || o?.type === "arrow_open" ? "none" : B, arrowheadStyle: "fill: #333", cssCompiledStyles: this.getCompiledStyles(o.classes), labelStyle: Q, style: Q, pattern: o.stroke, look: e.look, animate: o.animate, animation: o.animation, curve: o.interpolate || this.edges.defaultInterpolate || e.flowchart?.curve }; r.push(Te); }), { nodes: i, edges: r, other: {}, config: e }; }
    defaultConfig() { return i1.flowchart; }
}, T1 = A(function (e, i) { return i.db.getClasses(); }, "getClasses"), E1 = A(function (e, i, r, a) { return jt(this, null, function* () { Z.info("REF0:"), Z.info("Drawing state diagram (v2)", i); let { securityLevel: u, flowchart: f, layout: l } = de(); a.db.setDiagramId(i), Z.debug("Before getData: "); let k = a.db.getData(); Z.debug("Data: ", k); let h = h1(i, u), _ = a.db.getDirection(); k.type = a.type, k.layoutAlgorithm = o1(l), k.layoutAlgorithm === "dagre" && l === "elk" && Z.warn("flowchart-elk was moved to an external package in Mermaid v11. Please refer [release notes](https://github.com/mermaid-js/mermaid/releases/tag/v11.0.0) for more details. This diagram will be rendered using `dagre` layout as a fallback."), k.direction = _, k.nodeSpacing = f?.nodeSpacing || 50, k.rankSpacing = f?.rankSpacing || 50, k.markers = ["point", "circle", "cross"], k.diagramId = i, Z.debug("REF1:", k), yield u1(k, h); let y = k.config.flowchart?.diagramPadding ?? 8; Je.insertTitle(h, "flowchartTitleText", f?.titleTopMargin || 0, a.db.getDiagramTitle()), d1(h, y, "flowchart", f?.useMaxWidth || !1); }); }, "draw"), S1 = { getClasses: T1, draw: E1 }, ot = (function () {
    var e = A(function (ge, d, p, b) { for (p = p || {}, b = ge.length; b--; p[ge[b]] = d)
        ; return p; }, "o"), i = [1, 4], r = [1, 3], a = [1, 5], u = [1, 8, 9, 10, 11, 27, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], f = [2, 2], l = [1, 13], k = [1, 14], h = [1, 15], _ = [1, 16], y = [1, 23], L = [1, 25], g = [1, 26], o = [1, 27], c = [1, 50], E = [1, 49], B = [1, 29], Q = [1, 30], pe = [1, 31], fe = [1, 32], Te = [1, 33], I = [1, 45], w = [1, 47], R = [1, 43], N = [1, 48], G = [1, 44], P = [1, 51], O = [1, 46], M = [1, 52], U = [1, 53], Me = [1, 34], Ue = [1, 35], ze = [1, 36], We = [1, 37], je = [1, 38], be = [1, 58], S = [1, 8, 9, 10, 11, 27, 32, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], ee = [1, 62], te = [1, 61], se = [1, 63], Ee = [8, 9, 11, 75, 77, 78], lt = [1, 79], Se = [1, 92], ye = [1, 97], xe = [1, 96], Fe = [1, 93], _e = [1, 89], Be = [1, 95], ve = [1, 91], Le = [1, 98], Ve = [1, 94], Ie = [1, 99], we = [1, 90], Ae = [8, 9, 10, 11, 40, 75, 77, 78], W = [8, 9, 10, 11, 40, 46, 75, 77, 78], H = [8, 9, 10, 11, 29, 40, 44, 46, 48, 50, 52, 54, 56, 58, 60, 63, 65, 67, 68, 70, 75, 77, 78, 89, 102, 105, 106, 109, 111, 114, 115, 116], ct = [8, 9, 11, 44, 60, 75, 77, 78, 89, 102, 105, 106, 109, 111, 114, 115, 116], Re = [44, 60, 89, 102, 105, 106, 109, 111, 114, 115, 116], ht = [1, 122], dt = [1, 123], Ke = [1, 125], Ye = [1, 124], pt = [44, 60, 62, 74, 89, 102, 105, 106, 109, 111, 114, 115, 116], ft = [1, 134], bt = [1, 148], kt = [1, 149], gt = [1, 150], At = [1, 151], mt = [1, 136], Ct = [1, 138], Dt = [1, 142], Tt = [1, 143], Et = [1, 144], St = [1, 145], yt = [1, 146], xt = [1, 147], Ft = [1, 152], _t = [1, 153], Bt = [1, 132], vt = [1, 133], Lt = [1, 140], Vt = [1, 135], It = [1, 139], wt = [1, 137], $e = [8, 9, 10, 11, 27, 32, 34, 36, 38, 44, 60, 84, 85, 86, 87, 88, 89, 102, 105, 106, 109, 111, 114, 115, 116, 121, 122, 123, 124, 125], Rt = [1, 155], Nt = [1, 157], v = [8, 9, 11], q = [8, 9, 10, 11, 14, 44, 60, 89, 105, 106, 109, 111, 114, 115, 116], m = [1, 177], j = [1, 173], K = [1, 174], C = [1, 178], D = [1, 175], T = [1, 176], Ne = [77, 116, 119], x = [8, 9, 10, 11, 12, 14, 27, 29, 32, 44, 60, 75, 84, 85, 86, 87, 88, 89, 90, 105, 109, 111, 114, 115, 116], Gt = [10, 106], ke = [31, 49, 51, 53, 55, 57, 62, 64, 66, 67, 69, 71, 116, 117, 118], ie = [1, 248], re = [1, 246], ae = [1, 250], ne = [1, 244], ue = [1, 245], oe = [1, 247], le = [1, 249], ce = [1, 251], Ge = [1, 269], Pt = [8, 9, 11, 106], $ = [8, 9, 10, 11, 60, 84, 105, 106, 109, 110, 111, 112], et = { trace: A(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, graphConfig: 4, document: 5, line: 6, statement: 7, SEMI: 8, NEWLINE: 9, SPACE: 10, EOF: 11, GRAPH: 12, NODIR: 13, DIR: 14, FirstStmtSeparator: 15, ending: 16, endToken: 17, spaceList: 18, spaceListNewline: 19, vertexStatement: 20, separator: 21, styleStatement: 22, linkStyleStatement: 23, classDefStatement: 24, classStatement: 25, clickStatement: 26, subgraph: 27, textNoTags: 28, SQS: 29, text: 30, SQE: 31, end: 32, direction: 33, acc_title: 34, acc_title_value: 35, acc_descr: 36, acc_descr_value: 37, acc_descr_multiline_value: 38, shapeData: 39, SHAPE_DATA: 40, link: 41, node: 42, styledVertex: 43, AMP: 44, vertex: 45, STYLE_SEPARATOR: 46, idString: 47, DOUBLECIRCLESTART: 48, DOUBLECIRCLEEND: 49, PS: 50, PE: 51, "(-": 52, "-)": 53, STADIUMSTART: 54, STADIUMEND: 55, SUBROUTINESTART: 56, SUBROUTINEEND: 57, VERTEX_WITH_PROPS_START: 58, "NODE_STRING[field]": 59, COLON: 60, "NODE_STRING[value]": 61, PIPE: 62, CYLINDERSTART: 63, CYLINDEREND: 64, DIAMOND_START: 65, DIAMOND_STOP: 66, TAGEND: 67, TRAPSTART: 68, TRAPEND: 69, INVTRAPSTART: 70, INVTRAPEND: 71, linkStatement: 72, arrowText: 73, TESTSTR: 74, START_LINK: 75, edgeText: 76, LINK: 77, LINK_ID: 78, edgeTextToken: 79, STR: 80, MD_STR: 81, textToken: 82, keywords: 83, STYLE: 84, LINKSTYLE: 85, CLASSDEF: 86, CLASS: 87, CLICK: 88, DOWN: 89, UP: 90, textNoTagsToken: 91, stylesOpt: 92, "idString[vertex]": 93, "idString[class]": 94, CALLBACKNAME: 95, CALLBACKARGS: 96, HREF: 97, LINK_TARGET: 98, "STR[link]": 99, "STR[tooltip]": 100, alphaNum: 101, DEFAULT: 102, numList: 103, INTERPOLATE: 104, NUM: 105, COMMA: 106, style: 107, styleComponent: 108, NODE_STRING: 109, UNIT: 110, BRKT: 111, PCT: 112, idStringToken: 113, MINUS: 114, MULT: 115, UNICODE_TEXT: 116, TEXT: 117, TAGSTART: 118, EDGE_TEXT: 119, alphaNumToken: 120, direction_tb: 121, direction_bt: 122, direction_rl: 123, direction_lr: 124, direction_td: 125, $accept: 0, $end: 1 }, terminals_: { 2: "error", 8: "SEMI", 9: "NEWLINE", 10: "SPACE", 11: "EOF", 12: "GRAPH", 13: "NODIR", 14: "DIR", 27: "subgraph", 29: "SQS", 31: "SQE", 32: "end", 34: "acc_title", 35: "acc_title_value", 36: "acc_descr", 37: "acc_descr_value", 38: "acc_descr_multiline_value", 40: "SHAPE_DATA", 44: "AMP", 46: "STYLE_SEPARATOR", 48: "DOUBLECIRCLESTART", 49: "DOUBLECIRCLEEND", 50: "PS", 51: "PE", 52: "(-", 53: "-)", 54: "STADIUMSTART", 55: "STADIUMEND", 56: "SUBROUTINESTART", 57: "SUBROUTINEEND", 58: "VERTEX_WITH_PROPS_START", 59: "NODE_STRING[field]", 60: "COLON", 61: "NODE_STRING[value]", 62: "PIPE", 63: "CYLINDERSTART", 64: "CYLINDEREND", 65: "DIAMOND_START", 66: "DIAMOND_STOP", 67: "TAGEND", 68: "TRAPSTART", 69: "TRAPEND", 70: "INVTRAPSTART", 71: "INVTRAPEND", 74: "TESTSTR", 75: "START_LINK", 77: "LINK", 78: "LINK_ID", 80: "STR", 81: "MD_STR", 84: "STYLE", 85: "LINKSTYLE", 86: "CLASSDEF", 87: "CLASS", 88: "CLICK", 89: "DOWN", 90: "UP", 93: "idString[vertex]", 94: "idString[class]", 95: "CALLBACKNAME", 96: "CALLBACKARGS", 97: "HREF", 98: "LINK_TARGET", 99: "STR[link]", 100: "STR[tooltip]", 102: "DEFAULT", 104: "INTERPOLATE", 105: "NUM", 106: "COMMA", 109: "NODE_STRING", 110: "UNIT", 111: "BRKT", 112: "PCT", 114: "MINUS", 115: "MULT", 116: "UNICODE_TEXT", 117: "TEXT", 118: "TAGSTART", 119: "EDGE_TEXT", 121: "direction_tb", 122: "direction_bt", 123: "direction_rl", 124: "direction_lr", 125: "direction_td" }, productions_: [0, [3, 2], [5, 0], [5, 2], [6, 1], [6, 1], [6, 1], [6, 1], [6, 1], [4, 2], [4, 2], [4, 2], [4, 3], [16, 2], [16, 1], [17, 1], [17, 1], [17, 1], [15, 1], [15, 1], [15, 2], [19, 2], [19, 2], [19, 1], [19, 1], [18, 2], [18, 1], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 2], [7, 9], [7, 6], [7, 4], [7, 1], [7, 2], [7, 2], [7, 1], [21, 1], [21, 1], [21, 1], [39, 2], [39, 1], [20, 4], [20, 3], [20, 4], [20, 2], [20, 2], [20, 1], [42, 1], [42, 6], [42, 5], [43, 1], [43, 3], [45, 4], [45, 4], [45, 6], [45, 4], [45, 4], [45, 4], [45, 8], [45, 4], [45, 4], [45, 4], [45, 6], [45, 4], [45, 4], [45, 4], [45, 4], [45, 4], [45, 1], [41, 2], [41, 3], [41, 3], [41, 1], [41, 3], [41, 4], [76, 1], [76, 2], [76, 1], [76, 1], [72, 1], [72, 2], [73, 3], [30, 1], [30, 2], [30, 1], [30, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [83, 1], [28, 1], [28, 2], [28, 1], [28, 1], [24, 5], [25, 5], [26, 2], [26, 4], [26, 3], [26, 5], [26, 3], [26, 5], [26, 5], [26, 7], [26, 2], [26, 4], [26, 2], [26, 4], [26, 4], [26, 6], [22, 5], [23, 5], [23, 5], [23, 9], [23, 9], [23, 7], [23, 7], [103, 1], [103, 3], [92, 1], [92, 3], [107, 1], [107, 2], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [108, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [113, 1], [82, 1], [82, 1], [82, 1], [82, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [91, 1], [79, 1], [79, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [120, 1], [47, 1], [47, 2], [101, 1], [101, 2], [33, 1], [33, 1], [33, 1], [33, 1], [33, 1]], performAction: A(function (d, p, b, n, F, t, me) { var s = t.length - 1; switch (F) {
            case 2:
                this.$ = [];
                break;
            case 3:
                (!Array.isArray(t[s]) || t[s].length > 0) && t[s - 1].push(t[s]), this.$ = t[s - 1];
                break;
            case 4:
            case 183:
                this.$ = t[s];
                break;
            case 11:
                n.setDirection("TB"), this.$ = "TB";
                break;
            case 12:
                n.setDirection(t[s - 1]), this.$ = t[s - 1];
                break;
            case 27:
                this.$ = t[s - 1].nodes;
                break;
            case 28:
            case 29:
            case 30:
            case 31:
            case 32:
                this.$ = [];
                break;
            case 33:
                this.$ = n.addSubGraph(t[s - 6], t[s - 1], t[s - 4]);
                break;
            case 34:
                this.$ = n.addSubGraph(t[s - 3], t[s - 1], t[s - 3]);
                break;
            case 35:
                this.$ = n.addSubGraph(void 0, t[s - 1], void 0);
                break;
            case 37:
                this.$ = t[s].trim(), n.setAccTitle(this.$);
                break;
            case 38:
            case 39:
                this.$ = t[s].trim(), n.setAccDescription(this.$);
                break;
            case 43:
                this.$ = t[s - 1] + t[s];
                break;
            case 44:
                this.$ = t[s];
                break;
            case 45:
                n.addVertex(t[s - 1][t[s - 1].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, t[s]), n.addLink(t[s - 3].stmt, t[s - 1], t[s - 2]), this.$ = { stmt: t[s - 1], nodes: t[s - 1].concat(t[s - 3].nodes) };
                break;
            case 46:
                n.addLink(t[s - 2].stmt, t[s], t[s - 1]), this.$ = { stmt: t[s], nodes: t[s].concat(t[s - 2].nodes) };
                break;
            case 47:
                n.addLink(t[s - 3].stmt, t[s - 1], t[s - 2]), this.$ = { stmt: t[s - 1], nodes: t[s - 1].concat(t[s - 3].nodes) };
                break;
            case 48:
                this.$ = { stmt: t[s - 1], nodes: t[s - 1] };
                break;
            case 49:
                n.addVertex(t[s - 1][t[s - 1].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, t[s]), this.$ = { stmt: t[s - 1], nodes: t[s - 1], shapeData: t[s] };
                break;
            case 50:
                this.$ = { stmt: t[s], nodes: t[s] };
                break;
            case 51:
                this.$ = [t[s]];
                break;
            case 52:
                n.addVertex(t[s - 5][t[s - 5].length - 1], void 0, void 0, void 0, void 0, void 0, void 0, t[s - 4]), this.$ = t[s - 5].concat(t[s]);
                break;
            case 53:
                this.$ = t[s - 4].concat(t[s]);
                break;
            case 54:
                this.$ = t[s];
                break;
            case 55:
                this.$ = t[s - 2], n.setClass(t[s - 2], t[s]);
                break;
            case 56:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "square");
                break;
            case 57:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "doublecircle");
                break;
            case 58:
                this.$ = t[s - 5], n.addVertex(t[s - 5], t[s - 2], "circle");
                break;
            case 59:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "ellipse");
                break;
            case 60:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "stadium");
                break;
            case 61:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "subroutine");
                break;
            case 62:
                this.$ = t[s - 7], n.addVertex(t[s - 7], t[s - 1], "rect", void 0, void 0, void 0, Object.fromEntries([[t[s - 5], t[s - 3]]]));
                break;
            case 63:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "cylinder");
                break;
            case 64:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "round");
                break;
            case 65:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "diamond");
                break;
            case 66:
                this.$ = t[s - 5], n.addVertex(t[s - 5], t[s - 2], "hexagon");
                break;
            case 67:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "odd");
                break;
            case 68:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "trapezoid");
                break;
            case 69:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "inv_trapezoid");
                break;
            case 70:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "lean_right");
                break;
            case 71:
                this.$ = t[s - 3], n.addVertex(t[s - 3], t[s - 1], "lean_left");
                break;
            case 72:
                this.$ = t[s], n.addVertex(t[s]);
                break;
            case 73:
                t[s - 1].text = t[s], this.$ = t[s - 1];
                break;
            case 74:
            case 75:
                t[s - 2].text = t[s - 1], this.$ = t[s - 2];
                break;
            case 76:
                this.$ = t[s];
                break;
            case 77:
                var V = n.destructLink(t[s], t[s - 2]);
                this.$ = { type: V.type, stroke: V.stroke, length: V.length, text: t[s - 1] };
                break;
            case 78:
                var V = n.destructLink(t[s], t[s - 2]);
                this.$ = { type: V.type, stroke: V.stroke, length: V.length, text: t[s - 1], id: t[s - 3] };
                break;
            case 79:
                this.$ = { text: t[s], type: "text" };
                break;
            case 80:
                this.$ = { text: t[s - 1].text + "" + t[s], type: t[s - 1].type };
                break;
            case 81:
                this.$ = { text: t[s], type: "string" };
                break;
            case 82:
                this.$ = { text: t[s], type: "markdown" };
                break;
            case 83:
                var V = n.destructLink(t[s]);
                this.$ = { type: V.type, stroke: V.stroke, length: V.length };
                break;
            case 84:
                var V = n.destructLink(t[s]);
                this.$ = { type: V.type, stroke: V.stroke, length: V.length, id: t[s - 1] };
                break;
            case 85:
                this.$ = t[s - 1];
                break;
            case 86:
                this.$ = { text: t[s], type: "text" };
                break;
            case 87:
                this.$ = { text: t[s - 1].text + "" + t[s], type: t[s - 1].type };
                break;
            case 88:
                this.$ = { text: t[s], type: "string" };
                break;
            case 89:
            case 104:
                this.$ = { text: t[s], type: "markdown" };
                break;
            case 101:
                this.$ = { text: t[s], type: "text" };
                break;
            case 102:
                this.$ = { text: t[s - 1].text + "" + t[s], type: t[s - 1].type };
                break;
            case 103:
                this.$ = { text: t[s], type: "text" };
                break;
            case 105:
                this.$ = t[s - 4], n.addClass(t[s - 2], t[s]);
                break;
            case 106:
                this.$ = t[s - 4], n.setClass(t[s - 2], t[s]);
                break;
            case 107:
            case 115:
                this.$ = t[s - 1], n.setClickEvent(t[s - 1], t[s]);
                break;
            case 108:
            case 116:
                this.$ = t[s - 3], n.setClickEvent(t[s - 3], t[s - 2]), n.setTooltip(t[s - 3], t[s]);
                break;
            case 109:
                this.$ = t[s - 2], n.setClickEvent(t[s - 2], t[s - 1], t[s]);
                break;
            case 110:
                this.$ = t[s - 4], n.setClickEvent(t[s - 4], t[s - 3], t[s - 2]), n.setTooltip(t[s - 4], t[s]);
                break;
            case 111:
                this.$ = t[s - 2], n.setLink(t[s - 2], t[s]);
                break;
            case 112:
                this.$ = t[s - 4], n.setLink(t[s - 4], t[s - 2]), n.setTooltip(t[s - 4], t[s]);
                break;
            case 113:
                this.$ = t[s - 4], n.setLink(t[s - 4], t[s - 2], t[s]);
                break;
            case 114:
                this.$ = t[s - 6], n.setLink(t[s - 6], t[s - 4], t[s]), n.setTooltip(t[s - 6], t[s - 2]);
                break;
            case 117:
                this.$ = t[s - 1], n.setLink(t[s - 1], t[s]);
                break;
            case 118:
                this.$ = t[s - 3], n.setLink(t[s - 3], t[s - 2]), n.setTooltip(t[s - 3], t[s]);
                break;
            case 119:
                this.$ = t[s - 3], n.setLink(t[s - 3], t[s - 2], t[s]);
                break;
            case 120:
                this.$ = t[s - 5], n.setLink(t[s - 5], t[s - 4], t[s]), n.setTooltip(t[s - 5], t[s - 2]);
                break;
            case 121:
                this.$ = t[s - 4], n.addVertex(t[s - 2], void 0, void 0, t[s]);
                break;
            case 122:
                this.$ = t[s - 4], n.updateLink([t[s - 2]], t[s]);
                break;
            case 123:
                this.$ = t[s - 4], n.updateLink(t[s - 2], t[s]);
                break;
            case 124:
                this.$ = t[s - 8], n.updateLinkInterpolate([t[s - 6]], t[s - 2]), n.updateLink([t[s - 6]], t[s]);
                break;
            case 125:
                this.$ = t[s - 8], n.updateLinkInterpolate(t[s - 6], t[s - 2]), n.updateLink(t[s - 6], t[s]);
                break;
            case 126:
                this.$ = t[s - 6], n.updateLinkInterpolate([t[s - 4]], t[s]);
                break;
            case 127:
                this.$ = t[s - 6], n.updateLinkInterpolate(t[s - 4], t[s]);
                break;
            case 128:
            case 130:
                this.$ = [t[s]];
                break;
            case 129:
            case 131:
                t[s - 2].push(t[s]), this.$ = t[s - 2];
                break;
            case 133:
                this.$ = t[s - 1] + t[s];
                break;
            case 181:
                this.$ = t[s];
                break;
            case 182:
                this.$ = t[s - 1] + "" + t[s];
                break;
            case 184:
                this.$ = t[s - 1] + "" + t[s];
                break;
            case 185:
                this.$ = { stmt: "dir", value: "TB" };
                break;
            case 186:
                this.$ = { stmt: "dir", value: "BT" };
                break;
            case 187:
                this.$ = { stmt: "dir", value: "RL" };
                break;
            case 188:
                this.$ = { stmt: "dir", value: "LR" };
                break;
            case 189:
                this.$ = { stmt: "dir", value: "TD" };
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 9: i, 10: r, 12: a }, { 1: [3] }, e(u, f, { 5: 6 }), { 4: 7, 9: i, 10: r, 12: a }, { 4: 8, 9: i, 10: r, 12: a }, { 13: [1, 9], 14: [1, 10] }, { 1: [2, 1], 6: 11, 7: 12, 8: l, 9: k, 10: h, 11: _, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: y, 33: 24, 34: L, 36: g, 38: o, 42: 28, 43: 39, 44: c, 45: 40, 47: 41, 60: E, 84: B, 85: Q, 86: pe, 87: fe, 88: Te, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U, 121: Me, 122: Ue, 123: ze, 124: We, 125: je }, e(u, [2, 9]), e(u, [2, 10]), e(u, [2, 11]), { 8: [1, 55], 9: [1, 56], 10: be, 15: 54, 18: 57 }, e(S, [2, 3]), e(S, [2, 4]), e(S, [2, 5]), e(S, [2, 6]), e(S, [2, 7]), e(S, [2, 8]), { 8: ee, 9: te, 11: se, 21: 59, 41: 60, 72: 64, 75: [1, 65], 77: [1, 67], 78: [1, 66] }, { 8: ee, 9: te, 11: se, 21: 68 }, { 8: ee, 9: te, 11: se, 21: 69 }, { 8: ee, 9: te, 11: se, 21: 70 }, { 8: ee, 9: te, 11: se, 21: 71 }, { 8: ee, 9: te, 11: se, 21: 72 }, { 8: ee, 9: te, 10: [1, 73], 11: se, 21: 74 }, e(S, [2, 36]), { 35: [1, 75] }, { 37: [1, 76] }, e(S, [2, 39]), e(Ee, [2, 50], { 18: 77, 39: 78, 10: be, 40: lt }), { 10: [1, 80] }, { 10: [1, 81] }, { 10: [1, 82] }, { 10: [1, 83] }, { 14: Se, 44: ye, 60: xe, 80: [1, 87], 89: Fe, 95: [1, 84], 97: [1, 85], 101: 86, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we, 120: 88 }, e(S, [2, 185]), e(S, [2, 186]), e(S, [2, 187]), e(S, [2, 188]), e(S, [2, 189]), e(Ae, [2, 51]), e(Ae, [2, 54], { 46: [1, 100] }), e(W, [2, 72], { 113: 113, 29: [1, 101], 44: c, 48: [1, 102], 50: [1, 103], 52: [1, 104], 54: [1, 105], 56: [1, 106], 58: [1, 107], 60: E, 63: [1, 108], 65: [1, 109], 67: [1, 110], 68: [1, 111], 70: [1, 112], 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 114: O, 115: M, 116: U }), e(H, [2, 181]), e(H, [2, 142]), e(H, [2, 143]), e(H, [2, 144]), e(H, [2, 145]), e(H, [2, 146]), e(H, [2, 147]), e(H, [2, 148]), e(H, [2, 149]), e(H, [2, 150]), e(H, [2, 151]), e(H, [2, 152]), e(u, [2, 12]), e(u, [2, 18]), e(u, [2, 19]), { 9: [1, 114] }, e(ct, [2, 26], { 18: 115, 10: be }), e(S, [2, 27]), { 42: 116, 43: 39, 44: c, 45: 40, 47: 41, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, e(S, [2, 40]), e(S, [2, 41]), e(S, [2, 42]), e(Re, [2, 76], { 73: 117, 62: [1, 119], 74: [1, 118] }), { 76: 120, 79: 121, 80: ht, 81: dt, 116: Ke, 119: Ye }, { 75: [1, 126], 77: [1, 127] }, e(pt, [2, 83]), e(S, [2, 28]), e(S, [2, 29]), e(S, [2, 30]), e(S, [2, 31]), e(S, [2, 32]), { 10: ft, 12: bt, 14: kt, 27: gt, 28: 128, 32: At, 44: mt, 60: Ct, 75: Dt, 80: [1, 130], 81: [1, 131], 83: 141, 84: Tt, 85: Et, 86: St, 87: yt, 88: xt, 89: Ft, 90: _t, 91: 129, 105: Bt, 109: vt, 111: Lt, 114: Vt, 115: It, 116: wt }, e($e, f, { 5: 154 }), e(S, [2, 37]), e(S, [2, 38]), e(Ee, [2, 48], { 44: Rt }), e(Ee, [2, 49], { 18: 156, 10: be, 40: Nt }), e(Ae, [2, 44]), { 44: c, 47: 158, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, { 102: [1, 159], 103: 160, 105: [1, 161] }, { 44: c, 47: 162, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, { 44: c, 47: 163, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, e(v, [2, 107], { 10: [1, 164], 96: [1, 165] }), { 80: [1, 166] }, e(v, [2, 115], { 120: 168, 10: [1, 167], 14: Se, 44: ye, 60: xe, 89: Fe, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we }), e(v, [2, 117], { 10: [1, 169] }), e(q, [2, 183]), e(q, [2, 170]), e(q, [2, 171]), e(q, [2, 172]), e(q, [2, 173]), e(q, [2, 174]), e(q, [2, 175]), e(q, [2, 176]), e(q, [2, 177]), e(q, [2, 178]), e(q, [2, 179]), e(q, [2, 180]), { 44: c, 47: 170, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, { 30: 171, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 179, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 181, 50: [1, 180], 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 182, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 183, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 184, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 109: [1, 185] }, { 30: 186, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 187, 65: [1, 188], 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 189, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 190, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 30: 191, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, e(H, [2, 182]), e(u, [2, 20]), e(ct, [2, 25]), e(Ee, [2, 46], { 39: 192, 18: 193, 10: be, 40: lt }), e(Re, [2, 73], { 10: [1, 194] }), { 10: [1, 195] }, { 30: 196, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 77: [1, 197], 79: 198, 116: Ke, 119: Ye }, e(Ne, [2, 79]), e(Ne, [2, 81]), e(Ne, [2, 82]), e(Ne, [2, 168]), e(Ne, [2, 169]), { 76: 199, 79: 121, 80: ht, 81: dt, 116: Ke, 119: Ye }, e(pt, [2, 84]), { 8: ee, 9: te, 10: ft, 11: se, 12: bt, 14: kt, 21: 201, 27: gt, 29: [1, 200], 32: At, 44: mt, 60: Ct, 75: Dt, 83: 141, 84: Tt, 85: Et, 86: St, 87: yt, 88: xt, 89: Ft, 90: _t, 91: 202, 105: Bt, 109: vt, 111: Lt, 114: Vt, 115: It, 116: wt }, e(x, [2, 101]), e(x, [2, 103]), e(x, [2, 104]), e(x, [2, 157]), e(x, [2, 158]), e(x, [2, 159]), e(x, [2, 160]), e(x, [2, 161]), e(x, [2, 162]), e(x, [2, 163]), e(x, [2, 164]), e(x, [2, 165]), e(x, [2, 166]), e(x, [2, 167]), e(x, [2, 90]), e(x, [2, 91]), e(x, [2, 92]), e(x, [2, 93]), e(x, [2, 94]), e(x, [2, 95]), e(x, [2, 96]), e(x, [2, 97]), e(x, [2, 98]), e(x, [2, 99]), e(x, [2, 100]), { 6: 11, 7: 12, 8: l, 9: k, 10: h, 11: _, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: y, 32: [1, 203], 33: 24, 34: L, 36: g, 38: o, 42: 28, 43: 39, 44: c, 45: 40, 47: 41, 60: E, 84: B, 85: Q, 86: pe, 87: fe, 88: Te, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U, 121: Me, 122: Ue, 123: ze, 124: We, 125: je }, { 10: be, 18: 204 }, { 44: [1, 205] }, e(Ae, [2, 43]), { 10: [1, 206], 44: c, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 113, 114: O, 115: M, 116: U }, { 10: [1, 207] }, { 10: [1, 208], 106: [1, 209] }, e(Gt, [2, 128]), { 10: [1, 210], 44: c, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 113, 114: O, 115: M, 116: U }, { 10: [1, 211], 44: c, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 113, 114: O, 115: M, 116: U }, { 80: [1, 212] }, e(v, [2, 109], { 10: [1, 213] }), e(v, [2, 111], { 10: [1, 214] }), { 80: [1, 215] }, e(q, [2, 184]), { 80: [1, 216], 98: [1, 217] }, e(Ae, [2, 55], { 113: 113, 44: c, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 114: O, 115: M, 116: U }), { 31: [1, 218], 67: m, 82: 219, 116: C, 117: D, 118: T }, e(ke, [2, 86]), e(ke, [2, 88]), e(ke, [2, 89]), e(ke, [2, 153]), e(ke, [2, 154]), e(ke, [2, 155]), e(ke, [2, 156]), { 49: [1, 220], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 30: 221, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 51: [1, 222], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 53: [1, 223], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 55: [1, 224], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 57: [1, 225], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 60: [1, 226] }, { 64: [1, 227], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 66: [1, 228], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 30: 229, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, { 31: [1, 230], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 67: m, 69: [1, 231], 71: [1, 232], 82: 219, 116: C, 117: D, 118: T }, { 67: m, 69: [1, 234], 71: [1, 233], 82: 219, 116: C, 117: D, 118: T }, e(Ee, [2, 45], { 18: 156, 10: be, 40: Nt }), e(Ee, [2, 47], { 44: Rt }), e(Re, [2, 75]), e(Re, [2, 74]), { 62: [1, 235], 67: m, 82: 219, 116: C, 117: D, 118: T }, e(Re, [2, 77]), e(Ne, [2, 80]), { 77: [1, 236], 79: 198, 116: Ke, 119: Ye }, { 30: 237, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, e($e, f, { 5: 238 }), e(x, [2, 102]), e(S, [2, 35]), { 43: 239, 44: c, 45: 40, 47: 41, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, { 10: be, 18: 240 }, { 10: ie, 60: re, 84: ae, 92: 241, 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, { 10: ie, 60: re, 84: ae, 92: 252, 104: [1, 253], 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, { 10: ie, 60: re, 84: ae, 92: 254, 104: [1, 255], 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, { 105: [1, 256] }, { 10: ie, 60: re, 84: ae, 92: 257, 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, { 44: c, 47: 258, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, e(v, [2, 108]), { 80: [1, 259] }, { 80: [1, 260], 98: [1, 261] }, e(v, [2, 116]), e(v, [2, 118], { 10: [1, 262] }), e(v, [2, 119]), e(W, [2, 56]), e(ke, [2, 87]), e(W, [2, 57]), { 51: [1, 263], 67: m, 82: 219, 116: C, 117: D, 118: T }, e(W, [2, 64]), e(W, [2, 59]), e(W, [2, 60]), e(W, [2, 61]), { 109: [1, 264] }, e(W, [2, 63]), e(W, [2, 65]), { 66: [1, 265], 67: m, 82: 219, 116: C, 117: D, 118: T }, e(W, [2, 67]), e(W, [2, 68]), e(W, [2, 70]), e(W, [2, 69]), e(W, [2, 71]), e([10, 44, 60, 89, 102, 105, 106, 109, 111, 114, 115, 116], [2, 85]), e(Re, [2, 78]), { 31: [1, 266], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 6: 11, 7: 12, 8: l, 9: k, 10: h, 11: _, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: y, 32: [1, 267], 33: 24, 34: L, 36: g, 38: o, 42: 28, 43: 39, 44: c, 45: 40, 47: 41, 60: E, 84: B, 85: Q, 86: pe, 87: fe, 88: Te, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U, 121: Me, 122: Ue, 123: ze, 124: We, 125: je }, e(Ae, [2, 53]), { 43: 268, 44: c, 45: 40, 47: 41, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U }, e(v, [2, 121], { 106: Ge }), e(Pt, [2, 130], { 108: 270, 10: ie, 60: re, 84: ae, 105: ne, 109: ue, 110: oe, 111: le, 112: ce }), e($, [2, 132]), e($, [2, 134]), e($, [2, 135]), e($, [2, 136]), e($, [2, 137]), e($, [2, 138]), e($, [2, 139]), e($, [2, 140]), e($, [2, 141]), e(v, [2, 122], { 106: Ge }), { 10: [1, 271] }, e(v, [2, 123], { 106: Ge }), { 10: [1, 272] }, e(Gt, [2, 129]), e(v, [2, 105], { 106: Ge }), e(v, [2, 106], { 113: 113, 44: c, 60: E, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 114: O, 115: M, 116: U }), e(v, [2, 110]), e(v, [2, 112], { 10: [1, 273] }), e(v, [2, 113]), { 98: [1, 274] }, { 51: [1, 275] }, { 62: [1, 276] }, { 66: [1, 277] }, { 8: ee, 9: te, 11: se, 21: 278 }, e(S, [2, 34]), e(Ae, [2, 52]), { 10: ie, 60: re, 84: ae, 105: ne, 107: 279, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, e($, [2, 133]), { 14: Se, 44: ye, 60: xe, 89: Fe, 101: 280, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we, 120: 88 }, { 14: Se, 44: ye, 60: xe, 89: Fe, 101: 281, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we, 120: 88 }, { 98: [1, 282] }, e(v, [2, 120]), e(W, [2, 58]), { 30: 283, 67: m, 80: j, 81: K, 82: 172, 116: C, 117: D, 118: T }, e(W, [2, 66]), e($e, f, { 5: 284 }), e(Pt, [2, 131], { 108: 270, 10: ie, 60: re, 84: ae, 105: ne, 109: ue, 110: oe, 111: le, 112: ce }), e(v, [2, 126], { 120: 168, 10: [1, 285], 14: Se, 44: ye, 60: xe, 89: Fe, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we }), e(v, [2, 127], { 120: 168, 10: [1, 286], 14: Se, 44: ye, 60: xe, 89: Fe, 105: _e, 106: Be, 109: ve, 111: Le, 114: Ve, 115: Ie, 116: we }), e(v, [2, 114]), { 31: [1, 287], 67: m, 82: 219, 116: C, 117: D, 118: T }, { 6: 11, 7: 12, 8: l, 9: k, 10: h, 11: _, 20: 17, 22: 18, 23: 19, 24: 20, 25: 21, 26: 22, 27: y, 32: [1, 288], 33: 24, 34: L, 36: g, 38: o, 42: 28, 43: 39, 44: c, 45: 40, 47: 41, 60: E, 84: B, 85: Q, 86: pe, 87: fe, 88: Te, 89: I, 102: w, 105: R, 106: N, 109: G, 111: P, 113: 42, 114: O, 115: M, 116: U, 121: Me, 122: Ue, 123: ze, 124: We, 125: je }, { 10: ie, 60: re, 84: ae, 92: 289, 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, { 10: ie, 60: re, 84: ae, 92: 290, 105: ne, 107: 242, 108: 243, 109: ue, 110: oe, 111: le, 112: ce }, e(W, [2, 62]), e(S, [2, 33]), e(v, [2, 124], { 106: Ge }), e(v, [2, 125], { 106: Ge })], defaultActions: {}, parseError: A(function (d, p) { if (p.recoverable)
            this.trace(d);
        else {
            var b = new Error(d);
            throw b.hash = p, b;
        } }, "parseError"), parse: A(function (d) {
            var p = this, b = [0], n = [], F = [null], t = [], me = this.table, s = "", V = 0, Ot = 0, Mt = 0, k1 = 2, Ut = 1, g1 = t.slice.call(arguments, 1), z = Object.create(this.lexer), Ce = { yy: {} };
            for (var tt in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, tt) && (Ce.yy[tt] = this.yy[tt]);
            z.setInput(d, Ce.yy), Ce.yy.lexer = z, Ce.yy.parser = this, typeof z.yylloc > "u" && (z.yylloc = {});
            var st = z.yylloc;
            t.push(st);
            var A1 = z.options && z.options.ranges;
            typeof Ce.yy.parseError == "function" ? this.parseError = Ce.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function m1(X) { b.length = b.length - 2 * X, F.length = F.length - X, t.length = t.length - X; }
            A(m1, "popStack");
            function zt() { var X; return X = n.pop() || z.lex() || Ut, typeof X != "number" && (X instanceof Array && (n = X, X = n.pop()), X = p.symbols_[X] || X), X; }
            A(zt, "lex");
            for (var Y, it, De, J, v1, rt, Pe = {}, qe, he, Wt, Xe;;) {
                if (De = b[b.length - 1], this.defaultActions[De] ? J = this.defaultActions[De] : ((Y === null || typeof Y > "u") && (Y = zt()), J = me[De] && me[De][Y]), typeof J > "u" || !J.length || !J[0]) {
                    var at = "";
                    Xe = [];
                    for (qe in me[De])
                        this.terminals_[qe] && qe > k1 && Xe.push("'" + this.terminals_[qe] + "'");
                    z.showPosition ? at = "Parse error on line " + (V + 1) + `:
` + z.showPosition() + `
Expecting ` + Xe.join(", ") + ", got '" + (this.terminals_[Y] || Y) + "'" : at = "Parse error on line " + (V + 1) + ": Unexpected " + (Y == Ut ? "end of input" : "'" + (this.terminals_[Y] || Y) + "'"), this.parseError(at, { text: z.match, token: this.terminals_[Y] || Y, line: z.yylineno, loc: st, expected: Xe });
                }
                if (J[0] instanceof Array && J.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + De + ", token: " + Y);
                switch (J[0]) {
                    case 1:
                        b.push(Y), F.push(z.yytext), t.push(z.yylloc), b.push(J[1]), Y = null, it ? (Y = it, it = null) : (Ot = z.yyleng, s = z.yytext, V = z.yylineno, st = z.yylloc, Mt > 0 && Mt--);
                        break;
                    case 2:
                        if (he = this.productions_[J[1]][1], Pe.$ = F[F.length - he], Pe._$ = { first_line: t[t.length - (he || 1)].first_line, last_line: t[t.length - 1].last_line, first_column: t[t.length - (he || 1)].first_column, last_column: t[t.length - 1].last_column }, A1 && (Pe._$.range = [t[t.length - (he || 1)].range[0], t[t.length - 1].range[1]]), rt = this.performAction.apply(Pe, [s, Ot, V, Ce.yy, J[1], F, t].concat(g1)), typeof rt < "u")
                            return rt;
                        he && (b = b.slice(0, -1 * he * 2), F = F.slice(0, -1 * he), t = t.slice(0, -1 * he)), b.push(this.productions_[J[1]][0]), F.push(Pe.$), t.push(Pe._$), Wt = me[b[b.length - 2]][b[b.length - 1]], b.push(Wt);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, b1 = (function () {
        var ge = { EOF: 1, parseError: A(function (p, b) { if (this.yy.parser)
                this.yy.parser.parseError(p, b);
            else
                throw new Error(p); }, "parseError"), setInput: A(function (d, p) { return this.yy = p || this.yy || {}, this._input = d, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: A(function () { var d = this._input[0]; this.yytext += d, this.yyleng++, this.offset++, this.match += d, this.matched += d; var p = d.match(/(?:\r\n?|\n).*/g); return p ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), d; }, "input"), unput: A(function (d) { var p = d.length, b = d.split(/(?:\r\n?|\n)/g); this._input = d + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - p), this.offset -= p; var n = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), b.length - 1 && (this.yylineno -= b.length - 1); var F = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: b ? (b.length === n.length ? this.yylloc.first_column : 0) + n[n.length - b.length].length - b[0].length : this.yylloc.first_column - p }, this.options.ranges && (this.yylloc.range = [F[0], F[0] + this.yyleng - p]), this.yyleng = this.yytext.length, this; }, "unput"), more: A(function () { return this._more = !0, this; }, "more"), reject: A(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: A(function (d) { this.unput(this.match.slice(d)); }, "less"), pastInput: A(function () { var d = this.matched.substr(0, this.matched.length - this.match.length); return (d.length > 20 ? "..." : "") + d.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: A(function () { var d = this.match; return d.length < 20 && (d += this._input.substr(0, 20 - d.length)), (d.substr(0, 20) + (d.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: A(function () {
                var d = this.pastInput(), p = new Array(d.length + 1).join("-");
                return d + this.upcomingInput() + `
` + p + "^";
            }, "showPosition"), test_match: A(function (d, p) { var b, n, F; if (this.options.backtrack_lexer && (F = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (F.yylloc.range = this.yylloc.range.slice(0))), n = d[0].match(/(?:\r\n?|\n).*/g), n && (this.yylineno += n.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: n ? n[n.length - 1].length - n[n.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + d[0].length }, this.yytext += d[0], this.match += d[0], this.matches = d, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(d[0].length), this.matched += d[0], b = this.performAction.call(this, this.yy, this, p, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), b)
                return b; if (this._backtrack) {
                for (var t in F)
                    this[t] = F[t];
                return !1;
            } return !1; }, "test_match"), next: A(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var d, p, b, n;
                this._more || (this.yytext = "", this.match = "");
                for (var F = this._currentRules(), t = 0; t < F.length; t++)
                    if (b = this._input.match(this.rules[F[t]]), b && (!p || b[0].length > p[0].length)) {
                        if (p = b, n = t, this.options.backtrack_lexer) {
                            if (d = this.test_match(b, F[t]), d !== !1)
                                return d;
                            if (this._backtrack) {
                                p = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return p ? (d = this.test_match(p, F[n]), d !== !1 ? d : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: A(function () { var p = this.next(); return p || this.lex(); }, "lex"), begin: A(function (p) { this.conditionStack.push(p); }, "begin"), popState: A(function () { var p = this.conditionStack.length - 1; return p > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: A(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: A(function (p) { return p = this.conditionStack.length - 1 - Math.abs(p || 0), p >= 0 ? this.conditionStack[p] : "INITIAL"; }, "topState"), pushState: A(function (p) { this.begin(p); }, "pushState"), stateStackSize: A(function () { return this.conditionStack.length; }, "stateStackSize"), options: {}, performAction: A(function (p, b, n, F) { var t = F; switch (n) {
                case 0:
                    return this.begin("acc_title"), 34;
                    break;
                case 1:
                    return this.popState(), "acc_title_value";
                    break;
                case 2:
                    return this.begin("acc_descr"), 36;
                    break;
                case 3:
                    return this.popState(), "acc_descr_value";
                    break;
                case 4:
                    this.begin("acc_descr_multiline");
                    break;
                case 5:
                    this.popState();
                    break;
                case 6: return "acc_descr_multiline_value";
                case 7:
                    return this.pushState("shapeData"), b.yytext = "", 40;
                    break;
                case 8:
                    return this.pushState("shapeDataStr"), 40;
                    break;
                case 9:
                    return this.popState(), 40;
                    break;
                case 10:
                    let me = /\n\s*/g;
                    return b.yytext = b.yytext.replace(me, "<br/>"), 40;
                    break;
                case 11: return 40;
                case 12:
                    this.popState();
                    break;
                case 13:
                    this.begin("callbackname");
                    break;
                case 14:
                    this.popState();
                    break;
                case 15:
                    this.popState(), this.begin("callbackargs");
                    break;
                case 16: return 95;
                case 17:
                    this.popState();
                    break;
                case 18: return 96;
                case 19: return "MD_STR";
                case 20:
                    this.popState();
                    break;
                case 21:
                    this.begin("md_string");
                    break;
                case 22: return "STR";
                case 23:
                    this.popState();
                    break;
                case 24:
                    this.pushState("string");
                    break;
                case 25: return 84;
                case 26: return 102;
                case 27: return 85;
                case 28: return 104;
                case 29: return 86;
                case 30: return 87;
                case 31: return 97;
                case 32:
                    this.begin("click");
                    break;
                case 33:
                    this.popState();
                    break;
                case 34: return 88;
                case 35:
                    return p.lex.firstGraph() && this.begin("dir"), 12;
                    break;
                case 36:
                    return p.lex.firstGraph() && this.begin("dir"), 12;
                    break;
                case 37:
                    return p.lex.firstGraph() && this.begin("dir"), 12;
                    break;
                case 38:
                    return p.lex.firstGraph() && this.begin("dir"), 12;
                    break;
                case 39: return 27;
                case 40: return 32;
                case 41: return 98;
                case 42: return 98;
                case 43: return 98;
                case 44: return 98;
                case 45:
                    return this.popState(), 13;
                    break;
                case 46:
                    return this.popState(), 14;
                    break;
                case 47:
                    return this.popState(), 14;
                    break;
                case 48:
                    return this.popState(), 14;
                    break;
                case 49:
                    return this.popState(), 14;
                    break;
                case 50:
                    return this.popState(), 14;
                    break;
                case 51:
                    return this.popState(), 14;
                    break;
                case 52:
                    return this.popState(), 14;
                    break;
                case 53:
                    return this.popState(), 14;
                    break;
                case 54:
                    return this.popState(), 14;
                    break;
                case 55:
                    return this.popState(), 14;
                    break;
                case 56: return 121;
                case 57: return 122;
                case 58: return 123;
                case 59: return 124;
                case 60: return 125;
                case 61: return 78;
                case 62: return 105;
                case 63: return 111;
                case 64: return 46;
                case 65: return 60;
                case 66: return 44;
                case 67: return 8;
                case 68: return 106;
                case 69: return 115;
                case 70:
                    return this.popState(), 77;
                    break;
                case 71:
                    return this.pushState("edgeText"), 75;
                    break;
                case 72: return 119;
                case 73:
                    return this.popState(), 77;
                    break;
                case 74:
                    return this.pushState("thickEdgeText"), 75;
                    break;
                case 75: return 119;
                case 76:
                    return this.popState(), 77;
                    break;
                case 77:
                    return this.pushState("dottedEdgeText"), 75;
                    break;
                case 78: return 119;
                case 79: return 77;
                case 80:
                    return this.popState(), 53;
                    break;
                case 81: return "TEXT";
                case 82:
                    return this.pushState("ellipseText"), 52;
                    break;
                case 83:
                    return this.popState(), 55;
                    break;
                case 84:
                    return this.pushState("text"), 54;
                    break;
                case 85:
                    return this.popState(), 57;
                    break;
                case 86:
                    return this.pushState("text"), 56;
                    break;
                case 87: return 58;
                case 88:
                    return this.pushState("text"), 67;
                    break;
                case 89:
                    return this.popState(), 64;
                    break;
                case 90:
                    return this.pushState("text"), 63;
                    break;
                case 91:
                    return this.popState(), 49;
                    break;
                case 92:
                    return this.pushState("text"), 48;
                    break;
                case 93:
                    return this.popState(), 69;
                    break;
                case 94:
                    return this.popState(), 71;
                    break;
                case 95: return 117;
                case 96:
                    return this.pushState("trapText"), 68;
                    break;
                case 97:
                    return this.pushState("trapText"), 70;
                    break;
                case 98: return 118;
                case 99: return 67;
                case 100: return 90;
                case 101: return "SEP";
                case 102: return 89;
                case 103: return 115;
                case 104: return 111;
                case 105: return 44;
                case 106: return 109;
                case 107: return 114;
                case 108: return 116;
                case 109:
                    return this.popState(), 62;
                    break;
                case 110:
                    return this.pushState("text"), 62;
                    break;
                case 111:
                    return this.popState(), 51;
                    break;
                case 112:
                    return this.pushState("text"), 50;
                    break;
                case 113:
                    return this.popState(), 31;
                    break;
                case 114:
                    return this.pushState("text"), 29;
                    break;
                case 115:
                    return this.popState(), 66;
                    break;
                case 116:
                    return this.pushState("text"), 65;
                    break;
                case 117: return "TEXT";
                case 118: return "QUOTE";
                case 119: return 9;
                case 120: return 10;
                case 121: return 11;
            } }, "anonymous"), rules: [/^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:@\{)/, /^(?:["])/, /^(?:["])/, /^(?:[^\"]+)/, /^(?:[^}^"]+)/, /^(?:\})/, /^(?:call[\s]+)/, /^(?:\([\s]*\))/, /^(?:\()/, /^(?:[^(]*)/, /^(?:\))/, /^(?:[^)]*)/, /^(?:[^`"]+)/, /^(?:[`]["])/, /^(?:["][`])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:["])/, /^(?:style\b)/, /^(?:default\b)/, /^(?:linkStyle\b)/, /^(?:interpolate\b)/, /^(?:classDef\b)/, /^(?:class\b)/, /^(?:href[\s])/, /^(?:click[\s]+)/, /^(?:[\s\n])/, /^(?:[^\s\n]*)/, /^(?:flowchart-elk\b)/, /^(?:swimlane-beta\b)/, /^(?:graph\b)/, /^(?:flowchart\b)/, /^(?:subgraph\b)/, /^(?:end\b\s*)/, /^(?:_self\b)/, /^(?:_blank\b)/, /^(?:_parent\b)/, /^(?:_top\b)/, /^(?:(\r?\n)*\s*\n)/, /^(?:\s*LR\b)/, /^(?:\s*RL\b)/, /^(?:\s*TB\b)/, /^(?:\s*BT\b)/, /^(?:\s*TD\b)/, /^(?:\s*BR\b)/, /^(?:\s*<)/, /^(?:\s*>)/, /^(?:\s*\^)/, /^(?:\s*v\b)/, /^(?:.*direction\s+TB[^\n]*)/, /^(?:.*direction\s+BT[^\n]*)/, /^(?:.*direction\s+RL[^\n]*)/, /^(?:.*direction\s+LR[^\n]*)/, /^(?:.*direction\s+TD[^\n]*)/, /^(?:[^\s\"]+@(?=[^\{\"]))/, /^(?:[0-9]+)/, /^(?:#)/, /^(?::::)/, /^(?::)/, /^(?:&)/, /^(?:;)/, /^(?:,)/, /^(?:\*)/, /^(?:\s*[xo<]?--+[-xo>]\s*)/, /^(?:\s*[xo<]?--\s*)/, /^(?:[^-]|-(?!-)+)/, /^(?:\s*[xo<]?==+[=xo>]\s*)/, /^(?:\s*[xo<]?==\s*)/, /^(?:[^=]|=(?!))/, /^(?:\s*[xo<]?-?\.+-[xo>]?\s*)/, /^(?:\s*[xo<]?-\.\s*)/, /^(?:[^\.]|\.(?!))/, /^(?:\s*~~[\~]+\s*)/, /^(?:[-/\)][\)])/, /^(?:[^\(\)\[\]\{\}]|!\)+)/, /^(?:\(-)/, /^(?:\]\))/, /^(?:\(\[)/, /^(?:\]\])/, /^(?:\[\[)/, /^(?:\[\|)/, /^(?:>)/, /^(?:\)\])/, /^(?:\[\()/, /^(?:\)\)\))/, /^(?:\(\(\()/, /^(?:[\\(?=\])][\]])/, /^(?:\/(?=\])\])/, /^(?:\/(?!\])|\\(?!\])|[^\\\[\]\(\)\{\}\/]+)/, /^(?:\[\/)/, /^(?:\[\\)/, /^(?:<)/, /^(?:>)/, /^(?:\^)/, /^(?:\\\|)/, /^(?:v\b)/, /^(?:\*)/, /^(?:#)/, /^(?:&)/, /^(?:([A-Za-z0-9!"\#$%&'*+\.`?\\_\/]|-(?=[^\>\-\.])|(?!))+)/, /^(?:-)/, /^(?:[\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6]|[\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377]|[\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5]|[\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA]|[\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE]|[\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA]|[\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0]|[\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977]|[\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2]|[\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A]|[\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39]|[\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8]|[\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C]|[\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C]|[\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99]|[\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0]|[\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D]|[\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3]|[\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10]|[\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1]|[\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81]|[\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3]|[\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6]|[\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A]|[\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081]|[\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D]|[\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0]|[\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310]|[\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C]|[\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711]|[\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7]|[\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C]|[\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16]|[\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF]|[\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC]|[\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D]|[\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D]|[\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3]|[\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F]|[\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128]|[\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184]|[\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3]|[\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6]|[\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE]|[\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C]|[\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D]|[\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC]|[\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B]|[\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788]|[\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805]|[\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB]|[\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28]|[\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5]|[\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4]|[\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E]|[\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D]|[\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36]|[\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D]|[\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC]|[\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF]|[\uFFD2-\uFFD7\uFFDA-\uFFDC])/, /^(?:\|)/, /^(?:\|)/, /^(?:\))/, /^(?:\()/, /^(?:\])/, /^(?:\[)/, /^(?:(\}))/, /^(?:\{)/, /^(?:[^\[\]\(\)\{\}\|\"]+)/, /^(?:")/, /^(?:(\r?\n)+)/, /^(?:\s)/, /^(?:$)/], conditions: { shapeDataEndBracket: { rules: [21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, shapeDataStr: { rules: [9, 10, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, shapeData: { rules: [8, 11, 12, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, callbackargs: { rules: [17, 18, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, callbackname: { rules: [14, 15, 16, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, href: { rules: [21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, click: { rules: [21, 24, 33, 34, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, dottedEdgeText: { rules: [21, 24, 76, 78, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, thickEdgeText: { rules: [21, 24, 73, 75, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, edgeText: { rules: [21, 24, 70, 72, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, trapText: { rules: [21, 24, 79, 82, 84, 86, 90, 92, 93, 94, 95, 96, 97, 110, 112, 114, 116], inclusive: !1 }, ellipseText: { rules: [21, 24, 79, 80, 81, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, text: { rules: [21, 24, 79, 82, 83, 84, 85, 86, 89, 90, 91, 92, 96, 97, 109, 110, 111, 112, 113, 114, 115, 116, 117], inclusive: !1 }, vertex: { rules: [21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, dir: { rules: [21, 24, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, acc_descr_multiline: { rules: [5, 6, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, acc_descr: { rules: [3, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, acc_title: { rules: [1, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, md_string: { rules: [19, 20, 21, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, string: { rules: [21, 22, 23, 24, 79, 82, 84, 86, 90, 92, 96, 97, 110, 112, 114, 116], inclusive: !1 }, INITIAL: { rules: [0, 2, 4, 7, 13, 21, 24, 25, 26, 27, 28, 29, 30, 31, 32, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 73, 74, 76, 77, 79, 82, 84, 86, 87, 88, 90, 92, 96, 97, 98, 99, 100, 101, 102, 103, 104, 105, 106, 107, 108, 110, 112, 114, 116, 118, 119, 120, 121], inclusive: !0 } } };
        return ge;
    })();
    et.lexer = b1;
    function He() { this.yy = {}; }
    return A(He, "Parser"), He.prototype = et, et.Parser = He, new He;
})();
ot.parser = ot;
var p1 = ot, f1 = Object.assign({}, p1);
f1.parse = e => {
    let i = e.replace(/}\s*\n/g, `}
`);
    return p1.parse(i);
};
var y1 = f1, x1 = A((e, i) => { let r = Yt, a = r(e, "r"), u = r(e, "g"), f = r(e, "b"); return Kt(a, u, f, i); }, "fade"), F1 = A(e => `.label {
    font-family: ${e.fontFamily};
    color: ${e.nodeTextColor || e.textColor};
  }
  .cluster-label text {
    fill: ${e.titleColor};
  }
  .cluster-label span {
    color: ${e.titleColor};
  }
  .cluster-label span p {
    background-color: transparent;
  }

  .label text,span {
    fill: ${e.nodeTextColor || e.textColor};
    color: ${e.nodeTextColor || e.textColor};
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${e.mainBkg};
    stroke: ${e.nodeBorder};
    stroke-width: ${e.strokeWidth ?? 1}px;
  }
  .rough-node .label text , .node .label text, .image-shape .label, .icon-shape .label {
    text-anchor: middle;
  }

  .node .katex path {
    fill: #000;
    stroke: #000;
    stroke-width: 1px;
  }

  .rough-node .label,.node .label, .image-shape .label, .icon-shape .label {
    text-align: center;
  }
  .node.clickable {
    cursor: pointer;
  }


  .root .anchor path {
    fill: ${e.lineColor} !important;
    stroke-width: 0;
    stroke: ${e.lineColor};
  }

  .arrowheadPath {
    fill: ${e.arrowheadColor};
  }

  .edgePaths .path {
    stroke: ${e.lineColor};
    stroke-width: ${e.strokeWidth ?? 2}px;
  }

  .flowchart-link {
    stroke: ${e.lineColor};
    fill: none;
  }

  .edgeLabel {
    background-color: ${e.edgeLabelBackground};
    p {
      background-color: ${e.edgeLabelBackground};
    }
    rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }

  /* For html labels only */
  .labelBkg {
    background-color: ${x1(e.edgeLabelBackground, .5)};
    // background-color:
  }

  .cluster rect {
    fill: ${e.clusterBkg};
    stroke: ${e.clusterBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${e.titleColor};
  }

  .cluster span {
    color: ${e.titleColor};
  }
  /* .cluster div {
    color: ${e.titleColor};
  } */

  /* Collapsed subgraph node (@{ view: collapsed }) */
  .node .collapsed-indicator {
    fill: ${e.clusterBorder};
    stroke: none;
    opacity: 0.6;
  }

  .node .collapsed-separator {
    stroke: ${e.clusterBorder};
    stroke-width: 0.75px;
  }

  div.mermaidTooltip {
    position: absolute;
    text-align: center;
    max-width: 200px;
    padding: 2px;
    font-family: ${e.fontFamily};
    font-size: 12px;
    background: ${e.tertiaryColor};
    border: 1px solid ${e.border2};
    border-radius: 2px;
    pointer-events: none;
    z-index: 100;
  }

  .flowchartTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }

  rect.text {
    fill: none;
    stroke-width: 0;
  }

  .icon-shape, .image-shape {
    background-color: ${e.edgeLabelBackground};
    p {
      background-color: ${e.edgeLabelBackground};
      padding: 2px;
    }
    .label rect {
      opacity: 0.5;
      background-color: ${e.edgeLabelBackground};
      fill: ${e.edgeLabelBackground};
    }
    text-align: center;
  }
  ${c1()}
`, "getStyles"), _1 = F1, B1 = A(({ defaultLayout: e, styles: i = _1 } = {}) => ({ parser: y1, get db() { return new D1; }, renderer: S1, styles: i, init: A(r => { r.flowchart || (r.flowchart = {}); let a = qt().layout ?? e ?? r.layout; a && ut({ layout: a }), r.flowchart.arrowMarkerAbsolute = r.arrowMarkerAbsolute, ut({ flowchart: { arrowMarkerAbsolute: r.arrowMarkerAbsolute } }); }, "init") }), "createFlowDiagram"), K1 = B1();
export { _1 as a, B1 as b, K1 as c };
