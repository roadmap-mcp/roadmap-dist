import { a as o, b as n, c as s, d as i, e as l, g as d, t as m, w as c, y as p } from "@nf-internal/chunk-EPGORQP5";
var f = class extends p {
    static { o(this, "TreemapTokenBuilder"); }
    constructor() { super(["treemap"]); }
}, u = /classDef\s+([A-Z_a-z]\w+)(?:\s+([^\n\r;]*))?;?/, v = class extends c {
    static { o(this, "TreemapValueConverter"); }
    runCustomConverter(r, e, t) { if (r.name === "NUMBER2")
        return parseFloat(e.replace(/,/g, "")); if (r.name === "SEPARATOR")
        return e.substring(1, e.length - 1); if (r.name === "STRING2")
        return e.substring(1, e.length - 1); if (r.name === "INDENTATION")
        return e.length; if (r.name === "ClassDef") {
        if (typeof e != "string")
            return e;
        let a = u.exec(e);
        if (a)
            return { $type: "ClassDefStatement", className: a[1], styleText: a[2] || void 0 };
    } }
};
function T(r) { let e = r.validation.TreemapValidator, t = r.validation.ValidationRegistry; if (t) {
    let a = { Treemap: e.checkSingleRoot.bind(e) };
    t.register(a, e);
} }
o(T, "registerValidationChecks");
var g = class {
    static { o(this, "TreemapValidator"); }
    checkSingleRoot(r, e) { let t; for (let a of r.TreemapRows)
        a.item && (t === void 0 && a.indent === void 0 ? t = 0 : a.indent === void 0 ? e("error", "Multiple root nodes are not allowed in a treemap.", { node: a, property: "item" }) : t !== void 0 && t >= parseInt(a.indent, 10) && e("error", "Multiple root nodes are not allowed in a treemap.", { node: a, property: "item" })); }
}, h = { parser: { TokenBuilder: o(() => new f, "TokenBuilder"), ValueConverter: o(() => new v, "ValueConverter") }, validation: { TreemapValidator: o(() => new g, "TreemapValidator") } };
function C(r = l) { let e = i(s(r), d), t = i(n({ shared: e }), m, h); return e.ServiceRegistry.register(t), T(t), { shared: e, Treemap: t }; }
o(C, "createTreemapServices");
export { h as a, C as b };
