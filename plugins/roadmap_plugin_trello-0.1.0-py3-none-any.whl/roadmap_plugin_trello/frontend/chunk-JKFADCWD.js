import { f as g } from "@nf-internal/chunk-VEDGZ2C2";
import { t as o } from "@nf-internal/chunk-FDRUJGNH";
import { b as f } from "@nf-internal/chunk-RZWXGGKD";
import { a as s } from "@nf-internal/chunk-YUSHYV7C";
import { f as h } from "@nf-internal/chunk-OSQMNGTH";
var k = s(({ flowchart: a }) => { let t = a?.subGraphTitleMargin?.top ?? 0, i = a?.subGraphTitleMargin?.bottom ?? 0, r = t + i; return { subGraphTitleTopMargin: t, subGraphTitleBottomMargin: i, subGraphTitleTotalMargin: r }; }, "getSubGraphTitleMargins"), l = new Map;
function n(a, t, i) { return h(this, null, function* () { let r, e; t.shape === "rect" && (t.rx && t.ry ? t.shape = "roundedRect" : t.shape = "squareRect"); let p = t.shape ? g[t.shape] : void 0; if (!p)
    throw new Error(`No such shape: ${t.shape}. Please check your syntax.`); if (t.link) {
    let c;
    i.config.securityLevel === "sandbox" ? c = "_top" : t.linkTarget && (c = t.linkTarget || "_blank"), r = a.insert("svg:a").attr("xlink:href", t.link).attr("target", c ?? null), e = yield p(r, t, i);
}
else
    e = yield p(a, t, i), r = e; return r.attr("data-look", o(t.look)), t.tooltip && e.attr("title", t.tooltip), l.set(t.id, r), t.haveCallback && r.attr("class", r.attr("class") + " clickable"), r; }); }
s(n, "insertNode");
var v = s((a, t) => { l.set(t.id, a); }, "setNodeElem"), w = s(() => { l.clear(); }, "clear"), x = s(a => { let t = l.get(a.id); f.trace("Transforming node", a.diff, a, "translate(" + (a.x - a.width / 2 - 5) + ", " + a.width / 2 + ")"); let i = 8, r = a.diff || 0; return a.clusterNode ? t.attr("transform", "translate(" + (a.x + r - a.width / 2) + ", " + (a.y - a.height / 2 - i) + ")") : t.attr("transform", "translate(" + a.x + ", " + a.y + ")"), r; }, "positionNode");
export { k as a, n as b, v as c, w as d, x as e };
