import { a as T } from "@nf-internal/chunk-6BFRUI2I";
import { a as k } from "@nf-internal/chunk-LYW4QERV";
import "@nf-internal/chunk-RNULGOC3";
import "@nf-internal/chunk-Z4DWJRNS";
import { a as c } from "@nf-internal/chunk-SVIUGILY";
import { M as R, e as M, l as I, o as x, p as D, q as W, r as S, s as F, t as L } from "@nf-internal/chunk-LAIZNMCN";
import { a as O } from "@nf-internal/chunk-7RHXFCZM";
import { a as _ } from "@nf-internal/chunk-RMOXI6XO";
import { c as K } from "@nf-internal/chunk-6QY5OUOO";
import { a as A } from "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-OSQMNGTH";
import * as n from "@angular/core";
import { inject as d, signal as g, ElementRef as w, NgZone as N, ChangeDetectorRef as E, Renderer2 as H, booleanAttribute as u, forwardRef as P, numberAttribute as B } from "@angular/core";
import { NG_VALUE_ACCESSOR as j } from "@angular/forms";
import { Subject as f, defer as q, merge as C } from "rxjs";
import { startWith as m, switchMap as z, map as Q, takeUntil as b, filter as U } from "rxjs/operators";
import "@angular/common";
var y = class extends T {
    multiple;
    constructor(p = !1, e, t = !0, i) { super(!0, e, t, i), this.multiple = p; }
    isMultipleSelection() { return this.multiple; }
    select(...p) { return this.multiple ? super.select(...p) : super.setSelection(...p); }
}, G = (() => { class l {
    get id() { return this._id || this._generatedId; }
    set id(e) { this._id = e; }
    _id;
    _generatedId = d(_).getId("cdk-option-");
    value;
    typeaheadLabel = null;
    get disabled() { return this.listbox.disabled || this._disabled(); }
    set disabled(e) { this._disabled.set(e); }
    _disabled = g(!1);
    get enabledTabIndex() { return this._enabledTabIndex() === void 0 ? this.listbox.enabledTabIndex : this._enabledTabIndex(); }
    set enabledTabIndex(e) { this._enabledTabIndex.set(e); }
    _enabledTabIndex = g(void 0);
    element = d(w).nativeElement;
    listbox = d(Z);
    destroyed = new f;
    _clicked = new f;
    ngOnDestroy() { this.destroyed.next(), this.destroyed.complete(); }
    isSelected() { return this.listbox.isSelected(this); }
    isActive() { return this.listbox.isActive(this); }
    toggle() { this.listbox.toggle(this); }
    select() { this.listbox.select(this); }
    deselect() { this.listbox.deselect(this); }
    focus() { this.element.focus(); }
    getLabel() { return (this.typeaheadLabel ?? this.element.textContent?.trim()) || ""; }
    setActiveStyles() { this.listbox.useActiveDescendant && this.element.scrollIntoView({ block: "nearest", inline: "nearest" }); }
    setInactiveStyles() { }
    _handleFocus() { this.listbox.useActiveDescendant && (this.listbox._setActiveOption(this), this.listbox.focus()); }
    _getTabIndex() { return this.listbox.useActiveDescendant || this.disabled ? -1 : this.isActive() ? this.enabledTabIndex : -1; }
    static \u0275fac = function (t) { return new (t || l); };
    static \u0275dir = n.\u0275\u0275defineDirective({ type: l, selectors: [["", "cdkOption", ""]], hostAttrs: ["role", "option", 1, "cdk-option"], hostVars: 6, hostBindings: function (t, i) { t & 1 && n.\u0275\u0275listener("click", function (a) { return i._clicked.next(a); })("focus", function () { return i._handleFocus(); }), t & 2 && (n.\u0275\u0275domProperty("id", i.id), n.\u0275\u0275attribute("aria-selected", i.isSelected())("tabindex", i._getTabIndex())("aria-disabled", i.disabled), n.\u0275\u0275classProp("cdk-option-active", i.isActive())); }, inputs: { id: "id", value: [0, "cdkOption", "value"], typeaheadLabel: [0, "cdkOptionTypeaheadLabel", "typeaheadLabel"], disabled: [2, "cdkOptionDisabled", "disabled", u], enabledTabIndex: [2, "tabindex", "enabledTabIndex", e => e == null ? void 0 : B(e)] }, exportAs: ["cdkOption"] });
} return l; })(), Z = (() => { class l {
    _cleanupWindowBlur;
    get id() { return this._id || this._generatedId; }
    set id(e) { this._id = e; }
    _id;
    _generatedId = d(_).getId("cdk-listbox-");
    get enabledTabIndex() { return this._enabledTabIndex() === void 0 ? 0 : this._enabledTabIndex(); }
    set enabledTabIndex(e) { this._enabledTabIndex.set(e); }
    _enabledTabIndex = g(void 0);
    get value() { return this._invalid ? [] : this.selectionModel.selected; }
    set value(e) { this._setSelection(e); }
    get multiple() { return this.selectionModel.multiple; }
    set multiple(e) { this.selectionModel.multiple = e, this.options && this._updateInternalValue(); }
    get disabled() { return this._disabled(); }
    set disabled(e) { this._disabled.set(e); }
    _disabled = g(!1);
    get useActiveDescendant() { return this._useActiveDescendant(); }
    set useActiveDescendant(e) { this._useActiveDescendant.set(e); }
    _useActiveDescendant = g(!1);
    get orientation() { return this._orientation; }
    set orientation(e) { this._orientation = e === "horizontal" ? "horizontal" : "vertical", e === "horizontal" ? this.listKeyManager?.withHorizontalOrientation(this._dir?.value || "ltr") : this.listKeyManager?.withVerticalOrientation(); }
    _orientation = "vertical";
    get compareWith() { return this.selectionModel.compareWith; }
    set compareWith(e) { this.selectionModel.compareWith = e; }
    get navigationWrapDisabled() { return this._navigationWrapDisabled; }
    set navigationWrapDisabled(e) { this._navigationWrapDisabled = e, this.listKeyManager?.withWrap(!this._navigationWrapDisabled); }
    _navigationWrapDisabled = !1;
    get navigateDisabledOptions() { return this._navigateDisabledOptions; }
    set navigateDisabledOptions(e) { this._navigateDisabledOptions = e, this.listKeyManager?.skipPredicate(this._navigateDisabledOptions ? this._skipNonePredicate : this._skipDisabledPredicate); }
    _navigateDisabledOptions = !1;
    valueChange = new f;
    options;
    selectionModel = new y;
    listKeyManager;
    destroyed = new f;
    element = d(w).nativeElement;
    ngZone = d(N);
    changeDetectorRef = d(E);
    _invalid = !1;
    _lastTriggered = null;
    _onTouched = () => { };
    _onChange = () => { };
    _optionClicked = q(() => this.options.changes.pipe(m(this.options), z(e => C(...e.map(t => t._clicked.pipe(Q(i => ({ option: t, event: i }))))))));
    _dir = d(K, { optional: !0 });
    _isBrowser = d(O).isBrowser;
    _skipDisabledPredicate = e => e.disabled;
    _skipNonePredicate = () => !1;
    _hasFocus = !1;
    _previousActiveOption = null;
    constructor() { if (this._isBrowser) {
        let e = d(H);
        this._cleanupWindowBlur = this.ngZone.runOutsideAngular(() => e.listen("window", "blur", () => { this.element.contains(document.activeElement) && this._previousActiveOption && (this._setActiveOption(this._previousActiveOption), this._previousActiveOption = null); }));
    } }
    ngAfterContentInit() { this._initKeyManager(), C(this.selectionModel.changed, this.options.changes).pipe(m(null), b(this.destroyed)).subscribe(() => this._updateInternalValue()), this._optionClicked.pipe(U(({ option: e }) => !e.disabled), b(this.destroyed)).subscribe(({ option: e, event: t }) => this._handleOptionClicked(e, t)); }
    ngOnDestroy() { this._cleanupWindowBlur?.(), this.listKeyManager?.destroy(), this.destroyed.next(), this.destroyed.complete(); }
    toggle(e) { this.toggleValue(e.value); }
    toggleValue(e) { this._invalid && this.selectionModel.clear(!1), this.selectionModel.toggle(e); }
    select(e) { this.selectValue(e.value); }
    selectValue(e) { this._invalid && this.selectionModel.clear(!1), this.selectionModel.select(e); }
    deselect(e) { this.deselectValue(e.value); }
    deselectValue(e) { this._invalid && this.selectionModel.clear(!1), this.selectionModel.deselect(e); }
    setAllSelected(e) { e ? (this._invalid && this.selectionModel.clear(!1), this.selectionModel.select(...this.options.map(t => t.value))) : this.selectionModel.clear(); }
    isSelected(e) { return this.isValueSelected(e.value); }
    isActive(e) { return this.listKeyManager?.activeItem === e; }
    isValueSelected(e) { return this._invalid ? !1 : this.selectionModel.isSelected(e); }
    registerOnChange(e) { this._onChange = e; }
    registerOnTouched(e) { this._onTouched = e; }
    writeValue(e) { this._setSelection(e), this._verifyOptionValues(); }
    setDisabledState(e) { this.disabled = e, this.changeDetectorRef.markForCheck(); }
    focus() { this.element.focus(); }
    triggerOption(e) { e && !e.disabled && (this._lastTriggered = e, (this.multiple ? this.selectionModel.toggle(e.value) : this.selectionModel.select(e.value)) && (this._onChange(this.value), this.valueChange.next({ value: this.value, listbox: this, option: e }))); }
    triggerRange(e, t, i, s) { if (this.disabled || e && e.disabled)
        return; this._lastTriggered = e; let a = this.compareWith ?? Object.is, o = [...this.options].slice(Math.max(0, Math.min(t, i)), Math.min(this.options.length, Math.max(t, i) + 1)).filter(h => !h.disabled).map(h => h.value), r = [...this.value]; for (let h of o) {
        let v = r.findIndex(V => a(V, h));
        s && v === -1 ? r.push(h) : !s && v !== -1 && r.splice(v, 1);
    } this.selectionModel.setSelection(...r) && (this._onChange(this.value), this.valueChange.next({ value: this.value, listbox: this, option: e })); }
    _setActiveOption(e) { this.listKeyManager.setActiveItem(e); }
    _handleFocus() { this.useActiveDescendant || (this.selectionModel.selected.length > 0 ? this._setNextFocusToSelectedOption() : this.listKeyManager.setNextItemActive(), this._focusActiveOption()); }
    _handleKeydown(e) { if (this.disabled)
        return; let { keyCode: t } = e, i = this.listKeyManager.activeItemIndex, s = ["ctrlKey", "metaKey"]; if (this.multiple && t === 65 && c(e, ...s)) {
        this.triggerRange(null, 0, this.options.length - 1, this.options.length !== this.value.length), e.preventDefault();
        return;
    } if (this.multiple && (t === 32 || t === 13) && c(e, "shiftKey")) {
        this.listKeyManager.activeItem && this.listKeyManager.activeItemIndex != null && this.triggerRange(this.listKeyManager.activeItem, this._getLastTriggeredIndex() ?? this.listKeyManager.activeItemIndex, this.listKeyManager.activeItemIndex, !this.listKeyManager.activeItem.isSelected()), e.preventDefault();
        return;
    } if (this.multiple && t === 36 && c(e, ...s) && c(e, "shiftKey")) {
        let o = this.listKeyManager.activeItem;
        if (o) {
            let r = this.listKeyManager.activeItemIndex;
            this.listKeyManager.setFirstItemActive(), this.triggerRange(o, r, this.listKeyManager.activeItemIndex, !o.isSelected());
        }
        e.preventDefault();
        return;
    } if (this.multiple && t === 35 && c(e, ...s) && c(e, "shiftKey")) {
        let o = this.listKeyManager.activeItem;
        if (o) {
            let r = this.listKeyManager.activeItemIndex;
            this.listKeyManager.setLastItemActive(), this.triggerRange(o, r, this.listKeyManager.activeItemIndex, !o.isSelected());
        }
        e.preventDefault();
        return;
    } if (t === 32 || t === 13) {
        this.triggerOption(this.listKeyManager.activeItem), e.preventDefault();
        return;
    } let a = t === 38 || t === 40 || t === 37 || t === 39 || t === 36 || t === 35; this.listKeyManager.onKeydown(e), a && e.shiftKey && i !== this.listKeyManager.activeItemIndex && this.triggerOption(this.listKeyManager.activeItem); }
    _handleFocusIn() { this._hasFocus = !0; }
    _handleFocusOut(e) { this._previousActiveOption = this.listKeyManager.activeItem; let t = e.relatedTarget; this.element !== t && !this.element.contains(t) && (this._onTouched(), this._hasFocus = !1, this._setNextFocusToSelectedOption()); }
    _getAriaActiveDescendant() { return this.useActiveDescendant ? this.listKeyManager?.activeItem?.id : null; }
    _getTabIndex() { return this.disabled ? -1 : this.useActiveDescendant || !this.listKeyManager.activeItem ? this.enabledTabIndex : -1; }
    _initKeyManager() { this.listKeyManager = new k(this.options).withWrap(!this._navigationWrapDisabled).withTypeAhead().withHomeAndEnd().withAllowedModifierKeys(["shiftKey"]).skipPredicate(this._navigateDisabledOptions ? this._skipNonePredicate : this._skipDisabledPredicate), this.orientation === "vertical" ? this.listKeyManager.withVerticalOrientation() : this.listKeyManager.withHorizontalOrientation(this._dir?.value || "ltr"), this.selectionModel.selected.length && Promise.resolve().then(() => this._setNextFocusToSelectedOption()), this.listKeyManager.change.subscribe(() => this._focusActiveOption()), this.options.changes.pipe(b(this.destroyed)).subscribe(() => { let e = this.listKeyManager.activeItem; e && !this.options.find(t => t === e) && (this.listKeyManager.setActiveItem(-1), this.changeDetectorRef.markForCheck()); }); }
    _focusActiveOption() { this.useActiveDescendant || this.listKeyManager.activeItem?.focus(), this.changeDetectorRef.markForCheck(); }
    _setSelection(e) { this._invalid && this.selectionModel.clear(!1), this.selectionModel.setSelection(...this._coerceValue(e)), this._hasFocus || this._setNextFocusToSelectedOption(); }
    _setNextFocusToSelectedOption() { let e = this.options?.find(t => t.isSelected()); e && this.listKeyManager.updateActiveItem(e); }
    _updateInternalValue() { let e = new Map; this.selectionModel.sort((i, s) => { let a = this._getIndexForValue(e, i), o = this._getIndexForValue(e, s); return a - o; }); let t = this.selectionModel.selected; this._invalid = !this.multiple && t.length > 1 || !!this._getInvalidOptionValues(t).length, this.changeDetectorRef.markForCheck(); }
    _getIndexForValue(e, t) { let i = this.compareWith || Object.is; if (!e.has(t)) {
        let s = -1;
        for (let a = 0; a < this.options.length; a++)
            if (i(t, this.options.get(a).value)) {
                s = a;
                break;
            }
        e.set(t, s);
    } return e.get(t); }
    _handleOptionClicked(e, t) { t.preventDefault(), this.listKeyManager.setActiveItem(e), t.shiftKey && this.multiple ? this.triggerRange(e, this._getLastTriggeredIndex() ?? this.listKeyManager.activeItemIndex, this.listKeyManager.activeItemIndex, !e.isSelected()) : this.triggerOption(e); }
    _verifyNoOptionValueCollisions() { this.options.changes.pipe(m(this.options), b(this.destroyed)).subscribe(() => { let e = this.compareWith ?? Object.is; for (let t = 0; t < this.options.length; t++) {
        let i = this.options.get(t), s = null;
        for (let a = t + 1; a < this.options.length; a++) {
            let o = this.options.get(a);
            if (e(i.value, o.value)) {
                s = o;
                break;
            }
        }
        if (s) {
            this.compareWith ? console.warn("Found multiple CdkOption representing the same value under the given compareWith function", { option1: i.element, option2: s.element, compareWith: this.compareWith }) : console.warn("Found multiple CdkOption with the same value", { option1: i.element, option2: s.element });
            return;
        }
    } }); }
    _verifyOptionValues() { this.options; }
    _coerceValue(e) { return e == null ? [] : A(e); }
    _getInvalidOptionValues(e) { let t = this.compareWith || Object.is, i = (this.options || []).map(s => s.value); return e.filter(s => !i.some(a => t(s, a))); }
    _getLastTriggeredIndex() { let e = this.options.toArray().indexOf(this._lastTriggered); return e === -1 ? null : e; }
    static \u0275fac = function (t) { return new (t || l); };
    static \u0275dir = n.\u0275\u0275defineDirective({ type: l, selectors: [["", "cdkListbox", ""]], contentQueries: function (t, i, s) { if (t & 1 && n.\u0275\u0275contentQuery(s, G, 5), t & 2) {
            let a;
            n.\u0275\u0275queryRefresh(a = n.\u0275\u0275loadQuery()) && (i.options = a);
        } }, hostAttrs: ["role", "listbox", 1, "cdk-listbox"], hostVars: 6, hostBindings: function (t, i) { t & 1 && n.\u0275\u0275listener("focus", function () { return i._handleFocus(); })("keydown", function (a) { return i._handleKeydown(a); })("focusout", function (a) { return i._handleFocusOut(a); })("focusin", function () { return i._handleFocusIn(); }), t & 2 && (n.\u0275\u0275domProperty("id", i.id), n.\u0275\u0275attribute("tabindex", i._getTabIndex())("aria-disabled", i.disabled)("aria-multiselectable", i.multiple)("aria-activedescendant", i._getAriaActiveDescendant())("aria-orientation", i.orientation)); }, inputs: { id: "id", enabledTabIndex: [0, "tabindex", "enabledTabIndex"], value: [0, "cdkListboxValue", "value"], multiple: [2, "cdkListboxMultiple", "multiple", u], disabled: [2, "cdkListboxDisabled", "disabled", u], useActiveDescendant: [2, "cdkListboxUseActiveDescendant", "useActiveDescendant", u], orientation: [0, "cdkListboxOrientation", "orientation"], compareWith: [0, "cdkListboxCompareWith", "compareWith"], navigationWrapDisabled: [2, "cdkListboxNavigationWrapDisabled", "navigationWrapDisabled", u], navigateDisabledOptions: [2, "cdkListboxNavigatesDisabledOptions", "navigateDisabledOptions", u] }, outputs: { valueChange: "cdkListboxValueChange" }, exportAs: ["cdkListbox"], features: [n.\u0275\u0275ProvidersFeature([{ provide: j, useExisting: P(() => l), multi: !0 }])] });
} return l; })();
var pe = (() => { class l {
    static \u0275fac = function (t) { return new (t || l); };
    static \u0275mod = n.\u0275\u0275defineNgModule({ type: l });
    static \u0275inj = n.\u0275\u0275defineInjector({});
} return l; })();
export { Z as CdkListbox, pe as CdkListboxModule, G as CdkOption };
