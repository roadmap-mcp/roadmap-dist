import { a as t, b as s, c as d, d as o, e as l, g as u, p as c, w as f, y as m } from "@nf-internal/chunk-EPGORQP5";
var v = class extends m {
    static { t(this, "RailroadAbnfTokenBuilder"); }
    constructor() { super(["railroad-abnf-beta"]); }
}, b = class extends f {
    static { t(this, "RailroadAbnfValueConverter"); }
    runConverter(r, e, a) { let i = super.runConverter(r, e, a); if (r.name === "TITLE" && typeof i == "string") {
        let n = i.trim();
        if (n.startsWith('"') && n.endsWith('"') || n.startsWith("'") && n.endsWith("'"))
            return n.slice(1, -1);
    } return i; }
    runCustomConverter(r, e, a) { if (r.name === "ABNF_STRING")
        return e.slice(1, -1); }
}, A = { parser: { TokenBuilder: t(() => new v, "TokenBuilder"), ValueConverter: t(() => new b, "ValueConverter") } };
function C(r = l) { let e = o(d(r), u), a = o(s({ shared: e }), c, A); return e.ServiceRegistry.register(a), { shared: e, RailroadAbnf: a }; }
t(C, "createRailroadAbnfServices");
export { A as a, C as b };
