import { h as o } from "@nf-internal/chunk-RZWXGGKD";
import { a as m } from "@nf-internal/chunk-YUSHYV7C";
var g = m((t, e) => { let n; return e === "sandbox" && (n = o("#i" + t)), (e === "sandbox" ? o(n.nodes()[0].contentDocument.body) : o("body")).select(`[id="${t}"]`); }, "getDiagramElement");
export { g as a };
