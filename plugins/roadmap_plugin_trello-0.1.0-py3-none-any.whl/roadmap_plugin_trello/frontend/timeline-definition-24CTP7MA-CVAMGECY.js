import { a as bt } from "@nf-internal/chunk-YQ6X4GJP";
import { n as vt } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { P as nt, S as xt, T as kt, _ as it, c as ft, d as yt, e as mt, u as rt } from "@nf-internal/chunk-LEJRRF65";
import { F as st, b as _, h as K } from "@nf-internal/chunk-RZWXGGKD";
import { a as o, b as gt } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var at = (function () {
    var e = o(function (k, i, d, l) { for (d = d || {}, l = k.length; l--; d[k[l]] = i)
        ; return d; }, "o"), t = [6, 11, 13, 14, 15, 17, 19, 20, 23, 24], r = [1, 12], s = [1, 13], n = [1, 14], h = [1, 15], c = [1, 16], a = [1, 19], f = [1, 20], g = { trace: o(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, timeline_header: 4, document: 5, EOF: 6, timeline: 7, timeline_lr: 8, timeline_td: 9, line: 10, SPACE: 11, statement: 12, NEWLINE: 13, title: 14, acc_title: 15, acc_title_value: 16, acc_descr: 17, acc_descr_value: 18, acc_descr_multiline_value: 19, section: 20, period_statement: 21, event_statement: 22, period: 23, event: 24, $accept: 0, $end: 1 }, terminals_: { 2: "error", 6: "EOF", 7: "timeline", 8: "timeline_lr", 9: "timeline_td", 11: "SPACE", 13: "NEWLINE", 14: "title", 15: "acc_title", 16: "acc_title_value", 17: "acc_descr", 18: "acc_descr_value", 19: "acc_descr_multiline_value", 20: "section", 23: "period", 24: "event" }, productions_: [0, [3, 3], [4, 1], [4, 1], [4, 1], [5, 0], [5, 2], [10, 2], [10, 1], [10, 1], [10, 1], [12, 1], [12, 2], [12, 2], [12, 1], [12, 1], [12, 1], [12, 1], [21, 1], [22, 1]], performAction: o(function (i, d, l, p, m, u, w) { var b = u.length - 1; switch (m) {
            case 1: return u[b - 1];
            case 3:
                p.setDirection("LR");
                break;
            case 4:
                p.setDirection("TD");
                break;
            case 5:
                this.$ = [];
                break;
            case 6:
                u[b - 1].push(u[b]), this.$ = u[b - 1];
                break;
            case 7:
            case 8:
                this.$ = u[b];
                break;
            case 9:
            case 10:
                this.$ = [];
                break;
            case 11:
                p.getCommonDb().setDiagramTitle(u[b].substr(6)), this.$ = u[b].substr(6);
                break;
            case 12:
                this.$ = u[b].trim(), p.getCommonDb().setAccTitle(this.$);
                break;
            case 13:
            case 14:
                this.$ = u[b].trim(), p.getCommonDb().setAccDescription(this.$);
                break;
            case 15:
                p.addSection(u[b].substr(8)), this.$ = u[b].substr(8);
                break;
            case 18:
                p.addTask(u[b], 0, ""), this.$ = u[b];
                break;
            case 19:
                p.addEvent(u[b].substr(2)), this.$ = u[b];
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 7: [1, 3], 8: [1, 4], 9: [1, 5] }, { 1: [3] }, e(t, [2, 5], { 5: 6 }), e(t, [2, 2]), e(t, [2, 3]), e(t, [2, 4]), { 6: [1, 7], 10: 8, 11: [1, 9], 12: 10, 13: [1, 11], 14: r, 15: s, 17: n, 19: h, 20: c, 21: 17, 22: 18, 23: a, 24: f }, e(t, [2, 10], { 1: [2, 1] }), e(t, [2, 6]), { 12: 21, 14: r, 15: s, 17: n, 19: h, 20: c, 21: 17, 22: 18, 23: a, 24: f }, e(t, [2, 8]), e(t, [2, 9]), e(t, [2, 11]), { 16: [1, 22] }, { 18: [1, 23] }, e(t, [2, 14]), e(t, [2, 15]), e(t, [2, 16]), e(t, [2, 17]), e(t, [2, 18]), e(t, [2, 19]), e(t, [2, 7]), e(t, [2, 12]), e(t, [2, 13])], defaultActions: {}, parseError: o(function (i, d) { if (d.recoverable)
            this.trace(i);
        else {
            var l = new Error(i);
            throw l.hash = d, l;
        } }, "parseError"), parse: o(function (i) {
            var d = this, l = [0], p = [], m = [null], u = [], w = this.table, b = "", I = 0, P = 0, B = 0, G = 2, L = 1, R = u.slice.call(arguments, 1), E = Object.create(this.lexer), A = { yy: {} };
            for (var V in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, V) && (A.yy[V] = this.yy[V]);
            E.setInput(i, A.yy), A.yy.lexer = E, A.yy.parser = this, typeof E.yylloc > "u" && (E.yylloc = {});
            var D = E.yylloc;
            u.push(D);
            var $ = E.options && E.options.ranges;
            typeof A.yy.parseError == "function" ? this.parseError = A.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function v(W) { l.length = l.length - 2 * W, m.length = m.length - W, u.length = u.length - W; }
            o(v, "popStack");
            function T() { var W; return W = p.pop() || E.lex() || L, typeof W != "number" && (W instanceof Array && (p = W, W = p.pop()), W = d.symbols_[W] || W), W; }
            o(T, "lex");
            for (var S, H, M, N, tt, Z, O = {}, j, F, pt, q;;) {
                if (M = l[l.length - 1], this.defaultActions[M] ? N = this.defaultActions[M] : ((S === null || typeof S > "u") && (S = T()), N = w[M] && w[M][S]), typeof N > "u" || !N.length || !N[0]) {
                    var et = "";
                    q = [];
                    for (j in w[M])
                        this.terminals_[j] && j > G && q.push("'" + this.terminals_[j] + "'");
                    E.showPosition ? et = "Parse error on line " + (I + 1) + `:
` + E.showPosition() + `
Expecting ` + q.join(", ") + ", got '" + (this.terminals_[S] || S) + "'" : et = "Parse error on line " + (I + 1) + ": Unexpected " + (S == L ? "end of input" : "'" + (this.terminals_[S] || S) + "'"), this.parseError(et, { text: E.match, token: this.terminals_[S] || S, line: E.yylineno, loc: D, expected: q });
                }
                if (N[0] instanceof Array && N.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + M + ", token: " + S);
                switch (N[0]) {
                    case 1:
                        l.push(S), m.push(E.yytext), u.push(E.yylloc), l.push(N[1]), S = null, H ? (S = H, H = null) : (P = E.yyleng, b = E.yytext, I = E.yylineno, D = E.yylloc, B > 0 && B--);
                        break;
                    case 2:
                        if (F = this.productions_[N[1]][1], O.$ = m[m.length - F], O._$ = { first_line: u[u.length - (F || 1)].first_line, last_line: u[u.length - 1].last_line, first_column: u[u.length - (F || 1)].first_column, last_column: u[u.length - 1].last_column }, $ && (O._$.range = [u[u.length - (F || 1)].range[0], u[u.length - 1].range[1]]), Z = this.performAction.apply(O, [b, P, I, A.yy, N[1], m, u].concat(R)), typeof Z < "u")
                            return Z;
                        F && (l = l.slice(0, -1 * F * 2), m = m.slice(0, -1 * F), u = u.slice(0, -1 * F)), l.push(this.productions_[N[1]][0]), m.push(O.$), u.push(O._$), pt = w[l[l.length - 2]][l[l.length - 1]], l.push(pt);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, x = (function () {
        var k = { EOF: 1, parseError: o(function (d, l) { if (this.yy.parser)
                this.yy.parser.parseError(d, l);
            else
                throw new Error(d); }, "parseError"), setInput: o(function (i, d) { return this.yy = d || this.yy || {}, this._input = i, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: o(function () { var i = this._input[0]; this.yytext += i, this.yyleng++, this.offset++, this.match += i, this.matched += i; var d = i.match(/(?:\r\n?|\n).*/g); return d ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), i; }, "input"), unput: o(function (i) { var d = i.length, l = i.split(/(?:\r\n?|\n)/g); this._input = i + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - d), this.offset -= d; var p = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), l.length - 1 && (this.yylineno -= l.length - 1); var m = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: l ? (l.length === p.length ? this.yylloc.first_column : 0) + p[p.length - l.length].length - l[0].length : this.yylloc.first_column - d }, this.options.ranges && (this.yylloc.range = [m[0], m[0] + this.yyleng - d]), this.yyleng = this.yytext.length, this; }, "unput"), more: o(function () { return this._more = !0, this; }, "more"), reject: o(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: o(function (i) { this.unput(this.match.slice(i)); }, "less"), pastInput: o(function () { var i = this.matched.substr(0, this.matched.length - this.match.length); return (i.length > 20 ? "..." : "") + i.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: o(function () { var i = this.match; return i.length < 20 && (i += this._input.substr(0, 20 - i.length)), (i.substr(0, 20) + (i.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: o(function () {
                var i = this.pastInput(), d = new Array(i.length + 1).join("-");
                return i + this.upcomingInput() + `
` + d + "^";
            }, "showPosition"), test_match: o(function (i, d) { var l, p, m; if (this.options.backtrack_lexer && (m = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (m.yylloc.range = this.yylloc.range.slice(0))), p = i[0].match(/(?:\r\n?|\n).*/g), p && (this.yylineno += p.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: p ? p[p.length - 1].length - p[p.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + i[0].length }, this.yytext += i[0], this.match += i[0], this.matches = i, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(i[0].length), this.matched += i[0], l = this.performAction.call(this, this.yy, this, d, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), l)
                return l; if (this._backtrack) {
                for (var u in m)
                    this[u] = m[u];
                return !1;
            } return !1; }, "test_match"), next: o(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var i, d, l, p;
                this._more || (this.yytext = "", this.match = "");
                for (var m = this._currentRules(), u = 0; u < m.length; u++)
                    if (l = this._input.match(this.rules[m[u]]), l && (!d || l[0].length > d[0].length)) {
                        if (d = l, p = u, this.options.backtrack_lexer) {
                            if (i = this.test_match(l, m[u]), i !== !1)
                                return i;
                            if (this._backtrack) {
                                d = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return d ? (i = this.test_match(d, m[p]), i !== !1 ? i : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: o(function () { var d = this.next(); return d || this.lex(); }, "lex"), begin: o(function (d) { this.conditionStack.push(d); }, "begin"), popState: o(function () { var d = this.conditionStack.length - 1; return d > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: o(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: o(function (d) { return d = this.conditionStack.length - 1 - Math.abs(d || 0), d >= 0 ? this.conditionStack[d] : "INITIAL"; }, "topState"), pushState: o(function (d) { this.begin(d); }, "pushState"), stateStackSize: o(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: o(function (d, l, p, m) { var u = m; switch (p) {
                case 0: break;
                case 1: break;
                case 2: return 13;
                case 3: break;
                case 4: break;
                case 5: return 8;
                case 6: return 9;
                case 7: return 7;
                case 8: return 14;
                case 9:
                    return this.begin("acc_title"), 15;
                    break;
                case 10:
                    return this.popState(), "acc_title_value";
                    break;
                case 11:
                    return this.begin("acc_descr"), 17;
                    break;
                case 12:
                    return this.popState(), "acc_descr_value";
                    break;
                case 13:
                    this.begin("acc_descr_multiline");
                    break;
                case 14:
                    this.popState();
                    break;
                case 15: return "acc_descr_multiline_value";
                case 16: return 20;
                case 17: return 24;
                case 18: return 23;
                case 19: return 6;
                case 20: return "INVALID";
            } }, "anonymous"), rules: [/^(?:%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:#[^\n]*)/i, /^(?:timeline[ \t]+LR\b)/i, /^(?:timeline[ \t]+TD\b)/i, /^(?:timeline\b)/i, /^(?:title\s[^\n]+)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:section\s[^:\n]+)/i, /^(?::\s(?:[^:\n]|:(?!\s))+)/i, /^(?:[^#:\n]+)/i, /^(?:$)/i, /^(?:.)/i], conditions: { acc_descr_multiline: { rules: [14, 15], inclusive: !1 }, acc_descr: { rules: [12], inclusive: !1 }, acc_title: { rules: [10], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 11, 13, 16, 17, 18, 19, 20], inclusive: !0 } } };
        return k;
    })();
    g.lexer = x;
    function y() { this.yy = {}; }
    return o(y, "Parser"), y.prototype = g, g.Parser = y, new y;
})();
at.parser = at;
var Kt = at, $t = {};
gt($t, { addEvent: () => Pt, addSection: () => At, addTask: () => Wt, addTaskOrg: () => Bt, clear: () => Ht, default: () => Ut, getCommonDb: () => It, getDirection: () => Mt, getSections: () => Ct, getTasks: () => Rt, setDirection: () => Lt });
var U = "", Nt = 0, ct = "LR", lt = [], J = [], X = [], It = o(() => xt, "getCommonDb"), Ht = o(function () { lt.length = 0, J.length = 0, U = "", X.length = 0, ct = "LR", kt(); }, "clear"), Lt = o(function (e) { ct = e; }, "setDirection"), Mt = o(function () { return ct; }, "getDirection"), At = o(function (e) { U = e, lt.push(e); }, "addSection"), Ct = o(function () { return lt; }, "getSections"), Rt = o(function () { let e = _t(), t = 100, r = 0; for (; !e && r < t;)
    e = _t(), r++; return J.push(...X), J; }, "getTasks"), Wt = o(function (e, t, r) { let s = { id: Nt++, section: U, type: U, task: e, score: t || 0, events: r ? [r] : [] }; X.push(s); }, "addTask"), Pt = o(function (e) { X.find(r => r.id === Nt - 1).events.push(e); }, "addEvent"), Bt = o(function (e) { let t = { section: U, type: U, description: e, task: e, classes: [] }; J.push(t); }, "addTaskOrg"), _t = o(function () { let e = o(function (r) { return X[r].processed; }, "compileTask"), t = !0; for (let [r, s] of X.entries())
    e(r), t = t && s.processed; return t; }, "compileTasks"), Ut = { clear: Ht, getCommonDb: It, getDirection: Mt, setDirection: Lt, addSection: At, getSections: Ct, getTasks: Rt, addTask: Wt, addTaskOrg: Bt, addEvent: Pt }, Vt = 0, Q = o(function (e, t) { let r = e.append("rect"); return r.attr("x", t.x), r.attr("y", t.y), r.attr("fill", t.fill), r.attr("stroke", t.stroke), r.attr("width", t.width), r.attr("height", t.height), r.attr("rx", t.rx), r.attr("ry", t.ry), t.class !== void 0 && r.attr("class", t.class), r; }, "drawRect"), Xt = o(function (e, t) { let s = e.append("circle").attr("cx", t.cx).attr("cy", t.cy).attr("class", "face").attr("r", 15).attr("stroke-width", 2).attr("overflow", "visible"), n = e.append("g"); n.append("circle").attr("cx", t.cx - 15 / 3).attr("cy", t.cy - 15 / 3).attr("r", 1.5).attr("stroke-width", 2).attr("fill", "#666").attr("stroke", "#666"), n.append("circle").attr("cx", t.cx + 15 / 3).attr("cy", t.cy - 15 / 3).attr("r", 1.5).attr("stroke-width", 2).attr("fill", "#666").attr("stroke", "#666"); function h(f) { let g = st().startAngle(Math.PI / 2).endAngle(3 * (Math.PI / 2)).innerRadius(7.5).outerRadius(6.8181818181818175); f.append("path").attr("class", "mouth").attr("d", g).attr("transform", "translate(" + t.cx + "," + (t.cy + 2) + ")"); } o(h, "smile"); function c(f) { let g = st().startAngle(3 * Math.PI / 2).endAngle(5 * (Math.PI / 2)).innerRadius(7.5).outerRadius(6.8181818181818175); f.append("path").attr("class", "mouth").attr("d", g).attr("transform", "translate(" + t.cx + "," + (t.cy + 7) + ")"); } o(c, "sad"); function a(f) { f.append("line").attr("class", "mouth").attr("stroke", 2).attr("x1", t.cx - 5).attr("y1", t.cy + 7).attr("x2", t.cx + 5).attr("y2", t.cy + 7).attr("class", "mouth").attr("stroke-width", "1px").attr("stroke", "#666"); } return o(a, "ambivalent"), t.score > 3 ? h(n) : t.score < 3 ? c(n) : a(n), s; }, "drawFace"), Zt = o(function (e, t) { let r = e.append("circle"); return r.attr("cx", t.cx), r.attr("cy", t.cy), r.attr("class", "actor-" + t.pos), r.attr("fill", t.fill), r.attr("stroke", t.stroke), r.attr("r", t.r), r.class !== void 0 && r.attr("class", r.class), t.title !== void 0 && r.append("title").text(t.title), r; }, "drawCircle"), Ft = o(function (e, t) { let r = t.text.replace(/<br\s*\/?>/gi, " "), s = e.append("text"); s.attr("x", t.x), s.attr("y", t.y), s.attr("class", "legend"), s.style("text-anchor", t.anchor), t.class !== void 0 && s.attr("class", t.class); let n = s.append("tspan"); return n.attr("x", t.x + t.textMargin * 2), n.text(r), s; }, "drawText"), jt = o(function (e, t) { function r(n, h, c, a, f) { return n + "," + h + " " + (n + c) + "," + h + " " + (n + c) + "," + (h + a - f) + " " + (n + c - f * 1.2) + "," + (h + a) + " " + n + "," + (h + a); } o(r, "genPoints"); let s = e.append("polygon"); s.attr("points", r(t.x, t.y, 50, 20, 7)), s.attr("class", "labelBox"), t.y = t.y + t.labelMargin, t.x = t.x + .5 * t.labelMargin, Ft(e, t); }, "drawLabel"), qt = o(function (e, t, r) { let s = e.append("g"), n = ht(); n.x = t.x, n.y = t.y, n.fill = t.fill, n.width = r.width, n.height = r.height, n.class = "journey-section section-type-" + t.num, n.rx = 3, n.ry = 3, Q(s, n), zt(r)(t.text, s, n.x, n.y, n.width, n.height, { class: "journey-section section-type-" + t.num }, r, t.colour); }, "drawSection"), ot = -1, Jt = o(function (e, t, r, s) { let n = t.x + r.width / 2, h = e.append("g"); ot++, h.append("line").attr("id", s + "-task" + ot).attr("x1", n).attr("y1", t.y).attr("x2", n).attr("y2", 450).attr("class", "task-line").attr("stroke-width", "1px").attr("stroke-dasharray", "4 2").attr("stroke", "#666"), Xt(h, { cx: n, cy: 300 + (5 - t.score) * 30, score: t.score }); let a = ht(); a.x = t.x, a.y = t.y, a.fill = t.fill, a.width = r.width, a.height = r.height, a.class = "task task-type-" + t.num, a.rx = 3, a.ry = 3, Q(h, a), zt(r)(t.task, h, a.x, a.y, a.width, a.height, { class: "task" }, r, t.colour); }, "drawTask"), Qt = o(function (e, t) { Q(e, { x: t.startx, y: t.starty, width: t.stopx - t.startx, height: t.stopy - t.starty, fill: t.fill, class: "rect" }).lower(); }, "drawBackgroundRect"), Yt = o(function () { return { x: 0, y: 0, fill: void 0, "text-anchor": "start", width: 100, height: 100, textMargin: 0, rx: 0, ry: 0 }; }, "getTextObj"), ht = o(function () { return { x: 0, y: 0, width: 100, anchor: "start", height: 100, rx: 0, ry: 0 }; }, "getNoteRect"), zt = (function () { function e(n, h, c, a, f, g, x, y) { let k = h.append("text").attr("x", c + f / 2).attr("y", a + g / 2 + 5).style("font-color", y).style("text-anchor", "middle").text(n); s(k, x); } o(e, "byText"); function t(n, h, c, a, f, g, x, y, k) { let { taskFontSize: i, taskFontFamily: d } = y, l = n.split(/<br\s*\/?>/gi); for (let p = 0; p < l.length; p++) {
    let m = p * i - i * (l.length - 1) / 2, u = h.append("text").attr("x", c + f / 2).attr("y", a).attr("fill", k).style("text-anchor", "middle").style("font-size", i).style("font-family", d);
    u.append("tspan").attr("x", c + f / 2).attr("dy", m).text(l[p]), u.attr("y", a + g / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), s(u, x);
} } o(t, "byTspan"); function r(n, h, c, a, f, g, x, y) { let k = h.append("switch"), d = k.append("foreignObject").attr("x", c).attr("y", a).attr("width", f).attr("height", g).attr("position", "fixed").append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%"); d.append("div").attr("class", "label").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(n), t(n, k, c, a, f, g, x, y), s(d, x); } o(r, "byFo"); function s(n, h) { for (let c in h)
    c in h && n.attr(c, h[c]); } return o(s, "_setTextAttrs"), function (n) { return n.textPlacement === "fo" ? r : n.textPlacement === "old" ? e : t; }; })(), te = o(function (e, t) { Vt = 0, ot = -1, e.append("defs").append("marker").attr("id", t + "-arrowhead").attr("refX", 5).attr("refY", 2).attr("markerWidth", 6).attr("markerHeight", 4).attr("orient", "auto").append("path").attr("d", "M 0,0 V 4 L6,2 Z"); }, "initGraphics");
function dt(e, t) { e.each(function () { var r = K(this), s = r.text().split(/(\s+|<br>)/).reverse(), n, h = [], c = 1.1, a = r.attr("y"), f = parseFloat(r.attr("dy")), g = r.text(null).append("tspan").attr("x", 0).attr("y", a).attr("dy", f + "em"); for (let x = 0; x < s.length; x++)
    n = s[s.length - 1 - x], h.push(n), g.text(h.join(" ").trim()), (g.node().getComputedTextLength() > t || n === "<br>") && (h.pop(), g.text(h.join(" ").trim()), n === "<br>" ? h = [""] : h = [n], g = r.append("tspan").attr("x", 0).attr("y", a).attr("dy", c + "em").text(n)); }); }
o(dt, "wrap");
var ee = o(function (e, t, r, s, n, h = !1) { let { theme: c, look: a } = s, f = c?.includes("redux"), g = s?.themeVariables?.THEME_COLOR_LIMIT ?? 12, x = r % g - 1, y = e.append("g"); t.section = x, y.attr("class", (t.class ? t.class + " " : "") + "timeline-node " + ("section-" + x)); let k = y.append("g"), i = y.append("g"), l = i.append("text").text(t.descr).attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle").call(dt, t.width).node().getBBox(), p = s.fontSize?.replace ? s.fontSize.replace("px", "") : s.fontSize; if (t.height = l.height + p * 1.1 * .5 + t.padding, t.height = Math.max(t.height, t.maxHeight), t.width = t.width + 2 * t.padding, i.attr("transform", "translate(" + t.width / 2 + ", " + t.padding / 2 + ")"), f && i.attr("transform", `translate(${t.width / 2}, ${h ? t.padding / 2 + 3 : t.padding})`), ne(k, t, x, n, s), a === "neo" && (y.attr("data-look", "neo"), f)) {
    let m = c.includes("dark"), u = e.node()?.ownerSVGElement ?? e.node(), w = K(u), b = w.attr("id") ?? "", I = b ? `${b}-drop-shadow` : "drop-shadow";
    if (w.select(`#${I}`).empty()) {
        let P = w.select("defs");
        (P.empty() ? w.append("defs") : P).append("filter").attr("id", I).attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", m ? "0.2" : "0.06").attr("flood-color", m ? "#FFFFFF" : "#000000");
    }
} return t; }, "drawNode"), re = o(function (e, t, r) { let s = e.append("g"), h = s.append("text").text(t.descr).attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle").call(dt, t.width).node().getBBox(), c = r.fontSize?.replace ? r.fontSize.replace("px", "") : r.fontSize; return s.remove(), h.height + c * 1.1 * .5 + t.padding; }, "getVirtualNodeHeight"), ne = o(function (e, t, r, s, n) { let { theme: h } = n, c = h?.includes("redux") ? 0 : 5, a = 5, f = c > 0 ? `M0 ${t.height - a} v${-t.height + 2 * a} q0,-${c},${c},-${c} h${t.width - 2 * a} q${c},0,${c},${c} v${t.height - a} H0 Z` : `M0 ${t.height - a} v${-(t.height - a)} h${t.width} v${t.height} H0 Z`; e.append("path").attr("id", s + "-node-" + Vt++).attr("class", "node-bkg node-" + t.type).attr("d", f), h?.includes("redux") || e.append("line").attr("class", "node-line-" + r).attr("x1", 0).attr("y1", t.height).attr("x2", t.width).attr("y2", t.height); }, "defaultBkg"), C = { drawRect: Q, drawCircle: Zt, drawSection: qt, drawText: Ft, drawLabel: jt, drawTask: Jt, drawBackgroundRect: Qt, getTextObj: Yt, getNoteRect: ht, initGraphics: te, drawNode: ee, getVirtualNodeHeight: re }, ie = o(function (e, t, r, s) { let n = it(), { look: h, theme: c, themeVariables: a } = n, { useGradient: f, gradientStart: g, gradientStop: x } = a, y = n.timeline?.leftMargin ?? 50; _.debug("timeline", s.db); let k = n.securityLevel, i; k === "sandbox" && (i = K("#i" + t)); let l = (k === "sandbox" ? K(i.nodes()[0].contentDocument.body) : K("body")).select("#" + t); l.append("g"); let p = s.db.getTasks(), m = s.db.getCommonDb().getDiagramTitle(); _.debug("task", p), C.initGraphics(l, t); let u = s.db.getSections(); _.debug("sections", u); let w = 0, b = 0, I = 0, P = 0, B = 50 + y, G = 50; P = 50; let L = 0, R = !0; u.forEach(function ($) { let v = { number: L, descr: $, section: L, width: 150, padding: 20, maxHeight: w }, T = C.getVirtualNodeHeight(l, v, n); _.debug("sectionHeight before draw", T), w = Math.max(w, T + 20); }); let E = 0, A = 0; _.debug("tasks.length", p.length); for (let [$, v] of p.entries()) {
    let T = { number: $, descr: v, section: v.section, width: 150, padding: 20, maxHeight: b }, S = C.getVirtualNodeHeight(l, T, n);
    _.debug("taskHeight before draw", S), b = Math.max(b, S + 20), E = Math.max(E, v.events.length);
    let H = 0;
    for (let M of v.events) {
        let N = { descr: M, section: v.section, number: v.section, width: 150, padding: 20, maxHeight: 50 };
        H += C.getVirtualNodeHeight(l, N, n);
    }
    v.events.length > 0 && (H += (v.events.length - 1) * 10), A = Math.max(A, H);
} _.debug("maxSectionHeight before draw", w), _.debug("maxTaskHeight before draw", b), u && u.length > 0 ? u.forEach($ => { let v = p.filter(M => M.section === $), T = { number: L, descr: $, section: L, width: 200 * Math.max(v.length, 1) - 50, padding: 20, maxHeight: w }; _.debug("sectionNode", T); let S = l.append("g"), H = C.drawNode(S, T, L, n, t); _.debug("sectionNode output", H), S.attr("transform", `translate(${B}, ${P})`), G += w + 50, v.length > 0 && wt(l, v, L, B, G, b, n, E, A, w, !1, t), B += 200 * Math.max(v.length, 1), G = P, L++; }) : (R = !1, wt(l, p, L, B, G, b, n, E, A, w, !0, t)); let V = l.node().getBBox(); if (_.debug("bounds", V), m && l.append("text").text(m).attr("x", h === "neo" ? V.x * 2 + y : V.width / 2 - y).attr("font-size", "4ex").attr("font-weight", "bold").attr("y", 20), I = R ? w + b + 150 : b + 100, l.append("g").attr("class", "lineWrapper").append("line").attr("x1", y).attr("y1", I).attr("x2", V.width + 3 * y).attr("y2", I).attr("stroke-width", 4).attr("stroke", "black").attr("marker-end", `url(#${t}-arrowhead)`), h === "neo" && f && c !== "neutral") {
    let $ = l.select("defs"), T = ($.empty() ? l.append("defs") : $).append("linearGradient").attr("id", l.attr("id") + "-gradient").attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
    T.append("stop").attr("offset", "0%").attr("stop-color", g).attr("stop-opacity", 1), T.append("stop").attr("offset", "100%").attr("stop-color", x).attr("stop-opacity", 1);
} nt(void 0, l, n.timeline?.padding ?? 50, n.timeline?.useMaxWidth ?? !1); }, "draw"), wt = o(function (e, t, r, s, n, h, c, a, f, g, x, y) { for (let k of t) {
    let i = { descr: k.task, section: r, number: r, width: 150, padding: 20, maxHeight: h };
    _.debug("taskNode", i);
    let d = e.append("g").attr("class", "taskWrapper"), p = C.drawNode(d, i, r, c, y).height;
    if (_.debug("taskHeight after draw", p), d.attr("transform", `translate(${s}, ${n})`), h = Math.max(h, p), k.events) {
        let m = e.append("g").attr("class", "lineWrapper"), u = h;
        n += 100, u = u + se(e, k.events, r, s, n, c, y), n -= 100, m.append("line").attr("x1", s + 190 / 2).attr("y1", n + h).attr("x2", s + 190 / 2).attr("y2", n + h + 100 + f + 100).attr("stroke-width", 2).attr("stroke", "black").attr("marker-end", `url(#${y}-arrowhead)`).attr("stroke-dasharray", "5,5");
    }
    s = s + 200, x && !c.timeline?.disableMulticolor && r++;
} n = n - 10; }, "drawTasks"), se = o(function (e, t, r, s, n, h, c) { let a = 0, f = n; n = n + 100; for (let g of t) {
    let x = { descr: g, section: r, number: r, width: 150, padding: 20, maxHeight: 50 };
    _.debug("eventNode", x);
    let y = e.append("g").attr("class", "eventWrapper"), i = C.drawNode(y, x, r, h, c, !0).height;
    a = a + i, y.attr("transform", `translate(${s}, ${n})`), n = n + 10 + i;
} return n = f, a; }, "drawEvents"), ae = { setConf: o(() => { }, "setConf"), draw: ie }, Y = 200, z = 5, oe = Y + z * 2, ut = Y + 100, ce = ut + z * 2, Ot = 10, le = 0, St = 20, Gt = 20, Et = 30, Dt = 50, he = o(function (e, t, r, s) { let n = it(), h = n.timeline?.leftMargin ?? 50; _.debug("timeline", s.db); let c = bt(t); c.append("g"); let a = s.db.getTasks(), f = s.db.getCommonDb().getDiagramTitle(); _.debug("task", a), C.initGraphics(c); let g = s.db.getSections(); _.debug("sections", g); let x = 0, y = 0, k = 50 + h, i = 50, d = i, l = k, p = oe + Gt, m = ce + Dt, u = l + p, w = 0, b = g && g.length > 0, I = b ? u : k + p, P = Math.max(50, p + m - z * 2); g.forEach(function ($) { let v = { number: w, descr: $, section: w, width: P, padding: z, maxHeight: x }, T = C.getVirtualNodeHeight(c, v, n); _.debug("sectionHeight before draw", T), x = Math.max(x, T); }); let B = 0; _.debug("tasks.length", a.length); for (let [$, v] of a.entries()) {
    let T = { number: $, descr: v, section: v.section, width: Y, padding: z, maxHeight: y }, S = C.getVirtualNodeHeight(c, T, n);
    _.debug("taskHeight before draw", S), y = Math.max(y, S);
    let H = 0;
    for (let M of v.events) {
        let N = { descr: M, section: v.section, number: v.section, width: ut, padding: z, maxHeight: 50 };
        H += C.getVirtualNodeHeight(c, N, n);
    }
    v.events.length > 0 && (H += (v.events.length - 1) * Ot), B = Math.max(B, H) + le;
} _.debug("maxSectionHeight before draw", x), _.debug("maxTaskHeight before draw", y); let L = Math.max(y, B) + Et; b ? g.forEach($ => { let v = a.filter(O => O.section === $), T = { number: w, descr: $, section: w, width: P, padding: z, maxHeight: x }; _.debug("sectionNode", T); let S = c.append("g"), H = C.drawNode(S, T, w, n); _.debug("sectionNode output", H); let M = I - p; S.attr("transform", `translate(${M}, ${i})`); let N = i + H.height + St; v.length > 0 && Tt(c, v, w, I, N, y, n, L, !1); let tt = v.length, Z = H.height + St + L * Math.max(tt, 1) - (tt > 0 ? Et * 2 : 0); i += Z, w++; }) : Tt(c, a, w, I, i, y, n, L, !0); let R = c.node()?.getBBox(); if (!R)
    throw new Error("bbox not found"); if (_.debug("bounds", R), f) {
    if (c.append("text").text(f).attr("x", R.width / 2 - h).attr("font-size", "4ex").attr("font-weight", "bold").attr("y", 20), R = c.node()?.getBBox(), !R)
        throw new Error("bbox not found");
    _.debug("bounds after title", R);
} let [E] = vt(n.fontSize), A = (E ?? 16) * 2, V = (E ?? 16) * .5 + 20, D = c.append("g").attr("class", "lineWrapper"); D.append("line").attr("x1", I).attr("y1", d - A).attr("x2", I).attr("y2", R.y + R.height + V).attr("stroke-width", 4).attr("stroke", "black").attr("marker-end", "url(#arrowhead)"), D.lower(), nt(void 0, c, n.timeline?.padding ?? 50, n.timeline?.useMaxWidth ?? !1); }, "draw"), Tt = o(function (e, t, r, s, n, h, c, a, f) { for (let g of t) {
    let x = { descr: g.task, section: r, number: r, width: Y, padding: z, maxHeight: h };
    _.debug("taskNode", x);
    let y = e.append("g").attr("class", "taskWrapper"), k = C.drawNode(y, x, r, c), i = k.height;
    _.debug("taskHeight after draw", i);
    let d = s - Gt - k.width;
    if (y.attr("transform", `translate(${d}, ${n})`), h = Math.max(h, i), g.events && g.events.length > 0) {
        let l = n, p = s + Dt;
        de(e, g.events, r, s, p, l, c);
    }
    n = n + a, f && !c.timeline?.disableMulticolor && r++;
} }, "drawTasks"), de = o(function (e, t, r, s, n, h, c) { let a = h; for (let f of t) {
    let g = { descr: f, section: r, number: r, width: ut, padding: z, maxHeight: 0 };
    _.debug("eventNode", g);
    let x = e.append("g").attr("class", "eventWrapper"), k = C.drawNode(x, g, r, c).height;
    x.attr("transform", `translate(${n}, ${a})`);
    let i = e.append("g").attr("class", "lineWrapper"), d = a + k / 2;
    i.append("line").attr("x1", s).attr("y1", d).attr("x2", n).attr("y2", d).attr("stroke-width", 2).attr("stroke", "black").attr("marker-end", "url(#arrowhead)").attr("stroke-dasharray", "5,5"), a = a + k + Ot;
} return a - h; }, "drawEvents"), ue = { setConf: o(() => { }, "setConf"), draw: he }, pe = o(e => {
    let { theme: t } = rt(), r = t?.includes("dark"), s = t?.includes("color"), n = e.svgId?.replace(/^#/, "") ?? "", h = n ? `url(#${n}-drop-shadow)` : e.dropShadow ?? "none", c = "";
    for (let a = 0; a < e.THEME_COLOR_LIMIT; a++) {
        let f = `${17 - 3 * a}`, g = s ? e.borderColorArray[a] : e.mainBkg, x = s ? e.borderColorArray[a] : e.nodeBorder;
        c += `
    .section-${a - 1} rect,
    .section-${a - 1} path,
    .section-${a - 1} circle {
      fill: ${r && s ? e.mainBkg : g};
      stroke: ${x};
      stroke-width: ${e.strokeWidth};
      filter: ${h};
    }

    .section-${a - 1} text {
      fill: ${e.nodeBorder};
      font-weight: ${e.fontWeight}
    }

    .node-icon-${a - 1} {
      font-size: 40px;
      color: ${e["cScaleLabel" + a]};
    }

    .section-edge-${a - 1} {
      stroke: ${e["cScale" + a]};
    }

    .edge-depth-${a - 1} {
      stroke-width: ${f};
    }

    .section-${a - 1} line {
      stroke: ${e["cScaleInv" + a]};
      stroke-width: 3;
    }

    .lineWrapper line {
      stroke: ${e.nodeBorder};
      stroke-width:${e.strokeWidth}
    }

    .disabled,
    .disabled circle,
    .disabled text {
      fill: ${e.tertiaryColor ?? "lightgray"};
    }

    .disabled text {
      fill: ${e.clusterBorder ?? "#efefef"};
    }
    `;
    }
    return c;
}, "genReduxSections"), ge = o(e => {
    let t = "";
    for (let r = 0; r < e.THEME_COLOR_LIMIT; r++)
        e["lineColor" + r] = e["lineColor" + r] || e["cScaleInv" + r], ft(e["lineColor" + r]) ? e["lineColor" + r] = yt(e["lineColor" + r], 20) : e["lineColor" + r] = mt(e["lineColor" + r], 20);
    for (let r = 0; r < e.THEME_COLOR_LIMIT; r++) {
        let s = "" + (17 - 3 * r);
        t += `
    .section-${r - 1} rect, .section-${r - 1} path, .section-${r - 1} circle, .section-${r - 1} path  {
      fill: ${e["cScale" + r]};
    }
    .section-${r - 1} text {
     fill: ${e["cScaleLabel" + r]};
    }
    .node-icon-${r - 1} {
      font-size: 40px;
      color: ${e["cScaleLabel" + r]};
    }
    .section-edge-${r - 1}{
      stroke: ${e["cScale" + r]};
    }
    .edge-depth-${r - 1}{
      stroke-width: ${s};
    }
    .section-${r - 1} line {
      stroke: ${e["cScaleInv" + r]} ;
      stroke-width: 3;
    }

    .lineWrapper line{
      stroke: ${e["cScaleLabel" + r]} ;
    }

    .disabled, .disabled circle, .disabled text {
      fill: ${e.tertiaryColor ?? "lightgray"};
    }
    .disabled text {
      fill: ${e.clusterBorder ?? "#efefef"};
    }
    `;
    }
    return t;
}, "genSections"), fe = o(e => {
    let { theme: t } = rt(), r = t?.includes("redux"), s = t === "neutral", n = e.svgId?.replace(/^#/, "") ?? "", h = "";
    if (e.useGradient && n && e.THEME_COLOR_LIMIT && !s)
        for (let c = 0; c < e.THEME_COLOR_LIMIT; c++)
            h += `
      .section-${c - 1}[data-look="neo"] rect,
      .section-${c - 1}[data-look="neo"] path,
      .section-${c - 1}[data-look="neo"] circle {
        fill: ${e.mainBkg};
        stroke: url(#${n}-gradient);
        stroke-width: 2;
      }
      .section-${c - 1}[data-look="neo"] line {
        stroke: url(#${n}-gradient);
        stroke-width: 2;
      }`;
    return `
  .edge {
    stroke-width: 3;
  }
  ${r ? pe(e) : ge(e)}
  ${h}
  .section-root rect, .section-root path, .section-root circle  {
    fill: ${e.git0};
  }
  .section-root text {
    fill: ${e.gitBranchLabel0};
  }
  .icon-container {
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .edge {
    fill: none;
  }
  .eventWrapper  {
   filter: brightness(120%);
  }
`;
}, "getStyles"), ye = fe, me = { setConf: o(() => { }, "setConf"), draw: o((e, t, r, s) => (s?.db?.getDirection?.() ?? "LR") === "TD" ? ue.draw(e, t, r, s) : ae.draw(e, t, r, s), "draw") }, Te = { db: $t, renderer: me, parser: Kt, styles: ye };
export { Te as diagram };
