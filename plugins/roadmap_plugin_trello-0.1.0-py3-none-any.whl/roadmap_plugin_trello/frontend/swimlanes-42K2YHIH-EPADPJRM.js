import { g as Ro } from "@nf-internal/chunk-BA5WCRNE";
import "@nf-internal/chunk-LUZVEH3G";
import "@nf-internal/chunk-PFHS2QSV";
import { a as Mn } from "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import "@nf-internal/chunk-LEJRRF65";
import { b as Ge } from "@nf-internal/chunk-RZWXGGKD";
import { a as f } from "@nf-internal/chunk-YUSHYV7C";
import { a as xt, b as ae } from "@nf-internal/chunk-OSQMNGTH";
var No = 5, $e = 1e-5, ze = 1e-6;
function qe(t) { let e = []; for (let n = 0; n < t.length - 1; n++)
    e.push({ a: t[n], b: t[n + 1] }); return e; }
f(qe, "buildSegmentList");
function _o(t, e, n, o) { let s = e.x - t.x, r = e.y - t.y, i = o.x - n.x, g = o.y - n.y, l = s * g - r * i; if (l === 0)
    return null; let a = n.x - t.x, u = n.y - t.y, y = (a * g - u * i) / l, L = (a * r - u * s) / l; return y <= ze || y >= 1 - ze || L <= ze || L >= 1 - ze ? null : { point: { x: t.x + y * s, y: t.y + y * r }, tA: y, tB: L }; }
f(_o, "segmentIntersection");
function Ln(t) { return Math.abs(t.b.x - t.a.x) >= Math.abs(t.b.y - t.a.y); }
f(Ln, "isHorizontalSeg");
function Do(t) { let e = []; for (let n = 0; n < t.length; n++) {
    let o = t[n], s = qe(o.points);
    for (let r = n + 1; r < t.length; r++) {
        let i = t[r], g = qe(i.points);
        for (let [l, a] of s.entries())
            for (let [u, y] of g.entries()) {
                let L = _o(a.a, a.b, y.a, y.b);
                if (!L)
                    continue;
                let m = Ln(a), h = Ln(y);
                (m !== h ? m : !1) ? e.push({ jumpEdgeId: o.id, otherEdgeId: i.id, segIndex: l, t: L.tA, point: L.point }) : e.push({ jumpEdgeId: i.id, otherEdgeId: o.id, segIndex: u, t: L.tB, point: L.point });
            }
    }
} return e; }
f(Do, "findEdgeIntersections");
function ie(t) { let e = Math.round(t * 1e3) / 1e3; return Number.isInteger(e) ? `${e}` : `${e}`; }
f(ie, "fmt");
function Re(t) { return `${ie(t.x)},${ie(t.y)}`; }
f(Re, "pointToString");
function Ho(t) { let e = t.b.x - t.a.x, n = t.b.y - t.a.y; return Math.abs(e) >= Math.abs(n) ? e >= 0 ? 1 : 0 : n >= 0 ? 1 : 0; }
f(Ho, "getArcSweepFlag");
var Er = .001;
function Xo(t, e) { if (t.length < 2)
    return t.map(r => xt({}, r)); let n = t.map(r => xt({}, r)), o = e.arrowTypeStart && Mn[e.arrowTypeStart]; if (o) {
    let r = t[0], i = t[1], g = Math.atan2(i.y - r.y, i.x - r.x);
    n[0].x = r.x + o * Math.cos(g), n[0].y = r.y + o * Math.sin(g);
} let s = e.arrowTypeEnd && Mn[e.arrowTypeEnd]; if (s) {
    let r = t.length, i = t[r - 2], g = t[r - 1], l = Math.atan2(g.y - i.y, g.x - i.x);
    n[r - 1].x = g.x - s * Math.cos(l), n[r - 1].y = g.y - s * Math.sin(l);
} return n; }
f(Xo, "applyMarkerOffsets");
function Yo(t, e, n, o, s) { let r = t.point.x, i = t.point.y, g = { x: r - e * t.r, y: i - n * t.r }, l = { x: r + e * t.r, y: i + n * t.r }, a = [`L${Re(g)}`]; return s === "arc" ? a.push(`A${ie(t.r)},${ie(t.r)} 0 0 ${o} ${Re(l)}`) : a.push(`M${Re(l)}`), a; }
f(Yo, "emitJump");
function En(t, e, n, o) { let s = e.x - t.x, r = e.y - t.y, i = n.x - e.x, g = n.y - e.y, l = Math.hypot(s, r), a = Math.hypot(i, g); if (l < $e || a < $e)
    return null; let u = s / l, y = r / l, L = i / a, m = g / a, h = u * L + y * m, c = Math.max(-1, Math.min(1, h)), p = Math.acos(c); if (p < $e || Math.abs(Math.PI - p) < $e)
    return null; let C = Math.min(o / Math.sin(p / 2), l / 2, a / 2); return { startX: e.x - u * C, startY: e.y - y * C, endX: e.x + L * C, endY: e.y + m * C, ctrlX: e.x, ctrlY: e.y, cutLen: C }; }
f(En, "computeRoundedCorner");
function Go(t, e, n) { let o = t.points; if (o.length < 2)
    return ""; let s = Xo(o, t), r = t.curve === "rounded", i = qe(s), g = new Map; for (let a of e) {
    let u = i[a.segIndex];
    if (!u)
        continue;
    let y = Math.hypot(u.b.x - u.a.x, u.b.y - u.a.y), L = g.get(a.segIndex) ?? [];
    L.push({ t: a.t, point: a.point, d: a.t * y, r: n.jumpRadius }), g.set(a.segIndex, L);
} let l = [`M${Re(s[0])}`]; for (let a = 0; a < i.length; a++) {
    let u = i[a], y = Math.hypot(u.b.x - u.a.x, u.b.y - u.a.y), L = y === 0 ? 0 : (u.b.x - u.a.x) / y, m = y === 0 ? 0 : (u.b.y - u.a.y) / y, h = Ho(u), c = 0;
    if (r && a > 0) {
        let v = En(s[a - 1], s[a], s[a + 1] ?? s[a], No);
        v && (c = v.cutLen);
    }
    let p = y, C = null;
    r && a < i.length - 1 && (C = En(s[a], s[a + 1], s[a + 2] ?? s[a + 1], No), C && (p = y - C.cutLen));
    let M = [...g.get(a) ?? []].sort((v, R) => v.t - R.t);
    for (let v of M)
        v.r = Math.min(v.r, v.d - c, p - v.d);
    for (let v = 0; v < M.length - 1; v++) {
        let R = M[v + 1].d - M[v].d;
        if (M[v].r + M[v + 1].r > R) {
            let I = R / 2;
            M[v].r = Math.min(M[v].r, I), M[v + 1].r = Math.min(M[v + 1].r, I);
        }
    }
    for (let v of M)
        v.r < Er || l.push(...Yo(v, L, m, h, n.jumpStyle));
    r && C ? (l.push(`L${ie(C.startX)},${ie(C.startY)}`), l.push(`Q${ie(C.ctrlX)},${ie(C.ctrlY)} ${ie(C.endX)},${ie(C.endY)}`)) : l.push(`L${Re(u.b)}`);
} return l.join(" "); }
f(Go, "rewriteEdgePath");
function $o(t) { return /^[\d\s+,.LMelm-]*$/.test(t); }
f($o, "isStraightPath");
function zo(t) { return t ? t === "linear" || t === "rounded" || t === "step" || t === "stepBefore" || t === "stepAfter" : !0; }
f(zo, "curveSupportsLineHops");
function Vo(t) { if (!t)
    return null; try {
    let e = typeof atob == "function" ? atob(t) : Buffer.from(t, "base64").toString(), n = JSON.parse(e);
    if (!Array.isArray(n))
        return null;
    let o = [];
    for (let s of n)
        s && typeof s.x == "number" && typeof s.y == "number" && o.push({ x: s.x, y: s.y });
    return o.length >= 2 ? o : null;
}
catch {
    return null;
} }
f(Vo, "decodeDataPoints");
function Uo(t, e, n) { if (!n.enabled)
    return; let o = t.node(); if (!o)
    return; let s = new Map; for (let a of e)
    s.set(a.id, a); let r = [], i = new Map; for (let a of e) {
    let u = typeof CSS < "u" && CSS.escape ? CSS.escape(a.id) : a.id, y = o.querySelector(`path[data-id="${u}"]`);
    if (!y)
        continue;
    i.set(a.id, y);
    let m = Vo(y.getAttribute("data-points")) ?? a.points;
    r.push(ae(xt({}, a), { points: m }));
} let g = Do(r); if (g.length === 0)
    return; let l = new Map; for (let a of g) {
    let u = l.get(a.jumpEdgeId) ?? [];
    u.push(a), l.set(a.jumpEdgeId, u);
} for (let a of r) {
    let u = l.get(a.id);
    if (!u || u.length === 0)
        continue;
    let L = s.get(a.id)?.curve;
    if (L !== void 0 && !zo(L))
        continue;
    let m = i.get(a.id);
    if (!m)
        continue;
    if (L === void 0) {
        let v = m.getAttribute("d") ?? "";
        if (!$o(v))
            continue;
    }
    let h = m.getAttribute("style") ?? "", c = /stroke-dasharray\s*:\s*0\s+([\d.]+)\s+[\d.]+\s+([\d.]+)/.exec(h), p = c ? Number.parseFloat(c[1]) : null, C = c ? Number.parseFloat(c[2]) : null, M = Go(a, u, n);
    if (m.setAttribute("d", M), p !== null && C !== null && typeof m.getTotalLength == "function") {
        let v = m.getTotalLength(), R = Math.max(0, v - p - C), I = `0 ${p} ${R} ${C}`, b = h.replace(/stroke-dasharray\s*:[^;]*;?/g, `stroke-dasharray: ${I};`).replace(/;\s*;+/g, ";");
        m.setAttribute("style", b);
    }
} }
f(Uo, "applyLineJumpsToSvg");
function jo(t, { measure: e }) { let n = t.config?.swimlane?.lineHops; if (n === !1)
    return; let o = n === "gap" ? "gap" : "arc", s = t.edges.filter(r => Array.isArray(r.points) && r.points.length >= 2).map(r => ({ id: r.id, points: r.points, curve: r.curve, arrowTypeStart: r.arrowTypeStart, arrowTypeEnd: r.arrowTypeEnd })); Uo(e.groups.edgePaths, s, { enabled: !0, jumpRadius: 6, jumpStyle: o }); }
f(jo, "applySwimlaneLineJumps");
var In = "__swimlane_default__", Tr = 21, Oo = 20;
function Tn(t) { return Math.max(t.padding ?? Oo, Oo); }
f(Tn, "topLaneHorizontalPadding");
function Wo(t) { let { x: e, y: n, width: o, height: s } = t, r = t.swimlaneContentTop; if (typeof e != "number" || typeof n != "number" || typeof o != "number" || typeof s != "number" || typeof r != "number" || !Number.isFinite(e) || !Number.isFinite(n) || !Number.isFinite(o) || !Number.isFinite(s) || !Number.isFinite(r) || o <= 0 || s <= 0) {
    delete t.groupTitleRect;
    return;
} let i = n - s / 2, g = Math.min(r, n + s / 2), l = Math.min(Tr, Math.max(0, g - i)), a = i + l; if (a <= i) {
    delete t.groupTitleRect;
    return;
} t.groupTitleRect = { left: e - o / 2, right: e + o / 2, top: i, bottom: a }; }
f(Wo, "assignTopLaneTitleRect");
function Ko(t) { let e = t.direction, n = t.nodes ??= []; for (let r of t.nodes ?? [])
    r.isGroup && !r.parentId && (r.shape = "swimlane", e && (r.direction = e)); let o = n.filter(r => !r.isGroup && !r.parentId); if (o.length === 0)
    return; let s = n.find(r => r.id === In); s ? s.isGroup && (s.shape = "swimlane", e && (s.direction = e)) : (s = xt({ id: In, label: "", isGroup: !0, shape: "swimlane", padding: 20 }, e ? { direction: e } : {}), n.push(s)); for (let r of o)
    r.parentId = In; }
f(Ko, "prepareLayoutForSwimlanes");
function qo(t) { let e = new Map; for (let l of t.nodes ?? [])
    e.set(l.id, l); let n = []; for (let l of t.edges ?? []) {
    let a = typeof l.start == "string" ? l.start : void 0, u = typeof l.end == "string" ? l.end : void 0;
    !a || !u || l.labelNodeId || n.push({ id: l.id, src: a, dst: u, ref: l });
} let o = t.nodes ?? [], s = o.filter(l => l.isGroup), r = o.filter(l => !l.isGroup); return { nodes: [...[...s].reverse(), ...r].map(l => l.id), edges: n, layout: t, nodeById: e }; }
f(qo, "toGraphView");
function Jo(t, e, n, o) { let { layout: s } = t, r = t.nodeById, i = o?.layerGap ?? 100, g = o?.nodeGap ?? 40, l = 0; for (let L of e.layers) {
    let m = 0;
    for (let h of L) {
        let c = r.get(h);
        if (!c) {
            m++;
            continue;
        }
        c.layer = l, c.order = m;
        let p = n.x[h] ?? m * g, C = n.y[h] ?? l * i;
        c.x = p, c.y = C, m++;
    }
    l++;
} let a = s.nodes ?? [], u = new Map, y = []; for (let L of a) {
    if (!L?.isGroup)
        continue;
    L.parentId || y.push(L);
    let m = a.filter(M => M.parentId === L.id), h = 1 / 0, c = -1 / 0, p = 1 / 0, C = -1 / 0;
    for (let M of m) {
        let v = M.x ?? n.x[M.id], R = M.y ?? n.y[M.id], I = M.width ?? 0, b = M.height ?? 0;
        v != null && R != null && (h = Math.min(h, v - I / 2), c = Math.max(c, v + I / 2), p = Math.min(p, R - b / 2), C = Math.max(C, R + b / 2));
    }
    if (h === 1 / 0 || p === 1 / 0)
        L.x = L.x ?? 0, L.y = L.y ?? 0, L.width = L.width ?? 0, L.height = L.height ?? 0;
    else {
        let M = L.padding ?? 20, v = L.parentId ? M : 2 * Tn(L), R = M, I = Math.max(0, c - h) + v, b = Math.max(0, C - p) + R, T = (h + c) / 2, N = (p + C) / 2;
        L.x = T, L.y = N, L.width = I, L.height = b, u.set(L.id, { minX: h, maxX: c, minY: p, maxY: C });
    }
} if (y.length > 0 && u.size > 0) {
    let L = 1 / 0, m = -1 / 0, h = 0;
    for (let c of y) {
        let p = c.padding ?? 20;
        p > h && (h = p);
        let C = u.get(c.id);
        C && (L = Math.min(L, C.minY), m = Math.max(m, C.maxY));
    }
    if (L !== 1 / 0 && m !== -1 / 0) {
        let c = Math.max(0, m - L), C = Math.max(h, 36), M = c + 2 * C, v = (L + m) / 2;
        for (let F of y)
            F.y = v, F.height = M, F.swimlaneContentTop = L;
        let R = [...y].sort((F, w) => { let _ = F.x ?? 0, k = w.x ?? 0; return _ - k; }), I = [], b = [], T = [];
        for (let F of R) {
            let w = u.get(F.id);
            if (!w)
                continue;
            let _ = Math.max(0, w.maxX - w.minX) + 2 * Tn(F), k = (w.minX + w.maxX) / 2;
            I.push(F.id), b.push(k), T.push(_);
        }
        let N = I.length;
        if (N > 0) {
            let F = new Map;
            if (N === 1)
                F.set(I[0], T[0]);
            else {
                let w = [];
                for (let $ = 0; $ < N - 1; $++)
                    w.push(b[$ + 1] - b[$]);
                let _ = new Array(N);
                _[0] = 0;
                for (let $ = 0; $ < N - 1; $++)
                    _[$ + 1] = 2 * w[$] - _[$];
                let k = 0, B = Number.POSITIVE_INFINITY;
                for (let $ = 0; $ < N; $++) {
                    let K = T[$];
                    $ % 2 === 0 ? k = Math.max(k, K - _[$]) : B = Math.min(B, _[$] - K);
                }
                let X = k;
                k <= B ? X = (k + B) / 2 : X = k;
                for (let $ = 0; $ < N; $++) {
                    let K = _[$] + ($ % 2 === 0 ? X : -X), ct = Math.max(T[$], K);
                    F.set(I[$], ct);
                }
            }
            for (let w of y) {
                let _ = F.get(w.id);
                _ != null && (w.width = _), Wo(w);
            }
        }
    }
} }
f(Jo, "writeBackToLayoutData");
var Ar = "[EdgeLabelNodes]";
function Zo(t) { let e = [], n = [], o = new Map; for (let i of t.nodes)
    o.set(i.id, i); for (let i of t.edges) {
    if (!i.label || i.label.length === 0 || i.isLayoutOnly || i.labelNodeId)
        continue;
    let g = i.start ? o.get(i.start) : void 0, l = i.end ? o.get(i.end) : void 0;
    if (!g || !l) {
        Ge.warn(Ar, `Edge ${i.id} has missing source or target node`);
        continue;
    }
    let a = `edge-label-${i.start}-${i.end}-${i.id}`, y = g.parentId !== l.parentId ? l.parentId : g.parentId, L = xt({ id: a, label: i.label, edgeStart: i.start ?? "", edgeEnd: i.end ?? "", shape: "labelRect", width: 0, height: 0, isEdgeLabel: !0, isDummy: !0, parentId: y, isGroup: !1, labelStyle: Array.isArray(i.labelStyle) ? i.labelStyle[0] : i.labelStyle ?? "" }, g.dir ? { dir: g.dir } : {});
    e.push(L), i.labelNodeId = a, i.label = void 0, i.text = void 0;
    let m = { id: `${i.id}-to-label`, start: i.start, end: a, type: "normal", isLayoutOnly: !0 }, h = { id: `${i.id}-from-label`, start: a, end: i.end, type: "normal", isLayoutOnly: !0 };
    n.push(m, h);
} let s = [...t.nodes, ...e], r = [...t.edges, ...n]; return ae(xt({}, t), { nodes: s, edges: r }); }
f(Zo, "createEdgeLabelNodes");
var Dt = .001;
function so(t) { let e = t.x ?? 0, n = t.y ?? 0, o = t.width ?? 0, s = t.height ?? 0; return o > 0 && s > 0 ? { cx: e, cy: n, rect: Ne(e, n, o, s) } : void 0; }
f(so, "measuredNodeRect");
function ro(t) { if (t.isGroup)
    return; let e = so(t); return e ? { id: String(t.id ?? ""), cx: e.cx, cy: e.cy, rect: e.rect } : void 0; }
f(ro, "nodeBoundsInfoFor");
function se(t, e, n = Dt) { return Math.abs(t.x - e.x) < n && Math.abs(t.y - e.y) < n; }
f(se, "samePoint");
function dt(t, e, n = Dt) { return Math.abs(t.x - e.x) < n; }
f(dt, "sameX");
function ht(t, e, n = Dt) { return Math.abs(t.y - e.y) < n; }
f(ht, "sameY");
function At(t, e, n = Dt) { return ht(t, e, n) && Math.abs(t.x - e.x) > n; }
f(At, "isHorizontalSegment");
function wt(t, e, n = Dt) { return dt(t, e, n) && Math.abs(t.y - e.y) > n; }
f(wt, "isVerticalSegment");
function Vt(t, e, n, o) { return Math.max(0, Math.min(Math.max(t, e), Math.max(n, o)) - Math.max(Math.min(t, e), Math.min(n, o))); }
f(Vt, "overlapLength");
function le(t, e, n = Dt) { return t.horizontal && e.horizontal && ht(t.a, e.a, n) ? Vt(t.a.x, t.b.x, e.a.x, e.b.x) : t.vertical && e.vertical && dt(t.a, e.a, n) ? Vt(t.a.y, t.b.y, e.a.y, e.b.y) : 0; }
f(le, "sameAxisSegmentOverlapLength");
function Oe(t, e = Dt) { let n = []; for (let o = 0; o < t.length - 1; o++) {
    let s = t[o], r = t[o + 1], i = At(s, r, e), g = wt(s, r, e);
    (i || g) && n.push({ index: o, a: s, b: r, horizontal: i, vertical: g });
} return n; }
f(Oe, "orthogonalSegmentsForPoints");
function te(t, e = Dt) { let n = Oe(t, e), o = 0; for (let s = 1; s < n.length; s++)
    n[s - 1].horizontal !== n[s].horizontal && o++; return o; }
f(te, "countOrthogonalBends");
function pt(t, e = Dt) { let n = []; for (let o of t) {
    let s = n.length > 0 ? n[n.length - 1] : void 0;
    (!s || !se(s, o, e)) && n.push({ x: o.x, y: o.y });
} return n; }
f(pt, "dedupeConsecutivePoints");
function io(t, e = Dt) { if (!t || t.length !== 4)
    return; let [n, o, s, r] = t; return At(n, o, e) && wt(o, s, e) && At(s, r, e) ? { kind: "HVH", p0: n, p1: o, p2: s, p3: r } : wt(n, o, e) && At(o, s, e) && wt(s, r, e) ? { kind: "VHV", p0: n, p1: o, p2: s, p3: r } : void 0; }
f(io, "classifyThreeSegmentRoute");
function cn(t, e, n, o = 0) { let s = Math.min(t.x, e.x), r = Math.max(t.x, e.x), i = Math.min(t.y, e.y), g = Math.max(t.y, e.y); return r > n.left - o && s < n.right + o && g > n.top - o && i < n.bottom + o; }
f(cn, "segmentBoundsOverlapRect");
function co(t, e, n = 0) { return t.x > e.left + n && t.x < e.right - n && t.y > e.top + n && t.y < e.bottom - n; }
f(co, "pointInsideRect");
function Qo(t, e) { return t.left <= e.left && t.right >= e.right && t.top <= e.top && t.bottom >= e.bottom; }
f(Qo, "rectContainsRect");
function Je(t, e) { return t.left < e.right && t.right > e.left && t.top < e.bottom && t.bottom > e.top; }
f(Je, "rectsOverlap");
function An(t, e) { return { left: t.left - e, right: t.right + e, top: t.top - e, bottom: t.bottom + e }; }
f(An, "inflateRect");
function Ne(t, e, n, o) { return { left: t - n / 2, right: t + n / 2, top: e - o / 2, bottom: e + o / 2 }; }
f(Ne, "rectFromCenterSize");
function Jt(t) { return so(t)?.rect; }
f(Jt, "rectOfNodeBounds");
function Ce(t, e) { switch (e) {
    case "top": return { x: t.cx, y: t.rect.top };
    case "bottom": return { x: t.cx, y: t.rect.bottom };
    case "left": return { x: t.rect.left, y: t.cy };
    case "right": return { x: t.rect.right, y: t.cy };
} }
f(Ce, "portForRectSide");
function ao(t, e, n, o, s, r = Dt) { let i = e === "left" || e === "right", g = o === "left" || o === "right"; if (i && g) {
    if (e === "right" && o === "left" && t.x < n.x || e === "left" && o === "right" && t.x > n.x) {
        if (ht(t, n, r))
            return [t, n];
        let y = (t.x + n.x) / 2;
        return [t, { x: y, y: t.y }, { x: y, y: n.y }, n];
    }
    if (e === o) {
        if (ht(t, n, r))
            return;
        let y = e === "left" ? Math.min(t.x, n.x) - s : Math.max(t.x, n.x) + s;
        return [t, { x: y, y: t.y }, { x: y, y: n.y }, n];
    }
    return;
} if (!i && !g) {
    if (e === o) {
        if (dt(t, n, r))
            return;
        let L = e === "top" ? Math.min(t.y, n.y) - s : Math.max(t.y, n.y) + s;
        return [t, { x: t.x, y: L }, { x: n.x, y: L }, n];
    }
    if (!(e === "bottom" && o === "top" && t.y < n.y || e === "top" && o === "bottom" && t.y > n.y))
        return;
    if (dt(t, n, r))
        return [t, n];
    let y = (t.y + n.y) / 2;
    return [t, { x: t.x, y }, { x: n.x, y }, n];
} if (i && !g) {
    let u = e === "right" && n.x > t.x || e === "left" && n.x < t.x, y = o === "top" && t.y < n.y || o === "bottom" && t.y > n.y;
    return u && y ? [t, { x: n.x, y: t.y }, n] : void 0;
} let l = e === "bottom" && n.y > t.y || e === "top" && n.y < t.y, a = o === "left" && t.x < n.x || o === "right" && t.x > n.x; return l && a ? [t, { x: t.x, y: n.y }, n] : void 0; }
f(ao, "buildOrthogonalPortPath");
function lo(t, e, n, o) { return e === "left" || e === "right" ? [t, { x: o, y: t.y }, { x: o, y: n.y }, n] : [t, { x: t.x, y: o }, { x: n.x, y: o }, n]; }
f(lo, "buildSameSideTrackPath");
function an(t) { let e = new Map, n = []; for (let o of t) {
    if (o.isEdgeLabel)
        continue;
    let s = ro(o);
    s && (e.set(s.id, s), n.push({ id: s.id, rect: s.rect }));
} return { nodeInfoById: e, realNodeRects: n }; }
f(an, "collectRealNodeBounds");
function xe(t) { let e = [], n = []; for (let o of t) {
    let s = ro(o);
    if (!s)
        continue;
    let r = { id: s.id, rect: s.rect };
    o.isEdgeLabel ? n.push(r) : e.push(r);
} return { realNodeRects: e, labelNodeRects: n }; }
f(xe, "collectNodeRectEntries");
function ts(t, { includeEdgeLabels: e = !0 } = {}) { let n = []; for (let o of t) {
    if (o.isGroup || !e && o.isEdgeLabel)
        continue;
    let s = o.x ?? 0, r = o.y ?? 0, i = o.width ?? 0, g = o.height ?? 0;
    n.push(xt({ nodeId: o.id }, Ne(s, r, i, g)));
} return n; }
f(ts, "collectLayoutNodeRects");
function fo(t, e, n = Dt) { let o = t.start, s = t.end; if (!o || !s)
    return; let r = e.get(o), i = e.get(s); if (!(!r || !i))
    return { srcId: o, dstId: s, srcInfo: r, dstInfo: i, collinearX: Math.abs(r.cx - i.cx) < n, collinearY: Math.abs(r.cy - i.cy) < n }; }
f(fo, "getNodePairGeometry");
function Rt(t, e, n, o = [], s = 0) { for (let r of n)
    if (!o.includes(r.id) && cn(t, e, r.rect, -s))
        return !0; return !1; }
f(Rt, "segmentHitsAnyRect");
function uo(t, e, n, o, s = Dt, r = 1e-6) { let i = ht(t, e, s), g = dt(t, e, s), l = ht(n, o, s), a = dt(n, o, s); if (i && l || g && a || !(i || g) || !(l || a))
    return !1; let u = i ? { a: t, b: e } : { a: n, b: o }, y = g ? { a: t, b: e } : { a: n, b: o }, L = u.a.y, m = Math.min(u.a.x, u.b.x), h = Math.max(u.a.x, u.b.x), c = y.a.x, p = Math.min(y.a.y, y.b.y), C = Math.max(y.a.y, y.b.y); if (c < m || c > h || L < p || L > C)
    return !1; let M = Math.abs(c - u.a.x) < r && Math.abs(L - u.a.y) < r || Math.abs(c - u.b.x) < r && Math.abs(L - u.b.y) < r, v = Math.abs(c - y.a.x) < r && Math.abs(L - y.a.y) < r || Math.abs(c - y.b.x) < r && Math.abs(L - y.b.y) < r; return !(M && v); }
f(uo, "orthogonalSegmentsCross");
function es(t, e, n, o, s = Dt) { let r = ht(t, e, s), i = dt(t, e, s), g = ht(n, o, s), l = dt(n, o, s); return i && l && dt(t, n, s) ? Vt(t.y, e.y, n.y, o.y) > s : r && g && ht(t, n, s) ? Vt(t.x, e.x, n.x, o.x) > s : !1; }
f(es, "sameAxisSegmentsOverlap");
function Ze(t, e, n, o, { epsilon: s = Dt, skipDegenerateOther: r = !1 } = {}) { for (let i of n) {
    if (i === o || i.isLayoutOnly)
        continue;
    let g = i.points;
    if (!(!g || g.length < 2))
        for (let l = 0; l < g.length - 1; l++) {
            let a = g[l], u = g[l + 1];
            if (!(r && se(a, u, s)) && (uo(t, e, a, u, s) || es(t, e, a, u, s)))
                return !0;
        }
} return !1; }
f(Ze, "segmentConflictsWithAnyEdge");
function de(t, e, n, o, s = Dt) { let r = ht(t, e, s), i = dt(t, e, s), g = ht(n, o, s), l = dt(n, o, s); if (!(r && l || i && g))
    return !1; let a = r ? { a: t, b: e } : { a: n, b: o }, u = r ? { a: n, b: o } : { a: t, b: e }, y = a.a.y, L = Math.min(a.a.x, a.b.x), m = Math.max(a.a.x, a.b.x), h = u.a.x, c = Math.min(u.a.y, u.b.y), p = Math.max(u.a.y, u.b.y); return h > L + s && h < m - s && y > c + s && y < p - s; }
f(de, "orthogonalSegmentsStrictlyCross");
function wn(t, e, n) { let o = Math.min(e, n), s = Math.max(e, n); return t > o + Dt && t < s - Dt; }
f(wn, "strictlyBetween");
function ns(t, e, n) { return dt(t, e) && dt(e, n) ? wn(e.y, t.y, n.y) : ht(t, e) && ht(e, n) ? wn(e.x, t.x, n.x) : !1; }
f(ns, "isCollinearIntermediate");
function os(t) { let e = !1, n = []; for (let o = 0; o < t.length; o++) {
    let s = n[n.length - 1], r = t[o], i = o + 1 < t.length ? t[o + 1] : void 0;
    if (s && i) {
        if (se(s, i)) {
            o++, e = !0;
            continue;
        }
        if (ns(s, r, i)) {
            e = !0;
            continue;
        }
    }
    n.push(r);
} return { points: n, changed: e }; }
f(os, "simplifyPolylineOnce");
function Qe(t) { let e = [t[0]]; for (let o = 1; o < t.length; o++) {
    let s = e[e.length - 1], r = t[o];
    if (!dt(s, r) && !ht(s, r)) {
        let i = e.length >= 2 ? e[e.length - 2] : void 0, l = (i ? dt(i, s) : !1) ? { x: s.x, y: r.y } : { x: r.x, y: s.y };
        e.push(l);
    }
    e.push(r);
} let n = []; for (let o of e) {
    let s = n[n.length - 1];
    (!s || !se(s, o)) && n.push(o);
} return n; }
f(Qe, "orthogonalizePolyline");
function fe(t) { if (t.length < 3)
    return t; let e = [...t]; for (let n = 0; n < 32; n++) {
    let o = os(e);
    if (e = o.points, !o.changed)
        break;
} return e; }
f(fe, "simplifyPolyline");
var nt = .001, wr = .5, Bo = 4;
function ho(t, e, n) { let o = t; if (o.isLayoutOnly || !o.points || o.points.length < n)
    return; let s = o.start ? e.get(o.start) : void 0, r = o.end ? e.get(o.end) : void 0; return { edge: o, points: o.points, srcRect: s ? Jt(s) : void 0, dstRect: r ? Jt(r) : void 0 }; }
f(ho, "endpointContextFor");
function ss(t, e, n) { if (ht(t, e, nt))
    return { x: t.x < n.left ? n.left : n.right, y: t.y }; if (dt(t, e, nt)) {
    let o = t.y < n.top ? n.top : n.bottom;
    return { x: t.x, y: o };
} return { x: Math.min(n.right, Math.max(n.left, t.x)), y: Math.min(n.bottom, Math.max(n.top, t.y)) }; }
f(ss, "segmentEnterPoint");
function Rn(t, e, n) { let o = n ? 1 : -1, s = n ? 0 : t.length - 1; for (; s >= 0 && s < t.length && co(t[s], e, wr);)
    s += o; if (s < 0 || s >= t.length)
    return t; let r = s - o; if (r < 0 || r >= t.length)
    return t; let i = ss(t[s], t[r], e); return n ? [i, ...t.slice(s)] : [...t.slice(0, s + 1), i]; }
f(Rn, "clipEndpoint");
function rs(t, e) { for (let n of t) {
    let o = ho(n, e, 2);
    if (!o)
        continue;
    let s = [...o.points];
    o.srcRect && (s = Rn(s, o.srcRect, !0)), o.dstRect && (s = Rn(s, o.dstRect, !1)), s = fe(Qe(s)), s = go(s, o.srcRect, o.dstRect), o.edge.points = fe(Qe(s));
} }
f(rs, "clipEdgeEndpointsToNodeBoundaries");
function Nn(t, e, n, o = !1) { if (ht(t, e, nt)) {
    if (e.y < n.top - nt || e.y > n.bottom + nt)
        return e;
    if (o) {
        if (t.x < n.left - nt)
            return { x: n.left, y: t.y };
        if (t.x > n.right + nt)
            return { x: n.right, y: t.y };
    }
    return { x: Math.abs(e.x - n.left) <= Math.abs(e.x - n.right) ? n.left : n.right, y: t.y };
} if (dt(t, e, nt)) {
    if (e.x < n.left - nt || e.x > n.right + nt)
        return e;
    if (o) {
        if (t.y < n.top - nt)
            return { x: t.x, y: n.top };
        if (t.y > n.bottom + nt)
            return { x: t.x, y: n.bottom };
    }
    let s = Math.abs(e.y - n.top) <= Math.abs(e.y - n.bottom);
    return { x: t.x, y: s ? n.top : n.bottom };
} return e; }
f(Nn, "snapEndpointToBoundary");
function tn(t, e, n) { let o = t[e]; for (let s = e + n; s >= 0 && s < t.length; s += n) {
    let r = t[s];
    if (!se(r, o, nt))
        return r;
} return t[e + n]; }
f(tn, "firstDistinctAdjacent");
function en(t, e) { let n = t + Bo, o = e - Bo; return n <= o ? { lo: n, hi: o } : { lo: (t + e) / 2, hi: (t + e) / 2 }; }
f(en, "cornerClearanceRange");
function On(t, e, n) { let { lo: o, hi: s } = en(e, n); return Math.min(s, Math.max(o, t)); }
f(On, "clampToCornerClearance");
function is(t) { let e = Math.max(...t.map(o => o.lo)), n = Math.min(...t.map(o => o.hi)); if (!(e > n))
    return { lo: e, hi: n }; }
f(is, "intersectRanges");
function Bn(t, e) { return e === "left" || e === "right" ? en(t.top, t.bottom) : en(t.left, t.right); }
f(Bn, "clearanceRangeForSide");
function nn(t, e, n) { let o = t.y >= n.top - nt && t.y <= n.bottom + nt, s = t.x >= n.left - nt && t.x <= n.right + nt; if (ht(t, e, nt) && o) {
    if (Math.abs(t.x - n.left) < nt)
        return "left";
    if (Math.abs(t.x - n.right) < nt)
        return "right";
} if (dt(t, e, nt) && s) {
    if (Math.abs(t.y - n.top) < nt)
        return "top";
    if (Math.abs(t.y - n.bottom) < nt)
        return "bottom";
} }
f(nn, "terminalSideForSegment");
function Fe(t) { return t === "left" || t === "right"; }
f(Fe, "isHorizontalSide");
function cs(t, e, n, o, s) { let r = [], i = n ? nn(t, e, n) : void 0, g = o ? nn(e, t, o) : void 0; return n && i && Fe(i) === s && r.push(Bn(n, i)), o && g && Fe(g) === s && r.push(Bn(o, g)), r.length > 0 ? is(r) : void 0; }
f(cs, "straightClearanceRange");
function Fn(t, e, n, o, s) { let r = cs(t, e, n, o, s); if (!r)
    return; let i = s ? t.y : t.x, g = Math.min(r.hi, Math.max(r.lo, i)); if (!(Math.abs(g - i) < nt))
    return s ? [{ x: t.x, y: g }, { x: e.x, y: g }] : [{ x: g, y: t.y }, { x: g, y: e.y }]; }
f(Fn, "clearStraightEndpointCornerAxis");
function go(t, e, n) { if (t.length !== 2)
    return t; let [o, s] = t; return ht(o, s, nt) ? Fn(o, s, e, n, !0) ?? t : dt(o, s, nt) ? Fn(o, s, e, n, !1) ?? t : t; }
f(go, "clearStraightEndpointCornerConnections");
function as(t, e, n) { return Fe(n) ? { x: t.x, y: On(t.y, e.top, e.bottom) } : { x: On(t.x, e.left, e.right), y: t.y }; }
f(as, "cornerClearedEndpoint");
function ls(t, e, n, o, s, r) { let i = t.map(g => xt({}, g)); for (let g = e; g >= 0 && g < t.length; g += n) {
    let l = t[g];
    if (r && !ht(l, o, nt) || !r && !dt(l, o, nt))
        break;
    r ? i[g].y = s.y : i[g].x = s.x;
} return i; }
f(ls, "moveCollinearEndpointRun");
function Pn(t, e, n) { if (t.length < 2)
    return t; let o = n ? 0 : t.length - 1, s = n ? 1 : -1, r = t[o], i = tn(t, o, s); if (!i)
    return t; let g = nn(r, i, e); if (!g)
    return t; let l = Fe(g), a = as(r, e, g); return se(r, a, nt) ? t : ls(t, o, s, r, a, l); }
f(Pn, "clearEndpointCornerConnection");
function kn(t, e, n) { let o = Math.min(t.x, e.x) >= n.left - nt && Math.max(t.x, e.x) <= n.right + nt, s = Math.min(t.y, e.y) >= n.top - nt && Math.max(t.y, e.y) <= n.bottom + nt; if (Math.abs(t.y - n.top) < nt && Math.abs(e.y - n.top) < nt && o)
    return "top"; if (Math.abs(t.y - n.bottom) < nt && Math.abs(e.y - n.bottom) < nt && o)
    return "bottom"; if (Math.abs(t.x - n.left) < nt && Math.abs(e.x - n.left) < nt && s)
    return "left"; if (Math.abs(t.x - n.right) < nt && Math.abs(e.x - n.right) < nt && s)
    return "right"; }
f(kn, "borderSideForSegment");
function _n(t, e, n, o) { switch (t) {
    case "top": return dt(e, n, nt) && n.y < o.top - nt;
    case "bottom": return dt(e, n, nt) && n.y > o.bottom + nt;
    case "left": return ht(e, n, nt) && n.x < o.left - nt;
    case "right": return ht(e, n, nt) && n.x > o.right + nt;
} }
f(_n, "leavesOutward");
function Dn(t, e, n) { if (t.length < 3)
    return t; if (n) {
    let r = kn(t[0], t[1], e);
    return r && _n(r, t[1], t[2], e) ? t.slice(1) : t;
} let o = t.length - 1, s = kn(t[o - 1], t[o], e); return s && _n(s, t[o - 1], t[o - 2], e) ? t.slice(0, o) : t; }
f(Dn, "collapseOwnBorderStub");
function fs(t, e, n) { let o = t; if (e) {
    let r = tn(o, 0, 1);
    if (r) {
        let i = Nn(r, o[0], e);
        i !== o[0] && (o = [i, ...o.slice(1)]);
    }
    o = Dn(o, e, !0);
} if (n) {
    let r = o.length - 1, i = tn(o, r, -1);
    if (i) {
        let g = Nn(i, o[r], n, !0);
        g !== o[r] && (o = [...o.slice(0, r), g]);
    }
    o = Dn(o, n, !1);
} let s = go(o, e, n); return s !== o || o.length === 2 ? s : (e && (o = Pn(o, e, !0)), n && (o = Pn(o, n, !1)), o); }
f(fs, "snapAndCollapseEndpoints");
function Hn(t, e) { for (let n of t) {
    let o = ho(n, e, 2);
    if (!o)
        continue;
    let s = pt(o.points, nt), r = fs(s, o.srcRect, o.dstRect);
    if (r.length < 3) {
        o.edge.points = r;
        continue;
    }
    let i = [r[0], xt({}, r[0]), ...r.slice(1, -1), r[r.length - 1], xt({}, r[r.length - 1])];
    o.edge.points = i;
} }
f(Hn, "prepareEdgeEndpointsForRenderer");
function po(t) { return new Map(t.map(e => [e.id, e])); }
f(po, "buildNodeMap");
function ds(t, e) { let n = t.parentId, o = null; for (; n;) {
    let s = e.get(n);
    if (!s?.isGroup)
        break;
    o = s.id, n = s.parentId;
} return o; }
f(ds, "resolveTopLevelGroupId");
function Xn(t, e) { let n = 0, o = t.parentId; for (; o;) {
    let s = e.get(o);
    if (!s?.isGroup)
        break;
    n++, o = s.parentId;
} return n; }
f(Xn, "groupDepth");
function mo(t) { let e = 1 / 0, n = -1 / 0, o = 1 / 0, s = -1 / 0; for (let r of t) {
    let i = r.x, g = r.y;
    if (typeof i != "number" || typeof g != "number")
        continue;
    let l = r.width ?? 0, a = r.height ?? 0;
    e = Math.min(e, i - l / 2), n = Math.max(n, i + l / 2), o = Math.min(o, g - a / 2), s = Math.max(s, g + a / 2);
} return e === 1 / 0 || o === 1 / 0 ? null : { minX: e, maxX: n, minY: o, maxY: s }; }
f(mo, "boundsForChildren");
function us(t, e) { let n = t.padding ?? 20; t.x = (e.minX + e.maxX) / 2, t.y = (e.minY + e.maxY) / 2, t.width = Math.max(0, e.maxX - e.minX) + n, t.height = Math.max(0, e.maxY - e.minY) + n; }
f(us, "applyGroupBounds");
function hs(t) { let e = po(t), n = t.filter(o => o.isGroup && o.parentId).sort((o, s) => Xn(s, e) - Xn(o, e)); for (let o of n) {
    let s = t.filter(i => i.parentId === o.id), r = mo(s);
    r && us(o, r);
} }
f(hs, "recomputeNestedGroupBounds");
function on(t, e) { let n = t.nodes ?? [], o = t.edges ?? [], s = n.filter(l => !l.isGroup), r = 1 / 0, i = -1 / 0; for (let l of s) {
    let a = l[e];
    typeof a == "number" && (r = Math.min(r, a), i = Math.max(i, a));
} if (!Number.isFinite(r) || !Number.isFinite(i))
    return !1; let g = f(l => r + i - l, "mirror"); for (let l of n) {
    let a = l[e];
    typeof a == "number" && (l[e] = g(a));
    let u = l.groupTitleRect;
    u && (l.groupTitleRect = e === "x" ? ae(xt({}, u), { left: g(u.right), right: g(u.left) }) : ae(xt({}, u), { top: g(u.bottom), bottom: g(u.top) }));
} for (let l of o)
    for (let a of l.points ?? [])
        a[e] = g(a[e]); return !0; }
f(on, "mirrorAxis");
function gs(t) { return (t.nodes ?? []).some(n => !n.isGroup) ? on(t, "y") : !0; }
f(gs, "applyBtDirectionTransform");
function ps(t, e = "LR") { let n = t.nodes ?? [], o = t.edges ?? [], s = n.filter(B => !B.isGroup), r = 1 / 0, i = 1 / 0; for (let B of s) {
    let X = B.x ?? 0, $ = B.y ?? 0;
    X < r && (r = X), $ < i && (i = $);
} if (!Number.isFinite(r) || !Number.isFinite(i))
    return !1; let g = 36, l = 0, a = 0; for (let B of s)
    l += B.width ?? 0, a += B.height ?? 0; let u = l / s.length, y = a / s.length, L = y > 0 ? Math.max(1, u / y) : 1; for (let B of s) {
    let X = B.x ?? 0, K = ((B.y ?? 0) - i) * L + g, ct = X - r;
    B.x = K, B.y = ct;
} for (let B of o)
    if (B.points)
        for (let X of B.points) {
            let $ = X.x, ct = (X.y - i) * L + g, mt = $ - r;
            X.x = ct, X.y = mt;
        } hs(n); let m = n.filter(B => B.isGroup && !B.parentId); if (m.length === 0)
    return e === "RL" && on(t, "x"), !0; let h = po(n), c = new Map; for (let B of n) {
    if (B.isGroup)
        continue;
    let X = ds(B, h);
    if (!X)
        continue;
    let $ = c.get(X) ?? [];
    $.push(B), c.set(X, $);
} let p = 0; for (let B of m) {
    let X = B.padding ?? 0;
    X > p && (p = X);
} let C = [], M = 1 / 0, v = -1 / 0; for (let B of m) {
    let X = c.get(B.id) ?? [], $ = mo(X);
    $ && (M = Math.min(M, $.minX), v = Math.max(v, $.maxX), C.push({ lane: B, contentTop: $.minY, contentBottom: $.maxY, centerY: ($.minY + $.maxY) / 2 }));
} if (M === 1 / 0 || v === -1 / 0)
    return !0; let R = Math.max(0, v - M), I = Math.max(p, 10), b = R + 2 * I, T = g + b, w = (M + v) / 2 - b / 2 - g, _ = w + T / 2, k = Math.max(p, g); C.sort((B, X) => B.centerY - X.centerY); for (let B = 0; B < C.length; B++) {
    let X = C[B], $, K;
    if (B === 0 ? $ = X.contentTop - k : $ = (C[B - 1].contentBottom + X.contentTop) / 2, B === C.length - 1)
        K = X.contentBottom + k;
    else {
        let Nt = C[B + 1];
        K = (X.contentBottom + Nt.contentTop) / 2;
    }
    let ct = Math.max(0, K - $), mt = ($ + K) / 2;
    X.lane.x = _, X.lane.y = mt, X.lane.width = T, X.lane.height = ct, X.lane.swimlaneContentTop = X.contentTop, X.lane.groupTitleRect = { left: w, right: w + g, top: $, bottom: K };
} return e === "RL" && on(t, "x"), !0; }
f(ps, "applyLrDirectionTransform");
var re = 1e-6, Rr = 8, Ve = Rr, Nr = [0, Ve, -Ve, 2 * Ve, -2 * Ve];
function ms(t, e) { let { nodeInfoById: n, realNodeRects: o } = an(e); for (let s of t) {
    if (s.isLayoutOnly)
        continue;
    let r = s.points;
    if (!r || r.length < 4)
        continue;
    let i = io(pt(r, re), re);
    if (!i)
        continue;
    let { p3: g } = i, l = i.kind === "HVH", a = fo(s, n, re);
    if (!a)
        continue;
    let { srcId: u, dstId: y, srcInfo: L, dstInfo: m, collinearX: h, collinearY: c } = a;
    if (h || c)
        continue;
    let p, C = L.rect;
    for (let M of Nr) {
        let v, R, I;
        if (l) {
            let _ = m.cy > L.cy ? C.bottom : C.top, k = L.cx + M;
            if (k <= C.left + re || k >= C.right - re)
                continue;
            v = { x: k, y: _ }, R = { x: k, y: g.y }, I = { x: g.x, y: g.y };
        }
        else {
            let _ = m.cx > L.cx ? C.right : C.left, k = L.cy + M;
            if (k <= C.top + re || k >= C.bottom - re)
                continue;
            v = { x: _, y: k }, R = { x: g.x, y: k }, I = { x: g.x, y: g.y };
        }
        let b = se(v, R, re), T = se(R, I, re);
        if (b && T || !b && Rt(v, R, o, [u], 1) || !T && Rt(R, I, o, [y], 1))
            continue;
        let N = !b && Ze(v, R, t, s, { epsilon: re, skipDegenerateOther: !0 }), F = !T && Ze(R, I, t, s, { epsilon: re, skipDegenerateOther: !0 });
        if (!(N || F)) {
            b ? p = [R, I] : T ? p = [v, R] : p = [v, R, I];
            break;
        }
    }
    p && (s.points = p);
} }
f(ms, "portSwapToLShape");
function ys(t, e) { let { realNodeRects: r, labelNodeRects: i } = xe(e.values()); for (let g of t) {
    if (g.isLayoutOnly)
        continue;
    let l = g.points;
    if (!l || l.length < 4)
        continue;
    let a = pt(l, .001);
    if (a.length < 4)
        continue;
    let u = a.length - 1, y = a[u], L = a[u - 1], m = a[u - 2], h = y.x - L.x, c = y.y - L.y, p = Math.hypot(h, c);
    if (p >= 10 || p < .001)
        continue;
    let C = L.x - m.x, M = L.y - m.y;
    if (Math.hypot(C, M) < .001)
        continue;
    let R = At(L, y, .001), I = wt(L, y, .001), b = At(m, L, .001), T = wt(m, L, .001);
    if (!(R && T || I && b))
        continue;
    let N = g.end, F = g.start, w = N ? e.get(N) : void 0;
    if (!w)
        continue;
    let _ = w.x ?? 0, k = w.y ?? 0, B = Jt(w);
    if (!B)
        continue;
    let X, $;
    if (T) {
        let W = M < 0;
        X = { x: _, y: m.y }, $ = { x: _, y: W ? B.bottom : B.top };
    }
    else {
        let W = C > 0;
        X = { x: m.x, y: k }, $ = { x: W ? B.right : B.left, y: k };
    }
    if (Rt(X, $, r, N ? [N] : [], -2) || Rt(X, $, i, [], -2))
        continue;
    if (F) {
        let W = e.get(F), et = W ? Jt(W) : void 0;
        if (et && co(X, et, 2))
            continue;
    }
    let K = f((W, et) => `${W.x.toFixed(3)},${W.y.toFixed(3)}|${et.x.toFixed(3)},${et.y.toFixed(3)}`, "ownSegmentKey"), ct = new Set;
    for (let W = 0; W < a.length - 1; W++)
        ct.add(K(a[W], a[W + 1]));
    let mt = f((W, et) => { for (let lt of t) {
        if (lt === g || lt.isLayoutOnly)
            continue;
        let gt = lt.points;
        if (!(!gt || gt.length < 2))
            for (let bt = 0; bt < gt.length - 1; bt++) {
                let Lt = gt[bt], Ut = gt[bt + 1];
                if (!ct.has(K(Lt, Ut)) && de(W, et, Lt, Ut, .001))
                    return !0;
            }
    } return !1; }, "segmentCrossesOtherEdge");
    if (mt(X, $))
        continue;
    if (u - 3 >= 0) {
        let W = a[u - 3], et = [F, N].filter(lt => !!lt);
        if (Rt(W, X, r, et, -2) || mt(W, X))
            continue;
    }
    let Pt = [...a.slice(0, u - 2), X, $];
    g.points = Pt;
    let Q = g.labelNodeId;
    if (Q) {
        let W = e.get(Q);
        if (W) {
            let et = W.width ?? 0, lt = W.height ?? 0;
            if (et > 0 && lt > 0) {
                let gt, bt, Lt = -1;
                for (let Ut = 0; Ut < Pt.length - 1; Ut++) {
                    let jt = Pt[Ut], Wt = Pt[Ut + 1], ee = Math.hypot(Wt.x - jt.x, Wt.y - jt.y), ve = ht(jt, Wt, .001), he = dt(jt, Wt, .001);
                    (ve && ee >= et + 2 || he && ee >= lt + 2) && ee > Lt && (Lt = ee, gt = (jt.x + Wt.x) / 2, bt = (jt.y + Wt.y) / 2);
                }
                gt !== void 0 && bt !== void 0 && (W.x = gt, W.y = bt);
            }
        }
    }
} }
f(ys, "collapseShortTerminalStub");
var Z = .001, _t = 8, it = Oe, Sn = f((t, e) => dt(t, e, Z) || ht(t, e, Z), "orthogonallyAligned");
function xs(t, e) { let s = f((m, h) => { let c = m.x ?? 0, p = m.y ?? 0, C = h.x - c, M = h.y - p, v = (m.width ?? 0) / 2, R = (m.height ?? 0) / 2; return Math.abs(M) * v > Math.abs(C) * R ? (M < 0 && (R = -R), { x: c + (M === 0 ? 0 : R * C / M), y: p + R }) : (C < 0 && (v = -v), { x: c + v, y: p + (C === 0 ? 0 : v * M / C) }); }, "rectIntersect"), r = f((m, h) => { let c = pt(m.points ?? []); if (c.length < 2)
    return; let p = h ? m.start : m.end, C = p ? e.get(p) : void 0, M = C ? Jt(C) : void 0; if (!C || !p || !M)
    return; let v = h ? c[0] : c[c.length - 1], R = h ? c[1] : c[c.length - 2], I = s(C, v), b = v; if (Sn(R, I) && (b = R), dt(I, b, Z))
    return { edge: m, edgeId: String(m.id ?? ""), nodeId: p, atStart: h, orientation: "V", coord: I.x, min: Math.min(I.y, b.y), max: Math.max(I.y, b.y), boundary: I, railEnd: b, rect: M }; if (ht(I, b, Z))
    return { edge: m, edgeId: String(m.id ?? ""), nodeId: p, atStart: h, orientation: "H", coord: I.y, min: Math.min(I.x, b.x), max: Math.max(I.x, b.x), boundary: I, railEnd: b, rect: M }; }, "terminalLaneFor"), i = f((m, h) => Math.max(0, Math.min(m.max, h.max) - Math.max(m.min, h.min)), "projectedOverlapLength"), g = f((m, h) => m.nodeId !== h.nodeId || m.orientation !== h.orientation ? !1 : m.orientation === "H" ? (Math.abs(m.boundary.x - m.rect.left) < 1 || Math.abs(m.boundary.x - m.rect.right) < 1) && dt(m.boundary, h.boundary, 1) : (Math.abs(m.boundary.y - m.rect.top) < 1 || Math.abs(m.boundary.y - m.rect.bottom) < 1) && ht(m.boundary, h.boundary, 1), "sameTerminalFace"), l = f((m, h) => m.nodeId !== h.nodeId || m.orientation !== h.orientation ? !1 : i(m, h) >= _t && Math.abs(m.coord - h.coord) < .5, "exactTerminalLaneConflict"), a = f((m, h) => { if (m.nodeId !== h.nodeId || m.orientation !== h.orientation || m.orientation !== "H" || m.atStart === h.atStart)
    return !1; let c = i(m, h); if (c < _t)
    return !1; let p = m.rect.bottom - m.rect.top; return c < p || c > 2 * p ? !1 : g(m, h) && Math.abs(m.coord - h.coord) < 16; }, "nearTerminalLaneConflict"), u = f((m, h) => { let c = pt(m.edge.points ?? []); if (c.length < 2)
    return; let p = m.orientation === "V" ? { x: m.boundary.x + h, y: m.boundary.y } : { x: m.boundary.x, y: m.boundary.y + h }, C = m.orientation === "V" ? { x: m.railEnd.x + h, y: m.railEnd.y } : { x: m.railEnd.x, y: m.railEnd.y + h }; if (!f(() => Math.abs(m.boundary.y - m.rect.top) < 1 || Math.abs(m.boundary.y - m.rect.bottom) < 1 ? ht(p, m.boundary, Z) && p.x >= m.rect.left + 1 && p.x <= m.rect.right - 1 : Math.abs(m.boundary.x - m.rect.left) < 1 || Math.abs(m.boundary.x - m.rect.right) < 1 ? dt(p, m.boundary, Z) && p.y >= m.rect.top + 1 && p.y <= m.rect.bottom - 1 : !1, "boundaryStaysOnSameFace")())
    return; if (m.atStart) {
    let b = c.length > 1 && se(c[1], m.railEnd, Z), T = c.slice(b ? 2 : 1), N = T[0];
    return N && !Sn(N, C) ? void 0 : [p, C, ...T];
} let v = c.length > 1 && se(c[c.length - 2], m.railEnd, Z), R = c.slice(0, v ? -2 : -1), I = R[R.length - 1]; if (!(I && !Sn(I, C)))
    return [...R, C, p]; }, "shiftedCandidate"), y = f(m => { let h = m.edge, c = pt(h.points ?? []); if (c.length !== 2)
    return !1; let p = h.start, C = h.end, M = p ? e.get(p) : void 0, v = C ? e.get(C) : void 0; if (!M || !v)
    return !1; let R = M.x ?? 0, I = M.y ?? 0, b = v.x ?? 0, T = v.y ?? 0, [N, F] = c; return ht(N, F, Z) && Math.abs(I - T) < 1 && Math.abs(R - b) > 1 || dt(N, F, Z) && Math.abs(R - b) < 1 && Math.abs(I - T) > 1; }, "laneIsStraightCollinearConnector"), L = [-7, 7, -14, 14, -21, 21]; for (let m = 0; m < 8; m++) {
    let h = t.filter(p => !p.isLayoutOnly).flatMap(p => [r(p, !0), r(p, !1)]).filter(p => !!p), c = !1;
    for (let p = 0; p < h.length && !c; p++)
        for (let C = p + 1; C < h.length && !c; C++) {
            let M = h[p], v = h[C];
            if (M.edge === v.edge || !(l(M, v) || a(M, v)))
                continue;
            let R = !l(M, v), I = [M, v].sort((b, T) => { let N = y(b), F = y(T); return N !== F ? Number(N) - Number(F) : +!T.atStart - +!b.atStart; });
            for (let b of I) {
                for (let T of L) {
                    let N = u(b, T);
                    if (!N)
                        continue;
                    let F = r(ae(xt({}, b.edge), { points: N }), b.atStart);
                    if (!(!F || h.some(w => w.edge !== b.edge && (l(F, w) || R && a(F, w))))) {
                        b.edge.points = N, c = !0;
                        break;
                    }
                }
                if (c)
                    break;
            }
        }
    if (!c)
        return;
} }
f(xs, "separateSharedRenderedTerminalLanes");
function bs(t, e) { let { realNodeRects: s, labelNodeRects: r } = xe(e.values()), i = f((l, a) => { let u = l.start, y = l.end, L = it(a); if (L.length !== a.length - 1)
    return !1; let m = [u, y].filter(h => !!h); for (let h of L)
    if (Rt(h.a, h.b, s, m, -2) || Rt(h.a, h.b, r, [], -2))
        return !1; for (let h of t) {
    if (h === l || h.isLayoutOnly)
        continue;
    let c = h.points;
    if (!(!c || c.length < 2)) {
        for (let p of L)
            for (let C of it(pt(c)))
                if (le(p, C, .5) >= _t || de(p.a, p.b, C.a, C.b, Z))
                    return !1;
    }
} return !0; }, "candidateIsSafe"), g = f((l, a) => { if (a + 4 >= l.length)
    return; let u = l[a], y = l[a + 1], L = l[a + 2], m = l[a + 3], h = l[a + 4], c = At(u, y) && wt(y, L) && At(L, m) && wt(m, h) && dt(u, m, Z) && dt(u, h, Z) && dt(y, L, Z) && (y.x - u.x) * (m.x - L.x) < 0, p = wt(u, y) && At(y, L) && wt(L, m) && At(m, h) && ht(u, m, Z) && ht(u, h, Z) && ht(y, L, Z) && (y.y - u.y) * (m.y - L.y) < 0; if (c || p)
    return pt([...l.slice(0, a + 1), h, ...l.slice(a + 5)]); if (a + 5 >= l.length)
    return; let C = l[a + 5], M = wt(u, y) && At(y, L) && wt(L, m) && At(m, h) && wt(h, C) && dt(u, h, Z) && dt(u, C, Z) && dt(L, m, Z) && (L.x - y.x) * (h.x - m.x) < 0, v = At(u, y) && wt(y, L) && At(L, m) && wt(m, h) && At(h, C) && ht(u, h, Z) && ht(u, C, Z) && ht(L, m, Z) && (L.y - y.y) * (h.y - m.y) < 0; if (!(!M && !v))
    return pt([...l.slice(0, a + 1), C, ...l.slice(a + 6)]); }, "withoutDogleg"); for (let l = 0; l < 8; l++) {
    let a = !1;
    for (let u of t) {
        if (u.isLayoutOnly)
            continue;
        let y = pt(u.points ?? []);
        for (let L = 0; L <= y.length - 5; L++) {
            let m = g(y, L);
            if (!(!m || !i(u, m))) {
                u.points = m, a = !0;
                break;
            }
        }
        if (a)
            break;
    }
    if (!a)
        return;
} }
f(bs, "collapseRedundantRectangularDoglegs");
function Yn(t, e) { let { realNodeRects: r, labelNodeRects: i } = xe(e.values()), g = t.filter(h => !h.isLayoutOnly), l = f((h, c, p) => pt(h === c ? p ?? [] : h.points ?? []), "pointsFor"), a = f((h, c) => { let p = 0; for (let C = 0; C < g.length; C++) {
    let M = it(l(g[C], h, c));
    for (let v = C + 1; v < g.length; v++) {
        let R = it(l(g[v], h, c));
        for (let I of M)
            for (let b of R)
                de(I.a, I.b, b.a, b.b, Z) && p++;
    }
} return p; }, "strictCrossingCount"), u = f(h => { let c = it(h); if (c.length !== 3)
    return; let p = c[1]; if (!(c[0].horizontal === p.horizontal || c[2].horizontal === p.horizontal))
    return { index: p.index, horizontal: p.horizontal, vertical: p.vertical, segment: p }; }, "middleRail"), y = f((h, c) => { let p = [h.start, h.end].filter(C => !!C); return r.filter(C => { if (p.includes(C.id))
    return !1; let M = C.rect; return c.horizontal ? Vt(c.a.x, c.b.x, M.left, M.right) >= _t && c.a.y >= M.top - 2 && c.a.y <= M.bottom + 2 : Vt(c.a.y, c.b.y, M.top, M.bottom) >= _t && c.a.x >= M.left - 2 && c.a.x <= M.right + 2; }); }, "blockingRectsFor"), L = f((h, c, p) => { let C = h.map(v => xt({}, v)); if (c.horizontal)
    C[c.index].y = p, C[c.index + 1].y = p;
else if (c.vertical)
    C[c.index].x = p, C[c.index + 1].x = p;
else
    return; let M = fe(pt(C)); return it(M).length === M.length - 1 ? M : void 0; }, "candidateByMovingRail"), m = f((h, c, p) => { let C = [h.start, h.end].filter(v => !!v), M = it(c); if (M.length !== c.length - 1)
    return !1; for (let v of M)
    if (Rt(v.a, v.b, r, C, -2) || Rt(v.a, v.b, i, [], -2))
        return !1; for (let v of g)
    if (v !== h) {
        for (let R of M)
            for (let I of it(l(v)))
                if (le(R, I, .5) >= _t)
                    return !1;
    } return a(h, c) <= p; }, "candidateIsSafe"); for (let h = 0; h < 8; h++) {
    let c = a(), p = !1;
    for (let C of g) {
        let M = l(C), v = u(M);
        if (!v)
            continue;
        let R = y(C, v.segment);
        if (R.length === 0)
            continue;
        let I = v.horizontal ? [Math.min(...R.map(b => b.rect.top)) - 20, Math.max(...R.map(b => b.rect.bottom)) + 20] : [Math.min(...R.map(b => b.rect.left)) - 20, Math.max(...R.map(b => b.rect.right)) + 20];
        for (let b of I) {
            let T = L(M, v.segment, b);
            if (!(!T || !m(C, T, c))) {
                C.points = T, p = !0;
                break;
            }
        }
        if (p)
            break;
    }
    if (!p)
        return;
} }
f(Yn, "liftObstacleHuggingSameSideRails");
function Gn(t, e) { let o = f(l => { let a = l.groupTitleRect; if (!(!a || typeof a.left != "number" || typeof a.right != "number" || typeof a.top != "number" || typeof a.bottom != "number" || !Number.isFinite(a.left) || !Number.isFinite(a.right) || !Number.isFinite(a.top) || !Number.isFinite(a.bottom) || a.right <= a.left || a.bottom <= a.top))
    return { left: a.left, right: a.right, top: a.top, bottom: a.bottom }; }, "validTitleRect"), s = f(l => { if (!l.isGroup || l.parentId)
    return; let a = l.direction, u = typeof a == "string" ? a.toUpperCase() : ""; if (u === "LR" || u === "RL" || u === "BT")
    return; let y = o(l), L = l.y, m = l.height; if (!y || typeof L != "number" || typeof m != "number" || !Number.isFinite(L) || !Number.isFinite(m) || m <= 0)
    return; let h = y.right - y.left, c = y.bottom - y.top; if (!(c <= 0 || h < c))
    return { node: l, rect: y }; }, "topLaneTitleFor"), r = f((l, a) => { if (!l.horizontal)
    return !1; let u = l.a.y; return u <= a.top + Z || u >= a.bottom - Z ? !1 : Vt(l.a.x, l.b.x, a.left, a.right) >= _t; }, "horizontalSegmentIntersectsTitle"), i = [...e.values()].map(s).filter(l => !!l); if (i.length === 0)
    return; let g = 0; for (let l of t) {
    if (l.isLayoutOnly)
        continue;
    let a = pt(l.points ?? []);
    for (let u of it(a))
        for (let y of i)
            r(u, y.rect) && (g = Math.max(g, y.rect.bottom - u.a.y + 4));
} if (!(g <= Z))
    for (let l of i) {
        let a = l.node.y, u = l.node.height;
        typeof a != "number" || typeof u != "number" || !Number.isFinite(a) || !Number.isFinite(u) || u <= 0 || (l.node.y = a - g / 2, l.node.height = u + g, l.node.groupTitleRect = ae(xt({}, l.rect), { top: l.rect.top - g, bottom: l.rect.bottom - g }));
    } }
f(Gn, "liftTopLaneTitleBandsAboveRails");
function $n(t, e) { let o = f(a => { let u = a.groupTitleRect; if (!(!u || typeof u.left != "number" || typeof u.right != "number" || typeof u.top != "number" || typeof u.bottom != "number" || !Number.isFinite(u.left) || !Number.isFinite(u.right) || !Number.isFinite(u.top) || !Number.isFinite(u.bottom) || u.right <= u.left || u.bottom <= u.top))
    return { left: u.left, right: u.right, top: u.top, bottom: u.bottom }; }, "validTitleRect"), s = f(a => { if (!a.isGroup || a.parentId || a.direction !== "LR")
    return; let y = o(a), L = a.x, m = a.width; if (!y || typeof L != "number" || typeof m != "number" || !Number.isFinite(L) || !Number.isFinite(m) || m <= 0)
    return; let h = y.right - y.left, c = y.bottom - y.top; if (!(h <= 0 || c < h))
    return { node: a, rect: y }; }, "leftLaneTitleFor"), r = f((a, u) => { if (!a.vertical)
    return !1; let y = a.a.x; return y <= u.left + Z || y >= u.right - Z ? !1 : Vt(a.a.y, a.b.y, u.top, u.bottom) >= _t; }, "verticalSegmentIntersectsTitle"), i = f((a, u) => { if (!a.horizontal)
    return !1; let y = a.a.y; return y <= u.top + Z || y >= u.bottom - Z ? !1 : Vt(a.a.x, a.b.x, u.left, u.right) >= _t; }, "horizontalSegmentIntersectsTitle"), g = [...e.values()].map(s).filter(a => !!a); if (g.length === 0)
    return; let l = 0; for (let a of t) {
    if (a.isLayoutOnly)
        continue;
    let u = pt(a.points ?? []);
    for (let y of it(u))
        for (let L of g)
            if (r(y, L.rect))
                l = Math.max(l, L.rect.right - y.a.x + 4);
            else if (i(y, L.rect)) {
                let m = Math.min(y.a.x, y.b.x);
                l = Math.max(l, L.rect.right - m + 4);
            }
} if (!(l <= Z))
    for (let a of g) {
        let u = a.node.x, y = a.node.width;
        typeof u != "number" || typeof y != "number" || !Number.isFinite(u) || !Number.isFinite(y) || y <= 0 || (a.node.x = u - l / 2, a.node.width = y + l, a.node.groupTitleRect = ae(xt({}, a.rect), { left: a.rect.left - l, right: a.rect.right - l }));
    } }
f($n, "shiftLeftLaneTitleBandsLeftOfRails");
function Ms(t, e) { let { realNodeRects: s } = xe(e.values()), r = t.filter(c => !c.isLayoutOnly), i = f((c, p = new Map) => pt(p.get(c) ?? c.points ?? []), "replacementPointsFor"), g = f((c = new Map) => { let p = 0; for (let C = 0; C < r.length; C++) {
    let M = it(i(r[C], c));
    for (let v = C + 1; v < r.length; v++) {
        let R = it(i(r[v], c));
        for (let I of M)
            for (let b of R)
                de(I.a, I.b, b.a, b.b, Z) && p++;
    }
} return p; }, "crossingCount"), l = f((c = new Map) => r.reduce((p, C) => p + te(i(C, c)), 0), "totalBends"), a = f(c => { let p = i(c); if (p.length < 4)
    return; let C = p[p.length - 2], M = p[p.length - 1]; if (!(!At(C, M, Z) && !wt(C, M, Z)))
    return { tailStart: C, terminal: M }; }, "terminalTailFor"), u = f((c, p) => { let C = i(c); if (C.length < 3)
    return; let M = C[0], v = C[1], R; if (At(M, v, Z))
    R = { x: v.x, y: p.tailStart.y };
else if (wt(M, v, Z))
    R = { x: p.tailStart.x, y: v.y };
else
    return; let I = fe(pt([M, v, R, p.tailStart, p.terminal])); return it(I).length === I.length - 1 ? I : void 0; }, "candidateWithDestinationTail"), y = f((c, p) => { let C = [c.start, c.end].filter(M => !!M); for (let M of it(p))
    if (Rt(M.a, M.b, s, C, -2))
        return !0; return !1; }, "pathHasNodeHit"), L = f((c, p, C) => { for (let M of r)
    if (M !== c) {
        for (let v of it(p))
            for (let R of it(i(M, C)))
                if (le(v, R, .5) >= _t)
                    return !0;
    } return !1; }, "pathHasSharedTrack"), m = f((c, p, C) => !y(c, p) && !L(c, p, C), "candidateIsSafe"), h = f(() => { let c = new Map; for (let p of r) {
    let C = p.end;
    if (!C || !e.has(C) || i(p).length < 4)
        continue;
    let v = c.get(C) ?? [];
    v.push(p), c.set(C, v);
} return c; }, "edgesByDestination"); for (let c = 0; c < 4; c++) {
    let p = g();
    if (p === 0)
        return;
    let C = l(), M, v = p, R = C;
    for (let I of h().values())
        for (let b = 0; b < I.length; b++)
            for (let T = b + 1; T < I.length; T++) {
                let N = I[b], F = I[T], w = a(N), _ = a(F);
                if (!w || !_)
                    continue;
                let k = u(N, _), B = u(F, w);
                if (!k || !B)
                    continue;
                let X = new Map([[N, k], [F, B]]);
                if (!m(N, k, X) || !m(F, B, X))
                    continue;
                let $ = g(X), K = l(X);
                $ >= p || $ > v || $ === v && K >= R || (M = X, v = $, R = K);
            }
    if (!M)
        return;
    for (let [I, b] of M)
        I.points = b;
} }
f(Ms, "swapDestinationTerminalTailsToReduceCrossings");
function Is(t, e) { let { realNodeRects: i, labelNodeRects: g } = xe(e.values()), l = t.filter(I => !I.isLayoutOnly), a = f((I, b = new Map) => pt(b.get(I) ?? I.points ?? []), "replacementPointsFor"), u = f((I = new Map) => { let b = 0; for (let T = 0; T < l.length; T++) {
    let N = it(a(l[T], I));
    for (let F = T + 1; F < l.length; F++) {
        let w = it(a(l[F], I));
        for (let _ of N)
            for (let k of w)
                de(_.a, _.b, k.a, k.b, Z) && b++;
    }
} return b; }, "strictCrossingCount"), y = f((I = new Map) => l.reduce((b, T) => b + te(a(T, I)), 0), "totalBends"), L = f(I => { let b = I.start, T = I.end, N = b ? e.get(b) : void 0, F = T ? e.get(T) : void 0, w = N ? Jt(N) : void 0, _ = F ? Jt(F) : void 0; return w && _ ? { src: w, dst: _ } : void 0; }, "endpointRectsFor"), m = f((I, b, T) => { if (T.index <= 0 || T.index + 1 >= b.length - 1)
    return; let N = L(I); if (N) {
    if (T.vertical) {
        let F = T.a.x, w = Math.min(N.src.left, N.dst.left), _ = Math.max(N.src.right, N.dst.right), k = F < w - Z ? "left" : F > _ + Z ? "right" : void 0;
        return k ? { edge: I, points: b, segmentIndex: T.index, axis: "vertical", side: k, coord: F, min: Math.min(T.a.y, T.b.y), max: Math.max(T.a.y, T.b.y) } : void 0;
    }
    if (T.horizontal) {
        let F = T.a.y, w = Math.min(N.src.top, N.dst.top), _ = Math.max(N.src.bottom, N.dst.bottom), k = F < w - Z ? "top" : F > _ + Z ? "bottom" : void 0;
        return k ? { edge: I, points: b, segmentIndex: T.index, axis: "horizontal", side: k, coord: F, min: Math.min(T.a.x, T.b.x), max: Math.max(T.a.x, T.b.x) } : void 0;
    }
} }, "externalRailForSegment"), h = f(() => { let I = []; for (let b of l) {
    let T = a(b);
    for (let N of it(T)) {
        let F = m(b, T, N);
        F && I.push(F);
    }
} return I; }, "collectExternalRails"), c = f((I, b) => I.edge !== b.edge && I.axis === b.axis && I.side === b.side && Vt(I.min, I.max, b.min, b.max) >= _t, "railsInteract"), p = f(I => { let b = [], T = new Set; for (let N of I) {
    if (T.has(N))
        continue;
    let F = [N], w = [];
    for (T.add(N); F.length > 0;) {
        let _ = F.pop();
        w.push(_);
        for (let k of I)
            !T.has(k) && c(_, k) && (T.add(k), F.push(k));
    }
    w.length > 1 && b.push(w);
} return b; }, "connectedComponents"), C = f(I => { let b = []; for (let T of I)
    b.some(N => Math.abs(N - T.coord) < Z) || b.push(T.coord); for (; b.length < I.length;) {
    let T = Math.min(...b), N = Math.max(...b), F = I[0].side;
    b.push(F === "left" || F === "top" ? T - 12 * (I.length - b.length) : N + 12 * (I.length - b.length));
} return b; }, "uniqueCoordsFor"), M = f(I => { let b = I.map(F => F.coord), T = C(I), N = []; if (I.length <= 6) {
    let F = new Array(T.length).fill(!1), w = [], _ = f(() => { if (w.length === I.length) {
        w.some((k, B) => Math.abs(k - b[B]) >= Z) && N.push([...w]);
        return;
    } for (let [k, B] of T.entries())
        F[k] || (F[k] = !0, w.push(B), _(), w.pop(), F[k] = !1); }, "visit");
    return _(), N;
} for (let F = 0; F < b.length; F++)
    for (let w = F + 1; w < b.length; w++) {
        let _ = [...b];
        [_[F], _[w]] = [_[w], _[F]], N.push(_);
    } return N; }, "coordinateAssignmentsFor"), v = f((I, b) => { let T = new Map; for (let [F, w] of I.entries()) {
    let _ = b[F], k = T.get(w.edge) ?? w.points.map(B => ({ x: B.x, y: B.y }));
    w.axis === "vertical" ? (k[w.segmentIndex].x = _, k[w.segmentIndex + 1].x = _) : (k[w.segmentIndex].y = _, k[w.segmentIndex + 1].y = _), T.set(w.edge, k);
} let N = new Map; for (let [F, w] of T) {
    let _ = fe(pt(w));
    if (it(_).length !== _.length - 1)
        return;
    N.set(F, _);
} return N; }, "replacementsForAssignment"), R = f(I => { for (let [b, T] of I) {
    let N = [b.start, b.end].filter(F => !!F);
    for (let F of it(T))
        if (Rt(F.a, F.b, i, N, -2) || Rt(F.a, F.b, g, [], -2))
            return !1;
} for (let b = 0; b < l.length; b++) {
    let T = l[b], N = I.has(T), F = it(a(T, I));
    for (let w = b + 1; w < l.length; w++) {
        let _ = l[w];
        if (!N && !I.has(_))
            continue;
        let k = it(a(_, I));
        for (let B of F)
            for (let X of k)
                if (le(B, X, .5) >= _t)
                    return !1;
    }
} return !0; }, "candidateIsSafe"); for (let I = 0; I < 4; I++) {
    let b = u();
    if (b === 0)
        return;
    let T, N = b, F = y(), w = Number.POSITIVE_INFINITY;
    for (let _ of p(h()))
        for (let k of M(_)) {
            let B = v(_, k);
            if (!B || !R(B))
                continue;
            let X = u(B);
            if (X >= b)
                continue;
            let $ = y(B), K = _.reduce((ct, mt, Nt) => ct + Math.abs(k[Nt] - mt.coord), 0);
            X > N || X === N && ($ > F || $ === F && K >= w) || (T = B, N = X, F = $, w = K);
        }
    if (!T)
        return;
    for (let [_, k] of T)
        _.points = k;
} }
f(Is, "reassignCrossingExternalRailChannels");
function Ss(t, e) { let { realNodeRects: s, labelNodeRects: r } = xe(e.values()), i = t.filter(h => !h.isLayoutOnly), g = f((h, c, p) => pt(h === c ? p ?? [] : h.points ?? []), "pointsFor"), l = f(h => it(h).reduce((c, p) => { let C = p.a.x - p.b.x, M = p.a.y - p.b.y; return c + Math.hypot(C, M); }, 0), "pathLength"), a = f((h, c) => { let p = 0; for (let C = 0; C < i.length; C++) {
    let M = it(g(i[C], h, c));
    for (let v = C + 1; v < i.length; v++) {
        let R = it(g(i[v], h, c));
        for (let I of M)
            for (let b of R)
                de(I.a, I.b, b.a, b.b, Z) && p++;
    }
} return p; }, "strictCrossingCount"), u = f((h, c) => { if (h.horizontal) {
    let p = h.a.y;
    return (Math.abs(p - c.top) < 1 || Math.abs(p - c.bottom) < 1) && Vt(h.a.x, h.b.x, c.left, c.right) >= _t;
} if (h.vertical) {
    let p = h.a.x;
    return (Math.abs(p - c.left) < 1 || Math.abs(p - c.right) < 1) && Vt(h.a.y, h.b.y, c.top, c.bottom) >= _t;
} return !1; }, "segmentRunsAlongRectBorder"), y = f(h => { let c = [h.start, h.end].filter(C => !!C), p = []; for (let C of c) {
    let M = e.get(C), v = M ? Jt(M) : void 0;
    v && p.push(v);
} return p; }, "endpointRectsFor"), L = f((h, c) => { if (c + 3 >= h.length)
    return []; let p = h[c], C = h[c + 1], M = h[c + 2], v = h[c + 3], R = At(p, C, Z) && wt(C, M, Z) && At(M, v, Z), I = wt(p, C, Z) && At(C, M, Z) && wt(M, v, Z); if (!R && !I)
    return []; if (!(R ? Math.sign(C.x - p.x) !== Math.sign(v.x - M.x) : Math.sign(C.y - p.y) !== Math.sign(v.y - M.y)))
    return []; let T = dt(p, v, Z) || ht(p, v, Z) ? [] : [{ x: p.x, y: v.y }, { x: v.x, y: p.y }], N = T.length === 0 ? [[...h.slice(0, c + 1), ...h.slice(c + 3)]] : T.map(w => [...h.slice(0, c + 1), w, ...h.slice(c + 3)]), F = new Set; return N.map(w => fe(pt(w))).filter(w => { if (it(w).length !== w.length - 1 || !w.some(k => se(k, v, Z)))
    return !1; let _ = w.map(k => `${k.x.toFixed(3)},${k.y.toFixed(3)}`).join("|"); return F.has(_) ? !1 : (F.add(_), !0); }); }, "shortcutCandidatesAt"), m = f((h, c, p) => { let C = [h.start, h.end].filter(v => !!v), M = y(h); for (let v of it(c))
    if (Rt(v.a, v.b, s, C, -2) || Rt(v.a, v.b, r, [], -2) || M.some(R => u(v, R)))
        return !1; for (let v of i)
    if (v !== h) {
        for (let R of it(c))
            for (let I of it(g(v)))
                if (le(R, I, .5) >= _t)
                    return !1;
    } return a(h, c) <= p; }, "candidateIsSafe"); for (let h = 0; h < 8; h++) {
    let c = a(), p, C, M = c, v = Number.POSITIVE_INFINITY, R = Number.POSITIVE_INFINITY;
    for (let I of i) {
        let b = g(I), T = te(b, Z), N = l(b);
        for (let F = 0; F <= b.length - 4; F++)
            for (let w of L(b, F)) {
                let _ = te(w, Z), k = l(w);
                if (!(_ < T || _ === T && k < N - Z) || !m(I, w, c))
                    continue;
                let X = a(I, w);
                X > M || X === M && (_ > v || _ === v && k >= R) || (p = I, C = w, M = X, v = _, R = k);
            }
    }
    if (!p || !C)
        return;
    p.points = C;
} }
f(Ss, "shortcutRedundantOrthogonalJogs");
function Cs(t, e) { let i = []; for (let O of e.values()) {
    if (O.isGroup || O.isEdgeLabel)
        continue;
    let D = O.x ?? 0, H = O.y ?? 0, U = Jt(O);
    U && i.push({ id: String(O.id ?? ""), cx: D, cy: H, rect: U });
} if (i.length === 0)
    return; let g = new Map(i.map(O => [O.id, O])), l = i.map(O => ({ id: O.id, rect: O.rect })), a = ["top", "bottom", "left", "right"], u = { top: Math.min(...i.map(O => O.rect.top)) - 20, bottom: Math.max(...i.map(O => O.rect.bottom)) + 20, left: Math.min(...i.map(O => O.rect.left)) - 20, right: Math.max(...i.map(O => O.rect.right)) + 20 }, y = t.filter(O => !O.isLayoutOnly), L = new Map(y.map((O, D) => [O, D])), m = f(O => { let D = O === "left" || O === "top" ? -1 : 1, H = []; for (let U = 0; U <= 2; U++)
    H.push(u[O] + D * 20 * U); return H; }, "outwardTracksForSide"), h = f((O, D = new Map) => pt(D.get(O) ?? O.points ?? []), "replacementPointsFor"), c = f((O, D) => { let H = 0; for (let U of O)
    for (let d of D)
        de(U.a, U.b, d.a, d.b, Z) && H++; return H; }, "crossingCountBetweenSegments"), p = f((O, D) => c(it(O), it(D)), "crossingCountBetweenPaths"), C = f((O = new Map) => { let D = 0, H = [], U = new Set, d = [], x = f(S => { U.has(S) || (U.add(S), d.push(S)); }, "addEdge"); for (let S = 0; S < y.length; S++) {
    let E = y[S], A = h(E, O);
    for (let P = S + 1; P < y.length; P++) {
        let j = y[P], J = p(A, h(j, O));
        J > 0 && (D += J, H.push({ first: E, second: j, count: J }), x(E), x(j));
    }
} return d.sort((S, E) => (L.get(S) ?? 0) - (L.get(E) ?? 0)), { count: D, pairs: H, edgeSet: U, edges: d }; }, "crossingSnapshot"), M = f((O, D) => { let H = new Set(D.keys()); if (H.size === 0)
    return O.count; let U = 0; for (let x of O.pairs)
    (H.has(x.first) || H.has(x.second)) && (U += x.count); let d = 0; for (let x = 0; x < y.length; x++) {
    let S = y[x], E = H.has(S), A = h(S, D);
    for (let P = x + 1; P < y.length; P++) {
        let j = y[P];
        !E && !H.has(j) || (d += p(A, h(j, D)));
    }
} return O.count - U + d; }, "crossingCountWithReplacements"), v = f(O => { let D = new Map; for (let d of O.pairs) {
    let x = D.get(d.first) ?? new Set;
    x.add(d.second), D.set(d.first, x);
    let S = D.get(d.second) ?? new Set;
    S.add(d.first), D.set(d.second, S);
} let H = [], U = new Set; for (let d of O.edges) {
    if (U.has(d))
        continue;
    let x = [d], S = [];
    for (U.add(d); x.length > 0;) {
        let E = x.pop();
        S.push(E);
        for (let A of D.get(E) ?? [])
            U.has(A) || (U.add(A), x.push(A));
    }
    S.sort((E, A) => (L.get(E) ?? 0) - (L.get(A) ?? 0)), S.length > 1 && H.push(S);
} return H; }, "crossingComponents"), R = f(O => [O.start, O.end].filter(D => !!D), "endpointIdsFor"), I = f(O => { let D = []; for (let H of v(O)) {
    let U = new Set(H), d = new Set(H.flatMap(S => R(S))), x = [...H];
    for (let S of y)
        U.has(S) || R(S).some(E => d.has(E)) && x.push(S);
    x.sort((S, E) => (L.get(S) ?? 0) - (L.get(E) ?? 0)), D.push(x);
} return D; }, "pairSearchGroups"), b = f((O, D, H) => M(O, new Map([[D, H]])), "crossingCountWithSingleReplacement"), T = f(O => { let D = new Map; for (let H of O.pairs)
    D.set(H.first, (D.get(H.first) ?? 0) + H.count), D.set(H.second, (D.get(H.second) ?? 0) + H.count); return D; }, "currentCrossingsByEdge"), N = f(O => O.slice(1).reduce((D, H, U) => { let d = O[U]; return D + Math.abs(H.x - d.x) + Math.abs(H.y - d.y); }, 0), "pathLength"), F = f((O = new Map) => y.reduce((D, H) => D + te(h(H, O)), 0), "totalBends"), w = f((O = new Map) => y.reduce((D, H) => D + N(h(H, O)), 0), "totalLength"), _ = f((O, D, H = new Map) => { let U = it(D); for (let d of y)
    if (d !== O) {
        for (let x of U)
            for (let S of it(h(d, H)))
                if (le(x, S, .5) >= _t)
                    return !0;
    } return !1; }, "pathHasSegmentConflict"), k = f((O, D) => { let H = [O.start, O.end].filter(U => !!U); for (let U of it(D))
    if (Rt(U.a, U.b, l, H, -2))
        return !0; return !1; }, "pathHitsNode"), B = f((O, D) => { let H = fe(pt(D)); it(H).length === H.length - 1 && O.push(H); }, "pushOrthogonalCandidate"), X = f(O => O === "left" || O === "right", "sideIsHorizontal"), $ = f((O, D, H) => { switch (D) {
    case "left": return Math.min(O.x, H.x) - 20;
    case "right": return Math.max(O.x, H.x) + 20;
    case "top": return Math.min(O.y, H.y) - 20;
    case "bottom": return Math.max(O.y, H.y) + 20;
} }, "localTrackForSameSide"), K = f((O, D, H, U) => { let d = H === "left" || H === "top" ? -1 : 1, x = [$(D, H, U), u[H]]; for (let S of x)
    for (let E = 0; E <= 2; E++)
        B(O, lo(D, H, U, S + d * 20 * E)); }, "addSameSideCandidates"), ct = f((O, D, H, U, d) => { for (let x of m(H))
    for (let S of m(d))
        B(O, [D, { x, y: D.y }, { x, y: S }, { x: U.x, y: S }, U]); }, "addHorizontalToVerticalCandidates"), mt = f((O, D, H, U, d) => { for (let x of m(H))
    for (let S of m(d))
        B(O, [D, { x: D.x, y: x }, { x: S, y: x }, { x: S, y: U.y }, U]); }, "addVerticalToHorizontalCandidates"), Nt = f((O, D, H, U, d) => { let x = [...m("top"), ...m("bottom")]; for (let S of m(H))
    for (let E of m(d))
        for (let A of x)
            B(O, [D, { x: S, y: D.y }, { x: S, y: A }, { x: E, y: A }, { x: E, y: U.y }, U]); }, "addHorizontalPairCandidates"), Pt = f((O, D, H, U, d) => { let x = [...m("left"), ...m("right")]; for (let S of m(H))
    for (let E of m(d))
        for (let A of x)
            B(O, [D, { x: D.x, y: S }, { x: A, y: S }, { x: A, y: E }, { x: U.x, y: E }, U]); }, "addVerticalPairCandidates"), Q = f(O => { let D = new Set; return O.map(H => pt(H)).filter(H => { let U = H.map(d => `${d.x.toFixed(3)},${d.y.toFixed(3)}`).join("|"); return D.has(U) || H.length < 2 ? !1 : (D.add(U), !0); }); }, "dedupeCandidatePaths"), W = f((O, D, H, U) => { let d = [], x = ao(O, D, H, U, 20, Z); x && B(d, x), D === U && K(d, O, D, H); let S = X(D), E = X(U); return S && !E ? ct(d, O, D, H, U) : !S && E ? mt(d, O, D, H, U) : S ? Nt(d, O, D, H, U) : Pt(d, O, D, H, U), Q(d); }, "buildCandidatesForSides"), et = f((O, D, H, U) => { let d = [...m("left"), ...m("right")], x = [...m("top"), ...m("bottom")]; for (let S of a) {
    let E = Ce(U, S), A = S === "top" || S === "bottom" ? m(S) : x;
    for (let P of d) {
        B(O, [D, H, { x: P, y: H.y }, { x: P, y: E.y }, E]);
        for (let j of A)
            B(O, [D, H, { x: P, y: H.y }, { x: P, y: j }, { x: E.x, y: j }, E]);
    }
} }, "addVerticalDepartureOuterTrackCandidates"), lt = f((O, D, H, U) => { let d = [...m("left"), ...m("right")], x = [...m("top"), ...m("bottom")]; for (let S of a) {
    let E = Ce(U, S), A = S === "left" || S === "right" ? m(S) : d;
    for (let P of x) {
        B(O, [D, H, { x: H.x, y: P }, { x: E.x, y: P }, E]);
        for (let j of A)
            B(O, [D, H, { x: H.x, y: P }, { x: j, y: P }, { x: j, y: E.y }, E]);
    }
} }, "addHorizontalDepartureOuterTrackCandidates"), gt = f(O => { let D = O.start, H = O.end, U = H ? g.get(H) : void 0; if (!D || !U)
    return []; let d = pt(O.points ?? []); if (d.length < 4)
    return []; let x = d[0], S = d[1], E = []; return wt(x, S, Z) ? et(E, x, S, U) : At(x, S, Z) && lt(E, x, S, U), E; }, "terminalPreservingOuterTrackCandidates"), bt = f(O => { let D = O.start, H = O.end, U = D ? g.get(D) : void 0, d = H ? g.get(H) : void 0; if (!U || !d)
    return []; let x = []; for (let S of a) {
    let E = Ce(U, S);
    for (let A of a)
        x.push(...W(E, S, Ce(d, A), A));
} return x.push(...gt(O)), x; }, "candidatePathsFor"), Lt = f(() => new Map(y.map(O => [O, it(h(O))])), "currentSegmentsByEdge"), Ut = f((O, D, H) => { let U = new Set; for (let d of y) {
    if (d === O)
        continue;
    let x = H.get(d) ?? it(h(d));
    D.some(S => x.some(E => le(S, E, .5) >= _t)) && U.add(d);
} return U; }, "sharedTrackConflictsFor"), jt = f((O, D, H, U) => { let d = new Set; return bt(O).map(S => fe(pt(S))).filter(S => { if (k(O, S))
    return !1; let E = S.map(A => `${A.x.toFixed(3)},${A.y.toFixed(3)}`).join("|"); return d.has(E) || S.length < 2 ? !1 : (d.add(E), !0); }).map(S => { let E = it(S), A = 0; for (let P of y)
    P !== O && (A += c(E, H.get(P) ?? it(h(P)))); return { candidate: S, candidateSegments: E, crossings: D.count - (U.get(O) ?? 0) + A, bends: te(S, Z), totalBends: te(S), length: N(S) }; }).filter(({ crossings: S }) => S <= D.count).sort((S, E) => S.crossings - E.crossings || S.bends - E.bends || S.length - E.length).slice(0, 48).map(S => ({ path: S.candidate, segments: S.candidateSegments, sharedTrackConflicts: Ut(O, S.candidateSegments, H), totalBends: S.totalBends, length: S.length })); }, "pairCandidatesFor"), Wt = f((O, D, H, U, d, x) => { let S = 0; for (let A of O.pairs)
    (A.first === D || A.second === D || A.first === U || A.second === U) && (S += A.count); let E = c(H.segments, d.segments); for (let A of y) {
    if (A === D || A === U)
        continue;
    let P = x.get(A) ?? it(h(A));
    E += c(H.segments, P) + c(d.segments, P);
} return O.count - S + E; }, "pairCrossingCount"), ee = f((O, D) => { for (let H of O.sharedTrackConflicts)
    if (H !== D)
        return !1; return !0; }, "conflictsOnlyWith"), ve = f((O, D) => O.segments.some(H => D.segments.some(U => le(H, U, .5) >= _t)), "candidatesShareTrack"), he = f((O, D, H, U) => ee(D, H.edge) && ee(U, O.edge) && !ve(D, U), "pairCandidatesAreCompatible"), Le = f((O, D, H, U, d) => { let x = Wt(O.current, D.edge, H, U.edge, d, O.baseSegments); if (!(x >= O.current.count))
    return { replacements: new Map([[D.edge, H.path], [U.edge, d.path]]), crossings: x, bends: O.currentBends - (O.baseBendsByEdge.get(D.edge) ?? 0) - (O.baseBendsByEdge.get(U.edge) ?? 0) + H.totalBends + d.totalBends, length: O.currentLength - (O.baseLengthByEdge.get(D.edge) ?? 0) - (O.baseLengthByEdge.get(U.edge) ?? 0) + H.length + d.length }; }, "scorePairReplacement"), dn = f((O, D) => O.crossings < D.crossings || O.crossings === D.crossings && (O.bends < D.bends || O.bends === D.bends && O.length < D.length), "pairScoreIsBetter"), un = f((O, D, H, U) => { let d = U; for (let x of D.candidates)
    for (let S of H.candidates) {
        if (!he(D, x, H, S))
            continue;
        let E = Le(O, D, x, H, S);
        E && dn(E, d) && (d = E);
    } return d; }, "bestScoreForOptionPair"), hn = f(O => { let D = F(), H = w(), U = Lt(), d = T(O), x = new Map(y.map(J => [J, te(h(J))])), S = new Map(y.map(J => [J, N(h(J))])), E = new Map, A = I(O); for (let J of A)
    for (let V of J) {
        if (E.has(V))
            continue;
        let G = jt(V, O, U, d);
        G.length > 0 && E.set(V, { edge: V, candidates: G });
    } let P = { replacements: new Map, crossings: O.count, bends: D, length: H }, j = { current: O, currentBends: D, currentLength: H, baseBendsByEdge: x, baseLengthByEdge: S, baseSegments: U }; for (let J of A) {
    let V = new Set(J.filter(ot => O.edgeSet.has(ot))), G = J.map(ot => E.get(ot)).filter(ot => !!ot);
    for (let ot = 0; ot < G.length; ot++) {
        let rt = G[ot];
        for (let st = ot + 1; st < G.length; st++) {
            let tt = G[st];
            !V.has(rt.edge) && !V.has(tt.edge) || (P = un(j, rt, tt, P));
        }
    }
} return P.replacements.size > 0 ? P.replacements : void 0; }, "bestPairedReplacement"); for (let O = 0; O < 4; O++) {
    let D = C(), H = D.count;
    if (H === 0)
        return;
    let U, d, x = H, S = Number.POSITIVE_INFINITY;
    for (let A of D.edges) {
        let P = te(h(A), Z);
        for (let j of bt(A)) {
            let J = k(A, j), V = !J && _(A, j), G = b(D, A, j), ot = te(j, Z);
            J || V || !(G < H || G === H && ot < P) || G > x || G === x && ot >= S || (U = A, d = j, x = G, S = ot);
        }
    }
    if (U && d) {
        U.points = d;
        continue;
    }
    let E = hn(D);
    if (!E)
        return;
    for (let [A, P] of E)
        A.points = P;
} }
f(Cs, "resolveRenderedOrthogonalCrossings");
var ye = .001, Or = 8;
function vs(t, e) { let { nodeInfoById: n, realNodeRects: o } = an(e), s = ["top", "bottom", "left", "right"], r = 20, i = { top: Math.min(...o.map(c => c.rect.top)) - r, bottom: Math.max(...o.map(c => c.rect.bottom)) + r, left: Math.min(...o.map(c => c.rect.left)) - r, right: Math.max(...o.map(c => c.rect.right)) + r }, g = f((c, p, C, M) => { let v = [], R = ao(c, p, C, M, r, ye); return R && v.push(R), p === M && v.push(lo(c, p, C, i[p])), v; }, "buildOrthogonalPathCandidates"), l = f((c, p) => { for (let C = 0; C < c.length - 1; C++) {
    let M = c[C], v = c[C + 1];
    if (Rt(M, v, o, p, 1))
        return !0;
} return !1; }, "pathHitsNode"), a = f((c, p, C = !1) => { let M = 0, v = Oe(c, ye), R = p.start, I = p.end; for (let b of t) {
    if (b === p || b.isLayoutOnly)
        continue;
    let T = b.start, N = b.end;
    if (!C && R && I && (T === R || T === I || N === R || N === I))
        continue;
    let F = b.points;
    if (!(!F || F.length < 2))
        for (let w of v)
            for (let _ of Oe(F, ye)) {
                if (uo(w.a, w.b, _.a, _.b, ye, ye)) {
                    M++;
                    continue;
                }
                le(w, _, ye) >= Or && M++;
            }
} return M; }, "pathConflictCount"), u = 4, y = f((c, p) => { let C = Math.abs(c.y - p.rect.top), M = Math.abs(c.y - p.rect.bottom), v = Math.abs(c.x - p.rect.left), R = Math.abs(c.x - p.rect.right), I = "top", b = C; return M < b && (I = "bottom", b = M), v < b && (I = "left", b = v), R < b && (I = "right", b = R), I; }, "nearestSideOfRect"), L = new Map, m = f((c, p, C) => { let M = L.get(c) ?? []; M.push({ side: p, edgeId: C }), L.set(c, M); }, "addFaceClaim"); for (let c of t) {
    if (c.isLayoutOnly)
        continue;
    let p = c.points ?? [];
    if (p.length < 1)
        continue;
    let C = c.id ?? "", M = c.start, v = c.end;
    if (M) {
        let R = n.get(M);
        R && m(M, y(p[0], R), C);
    }
    if (v) {
        let R = n.get(v);
        R && m(v, y(p[p.length - 1], R), C);
    }
} let h = f((c, p, C) => L.get(c)?.some(M => M.edgeId !== C && M.side === p) ?? !1, "faceIsClaimed"); for (let c of t) {
    if (c.isLayoutOnly)
        continue;
    let p = c.points;
    if (!p || p.length < 2)
        continue;
    let C = te(p, ye);
    if (C < u)
        continue;
    let M = c.start, v = c.end;
    if (!M || !v)
        continue;
    let R = n.get(M), I = n.get(v);
    if (!R || !I)
        continue;
    let b = c.id ?? "", T = a(p, c, !0), N = a(p, c), F, w = T, _ = C;
    for (let k of s) {
        if (h(M, k, b))
            continue;
        let B = Ce(R, k);
        for (let X of s) {
            if (h(v, X, b))
                continue;
            let $ = Ce(I, X);
            for (let K of g(B, k, $, X)) {
                if (l(K, [M, v]))
                    continue;
                let ct = te(K, ye);
                if (T > 0) {
                    let mt = a(K, c, !0);
                    if (mt > w || mt === w && ct >= _)
                        continue;
                    w = mt, _ = ct, F = K;
                    continue;
                }
                a(K, c) > N || ct < _ && (_ = ct, F = K);
            }
        }
    }
    if (F) {
        c.points = F;
        let k = L.get(M);
        k && L.set(M, k.filter(X => X.edgeId !== b));
        let B = L.get(v);
        B && L.set(v, B.filter(X => X.edgeId !== b)), m(M, y(F[0], R), b), m(v, y(F[F.length - 1], I), b);
    }
} }
f(vs, "simplifyDetouredEdges");
var qt = .001, Fo = 10, Ue = 7;
function zn(t, e) { let n = e ? 0 : t.length - 1, o = e ? 1 : -1, s = t[n], r = t[n + o]; if (!s || !r)
    return; let i = r.x - s.x, g = r.y - s.y; if (!(Math.abs(i) + Math.abs(g) < qt)) {
    if (Math.abs(g) <= qt) {
        let a = s.x + Math.sign(i) * Fo;
        return { left: Math.min(s.x, a), right: Math.max(s.x, a), top: s.y - Ue, bottom: s.y + Ue };
    }
    if (Math.abs(i) <= qt) {
        let a = s.y + Math.sign(g) * Fo;
        return { left: s.x - Ue, right: s.x + Ue, top: Math.min(s.y, a), bottom: Math.max(s.y, a) };
    }
    return { left: Math.min(s.x, r.x), right: Math.max(s.x, r.x), top: Math.min(s.y, r.y), bottom: Math.max(s.y, r.y) };
} }
f(zn, "markerClearanceRectFor");
function Ls(t) { return { left: Math.min(t.left, t.right), right: Math.max(t.left, t.right), top: Math.min(t.top, t.bottom), bottom: Math.max(t.top, t.bottom) }; }
f(Ls, "normalizeRect");
function Vn(t, e) { let n = pt(e), o = zn(n, !0), s = zn(n, !1); return [o, s].some(r => r && Je(t, Ls(r))); }
f(Vn, "labelOverlapsOwnMarker");
function We(t, e) { let n = []; for (let h of t) {
    if (h.isLayoutOnly)
        continue;
    let c = h.points;
    if (!(!c || c.length < 2))
        for (let p = 0; p < c.length - 1; p++)
            n.push({ edgeId: h.id, p1: c[p], p2: c[p + 1] });
} let o = [], s = []; for (let h of e.values()) {
    let c = h.isGroup, p = h.parentId;
    if (c && !p) {
        let M = Jt(h);
        M && s.push({ id: h.id, rect: M });
        continue;
    }
    if (c || h.isEdgeLabel)
        continue;
    let C = Jt(h);
    C && o.push({ nodeId: h.id, rect: C });
} let r = 3, i = 1, g = 12, l = f((h, c) => { let p = An(c, r); for (let { nodeId: C, rect: M } of o)
    if (C !== h && Je(p, M))
        return !0; return !1; }, "labelOverlapsForeignNode"), a = f((h, c) => { let p = An(c, r); for (let C of n)
    if (C.edgeId !== h && cn(C.p1, C.p2, p))
        return !0; return !1; }, "labelOverlapsForeignEdge"), u = f((h, c, p) => l(h, p) || a(c, p), "labelOverlapsAnything"), y = [], L = f(h => { for (let { id: c, rect: p } of s)
    if (Qo(p, h))
        return c; }, "findContainingLane"), m = f((h, c) => y.some(p => p.labelId !== h && Je(c, p.rect)), "overlapsPlacedLabel"); for (let h of t) {
    if (h.isLayoutOnly)
        continue;
    let c = h.labelNodeId;
    if (!c)
        continue;
    let p = e.get(c);
    if (!p)
        continue;
    let C = h.points;
    if (!C || C.length < 2)
        continue;
    let M = p.width ?? 0, v = p.height ?? 0;
    if (M <= 0 || v <= 0)
        continue;
    let R = [];
    for (let Q = 0; Q < C.length - 1; Q++) {
        let W = C[Q], et = C[Q + 1], lt = Math.abs(W.x - et.x), gt = Math.abs(W.y - et.y);
        lt < qt && gt < qt || lt >= qt && gt >= qt || R.push({ idx: Q, length: lt + gt, orientation: lt >= qt ? "horizontal" : "vertical", midX: (W.x + et.x) / 2, midY: (W.y + et.y) / 2 });
    }
    if (R.length === 0)
        continue;
    let I = R.length >= 3 ? R.filter(Q => Q.idx > 0 && Q.idx < R.length - 1) : R, b = I.length > 0 ? I : R, T = M >= v ? "horizontal" : "vertical", N = f(Q => [...Q].sort((W, et) => { let lt = W.orientation === T, gt = et.orientation === T; if (lt !== gt)
        return lt ? -1 : 1; let bt = W.length >= (W.orientation === "horizontal" ? M : v) + 2, Lt = et.length >= (et.orientation === "horizontal" ? M : v) + 2; return bt !== Lt ? bt ? -1 : 1 : et.length - W.length; }), "rankSegments"), F = R[0], w = R[R.length - 1], _ = [.5, .25, .75, .05, .95, .15, .85, .1, .9], k = f((Q, W) => { let et = C[Q.idx], lt = C[Q.idx + 1]; return { midX: et.x + (lt.x - et.x) * W, midY: et.y + (lt.y - et.y) * W }; }, "anchorAtT"), B = f((Q, W, et) => Math.min(et, Math.max(W, Q)), "clamp"), X = f((Q, W) => Q.midX >= W.left - qt && Q.midX <= W.right + qt && Q.midY >= W.top - qt && Q.midY <= W.bottom + qt, "pointInsideRectInclusive"), $ = f(Q => { let W = Ne(Q.midX, Q.midY, M, v), et = L(W); if (et)
        return { laneId: et, anchor: Q, rect: W }; let lt = s.find(({ rect: ee }) => X(Q, ee)); if (!lt)
        return; let gt = lt.rect.left + M / 2 + i, bt = lt.rect.right - M / 2 - i, Lt = lt.rect.top + v / 2 + i, Ut = lt.rect.bottom - v / 2 - i; if (gt > bt || Lt > Ut)
        return; let jt = { midX: B(Q.midX, gt, bt), midY: B(Q.midY, Lt, Ut) }, Wt = Ne(jt.midX, jt.midY, M, v); return X(Q, Wt) ? { laneId: lt.id, anchor: jt, rect: Wt } : void 0; }, "placementForAnchor"), K = f((Q, W, et) => Q.orientation === "horizontal" ? Math.abs(W.midX - et.x) : Math.abs(W.midY - et.y), "distanceAlongSegment"), ct = f((Q, W) => { let lt = (Q.orientation === "horizontal" ? M / 2 : v / 2) + g; if (Q === F) {
        let gt = C[Q.idx];
        if (K(Q, W, gt) + qt < lt)
            return !1;
    } if (Q === w) {
        let gt = C[Q.idx + 1];
        if (K(Q, W, gt) + qt < lt)
            return !1;
    } return !0; }, "labelClearsTerminalEndpoints"), mt = f(Q => { let W = N(Q); for (let et of W)
        for (let lt of _) {
            let gt = k(et, lt);
            if (!ct(et, gt))
                continue;
            let bt = $(gt);
            if (bt && !Vn(bt.rect, C) && !m(c, bt.rect) && !u(c, h.id, bt.rect))
                return { laneId: bt.laneId, anchor: bt.anchor };
        } }, "tryPool"), Nt = f((Q, W, et = !1) => { let lt = N(Q); for (let gt of lt) {
        let bt = { midX: gt.midX, midY: gt.midY };
        if (W && !ct(gt, bt))
            continue;
        let Lt = $(bt);
        if (Lt && !Vn(Lt.rect, C) && !m(c, Lt.rect) && !l(c, Lt.rect) && (et || !a(h.id, Lt.rect)))
            return { laneId: Lt.laneId, anchor: Lt.anchor };
    } }, "findLaneContainingFallback"), Pt = mt(b) ?? (b.length < R.length ? mt(R) : void 0) ?? Nt(R, !0) ?? Nt(R, !1) ?? Nt(R, !1, !0);
    if (Pt) {
        p.x = Pt.anchor.midX, p.y = Pt.anchor.midY, p.parentId = Pt.laneId;
        let Q = Ne(Pt.anchor.midX, Pt.anchor.midY, M, v), W = y.findIndex(et => et.labelId === c);
        W >= 0 ? y[W] = { labelId: c, rect: Q } : y.push({ labelId: c, rect: Q });
    }
} }
f(We, "anchorLabelsToPolyline");
var Cn = 1e-6, Br = 8, Po = Br / 2, Fr = 3;
function Un(t, e) { return t < e ? `${t}::${e}` : `${e}::${t}`; }
f(Un, "pairKey");
function Es(t, e) { let { nodeInfoById: n, realNodeRects: o } = an(e), s = new Map; for (let i of e) {
    let g = i.id;
    if (!i.isGroup && i.isEdgeLabel) {
        s.set(g, { w: i.width ?? 0, h: i.height ?? 0 });
        continue;
    }
} let r = f((i, g, l, a) => { let u = Un(g, l), y = 0, L = f(m => { if (!m)
    return; let h = s.get(m); if (!h)
    return; let c = a === "x" ? h.w / 2 : h.h / 2; c > y && (y = c); }, "consider"); L(i.labelNodeId); for (let m of t) {
    if (m === i || m.isLayoutOnly)
        continue;
    let h = m.start, c = m.end;
    !h || !c || Un(h, c) === u && L(m.labelNodeId);
} return y > 0 ? y + Fr : 0; }, "labelClearanceFor"); for (let i of t) {
    if (i.isLayoutOnly)
        continue;
    let g = i.points;
    if (!io(g, Cn))
        continue;
    let l = fo(i, n, Cn);
    if (!l)
        continue;
    let { srcId: a, dstId: u, srcInfo: y, dstInfo: L, collinearX: m, collinearY: h } = l;
    if (m === h)
        continue;
    let c, p;
    if (m) {
        let I = L.cy > y.cy;
        c = { x: y.cx, y: I ? y.rect.bottom : y.rect.top }, p = { x: L.cx, y: I ? L.rect.top : L.rect.bottom };
    }
    else {
        let I = L.cx > y.cx;
        c = { x: I ? y.rect.right : y.rect.left, y: y.cy }, p = { x: I ? L.rect.left : L.rect.right, y: L.cy };
    }
    if (Rt(c, p, o, [a, u], 1))
        continue;
    let M = r(i, a, u, m ? "x" : "y"), v = M > Po ? M : Po, R = [0, v, -v];
    for (let I of R) {
        let b = xt({}, c), T = xt({}, p);
        if (m) {
            if (b.x += I, T.x += I, b.x <= y.rect.left || b.x >= y.rect.right || T.x <= L.rect.left || T.x >= L.rect.right)
                continue;
        }
        else if (b.y += I, T.y += I, b.y <= y.rect.top || b.y >= y.rect.bottom || T.y <= L.rect.top || T.y >= L.rect.bottom)
            continue;
        if (!Rt(b, T, o, [a, u], 1) && !Ze(b, T, t, i, { epsilon: Cn })) {
            i.points = [b, T];
            break;
        }
    }
} }
f(Es, "straightenCollinearSiblingDetours");
function jn(t, e) { let { realNodeRects: a, labelNodeRects: u } = xe(e.values()), y = f((b, T) => Oe(T, .001).map(N => ae(xt({}, N), { edge: b, interior: N.index >= 1 && N.index <= T.length - 3 })), "segmentsFor"), L = f(() => { let b = []; for (let T of t) {
    if (T.isLayoutOnly)
        continue;
    let N = T.points;
    !N || N.length < 2 || b.push(...y(T, pt(N)));
} return b; }, "allSegments"), m = f((b, T) => b.horizontal && T.horizontal ? Vt(b.a.x, b.b.x, T.a.x, T.b.x) >= 8 && Math.abs(b.a.y - T.a.y) < 7 : b.vertical && T.vertical ? Vt(b.a.y, b.b.y, T.a.y, T.b.y) >= 8 && Math.abs(b.a.x - T.a.x) < 7 : !1, "hasCrowdedParallelTrack"), h = f((b, T) => { let N = b.start, F = b.end, w = y(b, T); if (w.length !== T.length - 1)
    return !1; let _ = [N, F].filter(B => !!B), k = b.labelNodeId ? [b.labelNodeId] : []; for (let B of w)
    if (Rt(B.a, B.b, a, _, -2) || Rt(B.a, B.b, u, k, -2))
        return !1; for (let B of t) {
    if (B === b || B.isLayoutOnly)
        continue;
    let X = B.points;
    if (!(!X || X.length < 2)) {
        for (let $ of w)
            for (let K of y(B, pt(X)))
                if (m($, K) || de($.a, $.b, K.a, K.b, .001))
                    return !1;
    }
} return !0; }, "candidateIsSafe"), c = f((b, T) => { let N = pt(b.edge.points ?? []); if (N.length < 4 || b.index >= N.length - 1)
    return; let F = N.map(w => xt({}, w)); if (b.horizontal)
    F[b.index].y += T, F[b.index + 1].y += T;
else if (b.vertical)
    F[b.index].x += T, F[b.index + 1].x += T;
else
    return; return y(b.edge, F).length === F.length - 1 ? F : void 0; }, "shiftedCandidate"), p = f((b, T) => ({ x: b.x ?? (T.left + T.right) / 2, y: b.y ?? (T.top + T.bottom) / 2 }), "nodeCenter"), C = f(b => { let T = b.edge, N = pt(T.points ?? []); if (N.length !== 4 || b.index !== 1)
    return; let F = T.start ? e.get(T.start) : void 0, w = T.end ? e.get(T.end) : void 0, _ = F ? Jt(F) : void 0, k = w ? Jt(w) : void 0, B = N.slice(b.index + 2); if (!(!F || !w || !_ || !k || B.length === 0))
    return { sourceCenter: p(F, _), targetCenter: p(w, k), sourceRect: _, tail: B }; }, "sourceDetourContextFor"), M = f((b, T, N, F, w, _) => { let k = F.y >= N.y, B = k ? w.bottom : w.top, X = B + (k ? 20 : -20); if (k && b.b.y <= X + .001 || !k && b.b.y >= X - .001)
    return; let $ = b.a.x + T; return pt([{ x: N.x, y: B }, { x: N.x, y: X }, { x: $, y: X }, { x: $, y: b.b.y }, ..._], .001); }, "verticalSourceDetour"), v = f((b, T, N, F, w, _) => { let k = F.x >= N.x, B = k ? w.right : w.left, X = B + (k ? 20 : -20); if (k && b.b.x <= X + .001 || !k && b.b.x >= X - .001)
    return; let $ = b.a.y + T; return pt([{ x: B, y: N.y }, { x: X, y: N.y }, { x: X, y: $ }, { x: b.b.x, y: $ }, ..._], .001); }, "horizontalSourceDetour"), R = f((b, T) => { let N = C(b); if (N) {
    if (b.vertical)
        return M(b, T, N.sourceCenter, N.targetCenter, N.sourceRect, N.tail);
    if (b.horizontal)
        return v(b, T, N.sourceCenter, N.targetCenter, N.sourceRect, N.tail);
} }, "sourceDetourCandidate"), I = [-7, 7, -14, 14, -21, 21]; for (let b = 0; b < 12; b++) {
    let T = L(), N = !1;
    for (let F = 0; F < T.length && !N; F++)
        for (let w = F + 1; w < T.length && !N; w++) {
            let _ = T[F], k = T[w];
            if (_.edge === k.edge || !m(_, k))
                continue;
            let B = [_, k].filter(X => X.interior);
            for (let X of B) {
                for (let $ of I) {
                    let K = c(X, $);
                    if (K && h(X.edge, K)) {
                        X.edge.points = K, N = !0;
                        break;
                    }
                    let ct = R(X, $);
                    if (ct && h(X.edge, ct)) {
                        X.edge.points = ct, N = !0;
                        break;
                    }
                }
                if (N)
                    break;
            }
        }
    if (!N)
        return;
} }
f(jn, "nudgeSharedInteriorSubpaths");
function Ts(t, e, n, o) { let s = e.x - t.x, r = e.y - t.y, i = o.x - n.x, g = o.y - n.y, l = s * g - r * i; if (Math.abs(l) < 1e-10)
    return !1; let a = n.x - t.x, u = n.y - t.y, y = (a * g - u * i) / l, L = (a * r - u * s) / l, m = .01; return y > m && y < 1 - m && L > m && L < 1 - m; }
f(Ts, "segmentsIntersect");
function As(t) { let e = t.nodes ?? [], n = t.edges ?? [], o = []; if (!n.length || !e.length)
    return o; let s = ts(e), r = 1, i = []; for (let l of n) {
    if (l.isLayoutOnly)
        continue;
    let a = l.points;
    if (!a || a.length < 2)
        continue;
    let u = l.start, y = l.end, L = l.labelNodeId, m = l.id ?? `${u}->${y}`;
    for (let h of s)
        if (!(h.nodeId === u || h.nodeId === y) && !(L && h.nodeId === L)) {
            for (let c = 0; c < a.length - 1; c++)
                if (cn(a[c], a[c + 1], h, -r)) {
                    o.push({ type: "edge-node-overlap", edgeId: m, targetId: h.nodeId, detail: `segment ${c} passes through node "${h.nodeId}"` });
                    break;
                }
        }
    for (let h = 0; h < a.length - 1; h++)
        i.push({ edgeId: m, start: u, end: y, p1: a[h], p2: a[h + 1] });
} let g = new Set; for (let l = 0; l < i.length; l++)
    for (let a = l + 1; a < i.length; a++) {
        let u = i[l], y = i[a];
        if (u.edgeId !== y.edgeId && !(u.start === y.start || u.start === y.end || u.end === y.start || u.end === y.end) && Ts(u.p1, u.p2, y.p1, y.p2)) {
            let L = u.edgeId < y.edgeId ? `${u.edgeId}|${y.edgeId}` : `${y.edgeId}|${u.edgeId}`;
            g.has(L) || (g.add(L), o.push({ type: "edge-edge-crossing", edgeId: u.edgeId, targetId: y.edgeId, detail: `edges "${u.edgeId}" and "${y.edgeId}" cross` }));
        }
    } if (o.length > 0) {
    let l = o.filter(u => u.type === "edge-node-overlap").length, a = o.filter(u => u.type === "edge-edge-crossing").length;
    Ge.warn(`[SWIMLANE_VALIDATE] ${o.length} issue(s) detected: ${l} edge-node overlap(s), ${a} edge crossing(s)`);
    for (let u of o)
        Ge.warn(`[SWIMLANE_VALIDATE]   ${u.type}: ${u.detail}`);
} return o; }
f(As, "validateSwimlanesLayout");
function ws(t, e) { let n = t.nodes ?? [], o = t.edges ?? [], s = n.filter(g => !g.isGroup); if ((e === "LR" || e === "RL") && s.length > 0 && !ps(t, e) || e === "BT" && s.length > 0 && !gs(t))
    return; for (let g of o) {
    if (g.isLayoutOnly)
        continue;
    let l = g.points;
    !l || l.length < 2 || (g.points = fe(Qe(l)));
} vs(o, n), Es(o, n), ms(o, n); let r = new Map; for (let g of n)
    r.set(String(g.id), g); We(o, r), rs(o, r), ys(o, r), jn(o, r), xs(o, r), bs(o, r), Yn(o, r), Ms(o, r); let i = f(() => { Cs(o, r), Is(o, r), Ss(o, r), We(o, r), Hn(o, r), Yn(o, r), We(o, r), Hn(o, r); }, "finalizeRenderedEdges"); i(), jn(o, r), i(), Gn(o, r), $n(o, r), Gn(o, r), $n(o, r); }
f(ws, "postProcessSwimlaneLayout");
function be(t) { let e = new Map(t.nodeById), n = new Set, o = []; for (let r of t.edges) {
    if (!e.has(r.src) || !e.has(r.dst))
        continue;
    let i = `${r.id}:${r.src}->${r.dst}`;
    n.has(i) || (n.add(i), o.push(r));
} return { nodes: [...e.keys()], edges: o, layout: t.layout, nodeById: e }; }
f(be, "normalizeGraph");
function yo(t, e) { return t.edges.filter(n => n.dst === e); }
f(yo, "incoming");
function Rs(t) { let e = new Map; for (let n of t.nodes)
    e.set(n, []); for (let n of t.edges)
    e.get(n.src).push(n.dst); return e; }
f(Rs, "buildSuccessorMap");
function xo(t) { let e = Rs(t); for (let n of e.values())
    n.sort((o, s) => o.localeCompare(s)); return e; }
f(xo, "buildSortedSuccessorMap");
function bo(t) { let e = new Map; for (let n of t.nodes)
    e.set(n, 0); for (let n of t.edges)
    e.set(n.dst, (e.get(n.dst) ?? 0) + 1); return e; }
f(bo, "buildInDegreeMap");
function Mo(t) { return [...t.entries()].filter(([, e]) => e === 0).map(([e]) => e).sort((e, n) => e.localeCompare(n)); }
f(Mo, "sortedZeroInDegreeNodes");
function ln(t, e = () => !0) { let n = new Map, o = new Map; for (let s of t.nodes)
    n.set(s, []), o.set(s, []); for (let s of t.edges)
    e(s) && (o.get(s.src).push(s.dst), n.get(s.dst).push(s.src)); return { preds: n, succs: o }; }
f(ln, "buildPredecessorSuccessorMaps");
function Io(t, e, n, o) { let s = 0; for (let i of t.nodes)
    o?.skipGroups && t.nodeById.get(i)?.isGroup || (s = Math.max(s, n[i] ?? 0)); let r = Array.from({ length: s + 1 }, () => []); for (let i of e)
    o?.skipGroups && t.nodeById.get(i)?.isGroup || r[Math.max(0, n[i] ?? 0)].push(i); return r; }
f(Io, "buildLayersFromRanks");
function Pe(t) { let e = bo(t), n = Mo(e), o = [], s = xo(t); for (; n.length;) {
    let r = n.shift();
    o.push(r);
    for (let i of s.get(r) ?? [])
        if (e.set(i, (e.get(i) ?? 0) - 1), (e.get(i) ?? 0) === 0) {
            let g = 0;
            for (; g < n.length && n[g] < i;)
                g++;
            n.splice(g, 0, i);
        }
} return o.length === t.nodes.length ? o : null; }
f(Pe, "topoSortIfAcyclic");
function Be(t) { let e = new Map, n = 0; for (let o of t)
    e.set(o, n), n++; return e; }
f(Be, "buildLayerIndex");
function So(t) { let e = new Array(t.length), n = f((o, s) => { if (s - o <= 1)
    return 0; let r = o + s >> 1, i = n(o, r) + n(r, s), g = o, l = r, a = o; for (; g < r || l < s;)
    l >= s || g < r && t[g] <= t[l] ? e[a++] = t[g++] : (e[a++] = t[l++], i += r - g); for (let u = o; u < s; u++)
    t[u] = e[u]; return i; }, "count"); return n(0, t.length); }
f(So, "countInversions");
function Ns(t) { let e = be(t), n = new Map; for (let u of e.nodes)
    n.set(u, []); for (let u of e.edges)
    n.get(u.src).push(u); for (let u of n.values())
    u.sort((y, L) => y.dst === L.dst ? y.id.localeCompare(L.id) : y.dst.localeCompare(L.dst)); let o = Object.create(null); for (let u of e.nodes)
    o[u] = 0; let s = [], r = f(u => { o[u] = 1; for (let y of n.get(u) ?? []) {
    let L = y.dst;
    o[L] === 0 ? r(L) : o[L] === 1 && s.push(y);
} o[u] = 2; }, "dfs"), i = [...e.nodes].sort((u, y) => u.localeCompare(y)); for (let u of i)
    o[u] === 0 && r(u); let g = new Set(s.map(u => `${u.id}:${u.src}->${u.dst}`)), l = e.edges.map(u => g.has(`${u.id}:${u.src}->${u.dst}`) ? { id: u.id, src: u.dst, dst: u.src, weight: u.weight, ref: u.ref } : u); return { acyclic: { nodes: [...e.nodes], edges: l, layout: e.layout, nodeById: new Map(e.nodeById) }, reversed: s }; }
f(Ns, "removeCycles_DFS");
function Os(t) { let e = new Map, n = f(o => { if (e.has(o))
    return e.get(o); let s = t.nodeById.get(o); if (!s)
    return e.set(o, null), null; let r = s.parentId; if (!r)
    return e.set(o, null), null; let g = n(r) ?? r; return e.set(o, g), g; }, "resolve"); for (let o of t.nodes)
    n(o); return e; }
f(Os, "buildTopLaneMap");
function ue(t) { let e = Os(t); return n => e.get(n) ?? null; }
f(ue, "createTopLaneResolver");
function fn(t) { let e = []; for (let n of t.layout.nodes ?? [])
    n.isGroup && !n.parentId && e.push(n.id); return [...new Set(e)].reverse(); }
f(fn, "buildTopLaneOrder");
function Co(t, e) { let n = fn(t); if (!e || e.length === 0)
    return n; let o = new Set(n), s = new Set, r = []; for (let i of e)
    !o.has(i) || s.has(i) || (s.add(i), r.push(i)); for (let i of n)
    s.has(i) || r.push(i); return r; }
f(Co, "resolveTopLaneOrder");
var Pr = { EPSILON: 1e-6 }, sn = { GRAVITY_ITERATIONS: 8, MAX_CROSSING_OPTIMIZATION_PASSES: 4, DEFAULT_COMPACT_SINGLE_INPUT: !0 }, ko = { DEFAULT_LAYER_GAP: 100, DEFAULT_NODE_GAP: 40 };
function Bs(t, e) { let n = be(t), o = e?.laneOf ?? (() => null), s = e?.rankHint, { preds: r } = ln(n); for (let I of r.values())
    I.sort((b, T) => b.localeCompare(T)); let i = Pe(n) ?? [...n.nodes].sort((I, b) => I.localeCompare(b)), g = new Map; for (let [I, b] of i.entries())
    g.set(b, I); let l = new Map, a = new Map; for (let I of n.nodes)
    a.set(I, []); for (let I of i) {
    let b = (r.get(I) ?? []).filter(T => l.has(T));
    if (b.length > 0) {
        let T = Fs(I, b, { laneOf: o, rankHint: s, topoIndex: g });
        l.set(I, T), a.get(T).push(I);
    }
    else
        l.has(I) || l.set(I, null);
} for (let I of n.nodes)
    l.has(I) || l.set(I, null); let u = new Set; for (let I of n.nodes)
    (l.get(I) ?? null) === null && u.add(I); let y = [...u].sort((I, b) => { let T = g.get(I) ?? 0, N = g.get(b) ?? 0; return T === N ? I.localeCompare(b) : T - N; }), L = Ps(n), m = new Map; for (let [I, b] of L.entries())
    m.set(I, [...b].sort((T, N) => T.localeCompare(N))); let h = ks(m), c = _s(m), p = new Map; for (let I of n.nodes)
    p.set(I, []); for (let I of c)
    for (let b of I.nodes) {
        let T = p.get(b);
        T ? T.push(I.id) : p.set(b, [I.id]);
    } let C = [], M = [], v = new Set, R = f(I => { if (!v.has(I)) {
    v.add(I), C.push(I);
    for (let b of a.get(I) ?? [])
        R(b);
    M.push(I);
} }, "walk"); for (let I of y)
    R(I); for (let I of i)
    R(I); return { parent: l, children: a, roots: y, componentOf: h, blocks: c, nodeBlocks: p, adjacency: m, preorder: C, postorder: M, topologicalOrder: i }; }
f(Bs, "buildDrivingTree");
function Fs(t, e, n) { let o = n.laneOf(t); return [...e].sort((r, i) => { let g = n.laneOf(r), l = n.laneOf(i), a = g != null && g === o, u = l != null && l === o; if (a !== u)
    return a ? -1 : 1; let y = n.rankHint?.[r], L = n.rankHint?.[i]; if (y != null && L != null && y !== L)
    return L - y; let m = n.topoIndex.get(r) ?? 0, h = n.topoIndex.get(i) ?? 0; return m !== h ? m - h : r.localeCompare(i); })[0]; }
f(Fs, "chooseParent");
function Ps(t) { let e = new Map; for (let n of t.nodes)
    e.set(n, new Set); for (let n of t.edges)
    e.get(n.src).add(n.dst), e.get(n.dst).add(n.src); return e; }
f(Ps, "buildAdjacency");
function ks(t) { let e = new Map, n = 0; for (let o of t.keys()) {
    if (e.has(o))
        continue;
    let s = [o];
    for (; s.length > 0;) {
        let r = s.pop();
        if (!e.has(r)) {
            e.set(r, n);
            for (let i of t.get(r) ?? [])
                e.has(i) || s.push(i);
        }
    }
    n++;
} return e; }
f(ks, "assignComponents");
function _s(t) { let e = new Map, n = new Map, o = [], s = [], r = 0, i = f((g, l) => { e.set(g, ++r), n.set(g, r); for (let a of t.get(g) ?? [])
    a !== l && (e.has(a) ? (e.get(a) ?? 0) < (e.get(g) ?? 0) && (o.push([g, a]), n.set(g, Math.min(n.get(g) ?? r, e.get(a) ?? r))) : (o.push([g, a]), i(a, g), n.set(g, Math.min(n.get(g) ?? r, n.get(a) ?? r)), (n.get(a) ?? 0) >= (e.get(g) ?? 0) && s.push(Ds(g, a, o, s.length)))); }, "visit"); for (let g of t.keys())
    e.has(g) || i(g, null); return s; }
f(_s, "computeBlocks");
function Ds(t, e, n, o) { let s = [], r = new Set; for (; n.length > 0;) {
    let i = n.pop();
    if (s.push(i), r.add(i[0]), r.add(i[1]), i[0] === t && i[1] === e || i[0] === e && i[1] === t)
        break;
} return { id: o, edges: s, nodes: [...r] }; }
f(Ds, "popBlock");
function Hs(t, e, n) { let o = [...t.nodes], s = new Map; for (let [M, v] of o.entries())
    s.set(v, M); let r = o.length, i = new Array(r).fill(-1), g = new Array(r).fill(0), l = [], a = new Set; for (let M of o) {
    let v = n.parent.get(M) ?? null, R = s.get(M);
    R != null && v == null && (i[R] = -1, g[R] = 0, a.has(M) || (a.add(M), l.push(M)));
} for (; l.length > 0;) {
    let M = l.shift(), v = s.get(M);
    if (v == null)
        continue;
    let R = n.children.get(M) ?? [];
    for (let I of R) {
        if (a.has(I))
            continue;
        let b = s.get(I);
        b != null && (i[b] = v, g[b] = g[v] + 1, a.add(I), l.push(I));
    }
} for (let M of o) {
    if (a.has(M))
        continue;
    let v = s.get(M);
    v != null && (i[v] = -1, g[v] = 0, a.add(M));
} let u = Math.max(1, Math.ceil(Math.log2(Math.max(1, r))) + 1), y = Array.from({ length: u }, () => new Array(r).fill(-1)); for (let M = 0; M < r; M++)
    y[0][M] = i[M]; for (let M = 1; M < u; M++)
    for (let v = 0; v < r; v++) {
        let R = y[M - 1][v];
        y[M][v] = R === -1 ? -1 : y[M - 1][R];
    } let L = f((M, v) => { if (M === -1 || v === -1)
    return -1; g[M] < g[v] && ([M, v] = [v, M]); let R = g[M] - g[v]; for (let I = 0; I < u; I++)
    if (R >> I & 1 && (M = y[I][M], M === -1))
        return -1; if (M === v)
    return M; for (let I = u - 1; I >= 0; I--) {
    let b = y[I][M], T = y[I][v];
    b === -1 || T === -1 || b !== T && (M = b, v = T);
} return y[0][M]; }, "lcaIndex"), m = Array.from({ length: r }, () => new Map); for (let M of t.edges) {
    let v = M.src, R = M.dst, I = e[v], b = e[R];
    if (I == null || b == null || (I > b && ([v, R] = [R, v], [I, b] = [b, I]), I == null || b == null || I === b))
        continue;
    let T = s.get(v), N = s.get(R);
    if (T == null || N == null)
        continue;
    let F = L(T, N);
    if (F === -1)
        continue;
    let w = m[F];
    for (let _ = I; _ < b; _++)
        w.set(_, (w.get(_) ?? 0) + 1);
} let h = new Map, c = f((M, v) => { if (v.size !== 0)
    for (let [R, I] of v)
        M.set(R, (M.get(R) ?? 0) + I); }, "mergeInto"), p = new Set, C = f(M => { let v = s.get(M); p.add(M); let R = v == null ? void 0 : m[v], I = R ? new Map(R) : new Map, b = n.children.get(M) ?? []; for (let T of b) {
    let N = C(T), F = e[M];
    if (F != null) {
        let w = h.get(M);
        w || (w = new Map, h.set(M, w));
        let _ = N.get(F) ?? 0, k = e[T];
        k != null && k > F && (_ += 1), w.set(T, _);
    }
    c(I, N);
} return I; }, "dfs"); for (let M of n.roots)
    p.has(M) || C(M); for (let M of o)
    p.has(M) || C(M); return h; }
f(Hs, "computeSubtreeCrossCounts");
function Xs(t, e, n) { let o = new Map, s = f(r => { let i = n[r] ?? 0, g = [...e.get(r) ?? []]; g.sort(vo(n)); for (let l of g) {
    s(l);
    let a = o.get(l);
    a != null && (i = Math.min(i, a));
} o.set(r, i); }, "annotate"); for (let r of t)
    s(r); return o; }
f(Xs, "annotateMinimumLayers");
function vo(t) { return (e, n) => { let o = t[e] ?? 0, s = t[n] ?? 0; return o === s ? e.localeCompare(n) : o - s; }; }
f(vo, "compareByRankThenId");
function Ys(t, e, n, o) { let s = 0; for (let l of e) {
    let a = n[l] ?? 0;
    a > s && (s = a);
} let r = Array.from({ length: s + 1 }, () => []), i = new Set, g = f(l => { if (i.has(l))
    return; i.add(l); let a = n[l] ?? 0; r[a] || (r[a] = []), r[a].push(l); for (let u of o(l))
    g(u); }, "emit"); for (let l of t)
    g(l); for (let l of e)
    if (!i.has(l)) {
        let a = n[l] ?? 0;
        r[a] || (r[a] = []), r[a].push(l), i.add(l);
    } return r; }
f(Ys, "emitNodesInTreeOrder");
function Gs(t) { let e = []; for (let n of t) {
    let o = new Set, s = [];
    for (let r of n)
        o.has(r) || (o.add(r), s.push(r));
    e.push(s);
} return e; }
f(Gs, "deduplicateLayers");
function $s(t, e, n, o) { return s => { let r = t.get(s) ?? []; if (r.length === 0)
    return []; let i = e[s] ?? 0, g = [], l = [], a = n.get(s); for (let u of r) {
    let y = o.get(u) ?? i;
    y > i ? g.push({ child: u, min: y }) : l.push(u);
} return g.sort((u, y) => u.min === y.min ? u.child.localeCompare(y.child) : u.min - y.min), l.sort((u, y) => { let L = a?.get(u) ?? 0, m = a?.get(y) ?? 0; if (L !== m)
    return L - m; let h = o.get(u) ?? i, c = o.get(y) ?? i; return h !== c ? h - c : u.localeCompare(y); }), [...g.map(u => u.child), ...l]; }; }
f($s, "createChildOrderer");
function rn(t, e, n) { let o = Bs(t, { rankHint: e, laneOf: n }), { children: s, roots: r } = o; for (let y of t.nodes)
    s.has(y) || s.set(y, []); let i = Hs(t, e, o), g = [...r].sort(vo(e)), l = Xs(g, s, e), a = $s(s, e, i, l), u = Ys(g, t.nodes, e, a); return u = Gs(u), u; }
f(rn, "buildMultitreeLayerOrder");
function zs(t, e, n) { let o = new Set(t), s = new Set(e), r = Be(e), i = []; for (let g of n)
    o.has(g.src) && s.has(g.dst) && i.push(r.get(g.dst)); return So(i); }
f(zs, "countCrossingsBetweenAdjacent");
function Wn(t, e, n) { let o = []; for (let r of e) {
    let i = n[r.src], g = n[r.dst];
    if (i == null || g == null || i === g)
        continue;
    let l = r.src, a = r.dst, u = i, y = g;
    i > g && (l = r.dst, a = r.src, u = g, y = i);
    for (let L = u; L < y; L++)
        o.push({ id: `${r.id}@${L}`, src: l, dst: a, ref: r.ref });
} let s = 0; for (let r = 0; r + 1 < t.length; r++)
    s += zs(t[r], t[r + 1], o); return s; }
f(Wn, "totalCrossings");
function Vs(t, e) { let n = xt({}, e), { preds: o } = ln(t), s = ue(t), r = rn(t, n, s), i = Wn(r, t.edges, n), g = sn.MAX_CROSSING_OPTIMIZATION_PASSES; for (let l = 0; l < g; l++) {
    let a = !1, u = [...t.nodes].sort((y, L) => (n[L] ?? 0) - (n[y] ?? 0));
    for (let y of u) {
        let L = n[y] ?? 0;
        if (L === 0)
            continue;
        let m = 0;
        for (let C of o.get(y) ?? [])
            m = Math.max(m, (n[C] ?? 0) + 1);
        if (m >= L)
            continue;
        let h = L;
        n[y] = m;
        let c = rn(t, n, s), p = Wn(c, t.edges, n);
        p < i ? (i = p, a = !0) : n[y] = h;
    }
    if (!a)
        break;
} return n; }
f(Vs, "optimizeRanksByCrossings");
function Us(t, e) { let n = ue(t), o = [...t.nodes].sort((s, r) => (e[s] ?? 0) - (e[r] ?? 0) || s.localeCompare(r)); for (let s of o) {
    let r = n(s);
    if (!r)
        continue;
    let i = t.edges.filter(c => c.src === s);
    if (i.length === 0)
        continue;
    let g = !1, l = 0;
    for (let c of i) {
        let p = n(c.dst);
        p == null || p === r ? g = !0 : l++;
    }
    if (l === 0 || g)
        continue;
    let a = 0, u = !1;
    for (let c of t.edges) {
        if (c.dst !== s)
            continue;
        let p = n(c.src);
        p && (p === r ? u = !0 : a++);
    }
    if (a > 0 || !u)
        continue;
    let y = e[s] ?? 0, L = y + l, m = 0;
    for (let c of t.edges)
        c.dst === s && (m = Math.max(m, (e[c.src] ?? 0) + 1));
    let h = Math.max(y, m, L);
    h !== y && (e[s] = h);
} }
f(Us, "adjustCrossLaneSources");
function js(t, e) { let n = be(t), o = Pe(n) ?? [...n.nodes].sort(), s = e?.compactSingleInput ?? !1, r = ue(n), i = Object.create(null); for (let l of o) {
    let a = yo(n, l), u = e?.ignoreCrossLaneEdges ? a.filter(y => { let L = r(y.src), m = r(l); return !L || !m ? !0 : L === m; }) : a;
    if (u.length === 0)
        i[l] = 0;
    else if (s && u.length === 1) {
        let y = u[0].src, L = r(y), m = r(l);
        L !== m ? i[l] = i[y] ?? 0 : i[l] = (i[y] ?? 0) + 1;
    }
    else {
        let y = -1 / 0;
        for (let L of u)
            y = Math.max(y, (i[L.src] ?? 0) + 1);
        i[l] = y === -1 / 0 ? 0 : y;
    }
} return (e?.optimizeRanksByCrossings ?? !1) && (i = Vs(n, i)), e?.ignoreCrossLaneEdges && Us(n, i), { layers: rn(n, i, r), rankOf: i, dummy: new Set }; }
f(js, "assignLayers_LongestPath");
function Ws(t, e) { let n = be(t), o = js(n, { compactSingleInput: e?.compactSingleInput, ignoreCrossLaneEdges: e?.ignoreCrossLaneEdges, optimizeRanksByCrossings: e?.optimizeRanksByCrossings }), s = xt({}, o.rankOf), r = ue(n), { preds: i, succs: g } = ln(n, h => { if (e?.ignoreCrossLaneEdges) {
    let c = r(h.src), p = r(h.dst);
    if (c && p && c !== p)
        return !1;
} return !0; }), l = Pe(n) ?? [...n.nodes], a = [...l].reverse(), u = f((h, c) => { let p = 0; for (let v of i.get(h) ?? [])
    p = Math.max(p, (s[v] ?? 0) + 1); let C = Number.POSITIVE_INFINITY, M = g.get(h) ?? []; return M.length > 0 && (C = Math.min(...M.map(v => (s[v] ?? 0) - 1))), Number.isFinite(C) || (C = Math.max(p, c)), Math.min(Math.max(c, p), C); }, "clampFeasible"), y = sn.GRAVITY_ITERATIONS, L = f(h => { let c = !1; for (let p of h) {
    let C = i.get(p) ?? [], M = g.get(p) ?? [];
    if (C.length === 0 && M.length === 0)
        continue;
    let v = C.length > 0 ? C.reduce((T, N) => T + (s[N] ?? 0) + 1, 0) / C.length : s[p] ?? 0, R = M.length > 0 ? M.reduce((T, N) => T + (s[N] ?? 0) - 1, 0) / M.length : s[p] ?? 0, I = Math.round((v + R) / 2), b = u(p, I);
    b !== s[p] && (s[p] = b, c = !0);
} return c; }, "relaxOrder"); for (let h = 0; h < y; h++) {
    let c = L(l), p = L(a);
    if (!c && !p)
        break;
} for (let h of l) {
    let c = 0;
    for (let p of i.get(h) ?? [])
        c = Math.max(c, (s[p] ?? 0) + 1);
    (s[h] ?? 0) < c && (s[h] = c);
} for (let h of a) {
    let c = g.get(h) ?? [];
    if (c.length > 0) {
        let p = Math.min(...c.map(C => (s[C] ?? 0) - 1));
        (s[h] ?? 0) > p && (s[h] = p);
    }
} return { layers: Io(n, l, s), rankOf: s, dummy: new Set }; }
f(Ws, "assignLayers_Gravity");
function Ks(t) { let e = bo(t), n = xo(t), o = Mo(e), s = []; for (; o.length > 0;) {
    let r = [];
    for (let i of o) {
        s.push(i);
        for (let g of n.get(i) ?? [])
            e.set(g, (e.get(g) ?? 0) - 1), (e.get(g) ?? 0) === 0 && r.push(g);
    }
    o = r.sort((i, g) => i.localeCompare(g));
} return s.length === t.nodes.length ? s : null; }
f(Ks, "topoSortByGenerationIfAcyclic");
function qs(t, e) { let n = be(t), o = e?.direction === "LR" ? Ks(n) ?? [...n.nodes].sort() : Pe(n) ?? [...n.nodes].sort(), s = ue(n), r = f(u => s(u) ?? u, "laneOf"), i = Object.create(null), g = new Map, l = f((u, y) => e?.ignoreCrossLaneEdges ?? !0 ? r(u) === r(y) ? 1 : 0 : 1, "edgeWeight"); for (let u of o) {
    if (n.nodeById.get(u)?.isGroup)
        continue;
    let L = yo(n, u), m = 0;
    if (L.length > 0)
        for (let C of L) {
            let M = C.src, v = i[M] ?? 0;
            m = Math.max(m, v + l(M, u));
        }
    let h = r(u), c = g.get(h) ?? 0, p = Math.max(m, c);
    i[u] = p, g.set(h, p + 1);
} return { layers: Io(n, o, i, { skipGroups: !0 }), rankOf: i, dummy: new Set }; }
f(qs, "assignLayers_LaneAwareCompact");
function Js(t, e) { let n = be(e), { rankOf: o } = t, s = t.layers.map(m => [...m]), r = new Set(t.dummy ? [...t.dummy] : []), i = 0, g = new Map(n.nodeById), l = f(m => { let h = `placeholder-${i++}`, c = { id: h, isGroup: !1, isDummy: !0, width: 0, height: 0 }; for (g.set(h, c), r.add(h); s.length <= m;)
    s.push([]); return s[m].push(h), o[h] = m, h; }, "addDummyAt"), a = [...n.edges].sort((m, h) => m.id === h.id ? m.src === h.src ? m.dst.localeCompare(h.dst) : m.src.localeCompare(h.src) : m.id.localeCompare(h.id)), u = []; for (let m of a) {
    let h = o[m.src] ?? 0, c = o[m.dst] ?? 0;
    if (c - h <= 1) {
        u.push(m);
        continue;
    }
    let p = m.src;
    for (let M = h + 1, v = 0; M < c; M++, v++) {
        let R = l(M);
        u.push({ id: `${m.id}#${v}`, src: p, dst: R, weight: m.weight, ref: m.ref }), p = R;
    }
    let C = c - h - 2;
    u.push({ id: `${m.id}#${Math.max(C + 1, 0)}`, src: p, dst: m.dst, weight: m.weight, ref: m.ref });
} let L = { nodes: [...n.nodes, ...[...r].filter(m => !n.nodes.includes(m))], edges: u, layout: n.layout, nodeById: g }; return { layering: { layers: s, rankOf: o, dummy: r }, graphWithDummies: L }; }
f(Js, "makeProperLayering");
function Kn(t) { let e = t.length; if (e === 0)
    return Number.POSITIVE_INFINITY; let n = [...t].sort((o, s) => o - s); return e % 2 === 1 ? n[(e - 1) / 2] : .5 * (n[e / 2 - 1] + n[e / 2]); }
f(Kn, "median");
function qn(t) { return t.length === 0 ? Number.POSITIVE_INFINITY : t.reduce((n, o) => n + o, 0) / t.length; }
f(qn, "barycenter");
function Zs(t, e, n, o) { let s = new Map; for (let r of t)
    s.set(r, []); for (let r of n)
    o === "down" ? e.has(r.src) && s.has(r.dst) && s.get(r.dst).push(e.get(r.src)) : e.has(r.dst) && s.has(r.src) && s.get(r.src).push(e.get(r.dst)); return s; }
f(Zs, "neighborPositionsFor");
function Qs(t, e, n) { let o = n.get(t) ?? 0, s = n.get(e) ?? 0; return o !== s ? o - s : t.localeCompare(e); }
f(Qs, "currentOrderTieBreak");
function Jn(t, e, n) { let o = new Set(t), s = new Set(e), r = Be(t), i = Be(e), g = []; for (let a of n)
    o.has(a.src) && s.has(a.dst) && g.push({ u: r.get(a.src), v: i.get(a.dst) }); g.sort((a, u) => a.u === u.u ? a.v - u.v : a.u - u.u); let l = g.map(a => a.v); return So(l); }
f(Jn, "countCrossingsBetweenAdjacent");
function Ke(t, e, n) { return [...t].sort((o, s) => { let r = Kn(e.get(o) ?? []), i = Kn(e.get(s) ?? []); return r === i ? Qs(o, s, n) : isFinite(r) ? isFinite(i) ? r - i : -1 : 1; }); }
f(Ke, "sortByHeuristic");
function Zn(t, e, n, o, s, r) { let i = Be(t), g = Be(e), l = Zs(e, i, n, o); if (!s || !r || r.length === 0)
    return Ke(e, l, g); let a = new Map; for (let L of e) {
    let m = s(L), h = a.get(m) ?? [];
    h.push(L), a.set(m, h);
} let u = []; for (let L of r) {
    let m = a.get(L);
    if (!m || m.length === 0)
        continue;
    let h = Ke(m, l, g);
    u.push(...h);
} let y = a.get(null); if (y && y.length > 0) {
    let L = Ke(y, l, g);
    for (let m of L) {
        let h = qn(l.get(m) ?? []), c = u.length;
        if (isFinite(h))
            for (let [p, C] of u.entries()) {
                let M = qn(l.get(C) ?? []);
                if (h < M) {
                    c = p;
                    break;
                }
            }
        u.splice(c, 0, m);
    }
} return u; }
f(Zn, "reorderLayer");
function Qn(t, e, n, o, s) { let r = [...e], i = new Set(t), g = new Set(e), l = o ? new Set(o) : null, a = n.filter(c => i.has(c.src) && g.has(c.dst)), u = l ? n.filter(c => g.has(c.src) && l.has(c.dst)) : void 0, y = f(c => { let p = Jn(t, c, a); return u && o && (p += Jn(c, o, u)), p; }, "crossingScore"), L = s ? new Map : null; if (s && L)
    for (let c of e)
        L.set(c, s(c)); let m = !0, h = y(r); for (; m;) {
    m = !1;
    for (let c = 0; c + 1 < r.length; c++) {
        if (L) {
            let M = L.get(r[c]), v = L.get(r[c + 1]);
            if (M !== v)
                continue;
        }
        let p = h;
        [r[c], r[c + 1]] = [r[c + 1], r[c]];
        let C = y(r);
        C < p ? (h = C, m = !0) : [r[c], r[c + 1]] = [r[c + 1], r[c]];
    }
} return r; }
f(Qn, "transposeImprove");
function tr(t, e, n) { let o = t.layers.map(g => [...g]), s = e.edges, r = ue(e), i = Co(e, n?.laneOrder); for (let g = 0; g < 3; g++) {
    for (let l = 1; l < o.length; l++)
        o[l] = Zn(o[l - 1], o[l], s, "down", r, i), o[l] = Qn(o[l - 1], o[l], s, o[l + 1], r);
    for (let l = o.length - 2; l >= 0; l--)
        o[l] = Zn(o[l + 1], o[l], s, "up", r, i), o[l] = Qn(o[l + 1], o[l], s, o[l - 1], r);
} return { layers: o }; }
f(tr, "orderLayers");
function er(t, e, n) { let o = n?.layerGap ?? ko.DEFAULT_LAYER_GAP, s = n?.nodeGap ?? ko.DEFAULT_NODE_GAP, r = n?.laneGap ?? s * 2, i = n?.direction ?? "TB", g = i === "LR" || i === "RL", l = t.layers, a = Object.create(null), u = Object.create(null), y = f(w => e.nodeById.get(w), "getNode"), L = f(w => y(w)?.width ?? 0, "getWidth"), m = f(w => y(w)?.height ?? 0, "getHeight"), h = ue(e), c = Co(e, n?.laneOrder), p = l.map(w => w.reduce((_, k) => Math.max(_, m(k)), 0)), C = []; if (g)
    for (let w = 0; w + 1 < l.length; w++) {
        let _ = l[w].reduce((mt, Nt) => Math.max(mt, L(Nt)), 0), k = l[w + 1].reduce((mt, Nt) => Math.max(mt, L(Nt)), 0), B = p[w], X = p[w + 1], $ = B / 2 + X / 2, K = (_ + k) / 2, ct = Math.max(0, K - $ - o);
        C.push(ct);
    } let M = new Set; for (let w of l)
    for (let _ of w)
        M.add(h(_)); let v = M.has(null), R = c.filter(w => M.has(w)), I = [...v ? [null] : [], ...R], b = Object.create(null); for (let w of R)
    b[w] = 0; v && (b.null = 0); for (let w of l) {
    let _ = Object.create(null), k = [];
    for (let B of w) {
        let X = h(B);
        X === null ? k.push(B) : (_[X] ||= []).push(B);
    }
    for (let [B, X] of Object.entries(_)) {
        let $ = X.reduce((K, ct) => K + L(ct), 0) + s * Math.max(0, X.length - 1);
        b[B] = Math.max(b[B] ?? 0, $);
    }
    if (v && k.length) {
        let B = k.reduce((X, $) => X + L($), 0) + s * Math.max(0, k.length - 1);
        b.null = Math.max(b.null ?? 0, B);
    }
} let T = new Map; {
    let w = I.map(B => (B === null ? b.null : b[B]) ?? 0), k = -(w.reduce((B, X) => B + X, 0) + r * Math.max(0, I.length - 1)) / 2;
    for (let B = 0; B < I.length; B++) {
        let X = I[B], $ = w[B] ?? 0, K = k + $ / 2;
        T.set(X, K), k += $, B < I.length - 1 && (k += r);
    }
} let N = 0; for (let [w, _] of l.entries()) {
    let k = p[w] ?? 0, B = new Map;
    for (let $ of _) {
        let K = h($), ct = B.get(K) ?? [];
        ct.push($), B.set(K, ct);
    }
    for (let $ of I) {
        let K = B.get($) ?? [];
        if (K.length === 0)
            continue;
        let ct = T.get($);
        if (K.length === 1) {
            let mt = K[0];
            a[mt] = ct, u[mt] = N + k / 2;
        }
        else {
            let mt = K.map(Q => L(Q)), Nt = mt.reduce((Q, W) => Q + W, 0) + s * (K.length - 1), Pt = ct - Nt / 2;
            for (let [Q, W] of K.entries()) {
                let et = mt[Q];
                a[W] = Pt + et / 2, u[W] = N + k / 2, Pt += et + s;
            }
        }
    }
    let X = C[w] ?? 0;
    N += k + o + X;
} let F = new Map; for (let w of e.edges) {
    let _ = w.ref.id;
    F.has(_) || F.set(_, []), F.get(_).push(w);
} for (let [, w] of F) {
    if (w.length === 0)
        continue;
    let _ = w[0].ref, k = _.start, B = _.end;
    if (k == null || B == null)
        continue;
    let X = Math.round(((a[k] ?? 0) + (a[B] ?? 0)) / 2), $ = new Set;
    for (let K of w)
        $.add(K.src), $.add(K.dst);
    for (let K of $) {
        if (K === k || K === B)
            continue;
        e.nodeById.get(K)?.isDummy && (a[K] = X);
    }
} return { x: a, y: u }; }
f(er, "assignCoordinates");
var nr = 8;
function or(t) { let e = 2166136261; for (let n = 0; n < t.length; n++)
    e ^= t.charCodeAt(n), e = Math.imul(e, 16777619); return e >>> 0; }
f(or, "hashString");
function sr(t) { let e = t >>> 0; return () => { e += 1831565813; let n = e; return n = Math.imul(n ^ n >>> 15, n | 1), n ^= n + Math.imul(n ^ n >>> 7, n | 61), ((n ^ n >>> 14) >>> 0) / 4294967296; }; }
f(sr, "mulberry32");
function rr(t, e) { let n = [...t], o = sr(e); for (let s = n.length - 1; s > 0; s--) {
    let r = Math.floor(o() * (s + 1));
    [n[s], n[r]] = [n[r], n[s]];
} return n; }
f(rr, "deterministicShuffle");
function ir(t, e) { let n = 0; for (let [o, s] of t.entries())
    n += Math.abs(o - (e.get(s) ?? o)); return n; }
f(ir, "sourceDistance");
function to(t, e) { let n = new Map; for (let [s, r] of t.entries())
    n.set(r, s); let o = 0; for (let { a: s, b: r, weight: i } of e) {
    let g = n.get(s), l = n.get(r);
    g == null || l == null || (o += i * Math.abs(g - l));
} return o; }
f(to, "laneArrangementCost");
function cr(t) { let e = fn(t); if (e.length < 2)
    return []; let n = new Map(e.map((r, i) => [r, i])), o = ue(t), s = new Map; for (let r of t.layout.edges ?? []) {
    if (r.isLayoutOnly)
        continue;
    let i = typeof r.start == "string" ? r.start : void 0, g = typeof r.end == "string" ? r.end : void 0;
    if (!i || !g || !t.nodeById.has(i) || !t.nodeById.has(g))
        continue;
    let l = o(i), a = o(g);
    if (!l || !a || l === a)
        continue;
    let u = n.get(l), y = n.get(a);
    if (u == null || y == null)
        continue;
    let [L, m] = u <= y ? [l, a] : [a, l], h = `${L}\0${m}`, c = s.get(h);
    c ? c.weight++ : s.set(h, { a: L, b: m, weight: 1 });
} return [...s.values()]; }
f(cr, "buildWeightedLaneEdges");
function eo(t, e, n) { let o = [...t], s = to(o, e), r = !0, i = 0, g = Math.max(1, o.length); for (; r && i < g;) {
    r = !1, i++;
    for (let l = 0; l + 1 < o.length; l++) {
        [o[l], o[l + 1]] = [o[l + 1], o[l]];
        let a = to(o, e);
        a < s ? (s = a, r = !0) : [o[l], o[l + 1]] = [o[l + 1], o[l]];
    }
} return { order: o, cost: s, sourceDistance: ir(o, n) }; }
f(eo, "greedySwitch");
function ar(t, e) { return t.cost !== e.cost ? t.cost < e.cost : t.sourceDistance < e.sourceDistance; }
f(ar, "isBetterCandidate");
function lr(t, e, n) { let o = [...e].sort((s, r) => s.a === r.a ? s.b.localeCompare(r.b) : s.a.localeCompare(r.a)).map(({ a: s, b: r, weight: i }) => `${s}:${r}:${i}`).join("|"); return or(`${t.join("|")}#${o}#${n}`); }
f(lr, "seedForRestart");
function fr(t, e = {}) { let n = fn(t); if (n.length < 2)
    return n; let o = cr(t); if (o.length === 0)
    return n; let s = new Map(n.map((g, l) => [g, l])), r = eo(n, o, s), i = Math.max(0, e.restarts ?? nr); for (let g = 0; g < i; g++) {
    let l = lr(n, o, g), a = rr(n, l), u = eo(a, o, s);
    ar(u, r) && (r = u);
} return r.order; }
f(fr, "optimizeTopLaneOrder");
function dr(t, e) { let n = e?.ignoreCrossLaneEdges ?? !0, o = e?.optimizeRanksByCrossings ?? !0, s = be(t), r = e?.automaticLaneOrdering ? fr(s, { restarts: nr }) : void 0, i = Ns(s), g = i.acyclic, l = n ? qs(g, { compactSingleInput: e?.compactSingleInput ?? sn.DEFAULT_COMPACT_SINGLE_INPUT, ignoreCrossLaneEdges: !0, direction: e?.direction }) : Ws(g, { compactSingleInput: e?.compactSingleInput ?? sn.DEFAULT_COMPACT_SINGLE_INPUT, ignoreCrossLaneEdges: !1, optimizeRanksByCrossings: o }), { layering: a, graphWithDummies: u } = Js(l, g), y = tr(a, u, { laneOrder: r }), L = er(y, u, { layerGap: e?.layerGap, nodeGap: e?.nodeGap, direction: e?.direction, laneOrder: r }); return { acyclic: g, reversed: i.reversed, layering: a, ordered: y, coordinates: L }; }
f(dr, "sugiyamaLayout");
var at = Pr.EPSILON, kr = 8, Ie = 15, we = 15, je = 25, oe = 20, vn = 10;
function no(t, e, n) { let o = t.x ?? 0, s = t.y ?? 0, r = e.x - o, i = e.y - s, g = Math.abs(r), l = Math.abs(i); return g < at && l < at ? n : l > at && l * 3 >= g ? i > 0 ? "bottom" : "top" : g > at ? r > 0 ? "right" : "left" : n; }
f(no, "chooseOrthogonalSide");
function oo(t, e) { return Math.abs(t.to - e.from) < at || Math.abs(t.to - e.to) < at ? t.to : t.from; }
f(oo, "sharedLineEndpointCoord");
function Se(t, e) { return t.orient === "vertical" ? { x: t.coord, y: e } : { x: e, y: t.coord }; }
f(Se, "pointOnLine");
function ur(t, e) { let n = t.nodes ?? [], o = t.edges ?? [], s = []; for (let d of o)
    d.isLayoutOnly || s.push(ae(xt({}, d), { __originalEdge: d })); let r = new Map, i = new Map, g = [], l = e === "LR"; for (let d of n)
    r.set(d.id, d); let a = n.filter(d => d.isGroup && !d.parentId); for (let d of a) {
    let x = { id: d.id }, S = f(E => { i.set(E.id, x), n.filter(A => A.parentId === E.id).forEach(S); }, "assignLane");
    S(d);
} let u = n.filter(d => !d.isGroup && !d.isEdgeLabel).map(d => { let x = d.width ?? 10, S = d.height ?? 10, E = d.x ?? 0, A = d.y ?? 0, P = kr; return { nodeId: d.id, minX: E - x / 2 - P, maxX: E + x / 2 + P, minY: A - S / 2 - P, maxY: A + S / 2 + P, visualXHalfExtent: l ? S / 2 + P : x / 2 + P }; }), y = f((d, x, S, E) => { let A = g.find(P => P.orientation === d && Math.abs(P.coord - x) < 1); return A || (A = { id: `pipe-${d}-${x.toFixed(0)}`, orientation: d, coord: x, spanMin: S, spanMax: E, tracks: [] }, g.push(A)), A.spanMin = Math.min(A.spanMin, S), A.spanMax = Math.max(A.spanMax, E), A; }, "getOrAddPipe"), L = f((d, x) => { let S = d.width ?? 10, E = d.height ?? 10, A = d.x ?? 0, P = d.y ?? 0; switch (x) {
    case "top": return { x: A, y: P - E / 2 };
    case "bottom": return { x: A, y: P + E / 2 };
    case "left": return { x: A - S / 2, y: P };
    case "right": return { x: A + S / 2, y: P };
} }, "portForSide"), m = f((d, x, S) => L(d, no(d, x, S ? "bottom" : "top")), "getOrthogonalPort"), h = [], c = [], p = new Set, C = 1e3, M = f((d, x, S) => { if (h.length === 0)
    return 0; let E = Math.abs(x.y - S.y) < at, A = Math.abs(x.x - S.x) < at; if (!E && !A)
    return 0; let P = 0; if (E) {
    let j = x.y, J = Math.min(x.x, S.x) - at, V = Math.max(x.x, S.x) + at;
    if (V <= J)
        return 0;
    for (let G of h)
        G.edgeIndex === d || G.orientation !== "vertical" || G.pipe.coord < J || G.pipe.coord > V || G.from - at <= j && G.to + at >= j && (P += C);
}
else if (A) {
    let j = x.x, J = Math.min(x.y, S.y) - at, V = Math.max(x.y, S.y) + at;
    if (V <= J)
        return 0;
    for (let G of h)
        G.edgeIndex === d || G.orientation !== "horizontal" || G.pipe.coord < J || G.pipe.coord > V || G.from - at <= j && G.to + at >= j && (P += C);
} return P; }, "crossingPenalty"), v = s.map((d, x) => { if (!d.start || !d.end)
    return { idx: x, crossLane: 0, dx: 0, dy: 0 }; let S = r.get(d.start), E = r.get(d.end), A = i.get(d.start), P = i.get(d.end), j = A && P && A.id !== P.id ? 1 : 0, J = S && E ? Math.abs((E.x ?? 0) - (S.x ?? 0)) : 0, V = S && E ? Math.abs((E.y ?? 0) - (S.y ?? 0)) : 0; return { idx: x, crossLane: j, dx: J, dy: V }; }).sort((d, x) => { if (d.crossLane !== x.crossLane)
    return x.crossLane - d.crossLane; let S = d.dx + d.dy, E = x.dx + x.dy; return Math.abs(S - E) > 1 ? S - E : d.idx - x.idx; }).map(d => d.idx), R = f((d, x, S, E) => { let A = Math.min(d.x, x.x), P = Math.max(d.x, x.x), j = Math.min(d.y, x.y), J = Math.max(d.y, x.y); return !!u.find(G => S && G.nodeId === S || E && G.nodeId === E ? !1 : Math.abs(d.x - x.x) > at ? G.minY < d.y && G.maxY > d.y && G.maxX > A && G.minX < P : G.minX < d.x && G.maxX > d.x && G.maxY > j && G.minY < J); }, "isSegmentBlocked"), I = new Map, b = new Map; for (let d of s)
    !d.start || !d.end || d.start === d.end || (b.set(d.start, (b.get(d.start) ?? 0) + 1), b.set(d.end, (b.get(d.end) ?? 0) + 1)); let T = f((d, x) => no(d, x, "bottom"), "determineSide"), N = new Map; for (let [d, x] of s.entries()) {
    if (!x.start || !x.end || x.start === x.end || x.points && x.points.length > 0)
        continue;
    let S = r.get(x.start), E = r.get(x.end);
    if (!S || !E)
        continue;
    let A = (E.x ?? 0) - (S.x ?? 0), P = (E.y ?? 0) - (S.y ?? 0);
    N.set(d, { edgeIdx: d, srcId: x.start, dstId: x.end, srcSide: T(S, { x: E.x ?? 0, y: E.y ?? 0 }), dstSide: T(E, { x: S.x ?? 0, y: S.y ?? 0 }), absDx: Math.abs(A), absDy: Math.abs(P), dxSign: Math.sign(A), dySign: Math.sign(P) });
} let F = f(d => d.srcSide === "top" || d.srcSide === "bottom" ? d.absDx === 0 ? 1 / 0 : d.absDy / d.absDx : d.absDy === 0 ? 1 / 0 : d.absDx / d.absDy, "preferenceStrength"), w = f(d => d.srcSide === "top" || d.srcSide === "bottom" ? d.dxSign >= 0 ? "right" : "left" : d.dySign >= 0 ? "bottom" : "top", "secondarySide"), _ = new Map; for (let d of N.values()) {
    let x = `${d.srcId}:${d.srcSide}`;
    _.has(x) || _.set(x, []), _.get(x).push(d);
} let k = new Map, B = f((d, x) => `${d}:${x}`, "loadKey"); for (let d of N.values())
    k.set(B(d.srcId, d.srcSide), (k.get(B(d.srcId, d.srcSide)) ?? 0) + 1), k.set(B(d.dstId, d.dstSide), (k.get(B(d.dstId, d.dstSide)) ?? 0) + 1); for (let d of _.values())
    if (!(d.length < 2)) {
        d.sort((x, S) => { let E = F(x), A = F(S); return Math.abs(E - A) > 1e-9 ? A - E : x.edgeIdx - S.edgeIdx; });
        for (let x = 1; x < d.length; x++) {
            let S = d[x], E = w(S), A = k.get(B(S.srcId, S.srcSide)) ?? 0, P = k.get(B(S.srcId, E)) ?? 0;
            P >= A || (k.set(B(S.srcId, S.srcSide), A - 1), k.set(B(S.srcId, E), P + 1), S.srcSide = E);
        }
    } let X = f(d => { let x = d?.shape; return x === "question" || x === "diamond"; }, "isDiamondNode"), $ = new Map; for (let d of N.values())
    $.has(d.dstId) || $.set(d.dstId, new Set), $.get(d.dstId).add(d.dstSide); for (let d of N.values()) {
    if (!X(r.get(d.srcId)))
        continue;
    let x = $.get(d.srcId);
    if (!x?.has(d.srcSide))
        continue;
    let S = w(d);
    if (x.has(S) || (k.get(B(d.srcId, S)) ?? 0) > 0)
        continue;
    let E = k.get(B(d.srcId, d.srcSide)) ?? 0;
    k.set(B(d.srcId, d.srcSide), Math.max(0, E - 1)), k.set(B(d.srcId, S), 1), d.srcSide = S;
} for (let d of N.values()) {
    let { edgeIdx: x, srcId: S, dstId: E, srcSide: A, dstSide: P } = d, j = r.get(S), J = r.get(E), V = `${S}:${A}:src`, G = A === "top" || A === "bottom" ? J.x ?? 0 : J.y ?? 0;
    I.has(V) || I.set(V, []), I.get(V).push({ edgeIdx: x, oppositeCoord: G });
    let ot = `${E}:${P}:dst`, rt = P === "top" || P === "bottom" ? j.x ?? 0 : j.y ?? 0;
    I.has(ot) || I.set(ot, []), I.get(ot).push({ edgeIdx: x, oppositeCoord: rt });
} let K = new Map, ct = 8; for (let [d, x] of I) {
    if (x.length < 2)
        continue;
    x.sort((Et, Ht) => Et.oppositeCoord - Ht.oppositeCoord);
    let S = d.split(":"), E = S.slice(0, -2).join(":"), A = S[S.length - 2], P = S[S.length - 1], j = r.get(E);
    if (!j)
        continue;
    let V = A === "left" || A === "right" ? j.height ?? 10 : j.width ?? 10, G = j.shape, rt = G === "question" || G === "diamond" ? V * .3 : V, tt = Math.min(20, Math.max(ct, rt / (x.length + 1))), Ot = -(tt * (x.length - 1)) / 2;
    for (let [Et, Ht] of x.entries()) {
        let Zt = Ot + Et * tt, gn = `${Ht.edgeIdx}:${P}`;
        K.set(gn, Zt);
    }
} let mt = f(d => !!s[d]?.labelNodeId, "edgeHasLabelNode"), Nt = f((d, x) => d ? (I.get(`${d}:${x}:src`) ?? []).some(({ edgeIdx: S }) => mt(S)) || (I.get(`${d}:${x}:dst`) ?? []).some(({ edgeIdx: S }) => mt(S)) : !1, "faceHasLabelNode"), Pt = f((d, x, S) => x === "top" || x === "bottom" ? { x: d.x + S, y: d.y } : { x: d.x, y: d.y + S }, "applyPortOffset"), Q = f((d, x, S) => { let E = N.get(d), A = { x: S.x ?? 0, y: S.y ?? 0 }, P = { x: x.x ?? 0, y: x.y ?? 0 }, j = E?.srcSide ?? T(x, A), J = E?.dstSide ?? T(S, P), V = E ? L(x, E.srcSide) : m(x, A, !0), G = E ? L(S, E.dstSide) : m(S, P, !1), ot = K.get(`${d}:src`), rt = K.get(`${d}:dst`); return ot !== void 0 && (V = Pt(V, j, ot)), rt !== void 0 && (G = Pt(G, J, rt)), { pSrcPort: V, pDstPort: G, srcSide: j, dstSide: J }; }, "portsForEdge"); for (let d of v) {
    let x = s[d];
    if (c[d] = [], !x.start || !x.end || x.points && x.points.length > 0 || x.start === x.end)
        continue;
    let S = r.get(x.start), E = r.get(x.end);
    if (!S || !E)
        continue;
    let { pSrcPort: A, pDstPort: P, srcSide: j, dstSide: J } = Q(d, S, E), V = xt({}, A), G = xt({}, P), ot = j === "top" || j === "bottom", rt = J === "top" || J === "bottom";
    if (ot) {
        let Y = A.y > (S.y ?? 0);
        V.y = Y ? A.y + oe : A.y - oe;
    }
    else {
        let Y = A.x > (S.x ?? 0);
        V.x = Y ? A.x + oe : A.x - oe;
    }
    if (rt) {
        let Y = P.y > (E.y ?? 0);
        G.y = Y ? P.y + oe : P.y - oe;
    }
    else {
        let Y = P.x > (E.x ?? 0);
        G.x = Y ? P.x + oe : P.x - oe;
    }
    let st = f((Y, z) => { for (let q of u)
        if (!z.includes(q.nodeId) && Y.x > q.minX && Y.x < q.maxX && Y.y > q.minY && Y.y < q.maxY)
            return { inside: !0, obstacle: q }; return { inside: !1 }; }, "isPointInObstacle"), tt = f((Y, z, q, ft, vt) => { if (vt) {
        let Bt = Y.y > (z.y ?? 0);
        return { x: (q.x ?? 0) >= Y.x ? ft.maxX + Ie : ft.minX - Ie, y: Bt ? ft.maxY + we : ft.minY - we, leavesPositiveSide: Bt };
    } let Mt = Y.x > (z.x ?? 0), Tt = (q.y ?? 0) >= Y.y; return { x: Mt ? ft.maxX + Ie : ft.minX - Ie, y: Tt ? ft.maxY + we : ft.minY - we, leavesPositiveSide: Mt }; }, "obstacleDetour"), yt = [], Ot = [x.start, x.end], Et = st(V, Ot);
    if (Et.inside && Et.obstacle) {
        let Y = Et.obstacle;
        if (ot) {
            let z = tt(A, S, E, Y, !0);
            V.x = z.x, V.y = z.y;
            let q = z.leavesPositiveSide ? Math.min(Y.minY - 2, A.y + oe) : Math.max(Y.maxY + 2, A.y - oe);
            yt = [{ x: A.x, y: q }, { x: z.x, y: q }, { x: z.x, y: z.y }];
        }
        else {
            let z = tt(A, S, E, Y, !1), q = z.leavesPositiveSide ? Math.min(Y.minX - 2, A.x + oe) : Math.max(Y.maxX + 2, A.x - oe);
            V.x = z.x, V.y = z.y, yt = [{ x: q, y: A.y }, { x: q, y: z.y }, { x: z.x, y: z.y }];
        }
    }
    let Ht = [], Zt = st(G, Ot);
    if (Zt.inside && Zt.obstacle) {
        let Y = Zt.obstacle;
        if (rt) {
            let z = tt(P, E, S, Y, !0);
            G.x = z.x, G.y = z.y, Ht = [{ x: z.x, y: z.y }, { x: P.x, y: z.y }];
        }
        else {
            let z = tt(P, E, S, Y, !1);
            G.x = z.x, G.y = z.y, Ht = [{ x: z.x, y: z.y }, { x: z.x, y: P.y }];
        }
    }
    if (yt.length === 0 && Ht.length === 0) {
        let Y = Ie, z = Math.abs(V.x - G.x) < Y, q = Math.abs(V.y - G.y) < Y, ft = K.get(`${d}:src`) !== void 0 || K.get(`${d}:dst`) !== void 0, vt = (I.get(`${x.start ?? ""}:${j}:src`)?.length ?? 0) + (I.get(`${x.start ?? ""}:${j}:dst`)?.length ?? 0), Mt = (I.get(`${x.end ?? ""}:${J}:src`)?.length ?? 0) + (I.get(`${x.end ?? ""}:${J}:dst`)?.length ?? 0), Tt = vt > 1 || Mt > 1, Bt = b.get(x.start ?? "") ?? 0, ut = b.get(x.end ?? "") ?? 0, Gt = vt > 1 && Nt(x.start, j) || Mt > 1 && Nt(x.end, J), ne = vt <= 1 || Bt <= 2, kt = Mt <= 1 || ut <= 2;
        if ((z || q) && !ft && (!Tt || Tt && !Gt && ne && kt) && !R(A, P, x.start, x.end)) {
            x.points = [xt({}, A), xt({}, V), xt({}, G), xt({}, P)], p.add(d);
            let It = q ? "horizontal" : "vertical", zt = q ? A.y : A.x, St = q ? Math.min(A.x, P.x) : Math.min(A.y, P.y), Ct = q ? Math.max(A.x, P.x) : Math.max(A.y, P.y), Kt = { id: `fast-path-${It}-${zt.toFixed(0)}-${d}`, orientation: It, coord: zt, spanMin: St, spanMax: Ct, tracks: [] };
            h.push({ edgeIndex: d, segmentIndex: 0, orientation: It, pipe: Kt, trackIndex: 0, from: St, to: Ct });
            continue;
        }
    }
    let gn = y("vertical", V.x, V.y, V.y);
    V.x = gn.coord;
    let mr = y("vertical", G.x, G.y, G.y);
    G.x = mr.coord;
    let ge = Math.min(V.x, G.x) - 50, pe = Math.max(V.x, G.x) + 50, Ee = Math.min(V.y, G.y) - 50, Te = Math.max(V.y, G.y) + 50;
    for (let Y of u) {
        let z = Math.min(V.x, G.x), q = Math.max(V.x, G.x), ft = Math.min(V.y, G.y), vt = Math.max(V.y, G.y);
        Y.minX < q && Y.maxX > z && Y.minY < vt && Y.maxY > ft && (ge = Math.min(ge, Y.minX - je), pe = Math.max(pe, Y.maxX + je), Ee = Math.min(Ee, Y.minY - je), Te = Math.max(Te, Y.maxY + je));
    }
    for (let Y of u) {
        if (Y.maxX < ge || Y.minX > pe || Y.maxY < Ee || Y.minY > Te)
            continue;
        let z = Ie;
        y("horizontal", Y.minY - z, ge, pe), y("horizontal", Y.maxY + z, ge, pe);
        let q = we;
        y("vertical", Y.minX - q, Ee, Te), y("vertical", Y.maxX + q, Ee, Te);
    }
    y("horizontal", V.y, ge, pe), y("horizontal", G.y, ge, pe);
    let yr = g.filter(Y => Y.orientation === "horizontal" && Y.coord >= Ee && Y.coord <= Te), xr = g.filter(Y => Y.orientation === "vertical" && Y.coord >= ge && Y.coord <= pe), ke = f((Y, z) => `${Y.toFixed(1)},${z.toFixed(1)}`, "getKey"), _e = ke(V.x, V.y), Lo = ke(G.x, G.y), De = new Map, pn = new Map, mn = new Map, He = new Set, Me = [];
    De.set(_e, 0), mn.set(_e, "n"), Me.push({ key: _e, f: Math.hypot(G.x - V.x, G.y - V.y), pt: V }), He.add(_e);
    let Xt = [], me = f((Y, z) => R(Y, z, x.start, x.end), "checkSegmentBlocked"), yn = { x: G.x, y: V.y }, br = me(V, yn), Mr = me(yn, G), Ir = br || Mr, xn = { x: V.x, y: G.y }, Sr = me(V, xn), Cr = me(xn, G);
    if (Ir ? Sr || Cr || (Math.abs(V.x - G.x) < at ? Xt = [V, G] : Xt = [V, xn, G]) : Math.abs(V.y - G.y) < at || Math.abs(V.x - G.x) < at ? Xt = [V, G] : Xt = [V, yn, G], Xt.length === 0)
        for (; Me.length > 0;) {
            Me.sort((ut, Gt) => ut.f - Gt.f);
            let Y = Me.shift();
            if (He.delete(Y.key), Y.key === Lo) {
                let ut = Lo, Gt = G;
                for (Xt = [Gt]; pn.has(ut);) {
                    let ne = pn.get(ut);
                    Xt.unshift(ne), Gt = ne, ut = ke(ne.x, ne.y);
                }
                break;
            }
            let z = Y.pt.x, q = Y.pt.y, ft = xr.sort((ut, Gt) => ut.coord - Gt.coord), vt = ft.findIndex(ut => Math.abs(ut.coord - z) < 1), Mt = yr.sort((ut, Gt) => ut.coord - Gt.coord), Tt = Mt.findIndex(ut => Math.abs(ut.coord - q) < 1), Bt = [];
            vt > 0 && Bt.push({ x: ft[vt - 1].coord, y: q }), vt >= 0 && vt < ft.length - 1 && Bt.push({ x: ft[vt + 1].coord, y: q }), Tt > 0 && Bt.push({ x: z, y: Mt[Tt - 1].coord }), Tt >= 0 && Tt < Mt.length - 1 && Bt.push({ x: z, y: Mt[Tt + 1].coord });
            for (let ut of Bt) {
                let Gt = Math.min(z, ut.x), ne = Math.max(z, ut.x), kt = Math.min(q, ut.y), $t = Math.max(q, ut.y);
                if (u.some(Qt => Qt.nodeId === x.start || Qt.nodeId === x.end ? !1 : Gt !== ne ? Qt.minY < q && Qt.maxY > q && Qt.maxX > Gt && Qt.minX < ne : Qt.minX < z && Qt.maxX > z && Qt.maxY > kt && Qt.minY < $t))
                    continue;
                let It = ke(ut.x, ut.y), zt = Math.abs(ut.x - z) + Math.abs(ut.y - q), St = M(d, Y.pt, ut), Ct = 0, Kt = G.x - V.x, Ae = G.y - V.y, Xe = ut.x - z, bn = ut.y - q;
                (Ae > 10 && bn < -5 || Ae < -10 && bn > 5) && (Ct = Math.abs(bn) * 100), (Kt > 10 && Xe < -5 || Kt < -10 && Xe > 5) && (Ct += Math.abs(Xe) * 50);
                let Eo = 0, To = mn.get(Y.key) ?? "n", Ao = Math.abs(Xe) > at ? "h" : "v";
                To !== "n" && To !== Ao && (Eo = 50);
                let vr = zt + St + Ct + Eo, Ye = (De.get(Y.key) ?? 1 / 0) + vr, wo = Math.abs(G.x - ut.x) + Math.abs(G.y - ut.y);
                if (Ye < (De.get(It) ?? 1 / 0))
                    if (pn.set(It, Y.pt), De.set(It, Ye), mn.set(It, Ao), !He.has(It))
                        Me.push({ key: It, f: Ye + wo, pt: ut }), He.add(It);
                    else {
                        let Qt = Me.findIndex(Lr => Lr.key === It);
                        Qt !== -1 && (Me[Qt].f = Ye + wo);
                    }
            }
        }
    if (Xt.length === 0 && (Xt = [V, { x: V.x, y: G.y }, G]), Xt.length > 4) {
        let Y = Xt[0], z = Xt[Xt.length - 1], q = Math.min(Y.x, z.x), ft = Math.max(Y.x, z.x), vt = Math.min(Y.y, z.y), Mt = Math.max(Y.y, z.y);
        for (let kt of Xt)
            q = Math.min(q, kt.x), ft = Math.max(ft, kt.x), vt = Math.min(vt, kt.y), Mt = Math.max(Mt, kt.y);
        let Tt = ft > Math.max(Y.x, z.x), Bt = q < Math.min(Y.x, z.x);
        if (l) {
            let kt = we;
            if (Tt) {
                let $t = Math.max(Y.x, z.x), Ft = Math.min(Y.y, z.y), It = Math.max(Y.y, z.y), zt = u.filter(St => St.minX < $t && St.maxX > $t && St.minY < It && St.maxY > Ft);
                if (zt.length > 0) {
                    let St = Math.max(Y.x, z.x);
                    for (let Ct of zt) {
                        let Kt = (Ct.minX + Ct.maxX) / 2;
                        if (Ct.visualXHalfExtent === void 0 || isNaN(Ct.visualXHalfExtent))
                            continue;
                        let Ae = Kt + Ct.visualXHalfExtent + kt;
                        St = Math.max(St, Ae);
                    }
                    isNaN(St) || (ft = St);
                }
            }
            if (Bt) {
                let $t = u.filter(Ft => Ft.minX < Math.min(Y.x, z.x) + kt && Ft.minY < Math.max(Y.y, z.y) && Ft.maxY > Math.min(Y.y, z.y));
                if ($t.length > 0) {
                    let Ft = Math.min(Y.x, z.x);
                    for (let It of $t) {
                        let St = (It.minX + It.maxX) / 2 - It.visualXHalfExtent - kt;
                        Ft = Math.min(Ft, St);
                    }
                    q = Ft;
                }
            }
        }
        let ut = f(kt => { let $t = z.y > Y.y, Ft = u.filter(St => { let Ct = Math.min(Y.x, z.x) < St.maxX && Math.max(Y.x, z.x) > St.minX, Kt = Math.min(Y.y, z.y) < St.maxY && Math.max(Y.y, z.y) > St.minY; return Ct && Kt; }), It = Ft; if (l && Ft.length > 0) {
            let St = Ft.filter(Ct => Ct.minX < kt && Ct.maxX > kt);
            St.length > 0 && (It = St);
        } if (It.length === 0)
            return z.y; let zt = Ie; if ($t) {
            let Ct = Math.max(...It.map(Kt => Kt.maxY)) + zt;
            if (Ct < z.y - at)
                return Ct;
        }
        else {
            let Ct = Math.min(...It.map(Kt => Kt.minY)) - zt;
            if (Ct > z.y + at)
                return Ct;
        } return z.y; }, "findBestReturnY"), Gt = f(kt => { let $t = ut(kt), Ft = { x: kt, y: Y.y }, It = { x: kt, y: $t }, zt = { x: z.x, y: $t }, St = me(Y, Ft), Ct = me(Ft, It), Kt = me(It, zt), Ae = $t !== z.y ? me(zt, z) : !1; return !St && !Ct && !Kt && !Ae ? Math.abs($t - z.y) < at ? [Y, Ft, It, z] : [Y, Ft, It, zt, z] : null; }, "trySimplifyWithDetourX"), ne = Tt && !Bt ? Gt(ft) : Bt && !Tt ? Gt(q) : null;
        ne && (Xt = ne);
    }
    let Yt = [A, ...yt, ...Xt, ...Ht.reverse(), P];
    if (Yt.length >= 3) {
        let Y = Yt[Yt.length - 1], z = Yt[Yt.length - 2], q = Yt[Yt.length - 3], ft = Math.abs(q.y - z.y) < at && Math.abs(z.y - Y.y) < at, vt = Math.abs(q.x - z.x) < at && Math.abs(z.x - Y.x) < at;
        if (ft) {
            let Mt = Math.sign(z.x - q.x), Tt = Math.sign(Y.x - q.x);
            Mt !== 0 && Mt === Tt && Math.abs(z.x - q.x) > Math.abs(Y.x - q.x) && Yt.splice(-2, 1);
        }
        else if (vt) {
            let Mt = Math.sign(z.y - q.y), Tt = Math.sign(Y.y - q.y);
            Mt !== 0 && Mt === Tt && Math.abs(z.y - q.y) > Math.abs(Y.y - q.y) && Yt.splice(-2, 1);
        }
    }
    let ce = [Yt[0]];
    for (let Y = 1; Y < Yt.length - 1; Y++) {
        if (Y === 1) {
            ce.push(Yt[Y]);
            continue;
        }
        let z = ce[ce.length - 1], q = Yt[Y], ft = Yt[Y + 1];
        if (Math.abs(z.y - q.y) < at && Math.abs(q.y - ft.y) < at) {
            let vt = q.x > z.x, Mt = ft.x > q.x;
            if (vt !== Mt) {
                ce.push(q);
                continue;
            }
            continue;
        }
        if (Math.abs(z.x - q.x) < at && Math.abs(q.x - ft.x) < at) {
            let vt = q.y > z.y, Mt = ft.y > q.y;
            if (vt !== Mt) {
                ce.push(q);
                continue;
            }
            continue;
        }
        ce.push(q);
    }
    ce.push(Yt[Yt.length - 1]);
    for (let Y = 0; Y < ce.length - 1; Y++) {
        let z = ce[Y], q = ce[Y + 1], ft = Math.abs(z.x - q.x) < at ? "vertical" : "horizontal", vt = ft === "vertical" ? z.x : z.y, Mt = ft === "vertical" ? Math.min(z.y, q.y) : Math.min(z.x, q.x), Tt = ft === "vertical" ? Math.max(z.y, q.y) : Math.max(z.x, q.x), Bt = y(ft, vt, Mt, Tt), ut = { edgeIndex: d, segmentIndex: Y, orientation: ft, pipe: Bt, trackIndex: 0, from: Mt, to: Tt };
        h.push(ut), c[d].push(h.length - 1), Bt.tracks[0] || (Bt.tracks[0] = { index: 0, coord: Bt.coord, segments: [] }), Bt.tracks[0].segments.push({ edgeIndex: d, segmentIndex: Y, from: Mt, to: Tt });
    }
} let W = f((d, x) => d.from < x.to && x.from < d.to, "segmentsOverlap"), et = f((d, x, S, E) => { let A = !E.segments.some(j => (j.edgeIndex !== x.edgeIndex || j.segmentIndex !== x.segmentIndex) && W(j, d)), P = !S.segments.some(j => (j.edgeIndex !== d.edgeIndex || j.segmentIndex !== d.segmentIndex) && W(j, x)); return A && P ? (d.trackIndex = E.index, x.trackIndex = S.index, S.segments = [...S.segments.filter(j => j.edgeIndex !== d.edgeIndex || j.segmentIndex !== d.segmentIndex), { edgeIndex: x.edgeIndex, segmentIndex: x.segmentIndex, from: x.from, to: x.to }], E.segments = [...E.segments.filter(j => j.edgeIndex !== x.edgeIndex || j.segmentIndex !== x.segmentIndex), { edgeIndex: d.edgeIndex, segmentIndex: d.segmentIndex, from: d.from, to: d.to }], !0) : !1; }, "trySwapSegmentsAcrossTracks"), lt = f(d => { let x = d.tracks.length; return d.tracks[x] = { index: x, coord: d.coord, segments: [] }, x; }, "createNewTrack"), gt = f((d, x) => { let S = d.pipe.tracks[d.trackIndex]; S.segments = S.segments.filter(A => A.edgeIndex !== d.edgeIndex || A.segmentIndex !== d.segmentIndex), d.trackIndex = x, d.pipe.tracks[x].segments.push({ edgeIndex: d.edgeIndex, segmentIndex: d.segmentIndex, from: d.from, to: d.to }); }, "moveSegmentToTrack"), bt = f((d, x) => { let S = c[d.edgeIndex]; for (let E of S) {
    let A = h[E];
    A.pipe === d.pipe && gt(A, x);
} }, "moveSegmentChainToTrack"), Lt = f(d => { let x = c[d.edgeIndex], S = x.indexOf(h.indexOf(d)), E = []; return S > 0 && E.push(h[x[S - 1]]), S < x.length - 1 && E.push(h[x[S + 1]]), E; }, "getAdjacentSegmentsAlongEdge"), Ut = f((d, x) => { if (d.orientation === x.orientation)
    return !1; let S = d.orientation === "horizontal" ? d : x, E = d.orientation === "horizontal" ? x : d; return E.pipe.coord > S.from && E.pipe.coord < S.to && S.pipe.coord > E.from && S.pipe.coord < E.to; }, "haveAnyCrossing"), jt = f((d, x) => { for (let S of d.tracks)
    if (!S.segments.some(A => (A.edgeIndex !== x.edgeIndex || A.segmentIndex !== x.segmentIndex) && W(A, x)))
        return S.index; return -1; }, "findAvailableTrack"), Wt = f((d, x) => { if (d.trackIndex === x.trackIndex)
    return W(d, x); let S = Lt(d), E = Lt(x); return S.some(A => E.some(P => Ut(A, P))); }, "segmentsConflict"), ee = f((d, x, S) => { if (et(d, x, d.pipe.tracks[d.trackIndex], x.pipe.tracks[x.trackIndex]))
    return; let E = jt(d.pipe, x); S(x, E !== -1 ? E : lt(d.pipe)); }, "resolveTrackConflict"), ve = f(d => { let x = 0; for (let S = 0; S < d.length; S++)
    for (let E = S + 1; E < d.length; E++) {
        let A = d[S], P = d[E];
        A.pipe === P.pipe && Wt(A, P) && (x++, ee(A, P, bt));
    } return x; }, "resolveHandleConflicts"), he = new Map, Le = f(d => { if (he.has(d))
    return he.get(d); let x = c[d]; if (x.length === 0) {
    let J = { dest: 0, deviation: 0, base: 0, delta: 0 };
    return he.set(d, J), J;
} let E = h[x[0]].pipe.coord, A = E; for (let J = 1; J < x.length; J++) {
    let V = h[x[J]];
    if (V.orientation === "horizontal") {
        let G = V.from, ot = V.to;
        A = Math.abs(G - E) > Math.abs(ot - E) ? G : ot;
        break;
    }
} let P = Math.abs(A - E), j = { dest: A, deviation: P, base: E, delta: A - E }; return he.set(d, j), j; }, "getDestInfo"), dn = f(() => { let d = 0, x = new Map; for (let [E, A] of s.entries())
    c[E].length !== 0 && A.start && (x.has(A.start) || x.set(A.start, []), x.get(A.start).push(E)); let S = f(E => { let A = s[E]; if (!A.start || !A.end)
    return 0; let P = r.get(A.start), j = r.get(A.end); if (!P || !j)
    return 0; let J = (j.x ?? 0) - (P.x ?? 0), V = (j.y ?? 0) - (P.y ?? 0); return Math.abs(J) + Math.abs(V); }, "getEdgeDistance"); for (let E of x.values()) {
    E.sort((P, j) => { let J = Le(P), V = Le(j); if (Math.abs(J.deviation - V.deviation) > 1)
        return J.deviation - V.deviation; if (Math.abs(J.dest - V.dest) > 1)
        return J.dest - V.dest; let G = S(P), ot = S(j); if (Math.abs(G - ot) > 1)
        return ot - G; let rt = c[P].length, st = c[j].length; if (rt !== st)
        return rt - st; if (rt === 1) {
        let tt = c[P][0], yt = c[j][0];
        if (h[tt] && h[yt]) {
            let Ot = h[tt], Et = h[yt], Ht = Math.abs(Ot.to - Ot.from), Zt = Math.abs(Et.to - Et.from);
            if (Math.abs(Ht - Zt) > 1)
                return Ht - Zt;
        }
    } return 0; });
    let A = E.map(P => h[c[P][0]]);
    d += ve(A);
} return d; }, "fixSourceHandleCrossings"), un = f(() => { let d = 0, x = new Map; for (let [S, E] of s.entries())
    c[S].length !== 0 && E.end && (x.has(E.end) || x.set(E.end, []), x.get(E.end).push(S)); for (let S of x.values()) {
    S.sort((A, P) => { let j = f(G => { let ot = c[G]; if (ot.length < 2)
        return 0; let rt = h[ot[ot.length - 2]]; return Math.abs(rt.to - rt.from); }, "getDist"), J = j(A), V = j(P); return Math.abs(J - V) > .1 ? J - V : A - P; });
    let E = S.map(A => h[c[A][c[A].length - 1]]);
    d += ve(E);
} return d; }, "fixTargetHandleCrossings"), hn = f(() => { let d = 0; for (let x of g) {
    let S = [];
    for (let E of x.tracks)
        for (let A of E.segments) {
            let P = c[A.edgeIndex].find(j => h[j].segmentIndex === A.segmentIndex);
            P !== void 0 && S.push(h[P]);
        }
    S.sort((E, A) => E.edgeIndex - A.edgeIndex || E.segmentIndex - A.segmentIndex);
    for (let E = 0; E < S.length; E++)
        for (let A = E + 1; A < S.length; A++) {
            let P = S[E], j = S[A];
            Wt(P, j) && (d++, ee(P, j, gt));
        }
} return d; }, "fixPipeCrossings"), O = 0, D = 10; for (; O < D;) {
    let d = 0;
    if (d += dn(), d += un(), d += hn(), d === 0)
        break;
    O++;
} let H = new Map; for (let d of g) {
    let x = [];
    d.tracks.forEach(E => { E.segments.forEach(A => { x.push({ edgeIndex: A.edgeIndex, segmentIndex: A.segmentIndex, trackIndex: E.index, from: A.from, to: A.to }); }); }), x.sort((E, A) => E.from - A.from);
    let S = [];
    if (x.length > 0) {
        let E = [x[0]], A = x[0].to;
        for (let P = 1; P < x.length; P++) {
            let j = x[P];
            j.from < A ? (E.push(j), A = Math.max(A, j.to)) : (S.push(E), E = [j], A = j.to);
        }
        S.push(E);
    }
    for (let E of S) {
        let A = new Set;
        E.forEach(tt => A.add(tt.trackIndex));
        let P = new Map;
        E.forEach(tt => { let yt = Le(tt.edgeIndex); P.set(tt.trackIndex, (P.get(tt.trackIndex) ?? 0) + yt.delta); });
        let j = [...A].filter(tt => (P.get(tt) ?? 0) < -1), J = [...A].filter(tt => (P.get(tt) ?? 0) > 1), V = [...A].filter(tt => Math.abs(P.get(tt) ?? 0) <= 1);
        j.sort((tt, yt) => (P.get(yt) ?? 0) - (P.get(tt) ?? 0)), J.sort((tt, yt) => (P.get(tt) ?? 0) - (P.get(yt) ?? 0));
        let G = f((tt, yt) => { E.filter(Ot => Ot.trackIndex === tt).forEach(Ot => { let Et = p.has(Ot.edgeIndex) ? d.coord : yt; H.set(`${Ot.edgeIndex}-${Ot.segmentIndex}`, Et); }); }, "assignCoord"), ot = 0;
        for (let tt of j)
            ot++, G(tt, d.coord - ot * vn);
        if (V.length === 0 && A.size > 0) {
            let tt = [...A].sort((Et, Ht) => Math.abs(P.get(Et) ?? 0) - Math.abs(P.get(Ht) ?? 0))[0], yt = j.indexOf(tt);
            yt !== -1 && j.splice(yt, 1);
            let Ot = J.indexOf(tt);
            Ot !== -1 && J.splice(Ot, 1), V.push(tt);
        }
        let rt = 0;
        for (let tt of V) {
            if (rt === 0)
                G(tt, d.coord);
            else {
                let yt = rt % 2 === 1 ? 1 : -1, Ot = Math.ceil(rt / 2);
                G(tt, d.coord + yt * Ot * vn * .5);
            }
            rt++;
        }
        let st = 0;
        for (let tt of J)
            st++, G(tt, d.coord + st * vn);
    }
} for (let [d, x] of s.entries()) {
    let S = c[d] ?? [];
    if (S.length === 0)
        continue;
    let E = [], A = r.get(x.start), P = r.get(x.end), { pSrcPort: j, pDstPort: J } = Q(d, A, P), V = S.map(rt => { let st = h[rt], tt = H.get(`${st.edgeIndex}-${st.segmentIndex}`) ?? st.pipe.coord; return { orient: st.orientation, coord: tt, from: st.from, to: st.to }; });
    E.push(j);
    for (let rt = 0; rt < V.length; rt++) {
        let st = V[rt], tt = E[E.length - 1], yt = st.orient === "vertical" ? tt.y : tt.x, Ot = st.orient === "vertical" ? tt.x : tt.y, Et = V[rt + 1], Ht = rt < V.length - 1;
        if (Math.abs(Ot - st.coord) > at && E.push(Se(st, yt)), Ht && Et.orient === st.orient)
            if (Math.abs(st.coord - Et.coord) > at) {
                let Zt = st.orient === "vertical" ? (yt + Et.from) / 2 : oo(st, Et);
                E.push(Se(st, Zt), Se(Et, Zt));
            }
            else
                (rt === 0 || rt === V.length - 2) && E.push(Se(st, oo(st, Et)));
        else if (Ht)
            E.push(Se(st, Et.coord));
        else {
            let Zt = Math.abs(st.from - yt) < Math.abs(st.to - yt) ? st.to : st.from;
            E.push(Se(st, Zt));
        }
    }
    let G = E[E.length - 1];
    (Math.abs(G.x - J.x) > at || Math.abs(G.y - J.y) > at) && E.push(J);
    let ot = [];
    E.length > 0 && ot.push(E[0]);
    for (let rt = 1; rt < E.length; rt++) {
        let st = E[rt], tt = ot[ot.length - 1];
        (Math.abs(st.x - tt.x) > at || Math.abs(st.y - tt.y) > at) && ot.push(st);
    }
    x.points = ot;
} for (let d of s) {
    let x = d.__originalEdge;
    x && d.points && (x.points = d.points);
} t.edges = (t.edges ?? []).filter(d => !d.isLayoutOnly); let U = f((d, x) => { let S = x.x ?? 0, E = x.y ?? 0, A = x.width ?? 0, P = x.height ?? 0; if (A <= 0 || P <= 0)
    return d; let j = S - A / 2, J = S + A / 2, V = E - P / 2, G = E + P / 2; if (d.x < j || d.x > J || d.y < V || d.y > G)
    return d; let ot = d.x - j, rt = J - d.x, st = d.y - V, tt = G - d.y, yt = Math.min(ot, rt, st, tt); return yt === ot ? { x: j, y: d.y } : yt === rt ? { x: J, y: d.y } : yt === st ? { x: d.x, y: V } : { x: d.x, y: G }; }, "nodeBoundaryClamp"); for (let d of t.edges) {
    let x = d.points;
    if (!x || x.length < 2)
        continue;
    let S = d.start, E = d.end, A = S ? r.get(S) : void 0, P = E ? r.get(E) : void 0;
    A && (x[0] = U(x[0], A)), P && (x[x.length - 1] = U(x[x.length - 1], P));
} return t; }
f(ur, "routeEdgesOrthogonal");
function hr(t) { return t.direction ?? "TB"; }
f(hr, "getSwimlaneDirection");
function gr(t) { let e = qo(t), n = t.config.flowchart?.nodeSpacing ?? 40, o = t.config.flowchart?.rankSpacing ?? 100, s = t.config.swimlane?.ignoreCrossLaneEdges ?? !0, r = t.config.swimlane?.optimizeRanksByCrossings ?? !0, i = t.config.swimlane?.automaticLaneOrdering ?? !1, g = hr(t), { ordered: l, coordinates: a } = dr(e, { nodeGap: n, layerGap: o, ignoreCrossLaneEdges: s, optimizeRanksByCrossings: r, automaticLaneOrdering: i, direction: g }); Jo(e, l, a, { nodeGap: n, layerGap: o }); for (let u of t.edges ?? [])
    delete u.points; ur(t, g); for (let u of t.edges ?? [])
    (!u.curve || u.curve === "basis") && (u.curve = "rounded"); return ws(t, g), As(t), g; }
f(gr, "runSwimlaneLayoutCore");
function pr(t) { Ko(t); let e = Zo(t); t.nodes = e.nodes, t.edges = e.edges; }
f(pr, "prepareSwimlaneLayout");
var qr = Ro({ prepareLayout: pr, runLayoutCore: gr, afterPaint: jo });
export { qr as render };
