import { a as L } from "@nf-internal/chunk-RECHUXGF";
import { c as st, f as ot, i as nt } from "@nf-internal/chunk-EAER6ZQJ";
import { f as I, i as S, r as T } from "@nf-internal/chunk-UYYL2GTR";
import { b as rt } from "@nf-internal/chunk-FVDLKYOC";
import { a as Y } from "@nf-internal/chunk-ZVGPI6ZI";
import { d as D } from "@nf-internal/chunk-ZGWTKG5Z";
import { a as tt } from "@nf-internal/chunk-SVIUGILY";
import { k as St } from "@nf-internal/chunk-LAIZNMCN";
import { a as M } from "@nf-internal/chunk-7RHXFCZM";
import { a as et } from "@nf-internal/chunk-RMOXI6XO";
import { b as it } from "@nf-internal/chunk-5HDY5C2T";
import { c as V } from "@nf-internal/chunk-6QY5OUOO";
import { a as _ } from "@nf-internal/chunk-JE6VEUSL";
import { a as X } from "@nf-internal/chunk-XID2BBVI";
import { a as E, b as Q } from "@nf-internal/chunk-OSQMNGTH";
import * as f from "@angular/core";
import { DOCUMENT as x, NgZone as C, inject as p, Injector as R, RendererFactory2 as G, afterNextRender as at, ElementRef as B, InjectionToken as U, ApplicationRef as Pt, Renderer2 as xt, ANIMATION_MODULE_TYPE as Rt, EnvironmentInjector as Et, EventEmitter as w, TemplateRef as Dt, ViewContainerRef as Mt, booleanAttribute as m } from "@angular/core";
import { Location as Bt } from "@angular/common";
import { Subject as k, Subscription as O } from "rxjs";
import { filter as At, takeWhile as Yt } from "rxjs/operators";
var lt = rt();
function Xt(s) { return new W(s.get(S), s.get(x)); }
var W = class {
    _viewportRuler;
    _previousHTMLStyles = { top: "", left: "" };
    _previousScrollPosition;
    _isEnabled = !1;
    _document;
    constructor(t, e) { this._viewportRuler = t, this._document = e; }
    attach() { }
    enable() { if (this._canBeEnabled()) {
        let t = this._document.documentElement;
        this._previousScrollPosition = this._viewportRuler.getViewportScrollPosition(), this._previousHTMLStyles.left = t.style.left || "", this._previousHTMLStyles.top = t.style.top || "", t.style.left = _(-this._previousScrollPosition.left), t.style.top = _(-this._previousScrollPosition.top), t.classList.add("cdk-global-scrollblock"), this._isEnabled = !0;
    } }
    disable() { if (this._isEnabled) {
        let t = this._document.documentElement, e = this._document.body, i = t.style, o = e.style, n = i.scrollBehavior || "", r = o.scrollBehavior || "";
        this._isEnabled = !1, i.left = this._previousHTMLStyles.left, i.top = this._previousHTMLStyles.top, t.classList.remove("cdk-global-scrollblock"), lt && (i.scrollBehavior = o.scrollBehavior = "auto"), window.scroll(this._previousScrollPosition.left, this._previousScrollPosition.top), lt && (i.scrollBehavior = n, o.scrollBehavior = r);
    } }
    _canBeEnabled() { if (this._document.documentElement.classList.contains("cdk-global-scrollblock") || this._isEnabled)
        return !1; let e = this._document.documentElement, i = this._viewportRuler.getViewportSize(); return e.scrollHeight > i.height || e.scrollWidth > i.width; }
};
function Vt(s, t) { return new H(s.get(I), s.get(C), s.get(S), t); }
var H = class {
    _scrollDispatcher;
    _ngZone;
    _viewportRuler;
    _config;
    _scrollSubscription = null;
    _overlayRef;
    _initialScrollPosition;
    constructor(t, e, i, o) { this._scrollDispatcher = t, this._ngZone = e, this._viewportRuler = i, this._config = o; }
    attach(t) { this._overlayRef, this._overlayRef = t; }
    enable() { if (this._scrollSubscription)
        return; let t = this._scrollDispatcher.scrolled(0).pipe(At(e => !e || !this._overlayRef.overlayElement.contains(e.getElementRef().nativeElement))); this._config && this._config.threshold && this._config.threshold > 1 ? (this._initialScrollPosition = this._viewportRuler.getViewportScrollPosition().top, this._scrollSubscription = t.subscribe(() => { let e = this._viewportRuler.getViewportScrollPosition().top; Math.abs(e - this._initialScrollPosition) > this._config.threshold ? this._detach() : this._overlayRef.updatePosition(); })) : this._scrollSubscription = t.subscribe(this._detach); }
    disable() { this._scrollSubscription && (this._scrollSubscription.unsubscribe(), this._scrollSubscription = null); }
    detach() { this.disable(), this._overlayRef = null; }
    _detach = () => { this.disable(), this._overlayRef.hasAttached() && this._ngZone.run(() => this._overlayRef.detach()); };
};
function me() { return new P; }
var P = class {
    enable() { }
    disable() { }
    attach() { }
};
function F(s, t) { return t.some(e => { let i = s.bottom < e.top, o = s.top > e.bottom, n = s.right < e.left, r = s.left > e.right; return i || o || n || r; }); }
function ht(s, t) { return t.some(e => { let i = s.top < e.top, o = s.bottom > e.bottom, n = s.left < e.left, r = s.right > e.right; return i || o || n || r; }); }
function vt(s, t) { return new N(s.get(I), s.get(S), s.get(C), t); }
var N = class {
    _scrollDispatcher;
    _viewportRuler;
    _ngZone;
    _config;
    _scrollSubscription = null;
    _overlayRef;
    constructor(t, e, i, o) { this._scrollDispatcher = t, this._viewportRuler = e, this._ngZone = i, this._config = o; }
    attach(t) { this._overlayRef, this._overlayRef = t; }
    enable() { if (!this._scrollSubscription) {
        let t = this._config ? this._config.scrollThrottle : 0;
        this._scrollSubscription = this._scrollDispatcher.scrolled(t).subscribe(() => { if (this._overlayRef.updatePosition(), this._config && this._config.autoClose) {
            let e = this._overlayRef.overlayElement.getBoundingClientRect(), { width: i, height: o } = this._viewportRuler.getViewportSize();
            F(e, [{ width: i, height: o, bottom: o, right: i, top: 0, left: 0 }]) && (this.disable(), this._ngZone.run(() => this._overlayRef.detach()));
        } });
    } }
    disable() { this._scrollSubscription && (this._scrollSubscription.unsubscribe(), this._scrollSubscription = null); }
    detach() { this.disable(), this._overlayRef = null; }
}, Lt = (() => { class s {
    _injector = p(R);
    constructor() { }
    noop = () => new P;
    close = e => Vt(this._injector, e);
    block = () => Xt(this._injector);
    reposition = e => vt(this._injector, e);
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), A = class {
    positionStrategy;
    scrollStrategy = new P;
    panelClass = "";
    hasBackdrop = !1;
    backdropClass = "cdk-overlay-dark-backdrop";
    disableAnimations;
    width;
    height;
    minWidth;
    minHeight;
    maxWidth;
    maxHeight;
    direction;
    disposeOnNavigation = !1;
    usePopover;
    eventPredicate;
    constructor(t) { if (t) {
        let e = Object.keys(t);
        for (let i of e)
            t[i] !== void 0 && (this[i] = t[i]);
    } }
}, ct = class {
    offsetX;
    offsetY;
    panelClass;
    originX;
    originY;
    overlayX;
    overlayY;
    constructor(t, e, i, o, n) { this.offsetX = i, this.offsetY = o, this.panelClass = n, this.originX = t.originX, this.originY = t.originY, this.overlayX = e.overlayX, this.overlayY = e.overlayY; }
}, dt = class {
    isOriginClipped = !1;
    isOriginOutsideView = !1;
    isOverlayClipped = !1;
    isOverlayOutsideView = !1;
}, z = class {
    connectionPair;
    scrollableViewProperties;
    constructor(t, e) { this.connectionPair = t, this.scrollableViewProperties = e; }
};
function be(s, t) { if (t !== "top" && t !== "bottom" && t !== "center")
    throw Error(`ConnectedPosition: Invalid ${s} "${t}". Expected "top", "bottom" or "center".`); }
function we(s, t) { if (t !== "start" && t !== "end" && t !== "center")
    throw Error(`ConnectedPosition: Invalid ${s} "${t}". Expected "start", "end" or "center".`); }
var mt = (() => { class s {
    _attachedOverlays = [];
    _document = p(x);
    _isAttached = !1;
    constructor() { }
    ngOnDestroy() { this.detach(); }
    add(e) { this.remove(e), this._attachedOverlays.push(e); }
    remove(e) { let i = this._attachedOverlays.indexOf(e); i > -1 && this._attachedOverlays.splice(i, 1), this._attachedOverlays.length === 0 && this.detach(); }
    canReceiveEvent(e, i, o) { return o.observers.length < 1 ? !1 : e.eventPredicate ? e.eventPredicate(i) : !0; }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), It = (() => { class s extends mt {
    _ngZone = p(C);
    _renderer = p(G).createRenderer(null, null);
    _cleanupKeydown;
    add(e) { super.add(e), this._isAttached || (this._ngZone.runOutsideAngular(() => { this._cleanupKeydown = this._renderer.listen("body", "keydown", this._keydownListener); }), this._isAttached = !0); }
    detach() { this._isAttached && (this._cleanupKeydown?.(), this._isAttached = !1); }
    _keydownListener = e => { let i = this._attachedOverlays; for (let o = i.length - 1; o > -1; o--) {
        let n = i[o];
        if (this.canReceiveEvent(n, e, n._keydownEvents)) {
            this._ngZone.run(() => n._keydownEvents.next(e));
            break;
        }
    } };
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = f.\u0275\u0275getInheritedFactory(s)))(o || s); }; })();
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), Tt = (() => { class s extends mt {
    _platform = p(M);
    _ngZone = p(C);
    _renderer = p(G).createRenderer(null, null);
    _cursorOriginalValue;
    _cursorStyleIsSet = !1;
    _pointerDownEventTarget = null;
    _cleanups;
    add(e) { if (super.add(e), !this._isAttached) {
        let i = this._document.body, o = { capture: !0 }, n = this._renderer;
        this._cleanups = this._ngZone.runOutsideAngular(() => [n.listen(i, "pointerdown", this._pointerDownListener, o), n.listen(i, "click", this._clickListener, o), n.listen(i, "auxclick", this._clickListener, o), n.listen(i, "contextmenu", this._clickListener, o)]), this._platform.IOS && !this._cursorStyleIsSet && (this._cursorOriginalValue = i.style.cursor, i.style.cursor = "pointer", this._cursorStyleIsSet = !0), this._isAttached = !0;
    } }
    detach() { this._isAttached && (this._cleanups?.forEach(e => e()), this._cleanups = void 0, this._platform.IOS && this._cursorStyleIsSet && (this._document.body.style.cursor = this._cursorOriginalValue, this._cursorStyleIsSet = !1), this._isAttached = !1); }
    _pointerDownListener = e => { this._pointerDownEventTarget = D(e); };
    _clickListener = e => { let i = D(e), o = e.type === "click" && this._pointerDownEventTarget ? this._pointerDownEventTarget : i; this._pointerDownEventTarget = null; let n = this._attachedOverlays.slice(); for (let r = n.length - 1; r > -1; r--) {
        let a = n[r], h = a._outsidePointerEvents;
        if (!(!a.hasAttached() || !this.canReceiveEvent(a, e, h))) {
            if (pt(a.overlayElement, i) || pt(a.overlayElement, o))
                break;
            this._ngZone ? this._ngZone.run(() => h.next(e)) : h.next(e);
        }
    } };
    static \u0275fac = (() => { let e; return function (o) { return (e || (e = f.\u0275\u0275getInheritedFactory(s)))(o || s); }; })();
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })();
function pt(s, t) { let e = typeof ShadowRoot < "u" && ShadowRoot, i = t; for (; i;) {
    if (i === s)
        return !0;
    i = e && i instanceof ShadowRoot ? i.host : i.parentNode;
} return !1; }
var bt = (() => {
    class s {
        static \u0275fac = function (i) { return new (i || s); };
        static \u0275cmp = f.\u0275\u0275defineComponent({ type: s, selectors: [["ng-component"]], hostAttrs: ["cdk-overlay-style-loader", ""], decls: 0, vars: 0, template: function (i, o) { }, styles: [`.cdk-overlay-container, .cdk-global-overlay-wrapper {
  pointer-events: none;
  top: 0;
  left: 0;
  height: 100%;
  width: 100%;
}

.cdk-overlay-container {
  position: fixed;
}
@layer cdk-overlay {
  .cdk-overlay-container {
    z-index: 1000;
  }
}
.cdk-overlay-container:empty {
  display: none;
}

.cdk-global-overlay-wrapper {
  display: flex;
  position: absolute;
}
@layer cdk-overlay {
  .cdk-global-overlay-wrapper {
    z-index: 1000;
  }
}

.cdk-overlay-pane {
  position: absolute;
  pointer-events: auto;
  box-sizing: border-box;
  display: flex;
  max-width: 100%;
  max-height: 100%;
}
@layer cdk-overlay {
  .cdk-overlay-pane {
    z-index: 1000;
  }
}

.cdk-overlay-backdrop {
  position: absolute;
  top: 0;
  bottom: 0;
  left: 0;
  right: 0;
  pointer-events: auto;
  -webkit-tap-highlight-color: transparent;
  opacity: 0;
  touch-action: manipulation;
}
@layer cdk-overlay {
  .cdk-overlay-backdrop {
    z-index: 1000;
    transition: opacity 400ms cubic-bezier(0.25, 0.8, 0.25, 1);
  }
}
@media (prefers-reduced-motion) {
  .cdk-overlay-backdrop {
    transition-duration: 1ms;
  }
}

.cdk-overlay-backdrop-showing {
  opacity: 1;
}
@media (forced-colors: active) {
  .cdk-overlay-backdrop-showing {
    opacity: 0.6;
  }
}

@layer cdk-overlay {
  .cdk-overlay-dark-backdrop {
    background: rgba(0, 0, 0, 0.32);
  }
}

.cdk-overlay-transparent-backdrop {
  transition: visibility 1ms linear, opacity 1ms linear;
  visibility: hidden;
  opacity: 1;
}
.cdk-overlay-transparent-backdrop.cdk-overlay-backdrop-showing, .cdk-high-contrast-active .cdk-overlay-transparent-backdrop {
  opacity: 0;
  visibility: visible;
}

.cdk-overlay-backdrop-noop-animation {
  transition: none;
}

.cdk-overlay-connected-position-bounding-box {
  position: absolute;
  display: flex;
  flex-direction: column;
  min-width: 1px;
  min-height: 1px;
}
@layer cdk-overlay {
  .cdk-overlay-connected-position-bounding-box {
    z-index: 1000;
  }
}

.cdk-global-scrollblock {
  position: fixed;
  width: 100%;
  overflow-y: scroll;
}

.cdk-overlay-popover {
  background: none;
  border: none;
  padding: 0;
  outline: 0;
  overflow: visible;
  position: fixed;
  pointer-events: none;
  white-space: normal;
  color: inherit;
  text-decoration: none;
  width: 100%;
  height: 100%;
  inset: auto;
  top: 0;
  left: 0;
}
.cdk-overlay-popover::backdrop {
  display: none;
}
.cdk-overlay-popover .cdk-overlay-backdrop {
  position: fixed;
  z-index: auto;
}
`], encapsulation: 2, changeDetection: 0 });
    }
    return s;
})(), wt = (() => { class s {
    _platform = p(M);
    _containerElement;
    _document = p(x);
    _styleLoader = p(Y);
    constructor() { }
    ngOnDestroy() { this._containerElement?.remove(); }
    getContainerElement() { return this._loadStyles(), this._containerElement || this._createContainer(), this._containerElement; }
    _createContainer() { let e = "cdk-overlay-container"; if (this._platform.isBrowser || L()) {
        let o = this._document.querySelectorAll(`.${e}[platform="server"], .${e}[platform="test"]`);
        for (let n = 0; n < o.length; n++)
            o[n].remove();
    } let i = this._document.createElement("div"); i.classList.add(e), L() ? i.setAttribute("platform", "test") : this._platform.isBrowser || i.setAttribute("platform", "server"), this._document.body.appendChild(i), this._containerElement = i; }
    _loadStyles() { this._styleLoader.load(bt); }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), Z = class {
    _renderer;
    _ngZone;
    element;
    _cleanupClick;
    _cleanupTransitionEnd;
    _fallbackTimeout;
    constructor(t, e, i, o) { this._renderer = e, this._ngZone = i, this.element = t.createElement("div"), this.element.classList.add("cdk-overlay-backdrop"), this._cleanupClick = e.listen(this.element, "click", o); }
    detach() { this._ngZone.runOutsideAngular(() => { let t = this.element; clearTimeout(this._fallbackTimeout), this._cleanupTransitionEnd?.(), this._cleanupTransitionEnd = this._renderer.listen(t, "transitionend", this.dispose), this._fallbackTimeout = setTimeout(this.dispose, 500), t.style.pointerEvents = "none", t.classList.remove("cdk-overlay-backdrop-showing"); }); }
    dispose = () => { clearTimeout(this._fallbackTimeout), this._cleanupClick?.(), this._cleanupTransitionEnd?.(), this._cleanupClick = this._cleanupTransitionEnd = this._fallbackTimeout = void 0, this.element.remove(); };
};
function q(s) { return s && s.nodeType === 1; }
var j = class {
    _portalOutlet;
    _host;
    _pane;
    _config;
    _ngZone;
    _keyboardDispatcher;
    _document;
    _location;
    _outsideClickDispatcher;
    _animationsDisabled;
    _injector;
    _renderer;
    _backdropClick = new k;
    _attachments = new k;
    _detachments = new k;
    _positionStrategy;
    _scrollStrategy;
    _locationChanges = O.EMPTY;
    _backdropRef = null;
    _detachContentMutationObserver;
    _detachContentAfterRenderRef;
    _disposed = !1;
    _previousHostParent;
    _keydownEvents = new k;
    _outsidePointerEvents = new k;
    _afterNextRenderRef;
    constructor(t, e, i, o, n, r, a, h, d, l = !1, c, g) { this._portalOutlet = t, this._host = e, this._pane = i, this._config = o, this._ngZone = n, this._keyboardDispatcher = r, this._document = a, this._location = h, this._outsideClickDispatcher = d, this._animationsDisabled = l, this._injector = c, this._renderer = g, o.scrollStrategy && (this._scrollStrategy = o.scrollStrategy, this._scrollStrategy.attach(this)), this._positionStrategy = o.positionStrategy; }
    get overlayElement() { return this._pane; }
    get backdropElement() { return this._backdropRef?.element || null; }
    get hostElement() { return this._host; }
    get eventPredicate() { return this._config?.eventPredicate || null; }
    attach(t) { if (this._disposed)
        return null; this._attachHost(); let e = this._portalOutlet.attach(t); return this._positionStrategy?.attach(this), this._updateStackingOrder(), this._updateElementSize(), this._updateElementDirection(), this._scrollStrategy && this._scrollStrategy.enable(), this._afterNextRenderRef?.destroy(), this._afterNextRenderRef = at(() => { this.hasAttached() && this.updatePosition(); }, { injector: this._injector }), this._togglePointerEvents(!0), this._config.hasBackdrop && this._attachBackdrop(), this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !0), this._attachments.next(), this._completeDetachContent(), this._keyboardDispatcher.add(this), this._config.disposeOnNavigation && (this._locationChanges = this._location.subscribe(() => this.dispose())), this._outsideClickDispatcher.add(this), typeof e?.onDestroy == "function" && e.onDestroy(() => { this.hasAttached() && this._ngZone.runOutsideAngular(() => Promise.resolve().then(() => this.detach())); }), e; }
    detach() { if (!this.hasAttached())
        return; this.detachBackdrop(), this._togglePointerEvents(!1), this._positionStrategy && this._positionStrategy.detach && this._positionStrategy.detach(), this._scrollStrategy && this._scrollStrategy.disable(); let t = this._portalOutlet.detach(); return this._detachments.next(), this._completeDetachContent(), this._keyboardDispatcher.remove(this), this._detachContentWhenEmpty(), this._locationChanges.unsubscribe(), this._outsideClickDispatcher.remove(this), t; }
    dispose() { if (this._disposed)
        return; let t = this.hasAttached(); this._positionStrategy && this._positionStrategy.dispose(), this._disposeScrollStrategy(), this._backdropRef?.dispose(), this._locationChanges.unsubscribe(), this._keyboardDispatcher.remove(this), this._portalOutlet.dispose(), this._attachments.complete(), this._backdropClick.complete(), this._keydownEvents.complete(), this._outsidePointerEvents.complete(), this._outsideClickDispatcher.remove(this), this._host?.remove(), this._afterNextRenderRef?.destroy(), this._previousHostParent = this._pane = this._host = this._backdropRef = null, t && this._detachments.next(), this._detachments.complete(), this._completeDetachContent(), this._disposed = !0; }
    hasAttached() { return this._portalOutlet.hasAttached(); }
    backdropClick() { return this._backdropClick; }
    attachments() { return this._attachments; }
    detachments() { return this._detachments; }
    keydownEvents() { return this._keydownEvents; }
    outsidePointerEvents() { return this._outsidePointerEvents; }
    getConfig() { return this._config; }
    updatePosition() { this._positionStrategy && this._positionStrategy.apply(); }
    updatePositionStrategy(t) { t !== this._positionStrategy && (this._positionStrategy && this._positionStrategy.dispose(), this._positionStrategy = t, this.hasAttached() && (t.attach(this), this.updatePosition())); }
    updateSize(t) { this._config = E(E({}, this._config), t), this._updateElementSize(); }
    setDirection(t) { this._config = Q(E({}, this._config), { direction: t }), this._updateElementDirection(); }
    addPanelClass(t) { this._pane && this._toggleClasses(this._pane, t, !0); }
    removePanelClass(t) { this._pane && this._toggleClasses(this._pane, t, !1); }
    getDirection() { let t = this._config.direction; return t ? typeof t == "string" ? t : t.value : "ltr"; }
    updateScrollStrategy(t) { t !== this._scrollStrategy && (this._disposeScrollStrategy(), this._scrollStrategy = t, this.hasAttached() && (t.attach(this), t.enable())); }
    _updateElementDirection() { this._host.setAttribute("dir", this.getDirection()); }
    _updateElementSize() { if (!this._pane)
        return; let t = this._pane.style; t.width = _(this._config.width), t.height = _(this._config.height), t.minWidth = _(this._config.minWidth), t.minHeight = _(this._config.minHeight), t.maxWidth = _(this._config.maxWidth), t.maxHeight = _(this._config.maxHeight); }
    _togglePointerEvents(t) { this._pane.style.pointerEvents = t ? "" : "none"; }
    _attachHost() { if (!this._host.parentElement) {
        let t = this._config.usePopover ? this._positionStrategy?.getPopoverInsertionPoint?.() : null;
        q(t) ? t.after(this._host) : t?.type === "parent" ? t.element.appendChild(this._host) : this._previousHostParent?.appendChild(this._host);
    } if (this._config.usePopover)
        try {
            this._host.showPopover();
        }
        catch { } }
    _attachBackdrop() { let t = "cdk-overlay-backdrop-showing"; this._backdropRef?.dispose(), this._backdropRef = new Z(this._document, this._renderer, this._ngZone, e => { this._backdropClick.next(e); }), this._animationsDisabled && this._backdropRef.element.classList.add("cdk-overlay-backdrop-noop-animation"), this._config.backdropClass && this._toggleClasses(this._backdropRef.element, this._config.backdropClass, !0), this._config.usePopover ? this._host.prepend(this._backdropRef.element) : this._host.parentElement.insertBefore(this._backdropRef.element, this._host), !this._animationsDisabled && typeof requestAnimationFrame < "u" ? this._ngZone.runOutsideAngular(() => { requestAnimationFrame(() => this._backdropRef?.element.classList.add(t)); }) : this._backdropRef.element.classList.add(t); }
    _updateStackingOrder() { !this._config.usePopover && this._host.nextSibling && this._host.parentNode.appendChild(this._host); }
    detachBackdrop() { this._animationsDisabled ? (this._backdropRef?.dispose(), this._backdropRef = null) : this._backdropRef?.detach(); }
    _toggleClasses(t, e, i) { let o = X(e || []).filter(n => !!n); o.length && (i ? t.classList.add(...o) : t.classList.remove(...o)); }
    _detachContentWhenEmpty() { let t = !1; try {
        this._detachContentAfterRenderRef = at(() => { t = !0, this._detachContent(); }, { injector: this._injector });
    }
    catch (e) {
        if (t)
            throw e;
        this._detachContent();
    } globalThis.MutationObserver && this._pane && (this._detachContentMutationObserver ||= new globalThis.MutationObserver(() => { this._detachContent(); }), this._detachContentMutationObserver.observe(this._pane, { childList: !0 })); }
    _detachContent() { (!this._pane || !this._host || this._pane.children.length === 0) && (this._pane && this._config.panelClass && this._toggleClasses(this._pane, this._config.panelClass, !1), this._host && this._host.parentElement && (this._previousHostParent = this._host.parentElement, this._host.remove()), this._completeDetachContent()); }
    _completeDetachContent() { this._detachContentAfterRenderRef?.destroy(), this._detachContentAfterRenderRef = void 0, this._detachContentMutationObserver?.disconnect(); }
    _disposeScrollStrategy() { let t = this._scrollStrategy; t?.disable(), t?.detach?.(); }
}, ft = "cdk-overlay-connected-position-bounding-box", Wt = /([A-Za-z%]+)$/;
function kt(s, t) { return new $(t, s.get(S), s.get(x), s.get(M), s.get(wt)); }
var $ = class {
    _viewportRuler;
    _document;
    _platform;
    _overlayContainer;
    _overlayRef;
    _isInitialRender = !1;
    _lastBoundingBoxSize = { width: 0, height: 0 };
    _isPushed = !1;
    _canPush = !0;
    _growAfterOpen = !1;
    _hasFlexibleDimensions = !0;
    _positionLocked = !1;
    _originRect;
    _overlayRect;
    _viewportRect;
    _containerRect;
    _viewportMargin = 0;
    _scrollables = [];
    _preferredPositions = [];
    _origin;
    _pane;
    _isDisposed = !1;
    _boundingBox = null;
    _lastPosition = null;
    _lastScrollVisibility = null;
    _positionChanges = new k;
    _resizeSubscription = O.EMPTY;
    _offsetX = 0;
    _offsetY = 0;
    _transformOriginSelector;
    _appliedPanelClasses = [];
    _previousPushAmount = null;
    _popoverLocation = "global";
    positionChanges = this._positionChanges;
    get positions() { return this._preferredPositions; }
    constructor(t, e, i, o, n) { this._viewportRuler = e, this._document = i, this._platform = o, this._overlayContainer = n, this.setOrigin(t); }
    attach(t) { this._overlayRef && this._overlayRef, this._validatePositions(), t.hostElement.classList.add(ft), this._overlayRef = t, this._boundingBox = t.hostElement, this._pane = t.overlayElement, this._isDisposed = !1, this._isInitialRender = !0, this._lastPosition = null, this._resizeSubscription.unsubscribe(), this._resizeSubscription = this._viewportRuler.change().subscribe(() => { this._isInitialRender = !0, this.apply(); }); }
    apply() { if (this._isDisposed || !this._platform.isBrowser)
        return; if (!this._isInitialRender && this._positionLocked && this._lastPosition) {
        this.reapplyLastPosition();
        return;
    } this._clearPanelClasses(), this._resetOverlayElementStyles(), this._resetBoundingBoxStyles(), this._viewportRect = this._getNarrowedViewportRect(), this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._containerRect = this._getContainerRect(); let t = this._originRect, e = this._overlayRect, i = this._viewportRect, o = this._containerRect, n = [], r; for (let a of this._preferredPositions) {
        let h = this._getOriginPoint(t, o, a), d = this._getOverlayPoint(h, e, a), l = this._getOverlayFit(d, e, i, a);
        if (l.isCompletelyWithinViewport) {
            this._isPushed = !1, this._applyPosition(a, h);
            return;
        }
        if (this._canFitWithFlexibleDimensions(l, d, i)) {
            n.push({ position: a, origin: h, overlayRect: e, boundingBoxRect: this._calculateBoundingBoxRect(h, a) });
            continue;
        }
        (!r || r.overlayFit.visibleArea < l.visibleArea) && (r = { overlayFit: l, overlayPoint: d, originPoint: h, position: a, overlayRect: e });
    } if (n.length) {
        let a = null, h = -1;
        for (let d of n) {
            let l = d.boundingBoxRect.width * d.boundingBoxRect.height * (d.position.weight || 1);
            l > h && (h = l, a = d);
        }
        this._isPushed = !1, this._applyPosition(a.position, a.origin);
        return;
    } if (this._canPush) {
        this._isPushed = !0, this._applyPosition(r.position, r.originPoint);
        return;
    } this._applyPosition(r.position, r.originPoint); }
    detach() { this._clearPanelClasses(), this._lastPosition = null, this._previousPushAmount = null, this._resizeSubscription.unsubscribe(); }
    dispose() { this._isDisposed || (this._boundingBox && b(this._boundingBox.style, { top: "", left: "", right: "", bottom: "", height: "", width: "", alignItems: "", justifyContent: "" }), this._pane && this._resetOverlayElementStyles(), this._overlayRef && this._overlayRef.hostElement.classList.remove(ft), this.detach(), this._positionChanges.complete(), this._overlayRef = this._boundingBox = null, this._isDisposed = !0); }
    reapplyLastPosition() { if (this._isDisposed || !this._platform.isBrowser)
        return; let t = this._lastPosition; t ? (this._originRect = this._getOriginRect(), this._overlayRect = this._pane.getBoundingClientRect(), this._viewportRect = this._getNarrowedViewportRect(), this._containerRect = this._getContainerRect(), this._applyPosition(t, this._getOriginPoint(this._originRect, this._containerRect, t))) : this.apply(); }
    withScrollableContainers(t) { return this._scrollables = t, this; }
    withPositions(t) { return this._preferredPositions = t, t.indexOf(this._lastPosition) === -1 && (this._lastPosition = null), this._validatePositions(), this; }
    withViewportMargin(t) { return this._viewportMargin = t, this; }
    withFlexibleDimensions(t = !0) { return this._hasFlexibleDimensions = t, this; }
    withGrowAfterOpen(t = !0) { return this._growAfterOpen = t, this; }
    withPush(t = !0) { return this._canPush = t, this; }
    withLockedPosition(t = !0) { return this._positionLocked = t, this; }
    setOrigin(t) { return this._origin = t, this; }
    withDefaultOffsetX(t) { return this._offsetX = t, this; }
    withDefaultOffsetY(t) { return this._offsetY = t, this; }
    withTransformOriginOn(t) { return this._transformOriginSelector = t, this; }
    withPopoverLocation(t) { return this._popoverLocation = t, this; }
    getPopoverInsertionPoint() { return this._popoverLocation === "global" ? null : this._popoverLocation !== "inline" ? this._popoverLocation : this._origin instanceof B ? this._origin.nativeElement : q(this._origin) ? this._origin : null; }
    _getOriginPoint(t, e, i) { let o; if (i.originX == "center")
        o = t.left + t.width / 2;
    else {
        let r = this._isRtl() ? t.right : t.left, a = this._isRtl() ? t.left : t.right;
        o = i.originX == "start" ? r : a;
    } e.left < 0 && (o -= e.left); let n; return i.originY == "center" ? n = t.top + t.height / 2 : n = i.originY == "top" ? t.top : t.bottom, e.top < 0 && (n -= e.top), { x: o, y: n }; }
    _getOverlayPoint(t, e, i) { let o; i.overlayX == "center" ? o = -e.width / 2 : i.overlayX === "start" ? o = this._isRtl() ? -e.width : 0 : o = this._isRtl() ? 0 : -e.width; let n; return i.overlayY == "center" ? n = -e.height / 2 : n = i.overlayY == "top" ? 0 : -e.height, { x: t.x + o, y: t.y + n }; }
    _getOverlayFit(t, e, i, o) { let n = gt(e), { x: r, y: a } = t, h = this._getOffset(o, "x"), d = this._getOffset(o, "y"); h && (r += h), d && (a += d); let l = 0 - r, c = r + n.width - i.width, g = 0 - a, y = a + n.height - i.height, u = this._subtractOverflows(n.width, l, c), v = this._subtractOverflows(n.height, g, y), J = u * v; return { visibleArea: J, isCompletelyWithinViewport: n.width * n.height === J, fitsInViewportVertically: v === n.height, fitsInViewportHorizontally: u == n.width }; }
    _canFitWithFlexibleDimensions(t, e, i) { if (this._hasFlexibleDimensions) {
        let o = i.bottom - e.y, n = i.right - e.x, r = _t(this._overlayRef.getConfig().minHeight), a = _t(this._overlayRef.getConfig().minWidth), h = t.fitsInViewportVertically || r != null && r <= o, d = t.fitsInViewportHorizontally || a != null && a <= n;
        return h && d;
    } return !1; }
    _pushOverlayOnScreen(t, e, i) { if (this._previousPushAmount && this._positionLocked)
        return { x: t.x + this._previousPushAmount.x, y: t.y + this._previousPushAmount.y }; let o = gt(e), n = this._viewportRect, r = Math.max(t.x + o.width - n.width, 0), a = Math.max(t.y + o.height - n.height, 0), h = Math.max(n.top - i.top - t.y, 0), d = Math.max(n.left - i.left - t.x, 0), l = 0, c = 0; return o.width <= n.width ? l = d || -r : l = t.x < this._getViewportMarginStart() ? n.left - i.left - t.x : 0, o.height <= n.height ? c = h || -a : c = t.y < this._getViewportMarginTop() ? n.top - i.top - t.y : 0, this._previousPushAmount = { x: l, y: c }, { x: t.x + l, y: t.y + c }; }
    _applyPosition(t, e) { if (this._setTransformOrigin(t), this._setOverlayElementStyles(e, t), this._setBoundingBoxStyles(e, t), t.panelClass && this._addPanelClasses(t.panelClass), this._positionChanges.observers.length) {
        let i = this._getScrollVisibility();
        if (t !== this._lastPosition || !this._lastScrollVisibility || !Ht(this._lastScrollVisibility, i)) {
            let o = new z(t, i);
            this._positionChanges.next(o);
        }
        this._lastScrollVisibility = i;
    } this._lastPosition = t, this._isInitialRender = !1; }
    _setTransformOrigin(t) { if (!this._transformOriginSelector)
        return; let e = this._boundingBox.querySelectorAll(this._transformOriginSelector), i, o = t.overlayY; t.overlayX === "center" ? i = "center" : this._isRtl() ? i = t.overlayX === "start" ? "right" : "left" : i = t.overlayX === "start" ? "left" : "right"; for (let n = 0; n < e.length; n++)
        e[n].style.transformOrigin = `${i} ${o}`; }
    _calculateBoundingBoxRect(t, e) { let i = this._viewportRect, o = this._isRtl(), n, r, a; if (e.overlayY === "top")
        r = t.y, n = i.height - r + this._getViewportMarginBottom();
    else if (e.overlayY === "bottom")
        a = i.height - t.y + this._getViewportMarginTop() + this._getViewportMarginBottom(), n = i.height - a + this._getViewportMarginTop();
    else {
        let y = Math.min(i.bottom - t.y + i.top, t.y), u = this._lastBoundingBoxSize.height;
        n = y * 2, r = t.y - y, n > u && !this._isInitialRender && !this._growAfterOpen && (r = t.y - u / 2);
    } let h = e.overlayX === "start" && !o || e.overlayX === "end" && o, d = e.overlayX === "end" && !o || e.overlayX === "start" && o, l, c, g; if (d)
        g = i.width - t.x + this._getViewportMarginStart() + this._getViewportMarginEnd(), l = t.x - this._getViewportMarginStart();
    else if (h)
        c = t.x, l = i.right - t.x - this._getViewportMarginEnd();
    else {
        let y = Math.min(i.right - t.x + i.left, t.x), u = this._lastBoundingBoxSize.width;
        l = y * 2, c = t.x - y, l > u && !this._isInitialRender && !this._growAfterOpen && (c = t.x - u / 2);
    } return { top: r, left: c, bottom: a, right: g, width: l, height: n }; }
    _setBoundingBoxStyles(t, e) { let i = this._calculateBoundingBoxRect(t, e); !this._isInitialRender && !this._growAfterOpen && (i.height = Math.min(i.height, this._lastBoundingBoxSize.height), i.width = Math.min(i.width, this._lastBoundingBoxSize.width)); let o = {}; if (this._hasExactPosition())
        o.top = o.left = "0", o.bottom = o.right = "auto", o.maxHeight = o.maxWidth = "", o.width = o.height = "100%";
    else {
        let n = this._overlayRef.getConfig().maxHeight, r = this._overlayRef.getConfig().maxWidth;
        o.width = _(i.width), o.height = _(i.height), o.top = _(i.top) || "auto", o.bottom = _(i.bottom) || "auto", o.left = _(i.left) || "auto", o.right = _(i.right) || "auto", e.overlayX === "center" ? o.alignItems = "center" : o.alignItems = e.overlayX === "end" ? "flex-end" : "flex-start", e.overlayY === "center" ? o.justifyContent = "center" : o.justifyContent = e.overlayY === "bottom" ? "flex-end" : "flex-start", n && (o.maxHeight = _(n)), r && (o.maxWidth = _(r));
    } this._lastBoundingBoxSize = i, b(this._boundingBox.style, o); }
    _resetBoundingBoxStyles() { b(this._boundingBox.style, { top: "0", left: "0", right: "0", bottom: "0", height: "", width: "", alignItems: "", justifyContent: "" }); }
    _resetOverlayElementStyles() { b(this._pane.style, { top: "", left: "", bottom: "", right: "", position: "", transform: "" }); }
    _setOverlayElementStyles(t, e) { let i = {}, o = this._hasExactPosition(), n = this._hasFlexibleDimensions, r = this._overlayRef.getConfig(); if (o) {
        let l = this._viewportRuler.getViewportScrollPosition();
        b(i, this._getExactOverlayY(e, t, l)), b(i, this._getExactOverlayX(e, t, l));
    }
    else
        i.position = "static"; let a = "", h = this._getOffset(e, "x"), d = this._getOffset(e, "y"); h && (a += `translateX(${h}px) `), d && (a += `translateY(${d}px)`), i.transform = a.trim(), r.maxHeight && (o ? i.maxHeight = _(r.maxHeight) : n && (i.maxHeight = "")), r.maxWidth && (o ? i.maxWidth = _(r.maxWidth) : n && (i.maxWidth = "")), b(this._pane.style, i); }
    _getExactOverlayY(t, e, i) { let o = { top: "", bottom: "" }, n = this._getOverlayPoint(e, this._overlayRect, t); if (this._isPushed && (n = this._pushOverlayOnScreen(n, this._overlayRect, i)), t.overlayY === "bottom") {
        let r = this._document.documentElement.clientHeight;
        o.bottom = `${r - (n.y + this._overlayRect.height)}px`;
    }
    else
        o.top = _(n.y); return o; }
    _getExactOverlayX(t, e, i) { let o = { left: "", right: "" }, n = this._getOverlayPoint(e, this._overlayRect, t); this._isPushed && (n = this._pushOverlayOnScreen(n, this._overlayRect, i)); let r; if (this._isRtl() ? r = t.overlayX === "end" ? "left" : "right" : r = t.overlayX === "end" ? "right" : "left", r === "right") {
        let a = this._document.documentElement.clientWidth;
        o.right = `${a - (n.x + this._overlayRect.width)}px`;
    }
    else
        o.left = _(n.x); return o; }
    _getScrollVisibility() { let t = this._getOriginRect(), e = this._pane.getBoundingClientRect(), i = this._scrollables.map(o => o.getElementRef().nativeElement.getBoundingClientRect()); return { isOriginClipped: ht(t, i), isOriginOutsideView: F(t, i), isOverlayClipped: ht(e, i), isOverlayOutsideView: F(e, i) }; }
    _subtractOverflows(t, ...e) { return e.reduce((i, o) => i - Math.max(o, 0), t); }
    _getNarrowedViewportRect() { let t = this._document.documentElement.clientWidth, e = this._document.documentElement.clientHeight, i = this._viewportRuler.getViewportScrollPosition(); return { top: i.top + this._getViewportMarginTop(), left: i.left + this._getViewportMarginStart(), right: i.left + t - this._getViewportMarginEnd(), bottom: i.top + e - this._getViewportMarginBottom(), width: t - this._getViewportMarginStart() - this._getViewportMarginEnd(), height: e - this._getViewportMarginTop() - this._getViewportMarginBottom() }; }
    _isRtl() { return this._overlayRef.getDirection() === "rtl"; }
    _hasExactPosition() { return !this._hasFlexibleDimensions || this._isPushed; }
    _getOffset(t, e) { return e === "x" ? t.offsetX == null ? this._offsetX : t.offsetX : t.offsetY == null ? this._offsetY : t.offsetY; }
    _validatePositions() { }
    _addPanelClasses(t) { this._pane && X(t).forEach(e => { e !== "" && this._appliedPanelClasses.indexOf(e) === -1 && (this._appliedPanelClasses.push(e), this._pane.classList.add(e)); }); }
    _clearPanelClasses() { this._pane && (this._appliedPanelClasses.forEach(t => { this._pane.classList.remove(t); }), this._appliedPanelClasses = []); }
    _getViewportMarginStart() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.start ?? 0; }
    _getViewportMarginEnd() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.end ?? 0; }
    _getViewportMarginTop() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.top ?? 0; }
    _getViewportMarginBottom() { return typeof this._viewportMargin == "number" ? this._viewportMargin : this._viewportMargin?.bottom ?? 0; }
    _getOriginRect() { let t = this._origin; if (t instanceof B)
        return t.nativeElement.getBoundingClientRect(); if (t instanceof Element)
        return t.getBoundingClientRect(); let e = t.width || 0, i = t.height || 0; return { top: t.y, bottom: t.y + i, left: t.x, right: t.x + e, height: i, width: e }; }
    _getContainerRect() { let t = this._overlayRef.getConfig().usePopover && this._popoverLocation !== "global", e = this._overlayContainer.getContainerElement(); t && (e.style.display = "block"); let i = e.getBoundingClientRect(); return t && (e.style.display = ""), i; }
};
function b(s, t) { for (let e in t)
    t.hasOwnProperty(e) && (s[e] = t[e]); return s; }
function _t(s) { if (typeof s != "number" && s != null) {
    let [t, e] = s.split(Wt);
    return !e || e === "px" ? parseFloat(t) : null;
} return s || null; }
function gt(s) { return { top: Math.floor(s.top), right: Math.floor(s.right), bottom: Math.floor(s.bottom), left: Math.floor(s.left), width: Math.floor(s.width), height: Math.floor(s.height) }; }
function Ht(s, t) { return s === t ? !0 : s.isOriginClipped === t.isOriginClipped && s.isOriginOutsideView === t.isOriginOutsideView && s.isOverlayClipped === t.isOverlayClipped && s.isOverlayOutsideView === t.isOverlayOutsideView; }
var ke = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }], Oe = [{ originX: "end", originY: "top", overlayX: "start", overlayY: "top" }, { originX: "end", originY: "bottom", overlayX: "start", overlayY: "bottom" }, { originX: "start", originY: "top", overlayX: "end", overlayY: "top" }, { originX: "start", originY: "bottom", overlayX: "end", overlayY: "bottom" }], ut = "cdk-global-overlay-wrapper";
function Ft(s) { return new K; }
var K = class {
    _overlayRef;
    _cssPosition = "static";
    _topOffset = "";
    _bottomOffset = "";
    _alignItems = "";
    _xPosition = "";
    _xOffset = "";
    _width = "";
    _height = "";
    _isDisposed = !1;
    attach(t) { let e = t.getConfig(); this._overlayRef = t, this._width && !e.width && t.updateSize({ width: this._width }), this._height && !e.height && t.updateSize({ height: this._height }), t.hostElement.classList.add(ut), this._isDisposed = !1; }
    top(t = "") { return this._bottomOffset = "", this._topOffset = t, this._alignItems = "flex-start", this; }
    left(t = "") { return this._xOffset = t, this._xPosition = "left", this; }
    bottom(t = "") { return this._topOffset = "", this._bottomOffset = t, this._alignItems = "flex-end", this; }
    right(t = "") { return this._xOffset = t, this._xPosition = "right", this; }
    start(t = "") { return this._xOffset = t, this._xPosition = "start", this; }
    end(t = "") { return this._xOffset = t, this._xPosition = "end", this; }
    width(t = "") { return this._overlayRef ? this._overlayRef.updateSize({ width: t }) : this._width = t, this; }
    height(t = "") { return this._overlayRef ? this._overlayRef.updateSize({ height: t }) : this._height = t, this; }
    centerHorizontally(t = "") { return this.left(t), this._xPosition = "center", this; }
    centerVertically(t = "") { return this.top(t), this._alignItems = "center", this; }
    apply() { if (!this._overlayRef || !this._overlayRef.hasAttached())
        return; let t = this._overlayRef.overlayElement.style, e = this._overlayRef.hostElement.style, i = this._overlayRef.getConfig(), { width: o, height: n, maxWidth: r, maxHeight: a } = i, h = (o === "100%" || o === "100vw") && (!r || r === "100%" || r === "100vw"), d = (n === "100%" || n === "100vh") && (!a || a === "100%" || a === "100vh"), l = this._xPosition, c = this._xOffset, g = this._overlayRef.getConfig().direction === "rtl", y = "", u = "", v = ""; h ? v = "flex-start" : l === "center" ? (v = "center", g ? u = c : y = c) : g ? l === "left" || l === "end" ? (v = "flex-end", y = c) : (l === "right" || l === "start") && (v = "flex-start", u = c) : l === "left" || l === "start" ? (v = "flex-start", y = c) : (l === "right" || l === "end") && (v = "flex-end", u = c), t.position = this._cssPosition, t.marginLeft = h ? "0" : y, t.marginTop = d ? "0" : this._topOffset, t.marginBottom = this._bottomOffset, t.marginRight = h ? "0" : u, e.justifyContent = v, e.alignItems = d ? "flex-start" : this._alignItems; }
    dispose() { if (this._isDisposed || !this._overlayRef)
        return; let t = this._overlayRef.overlayElement.style, e = this._overlayRef.hostElement, i = e.style; e.classList.remove(ut), i.justifyContent = i.alignItems = t.marginTop = t.marginBottom = t.marginLeft = t.marginRight = t.position = "", this._overlayRef = null, this._isDisposed = !0; }
}, Nt = (() => { class s {
    _injector = p(R);
    constructor() { }
    global() { return Ft(); }
    flexibleConnectedTo(e) { return kt(this._injector, e); }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), Ot = new U("OVERLAY_DEFAULT_CONFIG");
function Ct(s, t) { s.get(Y).load(bt); let e = s.get(wt), i = s.get(x), o = s.get(et), n = s.get(Pt), r = s.get(V), a = s.get(xt, null, { optional: !0 }) || s.get(G).createRenderer(null, null), h = new A(t), d = s.get(Ot, null, { optional: !0 })?.usePopover ?? !0; h.direction = h.direction || r.value, "showPopover" in i.body ? h.usePopover = t?.usePopover ?? d : h.usePopover = !1; let l = i.createElement("div"), c = i.createElement("div"); l.id = o.getId("cdk-overlay-"), l.classList.add("cdk-overlay-pane"), c.appendChild(l), h.usePopover && (c.setAttribute("popover", "manual"), c.classList.add("cdk-overlay-popover")); let g = h.usePopover ? h.positionStrategy?.getPopoverInsertionPoint?.() : null; return q(g) ? g.after(c) : g?.type === "parent" ? g.element.appendChild(c) : e.getContainerElement().appendChild(c), new j(new ot(l, n, s), c, l, h, s.get(C), s.get(It), i, s.get(Bt), s.get(Tt), t?.disableAnimations ?? s.get(Rt, null, { optional: !0 }) === "NoopAnimations", s.get(Et), a); }
var zt = (() => { class s {
    scrollStrategies = p(Lt);
    _positionBuilder = p(Nt);
    _injector = p(R);
    constructor() { }
    create(e) { return Ct(this._injector, e); }
    position() { return this._positionBuilder; }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275prov = f.\u0275\u0275defineInjectable({ token: s, factory: s.\u0275fac, providedIn: "root" });
} return s; })(), Zt = [{ originX: "start", originY: "bottom", overlayX: "start", overlayY: "top" }, { originX: "start", originY: "top", overlayX: "start", overlayY: "bottom" }, { originX: "end", originY: "top", overlayX: "end", overlayY: "bottom" }, { originX: "end", originY: "bottom", overlayX: "end", overlayY: "top" }], jt = new U("cdk-connected-overlay-scroll-strategy", { providedIn: "root", factory: () => { let s = p(R); return () => vt(s); } }), yt = (() => { class s {
    elementRef = p(B);
    constructor() { }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275dir = f.\u0275\u0275defineDirective({ type: s, selectors: [["", "cdk-overlay-origin", ""], ["", "overlay-origin", ""], ["", "cdkOverlayOrigin", ""]], exportAs: ["cdkOverlayOrigin"] });
} return s; })(), $t = new U("cdk-connected-overlay-default-config"), Ce = (() => { class s {
    _dir = p(V, { optional: !0 });
    _injector = p(R);
    _overlayRef;
    _templatePortal;
    _backdropSubscription = O.EMPTY;
    _attachSubscription = O.EMPTY;
    _detachSubscription = O.EMPTY;
    _positionSubscription = O.EMPTY;
    _offsetX;
    _offsetY;
    _position;
    _scrollStrategyFactory = p(jt);
    _ngZone = p(C);
    origin;
    positions;
    positionStrategy;
    get offsetX() { return this._offsetX; }
    set offsetX(e) { this._offsetX = e, this._position && this._updatePositionStrategy(this._position); }
    get offsetY() { return this._offsetY; }
    set offsetY(e) { this._offsetY = e, this._position && this._updatePositionStrategy(this._position); }
    width;
    height;
    minWidth;
    minHeight;
    backdropClass;
    panelClass;
    viewportMargin = 0;
    scrollStrategy;
    open = !1;
    disableClose = !1;
    transformOriginSelector;
    hasBackdrop = !1;
    lockPosition = !1;
    flexibleDimensions = !1;
    growAfterOpen = !1;
    push = !1;
    disposeOnNavigation = !1;
    usePopover;
    matchWidth = !1;
    set _config(e) { typeof e != "string" && this._assignConfig(e); }
    backdropClick = new w;
    positionChange = new w;
    attach = new w;
    detach = new w;
    overlayKeydown = new w;
    overlayOutsideClick = new w;
    constructor() { let e = p(Dt), i = p(Mt), o = p($t, { optional: !0 }), n = p(Ot, { optional: !0 }); this.usePopover = n?.usePopover === !1 ? null : "global", this._templatePortal = new st(e, i), this.scrollStrategy = this._scrollStrategyFactory(), o && this._assignConfig(o); }
    get overlayRef() { return this._overlayRef; }
    get dir() { return this._dir ? this._dir.value : "ltr"; }
    ngOnDestroy() { this._attachSubscription.unsubscribe(), this._detachSubscription.unsubscribe(), this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this._overlayRef?.dispose(); }
    ngOnChanges(e) { this._position && (this._updatePositionStrategy(this._position), this._overlayRef?.updateSize({ width: this._getWidth(), minWidth: this.minWidth, height: this.height, minHeight: this.minHeight }), e.origin && this.open && this._position.apply()), e.open && (this.open ? this.attachOverlay() : this.detachOverlay()); }
    _createOverlay() { (!this.positions || !this.positions.length) && (this.positions = Zt); let e = this._overlayRef = Ct(this._injector, this._buildConfig()); this._attachSubscription = e.attachments().subscribe(() => this.attach.emit()), this._detachSubscription = e.detachments().subscribe(() => this.detach.emit()), e.keydownEvents().subscribe(i => { this.overlayKeydown.next(i), i.keyCode === 27 && !this.disableClose && !tt(i) && (i.preventDefault(), this.detachOverlay()); }), this._overlayRef.outsidePointerEvents().subscribe(i => { let o = this._getOriginElement(), n = D(i); (!o || o !== n && !o.contains(n)) && this.overlayOutsideClick.next(i); }); }
    _buildConfig() { let e = this._position = this.positionStrategy || this._createPositionStrategy(), i = new A({ direction: this._dir || "ltr", positionStrategy: e, scrollStrategy: this.scrollStrategy, hasBackdrop: this.hasBackdrop, disposeOnNavigation: this.disposeOnNavigation, usePopover: !!this.usePopover }); return (this.height || this.height === 0) && (i.height = this.height), (this.minWidth || this.minWidth === 0) && (i.minWidth = this.minWidth), (this.minHeight || this.minHeight === 0) && (i.minHeight = this.minHeight), this.backdropClass && (i.backdropClass = this.backdropClass), this.panelClass && (i.panelClass = this.panelClass), i; }
    _updatePositionStrategy(e) { let i = this.positions.map(o => ({ originX: o.originX, originY: o.originY, overlayX: o.overlayX, overlayY: o.overlayY, offsetX: o.offsetX || this.offsetX, offsetY: o.offsetY || this.offsetY, panelClass: o.panelClass || void 0 })); return e.setOrigin(this._getOrigin()).withPositions(i).withFlexibleDimensions(this.flexibleDimensions).withPush(this.push).withGrowAfterOpen(this.growAfterOpen).withViewportMargin(this.viewportMargin).withLockedPosition(this.lockPosition).withTransformOriginOn(this.transformOriginSelector).withPopoverLocation(this.usePopover === null ? "global" : this.usePopover); }
    _createPositionStrategy() { let e = kt(this._injector, this._getOrigin()); return this._updatePositionStrategy(e), e; }
    _getOrigin() { return this.origin instanceof yt ? this.origin.elementRef : this.origin; }
    _getOriginElement() { return this.origin instanceof yt ? this.origin.elementRef.nativeElement : this.origin instanceof B ? this.origin.nativeElement : typeof Element < "u" && this.origin instanceof Element ? this.origin : null; }
    _getWidth() { return this.width ? this.width : this.matchWidth ? this._getOriginElement()?.getBoundingClientRect?.().width : void 0; }
    attachOverlay() { this._overlayRef || this._createOverlay(); let e = this._overlayRef; e.getConfig().hasBackdrop = this.hasBackdrop, e.updateSize({ width: this._getWidth() }), e.hasAttached() || e.attach(this._templatePortal), this.hasBackdrop ? this._backdropSubscription = e.backdropClick().subscribe(i => this.backdropClick.emit(i)) : this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this.positionChange.observers.length > 0 && (this._positionSubscription = this._position.positionChanges.pipe(Yt(() => this.positionChange.observers.length > 0)).subscribe(i => { this._ngZone.run(() => this.positionChange.emit(i)), this.positionChange.observers.length === 0 && this._positionSubscription.unsubscribe(); })), this.open = !0; }
    detachOverlay() { this._overlayRef?.detach(), this._backdropSubscription.unsubscribe(), this._positionSubscription.unsubscribe(), this.open = !1; }
    _assignConfig(e) { this.origin = e.origin ?? this.origin, this.positions = e.positions ?? this.positions, this.positionStrategy = e.positionStrategy ?? this.positionStrategy, this.offsetX = e.offsetX ?? this.offsetX, this.offsetY = e.offsetY ?? this.offsetY, this.width = e.width ?? this.width, this.height = e.height ?? this.height, this.minWidth = e.minWidth ?? this.minWidth, this.minHeight = e.minHeight ?? this.minHeight, this.backdropClass = e.backdropClass ?? this.backdropClass, this.panelClass = e.panelClass ?? this.panelClass, this.viewportMargin = e.viewportMargin ?? this.viewportMargin, this.scrollStrategy = e.scrollStrategy ?? this.scrollStrategy, this.disableClose = e.disableClose ?? this.disableClose, this.transformOriginSelector = e.transformOriginSelector ?? this.transformOriginSelector, this.hasBackdrop = e.hasBackdrop ?? this.hasBackdrop, this.lockPosition = e.lockPosition ?? this.lockPosition, this.flexibleDimensions = e.flexibleDimensions ?? this.flexibleDimensions, this.growAfterOpen = e.growAfterOpen ?? this.growAfterOpen, this.push = e.push ?? this.push, this.disposeOnNavigation = e.disposeOnNavigation ?? this.disposeOnNavigation, this.usePopover = e.usePopover ?? this.usePopover, this.matchWidth = e.matchWidth ?? this.matchWidth; }
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275dir = f.\u0275\u0275defineDirective({ type: s, selectors: [["", "cdk-connected-overlay", ""], ["", "connected-overlay", ""], ["", "cdkConnectedOverlay", ""]], inputs: { origin: [0, "cdkConnectedOverlayOrigin", "origin"], positions: [0, "cdkConnectedOverlayPositions", "positions"], positionStrategy: [0, "cdkConnectedOverlayPositionStrategy", "positionStrategy"], offsetX: [0, "cdkConnectedOverlayOffsetX", "offsetX"], offsetY: [0, "cdkConnectedOverlayOffsetY", "offsetY"], width: [0, "cdkConnectedOverlayWidth", "width"], height: [0, "cdkConnectedOverlayHeight", "height"], minWidth: [0, "cdkConnectedOverlayMinWidth", "minWidth"], minHeight: [0, "cdkConnectedOverlayMinHeight", "minHeight"], backdropClass: [0, "cdkConnectedOverlayBackdropClass", "backdropClass"], panelClass: [0, "cdkConnectedOverlayPanelClass", "panelClass"], viewportMargin: [0, "cdkConnectedOverlayViewportMargin", "viewportMargin"], scrollStrategy: [0, "cdkConnectedOverlayScrollStrategy", "scrollStrategy"], open: [0, "cdkConnectedOverlayOpen", "open"], disableClose: [0, "cdkConnectedOverlayDisableClose", "disableClose"], transformOriginSelector: [0, "cdkConnectedOverlayTransformOriginOn", "transformOriginSelector"], hasBackdrop: [2, "cdkConnectedOverlayHasBackdrop", "hasBackdrop", m], lockPosition: [2, "cdkConnectedOverlayLockPosition", "lockPosition", m], flexibleDimensions: [2, "cdkConnectedOverlayFlexibleDimensions", "flexibleDimensions", m], growAfterOpen: [2, "cdkConnectedOverlayGrowAfterOpen", "growAfterOpen", m], push: [2, "cdkConnectedOverlayPush", "push", m], disposeOnNavigation: [2, "cdkConnectedOverlayDisposeOnNavigation", "disposeOnNavigation", m], usePopover: [0, "cdkConnectedOverlayUsePopover", "usePopover"], matchWidth: [2, "cdkConnectedOverlayMatchWidth", "matchWidth", m], _config: [0, "cdkConnectedOverlay", "_config"] }, outputs: { backdropClick: "backdropClick", positionChange: "positionChange", attach: "attach", detach: "detach", overlayKeydown: "overlayKeydown", overlayOutsideClick: "overlayOutsideClick" }, exportAs: ["cdkConnectedOverlay"], features: [f.\u0275\u0275NgOnChangesFeature] });
} return s; })(), Se = (() => { class s {
    static \u0275fac = function (i) { return new (i || s); };
    static \u0275mod = f.\u0275\u0275defineNgModule({ type: s });
    static \u0275inj = f.\u0275\u0275defineInjector({ providers: [zt], imports: [it, nt, T, T] });
} return s; })();
export { Xt as a, W as b, Vt as c, H as d, me as e, P as f, vt as g, N as h, Lt as i, A as j, ct as k, dt as l, z as m, be as n, we as o, It as p, Tt as q, wt as r, j as s, kt as t, $ as u, ke as v, Oe as w, Ft as x, K as y, Nt as z, Ot as A, Ct as B, zt as C, yt as D, $t as E, Ce as F, Se as G };
