function Y(a, t, s) { if (a && a.length) {
    let [e, n] = t, o = Math.PI / 180 * s, r = Math.cos(o), h = Math.sin(o);
    for (let i of a) {
        let [l, c] = i;
        i[0] = (l - e) * r - (c - n) * h + e, i[1] = (l - e) * h + (c - n) * r + n;
    }
} }
function zt(a, t) { return a[0] === t[0] && a[1] === t[1]; }
function Wt(a, t, s, e = 1) { let n = s, o = Math.max(t, .1), r = a[0] && a[0][0] && typeof a[0][0] == "number" ? [a] : a, h = [0, 0]; if (n)
    for (let l of r)
        Y(l, h, n); let i = (function (l, c, d) { let p = []; for (let M of l) {
    let m = [...M];
    zt(m[0], m[m.length - 1]) || m.push([m[0][0], m[0][1]]), m.length > 2 && p.push(m);
} let u = []; c = Math.max(c, .1); let f = []; for (let M of p)
    for (let m = 0; m < M.length - 1; m++) {
        let P = M[m], x = M[m + 1];
        if (P[1] !== x[1]) {
            let w = Math.min(P[1], x[1]);
            f.push({ ymin: w, ymax: Math.max(P[1], x[1]), x: w === P[1] ? P[0] : x[0], islope: (x[0] - P[0]) / (x[1] - P[1]) });
        }
    } if (f.sort((M, m) => M.ymin < m.ymin ? -1 : M.ymin > m.ymin ? 1 : M.x < m.x ? -1 : M.x > m.x ? 1 : M.ymax === m.ymax ? 0 : (M.ymax - m.ymax) / Math.abs(M.ymax - m.ymax)), !f.length)
    return u; let g = [], k = f[0].ymin, b = 0; for (; g.length || f.length;) {
    if (f.length) {
        let M = -1;
        for (let m = 0; m < f.length && !(f[m].ymin > k); m++)
            M = m;
        f.splice(0, M + 1).forEach(m => { g.push({ s: k, edge: m }); });
    }
    if (g = g.filter(M => !(M.edge.ymax <= k)), g.sort((M, m) => M.edge.x === m.edge.x ? 0 : (M.edge.x - m.edge.x) / Math.abs(M.edge.x - m.edge.x)), (d !== 1 || b % c == 0) && g.length > 1)
        for (let M = 0; M < g.length; M += 2) {
            let m = M + 1;
            if (m >= g.length)
                break;
            let P = g[M].edge, x = g[m].edge;
            u.push([[Math.round(P.x), k], [Math.round(x.x), k]]);
        }
    k += d, g.forEach(M => { M.edge.x = M.edge.x + d * M.edge.islope; }), b++;
} return u; })(r, o, e); if (n) {
    for (let l of r)
        Y(l, h, -n);
    (function (l, c, d) { let p = []; l.forEach(u => p.push(...u)), Y(p, c, d); })(i, h, -n);
} return i; }
function F(a, t) { var s; let e = t.hachureAngle + 90, n = t.hachureGap; n < 0 && (n = 4 * t.strokeWidth), n = Math.round(Math.max(n, .1)); let o = 1; return t.roughness >= 1 && (((s = t.randomizer) === null || s === void 0 ? void 0 : s.next()) || Math.random()) > .7 && (o = n), Wt(a, n, e, o || 1); }
var q = class {
    constructor(t) { this.helper = t; }
    fillPolygons(t, s) { return this._fillPolygons(t, s); }
    _fillPolygons(t, s) { let e = F(t, s); return { type: "fillSketch", ops: this.renderLines(e, s) }; }
    renderLines(t, s) { let e = []; for (let n of t)
        e.push(...this.helper.doubleLineOps(n[0][0], n[0][1], n[1][0], n[1][1], s)); return e; }
};
function X(a) { let t = a[0], s = a[1]; return Math.sqrt(Math.pow(t[0] - s[0], 2) + Math.pow(t[1] - s[1], 2)); }
var at = class extends q {
    fillPolygons(t, s) { let e = s.hachureGap; e < 0 && (e = 4 * s.strokeWidth), e = Math.max(e, .1); let n = F(t, Object.assign({}, s, { hachureGap: e })), o = Math.PI / 180 * s.hachureAngle, r = [], h = .5 * e * Math.cos(o), i = .5 * e * Math.sin(o); for (let [l, c] of n)
        X([l, c]) && r.push([[l[0] - h, l[1] + i], [...c]], [[l[0] + h, l[1] - i], [...c]]); return { type: "fillSketch", ops: this.renderLines(r, s) }; }
}, ot = class extends q {
    fillPolygons(t, s) { let e = this._fillPolygons(t, s), n = Object.assign({}, s, { hachureAngle: s.hachureAngle + 90 }), o = this._fillPolygons(t, n); return e.ops = e.ops.concat(o.ops), e; }
}, ht = class {
    constructor(t) { this.helper = t; }
    fillPolygons(t, s) { let e = F(t, s = Object.assign({}, s, { hachureAngle: 0 })); return this.dotsOnLines(e, s); }
    dotsOnLines(t, s) { let e = [], n = s.hachureGap; n < 0 && (n = 4 * s.strokeWidth), n = Math.max(n, .1); let o = s.fillWeight; o < 0 && (o = s.strokeWidth / 2); let r = n / 4; for (let h of t) {
        let i = X(h), l = i / n, c = Math.ceil(l) - 1, d = i - c * n, p = (h[0][0] + h[1][0]) / 2 - n / 4, u = Math.min(h[0][1], h[1][1]);
        for (let f = 0; f < c; f++) {
            let g = u + d + f * n, k = p - r + 2 * Math.random() * r, b = g - r + 2 * Math.random() * r, M = this.helper.ellipse(k, b, o, o, s);
            e.push(...M.ops);
        }
    } return { type: "fillSketch", ops: e }; }
}, rt = class {
    constructor(t) { this.helper = t; }
    fillPolygons(t, s) { let e = F(t, s); return { type: "fillSketch", ops: this.dashedLine(e, s) }; }
    dashedLine(t, s) { let e = s.dashOffset < 0 ? s.hachureGap < 0 ? 4 * s.strokeWidth : s.hachureGap : s.dashOffset, n = s.dashGap < 0 ? s.hachureGap < 0 ? 4 * s.strokeWidth : s.hachureGap : s.dashGap, o = []; return t.forEach(r => { let h = X(r), i = Math.floor(h / (e + n)), l = (h + n - i * (e + n)) / 2, c = r[0], d = r[1]; c[0] > d[0] && (c = r[1], d = r[0]); let p = Math.atan((d[1] - c[1]) / (d[0] - c[0])); for (let u = 0; u < i; u++) {
        let f = u * (e + n), g = f + e, k = [c[0] + f * Math.cos(p) + l * Math.cos(p), c[1] + f * Math.sin(p) + l * Math.sin(p)], b = [c[0] + g * Math.cos(p) + l * Math.cos(p), c[1] + g * Math.sin(p) + l * Math.sin(p)];
        o.push(...this.helper.doubleLineOps(k[0], k[1], b[0], b[1], s));
    } }), o; }
}, it = class {
    constructor(t) { this.helper = t; }
    fillPolygons(t, s) { let e = s.hachureGap < 0 ? 4 * s.strokeWidth : s.hachureGap, n = s.zigzagOffset < 0 ? e : s.zigzagOffset, o = F(t, s = Object.assign({}, s, { hachureGap: e + n })); return { type: "fillSketch", ops: this.zigzagLines(o, n, s) }; }
    zigzagLines(t, s, e) { let n = []; return t.forEach(o => { let r = X(o), h = Math.round(r / (2 * s)), i = o[0], l = o[1]; i[0] > l[0] && (i = o[1], l = o[0]); let c = Math.atan((l[1] - i[1]) / (l[0] - i[0])); for (let d = 0; d < h; d++) {
        let p = 2 * d * s, u = 2 * (d + 1) * s, f = Math.sqrt(2 * Math.pow(s, 2)), g = [i[0] + p * Math.cos(c), i[1] + p * Math.sin(c)], k = [i[0] + u * Math.cos(c), i[1] + u * Math.sin(c)], b = [g[0] + f * Math.cos(c + Math.PI / 4), g[1] + f * Math.sin(c + Math.PI / 4)];
        n.push(...this.helper.doubleLineOps(g[0], g[1], b[0], b[1], e), ...this.helper.doubleLineOps(b[0], b[1], k[0], k[1], e));
    } }), n; }
}, S = {}, ct = class {
    constructor(t) { this.seed = t; }
    next() { return this.seed ? (2 ** 31 - 1 & (this.seed = Math.imul(48271, this.seed))) / 2 ** 31 : Math.random(); }
}, Et = 0, tt = 1, bt = 2, Z = { A: 7, a: 7, C: 6, c: 6, H: 1, h: 1, L: 2, l: 2, M: 2, m: 2, Q: 4, q: 4, S: 4, s: 4, T: 2, t: 2, V: 1, v: 1, Z: 0, z: 0 };
function et(a, t) { return a.type === t; }
function gt(a) { let t = [], s = (function (r) { let h = new Array; for (; r !== "";)
    if (r.match(/^([ \t\r\n,]+)/))
        r = r.substr(RegExp.$1.length);
    else if (r.match(/^([aAcChHlLmMqQsStTvVzZ])/))
        h[h.length] = { type: Et, text: RegExp.$1 }, r = r.substr(RegExp.$1.length);
    else {
        if (!r.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))
            return [];
        h[h.length] = { type: tt, text: `${parseFloat(RegExp.$1)}` }, r = r.substr(RegExp.$1.length);
    } return h[h.length] = { type: bt, text: "" }, h; })(a), e = "BOD", n = 0, o = s[n]; for (; !et(o, bt);) {
    let r = 0, h = [];
    if (e === "BOD") {
        if (o.text !== "M" && o.text !== "m")
            return gt("M0,0" + a);
        n++, r = Z[o.text], e = o.text;
    }
    else
        et(o, tt) ? r = Z[e] : (n++, r = Z[o.text], e = o.text);
    if (!(n + r < s.length))
        throw new Error("Path data ended short");
    for (let i = n; i < n + r; i++) {
        let l = s[i];
        if (!et(l, tt))
            throw new Error("Param not a number: " + e + "," + l.text);
        h[h.length] = +l.text;
    }
    if (typeof Z[e] != "number")
        throw new Error("Bad segment: " + e);
    {
        let i = { key: e, data: h };
        t.push(i), n += r, o = s[n], e === "M" && (e = "L"), e === "m" && (e = "l");
    }
} return t; }
function Ot(a) { let t = 0, s = 0, e = 0, n = 0, o = []; for (let { key: r, data: h } of a)
    switch (r) {
        case "M":
            o.push({ key: "M", data: [...h] }), [t, s] = h, [e, n] = h;
            break;
        case "m":
            t += h[0], s += h[1], o.push({ key: "M", data: [t, s] }), e = t, n = s;
            break;
        case "L":
            o.push({ key: "L", data: [...h] }), [t, s] = h;
            break;
        case "l":
            t += h[0], s += h[1], o.push({ key: "L", data: [t, s] });
            break;
        case "C":
            o.push({ key: "C", data: [...h] }), t = h[4], s = h[5];
            break;
        case "c": {
            let i = h.map((l, c) => c % 2 ? l + s : l + t);
            o.push({ key: "C", data: i }), t = i[4], s = i[5];
            break;
        }
        case "Q":
            o.push({ key: "Q", data: [...h] }), t = h[2], s = h[3];
            break;
        case "q": {
            let i = h.map((l, c) => c % 2 ? l + s : l + t);
            o.push({ key: "Q", data: i }), t = i[2], s = i[3];
            break;
        }
        case "A":
            o.push({ key: "A", data: [...h] }), t = h[5], s = h[6];
            break;
        case "a":
            t += h[5], s += h[6], o.push({ key: "A", data: [h[0], h[1], h[2], h[3], h[4], t, s] });
            break;
        case "H":
            o.push({ key: "H", data: [...h] }), t = h[0];
            break;
        case "h":
            t += h[0], o.push({ key: "H", data: [t] });
            break;
        case "V":
            o.push({ key: "V", data: [...h] }), s = h[0];
            break;
        case "v":
            s += h[0], o.push({ key: "V", data: [s] });
            break;
        case "S":
            o.push({ key: "S", data: [...h] }), t = h[2], s = h[3];
            break;
        case "s": {
            let i = h.map((l, c) => c % 2 ? l + s : l + t);
            o.push({ key: "S", data: i }), t = i[2], s = i[3];
            break;
        }
        case "T":
            o.push({ key: "T", data: [...h] }), t = h[0], s = h[1];
            break;
        case "t":
            t += h[0], s += h[1], o.push({ key: "T", data: [t, s] });
            break;
        case "Z":
        case "z": o.push({ key: "Z", data: [] }), t = e, s = n;
    } return o; }
function Lt(a) { let t = [], s = "", e = 0, n = 0, o = 0, r = 0, h = 0, i = 0; for (let { key: l, data: c } of a) {
    switch (l) {
        case "M":
            t.push({ key: "M", data: [...c] }), [e, n] = c, [o, r] = c;
            break;
        case "C":
            t.push({ key: "C", data: [...c] }), e = c[4], n = c[5], h = c[2], i = c[3];
            break;
        case "L":
            t.push({ key: "L", data: [...c] }), [e, n] = c;
            break;
        case "H":
            e = c[0], t.push({ key: "L", data: [e, n] });
            break;
        case "V":
            n = c[0], t.push({ key: "L", data: [e, n] });
            break;
        case "S": {
            let d = 0, p = 0;
            s === "C" || s === "S" ? (d = e + (e - h), p = n + (n - i)) : (d = e, p = n), t.push({ key: "C", data: [d, p, ...c] }), h = c[0], i = c[1], e = c[2], n = c[3];
            break;
        }
        case "T": {
            let [d, p] = c, u = 0, f = 0;
            s === "Q" || s === "T" ? (u = e + (e - h), f = n + (n - i)) : (u = e, f = n);
            let g = e + 2 * (u - e) / 3, k = n + 2 * (f - n) / 3, b = d + 2 * (u - d) / 3, M = p + 2 * (f - p) / 3;
            t.push({ key: "C", data: [g, k, b, M, d, p] }), h = u, i = f, e = d, n = p;
            break;
        }
        case "Q": {
            let [d, p, u, f] = c, g = e + 2 * (d - e) / 3, k = n + 2 * (p - n) / 3, b = u + 2 * (d - u) / 3, M = f + 2 * (p - f) / 3;
            t.push({ key: "C", data: [g, k, b, M, u, f] }), h = d, i = p, e = u, n = f;
            break;
        }
        case "A": {
            let d = Math.abs(c[0]), p = Math.abs(c[1]), u = c[2], f = c[3], g = c[4], k = c[5], b = c[6];
            d === 0 || p === 0 ? (t.push({ key: "C", data: [e, n, k, b, k, b] }), e = k, n = b) : (e !== k || n !== b) && (Tt(e, n, k, b, d, p, u, f, g).forEach(function (M) { t.push({ key: "C", data: M }); }), e = k, n = b);
            break;
        }
        case "Z": t.push({ key: "Z", data: [] }), e = o, n = r;
    }
    s = l;
} return t; }
function R(a, t, s) { return [a * Math.cos(s) - t * Math.sin(s), a * Math.sin(s) + t * Math.cos(s)]; }
function Tt(a, t, s, e, n, o, r, h, i, l) { let c = (d = r, Math.PI * d / 180); var d; let p = [], u = 0, f = 0, g = 0, k = 0; if (l)
    [u, f, g, k] = l;
else {
    [a, t] = R(a, t, -c), [s, e] = R(s, e, -c);
    let T = (a - s) / 2, v = (t - e) / 2, _ = T * T / (n * n) + v * v / (o * o);
    _ > 1 && (_ = Math.sqrt(_), n *= _, o *= _);
    let W = n * n, E = o * o, It = W * E - W * v * v - E * T * T, Ct = W * v * v + E * T * T, kt = (h === i ? -1 : 1) * Math.sqrt(Math.abs(It / Ct));
    g = kt * n * v / o + (a + s) / 2, k = kt * -o * T / n + (t + e) / 2, u = Math.asin(parseFloat(((t - k) / o).toFixed(9))), f = Math.asin(parseFloat(((e - k) / o).toFixed(9))), a < g && (u = Math.PI - u), s < g && (f = Math.PI - f), u < 0 && (u = 2 * Math.PI + u), f < 0 && (f = 2 * Math.PI + f), i && u > f && (u -= 2 * Math.PI), !i && f > u && (f -= 2 * Math.PI);
} let b = f - u; if (Math.abs(b) > 120 * Math.PI / 180) {
    let T = f, v = s, _ = e;
    f = i && f > u ? u + 120 * Math.PI / 180 * 1 : u + 120 * Math.PI / 180 * -1, p = Tt(s = g + n * Math.cos(f), e = k + o * Math.sin(f), v, _, n, o, r, 0, i, [f, T, g, k]);
} b = f - u; let M = Math.cos(u), m = Math.sin(u), P = Math.cos(f), x = Math.sin(f), w = Math.tan(b / 4), L = 4 / 3 * n * w, A = 4 / 3 * o * w, V = [a, t], D = [a + L * m, t - A * M], C = [s + L * x, e - A * P], Mt = [s, e]; if (D[0] = 2 * V[0] - D[0], D[1] = 2 * V[1] - D[1], l)
    return [D, C, Mt].concat(p); {
    p = [D, C, Mt].concat(p);
    let T = [];
    for (let v = 0; v < p.length; v += 3) {
        let _ = R(p[v][0], p[v][1], c), W = R(p[v + 1][0], p[v + 1][1], c), E = R(p[v + 2][0], p[v + 2][1], c);
        T.push([_[0], _[1], W[0], W[1], E[0], E[1]]);
    }
    return T;
} }
var Gt = { randOffset: function (a, t) { return y(a, t); }, randOffsetWithRange: function (a, t, s) { return J(a, t, s); }, ellipse: function (a, t, s, e, n) { let o = At(s, e, n); return lt(a, t, n, o).opset; }, doubleLineOps: function (a, t, s, e, n) { return I(a, t, s, e, n, !0); } };
function Dt(a, t, s, e, n) { return { type: "path", ops: I(a, t, s, e, n) }; }
function N(a, t, s) { let e = (a || []).length; if (e > 2) {
    let n = [];
    for (let o = 0; o < e - 1; o++)
        n.push(...I(a[o][0], a[o][1], a[o + 1][0], a[o + 1][1], s));
    return t && n.push(...I(a[e - 1][0], a[e - 1][1], a[0][0], a[0][1], s)), { type: "path", ops: n };
} return e === 2 ? Dt(a[0][0], a[0][1], a[1][0], a[1][1], s) : { type: "path", ops: [] }; }
function $t(a, t, s, e, n) { return (function (o, r) { return N(o, !0, r); })([[a, t], [a + s, t], [a + s, t + e], [a, t + e]], n); }
function yt(a, t) { if (a.length) {
    let s = typeof a[0][0] == "number" ? [a] : a, e = Q(s[0], 1 * (1 + .2 * t.roughness), t), n = t.disableMultiStroke ? [] : Q(s[0], 1.5 * (1 + .22 * t.roughness), xt(t));
    for (let o = 1; o < s.length; o++) {
        let r = s[o];
        if (r.length) {
            let h = Q(r, 1 * (1 + .2 * t.roughness), t), i = t.disableMultiStroke ? [] : Q(r, 1.5 * (1 + .22 * t.roughness), xt(t));
            for (let l of h)
                l.op !== "move" && e.push(l);
            for (let l of i)
                l.op !== "move" && n.push(l);
        }
    }
    return { type: "path", ops: e.concat(n) };
} return { type: "path", ops: [] }; }
function At(a, t, s) { let e = Math.sqrt(2 * Math.PI * Math.sqrt((Math.pow(a / 2, 2) + Math.pow(t / 2, 2)) / 2)), n = Math.ceil(Math.max(s.curveStepCount, s.curveStepCount / Math.sqrt(200) * e)), o = 2 * Math.PI / n, r = Math.abs(a / 2), h = Math.abs(t / 2), i = 1 - s.curveFitting; return r += y(r * i, s), h += y(h * i, s), { increment: o, rx: r, ry: h }; }
function lt(a, t, s, e) { let [n, o] = Pt(e.increment, a, t, e.rx, e.ry, 1, e.increment * J(.1, J(.4, 1, s), s), s), r = K(n, null, s); if (!s.disableMultiStroke && s.roughness !== 0) {
    let [h] = Pt(e.increment, a, t, e.rx, e.ry, 1.5, 0, s), i = K(h, null, s);
    r = r.concat(i);
} return { estimatedPoints: o, opset: { type: "path", ops: r } }; }
function mt(a, t, s, e, n, o, r, h, i) { let l = a, c = t, d = Math.abs(s / 2), p = Math.abs(e / 2); d += y(.01 * d, i), p += y(.01 * p, i); let u = n, f = o; for (; u < 0;)
    u += 2 * Math.PI, f += 2 * Math.PI; f - u > 2 * Math.PI && (u = 0, f = 2 * Math.PI); let g = 2 * Math.PI / i.curveStepCount, k = Math.min(g / 2, (f - u) / 2), b = vt(k, l, c, d, p, u, f, 1, i); if (!i.disableMultiStroke) {
    let M = vt(k, l, c, d, p, u, f, 1.5, i);
    b.push(...M);
} return r && (h ? b.push(...I(l, c, l + d * Math.cos(u), c + p * Math.sin(u), i), ...I(l, c, l + d * Math.cos(f), c + p * Math.sin(f), i)) : b.push({ op: "lineTo", data: [l, c] }, { op: "lineTo", data: [l + d * Math.cos(u), c + p * Math.sin(u)] })), { type: "path", ops: b }; }
function wt(a, t) { let s = Lt(Ot(gt(a))), e = [], n = [0, 0], o = [0, 0]; for (let { key: r, data: h } of s)
    switch (r) {
        case "M":
            o = [h[0], h[1]], n = [h[0], h[1]];
            break;
        case "L":
            e.push(...I(o[0], o[1], h[0], h[1], t)), o = [h[0], h[1]];
            break;
        case "C": {
            let [i, l, c, d, p, u] = h;
            e.push(...Rt(i, l, c, d, p, u, o, t)), o = [p, u];
            break;
        }
        case "Z": e.push(...I(o[0], o[1], n[0], n[1], t)), o = [n[0], n[1]];
    } return { type: "path", ops: e }; }
function st(a, t) { let s = []; for (let e of a)
    if (e.length) {
        let n = t.maxRandomnessOffset || 0, o = e.length;
        if (o > 2) {
            s.push({ op: "move", data: [e[0][0] + y(n, t), e[0][1] + y(n, t)] });
            for (let r = 1; r < o; r++)
                s.push({ op: "lineTo", data: [e[r][0] + y(n, t), e[r][1] + y(n, t)] });
        }
    } return { type: "fillPath", ops: s }; }
function G(a, t) { return (function (s, e) { let n = s.fillStyle || "hachure"; if (!S[n])
    switch (n) {
        case "zigzag":
            S[n] || (S[n] = new at(e));
            break;
        case "cross-hatch":
            S[n] || (S[n] = new ot(e));
            break;
        case "dots":
            S[n] || (S[n] = new ht(e));
            break;
        case "dashed":
            S[n] || (S[n] = new rt(e));
            break;
        case "zigzag-line":
            S[n] || (S[n] = new it(e));
            break;
        default: n = "hachure", S[n] || (S[n] = new q(e));
    } return S[n]; })(t, Gt).fillPolygons(a, t); }
function xt(a) { let t = Object.assign({}, a); return t.randomizer = void 0, a.seed && (t.seed = a.seed + 1), t; }
function _t(a) { return a.randomizer || (a.randomizer = new ct(a.seed || 0)), a.randomizer.next(); }
function J(a, t, s, e = 1) { return s.roughness * e * (_t(s) * (t - a) + a); }
function y(a, t, s = 1) { return J(-a, a, t, s); }
function I(a, t, s, e, n, o = !1) { let r = o ? n.disableMultiStrokeFill : n.disableMultiStroke, h = ut(a, t, s, e, n, !0, !1); if (r)
    return h; let i = ut(a, t, s, e, n, !0, !0); return h.concat(i); }
function ut(a, t, s, e, n, o, r) { let h = Math.pow(a - s, 2) + Math.pow(t - e, 2), i = Math.sqrt(h), l = 1; l = i < 200 ? 1 : i > 500 ? .4 : -.0016668 * i + 1.233334; let c = n.maxRandomnessOffset || 0; c * c * 100 > h && (c = i / 10); let d = c / 2, p = .2 + .2 * _t(n), u = n.bowing * n.maxRandomnessOffset * (e - t) / 200, f = n.bowing * n.maxRandomnessOffset * (a - s) / 200; u = y(u, n, l), f = y(f, n, l); let g = [], k = () => y(d, n, l), b = () => y(c, n, l), M = n.preserveVertices; return o && (r ? g.push({ op: "move", data: [a + (M ? 0 : k()), t + (M ? 0 : k())] }) : g.push({ op: "move", data: [a + (M ? 0 : y(c, n, l)), t + (M ? 0 : y(c, n, l))] })), r ? g.push({ op: "bcurveTo", data: [u + a + (s - a) * p + k(), f + t + (e - t) * p + k(), u + a + 2 * (s - a) * p + k(), f + t + 2 * (e - t) * p + k(), s + (M ? 0 : k()), e + (M ? 0 : k())] }) : g.push({ op: "bcurveTo", data: [u + a + (s - a) * p + b(), f + t + (e - t) * p + b(), u + a + 2 * (s - a) * p + b(), f + t + 2 * (e - t) * p + b(), s + (M ? 0 : b()), e + (M ? 0 : b())] }), g; }
function Q(a, t, s) { if (!a.length)
    return []; let e = []; e.push([a[0][0] + y(t, s), a[0][1] + y(t, s)]), e.push([a[0][0] + y(t, s), a[0][1] + y(t, s)]); for (let n = 1; n < a.length; n++)
    e.push([a[n][0] + y(t, s), a[n][1] + y(t, s)]), n === a.length - 1 && e.push([a[n][0] + y(t, s), a[n][1] + y(t, s)]); return K(e, null, s); }
function K(a, t, s) { let e = a.length, n = []; if (e > 3) {
    let o = [], r = 1 - s.curveTightness;
    n.push({ op: "move", data: [a[1][0], a[1][1]] });
    for (let h = 1; h + 2 < e; h++) {
        let i = a[h];
        o[0] = [i[0], i[1]], o[1] = [i[0] + (r * a[h + 1][0] - r * a[h - 1][0]) / 6, i[1] + (r * a[h + 1][1] - r * a[h - 1][1]) / 6], o[2] = [a[h + 1][0] + (r * a[h][0] - r * a[h + 2][0]) / 6, a[h + 1][1] + (r * a[h][1] - r * a[h + 2][1]) / 6], o[3] = [a[h + 1][0], a[h + 1][1]], n.push({ op: "bcurveTo", data: [o[1][0], o[1][1], o[2][0], o[2][1], o[3][0], o[3][1]] });
    }
    if (t && t.length === 2) {
        let h = s.maxRandomnessOffset;
        n.push({ op: "lineTo", data: [t[0] + y(h, s), t[1] + y(h, s)] });
    }
}
else
    e === 3 ? (n.push({ op: "move", data: [a[1][0], a[1][1]] }), n.push({ op: "bcurveTo", data: [a[1][0], a[1][1], a[2][0], a[2][1], a[2][0], a[2][1]] })) : e === 2 && n.push(...ut(a[0][0], a[0][1], a[1][0], a[1][1], s, !0, !0)); return n; }
function Pt(a, t, s, e, n, o, r, h) { let i = [], l = []; if (h.roughness === 0) {
    a /= 4, l.push([t + e * Math.cos(-a), s + n * Math.sin(-a)]);
    for (let c = 0; c <= 2 * Math.PI; c += a) {
        let d = [t + e * Math.cos(c), s + n * Math.sin(c)];
        i.push(d), l.push(d);
    }
    l.push([t + e * Math.cos(0), s + n * Math.sin(0)]), l.push([t + e * Math.cos(a), s + n * Math.sin(a)]);
}
else {
    let c = y(.5, h) - Math.PI / 2;
    l.push([y(o, h) + t + .9 * e * Math.cos(c - a), y(o, h) + s + .9 * n * Math.sin(c - a)]);
    let d = 2 * Math.PI + c - .01;
    for (let p = c; p < d; p += a) {
        let u = [y(o, h) + t + e * Math.cos(p), y(o, h) + s + n * Math.sin(p)];
        i.push(u), l.push(u);
    }
    l.push([y(o, h) + t + e * Math.cos(c + 2 * Math.PI + .5 * r), y(o, h) + s + n * Math.sin(c + 2 * Math.PI + .5 * r)]), l.push([y(o, h) + t + .98 * e * Math.cos(c + r), y(o, h) + s + .98 * n * Math.sin(c + r)]), l.push([y(o, h) + t + .9 * e * Math.cos(c + .5 * r), y(o, h) + s + .9 * n * Math.sin(c + .5 * r)]);
} return [l, i]; }
function vt(a, t, s, e, n, o, r, h, i) { let l = o + y(.1, i), c = []; c.push([y(h, i) + t + .9 * e * Math.cos(l - a), y(h, i) + s + .9 * n * Math.sin(l - a)]); for (let d = l; d <= r; d += a)
    c.push([y(h, i) + t + e * Math.cos(d), y(h, i) + s + n * Math.sin(d)]); return c.push([t + e * Math.cos(r), s + n * Math.sin(r)]), c.push([t + e * Math.cos(r), s + n * Math.sin(r)]), K(c, null, i); }
function Rt(a, t, s, e, n, o, r, h) { let i = [], l = [h.maxRandomnessOffset || 1, (h.maxRandomnessOffset || 1) + .3], c = [0, 0], d = h.disableMultiStroke ? 1 : 2, p = h.preserveVertices; for (let u = 0; u < d; u++)
    u === 0 ? i.push({ op: "move", data: [r[0], r[1]] }) : i.push({ op: "move", data: [r[0] + (p ? 0 : y(l[0], h)), r[1] + (p ? 0 : y(l[0], h))] }), c = p ? [n, o] : [n + y(l[u], h), o + y(l[u], h)], i.push({ op: "bcurveTo", data: [a + y(l[u], h), t + y(l[u], h), s + y(l[u], h), e + y(l[u], h), c[0], c[1]] }); return i; }
function j(a) { return [...a]; }
function St(a, t = 0) { let s = a.length; if (s < 3)
    throw new Error("A curve must have at least three points."); let e = []; if (s === 3)
    e.push(j(a[0]), j(a[1]), j(a[2]), j(a[2]));
else {
    let n = [];
    n.push(a[0], a[0]);
    for (let h = 1; h < a.length; h++)
        n.push(a[h]), h === a.length - 1 && n.push(a[h]);
    let o = [], r = 1 - t;
    e.push(j(n[0]));
    for (let h = 1; h + 2 < n.length; h++) {
        let i = n[h];
        o[0] = [i[0], i[1]], o[1] = [i[0] + (r * n[h + 1][0] - r * n[h - 1][0]) / 6, i[1] + (r * n[h + 1][1] - r * n[h - 1][1]) / 6], o[2] = [n[h + 1][0] + (r * n[h][0] - r * n[h + 2][0]) / 6, n[h + 1][1] + (r * n[h][1] - r * n[h + 2][1]) / 6], o[3] = [n[h + 1][0], n[h + 1][1]], e.push(o[1], o[2], o[3]);
    }
} return e; }
function B(a, t) { return Math.pow(a[0] - t[0], 2) + Math.pow(a[1] - t[1], 2); }
function jt(a, t, s) { let e = B(t, s); if (e === 0)
    return B(a, t); let n = ((a[0] - t[0]) * (s[0] - t[0]) + (a[1] - t[1]) * (s[1] - t[1])) / e; return n = Math.max(0, Math.min(1, n)), B(a, z(t, s, n)); }
function z(a, t, s) { return [a[0] + (t[0] - a[0]) * s, a[1] + (t[1] - a[1]) * s]; }
function pt(a, t, s, e) { let n = e || []; if ((function (h, i) { let l = h[i + 0], c = h[i + 1], d = h[i + 2], p = h[i + 3], u = 3 * c[0] - 2 * l[0] - p[0]; u *= u; let f = 3 * c[1] - 2 * l[1] - p[1]; f *= f; let g = 3 * d[0] - 2 * p[0] - l[0]; g *= g; let k = 3 * d[1] - 2 * p[1] - l[1]; return k *= k, u < g && (u = g), f < k && (f = k), u + f; })(a, t) < s) {
    let h = a[t + 0];
    n.length ? (o = n[n.length - 1], r = h, Math.sqrt(B(o, r)) > 1 && n.push(h)) : n.push(h), n.push(a[t + 3]);
}
else {
    let i = a[t + 0], l = a[t + 1], c = a[t + 2], d = a[t + 3], p = z(i, l, .5), u = z(l, c, .5), f = z(c, d, .5), g = z(p, u, .5), k = z(u, f, .5), b = z(g, k, .5);
    pt([i, p, g, b], 0, s, n), pt([b, k, f, d], 0, s, n);
} var o, r; return n; }
function qt(a, t) { return U(a, 0, a.length, t); }
function U(a, t, s, e, n) { let o = n || [], r = a[t], h = a[s - 1], i = 0, l = 1; for (let c = t + 1; c < s - 1; ++c) {
    let d = jt(a[c], r, h);
    d > i && (i = d, l = c);
} return Math.sqrt(i) > e ? (U(a, t, l + 1, e, o), U(a, l, s, e, o)) : (o.length || o.push(r), o.push(h)), o; }
function nt(a, t = .15, s) { let e = [], n = (a.length - 1) / 3; for (let o = 0; o < n; o++)
    pt(a, 3 * o, t, e); return s && s > 0 ? U(e, 0, e.length, s) : e; }
var O = "none", $ = class {
    constructor(t) { this.defaultOptions = { maxRandomnessOffset: 2, roughness: 1, bowing: 1, stroke: "#000", strokeWidth: 1, curveTightness: 0, curveFitting: .95, curveStepCount: 9, fillStyle: "hachure", fillWeight: -1, hachureAngle: -41, hachureGap: -1, dashOffset: -1, dashGap: -1, zigzagOffset: -1, seed: 0, disableMultiStroke: !1, disableMultiStrokeFill: !1, preserveVertices: !1, fillShapeRoughnessGain: .8 }, this.config = t || {}, this.config.options && (this.defaultOptions = this._o(this.config.options)); }
    static newSeed() { return Math.floor(Math.random() * 2 ** 31); }
    _o(t) { return t ? Object.assign({}, this.defaultOptions, t) : this.defaultOptions; }
    _d(t, s, e) { return { shape: t, sets: s || [], options: e || this.defaultOptions }; }
    line(t, s, e, n, o) { let r = this._o(o); return this._d("line", [Dt(t, s, e, n, r)], r); }
    rectangle(t, s, e, n, o) { let r = this._o(o), h = [], i = $t(t, s, e, n, r); if (r.fill) {
        let l = [[t, s], [t + e, s], [t + e, s + n], [t, s + n]];
        r.fillStyle === "solid" ? h.push(st([l], r)) : h.push(G([l], r));
    } return r.stroke !== O && h.push(i), this._d("rectangle", h, r); }
    ellipse(t, s, e, n, o) { let r = this._o(o), h = [], i = At(e, n, r), l = lt(t, s, r, i); if (r.fill)
        if (r.fillStyle === "solid") {
            let c = lt(t, s, r, i).opset;
            c.type = "fillPath", h.push(c);
        }
        else
            h.push(G([l.estimatedPoints], r)); return r.stroke !== O && h.push(l.opset), this._d("ellipse", h, r); }
    circle(t, s, e, n) { let o = this.ellipse(t, s, e, e, n); return o.shape = "circle", o; }
    linearPath(t, s) { let e = this._o(s); return this._d("linearPath", [N(t, !1, e)], e); }
    arc(t, s, e, n, o, r, h = !1, i) { let l = this._o(i), c = [], d = mt(t, s, e, n, o, r, h, !0, l); if (h && l.fill)
        if (l.fillStyle === "solid") {
            let p = Object.assign({}, l);
            p.disableMultiStroke = !0;
            let u = mt(t, s, e, n, o, r, !0, !1, p);
            u.type = "fillPath", c.push(u);
        }
        else
            c.push((function (p, u, f, g, k, b, M) { let m = p, P = u, x = Math.abs(f / 2), w = Math.abs(g / 2); x += y(.01 * x, M), w += y(.01 * w, M); let L = k, A = b; for (; L < 0;)
                L += 2 * Math.PI, A += 2 * Math.PI; A - L > 2 * Math.PI && (L = 0, A = 2 * Math.PI); let V = (A - L) / M.curveStepCount, D = []; for (let C = L; C <= A; C += V)
                D.push([m + x * Math.cos(C), P + w * Math.sin(C)]); return D.push([m + x * Math.cos(A), P + w * Math.sin(A)]), D.push([m, P]), G([D], M); })(t, s, e, n, o, r, l)); return l.stroke !== O && c.push(d), this._d("arc", c, l); }
    curve(t, s) { let e = this._o(s), n = [], o = yt(t, e); if (e.fill && e.fill !== O)
        if (e.fillStyle === "solid") {
            let r = yt(t, Object.assign(Object.assign({}, e), { disableMultiStroke: !0, roughness: e.roughness ? e.roughness + e.fillShapeRoughnessGain : 0 }));
            n.push({ type: "fillPath", ops: this._mergedShape(r.ops) });
        }
        else {
            let r = [], h = t;
            if (h.length) {
                let i = typeof h[0][0] == "number" ? [h] : h;
                for (let l of i)
                    l.length < 3 ? r.push(...l) : l.length === 3 ? r.push(...nt(St([l[0], l[0], l[1], l[2]]), 10, (1 + e.roughness) / 2)) : r.push(...nt(St(l), 10, (1 + e.roughness) / 2));
            }
            r.length && n.push(G([r], e));
        } return e.stroke !== O && n.push(o), this._d("curve", n, e); }
    polygon(t, s) { let e = this._o(s), n = [], o = N(t, !0, e); return e.fill && (e.fillStyle === "solid" ? n.push(st([t], e)) : n.push(G([t], e))), e.stroke !== O && n.push(o), this._d("polygon", n, e); }
    path(t, s) { let e = this._o(s), n = []; if (!t)
        return this._d("path", n, e); t = (t || "").replace(/\n/g, " ").replace(/(-\s)/g, "-").replace("/(ss)/g", " "); let o = e.fill && e.fill !== "transparent" && e.fill !== O, r = e.stroke !== O, h = !!(e.simplification && e.simplification < 1), i = (function (c, d, p) { let u = Lt(Ot(gt(c))), f = [], g = [], k = [0, 0], b = [], M = () => { b.length >= 4 && g.push(...nt(b, d)), b = []; }, m = () => { M(), g.length && (f.push(g), g = []); }; for (let { key: x, data: w } of u)
        switch (x) {
            case "M":
                m(), k = [w[0], w[1]], g.push(k);
                break;
            case "L":
                M(), g.push([w[0], w[1]]);
                break;
            case "C":
                if (!b.length) {
                    let L = g.length ? g[g.length - 1] : k;
                    b.push([L[0], L[1]]);
                }
                b.push([w[0], w[1]]), b.push([w[2], w[3]]), b.push([w[4], w[5]]);
                break;
            case "Z": M(), g.push([k[0], k[1]]);
        } if (m(), !p)
        return f; let P = []; for (let x of f) {
        let w = qt(x, p);
        w.length && P.push(w);
    } return P; })(t, 1, h ? 4 - 4 * (e.simplification || 1) : (1 + e.roughness) / 2), l = wt(t, e); if (o)
        if (e.fillStyle === "solid")
            if (i.length === 1) {
                let c = wt(t, Object.assign(Object.assign({}, e), { disableMultiStroke: !0, roughness: e.roughness ? e.roughness + e.fillShapeRoughnessGain : 0 }));
                n.push({ type: "fillPath", ops: this._mergedShape(c.ops) });
            }
            else
                n.push(st(i, e));
        else
            n.push(G(i, e)); return r && (h ? i.forEach(c => { n.push(N(c, !1, e)); }) : n.push(l)), this._d("path", n, e); }
    opsToPath(t, s) { let e = ""; for (let n of t.ops) {
        let o = typeof s == "number" && s >= 0 ? n.data.map(r => +r.toFixed(s)) : n.data;
        switch (n.op) {
            case "move":
                e += `M${o[0]} ${o[1]} `;
                break;
            case "bcurveTo":
                e += `C${o[0]} ${o[1]}, ${o[2]} ${o[3]}, ${o[4]} ${o[5]} `;
                break;
            case "lineTo": e += `L${o[0]} ${o[1]} `;
        }
    } return e.trim(); }
    toPaths(t) { let s = t.sets || [], e = t.options || this.defaultOptions, n = []; for (let o of s) {
        let r = null;
        switch (o.type) {
            case "path":
                r = { d: this.opsToPath(o), stroke: e.stroke, strokeWidth: e.strokeWidth, fill: O };
                break;
            case "fillPath":
                r = { d: this.opsToPath(o), stroke: O, strokeWidth: 0, fill: e.fill || O };
                break;
            case "fillSketch": r = this.fillSketch(o, e);
        }
        r && n.push(r);
    } return n; }
    fillSketch(t, s) { let e = s.fillWeight; return e < 0 && (e = s.strokeWidth / 2), { d: this.opsToPath(t), stroke: s.fill || O, strokeWidth: e, fill: O }; }
    _mergedShape(t) { return t.filter((s, e) => e === 0 || s.op !== "move"); }
}, ft = class {
    constructor(t, s) { this.canvas = t, this.ctx = this.canvas.getContext("2d"), this.gen = new $(s); }
    draw(t) { let s = t.sets || [], e = t.options || this.getDefaultOptions(), n = this.ctx, o = t.options.fixedDecimalPlaceDigits; for (let r of s)
        switch (r.type) {
            case "path":
                n.save(), n.strokeStyle = e.stroke === "none" ? "transparent" : e.stroke, n.lineWidth = e.strokeWidth, e.strokeLineDash && n.setLineDash(e.strokeLineDash), e.strokeLineDashOffset && (n.lineDashOffset = e.strokeLineDashOffset), this._drawToContext(n, r, o), n.restore();
                break;
            case "fillPath": {
                n.save(), n.fillStyle = e.fill || "";
                let h = t.shape === "curve" || t.shape === "polygon" || t.shape === "path" ? "evenodd" : "nonzero";
                this._drawToContext(n, r, o, h), n.restore();
                break;
            }
            case "fillSketch": this.fillSketch(n, r, e);
        } }
    fillSketch(t, s, e) { let n = e.fillWeight; n < 0 && (n = e.strokeWidth / 2), t.save(), e.fillLineDash && t.setLineDash(e.fillLineDash), e.fillLineDashOffset && (t.lineDashOffset = e.fillLineDashOffset), t.strokeStyle = e.fill || "", t.lineWidth = n, this._drawToContext(t, s, e.fixedDecimalPlaceDigits), t.restore(); }
    _drawToContext(t, s, e, n = "nonzero") { t.beginPath(); for (let o of s.ops) {
        let r = typeof e == "number" && e >= 0 ? o.data.map(h => +h.toFixed(e)) : o.data;
        switch (o.op) {
            case "move":
                t.moveTo(r[0], r[1]);
                break;
            case "bcurveTo":
                t.bezierCurveTo(r[0], r[1], r[2], r[3], r[4], r[5]);
                break;
            case "lineTo": t.lineTo(r[0], r[1]);
        }
    } s.type === "fillPath" ? t.fill(n) : t.stroke(); }
    get generator() { return this.gen; }
    getDefaultOptions() { return this.gen.defaultOptions; }
    line(t, s, e, n, o) { let r = this.gen.line(t, s, e, n, o); return this.draw(r), r; }
    rectangle(t, s, e, n, o) { let r = this.gen.rectangle(t, s, e, n, o); return this.draw(r), r; }
    ellipse(t, s, e, n, o) { let r = this.gen.ellipse(t, s, e, n, o); return this.draw(r), r; }
    circle(t, s, e, n) { let o = this.gen.circle(t, s, e, n); return this.draw(o), o; }
    linearPath(t, s) { let e = this.gen.linearPath(t, s); return this.draw(e), e; }
    polygon(t, s) { let e = this.gen.polygon(t, s); return this.draw(e), e; }
    arc(t, s, e, n, o, r, h = !1, i) { let l = this.gen.arc(t, s, e, n, o, r, h, i); return this.draw(l), l; }
    curve(t, s) { let e = this.gen.curve(t, s); return this.draw(e), e; }
    path(t, s) { let e = this.gen.path(t, s); return this.draw(e), e; }
}, H = "http://www.w3.org/2000/svg", dt = class {
    constructor(t, s) { this.svg = t, this.gen = new $(s); }
    draw(t) { let s = t.sets || [], e = t.options || this.getDefaultOptions(), n = this.svg.ownerDocument || window.document, o = n.createElementNS(H, "g"), r = t.options.fixedDecimalPlaceDigits; for (let h of s) {
        let i = null;
        switch (h.type) {
            case "path":
                i = n.createElementNS(H, "path"), i.setAttribute("d", this.opsToPath(h, r)), i.setAttribute("stroke", e.stroke), i.setAttribute("stroke-width", e.strokeWidth + ""), i.setAttribute("fill", "none"), e.strokeLineDash && i.setAttribute("stroke-dasharray", e.strokeLineDash.join(" ").trim()), e.strokeLineDashOffset && i.setAttribute("stroke-dashoffset", `${e.strokeLineDashOffset}`);
                break;
            case "fillPath":
                i = n.createElementNS(H, "path"), i.setAttribute("d", this.opsToPath(h, r)), i.setAttribute("stroke", "none"), i.setAttribute("stroke-width", "0"), i.setAttribute("fill", e.fill || ""), t.shape !== "curve" && t.shape !== "polygon" || i.setAttribute("fill-rule", "evenodd");
                break;
            case "fillSketch": i = this.fillSketch(n, h, e);
        }
        i && o.appendChild(i);
    } return o; }
    fillSketch(t, s, e) { let n = e.fillWeight; n < 0 && (n = e.strokeWidth / 2); let o = t.createElementNS(H, "path"); return o.setAttribute("d", this.opsToPath(s, e.fixedDecimalPlaceDigits)), o.setAttribute("stroke", e.fill || ""), o.setAttribute("stroke-width", n + ""), o.setAttribute("fill", "none"), e.fillLineDash && o.setAttribute("stroke-dasharray", e.fillLineDash.join(" ").trim()), e.fillLineDashOffset && o.setAttribute("stroke-dashoffset", `${e.fillLineDashOffset}`), o; }
    get generator() { return this.gen; }
    getDefaultOptions() { return this.gen.defaultOptions; }
    opsToPath(t, s) { return this.gen.opsToPath(t, s); }
    line(t, s, e, n, o) { let r = this.gen.line(t, s, e, n, o); return this.draw(r); }
    rectangle(t, s, e, n, o) { let r = this.gen.rectangle(t, s, e, n, o); return this.draw(r); }
    ellipse(t, s, e, n, o) { let r = this.gen.ellipse(t, s, e, n, o); return this.draw(r); }
    circle(t, s, e, n) { let o = this.gen.circle(t, s, e, n); return this.draw(o); }
    linearPath(t, s) { let e = this.gen.linearPath(t, s); return this.draw(e); }
    polygon(t, s) { let e = this.gen.polygon(t, s); return this.draw(e); }
    arc(t, s, e, n, o, r, h = !1, i) { let l = this.gen.arc(t, s, e, n, o, r, h, i); return this.draw(l); }
    curve(t, s) { let e = this.gen.curve(t, s); return this.draw(e); }
    path(t, s) { let e = this.gen.path(t, s); return this.draw(e); }
}, Ft = { canvas: (a, t) => new ft(a, t), svg: (a, t) => new dt(a, t), generator: a => new $(a), newSeed: () => $.newSeed() };
export { Ft as a };
