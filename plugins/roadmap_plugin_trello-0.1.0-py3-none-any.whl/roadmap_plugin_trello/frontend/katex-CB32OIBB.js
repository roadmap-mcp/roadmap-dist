import "@nf-internal/chunk-OSQMNGTH";
var z = class r extends Error {
    constructor(e, t) { var a = "KaTeX parse error: " + e, i, s, u = t && t.loc; if (u && u.start <= u.end) {
        var h = u.lexer.input;
        i = u.start, s = u.end, i === h.length ? a += " at end of input: " : a += " at position " + (i + 1) + ": ";
        var c = h.slice(i, s).replace(/[^]/g, "$&\u0332"), v;
        i > 15 ? v = "\u2026" + h.slice(i - 15, i) : v = h.slice(0, i);
        var p;
        s + 15 < h.length ? p = h.slice(s, s + 15) + "\u2026" : p = h.slice(s), a += v + c + p;
    } super(a), this.name = "ParseError", this.position = void 0, this.length = void 0, this.rawMessage = void 0, Object.setPrototypeOf(this, r.prototype), this.position = i, i != null && s != null && (this.length = s - i), this.rawMessage = e; }
}, W1 = /([A-Z])/g, j1 = r => r.replace(W1, "-$1").toLowerCase(), Z1 = { "&": "&amp;", ">": "&gt;", "<": "&lt;", '"': "&quot;", "'": "&#x27;" }, K1 = /[&><"']/g, n0 = r => String(r).replace(K1, e => Z1[e]), Ne = r => r.type === "ordgroup" || r.type === "color" ? r.body.length === 1 ? Ne(r.body[0]) : r : r.type === "font" ? Ne(r.body) : r, J1 = new Set(["mathord", "textord", "atom"]), E0 = r => J1.has(Ne(r).type), Q1 = r => { var e = /^[\x00-\x20]*([^\\/#?]*?)(:|&#0*58|&#x0*3a|&colon)/i.exec(r); return e ? e[2] !== ":" || !/^[a-zA-Z][a-zA-Z0-9+\-.]*$/.test(e[1]) ? null : e[1].toLowerCase() : "_relative"; }, bt = { displayMode: { type: "boolean", description: "Render math in display mode, which puts the math in display style (so \\int and \\sum are large, for example), and centers the math on the page on its own line.", cli: "-d, --display-mode" }, output: { type: { enum: ["htmlAndMathml", "html", "mathml"] }, description: "Determines the markup language of the output.", cli: "-F, --format <type>" }, leqno: { type: "boolean", description: "Render display math in leqno style (left-justified tags)." }, fleqn: { type: "boolean", description: "Render display math flush left." }, throwOnError: { type: "boolean", default: !0, cli: "-t, --no-throw-on-error", cliDescription: "Render errors (in the color given by --error-color) instead of throwing a ParseError exception when encountering an error." }, errorColor: { type: "string", default: "#cc0000", cli: "-c, --error-color <color>", cliDescription: "A color string given in the format 'rgb' or 'rrggbb' (no #). This option determines the color of errors rendered by the -t option.", cliProcessor: r => "#" + r }, macros: { type: "object", cli: "-m, --macro <def>", cliDescription: "Define custom macro of the form '\\foo:expansion' (use multiple -m arguments for multiple macros).", cliDefault: [], cliProcessor: (r, e) => (e.push(r), e) }, minRuleThickness: { type: "number", description: "Specifies a minimum thickness, in ems, for fraction lines, `\\sqrt` top lines, `{array}` vertical lines, `\\hline`, `\\hdashline`, `\\underline`, `\\overline`, and the borders of `\\fbox`, `\\boxed`, and `\\fcolorbox`.", processor: r => Math.max(0, r), cli: "--min-rule-thickness <size>", cliProcessor: parseFloat }, colorIsTextColor: { type: "boolean", description: "Makes \\color behave like LaTeX's 2-argument \\textcolor, instead of LaTeX's one-argument \\color mode change.", cli: "-b, --color-is-text-color" }, strict: { type: [{ enum: ["warn", "ignore", "error"] }, "boolean", "function"], description: "Turn on strict / LaTeX faithfulness mode, which throws an error if the input uses features that are not supported by LaTeX.", cli: "-S, --strict", cliDefault: !1 }, trust: { type: ["boolean", "function"], description: "Trust the input, enabling all HTML features such as \\url.", cli: "-T, --trust" }, maxSize: { type: "number", default: 1 / 0, description: "If non-zero, all user-specified sizes, e.g. in \\rule{500em}{500em}, will be capped to maxSize ems. Otherwise, elements and spaces can be arbitrarily large", processor: r => Math.max(0, r), cli: "-s, --max-size <n>", cliProcessor: parseInt }, maxExpand: { type: "number", default: 1e3, description: "Limit the number of macro expansions to the specified number, to prevent e.g. infinite macro loops. If set to Infinity, the macro expander will try to fully expand as in LaTeX.", processor: r => Math.max(0, r), cli: "-e, --max-expand <n>", cliProcessor: r => r === "Infinity" ? 1 / 0 : parseInt(r) }, globalGroup: { type: "boolean", cli: !1 } };
function _1(r) { if (typeof r != "string")
    return r.enum[0]; switch (r) {
    case "boolean": return !1;
    case "string": return "";
    case "number": return 0;
    case "object": return {};
    default: throw new Error("Unexpected schema type; settings must declare an explicit default.");
} }
function ea(r) { if (r.default !== void 0)
    return r.default; var e = Array.isArray(r.type) ? r.type[0] : r.type; return _1(e); }
function ta(r, e, t, a) { var i = t[e]; r[e] = i !== void 0 ? a.processor ? a.processor(i) : i : ea(a); }
var de = class {
    constructor(e) { e === void 0 && (e = {}), this.displayMode = void 0, this.output = void 0, this.leqno = void 0, this.fleqn = void 0, this.throwOnError = void 0, this.errorColor = void 0, this.macros = void 0, this.minRuleThickness = void 0, this.colorIsTextColor = void 0, this.strict = void 0, this.trust = void 0, this.maxSize = void 0, this.maxExpand = void 0, this.globalGroup = void 0, e = e || {}; for (var t of Object.keys(bt)) {
        var a = bt[t];
        a && ta(this, t, e, a);
    } }
    reportNonstrict(e, t, a) { var i = this.strict; if (typeof i == "function" && (i = i(e, t, a)), !(!i || i === "ignore")) {
        if (i === !0 || i === "error")
            throw new z("LaTeX-incompatible input and strict mode is set to 'error': " + (t + " [" + e + "]"), a);
        i === "warn" ? typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")) : typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + i + "': " + t + " [" + e + "]"));
    } }
    useStrictBehavior(e, t, a) { var i = this.strict; if (typeof i == "function")
        try {
            i = i(e, t, a);
        }
        catch {
            i = "error";
        } return !i || i === "ignore" ? !1 : i === !0 || i === "error" ? !0 : i === "warn" ? (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to 'warn': " + (t + " [" + e + "]")), !1) : (typeof console < "u" && console.warn("LaTeX-incompatible input and strict mode is set to " + ("unrecognized '" + i + "': " + t + " [" + e + "]")), !1); }
    isTrusted(e) { if ("url" in e && e.url && !e.protocol) {
        var t = Q1(e.url);
        if (t == null)
            return !1;
        e.protocol = t;
    } var a = typeof this.trust == "function" ? this.trust(e) : this.trust; return !!a; }
}, k0 = class {
    constructor(e, t, a) { this.id = void 0, this.size = void 0, this.cramped = void 0, this.id = e, this.size = t, this.cramped = a; }
    sup() { return S0[ra[this.id]]; }
    sub() { return S0[aa[this.id]]; }
    fracNum() { return S0[ia[this.id]]; }
    fracDen() { return S0[na[this.id]]; }
    cramp() { return S0[sa[this.id]]; }
    text() { return S0[la[this.id]]; }
    isTight() { return this.size >= 2; }
}, Lt = 0, Oe = 1, ee = 2, q0 = 3, fe = 4, p0 = 5, te = 6, l0 = 7, S0 = [new k0(Lt, 0, !1), new k0(Oe, 0, !0), new k0(ee, 1, !1), new k0(q0, 1, !0), new k0(fe, 2, !1), new k0(p0, 2, !0), new k0(te, 3, !1), new k0(l0, 3, !0)], ra = [fe, p0, fe, p0, te, l0, te, l0], aa = [p0, p0, p0, p0, l0, l0, l0, l0], ia = [ee, q0, fe, p0, te, l0, te, l0], na = [q0, q0, p0, p0, l0, l0, l0, l0], sa = [Oe, Oe, q0, q0, p0, p0, l0, l0], la = [Lt, Oe, ee, q0, ee, q0, ee, q0], N = { DISPLAY: S0[Lt], TEXT: S0[ee], SCRIPT: S0[fe], SCRIPTSCRIPT: S0[te] }, yt = [{ name: "latin", blocks: [[256, 591], [768, 879]] }, { name: "cyrillic", blocks: [[1024, 1279]] }, { name: "armenian", blocks: [[1328, 1423]] }, { name: "brahmic", blocks: [[2304, 4255]] }, { name: "georgian", blocks: [[4256, 4351]] }, { name: "cjk", blocks: [[12288, 12543], [19968, 40879], [65280, 65376]] }, { name: "hangul", blocks: [[44032, 55215]] }];
function ua(r) { for (var e = 0; e < yt.length; e++)
    for (var t = yt[e], a = 0; a < t.blocks.length; a++) {
        var i = t.blocks[a];
        if (r >= i[0] && r <= i[1])
            return t.name;
    } return null; }
var Fe = [];
yt.forEach(r => r.blocks.forEach(e => Fe.push(...e)));
function Xr(r) { for (var e = 0; e < Fe.length; e += 2)
    if (r >= Fe[e] && r <= Fe[e + 1])
        return !0; return !1; }
var r0 = r => r + " " + r, _0 = 80, oa = function (e, t) {
    return "M95," + (622 + e + t) + `
c-2.7,0,-7.17,-2.7,-13.5,-8c-5.8,-5.3,-9.5,-10,-9.5,-14
c0,-2,0.3,-3.3,1,-4c1.3,-2.7,23.83,-20.7,67.5,-54
c44.2,-33.3,65.8,-50.3,66.5,-51c1.3,-1.3,3,-2,5,-2c4.7,0,8.7,3.3,12,10
s173,378,173,378c0.7,0,35.3,-71,104,-213c68.7,-142,137.5,-285,206.5,-429
c69,-144,104.5,-217.7,106.5,-221
l` + e / 2.075 + " -" + e + `
c5.3,-9.3,12,-14,20,-14
H400000v` + (40 + e) + `H845.2724
s-225.272,467,-225.272,467s-235,486,-235,486c-2.7,4.7,-9,7,-19,7
c-6,0,-10,-1,-12,-3s-194,-422,-194,-422s-65,47,-65,47z
M` + (834 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, ha = function (e, t) {
    return "M263," + (601 + e + t) + `c0.7,0,18,39.7,52,119
c34,79.3,68.167,158.7,102.5,238c34.3,79.3,51.8,119.3,52.5,120
c340,-704.7,510.7,-1060.3,512,-1067
l` + e / 2.084 + " -" + e + `
c4.7,-7.3,11,-11,19,-11
H40000v` + (40 + e) + `H1012.3
s-271.3,567,-271.3,567c-38.7,80.7,-84,175,-136,283c-52,108,-89.167,185.3,-111.5,232
c-22.3,46.7,-33.8,70.3,-34.5,71c-4.7,4.7,-12.3,7,-23,7s-12,-1,-12,-1
s-109,-253,-109,-253c-72.7,-168,-109.3,-252,-110,-252c-10.7,8,-22,16.7,-34,26
c-22,17.3,-33.3,26,-34,26s-26,-26,-26,-26s76,-59,76,-59s76,-60,76,-60z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, ma = function (e, t) {
    return "M983 " + (10 + e + t) + `
l` + e / 3.13 + " -" + e + `
c4,-6.7,10,-10,18,-10 H400000v` + (40 + e) + `
H1013.1s-83.4,268,-264.1,840c-180.7,572,-277,876.3,-289,913c-4.7,4.7,-12.7,7,-24,7
s-12,0,-12,0c-1.3,-3.3,-3.7,-11.7,-7,-25c-35.3,-125.3,-106.7,-373.3,-214,-744
c-10,12,-21,25,-33,39s-32,39,-32,39c-6,-5.3,-15,-14,-27,-26s25,-30,25,-30
c26.7,-32.7,52,-63,76,-91s52,-60,52,-60s208,722,208,722
c56,-175.3,126.3,-397.3,211,-666c84.7,-268.7,153.8,-488.2,207.5,-658.5
c53.7,-170.3,84.5,-266.8,92.5,-289.5z
M` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "h-400000z";
}, ca = function (e, t) {
    return "M424," + (2398 + e + t) + `
c-1.3,-0.7,-38.5,-172,-111.5,-514c-73,-342,-109.8,-513.3,-110.5,-514
c0,-2,-10.7,14.3,-32,49c-4.7,7.3,-9.8,15.7,-15.5,25c-5.7,9.3,-9.8,16,-12.5,20
s-5,7,-5,7c-4,-3.3,-8.3,-7.7,-13,-13s-13,-13,-13,-13s76,-122,76,-122s77,-121,77,-121
s209,968,209,968c0,-2,84.7,-361.7,254,-1079c169.3,-717.3,254.7,-1077.7,256,-1081
l` + e / 4.223 + " -" + e + `c4,-6.7,10,-10,18,-10 H400000
v` + (40 + e) + `H1014.6
s-87.3,378.7,-272.6,1166c-185.3,787.3,-279.3,1182.3,-282,1185
c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2z M` + (1001 + e) + " " + t + `
h400000v` + (40 + e) + "h-400000z";
}, da = function (e, t) {
    return "M473," + (2713 + e + t) + `
c339.3,-1799.3,509.3,-2700,510,-2702 l` + e / 5.298 + " -" + e + `
c3.3,-7.3,9.3,-11,18,-11 H400000v` + (40 + e) + `H1017.7
s-90.5,478,-276.2,1466c-185.7,988,-279.5,1483,-281.5,1485c-2,6,-10,9,-24,9
c-8,0,-12,-0.7,-12,-2c0,-1.3,-5.3,-32,-16,-92c-50.7,-293.3,-119.7,-693.3,-207,-1200
c0,-1.3,-5.3,8.7,-16,30c-10.7,21.3,-21.3,42.7,-32,64s-16,33,-16,33s-26,-26,-26,-26
s76,-153,76,-153s77,-151,77,-151c0.7,0.7,35.7,202,105,604c67.3,400.7,102,602.7,104,
606zM` + (1001 + e) + " " + t + "h400000v" + (40 + e) + "H1017.7z";
}, fa = function (e) { var t = e / 2; return "M400000 " + e + " H0 L" + t + " 0 l65 45 L145 " + (e - 80) + " H400000z"; }, va = function (e, t, a) {
    var i = a - 54 - t - e;
    return "M702 " + (e + t) + "H400000" + (40 + e) + `
H742v` + i + `l-4 4-4 4c-.667.7 -2 1.5-4 2.5s-4.167 1.833-6.5 2.5-5.5 1-9.5 1
h-12l-28-84c-16.667-52-96.667 -294.333-240-727l-212 -643 -85 170
c-4-3.333-8.333-7.667-13 -13l-13-13l77-155 77-156c66 199.333 139 419.667
219 661 l218 661zM702 ` + t + "H400000v" + (40 + e) + "H742z";
}, pa = function (e, t, a) { t = 1e3 * t; var i = ""; switch (e) {
    case "sqrtMain":
        i = oa(t, _0);
        break;
    case "sqrtSize1":
        i = ha(t, _0);
        break;
    case "sqrtSize2":
        i = ma(t, _0);
        break;
    case "sqrtSize3":
        i = ca(t, _0);
        break;
    case "sqrtSize4":
        i = da(t, _0);
        break;
    case "sqrtTall": i = va(t, _0, a);
} return i; }, ga = function (e, t) { switch (e) {
    case "\u239C": return r0("M291 0 H417 V" + t + " H291z");
    case "\u2223": return r0("M145 0 H188 V" + t + " H145z");
    case "\u2225": return r0("M145 0 H188 V" + t + " H145z") + r0("M367 0 H410 V" + t + " H367z");
    case "\u239F": return r0("M457 0 H583 V" + t + " H457z");
    case "\u23A2": return r0("M319 0 H403 V" + t + " H319z");
    case "\u23A5": return r0("M263 0 H347 V" + t + " H263z");
    case "\u23AA": return r0("M384 0 H504 V" + t + " H384z");
    case "\u23D0": return r0("M312 0 H355 V" + t + " H312z");
    case "\u2016": return r0("M257 0 H300 V" + t + " H257z") + r0("M478 0 H521 V" + t + " H478z");
    default: return "";
} }, or = { doubleleftarrow: `M262 157
l10-10c34-36 62.7-77 86-123 3.3-8 5-13.3 5-16 0-5.3-6.7-8-20-8-7.3
 0-12.2.5-14.5 1.5-2.3 1-4.8 4.5-7.5 10.5-49.3 97.3-121.7 169.3-217 216-28
 14-57.3 25-88 33-6.7 2-11 3.8-13 5.5-2 1.7-3 4.2-3 7.5s1 5.8 3 7.5
c2 1.7 6.3 3.5 13 5.5 68 17.3 128.2 47.8 180.5 91.5 52.3 43.7 93.8 96.2 124.5
 157.5 9.3 8 15.3 12.3 18 13h6c12-.7 18-4 18-10 0-2-1.7-7-5-15-23.3-46-52-87
-86-123l-10-10h399738v-40H218c328 0 0 0 0 0l-10-8c-26.7-20-65.7-43-117-69 2.7
-2 6-3.7 10-5 36.7-16 72.3-37.3 107-64l10-8h399782v-40z
m8 0v40h399730v-40zm0 194v40h399730v-40z`, doublerightarrow: `M399738 392l
-10 10c-34 36-62.7 77-86 123-3.3 8-5 13.3-5 16 0 5.3 6.7 8 20 8 7.3 0 12.2-.5
 14.5-1.5 2.3-1 4.8-4.5 7.5-10.5 49.3-97.3 121.7-169.3 217-216 28-14 57.3-25 88
-33 6.7-2 11-3.8 13-5.5 2-1.7 3-4.2 3-7.5s-1-5.8-3-7.5c-2-1.7-6.3-3.5-13-5.5-68
-17.3-128.2-47.8-180.5-91.5-52.3-43.7-93.8-96.2-124.5-157.5-9.3-8-15.3-12.3-18
-13h-6c-12 .7-18 4-18 10 0 2 1.7 7 5 15 23.3 46 52 87 86 123l10 10H0v40h399782
c-328 0 0 0 0 0l10 8c26.7 20 65.7 43 117 69-2.7 2-6 3.7-10 5-36.7 16-72.3 37.3
-107 64l-10 8H0v40zM0 157v40h399730v-40zm0 194v40h399730v-40z`, leftarrow: `M400000 241H110l3-3c68.7-52.7 113.7-120
 135-202 4-14.7 6-23 6-25 0-7.3-7-11-21-11-8 0-13.2.8-15.5 2.5-2.3 1.7-4.2 5.8
-5.5 12.5-1.3 4.7-2.7 10.3-4 17-12 48.7-34.8 92-68.5 130S65.3 228.3 18 247
c-10 4-16 7.7-18 11 0 8.7 6 14.3 18 17 47.3 18.7 87.8 47 121.5 85S196 441.3 208
 490c.7 2 1.3 5 2 9s1.2 6.7 1.5 8c.3 1.3 1 3.3 2 6s2.2 4.5 3.5 5.5c1.3 1 3.3
 1.8 6 2.5s6 1 10 1c14 0 21-3.7 21-11 0-2-2-10.3-6-25-20-79.3-65-146.7-135-202
 l-3-3h399890zM100 241v40h399900v-40z`, leftbrace: `M6 548l-6-6v-35l6-11c56-104 135.3-181.3 238-232 57.3-28.7 117
-45 179-50h399577v120H403c-43.3 7-81 15-113 26-100.7 33-179.7 91-237 174-2.7
 5-6 9-10 13-.7 1-7.3 1-20 1H6z`, leftbraceunder: `M0 6l6-6h17c12.688 0 19.313.3 20 1 4 4 7.313 8.3 10 13
 35.313 51.3 80.813 93.8 136.5 127.5 55.688 33.7 117.188 55.8 184.5 66.5.688
 0 2 .3 4 1 18.688 2.7 76 4.3 172 5h399450v120H429l-6-1c-124.688-8-235-61.7
-331-161C60.687 138.7 32.312 99.3 7 54L0 41V6z`, leftgroup: `M400000 80
H435C64 80 168.3 229.4 21 260c-5.9 1.2-18 0-18 0-2 0-3-1-3-3v-38C76 61 257 0
 435 0h399565z`, leftgroupunder: `M400000 262
H435C64 262 168.3 112.6 21 82c-5.9-1.2-18 0-18 0-2 0-3 1-3 3v38c76 158 257 219
 435 219h399565z`, leftharpoon: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3
-3.3 10.2-9.5 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5
-18.3 3-21-1.3-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7
-196 228-6.7 4.7-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40z`, leftharpoonplus: `M0 267c.7 5.3 3 10 7 14h399993v-40H93c3.3-3.3 10.2-9.5
 20.5-18.5s17.8-15.8 22.5-20.5c50.7-52 88-110.3 112-175 4-11.3 5-18.3 3-21-1.3
-4-7.3-6-18-6-8 0-13 .7-15 2s-4.7 6.7-8 16c-42 98.7-107.3 174.7-196 228-6.7 4.7
-10.7 8-12 10-1.3 2-2 5.7-2 11zm100-26v40h399900v-40zM0 435v40h400000v-40z
m0 0v40h400000v-40z`, leftharpoondown: `M7 241c-4 4-6.333 8.667-7 14 0 5.333.667 9 2 11s5.333
 5.333 12 10c90.667 54 156 130 196 228 3.333 10.667 6.333 16.333 9 17 2 .667 5
 1 9 1h5c10.667 0 16.667-2 18-6 2-2.667 1-9.667-3-21-32-87.333-82.667-157.667
-152-211l-3-3h399907v-40zM93 281 H400000 v-40L7 241z`, leftharpoondownplus: `M7 435c-4 4-6.3 8.7-7 14 0 5.3.7 9 2 11s5.3 5.3 12
 10c90.7 54 156 130 196 228 3.3 10.7 6.3 16.3 9 17 2 .7 5 1 9 1h5c10.7 0 16.7
-2 18-6 2-2.7 1-9.7-3-21-32-87.3-82.7-157.7-152-211l-3-3h399907v-40H7zm93 0
v40h399900v-40zM0 241v40h399900v-40zm0 0v40h399900v-40z`, lefthook: `M400000 281 H103s-33-11.2-61-33.5S0 197.3 0 164s14.2-61.2 42.5
-83.5C70.8 58.2 104 47 142 47 c16.7 0 25 6.7 25 20 0 12-8.7 18.7-26 20-40 3.3
-68.7 15.7-86 37-10 12-15 25.3-15 40 0 22.7 9.8 40.7 29.5 54 19.7 13.3 43.5 21
 71.5 23h399859zM103 281v-40h399897v40z`, leftlinesegment: r0("M40 281 V428 H0 V94 H40 V241 H400000 v40z"), leftbracketunder: r0("M0 0 h120 V290 H399995 v120 H0z"), leftbracketover: r0("M0 440 h120 V150 H399995 v-120 H0z"), leftmapsto: r0("M40 281 V448H0V74H40V241H400000v40z"), leftToFrom: `M0 147h400000v40H0zm0 214c68 40 115.7 95.7 143 167h22c15.3 0 23
-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69-70-101l-7-8h399905v-40H95l7-8
c28.7-32 52-65.7 70-101 10.7-23.3 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 265.3
 68 321 0 361zm0-174v-40h399900v40zm100 154v40h399900v-40z`, longequal: r0("M0 50 h400000 v40H0z m0 194h40000v40H0z"), midbrace: `M200428 334
c-100.7-8.3-195.3-44-280-108-55.3-42-101.7-93-139-153l-9-14c-2.7 4-5.7 8.7-9 14
-53.3 86.7-123.7 153-211 199-66.7 36-137.3 56.3-212 62H0V214h199568c178.3-11.7
 311.7-78.3 403-201 6-8 9.7-12 11-12 .7-.7 6.7-1 18-1s17.3.3 18 1c1.3 0 5 4 11
 12 44.7 59.3 101.3 106.3 170 141s145.3 54.3 229 60h199572v120z`, midbraceunder: `M199572 214
c100.7 8.3 195.3 44 280 108 55.3 42 101.7 93 139 153l9 14c2.7-4 5.7-8.7 9-14
 53.3-86.7 123.7-153 211-199 66.7-36 137.3-56.3 212-62h199568v120H200432c-178.3
 11.7-311.7 78.3-403 201-6 8-9.7 12-11 12-.7.7-6.7 1-18 1s-17.3-.3-18-1c-1.3 0
-5-4-11-12-44.7-59.3-101.3-106.3-170-141s-145.3-54.3-229-60H0V214z`, oiintSize1: `M512.6 71.6c272.6 0 320.3 106.8 320.3 178.2 0 70.8-47.7 177.6
-320.3 177.6S193.1 320.6 193.1 249.8c0-71.4 46.9-178.2 319.5-178.2z
m368.1 178.2c0-86.4-60.9-215.4-368.1-215.4-306.4 0-367.3 129-367.3 215.4 0 85.8
60.9 214.8 367.3 214.8 307.2 0 368.1-129 368.1-214.8z`, oiintSize2: `M757.8 100.1c384.7 0 451.1 137.6 451.1 230 0 91.3-66.4 228.8
-451.1 228.8-386.3 0-452.7-137.5-452.7-228.8 0-92.4 66.4-230 452.7-230z
m502.4 230c0-111.2-82.4-277.2-502.4-277.2s-504 166-504 277.2
c0 110 84 276 504 276s502.4-166 502.4-276z`, oiiintSize1: `M681.4 71.6c408.9 0 480.5 106.8 480.5 178.2 0 70.8-71.6 177.6
-480.5 177.6S202.1 320.6 202.1 249.8c0-71.4 70.5-178.2 479.3-178.2z
m525.8 178.2c0-86.4-86.8-215.4-525.7-215.4-437.9 0-524.7 129-524.7 215.4 0
85.8 86.8 214.8 524.7 214.8 438.9 0 525.7-129 525.7-214.8z`, oiiintSize2: `M1021.2 53c603.6 0 707.8 165.8 707.8 277.2 0 110-104.2 275.8
-707.8 275.8-606 0-710.2-165.8-710.2-275.8C311 218.8 415.2 53 1021.2 53z
m770.4 277.1c0-131.2-126.4-327.6-770.5-327.6S248.4 198.9 248.4 330.1
c0 130 128.8 326.4 772.7 326.4s770.5-196.4 770.5-326.4z`, rightarrow: `M0 241v40h399891c-47.3 35.3-84 78-110 128
-16.7 32-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20
 11 8 0 13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7
 39-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85
-40.5-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
 151.7 139 205zm0 0v40h399900v-40z`, rightbrace: `M400000 542l
-6 6h-17c-12.7 0-19.3-.3-20-1-4-4-7.3-8.3-10-13-35.3-51.3-80.8-93.8-136.5-127.5
s-117.2-55.8-184.5-66.5c-.7 0-2-.3-4-1-18.7-2.7-76-4.3-172-5H0V214h399571l6 1
c124.7 8 235 61.7 331 161 31.3 33.3 59.7 72.7 85 118l7 13v35z`, rightbraceunder: `M399994 0l6 6v35l-6 11c-56 104-135.3 181.3-238 232-57.3
 28.7-117 45-179 50H-300V214h399897c43.3-7 81-15 113-26 100.7-33 179.7-91 237
-174 2.7-5 6-9 10-13 .7-1 7.3-1 20-1h17z`, rightgroup: `M0 80h399565c371 0 266.7 149.4 414 180 5.9 1.2 18 0 18 0 2 0
 3-1 3-3v-38c-76-158-257-219-435-219H0z`, rightgroupunder: `M0 262h399565c371 0 266.7-149.4 414-180 5.9-1.2 18 0 18
 0 2 0 3 1 3 3v38c-76 158-257 219-435 219H0z`, rightharpoon: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3
-3.7-15.3-11-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2
-10.7 0-16.7 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58
 69.2 92 94.5zm0 0v40h399900v-40z`, rightharpoonplus: `M0 241v40h399993c4.7-4.7 7-9.3 7-14 0-9.3-3.7-15.3-11
-18-92.7-56.7-159-133.7-199-231-3.3-9.3-6-14.7-8-16-2-1.3-7-2-15-2-10.7 0-16.7
 2-18 6-2 2.7-1 9.7 3 21 15.3 42 36.7 81.8 64 119.5 27.3 37.7 58 69.2 92 94.5z
m0 0v40h399900v-40z m100 194v40h399900v-40zm0 0v40h399900v-40z`, rightharpoondown: `M399747 511c0 7.3 6.7 11 20 11 8 0 13-.8 15-2.5s4.7-6.8
 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3 8.5-5.8 9.5
-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3-64.7 57-92 95
-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 241v40h399900v-40z`, rightharpoondownplus: `M399747 705c0 7.3 6.7 11 20 11 8 0 13-.8
 15-2.5s4.7-6.8 8-15.5c40-94 99.3-166.3 178-217 13.3-8 20.3-12.3 21-13 5.3-3.3
 8.5-5.8 9.5-7.5 1-1.7 1.5-5.2 1.5-10.5s-2.3-10.3-7-15H0v40h399908c-34 25.3
-64.7 57-92 95-27.3 38-48.7 77.7-64 119-3.3 8.7-5 14-5 16zM0 435v40h399900v-40z
m0-194v40h400000v-40zm0 0v40h400000v-40z`, righthook: `M399859 241c-764 0 0 0 0 0 40-3.3 68.7-15.7 86-37 10-12 15-25.3
 15-40 0-22.7-9.8-40.7-29.5-54-19.7-13.3-43.5-21-71.5-23-17.3-1.3-26-8-26-20 0
-13.3 8.7-20 26-20 38 0 71 11.2 99 33.5 0 0 7 5.6 21 16.7 14 11.2 21 33.5 21
 66.8s-14 61.2-42 83.5c-28 22.3-61 33.5-99 33.5L0 241z M0 281v-40h399859v40z`, rightlinesegment: r0("M399960 241 V94 h40 V428 h-40 V281 H0 v-40z"), rightbracketunder: r0("M399995 0 h-120 V290 H0 v120 H400000z"), rightbracketover: r0("M399995 440 h-120 V150 H0 v-120 H399995z"), rightToFrom: `M400000 167c-70.7-42-118-97.7-142-167h-23c-15.3 0-23 .3-23
 1 0 1.3 5.3 13.7 16 37 18 35.3 41.3 69 70 101l7 8H0v40h399905l-7 8c-28.7 32
-52 65.7-70 101-10.7 23.3-16 35.7-16 37 0 .7 7.7 1 23 1h23c24-69.3 71.3-125 142
-167z M100 147v40h399900v-40zM0 341v40h399900v-40z`, twoheadleftarrow: `M0 167c68 40
 115.7 95.7 143 167h22c15.3 0 23-.3 23-1 0-1.3-5.3-13.7-16-37-18-35.3-41.3-69
-70-101l-7-8h125l9 7c50.7 39.3 85 86 103 140h46c0-4.7-6.3-18.7-19-42-18-35.3
-40-67.3-66-96l-9-9h399716v-40H284l9-9c26-28.7 48-60.7 66-96 12.7-23.333 19
-37.333 19-42h-46c-18 54-52.3 100.7-103 140l-9 7H95l7-8c28.7-32 52-65.7 70-101
 10.7-23.333 16-35.7 16-37 0-.7-7.7-1-23-1h-22C115.7 71.3 68 127 0 167z`, twoheadrightarrow: `M400000 167
c-68-40-115.7-95.7-143-167h-22c-15.3 0-23 .3-23 1 0 1.3 5.3 13.7 16 37 18 35.3
 41.3 69 70 101l7 8h-125l-9-7c-50.7-39.3-85-86-103-140h-46c0 4.7 6.3 18.7 19 42
 18 35.3 40 67.3 66 96l9 9H0v40h399716l-9 9c-26 28.7-48 60.7-66 96-12.7 23.333
-19 37.333-19 42h46c18-54 52.3-100.7 103-140l9-7h125l-7 8c-28.7 32-52 65.7-70
 101-10.7 23.333-16 35.7-16 37 0 .7 7.7 1 23 1h22c27.3-71.3 75-127 143-167z`, tilde1: `M200 55.538c-77 0-168 73.953-177 73.953-3 0-7
-2.175-9-5.437L2 97c-1-2-2-4-2-6 0-4 2-7 5-9l20-12C116 12 171 0 207 0c86 0
 114 68 191 68 78 0 168-68 177-68 4 0 7 2 9 5l12 19c1 2.175 2 4.35 2 6.525 0
 4.35-2 7.613-5 9.788l-19 13.05c-92 63.077-116.937 75.308-183 76.128
-68.267.847-113-73.952-191-73.952z`, tilde2: `M344 55.266c-142 0-300.638 81.316-311.5 86.418
-8.01 3.762-22.5 10.91-23.5 5.562L1 120c-1-2-1-3-1-4 0-5 3-9 8-10l18.4-9C160.9
 31.9 283 0 358 0c148 0 188 122 331 122s314-97 326-97c4 0 8 2 10 7l7 21.114
c1 2.14 1 3.21 1 4.28 0 5.347-3 9.626-7 10.696l-22.3 12.622C852.6 158.372 751
 181.476 676 181.476c-149 0-189-126.21-332-126.21z`, tilde3: `M786 59C457 59 32 175.242 13 175.242c-6 0-10-3.457
-11-10.37L.15 138c-1-7 3-12 10-13l19.2-6.4C378.4 40.7 634.3 0 804.3 0c337 0
 411.8 157 746.8 157 328 0 754-112 773-112 5 0 10 3 11 9l1 14.075c1 8.066-.697
 16.595-6.697 17.492l-21.052 7.31c-367.9 98.146-609.15 122.696-778.15 122.696
 -338 0-409-156.573-744-156.573z`, tilde4: `M786 58C457 58 32 177.487 13 177.487c-6 0-10-3.345
-11-10.035L.15 143c-1-7 3-12 10-13l22-6.7C381.2 35 637.15 0 807.15 0c337 0 409
 177 744 177 328 0 754-127 773-127 5 0 10 3 11 9l1 14.794c1 7.805-3 13.38-9
 14.495l-20.7 5.574c-366.85 99.79-607.3 139.372-776.3 139.372-338 0-409
 -175.236-744-175.236z`, vec: `M377 20c0-5.333 1.833-10 5.5-14S391 0 397 0c4.667 0 8.667 1.667 12 5
3.333 2.667 6.667 9 10 19 6.667 24.667 20.333 43.667 41 57 7.333 4.667 11
10.667 11 18 0 6-1 10-3 12s-6.667 5-14 9c-28.667 14.667-53.667 35.667-75 63
-1.333 1.333-3.167 3.5-5.5 6.5s-4 4.833-5 5.5c-1 .667-2.5 1.333-4.5 2s-4.333 1
-7 1c-4.667 0-9.167-1.833-13.5-5.5S337 184 337 178c0-12.667 15.667-32.333 47-59
H213l-171-1c-8.667-6-13-12.333-13-19 0-4.667 4.333-11.333 13-20h359
c-16-25.333-24-45-24-59z`, widehat1: `M529 0h5l519 115c5 1 9 5 9 10 0 1-1 2-1 3l-4 22
c-1 5-5 9-11 9h-2L532 67 19 159h-2c-5 0-9-4-11-9l-5-22c-1-6 2-12 8-13z`, widehat2: `M1181 0h2l1171 176c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 220h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`, widehat3: `M1181 0h2l1171 236c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 280h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`, widehat4: `M1181 0h2l1171 296c6 0 10 5 10 11l-2 23c-1 6-5 10
-11 10h-1L1182 67 15 340h-1c-6 0-10-4-11-10l-2-23c-1-6 4-11 10-11z`, widecheck1: `M529,159h5l519,-115c5,-1,9,-5,9,-10c0,-1,-1,-2,-1,-3l-4,-22c-1,
-5,-5,-9,-11,-9h-2l-512,92l-513,-92h-2c-5,0,-9,4,-11,9l-5,22c-1,6,2,12,8,13z`, widecheck2: `M1181,220h2l1171,-176c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,153l-1167,-153h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`, widecheck3: `M1181,280h2l1171,-236c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,213l-1167,-213h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`, widecheck4: `M1181,340h2l1171,-296c6,0,10,-5,10,-11l-2,-23c-1,-6,-5,-10,
-11,-10h-1l-1168,273l-1167,-273h-1c-6,0,-10,4,-11,10l-2,23c-1,6,4,11,10,11z`, baraboveleftarrow: `M400000 620h-399890l3 -3c68.7 -52.7 113.7 -120 135 -202
c4 -14.7 6 -23 6 -25c0 -7.3 -7 -11 -21 -11c-8 0 -13.2 0.8 -15.5 2.5
c-2.3 1.7 -4.2 5.8 -5.5 12.5c-1.3 4.7 -2.7 10.3 -4 17c-12 48.7 -34.8 92 -68.5 130
s-74.2 66.3 -121.5 85c-10 4 -16 7.7 -18 11c0 8.7 6 14.3 18 17c47.3 18.7 87.8 47
121.5 85s56.5 81.3 68.5 130c0.7 2 1.3 5 2 9s1.2 6.7 1.5 8c0.3 1.3 1 3.3 2 6
s2.2 4.5 3.5 5.5c1.3 1 3.3 1.8 6 2.5s6 1 10 1c14 0 21 -3.7 21 -11
c0 -2 -2 -10.3 -6 -25c-20 -79.3 -65 -146.7 -135 -202l-3 -3h399890z
M100 620v40h399900v-40z M0 241v40h399900v-40zM0 241v40h399900v-40z`, rightarrowabovebar: `M0 241v40h399891c-47.3 35.3-84 78-110 128-16.7 32
-27.7 63.7-33 95 0 1.3-.2 2.7-.5 4-.3 1.3-.5 2.3-.5 3 0 7.3 6.7 11 20 11 8 0
13.2-.8 15.5-2.5 2.3-1.7 4.2-5.5 5.5-11.5 2-13.3 5.7-27 11-41 14.7-44.7 39
-84.5 73-119.5s73.7-60.2 119-75.5c6-2 9-5.7 9-11s-3-9-9-11c-45.3-15.3-85-40.5
-119-75.5s-58.3-74.8-73-119.5c-4.7-14-8.3-27.3-11-40-1.3-6.7-3.2-10.8-5.5
-12.5-2.3-1.7-7.5-2.5-15.5-2.5-14 0-21 3.7-21 11 0 2 2 10.3 6 25 20.7 83.3 67
151.7 139 205zm96 379h399894v40H0zm0 0h399904v40H0z`, baraboveshortleftharpoon: `M507,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17
c2,0.7,5,1,9,1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21
c-32,-87.3,-82.7,-157.7,-152,-211c0,0,-3,-3,-3,-3l399351,0l0,-40
c-398570,0,-399437,0,-399437,0z M593 435 v40 H399500 v-40z
M0 281 v-40 H399908 v40z M0 281 v-40 H399908 v40z`, rightharpoonaboveshortbar: `M0,241 l0,40c399126,0,399993,0,399993,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M0 241 v40 H399908 v-40z M0 475 v-40 H399500 v40z M0 475 v-40 H399500 v40z`, shortbaraboveleftharpoon: `M7,435c-4,4,-6.3,8.7,-7,14c0,5.3,0.7,9,2,11
c1.3,2,5.3,5.3,12,10c90.7,54,156,130,196,228c3.3,10.7,6.3,16.3,9,17c2,0.7,5,1,9,
1c0,0,5,0,5,0c10.7,0,16.7,-2,18,-6c2,-2.7,1,-9.7,-3,-21c-32,-87.3,-82.7,-157.7,
-152,-211c0,0,-3,-3,-3,-3l399907,0l0,-40c-399126,0,-399993,0,-399993,0z
M93 435 v40 H400000 v-40z M500 241 v40 H400000 v-40z M500 241 v40 H400000 v-40z`, shortrightharpoonabovebar: `M53,241l0,40c398570,0,399437,0,399437,0
c4.7,-4.7,7,-9.3,7,-14c0,-9.3,-3.7,-15.3,-11,-18c-92.7,-56.7,-159,-133.7,-199,
-231c-3.3,-9.3,-6,-14.7,-8,-16c-2,-1.3,-7,-2,-15,-2c-10.7,0,-16.7,2,-18,6
c-2,2.7,-1,9.7,3,21c15.3,42,36.7,81.8,64,119.5c27.3,37.7,58,69.2,92,94.5z
M500 241 v40 H399408 v-40z M500 435 v40 H400000 v-40z` }, ba = function (e, t) {
    switch (e) {
        case "lbrack": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v1759 v84 h347 v-84
H403z M403 1759 V0 H319 V1759 v` + t + " v1759 v84 h84z";
        case "rbrack": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v1759 H0 v84 H347z
M347 1759 V0 H263 V1759 v` + t + " v1759 h84z";
        case "vert": return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + " v585 h43z";
        case "doublevert": return "M145 15 v585 v" + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M188 15 H145 v585 v` + t + ` v585 h43z
M367 15 v585 v` + t + ` v585 c2.667,10,9.667,15,21,15
c10,0,16.667,-5,20,-15 v-585 v` + -t + ` v-585 c-2.667,-10,-9.667,-15,-21,-15
c-10,0,-16.667,5,-20,15z M410 15 H367 v585 v` + t + " v585 h43z";
        case "lfloor": return "M319 602 V0 H403 V602 v" + t + ` v1715 h263 v84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
        case "rfloor": return "M319 602 V0 H403 V602 v" + t + ` v1799 H0 v-84 H319z
MM319 602 V0 H403 V602 v` + t + " v1715 H319z";
        case "lceil": return "M403 1759 V84 H666 V0 H319 V1759 v" + t + ` v602 h84z
M403 1759 V0 H319 V1759 v` + t + " v602 h84z";
        case "rceil": return "M347 1759 V0 H0 V84 H263 V1759 v" + t + ` v602 h84z
M347 1759 V0 h-84 V1759 v` + t + " v602 h84z";
        case "lparen": return `M863,9c0,-2,-2,-5,-6,-9c0,0,-17,0,-17,0c-12.7,0,-19.3,0.3,-20,1
c-5.3,5.3,-10.3,11,-15,17c-242.7,294.7,-395.3,682,-458,1162c-21.3,163.3,-33.3,349,
-36,557 l0,` + (t + 84) + `c0.2,6,0,26,0,60c2,159.3,10,310.7,24,454c53.3,528,210,
949.7,470,1265c4.7,6,9.7,11.7,15,17c0.7,0.7,7,1,19,1c0,0,18,0,18,0c4,-4,6,-7,6,-9
c0,-2.7,-3.3,-8.7,-10,-18c-135.3,-192.7,-235.5,-414.3,-300.5,-665c-65,-250.7,-102.5,
-544.7,-112.5,-882c-2,-104,-3,-167,-3,-189
l0,-` + (t + 92) + `c0,-162.7,5.7,-314,17,-454c20.7,-272,63.7,-513,129,-723c65.3,
-210,155.3,-396.3,270,-559c6.7,-9.3,10,-15.3,10,-18z`;
        case "rparen": return `M76,0c-16.7,0,-25,3,-25,9c0,2,2,6.3,6,13c21.3,28.7,42.3,60.3,
63,95c96.7,156.7,172.8,332.5,228.5,527.5c55.7,195,92.8,416.5,111.5,664.5
c11.3,139.3,17,290.7,17,454c0,28,1.7,43,3.3,45l0,` + (t + 9) + `
c-3,4,-3.3,16.7,-3.3,38c0,162,-5.7,313.7,-17,455c-18.7,248,-55.8,469.3,-111.5,664
c-55.7,194.7,-131.8,370.3,-228.5,527c-20.7,34.7,-41.7,66.3,-63,95c-2,3.3,-4,7,-6,11
c0,7.3,5.7,11,17,11c0,0,11,0,11,0c9.3,0,14.3,-0.3,15,-1c5.3,-5.3,10.3,-11,15,-17
c242.7,-294.7,395.3,-681.7,458,-1161c21.3,-164.7,33.3,-350.7,36,-558
l0,-` + (t + 144) + `c-2,-159.3,-10,-310.7,-24,-454c-53.3,-528,-210,-949.7,
-470,-1265c-4.7,-6,-9.7,-11.7,-15,-17c-0.7,-0.7,-6.7,-1,-18,-1z`;
        default: throw new Error("Unknown stretchy delimiter.");
    }
};
function ya(r) { return "toText" in r; }
var P0 = class {
    constructor(e) { this.children = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.children = e, this.classes = [], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = {}; }
    hasClass(e) { return this.classes.includes(e); }
    toNode() { for (var e = document.createDocumentFragment(), t = 0; t < this.children.length; t++)
        e.appendChild(this.children[t].toNode()); return e; }
    toMarkup() { for (var e = "", t = 0; t < this.children.length; t++)
        e += this.children[t].toMarkup(); return e; }
    toText() { return this.children.map(e => { if (ya(e))
        return e.toText(); throw new Error("Expected MathDomNode with toText, got " + e.constructor.name); }).join(""); }
}, xt = { pt: 1, mm: 7227 / 2540, cm: 7227 / 254, in: 72.27, bp: 803 / 800, pc: 12, dd: 1238 / 1157, cc: 14856 / 1157, nd: 685 / 642, nc: 1370 / 107, sp: 1 / 65536, px: 803 / 800 }, xa = { ex: !0, em: !0, mu: !0 }, Yr = function (e) { return typeof e != "string" && (e = e.unit), e in xt || e in xa || e === "ex"; }, J = function (e, t) { var a; if (e.unit in xt)
    a = xt[e.unit] / t.fontMetrics().ptPerEm / t.sizeMultiplier;
else if (e.unit === "mu")
    a = t.fontMetrics().cssEmPerMu;
else {
    var i;
    if (t.style.isTight() ? i = t.havingStyle(t.style.text()) : i = t, e.unit === "ex")
        a = i.fontMetrics().xHeight;
    else if (e.unit === "em")
        a = i.fontMetrics().quad;
    else
        throw new z("Invalid unit: '" + e.unit + "'");
    i !== t && (a *= i.sizeMultiplier / t.sizeMultiplier);
} return Math.min(e.number * a, t.maxSize); }, A = function (e) { return +e.toFixed(4) + "em"; }, G0 = function (e) { return e.filter(t => t).join(" "); }, Pt = function (e) { var t = ""; for (var a of Object.keys(e)) {
    var i = e[a];
    i !== void 0 && (t += j1(a) + ":" + i + ";");
} return t; }, $r = function (e, t, a) { if (this.classes = e || [], this.attributes = {}, this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a || {}, t) {
    t.style.isTight() && this.classes.push("mtight");
    var i = t.getColor();
    i && (this.style.color = i);
} }, Wr = function (e) { var t = document.createElement(e); t.className = G0(this.classes), Object.assign(t.style, this.style); for (var a of Object.keys(this.attributes))
    t.setAttribute(a, this.attributes[a]); for (var i = 0; i < this.children.length; i++)
    t.appendChild(this.children[i].toNode()); return t; }, wa = /[\s"'>/=\x00-\x1f]/, jr = function (e) { var t = "<" + e; this.classes.length && (t += ' class="' + n0(G0(this.classes)) + '"'); var a = Pt(this.style); a && (t += ' style="' + n0(a) + '"'); for (var i of Object.keys(this.attributes)) {
    if (wa.test(i))
        throw new z("Invalid attribute name '" + i + "'");
    t += " " + i + '="' + n0(this.attributes[i]) + '"';
} t += ">"; for (var s = 0; s < this.children.length; s++)
    t += this.children[s].toMarkup(); return t += "</" + e + ">", t; }, U0 = class {
    constructor(e, t, a, i) { this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.width = void 0, this.maxFontSize = void 0, this.style = void 0, this.italic = void 0, $r.call(this, e, a, i), this.children = t || []; }
    setAttribute(e, t) { this.attributes[e] = t; }
    hasClass(e) { return this.classes.includes(e); }
    toNode() { return Wr.call(this, "span"); }
    toMarkup() { return jr.call(this, "span"); }
}, re = class {
    constructor(e, t, a, i) { this.children = void 0, this.attributes = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, $r.call(this, t, i), this.children = a || [], this.setAttribute("href", e); }
    setAttribute(e, t) { this.attributes[e] = t; }
    hasClass(e) { return this.classes.includes(e); }
    toNode() { return Wr.call(this, "a"); }
    toMarkup() { return jr.call(this, "a"); }
}, wt = class {
    constructor(e, t, a) { this.src = void 0, this.alt = void 0, this.classes = void 0, this.height = void 0, this.depth = void 0, this.maxFontSize = void 0, this.style = void 0, this.alt = t, this.src = e, this.classes = ["mord"], this.height = 0, this.depth = 0, this.maxFontSize = 0, this.style = a; }
    hasClass(e) { return this.classes.includes(e); }
    toNode() { var e = document.createElement("img"); return e.src = this.src, e.alt = this.alt, e.className = "mord", Object.assign(e.style, this.style), e; }
    toMarkup() { var e = '<img src="' + n0(this.src) + '"' + (' alt="' + n0(this.alt) + '"'), t = Pt(this.style); return t && (e += ' style="' + n0(t) + '"'), e += "'/>", e; }
}, ka = { \u00EE: "\u0131\u0302", \u00EF: "\u0131\u0308", \u00ED: "\u0131\u0301", \u00EC: "\u0131\u0300" }, u0 = class {
    constructor(e, t, a, i, s, u, h, c) { this.text = void 0, this.height = void 0, this.depth = void 0, this.italic = void 0, this.skew = void 0, this.width = void 0, this.maxFontSize = void 0, this.classes = void 0, this.style = void 0, this.text = e, this.height = t || 0, this.depth = a || 0, this.italic = i || 0, this.skew = s || 0, this.width = u || 0, this.classes = h || [], this.style = c || {}, this.maxFontSize = 0; var v = ua(this.text.charCodeAt(0)); v && this.classes.push(v + "_fallback"), /[îïíì]/.test(this.text) && (this.text = ka[this.text]); }
    hasClass(e) { return this.classes.includes(e); }
    toNode() { var e = document.createTextNode(this.text), t = null; return this.italic > 0 && (t = document.createElement("span"), t.style.marginRight = A(this.italic)), this.classes.length > 0 && (t = t || document.createElement("span"), t.className = G0(this.classes)), Object.keys(this.style).length > 0 && (t = t || document.createElement("span"), Object.assign(t.style, this.style)), t ? (t.appendChild(e), t) : e; }
    toMarkup() { var e = !1, t = "<span"; this.classes.length && (e = !0, t += ' class="', t += n0(G0(this.classes)), t += '"'); var a = ""; this.italic > 0 && (a += "margin-right:" + A(this.italic) + ";"), a += Pt(this.style), a && (e = !0, t += ' style="' + n0(a) + '"'); var i = n0(this.text); return e ? (t += ">", t += i, t += "</span>", t) : i; }
}, x0 = class {
    constructor(e, t) { this.children = void 0, this.attributes = void 0, this.children = e || [], this.attributes = t || {}; }
    toNode() { var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "svg"); for (var a of Object.keys(this.attributes))
        t.setAttribute(a, this.attributes[a]); for (var i = 0; i < this.children.length; i++)
        t.appendChild(this.children[i].toNode()); return t; }
    toMarkup() { var e = '<svg xmlns="http://www.w3.org/2000/svg"'; for (var t of Object.keys(this.attributes))
        e += " " + t + '="' + n0(this.attributes[t]) + '"'; e += ">"; for (var a = 0; a < this.children.length; a++)
        e += this.children[a].toMarkup(); return e += "</svg>", e; }
}, A0 = class {
    constructor(e, t) { this.pathName = void 0, this.alternate = void 0, this.pathName = e, this.alternate = t; }
    toNode() { var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "path"); return this.alternate ? t.setAttribute("d", this.alternate) : t.setAttribute("d", or[this.pathName]), t; }
    toMarkup() { return this.alternate ? '<path d="' + n0(this.alternate) + '"/>' : '<path d="' + n0(or[this.pathName]) + '"/>'; }
}, ve = class {
    constructor(e) { this.attributes = void 0, this.attributes = e || {}; }
    toNode() { var e = "http://www.w3.org/2000/svg", t = document.createElementNS(e, "line"); for (var a of Object.keys(this.attributes))
        t.setAttribute(a, this.attributes[a]); return t; }
    toMarkup() { var e = "<line"; for (var t of Object.keys(this.attributes))
        e += " " + t + '="' + n0(this.attributes[t]) + '"'; return e += "/>", e; }
};
function Sa(r) { if (r instanceof u0)
    return r; throw new Error("Expected symbolNode but got " + String(r) + "."); }
function za(r) { if (r instanceof U0)
    return r; throw new Error("Expected span<HtmlDomNode> but got " + String(r) + "."); }
var Aa = r => r instanceof U0 || r instanceof re || r instanceof P0, z0 = { "AMS-Regular": { 32: [0, 0, 0, 0, .25], 65: [0, .68889, 0, 0, .72222], 66: [0, .68889, 0, 0, .66667], 67: [0, .68889, 0, 0, .72222], 68: [0, .68889, 0, 0, .72222], 69: [0, .68889, 0, 0, .66667], 70: [0, .68889, 0, 0, .61111], 71: [0, .68889, 0, 0, .77778], 72: [0, .68889, 0, 0, .77778], 73: [0, .68889, 0, 0, .38889], 74: [.16667, .68889, 0, 0, .5], 75: [0, .68889, 0, 0, .77778], 76: [0, .68889, 0, 0, .66667], 77: [0, .68889, 0, 0, .94445], 78: [0, .68889, 0, 0, .72222], 79: [.16667, .68889, 0, 0, .77778], 80: [0, .68889, 0, 0, .61111], 81: [.16667, .68889, 0, 0, .77778], 82: [0, .68889, 0, 0, .72222], 83: [0, .68889, 0, 0, .55556], 84: [0, .68889, 0, 0, .66667], 85: [0, .68889, 0, 0, .72222], 86: [0, .68889, 0, 0, .72222], 87: [0, .68889, 0, 0, 1], 88: [0, .68889, 0, 0, .72222], 89: [0, .68889, 0, 0, .72222], 90: [0, .68889, 0, 0, .66667], 107: [0, .68889, 0, 0, .55556], 160: [0, 0, 0, 0, .25], 165: [0, .675, .025, 0, .75], 174: [.15559, .69224, 0, 0, .94666], 240: [0, .68889, 0, 0, .55556], 295: [0, .68889, 0, 0, .54028], 710: [0, .825, 0, 0, 2.33334], 732: [0, .9, 0, 0, 2.33334], 770: [0, .825, 0, 0, 2.33334], 771: [0, .9, 0, 0, 2.33334], 989: [.08167, .58167, 0, 0, .77778], 1008: [0, .43056, .04028, 0, .66667], 8245: [0, .54986, 0, 0, .275], 8463: [0, .68889, 0, 0, .54028], 8487: [0, .68889, 0, 0, .72222], 8498: [0, .68889, 0, 0, .55556], 8502: [0, .68889, 0, 0, .66667], 8503: [0, .68889, 0, 0, .44445], 8504: [0, .68889, 0, 0, .66667], 8513: [0, .68889, 0, 0, .63889], 8592: [-.03598, .46402, 0, 0, .5], 8594: [-.03598, .46402, 0, 0, .5], 8602: [-.13313, .36687, 0, 0, 1], 8603: [-.13313, .36687, 0, 0, 1], 8606: [.01354, .52239, 0, 0, 1], 8608: [.01354, .52239, 0, 0, 1], 8610: [.01354, .52239, 0, 0, 1.11111], 8611: [.01354, .52239, 0, 0, 1.11111], 8619: [0, .54986, 0, 0, 1], 8620: [0, .54986, 0, 0, 1], 8621: [-.13313, .37788, 0, 0, 1.38889], 8622: [-.13313, .36687, 0, 0, 1], 8624: [0, .69224, 0, 0, .5], 8625: [0, .69224, 0, 0, .5], 8630: [0, .43056, 0, 0, 1], 8631: [0, .43056, 0, 0, 1], 8634: [.08198, .58198, 0, 0, .77778], 8635: [.08198, .58198, 0, 0, .77778], 8638: [.19444, .69224, 0, 0, .41667], 8639: [.19444, .69224, 0, 0, .41667], 8642: [.19444, .69224, 0, 0, .41667], 8643: [.19444, .69224, 0, 0, .41667], 8644: [.1808, .675, 0, 0, 1], 8646: [.1808, .675, 0, 0, 1], 8647: [.1808, .675, 0, 0, 1], 8648: [.19444, .69224, 0, 0, .83334], 8649: [.1808, .675, 0, 0, 1], 8650: [.19444, .69224, 0, 0, .83334], 8651: [.01354, .52239, 0, 0, 1], 8652: [.01354, .52239, 0, 0, 1], 8653: [-.13313, .36687, 0, 0, 1], 8654: [-.13313, .36687, 0, 0, 1], 8655: [-.13313, .36687, 0, 0, 1], 8666: [.13667, .63667, 0, 0, 1], 8667: [.13667, .63667, 0, 0, 1], 8669: [-.13313, .37788, 0, 0, 1], 8672: [-.064, .437, 0, 0, 1.334], 8674: [-.064, .437, 0, 0, 1.334], 8705: [0, .825, 0, 0, .5], 8708: [0, .68889, 0, 0, .55556], 8709: [.08167, .58167, 0, 0, .77778], 8717: [0, .43056, 0, 0, .42917], 8722: [-.03598, .46402, 0, 0, .5], 8724: [.08198, .69224, 0, 0, .77778], 8726: [.08167, .58167, 0, 0, .77778], 8733: [0, .69224, 0, 0, .77778], 8736: [0, .69224, 0, 0, .72222], 8737: [0, .69224, 0, 0, .72222], 8738: [.03517, .52239, 0, 0, .72222], 8739: [.08167, .58167, 0, 0, .22222], 8740: [.25142, .74111, 0, 0, .27778], 8741: [.08167, .58167, 0, 0, .38889], 8742: [.25142, .74111, 0, 0, .5], 8756: [0, .69224, 0, 0, .66667], 8757: [0, .69224, 0, 0, .66667], 8764: [-.13313, .36687, 0, 0, .77778], 8765: [-.13313, .37788, 0, 0, .77778], 8769: [-.13313, .36687, 0, 0, .77778], 8770: [-.03625, .46375, 0, 0, .77778], 8774: [.30274, .79383, 0, 0, .77778], 8776: [-.01688, .48312, 0, 0, .77778], 8778: [.08167, .58167, 0, 0, .77778], 8782: [.06062, .54986, 0, 0, .77778], 8783: [.06062, .54986, 0, 0, .77778], 8785: [.08198, .58198, 0, 0, .77778], 8786: [.08198, .58198, 0, 0, .77778], 8787: [.08198, .58198, 0, 0, .77778], 8790: [0, .69224, 0, 0, .77778], 8791: [.22958, .72958, 0, 0, .77778], 8796: [.08198, .91667, 0, 0, .77778], 8806: [.25583, .75583, 0, 0, .77778], 8807: [.25583, .75583, 0, 0, .77778], 8808: [.25142, .75726, 0, 0, .77778], 8809: [.25142, .75726, 0, 0, .77778], 8812: [.25583, .75583, 0, 0, .5], 8814: [.20576, .70576, 0, 0, .77778], 8815: [.20576, .70576, 0, 0, .77778], 8816: [.30274, .79383, 0, 0, .77778], 8817: [.30274, .79383, 0, 0, .77778], 8818: [.22958, .72958, 0, 0, .77778], 8819: [.22958, .72958, 0, 0, .77778], 8822: [.1808, .675, 0, 0, .77778], 8823: [.1808, .675, 0, 0, .77778], 8828: [.13667, .63667, 0, 0, .77778], 8829: [.13667, .63667, 0, 0, .77778], 8830: [.22958, .72958, 0, 0, .77778], 8831: [.22958, .72958, 0, 0, .77778], 8832: [.20576, .70576, 0, 0, .77778], 8833: [.20576, .70576, 0, 0, .77778], 8840: [.30274, .79383, 0, 0, .77778], 8841: [.30274, .79383, 0, 0, .77778], 8842: [.13597, .63597, 0, 0, .77778], 8843: [.13597, .63597, 0, 0, .77778], 8847: [.03517, .54986, 0, 0, .77778], 8848: [.03517, .54986, 0, 0, .77778], 8858: [.08198, .58198, 0, 0, .77778], 8859: [.08198, .58198, 0, 0, .77778], 8861: [.08198, .58198, 0, 0, .77778], 8862: [0, .675, 0, 0, .77778], 8863: [0, .675, 0, 0, .77778], 8864: [0, .675, 0, 0, .77778], 8865: [0, .675, 0, 0, .77778], 8872: [0, .69224, 0, 0, .61111], 8873: [0, .69224, 0, 0, .72222], 8874: [0, .69224, 0, 0, .88889], 8876: [0, .68889, 0, 0, .61111], 8877: [0, .68889, 0, 0, .61111], 8878: [0, .68889, 0, 0, .72222], 8879: [0, .68889, 0, 0, .72222], 8882: [.03517, .54986, 0, 0, .77778], 8883: [.03517, .54986, 0, 0, .77778], 8884: [.13667, .63667, 0, 0, .77778], 8885: [.13667, .63667, 0, 0, .77778], 8888: [0, .54986, 0, 0, 1.11111], 8890: [.19444, .43056, 0, 0, .55556], 8891: [.19444, .69224, 0, 0, .61111], 8892: [.19444, .69224, 0, 0, .61111], 8901: [0, .54986, 0, 0, .27778], 8903: [.08167, .58167, 0, 0, .77778], 8905: [.08167, .58167, 0, 0, .77778], 8906: [.08167, .58167, 0, 0, .77778], 8907: [0, .69224, 0, 0, .77778], 8908: [0, .69224, 0, 0, .77778], 8909: [-.03598, .46402, 0, 0, .77778], 8910: [0, .54986, 0, 0, .76042], 8911: [0, .54986, 0, 0, .76042], 8912: [.03517, .54986, 0, 0, .77778], 8913: [.03517, .54986, 0, 0, .77778], 8914: [0, .54986, 0, 0, .66667], 8915: [0, .54986, 0, 0, .66667], 8916: [0, .69224, 0, 0, .66667], 8918: [.0391, .5391, 0, 0, .77778], 8919: [.0391, .5391, 0, 0, .77778], 8920: [.03517, .54986, 0, 0, 1.33334], 8921: [.03517, .54986, 0, 0, 1.33334], 8922: [.38569, .88569, 0, 0, .77778], 8923: [.38569, .88569, 0, 0, .77778], 8926: [.13667, .63667, 0, 0, .77778], 8927: [.13667, .63667, 0, 0, .77778], 8928: [.30274, .79383, 0, 0, .77778], 8929: [.30274, .79383, 0, 0, .77778], 8934: [.23222, .74111, 0, 0, .77778], 8935: [.23222, .74111, 0, 0, .77778], 8936: [.23222, .74111, 0, 0, .77778], 8937: [.23222, .74111, 0, 0, .77778], 8938: [.20576, .70576, 0, 0, .77778], 8939: [.20576, .70576, 0, 0, .77778], 8940: [.30274, .79383, 0, 0, .77778], 8941: [.30274, .79383, 0, 0, .77778], 8994: [.19444, .69224, 0, 0, .77778], 8995: [.19444, .69224, 0, 0, .77778], 9416: [.15559, .69224, 0, 0, .90222], 9484: [0, .69224, 0, 0, .5], 9488: [0, .69224, 0, 0, .5], 9492: [0, .37788, 0, 0, .5], 9496: [0, .37788, 0, 0, .5], 9585: [.19444, .68889, 0, 0, .88889], 9586: [.19444, .74111, 0, 0, .88889], 9632: [0, .675, 0, 0, .77778], 9633: [0, .675, 0, 0, .77778], 9650: [0, .54986, 0, 0, .72222], 9651: [0, .54986, 0, 0, .72222], 9654: [.03517, .54986, 0, 0, .77778], 9660: [0, .54986, 0, 0, .72222], 9661: [0, .54986, 0, 0, .72222], 9664: [.03517, .54986, 0, 0, .77778], 9674: [.11111, .69224, 0, 0, .66667], 9733: [.19444, .69224, 0, 0, .94445], 10003: [0, .69224, 0, 0, .83334], 10016: [0, .69224, 0, 0, .83334], 10731: [.11111, .69224, 0, 0, .66667], 10846: [.19444, .75583, 0, 0, .61111], 10877: [.13667, .63667, 0, 0, .77778], 10878: [.13667, .63667, 0, 0, .77778], 10885: [.25583, .75583, 0, 0, .77778], 10886: [.25583, .75583, 0, 0, .77778], 10887: [.13597, .63597, 0, 0, .77778], 10888: [.13597, .63597, 0, 0, .77778], 10889: [.26167, .75726, 0, 0, .77778], 10890: [.26167, .75726, 0, 0, .77778], 10891: [.48256, .98256, 0, 0, .77778], 10892: [.48256, .98256, 0, 0, .77778], 10901: [.13667, .63667, 0, 0, .77778], 10902: [.13667, .63667, 0, 0, .77778], 10933: [.25142, .75726, 0, 0, .77778], 10934: [.25142, .75726, 0, 0, .77778], 10935: [.26167, .75726, 0, 0, .77778], 10936: [.26167, .75726, 0, 0, .77778], 10937: [.26167, .75726, 0, 0, .77778], 10938: [.26167, .75726, 0, 0, .77778], 10949: [.25583, .75583, 0, 0, .77778], 10950: [.25583, .75583, 0, 0, .77778], 10955: [.28481, .79383, 0, 0, .77778], 10956: [.28481, .79383, 0, 0, .77778], 57350: [.08167, .58167, 0, 0, .22222], 57351: [.08167, .58167, 0, 0, .38889], 57352: [.08167, .58167, 0, 0, .77778], 57353: [0, .43056, .04028, 0, .66667], 57356: [.25142, .75726, 0, 0, .77778], 57357: [.25142, .75726, 0, 0, .77778], 57358: [.41951, .91951, 0, 0, .77778], 57359: [.30274, .79383, 0, 0, .77778], 57360: [.30274, .79383, 0, 0, .77778], 57361: [.41951, .91951, 0, 0, .77778], 57366: [.25142, .75726, 0, 0, .77778], 57367: [.25142, .75726, 0, 0, .77778], 57368: [.25142, .75726, 0, 0, .77778], 57369: [.25142, .75726, 0, 0, .77778], 57370: [.13597, .63597, 0, 0, .77778], 57371: [.13597, .63597, 0, 0, .77778] }, "Caligraphic-Regular": { 32: [0, 0, 0, 0, .25], 65: [0, .68333, 0, .19445, .79847], 66: [0, .68333, .03041, .13889, .65681], 67: [0, .68333, .05834, .13889, .52653], 68: [0, .68333, .02778, .08334, .77139], 69: [0, .68333, .08944, .11111, .52778], 70: [0, .68333, .09931, .11111, .71875], 71: [.09722, .68333, .0593, .11111, .59487], 72: [0, .68333, .00965, .11111, .84452], 73: [0, .68333, .07382, 0, .54452], 74: [.09722, .68333, .18472, .16667, .67778], 75: [0, .68333, .01445, .05556, .76195], 76: [0, .68333, 0, .13889, .68972], 77: [0, .68333, 0, .13889, 1.2009], 78: [0, .68333, .14736, .08334, .82049], 79: [0, .68333, .02778, .11111, .79611], 80: [0, .68333, .08222, .08334, .69556], 81: [.09722, .68333, 0, .11111, .81667], 82: [0, .68333, 0, .08334, .8475], 83: [0, .68333, .075, .13889, .60556], 84: [0, .68333, .25417, 0, .54464], 85: [0, .68333, .09931, .08334, .62583], 86: [0, .68333, .08222, 0, .61278], 87: [0, .68333, .08222, .08334, .98778], 88: [0, .68333, .14643, .13889, .7133], 89: [.09722, .68333, .08222, .08334, .66834], 90: [0, .68333, .07944, .13889, .72473], 160: [0, 0, 0, 0, .25] }, "Fraktur-Regular": { 32: [0, 0, 0, 0, .25], 33: [0, .69141, 0, 0, .29574], 34: [0, .69141, 0, 0, .21471], 38: [0, .69141, 0, 0, .73786], 39: [0, .69141, 0, 0, .21201], 40: [.24982, .74947, 0, 0, .38865], 41: [.24982, .74947, 0, 0, .38865], 42: [0, .62119, 0, 0, .27764], 43: [.08319, .58283, 0, 0, .75623], 44: [0, .10803, 0, 0, .27764], 45: [.08319, .58283, 0, 0, .75623], 46: [0, .10803, 0, 0, .27764], 47: [.24982, .74947, 0, 0, .50181], 48: [0, .47534, 0, 0, .50181], 49: [0, .47534, 0, 0, .50181], 50: [0, .47534, 0, 0, .50181], 51: [.18906, .47534, 0, 0, .50181], 52: [.18906, .47534, 0, 0, .50181], 53: [.18906, .47534, 0, 0, .50181], 54: [0, .69141, 0, 0, .50181], 55: [.18906, .47534, 0, 0, .50181], 56: [0, .69141, 0, 0, .50181], 57: [.18906, .47534, 0, 0, .50181], 58: [0, .47534, 0, 0, .21606], 59: [.12604, .47534, 0, 0, .21606], 61: [-.13099, .36866, 0, 0, .75623], 63: [0, .69141, 0, 0, .36245], 65: [0, .69141, 0, 0, .7176], 66: [0, .69141, 0, 0, .88397], 67: [0, .69141, 0, 0, .61254], 68: [0, .69141, 0, 0, .83158], 69: [0, .69141, 0, 0, .66278], 70: [.12604, .69141, 0, 0, .61119], 71: [0, .69141, 0, 0, .78539], 72: [.06302, .69141, 0, 0, .7203], 73: [0, .69141, 0, 0, .55448], 74: [.12604, .69141, 0, 0, .55231], 75: [0, .69141, 0, 0, .66845], 76: [0, .69141, 0, 0, .66602], 77: [0, .69141, 0, 0, 1.04953], 78: [0, .69141, 0, 0, .83212], 79: [0, .69141, 0, 0, .82699], 80: [.18906, .69141, 0, 0, .82753], 81: [.03781, .69141, 0, 0, .82699], 82: [0, .69141, 0, 0, .82807], 83: [0, .69141, 0, 0, .82861], 84: [0, .69141, 0, 0, .66899], 85: [0, .69141, 0, 0, .64576], 86: [0, .69141, 0, 0, .83131], 87: [0, .69141, 0, 0, 1.04602], 88: [0, .69141, 0, 0, .71922], 89: [.18906, .69141, 0, 0, .83293], 90: [.12604, .69141, 0, 0, .60201], 91: [.24982, .74947, 0, 0, .27764], 93: [.24982, .74947, 0, 0, .27764], 94: [0, .69141, 0, 0, .49965], 97: [0, .47534, 0, 0, .50046], 98: [0, .69141, 0, 0, .51315], 99: [0, .47534, 0, 0, .38946], 100: [0, .62119, 0, 0, .49857], 101: [0, .47534, 0, 0, .40053], 102: [.18906, .69141, 0, 0, .32626], 103: [.18906, .47534, 0, 0, .5037], 104: [.18906, .69141, 0, 0, .52126], 105: [0, .69141, 0, 0, .27899], 106: [0, .69141, 0, 0, .28088], 107: [0, .69141, 0, 0, .38946], 108: [0, .69141, 0, 0, .27953], 109: [0, .47534, 0, 0, .76676], 110: [0, .47534, 0, 0, .52666], 111: [0, .47534, 0, 0, .48885], 112: [.18906, .52396, 0, 0, .50046], 113: [.18906, .47534, 0, 0, .48912], 114: [0, .47534, 0, 0, .38919], 115: [0, .47534, 0, 0, .44266], 116: [0, .62119, 0, 0, .33301], 117: [0, .47534, 0, 0, .5172], 118: [0, .52396, 0, 0, .5118], 119: [0, .52396, 0, 0, .77351], 120: [.18906, .47534, 0, 0, .38865], 121: [.18906, .47534, 0, 0, .49884], 122: [.18906, .47534, 0, 0, .39054], 160: [0, 0, 0, 0, .25], 8216: [0, .69141, 0, 0, .21471], 8217: [0, .69141, 0, 0, .21471], 58112: [0, .62119, 0, 0, .49749], 58113: [0, .62119, 0, 0, .4983], 58114: [.18906, .69141, 0, 0, .33328], 58115: [.18906, .69141, 0, 0, .32923], 58116: [.18906, .47534, 0, 0, .50343], 58117: [0, .69141, 0, 0, .33301], 58118: [0, .62119, 0, 0, .33409], 58119: [0, .47534, 0, 0, .50073] }, "Main-Bold": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, 0, 0, .35], 34: [0, .69444, 0, 0, .60278], 35: [.19444, .69444, 0, 0, .95833], 36: [.05556, .75, 0, 0, .575], 37: [.05556, .75, 0, 0, .95833], 38: [0, .69444, 0, 0, .89444], 39: [0, .69444, 0, 0, .31944], 40: [.25, .75, 0, 0, .44722], 41: [.25, .75, 0, 0, .44722], 42: [0, .75, 0, 0, .575], 43: [.13333, .63333, 0, 0, .89444], 44: [.19444, .15556, 0, 0, .31944], 45: [0, .44444, 0, 0, .38333], 46: [0, .15556, 0, 0, .31944], 47: [.25, .75, 0, 0, .575], 48: [0, .64444, 0, 0, .575], 49: [0, .64444, 0, 0, .575], 50: [0, .64444, 0, 0, .575], 51: [0, .64444, 0, 0, .575], 52: [0, .64444, 0, 0, .575], 53: [0, .64444, 0, 0, .575], 54: [0, .64444, 0, 0, .575], 55: [0, .64444, 0, 0, .575], 56: [0, .64444, 0, 0, .575], 57: [0, .64444, 0, 0, .575], 58: [0, .44444, 0, 0, .31944], 59: [.19444, .44444, 0, 0, .31944], 60: [.08556, .58556, 0, 0, .89444], 61: [-.10889, .39111, 0, 0, .89444], 62: [.08556, .58556, 0, 0, .89444], 63: [0, .69444, 0, 0, .54305], 64: [0, .69444, 0, 0, .89444], 65: [0, .68611, 0, 0, .86944], 66: [0, .68611, 0, 0, .81805], 67: [0, .68611, 0, 0, .83055], 68: [0, .68611, 0, 0, .88194], 69: [0, .68611, 0, 0, .75555], 70: [0, .68611, 0, 0, .72361], 71: [0, .68611, 0, 0, .90416], 72: [0, .68611, 0, 0, .9], 73: [0, .68611, 0, 0, .43611], 74: [0, .68611, 0, 0, .59444], 75: [0, .68611, 0, 0, .90138], 76: [0, .68611, 0, 0, .69166], 77: [0, .68611, 0, 0, 1.09166], 78: [0, .68611, 0, 0, .9], 79: [0, .68611, 0, 0, .86388], 80: [0, .68611, 0, 0, .78611], 81: [.19444, .68611, 0, 0, .86388], 82: [0, .68611, 0, 0, .8625], 83: [0, .68611, 0, 0, .63889], 84: [0, .68611, 0, 0, .8], 85: [0, .68611, 0, 0, .88472], 86: [0, .68611, .01597, 0, .86944], 87: [0, .68611, .01597, 0, 1.18888], 88: [0, .68611, 0, 0, .86944], 89: [0, .68611, .02875, 0, .86944], 90: [0, .68611, 0, 0, .70277], 91: [.25, .75, 0, 0, .31944], 92: [.25, .75, 0, 0, .575], 93: [.25, .75, 0, 0, .31944], 94: [0, .69444, 0, 0, .575], 95: [.31, .13444, .03194, 0, .575], 97: [0, .44444, 0, 0, .55902], 98: [0, .69444, 0, 0, .63889], 99: [0, .44444, 0, 0, .51111], 100: [0, .69444, 0, 0, .63889], 101: [0, .44444, 0, 0, .52708], 102: [0, .69444, .10903, 0, .35139], 103: [.19444, .44444, .01597, 0, .575], 104: [0, .69444, 0, 0, .63889], 105: [0, .69444, 0, 0, .31944], 106: [.19444, .69444, 0, 0, .35139], 107: [0, .69444, 0, 0, .60694], 108: [0, .69444, 0, 0, .31944], 109: [0, .44444, 0, 0, .95833], 110: [0, .44444, 0, 0, .63889], 111: [0, .44444, 0, 0, .575], 112: [.19444, .44444, 0, 0, .63889], 113: [.19444, .44444, 0, 0, .60694], 114: [0, .44444, 0, 0, .47361], 115: [0, .44444, 0, 0, .45361], 116: [0, .63492, 0, 0, .44722], 117: [0, .44444, 0, 0, .63889], 118: [0, .44444, .01597, 0, .60694], 119: [0, .44444, .01597, 0, .83055], 120: [0, .44444, 0, 0, .60694], 121: [.19444, .44444, .01597, 0, .60694], 122: [0, .44444, 0, 0, .51111], 123: [.25, .75, 0, 0, .575], 124: [.25, .75, 0, 0, .31944], 125: [.25, .75, 0, 0, .575], 126: [.35, .34444, 0, 0, .575], 160: [0, 0, 0, 0, .25], 163: [0, .69444, 0, 0, .86853], 168: [0, .69444, 0, 0, .575], 172: [0, .44444, 0, 0, .76666], 176: [0, .69444, 0, 0, .86944], 177: [.13333, .63333, 0, 0, .89444], 184: [.17014, 0, 0, 0, .51111], 198: [0, .68611, 0, 0, 1.04166], 215: [.13333, .63333, 0, 0, .89444], 216: [.04861, .73472, 0, 0, .89444], 223: [0, .69444, 0, 0, .59722], 230: [0, .44444, 0, 0, .83055], 247: [.13333, .63333, 0, 0, .89444], 248: [.09722, .54167, 0, 0, .575], 305: [0, .44444, 0, 0, .31944], 338: [0, .68611, 0, 0, 1.16944], 339: [0, .44444, 0, 0, .89444], 567: [.19444, .44444, 0, 0, .35139], 710: [0, .69444, 0, 0, .575], 711: [0, .63194, 0, 0, .575], 713: [0, .59611, 0, 0, .575], 714: [0, .69444, 0, 0, .575], 715: [0, .69444, 0, 0, .575], 728: [0, .69444, 0, 0, .575], 729: [0, .69444, 0, 0, .31944], 730: [0, .69444, 0, 0, .86944], 732: [0, .69444, 0, 0, .575], 733: [0, .69444, 0, 0, .575], 915: [0, .68611, 0, 0, .69166], 916: [0, .68611, 0, 0, .95833], 920: [0, .68611, 0, 0, .89444], 923: [0, .68611, 0, 0, .80555], 926: [0, .68611, 0, 0, .76666], 928: [0, .68611, 0, 0, .9], 931: [0, .68611, 0, 0, .83055], 933: [0, .68611, 0, 0, .89444], 934: [0, .68611, 0, 0, .83055], 936: [0, .68611, 0, 0, .89444], 937: [0, .68611, 0, 0, .83055], 8211: [0, .44444, .03194, 0, .575], 8212: [0, .44444, .03194, 0, 1.14999], 8216: [0, .69444, 0, 0, .31944], 8217: [0, .69444, 0, 0, .31944], 8220: [0, .69444, 0, 0, .60278], 8221: [0, .69444, 0, 0, .60278], 8224: [.19444, .69444, 0, 0, .51111], 8225: [.19444, .69444, 0, 0, .51111], 8242: [0, .55556, 0, 0, .34444], 8407: [0, .72444, .15486, 0, .575], 8463: [0, .69444, 0, 0, .66759], 8465: [0, .69444, 0, 0, .83055], 8467: [0, .69444, 0, 0, .47361], 8472: [.19444, .44444, 0, 0, .74027], 8476: [0, .69444, 0, 0, .83055], 8501: [0, .69444, 0, 0, .70277], 8592: [-.10889, .39111, 0, 0, 1.14999], 8593: [.19444, .69444, 0, 0, .575], 8594: [-.10889, .39111, 0, 0, 1.14999], 8595: [.19444, .69444, 0, 0, .575], 8596: [-.10889, .39111, 0, 0, 1.14999], 8597: [.25, .75, 0, 0, .575], 8598: [.19444, .69444, 0, 0, 1.14999], 8599: [.19444, .69444, 0, 0, 1.14999], 8600: [.19444, .69444, 0, 0, 1.14999], 8601: [.19444, .69444, 0, 0, 1.14999], 8636: [-.10889, .39111, 0, 0, 1.14999], 8637: [-.10889, .39111, 0, 0, 1.14999], 8640: [-.10889, .39111, 0, 0, 1.14999], 8641: [-.10889, .39111, 0, 0, 1.14999], 8656: [-.10889, .39111, 0, 0, 1.14999], 8657: [.19444, .69444, 0, 0, .70277], 8658: [-.10889, .39111, 0, 0, 1.14999], 8659: [.19444, .69444, 0, 0, .70277], 8660: [-.10889, .39111, 0, 0, 1.14999], 8661: [.25, .75, 0, 0, .70277], 8704: [0, .69444, 0, 0, .63889], 8706: [0, .69444, .06389, 0, .62847], 8707: [0, .69444, 0, 0, .63889], 8709: [.05556, .75, 0, 0, .575], 8711: [0, .68611, 0, 0, .95833], 8712: [.08556, .58556, 0, 0, .76666], 8715: [.08556, .58556, 0, 0, .76666], 8722: [.13333, .63333, 0, 0, .89444], 8723: [.13333, .63333, 0, 0, .89444], 8725: [.25, .75, 0, 0, .575], 8726: [.25, .75, 0, 0, .575], 8727: [-.02778, .47222, 0, 0, .575], 8728: [-.02639, .47361, 0, 0, .575], 8729: [-.02639, .47361, 0, 0, .575], 8730: [.18, .82, 0, 0, .95833], 8733: [0, .44444, 0, 0, .89444], 8734: [0, .44444, 0, 0, 1.14999], 8736: [0, .69224, 0, 0, .72222], 8739: [.25, .75, 0, 0, .31944], 8741: [.25, .75, 0, 0, .575], 8743: [0, .55556, 0, 0, .76666], 8744: [0, .55556, 0, 0, .76666], 8745: [0, .55556, 0, 0, .76666], 8746: [0, .55556, 0, 0, .76666], 8747: [.19444, .69444, .12778, 0, .56875], 8764: [-.10889, .39111, 0, 0, .89444], 8768: [.19444, .69444, 0, 0, .31944], 8771: [.00222, .50222, 0, 0, .89444], 8773: [.027, .638, 0, 0, .894], 8776: [.02444, .52444, 0, 0, .89444], 8781: [.00222, .50222, 0, 0, .89444], 8801: [.00222, .50222, 0, 0, .89444], 8804: [.19667, .69667, 0, 0, .89444], 8805: [.19667, .69667, 0, 0, .89444], 8810: [.08556, .58556, 0, 0, 1.14999], 8811: [.08556, .58556, 0, 0, 1.14999], 8826: [.08556, .58556, 0, 0, .89444], 8827: [.08556, .58556, 0, 0, .89444], 8834: [.08556, .58556, 0, 0, .89444], 8835: [.08556, .58556, 0, 0, .89444], 8838: [.19667, .69667, 0, 0, .89444], 8839: [.19667, .69667, 0, 0, .89444], 8846: [0, .55556, 0, 0, .76666], 8849: [.19667, .69667, 0, 0, .89444], 8850: [.19667, .69667, 0, 0, .89444], 8851: [0, .55556, 0, 0, .76666], 8852: [0, .55556, 0, 0, .76666], 8853: [.13333, .63333, 0, 0, .89444], 8854: [.13333, .63333, 0, 0, .89444], 8855: [.13333, .63333, 0, 0, .89444], 8856: [.13333, .63333, 0, 0, .89444], 8857: [.13333, .63333, 0, 0, .89444], 8866: [0, .69444, 0, 0, .70277], 8867: [0, .69444, 0, 0, .70277], 8868: [0, .69444, 0, 0, .89444], 8869: [0, .69444, 0, 0, .89444], 8900: [-.02639, .47361, 0, 0, .575], 8901: [-.02639, .47361, 0, 0, .31944], 8902: [-.02778, .47222, 0, 0, .575], 8968: [.25, .75, 0, 0, .51111], 8969: [.25, .75, 0, 0, .51111], 8970: [.25, .75, 0, 0, .51111], 8971: [.25, .75, 0, 0, .51111], 8994: [-.13889, .36111, 0, 0, 1.14999], 8995: [-.13889, .36111, 0, 0, 1.14999], 9651: [.19444, .69444, 0, 0, 1.02222], 9657: [-.02778, .47222, 0, 0, .575], 9661: [.19444, .69444, 0, 0, 1.02222], 9667: [-.02778, .47222, 0, 0, .575], 9711: [.19444, .69444, 0, 0, 1.14999], 9824: [.12963, .69444, 0, 0, .89444], 9825: [.12963, .69444, 0, 0, .89444], 9826: [.12963, .69444, 0, 0, .89444], 9827: [.12963, .69444, 0, 0, .89444], 9837: [0, .75, 0, 0, .44722], 9838: [.19444, .69444, 0, 0, .44722], 9839: [.19444, .69444, 0, 0, .44722], 10216: [.25, .75, 0, 0, .44722], 10217: [.25, .75, 0, 0, .44722], 10815: [0, .68611, 0, 0, .9], 10927: [.19667, .69667, 0, 0, .89444], 10928: [.19667, .69667, 0, 0, .89444], 57376: [.19444, .69444, 0, 0, 0] }, "Main-BoldItalic": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, .11417, 0, .38611], 34: [0, .69444, .07939, 0, .62055], 35: [.19444, .69444, .06833, 0, .94444], 37: [.05556, .75, .12861, 0, .94444], 38: [0, .69444, .08528, 0, .88555], 39: [0, .69444, .12945, 0, .35555], 40: [.25, .75, .15806, 0, .47333], 41: [.25, .75, .03306, 0, .47333], 42: [0, .75, .14333, 0, .59111], 43: [.10333, .60333, .03306, 0, .88555], 44: [.19444, .14722, 0, 0, .35555], 45: [0, .44444, .02611, 0, .41444], 46: [0, .14722, 0, 0, .35555], 47: [.25, .75, .15806, 0, .59111], 48: [0, .64444, .13167, 0, .59111], 49: [0, .64444, .13167, 0, .59111], 50: [0, .64444, .13167, 0, .59111], 51: [0, .64444, .13167, 0, .59111], 52: [.19444, .64444, .13167, 0, .59111], 53: [0, .64444, .13167, 0, .59111], 54: [0, .64444, .13167, 0, .59111], 55: [.19444, .64444, .13167, 0, .59111], 56: [0, .64444, .13167, 0, .59111], 57: [0, .64444, .13167, 0, .59111], 58: [0, .44444, .06695, 0, .35555], 59: [.19444, .44444, .06695, 0, .35555], 61: [-.10889, .39111, .06833, 0, .88555], 63: [0, .69444, .11472, 0, .59111], 64: [0, .69444, .09208, 0, .88555], 65: [0, .68611, 0, 0, .86555], 66: [0, .68611, .0992, 0, .81666], 67: [0, .68611, .14208, 0, .82666], 68: [0, .68611, .09062, 0, .87555], 69: [0, .68611, .11431, 0, .75666], 70: [0, .68611, .12903, 0, .72722], 71: [0, .68611, .07347, 0, .89527], 72: [0, .68611, .17208, 0, .8961], 73: [0, .68611, .15681, 0, .47166], 74: [0, .68611, .145, 0, .61055], 75: [0, .68611, .14208, 0, .89499], 76: [0, .68611, 0, 0, .69777], 77: [0, .68611, .17208, 0, 1.07277], 78: [0, .68611, .17208, 0, .8961], 79: [0, .68611, .09062, 0, .85499], 80: [0, .68611, .0992, 0, .78721], 81: [.19444, .68611, .09062, 0, .85499], 82: [0, .68611, .02559, 0, .85944], 83: [0, .68611, .11264, 0, .64999], 84: [0, .68611, .12903, 0, .7961], 85: [0, .68611, .17208, 0, .88083], 86: [0, .68611, .18625, 0, .86555], 87: [0, .68611, .18625, 0, 1.15999], 88: [0, .68611, .15681, 0, .86555], 89: [0, .68611, .19803, 0, .86555], 90: [0, .68611, .14208, 0, .70888], 91: [.25, .75, .1875, 0, .35611], 93: [.25, .75, .09972, 0, .35611], 94: [0, .69444, .06709, 0, .59111], 95: [.31, .13444, .09811, 0, .59111], 97: [0, .44444, .09426, 0, .59111], 98: [0, .69444, .07861, 0, .53222], 99: [0, .44444, .05222, 0, .53222], 100: [0, .69444, .10861, 0, .59111], 101: [0, .44444, .085, 0, .53222], 102: [.19444, .69444, .21778, 0, .4], 103: [.19444, .44444, .105, 0, .53222], 104: [0, .69444, .09426, 0, .59111], 105: [0, .69326, .11387, 0, .35555], 106: [.19444, .69326, .1672, 0, .35555], 107: [0, .69444, .11111, 0, .53222], 108: [0, .69444, .10861, 0, .29666], 109: [0, .44444, .09426, 0, .94444], 110: [0, .44444, .09426, 0, .64999], 111: [0, .44444, .07861, 0, .59111], 112: [.19444, .44444, .07861, 0, .59111], 113: [.19444, .44444, .105, 0, .53222], 114: [0, .44444, .11111, 0, .50167], 115: [0, .44444, .08167, 0, .48694], 116: [0, .63492, .09639, 0, .385], 117: [0, .44444, .09426, 0, .62055], 118: [0, .44444, .11111, 0, .53222], 119: [0, .44444, .11111, 0, .76777], 120: [0, .44444, .12583, 0, .56055], 121: [.19444, .44444, .105, 0, .56166], 122: [0, .44444, .13889, 0, .49055], 126: [.35, .34444, .11472, 0, .59111], 160: [0, 0, 0, 0, .25], 168: [0, .69444, .11473, 0, .59111], 176: [0, .69444, 0, 0, .94888], 184: [.17014, 0, 0, 0, .53222], 198: [0, .68611, .11431, 0, 1.02277], 216: [.04861, .73472, .09062, 0, .88555], 223: [.19444, .69444, .09736, 0, .665], 230: [0, .44444, .085, 0, .82666], 248: [.09722, .54167, .09458, 0, .59111], 305: [0, .44444, .09426, 0, .35555], 338: [0, .68611, .11431, 0, 1.14054], 339: [0, .44444, .085, 0, .82666], 567: [.19444, .44444, .04611, 0, .385], 710: [0, .69444, .06709, 0, .59111], 711: [0, .63194, .08271, 0, .59111], 713: [0, .59444, .10444, 0, .59111], 714: [0, .69444, .08528, 0, .59111], 715: [0, .69444, 0, 0, .59111], 728: [0, .69444, .10333, 0, .59111], 729: [0, .69444, .12945, 0, .35555], 730: [0, .69444, 0, 0, .94888], 732: [0, .69444, .11472, 0, .59111], 733: [0, .69444, .11472, 0, .59111], 915: [0, .68611, .12903, 0, .69777], 916: [0, .68611, 0, 0, .94444], 920: [0, .68611, .09062, 0, .88555], 923: [0, .68611, 0, 0, .80666], 926: [0, .68611, .15092, 0, .76777], 928: [0, .68611, .17208, 0, .8961], 931: [0, .68611, .11431, 0, .82666], 933: [0, .68611, .10778, 0, .88555], 934: [0, .68611, .05632, 0, .82666], 936: [0, .68611, .10778, 0, .88555], 937: [0, .68611, .0992, 0, .82666], 8211: [0, .44444, .09811, 0, .59111], 8212: [0, .44444, .09811, 0, 1.18221], 8216: [0, .69444, .12945, 0, .35555], 8217: [0, .69444, .12945, 0, .35555], 8220: [0, .69444, .16772, 0, .62055], 8221: [0, .69444, .07939, 0, .62055] }, "Main-Italic": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, .12417, 0, .30667], 34: [0, .69444, .06961, 0, .51444], 35: [.19444, .69444, .06616, 0, .81777], 37: [.05556, .75, .13639, 0, .81777], 38: [0, .69444, .09694, 0, .76666], 39: [0, .69444, .12417, 0, .30667], 40: [.25, .75, .16194, 0, .40889], 41: [.25, .75, .03694, 0, .40889], 42: [0, .75, .14917, 0, .51111], 43: [.05667, .56167, .03694, 0, .76666], 44: [.19444, .10556, 0, 0, .30667], 45: [0, .43056, .02826, 0, .35778], 46: [0, .10556, 0, 0, .30667], 47: [.25, .75, .16194, 0, .51111], 48: [0, .64444, .13556, 0, .51111], 49: [0, .64444, .13556, 0, .51111], 50: [0, .64444, .13556, 0, .51111], 51: [0, .64444, .13556, 0, .51111], 52: [.19444, .64444, .13556, 0, .51111], 53: [0, .64444, .13556, 0, .51111], 54: [0, .64444, .13556, 0, .51111], 55: [.19444, .64444, .13556, 0, .51111], 56: [0, .64444, .13556, 0, .51111], 57: [0, .64444, .13556, 0, .51111], 58: [0, .43056, .0582, 0, .30667], 59: [.19444, .43056, .0582, 0, .30667], 61: [-.13313, .36687, .06616, 0, .76666], 63: [0, .69444, .1225, 0, .51111], 64: [0, .69444, .09597, 0, .76666], 65: [0, .68333, 0, 0, .74333], 66: [0, .68333, .10257, 0, .70389], 67: [0, .68333, .14528, 0, .71555], 68: [0, .68333, .09403, 0, .755], 69: [0, .68333, .12028, 0, .67833], 70: [0, .68333, .13305, 0, .65277], 71: [0, .68333, .08722, 0, .77361], 72: [0, .68333, .16389, 0, .74333], 73: [0, .68333, .15806, 0, .38555], 74: [0, .68333, .14028, 0, .525], 75: [0, .68333, .14528, 0, .76888], 76: [0, .68333, 0, 0, .62722], 77: [0, .68333, .16389, 0, .89666], 78: [0, .68333, .16389, 0, .74333], 79: [0, .68333, .09403, 0, .76666], 80: [0, .68333, .10257, 0, .67833], 81: [.19444, .68333, .09403, 0, .76666], 82: [0, .68333, .03868, 0, .72944], 83: [0, .68333, .11972, 0, .56222], 84: [0, .68333, .13305, 0, .71555], 85: [0, .68333, .16389, 0, .74333], 86: [0, .68333, .18361, 0, .74333], 87: [0, .68333, .18361, 0, .99888], 88: [0, .68333, .15806, 0, .74333], 89: [0, .68333, .19383, 0, .74333], 90: [0, .68333, .14528, 0, .61333], 91: [.25, .75, .1875, 0, .30667], 93: [.25, .75, .10528, 0, .30667], 94: [0, .69444, .06646, 0, .51111], 95: [.31, .12056, .09208, 0, .51111], 97: [0, .43056, .07671, 0, .51111], 98: [0, .69444, .06312, 0, .46], 99: [0, .43056, .05653, 0, .46], 100: [0, .69444, .10333, 0, .51111], 101: [0, .43056, .07514, 0, .46], 102: [.19444, .69444, .21194, 0, .30667], 103: [.19444, .43056, .08847, 0, .46], 104: [0, .69444, .07671, 0, .51111], 105: [0, .65536, .1019, 0, .30667], 106: [.19444, .65536, .14467, 0, .30667], 107: [0, .69444, .10764, 0, .46], 108: [0, .69444, .10333, 0, .25555], 109: [0, .43056, .07671, 0, .81777], 110: [0, .43056, .07671, 0, .56222], 111: [0, .43056, .06312, 0, .51111], 112: [.19444, .43056, .06312, 0, .51111], 113: [.19444, .43056, .08847, 0, .46], 114: [0, .43056, .10764, 0, .42166], 115: [0, .43056, .08208, 0, .40889], 116: [0, .61508, .09486, 0, .33222], 117: [0, .43056, .07671, 0, .53666], 118: [0, .43056, .10764, 0, .46], 119: [0, .43056, .10764, 0, .66444], 120: [0, .43056, .12042, 0, .46389], 121: [.19444, .43056, .08847, 0, .48555], 122: [0, .43056, .12292, 0, .40889], 126: [.35, .31786, .11585, 0, .51111], 160: [0, 0, 0, 0, .25], 168: [0, .66786, .10474, 0, .51111], 176: [0, .69444, 0, 0, .83129], 184: [.17014, 0, 0, 0, .46], 198: [0, .68333, .12028, 0, .88277], 216: [.04861, .73194, .09403, 0, .76666], 223: [.19444, .69444, .10514, 0, .53666], 230: [0, .43056, .07514, 0, .71555], 248: [.09722, .52778, .09194, 0, .51111], 338: [0, .68333, .12028, 0, .98499], 339: [0, .43056, .07514, 0, .71555], 710: [0, .69444, .06646, 0, .51111], 711: [0, .62847, .08295, 0, .51111], 713: [0, .56167, .10333, 0, .51111], 714: [0, .69444, .09694, 0, .51111], 715: [0, .69444, 0, 0, .51111], 728: [0, .69444, .10806, 0, .51111], 729: [0, .66786, .11752, 0, .30667], 730: [0, .69444, 0, 0, .83129], 732: [0, .66786, .11585, 0, .51111], 733: [0, .69444, .1225, 0, .51111], 915: [0, .68333, .13305, 0, .62722], 916: [0, .68333, 0, 0, .81777], 920: [0, .68333, .09403, 0, .76666], 923: [0, .68333, 0, 0, .69222], 926: [0, .68333, .15294, 0, .66444], 928: [0, .68333, .16389, 0, .74333], 931: [0, .68333, .12028, 0, .71555], 933: [0, .68333, .11111, 0, .76666], 934: [0, .68333, .05986, 0, .71555], 936: [0, .68333, .11111, 0, .76666], 937: [0, .68333, .10257, 0, .71555], 8211: [0, .43056, .09208, 0, .51111], 8212: [0, .43056, .09208, 0, 1.02222], 8216: [0, .69444, .12417, 0, .30667], 8217: [0, .69444, .12417, 0, .30667], 8220: [0, .69444, .1685, 0, .51444], 8221: [0, .69444, .06961, 0, .51444], 8463: [0, .68889, 0, 0, .54028] }, "Main-Regular": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, 0, 0, .27778], 34: [0, .69444, 0, 0, .5], 35: [.19444, .69444, 0, 0, .83334], 36: [.05556, .75, 0, 0, .5], 37: [.05556, .75, 0, 0, .83334], 38: [0, .69444, 0, 0, .77778], 39: [0, .69444, 0, 0, .27778], 40: [.25, .75, 0, 0, .38889], 41: [.25, .75, 0, 0, .38889], 42: [0, .75, 0, 0, .5], 43: [.08333, .58333, 0, 0, .77778], 44: [.19444, .10556, 0, 0, .27778], 45: [0, .43056, 0, 0, .33333], 46: [0, .10556, 0, 0, .27778], 47: [.25, .75, 0, 0, .5], 48: [0, .64444, 0, 0, .5], 49: [0, .64444, 0, 0, .5], 50: [0, .64444, 0, 0, .5], 51: [0, .64444, 0, 0, .5], 52: [0, .64444, 0, 0, .5], 53: [0, .64444, 0, 0, .5], 54: [0, .64444, 0, 0, .5], 55: [0, .64444, 0, 0, .5], 56: [0, .64444, 0, 0, .5], 57: [0, .64444, 0, 0, .5], 58: [0, .43056, 0, 0, .27778], 59: [.19444, .43056, 0, 0, .27778], 60: [.0391, .5391, 0, 0, .77778], 61: [-.13313, .36687, 0, 0, .77778], 62: [.0391, .5391, 0, 0, .77778], 63: [0, .69444, 0, 0, .47222], 64: [0, .69444, 0, 0, .77778], 65: [0, .68333, 0, 0, .75], 66: [0, .68333, 0, 0, .70834], 67: [0, .68333, 0, 0, .72222], 68: [0, .68333, 0, 0, .76389], 69: [0, .68333, 0, 0, .68056], 70: [0, .68333, 0, 0, .65278], 71: [0, .68333, 0, 0, .78472], 72: [0, .68333, 0, 0, .75], 73: [0, .68333, 0, 0, .36111], 74: [0, .68333, 0, 0, .51389], 75: [0, .68333, 0, 0, .77778], 76: [0, .68333, 0, 0, .625], 77: [0, .68333, 0, 0, .91667], 78: [0, .68333, 0, 0, .75], 79: [0, .68333, 0, 0, .77778], 80: [0, .68333, 0, 0, .68056], 81: [.19444, .68333, 0, 0, .77778], 82: [0, .68333, 0, 0, .73611], 83: [0, .68333, 0, 0, .55556], 84: [0, .68333, 0, 0, .72222], 85: [0, .68333, 0, 0, .75], 86: [0, .68333, .01389, 0, .75], 87: [0, .68333, .01389, 0, 1.02778], 88: [0, .68333, 0, 0, .75], 89: [0, .68333, .025, 0, .75], 90: [0, .68333, 0, 0, .61111], 91: [.25, .75, 0, 0, .27778], 92: [.25, .75, 0, 0, .5], 93: [.25, .75, 0, 0, .27778], 94: [0, .69444, 0, 0, .5], 95: [.31, .12056, .02778, 0, .5], 97: [0, .43056, 0, 0, .5], 98: [0, .69444, 0, 0, .55556], 99: [0, .43056, 0, 0, .44445], 100: [0, .69444, 0, 0, .55556], 101: [0, .43056, 0, 0, .44445], 102: [0, .69444, .07778, 0, .30556], 103: [.19444, .43056, .01389, 0, .5], 104: [0, .69444, 0, 0, .55556], 105: [0, .66786, 0, 0, .27778], 106: [.19444, .66786, 0, 0, .30556], 107: [0, .69444, 0, 0, .52778], 108: [0, .69444, 0, 0, .27778], 109: [0, .43056, 0, 0, .83334], 110: [0, .43056, 0, 0, .55556], 111: [0, .43056, 0, 0, .5], 112: [.19444, .43056, 0, 0, .55556], 113: [.19444, .43056, 0, 0, .52778], 114: [0, .43056, 0, 0, .39167], 115: [0, .43056, 0, 0, .39445], 116: [0, .61508, 0, 0, .38889], 117: [0, .43056, 0, 0, .55556], 118: [0, .43056, .01389, 0, .52778], 119: [0, .43056, .01389, 0, .72222], 120: [0, .43056, 0, 0, .52778], 121: [.19444, .43056, .01389, 0, .52778], 122: [0, .43056, 0, 0, .44445], 123: [.25, .75, 0, 0, .5], 124: [.25, .75, 0, 0, .27778], 125: [.25, .75, 0, 0, .5], 126: [.35, .31786, 0, 0, .5], 160: [0, 0, 0, 0, .25], 163: [0, .69444, 0, 0, .76909], 167: [.19444, .69444, 0, 0, .44445], 168: [0, .66786, 0, 0, .5], 172: [0, .43056, 0, 0, .66667], 176: [0, .69444, 0, 0, .75], 177: [.08333, .58333, 0, 0, .77778], 182: [.19444, .69444, 0, 0, .61111], 184: [.17014, 0, 0, 0, .44445], 198: [0, .68333, 0, 0, .90278], 215: [.08333, .58333, 0, 0, .77778], 216: [.04861, .73194, 0, 0, .77778], 223: [0, .69444, 0, 0, .5], 230: [0, .43056, 0, 0, .72222], 247: [.08333, .58333, 0, 0, .77778], 248: [.09722, .52778, 0, 0, .5], 305: [0, .43056, 0, 0, .27778], 338: [0, .68333, 0, 0, 1.01389], 339: [0, .43056, 0, 0, .77778], 567: [.19444, .43056, 0, 0, .30556], 710: [0, .69444, 0, 0, .5], 711: [0, .62847, 0, 0, .5], 713: [0, .56778, 0, 0, .5], 714: [0, .69444, 0, 0, .5], 715: [0, .69444, 0, 0, .5], 728: [0, .69444, 0, 0, .5], 729: [0, .66786, 0, 0, .27778], 730: [0, .69444, 0, 0, .75], 732: [0, .66786, 0, 0, .5], 733: [0, .69444, 0, 0, .5], 915: [0, .68333, 0, 0, .625], 916: [0, .68333, 0, 0, .83334], 920: [0, .68333, 0, 0, .77778], 923: [0, .68333, 0, 0, .69445], 926: [0, .68333, 0, 0, .66667], 928: [0, .68333, 0, 0, .75], 931: [0, .68333, 0, 0, .72222], 933: [0, .68333, 0, 0, .77778], 934: [0, .68333, 0, 0, .72222], 936: [0, .68333, 0, 0, .77778], 937: [0, .68333, 0, 0, .72222], 8211: [0, .43056, .02778, 0, .5], 8212: [0, .43056, .02778, 0, 1], 8216: [0, .69444, 0, 0, .27778], 8217: [0, .69444, 0, 0, .27778], 8220: [0, .69444, 0, 0, .5], 8221: [0, .69444, 0, 0, .5], 8224: [.19444, .69444, 0, 0, .44445], 8225: [.19444, .69444, 0, 0, .44445], 8230: [0, .123, 0, 0, 1.172], 8242: [0, .55556, 0, 0, .275], 8407: [0, .71444, .15382, 0, .5], 8463: [0, .68889, 0, 0, .54028], 8465: [0, .69444, 0, 0, .72222], 8467: [0, .69444, 0, .11111, .41667], 8472: [.19444, .43056, 0, .11111, .63646], 8476: [0, .69444, 0, 0, .72222], 8501: [0, .69444, 0, 0, .61111], 8592: [-.13313, .36687, 0, 0, 1], 8593: [.19444, .69444, 0, 0, .5], 8594: [-.13313, .36687, 0, 0, 1], 8595: [.19444, .69444, 0, 0, .5], 8596: [-.13313, .36687, 0, 0, 1], 8597: [.25, .75, 0, 0, .5], 8598: [.19444, .69444, 0, 0, 1], 8599: [.19444, .69444, 0, 0, 1], 8600: [.19444, .69444, 0, 0, 1], 8601: [.19444, .69444, 0, 0, 1], 8614: [.011, .511, 0, 0, 1], 8617: [.011, .511, 0, 0, 1.126], 8618: [.011, .511, 0, 0, 1.126], 8636: [-.13313, .36687, 0, 0, 1], 8637: [-.13313, .36687, 0, 0, 1], 8640: [-.13313, .36687, 0, 0, 1], 8641: [-.13313, .36687, 0, 0, 1], 8652: [.011, .671, 0, 0, 1], 8656: [-.13313, .36687, 0, 0, 1], 8657: [.19444, .69444, 0, 0, .61111], 8658: [-.13313, .36687, 0, 0, 1], 8659: [.19444, .69444, 0, 0, .61111], 8660: [-.13313, .36687, 0, 0, 1], 8661: [.25, .75, 0, 0, .61111], 8704: [0, .69444, 0, 0, .55556], 8706: [0, .69444, .05556, .08334, .5309], 8707: [0, .69444, 0, 0, .55556], 8709: [.05556, .75, 0, 0, .5], 8711: [0, .68333, 0, 0, .83334], 8712: [.0391, .5391, 0, 0, .66667], 8715: [.0391, .5391, 0, 0, .66667], 8722: [.08333, .58333, 0, 0, .77778], 8723: [.08333, .58333, 0, 0, .77778], 8725: [.25, .75, 0, 0, .5], 8726: [.25, .75, 0, 0, .5], 8727: [-.03472, .46528, 0, 0, .5], 8728: [-.05555, .44445, 0, 0, .5], 8729: [-.05555, .44445, 0, 0, .5], 8730: [.2, .8, 0, 0, .83334], 8733: [0, .43056, 0, 0, .77778], 8734: [0, .43056, 0, 0, 1], 8736: [0, .69224, 0, 0, .72222], 8739: [.25, .75, 0, 0, .27778], 8741: [.25, .75, 0, 0, .5], 8743: [0, .55556, 0, 0, .66667], 8744: [0, .55556, 0, 0, .66667], 8745: [0, .55556, 0, 0, .66667], 8746: [0, .55556, 0, 0, .66667], 8747: [.19444, .69444, .11111, 0, .41667], 8764: [-.13313, .36687, 0, 0, .77778], 8768: [.19444, .69444, 0, 0, .27778], 8771: [-.03625, .46375, 0, 0, .77778], 8773: [-.022, .589, 0, 0, .778], 8776: [-.01688, .48312, 0, 0, .77778], 8781: [-.03625, .46375, 0, 0, .77778], 8784: [-.133, .673, 0, 0, .778], 8801: [-.03625, .46375, 0, 0, .77778], 8804: [.13597, .63597, 0, 0, .77778], 8805: [.13597, .63597, 0, 0, .77778], 8810: [.0391, .5391, 0, 0, 1], 8811: [.0391, .5391, 0, 0, 1], 8826: [.0391, .5391, 0, 0, .77778], 8827: [.0391, .5391, 0, 0, .77778], 8834: [.0391, .5391, 0, 0, .77778], 8835: [.0391, .5391, 0, 0, .77778], 8838: [.13597, .63597, 0, 0, .77778], 8839: [.13597, .63597, 0, 0, .77778], 8846: [0, .55556, 0, 0, .66667], 8849: [.13597, .63597, 0, 0, .77778], 8850: [.13597, .63597, 0, 0, .77778], 8851: [0, .55556, 0, 0, .66667], 8852: [0, .55556, 0, 0, .66667], 8853: [.08333, .58333, 0, 0, .77778], 8854: [.08333, .58333, 0, 0, .77778], 8855: [.08333, .58333, 0, 0, .77778], 8856: [.08333, .58333, 0, 0, .77778], 8857: [.08333, .58333, 0, 0, .77778], 8866: [0, .69444, 0, 0, .61111], 8867: [0, .69444, 0, 0, .61111], 8868: [0, .69444, 0, 0, .77778], 8869: [0, .69444, 0, 0, .77778], 8872: [.249, .75, 0, 0, .867], 8900: [-.05555, .44445, 0, 0, .5], 8901: [-.05555, .44445, 0, 0, .27778], 8902: [-.03472, .46528, 0, 0, .5], 8904: [.005, .505, 0, 0, .9], 8942: [.03, .903, 0, 0, .278], 8943: [-.19, .313, 0, 0, 1.172], 8945: [-.1, .823, 0, 0, 1.282], 8968: [.25, .75, 0, 0, .44445], 8969: [.25, .75, 0, 0, .44445], 8970: [.25, .75, 0, 0, .44445], 8971: [.25, .75, 0, 0, .44445], 8994: [-.14236, .35764, 0, 0, 1], 8995: [-.14236, .35764, 0, 0, 1], 9136: [.244, .744, 0, 0, .412], 9137: [.244, .745, 0, 0, .412], 9651: [.19444, .69444, 0, 0, .88889], 9657: [-.03472, .46528, 0, 0, .5], 9661: [.19444, .69444, 0, 0, .88889], 9667: [-.03472, .46528, 0, 0, .5], 9711: [.19444, .69444, 0, 0, 1], 9824: [.12963, .69444, 0, 0, .77778], 9825: [.12963, .69444, 0, 0, .77778], 9826: [.12963, .69444, 0, 0, .77778], 9827: [.12963, .69444, 0, 0, .77778], 9837: [0, .75, 0, 0, .38889], 9838: [.19444, .69444, 0, 0, .38889], 9839: [.19444, .69444, 0, 0, .38889], 10216: [.25, .75, 0, 0, .38889], 10217: [.25, .75, 0, 0, .38889], 10222: [.244, .744, 0, 0, .412], 10223: [.244, .745, 0, 0, .412], 10229: [.011, .511, 0, 0, 1.609], 10230: [.011, .511, 0, 0, 1.638], 10231: [.011, .511, 0, 0, 1.859], 10232: [.024, .525, 0, 0, 1.609], 10233: [.024, .525, 0, 0, 1.638], 10234: [.024, .525, 0, 0, 1.858], 10236: [.011, .511, 0, 0, 1.638], 10815: [0, .68333, 0, 0, .75], 10927: [.13597, .63597, 0, 0, .77778], 10928: [.13597, .63597, 0, 0, .77778], 57376: [.19444, .69444, 0, 0, 0] }, "Math-BoldItalic": { 32: [0, 0, 0, 0, .25], 48: [0, .44444, 0, 0, .575], 49: [0, .44444, 0, 0, .575], 50: [0, .44444, 0, 0, .575], 51: [.19444, .44444, 0, 0, .575], 52: [.19444, .44444, 0, 0, .575], 53: [.19444, .44444, 0, 0, .575], 54: [0, .64444, 0, 0, .575], 55: [.19444, .44444, 0, 0, .575], 56: [0, .64444, 0, 0, .575], 57: [.19444, .44444, 0, 0, .575], 65: [0, .68611, 0, 0, .86944], 66: [0, .68611, .04835, 0, .8664], 67: [0, .68611, .06979, 0, .81694], 68: [0, .68611, .03194, 0, .93812], 69: [0, .68611, .05451, 0, .81007], 70: [0, .68611, .15972, 0, .68889], 71: [0, .68611, 0, 0, .88673], 72: [0, .68611, .08229, 0, .98229], 73: [0, .68611, .07778, 0, .51111], 74: [0, .68611, .10069, 0, .63125], 75: [0, .68611, .06979, 0, .97118], 76: [0, .68611, 0, 0, .75555], 77: [0, .68611, .11424, 0, 1.14201], 78: [0, .68611, .11424, 0, .95034], 79: [0, .68611, .03194, 0, .83666], 80: [0, .68611, .15972, 0, .72309], 81: [.19444, .68611, 0, 0, .86861], 82: [0, .68611, .00421, 0, .87235], 83: [0, .68611, .05382, 0, .69271], 84: [0, .68611, .15972, 0, .63663], 85: [0, .68611, .11424, 0, .80027], 86: [0, .68611, .25555, 0, .67778], 87: [0, .68611, .15972, 0, 1.09305], 88: [0, .68611, .07778, 0, .94722], 89: [0, .68611, .25555, 0, .67458], 90: [0, .68611, .06979, 0, .77257], 97: [0, .44444, 0, 0, .63287], 98: [0, .69444, 0, 0, .52083], 99: [0, .44444, 0, 0, .51342], 100: [0, .69444, 0, 0, .60972], 101: [0, .44444, 0, 0, .55361], 102: [.19444, .69444, .11042, 0, .56806], 103: [.19444, .44444, .03704, 0, .5449], 104: [0, .69444, 0, 0, .66759], 105: [0, .69326, 0, 0, .4048], 106: [.19444, .69326, .0622, 0, .47083], 107: [0, .69444, .01852, 0, .6037], 108: [0, .69444, .0088, 0, .34815], 109: [0, .44444, 0, 0, 1.0324], 110: [0, .44444, 0, 0, .71296], 111: [0, .44444, 0, 0, .58472], 112: [.19444, .44444, 0, 0, .60092], 113: [.19444, .44444, .03704, 0, .54213], 114: [0, .44444, .03194, 0, .5287], 115: [0, .44444, 0, 0, .53125], 116: [0, .63492, 0, 0, .41528], 117: [0, .44444, 0, 0, .68102], 118: [0, .44444, .03704, 0, .56666], 119: [0, .44444, .02778, 0, .83148], 120: [0, .44444, 0, 0, .65903], 121: [.19444, .44444, .03704, 0, .59028], 122: [0, .44444, .04213, 0, .55509], 160: [0, 0, 0, 0, .25], 915: [0, .68611, .15972, 0, .65694], 916: [0, .68611, 0, 0, .95833], 920: [0, .68611, .03194, 0, .86722], 923: [0, .68611, 0, 0, .80555], 926: [0, .68611, .07458, 0, .84125], 928: [0, .68611, .08229, 0, .98229], 931: [0, .68611, .05451, 0, .88507], 933: [0, .68611, .15972, 0, .67083], 934: [0, .68611, 0, 0, .76666], 936: [0, .68611, .11653, 0, .71402], 937: [0, .68611, .04835, 0, .8789], 945: [0, .44444, 0, 0, .76064], 946: [.19444, .69444, .03403, 0, .65972], 947: [.19444, .44444, .06389, 0, .59003], 948: [0, .69444, .03819, 0, .52222], 949: [0, .44444, 0, 0, .52882], 950: [.19444, .69444, .06215, 0, .50833], 951: [.19444, .44444, .03704, 0, .6], 952: [0, .69444, .03194, 0, .5618], 953: [0, .44444, 0, 0, .41204], 954: [0, .44444, 0, 0, .66759], 955: [0, .69444, 0, 0, .67083], 956: [.19444, .44444, 0, 0, .70787], 957: [0, .44444, .06898, 0, .57685], 958: [.19444, .69444, .03021, 0, .50833], 959: [0, .44444, 0, 0, .58472], 960: [0, .44444, .03704, 0, .68241], 961: [.19444, .44444, 0, 0, .6118], 962: [.09722, .44444, .07917, 0, .42361], 963: [0, .44444, .03704, 0, .68588], 964: [0, .44444, .13472, 0, .52083], 965: [0, .44444, .03704, 0, .63055], 966: [.19444, .44444, 0, 0, .74722], 967: [.19444, .44444, 0, 0, .71805], 968: [.19444, .69444, .03704, 0, .75833], 969: [0, .44444, .03704, 0, .71782], 977: [0, .69444, 0, 0, .69155], 981: [.19444, .69444, 0, 0, .7125], 982: [0, .44444, .03194, 0, .975], 1009: [.19444, .44444, 0, 0, .6118], 1013: [0, .44444, 0, 0, .48333], 57649: [0, .44444, 0, 0, .39352], 57911: [.19444, .44444, 0, 0, .43889] }, "Math-Italic": { 32: [0, 0, 0, 0, .25], 48: [0, .43056, 0, 0, .5], 49: [0, .43056, 0, 0, .5], 50: [0, .43056, 0, 0, .5], 51: [.19444, .43056, 0, 0, .5], 52: [.19444, .43056, 0, 0, .5], 53: [.19444, .43056, 0, 0, .5], 54: [0, .64444, 0, 0, .5], 55: [.19444, .43056, 0, 0, .5], 56: [0, .64444, 0, 0, .5], 57: [.19444, .43056, 0, 0, .5], 65: [0, .68333, 0, .13889, .75], 66: [0, .68333, .05017, .08334, .75851], 67: [0, .68333, .07153, .08334, .71472], 68: [0, .68333, .02778, .05556, .82792], 69: [0, .68333, .05764, .08334, .7382], 70: [0, .68333, .13889, .08334, .64306], 71: [0, .68333, 0, .08334, .78625], 72: [0, .68333, .08125, .05556, .83125], 73: [0, .68333, .07847, .11111, .43958], 74: [0, .68333, .09618, .16667, .55451], 75: [0, .68333, .07153, .05556, .84931], 76: [0, .68333, 0, .02778, .68056], 77: [0, .68333, .10903, .08334, .97014], 78: [0, .68333, .10903, .08334, .80347], 79: [0, .68333, .02778, .08334, .76278], 80: [0, .68333, .13889, .08334, .64201], 81: [.19444, .68333, 0, .08334, .79056], 82: [0, .68333, .00773, .08334, .75929], 83: [0, .68333, .05764, .08334, .6132], 84: [0, .68333, .13889, .08334, .58438], 85: [0, .68333, .10903, .02778, .68278], 86: [0, .68333, .22222, 0, .58333], 87: [0, .68333, .13889, 0, .94445], 88: [0, .68333, .07847, .08334, .82847], 89: [0, .68333, .22222, 0, .58056], 90: [0, .68333, .07153, .08334, .68264], 97: [0, .43056, 0, 0, .52859], 98: [0, .69444, 0, 0, .42917], 99: [0, .43056, 0, .05556, .43276], 100: [0, .69444, 0, .16667, .52049], 101: [0, .43056, 0, .05556, .46563], 102: [.19444, .69444, .10764, .16667, .48959], 103: [.19444, .43056, .03588, .02778, .47697], 104: [0, .69444, 0, 0, .57616], 105: [0, .65952, 0, 0, .34451], 106: [.19444, .65952, .05724, 0, .41181], 107: [0, .69444, .03148, 0, .5206], 108: [0, .69444, .01968, .08334, .29838], 109: [0, .43056, 0, 0, .87801], 110: [0, .43056, 0, 0, .60023], 111: [0, .43056, 0, .05556, .48472], 112: [.19444, .43056, 0, .08334, .50313], 113: [.19444, .43056, .03588, .08334, .44641], 114: [0, .43056, .02778, .05556, .45116], 115: [0, .43056, 0, .05556, .46875], 116: [0, .61508, 0, .08334, .36111], 117: [0, .43056, 0, .02778, .57246], 118: [0, .43056, .03588, .02778, .48472], 119: [0, .43056, .02691, .08334, .71592], 120: [0, .43056, 0, .02778, .57153], 121: [.19444, .43056, .03588, .05556, .49028], 122: [0, .43056, .04398, .05556, .46505], 160: [0, 0, 0, 0, .25], 915: [0, .68333, .13889, .08334, .61528], 916: [0, .68333, 0, .16667, .83334], 920: [0, .68333, .02778, .08334, .76278], 923: [0, .68333, 0, .16667, .69445], 926: [0, .68333, .07569, .08334, .74236], 928: [0, .68333, .08125, .05556, .83125], 931: [0, .68333, .05764, .08334, .77986], 933: [0, .68333, .13889, .05556, .58333], 934: [0, .68333, 0, .08334, .66667], 936: [0, .68333, .11, .05556, .61222], 937: [0, .68333, .05017, .08334, .7724], 945: [0, .43056, .0037, .02778, .6397], 946: [.19444, .69444, .05278, .08334, .56563], 947: [.19444, .43056, .05556, 0, .51773], 948: [0, .69444, .03785, .05556, .44444], 949: [0, .43056, 0, .08334, .46632], 950: [.19444, .69444, .07378, .08334, .4375], 951: [.19444, .43056, .03588, .05556, .49653], 952: [0, .69444, .02778, .08334, .46944], 953: [0, .43056, 0, .05556, .35394], 954: [0, .43056, 0, 0, .57616], 955: [0, .69444, 0, 0, .58334], 956: [.19444, .43056, 0, .02778, .60255], 957: [0, .43056, .06366, .02778, .49398], 958: [.19444, .69444, .04601, .11111, .4375], 959: [0, .43056, 0, .05556, .48472], 960: [0, .43056, .03588, 0, .57003], 961: [.19444, .43056, 0, .08334, .51702], 962: [.09722, .43056, .07986, .08334, .36285], 963: [0, .43056, .03588, 0, .57141], 964: [0, .43056, .1132, .02778, .43715], 965: [0, .43056, .03588, .02778, .54028], 966: [.19444, .43056, 0, .08334, .65417], 967: [.19444, .43056, 0, .05556, .62569], 968: [.19444, .69444, .03588, .11111, .65139], 969: [0, .43056, .03588, 0, .62245], 977: [0, .69444, 0, .08334, .59144], 981: [.19444, .69444, 0, .08334, .59583], 982: [0, .43056, .02778, 0, .82813], 1009: [.19444, .43056, 0, .08334, .51702], 1013: [0, .43056, 0, .05556, .4059], 57649: [0, .43056, 0, .02778, .32246], 57911: [.19444, .43056, 0, .08334, .38403] }, "SansSerif-Bold": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, 0, 0, .36667], 34: [0, .69444, 0, 0, .55834], 35: [.19444, .69444, 0, 0, .91667], 36: [.05556, .75, 0, 0, .55], 37: [.05556, .75, 0, 0, 1.02912], 38: [0, .69444, 0, 0, .83056], 39: [0, .69444, 0, 0, .30556], 40: [.25, .75, 0, 0, .42778], 41: [.25, .75, 0, 0, .42778], 42: [0, .75, 0, 0, .55], 43: [.11667, .61667, 0, 0, .85556], 44: [.10556, .13056, 0, 0, .30556], 45: [0, .45833, 0, 0, .36667], 46: [0, .13056, 0, 0, .30556], 47: [.25, .75, 0, 0, .55], 48: [0, .69444, 0, 0, .55], 49: [0, .69444, 0, 0, .55], 50: [0, .69444, 0, 0, .55], 51: [0, .69444, 0, 0, .55], 52: [0, .69444, 0, 0, .55], 53: [0, .69444, 0, 0, .55], 54: [0, .69444, 0, 0, .55], 55: [0, .69444, 0, 0, .55], 56: [0, .69444, 0, 0, .55], 57: [0, .69444, 0, 0, .55], 58: [0, .45833, 0, 0, .30556], 59: [.10556, .45833, 0, 0, .30556], 61: [-.09375, .40625, 0, 0, .85556], 63: [0, .69444, 0, 0, .51945], 64: [0, .69444, 0, 0, .73334], 65: [0, .69444, 0, 0, .73334], 66: [0, .69444, 0, 0, .73334], 67: [0, .69444, 0, 0, .70278], 68: [0, .69444, 0, 0, .79445], 69: [0, .69444, 0, 0, .64167], 70: [0, .69444, 0, 0, .61111], 71: [0, .69444, 0, 0, .73334], 72: [0, .69444, 0, 0, .79445], 73: [0, .69444, 0, 0, .33056], 74: [0, .69444, 0, 0, .51945], 75: [0, .69444, 0, 0, .76389], 76: [0, .69444, 0, 0, .58056], 77: [0, .69444, 0, 0, .97778], 78: [0, .69444, 0, 0, .79445], 79: [0, .69444, 0, 0, .79445], 80: [0, .69444, 0, 0, .70278], 81: [.10556, .69444, 0, 0, .79445], 82: [0, .69444, 0, 0, .70278], 83: [0, .69444, 0, 0, .61111], 84: [0, .69444, 0, 0, .73334], 85: [0, .69444, 0, 0, .76389], 86: [0, .69444, .01528, 0, .73334], 87: [0, .69444, .01528, 0, 1.03889], 88: [0, .69444, 0, 0, .73334], 89: [0, .69444, .0275, 0, .73334], 90: [0, .69444, 0, 0, .67223], 91: [.25, .75, 0, 0, .34306], 93: [.25, .75, 0, 0, .34306], 94: [0, .69444, 0, 0, .55], 95: [.35, .10833, .03056, 0, .55], 97: [0, .45833, 0, 0, .525], 98: [0, .69444, 0, 0, .56111], 99: [0, .45833, 0, 0, .48889], 100: [0, .69444, 0, 0, .56111], 101: [0, .45833, 0, 0, .51111], 102: [0, .69444, .07639, 0, .33611], 103: [.19444, .45833, .01528, 0, .55], 104: [0, .69444, 0, 0, .56111], 105: [0, .69444, 0, 0, .25556], 106: [.19444, .69444, 0, 0, .28611], 107: [0, .69444, 0, 0, .53056], 108: [0, .69444, 0, 0, .25556], 109: [0, .45833, 0, 0, .86667], 110: [0, .45833, 0, 0, .56111], 111: [0, .45833, 0, 0, .55], 112: [.19444, .45833, 0, 0, .56111], 113: [.19444, .45833, 0, 0, .56111], 114: [0, .45833, .01528, 0, .37222], 115: [0, .45833, 0, 0, .42167], 116: [0, .58929, 0, 0, .40417], 117: [0, .45833, 0, 0, .56111], 118: [0, .45833, .01528, 0, .5], 119: [0, .45833, .01528, 0, .74445], 120: [0, .45833, 0, 0, .5], 121: [.19444, .45833, .01528, 0, .5], 122: [0, .45833, 0, 0, .47639], 126: [.35, .34444, 0, 0, .55], 160: [0, 0, 0, 0, .25], 168: [0, .69444, 0, 0, .55], 176: [0, .69444, 0, 0, .73334], 180: [0, .69444, 0, 0, .55], 184: [.17014, 0, 0, 0, .48889], 305: [0, .45833, 0, 0, .25556], 567: [.19444, .45833, 0, 0, .28611], 710: [0, .69444, 0, 0, .55], 711: [0, .63542, 0, 0, .55], 713: [0, .63778, 0, 0, .55], 728: [0, .69444, 0, 0, .55], 729: [0, .69444, 0, 0, .30556], 730: [0, .69444, 0, 0, .73334], 732: [0, .69444, 0, 0, .55], 733: [0, .69444, 0, 0, .55], 915: [0, .69444, 0, 0, .58056], 916: [0, .69444, 0, 0, .91667], 920: [0, .69444, 0, 0, .85556], 923: [0, .69444, 0, 0, .67223], 926: [0, .69444, 0, 0, .73334], 928: [0, .69444, 0, 0, .79445], 931: [0, .69444, 0, 0, .79445], 933: [0, .69444, 0, 0, .85556], 934: [0, .69444, 0, 0, .79445], 936: [0, .69444, 0, 0, .85556], 937: [0, .69444, 0, 0, .79445], 8211: [0, .45833, .03056, 0, .55], 8212: [0, .45833, .03056, 0, 1.10001], 8216: [0, .69444, 0, 0, .30556], 8217: [0, .69444, 0, 0, .30556], 8220: [0, .69444, 0, 0, .55834], 8221: [0, .69444, 0, 0, .55834] }, "SansSerif-Italic": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, .05733, 0, .31945], 34: [0, .69444, .00316, 0, .5], 35: [.19444, .69444, .05087, 0, .83334], 36: [.05556, .75, .11156, 0, .5], 37: [.05556, .75, .03126, 0, .83334], 38: [0, .69444, .03058, 0, .75834], 39: [0, .69444, .07816, 0, .27778], 40: [.25, .75, .13164, 0, .38889], 41: [.25, .75, .02536, 0, .38889], 42: [0, .75, .11775, 0, .5], 43: [.08333, .58333, .02536, 0, .77778], 44: [.125, .08333, 0, 0, .27778], 45: [0, .44444, .01946, 0, .33333], 46: [0, .08333, 0, 0, .27778], 47: [.25, .75, .13164, 0, .5], 48: [0, .65556, .11156, 0, .5], 49: [0, .65556, .11156, 0, .5], 50: [0, .65556, .11156, 0, .5], 51: [0, .65556, .11156, 0, .5], 52: [0, .65556, .11156, 0, .5], 53: [0, .65556, .11156, 0, .5], 54: [0, .65556, .11156, 0, .5], 55: [0, .65556, .11156, 0, .5], 56: [0, .65556, .11156, 0, .5], 57: [0, .65556, .11156, 0, .5], 58: [0, .44444, .02502, 0, .27778], 59: [.125, .44444, .02502, 0, .27778], 61: [-.13, .37, .05087, 0, .77778], 63: [0, .69444, .11809, 0, .47222], 64: [0, .69444, .07555, 0, .66667], 65: [0, .69444, 0, 0, .66667], 66: [0, .69444, .08293, 0, .66667], 67: [0, .69444, .11983, 0, .63889], 68: [0, .69444, .07555, 0, .72223], 69: [0, .69444, .11983, 0, .59722], 70: [0, .69444, .13372, 0, .56945], 71: [0, .69444, .11983, 0, .66667], 72: [0, .69444, .08094, 0, .70834], 73: [0, .69444, .13372, 0, .27778], 74: [0, .69444, .08094, 0, .47222], 75: [0, .69444, .11983, 0, .69445], 76: [0, .69444, 0, 0, .54167], 77: [0, .69444, .08094, 0, .875], 78: [0, .69444, .08094, 0, .70834], 79: [0, .69444, .07555, 0, .73611], 80: [0, .69444, .08293, 0, .63889], 81: [.125, .69444, .07555, 0, .73611], 82: [0, .69444, .08293, 0, .64584], 83: [0, .69444, .09205, 0, .55556], 84: [0, .69444, .13372, 0, .68056], 85: [0, .69444, .08094, 0, .6875], 86: [0, .69444, .1615, 0, .66667], 87: [0, .69444, .1615, 0, .94445], 88: [0, .69444, .13372, 0, .66667], 89: [0, .69444, .17261, 0, .66667], 90: [0, .69444, .11983, 0, .61111], 91: [.25, .75, .15942, 0, .28889], 93: [.25, .75, .08719, 0, .28889], 94: [0, .69444, .0799, 0, .5], 95: [.35, .09444, .08616, 0, .5], 97: [0, .44444, .00981, 0, .48056], 98: [0, .69444, .03057, 0, .51667], 99: [0, .44444, .08336, 0, .44445], 100: [0, .69444, .09483, 0, .51667], 101: [0, .44444, .06778, 0, .44445], 102: [0, .69444, .21705, 0, .30556], 103: [.19444, .44444, .10836, 0, .5], 104: [0, .69444, .01778, 0, .51667], 105: [0, .67937, .09718, 0, .23889], 106: [.19444, .67937, .09162, 0, .26667], 107: [0, .69444, .08336, 0, .48889], 108: [0, .69444, .09483, 0, .23889], 109: [0, .44444, .01778, 0, .79445], 110: [0, .44444, .01778, 0, .51667], 111: [0, .44444, .06613, 0, .5], 112: [.19444, .44444, .0389, 0, .51667], 113: [.19444, .44444, .04169, 0, .51667], 114: [0, .44444, .10836, 0, .34167], 115: [0, .44444, .0778, 0, .38333], 116: [0, .57143, .07225, 0, .36111], 117: [0, .44444, .04169, 0, .51667], 118: [0, .44444, .10836, 0, .46111], 119: [0, .44444, .10836, 0, .68334], 120: [0, .44444, .09169, 0, .46111], 121: [.19444, .44444, .10836, 0, .46111], 122: [0, .44444, .08752, 0, .43472], 126: [.35, .32659, .08826, 0, .5], 160: [0, 0, 0, 0, .25], 168: [0, .67937, .06385, 0, .5], 176: [0, .69444, 0, 0, .73752], 184: [.17014, 0, 0, 0, .44445], 305: [0, .44444, .04169, 0, .23889], 567: [.19444, .44444, .04169, 0, .26667], 710: [0, .69444, .0799, 0, .5], 711: [0, .63194, .08432, 0, .5], 713: [0, .60889, .08776, 0, .5], 714: [0, .69444, .09205, 0, .5], 715: [0, .69444, 0, 0, .5], 728: [0, .69444, .09483, 0, .5], 729: [0, .67937, .07774, 0, .27778], 730: [0, .69444, 0, 0, .73752], 732: [0, .67659, .08826, 0, .5], 733: [0, .69444, .09205, 0, .5], 915: [0, .69444, .13372, 0, .54167], 916: [0, .69444, 0, 0, .83334], 920: [0, .69444, .07555, 0, .77778], 923: [0, .69444, 0, 0, .61111], 926: [0, .69444, .12816, 0, .66667], 928: [0, .69444, .08094, 0, .70834], 931: [0, .69444, .11983, 0, .72222], 933: [0, .69444, .09031, 0, .77778], 934: [0, .69444, .04603, 0, .72222], 936: [0, .69444, .09031, 0, .77778], 937: [0, .69444, .08293, 0, .72222], 8211: [0, .44444, .08616, 0, .5], 8212: [0, .44444, .08616, 0, 1], 8216: [0, .69444, .07816, 0, .27778], 8217: [0, .69444, .07816, 0, .27778], 8220: [0, .69444, .14205, 0, .5], 8221: [0, .69444, .00316, 0, .5] }, "SansSerif-Regular": { 32: [0, 0, 0, 0, .25], 33: [0, .69444, 0, 0, .31945], 34: [0, .69444, 0, 0, .5], 35: [.19444, .69444, 0, 0, .83334], 36: [.05556, .75, 0, 0, .5], 37: [.05556, .75, 0, 0, .83334], 38: [0, .69444, 0, 0, .75834], 39: [0, .69444, 0, 0, .27778], 40: [.25, .75, 0, 0, .38889], 41: [.25, .75, 0, 0, .38889], 42: [0, .75, 0, 0, .5], 43: [.08333, .58333, 0, 0, .77778], 44: [.125, .08333, 0, 0, .27778], 45: [0, .44444, 0, 0, .33333], 46: [0, .08333, 0, 0, .27778], 47: [.25, .75, 0, 0, .5], 48: [0, .65556, 0, 0, .5], 49: [0, .65556, 0, 0, .5], 50: [0, .65556, 0, 0, .5], 51: [0, .65556, 0, 0, .5], 52: [0, .65556, 0, 0, .5], 53: [0, .65556, 0, 0, .5], 54: [0, .65556, 0, 0, .5], 55: [0, .65556, 0, 0, .5], 56: [0, .65556, 0, 0, .5], 57: [0, .65556, 0, 0, .5], 58: [0, .44444, 0, 0, .27778], 59: [.125, .44444, 0, 0, .27778], 61: [-.13, .37, 0, 0, .77778], 63: [0, .69444, 0, 0, .47222], 64: [0, .69444, 0, 0, .66667], 65: [0, .69444, 0, 0, .66667], 66: [0, .69444, 0, 0, .66667], 67: [0, .69444, 0, 0, .63889], 68: [0, .69444, 0, 0, .72223], 69: [0, .69444, 0, 0, .59722], 70: [0, .69444, 0, 0, .56945], 71: [0, .69444, 0, 0, .66667], 72: [0, .69444, 0, 0, .70834], 73: [0, .69444, 0, 0, .27778], 74: [0, .69444, 0, 0, .47222], 75: [0, .69444, 0, 0, .69445], 76: [0, .69444, 0, 0, .54167], 77: [0, .69444, 0, 0, .875], 78: [0, .69444, 0, 0, .70834], 79: [0, .69444, 0, 0, .73611], 80: [0, .69444, 0, 0, .63889], 81: [.125, .69444, 0, 0, .73611], 82: [0, .69444, 0, 0, .64584], 83: [0, .69444, 0, 0, .55556], 84: [0, .69444, 0, 0, .68056], 85: [0, .69444, 0, 0, .6875], 86: [0, .69444, .01389, 0, .66667], 87: [0, .69444, .01389, 0, .94445], 88: [0, .69444, 0, 0, .66667], 89: [0, .69444, .025, 0, .66667], 90: [0, .69444, 0, 0, .61111], 91: [.25, .75, 0, 0, .28889], 93: [.25, .75, 0, 0, .28889], 94: [0, .69444, 0, 0, .5], 95: [.35, .09444, .02778, 0, .5], 97: [0, .44444, 0, 0, .48056], 98: [0, .69444, 0, 0, .51667], 99: [0, .44444, 0, 0, .44445], 100: [0, .69444, 0, 0, .51667], 101: [0, .44444, 0, 0, .44445], 102: [0, .69444, .06944, 0, .30556], 103: [.19444, .44444, .01389, 0, .5], 104: [0, .69444, 0, 0, .51667], 105: [0, .67937, 0, 0, .23889], 106: [.19444, .67937, 0, 0, .26667], 107: [0, .69444, 0, 0, .48889], 108: [0, .69444, 0, 0, .23889], 109: [0, .44444, 0, 0, .79445], 110: [0, .44444, 0, 0, .51667], 111: [0, .44444, 0, 0, .5], 112: [.19444, .44444, 0, 0, .51667], 113: [.19444, .44444, 0, 0, .51667], 114: [0, .44444, .01389, 0, .34167], 115: [0, .44444, 0, 0, .38333], 116: [0, .57143, 0, 0, .36111], 117: [0, .44444, 0, 0, .51667], 118: [0, .44444, .01389, 0, .46111], 119: [0, .44444, .01389, 0, .68334], 120: [0, .44444, 0, 0, .46111], 121: [.19444, .44444, .01389, 0, .46111], 122: [0, .44444, 0, 0, .43472], 126: [.35, .32659, 0, 0, .5], 160: [0, 0, 0, 0, .25], 168: [0, .67937, 0, 0, .5], 176: [0, .69444, 0, 0, .66667], 184: [.17014, 0, 0, 0, .44445], 305: [0, .44444, 0, 0, .23889], 567: [.19444, .44444, 0, 0, .26667], 710: [0, .69444, 0, 0, .5], 711: [0, .63194, 0, 0, .5], 713: [0, .60889, 0, 0, .5], 714: [0, .69444, 0, 0, .5], 715: [0, .69444, 0, 0, .5], 728: [0, .69444, 0, 0, .5], 729: [0, .67937, 0, 0, .27778], 730: [0, .69444, 0, 0, .66667], 732: [0, .67659, 0, 0, .5], 733: [0, .69444, 0, 0, .5], 915: [0, .69444, 0, 0, .54167], 916: [0, .69444, 0, 0, .83334], 920: [0, .69444, 0, 0, .77778], 923: [0, .69444, 0, 0, .61111], 926: [0, .69444, 0, 0, .66667], 928: [0, .69444, 0, 0, .70834], 931: [0, .69444, 0, 0, .72222], 933: [0, .69444, 0, 0, .77778], 934: [0, .69444, 0, 0, .72222], 936: [0, .69444, 0, 0, .77778], 937: [0, .69444, 0, 0, .72222], 8211: [0, .44444, .02778, 0, .5], 8212: [0, .44444, .02778, 0, 1], 8216: [0, .69444, 0, 0, .27778], 8217: [0, .69444, 0, 0, .27778], 8220: [0, .69444, 0, 0, .5], 8221: [0, .69444, 0, 0, .5] }, "Script-Regular": { 32: [0, 0, 0, 0, .25], 65: [0, .7, .22925, 0, .80253], 66: [0, .7, .04087, 0, .90757], 67: [0, .7, .1689, 0, .66619], 68: [0, .7, .09371, 0, .77443], 69: [0, .7, .18583, 0, .56162], 70: [0, .7, .13634, 0, .89544], 71: [0, .7, .17322, 0, .60961], 72: [0, .7, .29694, 0, .96919], 73: [0, .7, .19189, 0, .80907], 74: [.27778, .7, .19189, 0, 1.05159], 75: [0, .7, .31259, 0, .91364], 76: [0, .7, .19189, 0, .87373], 77: [0, .7, .15981, 0, 1.08031], 78: [0, .7, .3525, 0, .9015], 79: [0, .7, .08078, 0, .73787], 80: [0, .7, .08078, 0, 1.01262], 81: [0, .7, .03305, 0, .88282], 82: [0, .7, .06259, 0, .85], 83: [0, .7, .19189, 0, .86767], 84: [0, .7, .29087, 0, .74697], 85: [0, .7, .25815, 0, .79996], 86: [0, .7, .27523, 0, .62204], 87: [0, .7, .27523, 0, .80532], 88: [0, .7, .26006, 0, .94445], 89: [0, .7, .2939, 0, .70961], 90: [0, .7, .24037, 0, .8212], 160: [0, 0, 0, 0, .25] }, "Size1-Regular": { 32: [0, 0, 0, 0, .25], 40: [.35001, .85, 0, 0, .45834], 41: [.35001, .85, 0, 0, .45834], 47: [.35001, .85, 0, 0, .57778], 91: [.35001, .85, 0, 0, .41667], 92: [.35001, .85, 0, 0, .57778], 93: [.35001, .85, 0, 0, .41667], 123: [.35001, .85, 0, 0, .58334], 125: [.35001, .85, 0, 0, .58334], 160: [0, 0, 0, 0, .25], 710: [0, .72222, 0, 0, .55556], 732: [0, .72222, 0, 0, .55556], 770: [0, .72222, 0, 0, .55556], 771: [0, .72222, 0, 0, .55556], 8214: [-99e-5, .601, 0, 0, .77778], 8593: [1e-5, .6, 0, 0, .66667], 8595: [1e-5, .6, 0, 0, .66667], 8657: [1e-5, .6, 0, 0, .77778], 8659: [1e-5, .6, 0, 0, .77778], 8719: [.25001, .75, 0, 0, .94445], 8720: [.25001, .75, 0, 0, .94445], 8721: [.25001, .75, 0, 0, 1.05556], 8730: [.35001, .85, 0, 0, 1], 8739: [-.00599, .606, 0, 0, .33333], 8741: [-.00599, .606, 0, 0, .55556], 8747: [.30612, .805, .19445, 0, .47222], 8748: [.306, .805, .19445, 0, .47222], 8749: [.306, .805, .19445, 0, .47222], 8750: [.30612, .805, .19445, 0, .47222], 8896: [.25001, .75, 0, 0, .83334], 8897: [.25001, .75, 0, 0, .83334], 8898: [.25001, .75, 0, 0, .83334], 8899: [.25001, .75, 0, 0, .83334], 8968: [.35001, .85, 0, 0, .47222], 8969: [.35001, .85, 0, 0, .47222], 8970: [.35001, .85, 0, 0, .47222], 8971: [.35001, .85, 0, 0, .47222], 9168: [-99e-5, .601, 0, 0, .66667], 10216: [.35001, .85, 0, 0, .47222], 10217: [.35001, .85, 0, 0, .47222], 10752: [.25001, .75, 0, 0, 1.11111], 10753: [.25001, .75, 0, 0, 1.11111], 10754: [.25001, .75, 0, 0, 1.11111], 10756: [.25001, .75, 0, 0, .83334], 10758: [.25001, .75, 0, 0, .83334] }, "Size2-Regular": { 32: [0, 0, 0, 0, .25], 40: [.65002, 1.15, 0, 0, .59722], 41: [.65002, 1.15, 0, 0, .59722], 47: [.65002, 1.15, 0, 0, .81111], 91: [.65002, 1.15, 0, 0, .47222], 92: [.65002, 1.15, 0, 0, .81111], 93: [.65002, 1.15, 0, 0, .47222], 123: [.65002, 1.15, 0, 0, .66667], 125: [.65002, 1.15, 0, 0, .66667], 160: [0, 0, 0, 0, .25], 710: [0, .75, 0, 0, 1], 732: [0, .75, 0, 0, 1], 770: [0, .75, 0, 0, 1], 771: [0, .75, 0, 0, 1], 8719: [.55001, 1.05, 0, 0, 1.27778], 8720: [.55001, 1.05, 0, 0, 1.27778], 8721: [.55001, 1.05, 0, 0, 1.44445], 8730: [.65002, 1.15, 0, 0, 1], 8747: [.86225, 1.36, .44445, 0, .55556], 8748: [.862, 1.36, .44445, 0, .55556], 8749: [.862, 1.36, .44445, 0, .55556], 8750: [.86225, 1.36, .44445, 0, .55556], 8896: [.55001, 1.05, 0, 0, 1.11111], 8897: [.55001, 1.05, 0, 0, 1.11111], 8898: [.55001, 1.05, 0, 0, 1.11111], 8899: [.55001, 1.05, 0, 0, 1.11111], 8968: [.65002, 1.15, 0, 0, .52778], 8969: [.65002, 1.15, 0, 0, .52778], 8970: [.65002, 1.15, 0, 0, .52778], 8971: [.65002, 1.15, 0, 0, .52778], 10216: [.65002, 1.15, 0, 0, .61111], 10217: [.65002, 1.15, 0, 0, .61111], 10752: [.55001, 1.05, 0, 0, 1.51112], 10753: [.55001, 1.05, 0, 0, 1.51112], 10754: [.55001, 1.05, 0, 0, 1.51112], 10756: [.55001, 1.05, 0, 0, 1.11111], 10758: [.55001, 1.05, 0, 0, 1.11111] }, "Size3-Regular": { 32: [0, 0, 0, 0, .25], 40: [.95003, 1.45, 0, 0, .73611], 41: [.95003, 1.45, 0, 0, .73611], 47: [.95003, 1.45, 0, 0, 1.04445], 91: [.95003, 1.45, 0, 0, .52778], 92: [.95003, 1.45, 0, 0, 1.04445], 93: [.95003, 1.45, 0, 0, .52778], 123: [.95003, 1.45, 0, 0, .75], 125: [.95003, 1.45, 0, 0, .75], 160: [0, 0, 0, 0, .25], 710: [0, .75, 0, 0, 1.44445], 732: [0, .75, 0, 0, 1.44445], 770: [0, .75, 0, 0, 1.44445], 771: [0, .75, 0, 0, 1.44445], 8730: [.95003, 1.45, 0, 0, 1], 8968: [.95003, 1.45, 0, 0, .58334], 8969: [.95003, 1.45, 0, 0, .58334], 8970: [.95003, 1.45, 0, 0, .58334], 8971: [.95003, 1.45, 0, 0, .58334], 10216: [.95003, 1.45, 0, 0, .75], 10217: [.95003, 1.45, 0, 0, .75] }, "Size4-Regular": { 32: [0, 0, 0, 0, .25], 40: [1.25003, 1.75, 0, 0, .79167], 41: [1.25003, 1.75, 0, 0, .79167], 47: [1.25003, 1.75, 0, 0, 1.27778], 91: [1.25003, 1.75, 0, 0, .58334], 92: [1.25003, 1.75, 0, 0, 1.27778], 93: [1.25003, 1.75, 0, 0, .58334], 123: [1.25003, 1.75, 0, 0, .80556], 125: [1.25003, 1.75, 0, 0, .80556], 160: [0, 0, 0, 0, .25], 710: [0, .825, 0, 0, 1.8889], 732: [0, .825, 0, 0, 1.8889], 770: [0, .825, 0, 0, 1.8889], 771: [0, .825, 0, 0, 1.8889], 8730: [1.25003, 1.75, 0, 0, 1], 8968: [1.25003, 1.75, 0, 0, .63889], 8969: [1.25003, 1.75, 0, 0, .63889], 8970: [1.25003, 1.75, 0, 0, .63889], 8971: [1.25003, 1.75, 0, 0, .63889], 9115: [.64502, 1.155, 0, 0, .875], 9116: [1e-5, .6, 0, 0, .875], 9117: [.64502, 1.155, 0, 0, .875], 9118: [.64502, 1.155, 0, 0, .875], 9119: [1e-5, .6, 0, 0, .875], 9120: [.64502, 1.155, 0, 0, .875], 9121: [.64502, 1.155, 0, 0, .66667], 9122: [-99e-5, .601, 0, 0, .66667], 9123: [.64502, 1.155, 0, 0, .66667], 9124: [.64502, 1.155, 0, 0, .66667], 9125: [-99e-5, .601, 0, 0, .66667], 9126: [.64502, 1.155, 0, 0, .66667], 9127: [1e-5, .9, 0, 0, .88889], 9128: [.65002, 1.15, 0, 0, .88889], 9129: [.90001, 0, 0, 0, .88889], 9130: [0, .3, 0, 0, .88889], 9131: [1e-5, .9, 0, 0, .88889], 9132: [.65002, 1.15, 0, 0, .88889], 9133: [.90001, 0, 0, 0, .88889], 9143: [.88502, .915, 0, 0, 1.05556], 10216: [1.25003, 1.75, 0, 0, .80556], 10217: [1.25003, 1.75, 0, 0, .80556], 57344: [-.00499, .605, 0, 0, 1.05556], 57345: [-.00499, .605, 0, 0, 1.05556], 57680: [0, .12, 0, 0, .45], 57681: [0, .12, 0, 0, .45], 57682: [0, .12, 0, 0, .45], 57683: [0, .12, 0, 0, .45] }, "Typewriter-Regular": { 32: [0, 0, 0, 0, .525], 33: [0, .61111, 0, 0, .525], 34: [0, .61111, 0, 0, .525], 35: [0, .61111, 0, 0, .525], 36: [.08333, .69444, 0, 0, .525], 37: [.08333, .69444, 0, 0, .525], 38: [0, .61111, 0, 0, .525], 39: [0, .61111, 0, 0, .525], 40: [.08333, .69444, 0, 0, .525], 41: [.08333, .69444, 0, 0, .525], 42: [0, .52083, 0, 0, .525], 43: [-.08056, .53055, 0, 0, .525], 44: [.13889, .125, 0, 0, .525], 45: [-.08056, .53055, 0, 0, .525], 46: [0, .125, 0, 0, .525], 47: [.08333, .69444, 0, 0, .525], 48: [0, .61111, 0, 0, .525], 49: [0, .61111, 0, 0, .525], 50: [0, .61111, 0, 0, .525], 51: [0, .61111, 0, 0, .525], 52: [0, .61111, 0, 0, .525], 53: [0, .61111, 0, 0, .525], 54: [0, .61111, 0, 0, .525], 55: [0, .61111, 0, 0, .525], 56: [0, .61111, 0, 0, .525], 57: [0, .61111, 0, 0, .525], 58: [0, .43056, 0, 0, .525], 59: [.13889, .43056, 0, 0, .525], 60: [-.05556, .55556, 0, 0, .525], 61: [-.19549, .41562, 0, 0, .525], 62: [-.05556, .55556, 0, 0, .525], 63: [0, .61111, 0, 0, .525], 64: [0, .61111, 0, 0, .525], 65: [0, .61111, 0, 0, .525], 66: [0, .61111, 0, 0, .525], 67: [0, .61111, 0, 0, .525], 68: [0, .61111, 0, 0, .525], 69: [0, .61111, 0, 0, .525], 70: [0, .61111, 0, 0, .525], 71: [0, .61111, 0, 0, .525], 72: [0, .61111, 0, 0, .525], 73: [0, .61111, 0, 0, .525], 74: [0, .61111, 0, 0, .525], 75: [0, .61111, 0, 0, .525], 76: [0, .61111, 0, 0, .525], 77: [0, .61111, 0, 0, .525], 78: [0, .61111, 0, 0, .525], 79: [0, .61111, 0, 0, .525], 80: [0, .61111, 0, 0, .525], 81: [.13889, .61111, 0, 0, .525], 82: [0, .61111, 0, 0, .525], 83: [0, .61111, 0, 0, .525], 84: [0, .61111, 0, 0, .525], 85: [0, .61111, 0, 0, .525], 86: [0, .61111, 0, 0, .525], 87: [0, .61111, 0, 0, .525], 88: [0, .61111, 0, 0, .525], 89: [0, .61111, 0, 0, .525], 90: [0, .61111, 0, 0, .525], 91: [.08333, .69444, 0, 0, .525], 92: [.08333, .69444, 0, 0, .525], 93: [.08333, .69444, 0, 0, .525], 94: [0, .61111, 0, 0, .525], 95: [.09514, 0, 0, 0, .525], 96: [0, .61111, 0, 0, .525], 97: [0, .43056, 0, 0, .525], 98: [0, .61111, 0, 0, .525], 99: [0, .43056, 0, 0, .525], 100: [0, .61111, 0, 0, .525], 101: [0, .43056, 0, 0, .525], 102: [0, .61111, 0, 0, .525], 103: [.22222, .43056, 0, 0, .525], 104: [0, .61111, 0, 0, .525], 105: [0, .61111, 0, 0, .525], 106: [.22222, .61111, 0, 0, .525], 107: [0, .61111, 0, 0, .525], 108: [0, .61111, 0, 0, .525], 109: [0, .43056, 0, 0, .525], 110: [0, .43056, 0, 0, .525], 111: [0, .43056, 0, 0, .525], 112: [.22222, .43056, 0, 0, .525], 113: [.22222, .43056, 0, 0, .525], 114: [0, .43056, 0, 0, .525], 115: [0, .43056, 0, 0, .525], 116: [0, .55358, 0, 0, .525], 117: [0, .43056, 0, 0, .525], 118: [0, .43056, 0, 0, .525], 119: [0, .43056, 0, 0, .525], 120: [0, .43056, 0, 0, .525], 121: [.22222, .43056, 0, 0, .525], 122: [0, .43056, 0, 0, .525], 123: [.08333, .69444, 0, 0, .525], 124: [.08333, .69444, 0, 0, .525], 125: [.08333, .69444, 0, 0, .525], 126: [0, .61111, 0, 0, .525], 127: [0, .61111, 0, 0, .525], 160: [0, 0, 0, 0, .525], 176: [0, .61111, 0, 0, .525], 184: [.19445, 0, 0, 0, .525], 305: [0, .43056, 0, 0, .525], 567: [.22222, .43056, 0, 0, .525], 711: [0, .56597, 0, 0, .525], 713: [0, .56555, 0, 0, .525], 714: [0, .61111, 0, 0, .525], 715: [0, .61111, 0, 0, .525], 728: [0, .61111, 0, 0, .525], 730: [0, .61111, 0, 0, .525], 770: [0, .61111, 0, 0, .525], 771: [0, .61111, 0, 0, .525], 776: [0, .61111, 0, 0, .525], 915: [0, .61111, 0, 0, .525], 916: [0, .61111, 0, 0, .525], 920: [0, .61111, 0, 0, .525], 923: [0, .61111, 0, 0, .525], 926: [0, .61111, 0, 0, .525], 928: [0, .61111, 0, 0, .525], 931: [0, .61111, 0, 0, .525], 933: [0, .61111, 0, 0, .525], 934: [0, .61111, 0, 0, .525], 936: [0, .61111, 0, 0, .525], 937: [0, .61111, 0, 0, .525], 8216: [0, .61111, 0, 0, .525], 8217: [0, .61111, 0, 0, .525], 8242: [0, .61111, 0, 0, .525], 9251: [.11111, .21944, 0, 0, .525] } }, Ae = { slant: [.25, .25, .25], space: [0, 0, 0], stretch: [0, 0, 0], shrink: [0, 0, 0], xHeight: [.431, .431, .431], quad: [1, 1.171, 1.472], extraSpace: [0, 0, 0], num1: [.677, .732, .925], num2: [.394, .384, .387], num3: [.444, .471, .504], denom1: [.686, .752, 1.025], denom2: [.345, .344, .532], sup1: [.413, .503, .504], sup2: [.363, .431, .404], sup3: [.289, .286, .294], sub1: [.15, .143, .2], sub2: [.247, .286, .4], supDrop: [.386, .353, .494], subDrop: [.05, .071, .1], delim1: [2.39, 1.7, 1.98], delim2: [1.01, 1.157, 1.42], axisHeight: [.25, .25, .25], defaultRuleThickness: [.04, .049, .049], bigOpSpacing1: [.111, .111, .111], bigOpSpacing2: [.166, .166, .166], bigOpSpacing3: [.2, .2, .2], bigOpSpacing4: [.6, .611, .611], bigOpSpacing5: [.1, .143, .143], sqrtRuleThickness: [.04, .04, .04], ptPerEm: [10, 10, 10], doubleRuleSep: [.2, .2, .2], arrayRuleWidth: [.04, .04, .04], fboxsep: [.3, .3, .3], fboxrule: [.04, .04, .04] }, hr = { \u00C5: "A", \u00D0: "D", \u00DE: "o", \u00E5: "a", \u00F0: "d", \u00FE: "o", \u0410: "A", \u0411: "B", \u0412: "B", \u0413: "F", \u0414: "A", \u0415: "E", \u0416: "K", \u0417: "3", \u0418: "N", \u0419: "N", \u041A: "K", \u041B: "N", \u041C: "M", \u041D: "H", \u041E: "O", \u041F: "N", \u0420: "P", \u0421: "C", \u0422: "T", \u0423: "y", \u0424: "O", \u0425: "X", \u0426: "U", \u0427: "h", \u0428: "W", \u0429: "W", \u042A: "B", \u042B: "X", \u042C: "B", \u042D: "3", \u042E: "X", \u042F: "R", \u0430: "a", \u0431: "b", \u0432: "a", \u0433: "r", \u0434: "y", \u0435: "e", \u0436: "m", \u0437: "e", \u0438: "n", \u0439: "n", \u043A: "n", \u043B: "n", \u043C: "m", \u043D: "n", \u043E: "o", \u043F: "n", \u0440: "p", \u0441: "c", \u0442: "o", \u0443: "y", \u0444: "b", \u0445: "x", \u0446: "n", \u0447: "n", \u0448: "w", \u0449: "w", \u044A: "a", \u044B: "m", \u044C: "a", \u044D: "e", \u044E: "m", \u044F: "r" };
function Ma(r, e) { z0[r] = e; }
function Gt(r, e, t) { if (!z0[e])
    throw new Error("Font metrics not found for font: " + e + "."); var a = r.charCodeAt(0), i = z0[e][a]; if (!i && r[0] in hr && (a = hr[r[0]].charCodeAt(0), i = z0[e][a]), !i && t === "text" && Xr(a) && (i = z0[e][77]), i)
    return { depth: i[0], height: i[1], italic: i[2], skew: i[3], width: i[4] }; }
var it = {};
function Ta(r) { var e; if (r >= 5 ? e = 0 : r >= 3 ? e = 1 : e = 2, !it[e]) {
    var t = it[e] = { cssEmPerMu: Ae.quad[e] / 18 };
    for (var a in Ae)
        Ae.hasOwnProperty(a) && (t[a] = Ae[a][e]);
} return it[e]; }
var W = { math: {}, text: {} };
function n(r, e, t, a, i, s) { W[r][i] = { font: e, group: t, replace: a }, s && a && (W[r][a] = W[r][i]); }
var l = "math", w = "text", o = "main", d = "ams", j = "accent-token", D = "bin", o0 = "close", ne = "inner", E = "mathord", t0 = "op-token", f0 = "open", ge = "punct", f = "rel", R0 = "spacing", g = "textord";
n(l, o, f, "\u2261", "\\equiv", !0);
n(l, o, f, "\u227A", "\\prec", !0);
n(l, o, f, "\u227B", "\\succ", !0);
n(l, o, f, "\u223C", "\\sim", !0);
n(l, o, f, "\u22A5", "\\perp");
n(l, o, f, "\u2AAF", "\\preceq", !0);
n(l, o, f, "\u2AB0", "\\succeq", !0);
n(l, o, f, "\u2243", "\\simeq", !0);
n(l, o, f, "\u2223", "\\mid", !0);
n(l, o, f, "\u226A", "\\ll", !0);
n(l, o, f, "\u226B", "\\gg", !0);
n(l, o, f, "\u224D", "\\asymp", !0);
n(l, o, f, "\u2225", "\\parallel");
n(l, o, f, "\u22C8", "\\bowtie", !0);
n(l, o, f, "\u2323", "\\smile", !0);
n(l, o, f, "\u2291", "\\sqsubseteq", !0);
n(l, o, f, "\u2292", "\\sqsupseteq", !0);
n(l, o, f, "\u2250", "\\doteq", !0);
n(l, o, f, "\u2322", "\\frown", !0);
n(l, o, f, "\u220B", "\\ni", !0);
n(l, o, f, "\u221D", "\\propto", !0);
n(l, o, f, "\u22A2", "\\vdash", !0);
n(l, o, f, "\u22A3", "\\dashv", !0);
n(l, o, f, "\u220B", "\\owns");
n(l, o, ge, ".", "\\ldotp");
n(l, o, ge, "\u22C5", "\\cdotp");
n(l, o, ge, "\u22C5", "\xB7");
n(w, o, g, "\u22C5", "\xB7");
n(l, o, g, "#", "\\#");
n(w, o, g, "#", "\\#");
n(l, o, g, "&", "\\&");
n(w, o, g, "&", "\\&");
n(l, o, g, "\u2135", "\\aleph", !0);
n(l, o, g, "\u2200", "\\forall", !0);
n(l, o, g, "\u210F", "\\hbar", !0);
n(l, o, g, "\u2203", "\\exists", !0);
n(l, o, g, "\u2207", "\\nabla", !0);
n(l, o, g, "\u266D", "\\flat", !0);
n(l, o, g, "\u2113", "\\ell", !0);
n(l, o, g, "\u266E", "\\natural", !0);
n(l, o, g, "\u2663", "\\clubsuit", !0);
n(l, o, g, "\u2118", "\\wp", !0);
n(l, o, g, "\u266F", "\\sharp", !0);
n(l, o, g, "\u2662", "\\diamondsuit", !0);
n(l, o, g, "\u211C", "\\Re", !0);
n(l, o, g, "\u2661", "\\heartsuit", !0);
n(l, o, g, "\u2111", "\\Im", !0);
n(l, o, g, "\u2660", "\\spadesuit", !0);
n(l, o, g, "\xA7", "\\S", !0);
n(w, o, g, "\xA7", "\\S");
n(l, o, g, "\xB6", "\\P", !0);
n(w, o, g, "\xB6", "\\P");
n(l, o, g, "\u2020", "\\dag");
n(w, o, g, "\u2020", "\\dag");
n(w, o, g, "\u2020", "\\textdagger");
n(l, o, g, "\u2021", "\\ddag");
n(w, o, g, "\u2021", "\\ddag");
n(w, o, g, "\u2021", "\\textdaggerdbl");
n(l, o, o0, "\u23B1", "\\rmoustache", !0);
n(l, o, f0, "\u23B0", "\\lmoustache", !0);
n(l, o, o0, "\u27EF", "\\rgroup", !0);
n(l, o, f0, "\u27EE", "\\lgroup", !0);
n(l, o, D, "\u2213", "\\mp", !0);
n(l, o, D, "\u2296", "\\ominus", !0);
n(l, o, D, "\u228E", "\\uplus", !0);
n(l, o, D, "\u2293", "\\sqcap", !0);
n(l, o, D, "\u2217", "\\ast");
n(l, o, D, "\u2294", "\\sqcup", !0);
n(l, o, D, "\u25EF", "\\bigcirc", !0);
n(l, o, D, "\u2219", "\\bullet", !0);
n(l, o, D, "\u2021", "\\ddagger");
n(l, o, D, "\u2240", "\\wr", !0);
n(l, o, D, "\u2A3F", "\\amalg");
n(l, o, D, "&", "\\And");
n(l, o, f, "\u27F5", "\\longleftarrow", !0);
n(l, o, f, "\u21D0", "\\Leftarrow", !0);
n(l, o, f, "\u27F8", "\\Longleftarrow", !0);
n(l, o, f, "\u27F6", "\\longrightarrow", !0);
n(l, o, f, "\u21D2", "\\Rightarrow", !0);
n(l, o, f, "\u27F9", "\\Longrightarrow", !0);
n(l, o, f, "\u2194", "\\leftrightarrow", !0);
n(l, o, f, "\u27F7", "\\longleftrightarrow", !0);
n(l, o, f, "\u21D4", "\\Leftrightarrow", !0);
n(l, o, f, "\u27FA", "\\Longleftrightarrow", !0);
n(l, o, f, "\u21A6", "\\mapsto", !0);
n(l, o, f, "\u27FC", "\\longmapsto", !0);
n(l, o, f, "\u2197", "\\nearrow", !0);
n(l, o, f, "\u21A9", "\\hookleftarrow", !0);
n(l, o, f, "\u21AA", "\\hookrightarrow", !0);
n(l, o, f, "\u2198", "\\searrow", !0);
n(l, o, f, "\u21BC", "\\leftharpoonup", !0);
n(l, o, f, "\u21C0", "\\rightharpoonup", !0);
n(l, o, f, "\u2199", "\\swarrow", !0);
n(l, o, f, "\u21BD", "\\leftharpoondown", !0);
n(l, o, f, "\u21C1", "\\rightharpoondown", !0);
n(l, o, f, "\u2196", "\\nwarrow", !0);
n(l, o, f, "\u21CC", "\\rightleftharpoons", !0);
n(l, d, f, "\u226E", "\\nless", !0);
n(l, d, f, "\uE010", "\\@nleqslant");
n(l, d, f, "\uE011", "\\@nleqq");
n(l, d, f, "\u2A87", "\\lneq", !0);
n(l, d, f, "\u2268", "\\lneqq", !0);
n(l, d, f, "\uE00C", "\\@lvertneqq");
n(l, d, f, "\u22E6", "\\lnsim", !0);
n(l, d, f, "\u2A89", "\\lnapprox", !0);
n(l, d, f, "\u2280", "\\nprec", !0);
n(l, d, f, "\u22E0", "\\npreceq", !0);
n(l, d, f, "\u22E8", "\\precnsim", !0);
n(l, d, f, "\u2AB9", "\\precnapprox", !0);
n(l, d, f, "\u2241", "\\nsim", !0);
n(l, d, f, "\uE006", "\\@nshortmid");
n(l, d, f, "\u2224", "\\nmid", !0);
n(l, d, f, "\u22AC", "\\nvdash", !0);
n(l, d, f, "\u22AD", "\\nvDash", !0);
n(l, d, f, "\u22EA", "\\ntriangleleft");
n(l, d, f, "\u22EC", "\\ntrianglelefteq", !0);
n(l, d, f, "\u228A", "\\subsetneq", !0);
n(l, d, f, "\uE01A", "\\@varsubsetneq");
n(l, d, f, "\u2ACB", "\\subsetneqq", !0);
n(l, d, f, "\uE017", "\\@varsubsetneqq");
n(l, d, f, "\u226F", "\\ngtr", !0);
n(l, d, f, "\uE00F", "\\@ngeqslant");
n(l, d, f, "\uE00E", "\\@ngeqq");
n(l, d, f, "\u2A88", "\\gneq", !0);
n(l, d, f, "\u2269", "\\gneqq", !0);
n(l, d, f, "\uE00D", "\\@gvertneqq");
n(l, d, f, "\u22E7", "\\gnsim", !0);
n(l, d, f, "\u2A8A", "\\gnapprox", !0);
n(l, d, f, "\u2281", "\\nsucc", !0);
n(l, d, f, "\u22E1", "\\nsucceq", !0);
n(l, d, f, "\u22E9", "\\succnsim", !0);
n(l, d, f, "\u2ABA", "\\succnapprox", !0);
n(l, d, f, "\u2246", "\\ncong", !0);
n(l, d, f, "\uE007", "\\@nshortparallel");
n(l, d, f, "\u2226", "\\nparallel", !0);
n(l, d, f, "\u22AF", "\\nVDash", !0);
n(l, d, f, "\u22EB", "\\ntriangleright");
n(l, d, f, "\u22ED", "\\ntrianglerighteq", !0);
n(l, d, f, "\uE018", "\\@nsupseteqq");
n(l, d, f, "\u228B", "\\supsetneq", !0);
n(l, d, f, "\uE01B", "\\@varsupsetneq");
n(l, d, f, "\u2ACC", "\\supsetneqq", !0);
n(l, d, f, "\uE019", "\\@varsupsetneqq");
n(l, d, f, "\u22AE", "\\nVdash", !0);
n(l, d, f, "\u2AB5", "\\precneqq", !0);
n(l, d, f, "\u2AB6", "\\succneqq", !0);
n(l, d, f, "\uE016", "\\@nsubseteqq");
n(l, d, D, "\u22B4", "\\unlhd");
n(l, d, D, "\u22B5", "\\unrhd");
n(l, d, f, "\u219A", "\\nleftarrow", !0);
n(l, d, f, "\u219B", "\\nrightarrow", !0);
n(l, d, f, "\u21CD", "\\nLeftarrow", !0);
n(l, d, f, "\u21CF", "\\nRightarrow", !0);
n(l, d, f, "\u21AE", "\\nleftrightarrow", !0);
n(l, d, f, "\u21CE", "\\nLeftrightarrow", !0);
n(l, d, f, "\u25B3", "\\vartriangle");
n(l, d, g, "\u210F", "\\hslash");
n(l, d, g, "\u25BD", "\\triangledown");
n(l, d, g, "\u25CA", "\\lozenge");
n(l, d, g, "\u24C8", "\\circledS");
n(l, d, g, "\xAE", "\\circledR");
n(w, d, g, "\xAE", "\\circledR");
n(l, d, g, "\u2221", "\\measuredangle", !0);
n(l, d, g, "\u2204", "\\nexists");
n(l, d, g, "\u2127", "\\mho");
n(l, d, g, "\u2132", "\\Finv", !0);
n(l, d, g, "\u2141", "\\Game", !0);
n(l, d, g, "\u2035", "\\backprime");
n(l, d, g, "\u25B2", "\\blacktriangle");
n(l, d, g, "\u25BC", "\\blacktriangledown");
n(l, d, g, "\u25A0", "\\blacksquare");
n(l, d, g, "\u29EB", "\\blacklozenge");
n(l, d, g, "\u2605", "\\bigstar");
n(l, d, g, "\u2222", "\\sphericalangle", !0);
n(l, d, g, "\u2201", "\\complement", !0);
n(l, d, g, "\xF0", "\\eth", !0);
n(w, o, g, "\xF0", "\xF0");
n(l, d, g, "\u2571", "\\diagup");
n(l, d, g, "\u2572", "\\diagdown");
n(l, d, g, "\u25A1", "\\square");
n(l, d, g, "\u25A1", "\\Box");
n(l, d, g, "\u25CA", "\\Diamond");
n(l, d, g, "\xA5", "\\yen", !0);
n(w, d, g, "\xA5", "\\yen", !0);
n(l, d, g, "\u2713", "\\checkmark", !0);
n(w, d, g, "\u2713", "\\checkmark");
n(l, d, g, "\u2136", "\\beth", !0);
n(l, d, g, "\u2138", "\\daleth", !0);
n(l, d, g, "\u2137", "\\gimel", !0);
n(l, d, g, "\u03DD", "\\digamma", !0);
n(l, d, g, "\u03F0", "\\varkappa");
n(l, d, f0, "\u250C", "\\@ulcorner", !0);
n(l, d, o0, "\u2510", "\\@urcorner", !0);
n(l, d, f0, "\u2514", "\\@llcorner", !0);
n(l, d, o0, "\u2518", "\\@lrcorner", !0);
n(l, d, f, "\u2266", "\\leqq", !0);
n(l, d, f, "\u2A7D", "\\leqslant", !0);
n(l, d, f, "\u2A95", "\\eqslantless", !0);
n(l, d, f, "\u2272", "\\lesssim", !0);
n(l, d, f, "\u2A85", "\\lessapprox", !0);
n(l, d, f, "\u224A", "\\approxeq", !0);
n(l, d, D, "\u22D6", "\\lessdot");
n(l, d, f, "\u22D8", "\\lll", !0);
n(l, d, f, "\u2276", "\\lessgtr", !0);
n(l, d, f, "\u22DA", "\\lesseqgtr", !0);
n(l, d, f, "\u2A8B", "\\lesseqqgtr", !0);
n(l, d, f, "\u2251", "\\doteqdot");
n(l, d, f, "\u2253", "\\risingdotseq", !0);
n(l, d, f, "\u2252", "\\fallingdotseq", !0);
n(l, d, f, "\u223D", "\\backsim", !0);
n(l, d, f, "\u22CD", "\\backsimeq", !0);
n(l, d, f, "\u2AC5", "\\subseteqq", !0);
n(l, d, f, "\u22D0", "\\Subset", !0);
n(l, d, f, "\u228F", "\\sqsubset", !0);
n(l, d, f, "\u227C", "\\preccurlyeq", !0);
n(l, d, f, "\u22DE", "\\curlyeqprec", !0);
n(l, d, f, "\u227E", "\\precsim", !0);
n(l, d, f, "\u2AB7", "\\precapprox", !0);
n(l, d, f, "\u22B2", "\\vartriangleleft");
n(l, d, f, "\u22B4", "\\trianglelefteq");
n(l, d, f, "\u22A8", "\\vDash", !0);
n(l, d, f, "\u22AA", "\\Vvdash", !0);
n(l, d, f, "\u2323", "\\smallsmile");
n(l, d, f, "\u2322", "\\smallfrown");
n(l, d, f, "\u224F", "\\bumpeq", !0);
n(l, d, f, "\u224E", "\\Bumpeq", !0);
n(l, d, f, "\u2267", "\\geqq", !0);
n(l, d, f, "\u2A7E", "\\geqslant", !0);
n(l, d, f, "\u2A96", "\\eqslantgtr", !0);
n(l, d, f, "\u2273", "\\gtrsim", !0);
n(l, d, f, "\u2A86", "\\gtrapprox", !0);
n(l, d, D, "\u22D7", "\\gtrdot");
n(l, d, f, "\u22D9", "\\ggg", !0);
n(l, d, f, "\u2277", "\\gtrless", !0);
n(l, d, f, "\u22DB", "\\gtreqless", !0);
n(l, d, f, "\u2A8C", "\\gtreqqless", !0);
n(l, d, f, "\u2256", "\\eqcirc", !0);
n(l, d, f, "\u2257", "\\circeq", !0);
n(l, d, f, "\u225C", "\\triangleq", !0);
n(l, d, f, "\u223C", "\\thicksim");
n(l, d, f, "\u2248", "\\thickapprox");
n(l, d, f, "\u2AC6", "\\supseteqq", !0);
n(l, d, f, "\u22D1", "\\Supset", !0);
n(l, d, f, "\u2290", "\\sqsupset", !0);
n(l, d, f, "\u227D", "\\succcurlyeq", !0);
n(l, d, f, "\u22DF", "\\curlyeqsucc", !0);
n(l, d, f, "\u227F", "\\succsim", !0);
n(l, d, f, "\u2AB8", "\\succapprox", !0);
n(l, d, f, "\u22B3", "\\vartriangleright");
n(l, d, f, "\u22B5", "\\trianglerighteq");
n(l, d, f, "\u22A9", "\\Vdash", !0);
n(l, d, f, "\u2223", "\\shortmid");
n(l, d, f, "\u2225", "\\shortparallel");
n(l, d, f, "\u226C", "\\between", !0);
n(l, d, f, "\u22D4", "\\pitchfork", !0);
n(l, d, f, "\u221D", "\\varpropto");
n(l, d, f, "\u25C0", "\\blacktriangleleft");
n(l, d, f, "\u2234", "\\therefore", !0);
n(l, d, f, "\u220D", "\\backepsilon");
n(l, d, f, "\u25B6", "\\blacktriangleright");
n(l, d, f, "\u2235", "\\because", !0);
n(l, d, f, "\u22D8", "\\llless");
n(l, d, f, "\u22D9", "\\gggtr");
n(l, d, D, "\u22B2", "\\lhd");
n(l, d, D, "\u22B3", "\\rhd");
n(l, d, f, "\u2242", "\\eqsim", !0);
n(l, o, f, "\u22C8", "\\Join");
n(l, d, f, "\u2251", "\\Doteq", !0);
n(l, d, D, "\u2214", "\\dotplus", !0);
n(l, d, D, "\u2216", "\\smallsetminus");
n(l, d, D, "\u22D2", "\\Cap", !0);
n(l, d, D, "\u22D3", "\\Cup", !0);
n(l, d, D, "\u2A5E", "\\doublebarwedge", !0);
n(l, d, D, "\u229F", "\\boxminus", !0);
n(l, d, D, "\u229E", "\\boxplus", !0);
n(l, d, D, "\u22C7", "\\divideontimes", !0);
n(l, d, D, "\u22C9", "\\ltimes", !0);
n(l, d, D, "\u22CA", "\\rtimes", !0);
n(l, d, D, "\u22CB", "\\leftthreetimes", !0);
n(l, d, D, "\u22CC", "\\rightthreetimes", !0);
n(l, d, D, "\u22CF", "\\curlywedge", !0);
n(l, d, D, "\u22CE", "\\curlyvee", !0);
n(l, d, D, "\u229D", "\\circleddash", !0);
n(l, d, D, "\u229B", "\\circledast", !0);
n(l, d, D, "\u22C5", "\\centerdot");
n(l, d, D, "\u22BA", "\\intercal", !0);
n(l, d, D, "\u22D2", "\\doublecap");
n(l, d, D, "\u22D3", "\\doublecup");
n(l, d, D, "\u22A0", "\\boxtimes", !0);
n(l, d, f, "\u21E2", "\\dashrightarrow", !0);
n(l, d, f, "\u21E0", "\\dashleftarrow", !0);
n(l, d, f, "\u21C7", "\\leftleftarrows", !0);
n(l, d, f, "\u21C6", "\\leftrightarrows", !0);
n(l, d, f, "\u21DA", "\\Lleftarrow", !0);
n(l, d, f, "\u219E", "\\twoheadleftarrow", !0);
n(l, d, f, "\u21A2", "\\leftarrowtail", !0);
n(l, d, f, "\u21AB", "\\looparrowleft", !0);
n(l, d, f, "\u21CB", "\\leftrightharpoons", !0);
n(l, d, f, "\u21B6", "\\curvearrowleft", !0);
n(l, d, f, "\u21BA", "\\circlearrowleft", !0);
n(l, d, f, "\u21B0", "\\Lsh", !0);
n(l, d, f, "\u21C8", "\\upuparrows", !0);
n(l, d, f, "\u21BF", "\\upharpoonleft", !0);
n(l, d, f, "\u21C3", "\\downharpoonleft", !0);
n(l, o, f, "\u22B6", "\\origof", !0);
n(l, o, f, "\u22B7", "\\imageof", !0);
n(l, d, f, "\u22B8", "\\multimap", !0);
n(l, d, f, "\u21AD", "\\leftrightsquigarrow", !0);
n(l, d, f, "\u21C9", "\\rightrightarrows", !0);
n(l, d, f, "\u21C4", "\\rightleftarrows", !0);
n(l, d, f, "\u21A0", "\\twoheadrightarrow", !0);
n(l, d, f, "\u21A3", "\\rightarrowtail", !0);
n(l, d, f, "\u21AC", "\\looparrowright", !0);
n(l, d, f, "\u21B7", "\\curvearrowright", !0);
n(l, d, f, "\u21BB", "\\circlearrowright", !0);
n(l, d, f, "\u21B1", "\\Rsh", !0);
n(l, d, f, "\u21CA", "\\downdownarrows", !0);
n(l, d, f, "\u21BE", "\\upharpoonright", !0);
n(l, d, f, "\u21C2", "\\downharpoonright", !0);
n(l, d, f, "\u21DD", "\\rightsquigarrow", !0);
n(l, d, f, "\u21DD", "\\leadsto");
n(l, d, f, "\u21DB", "\\Rrightarrow", !0);
n(l, d, f, "\u21BE", "\\restriction");
n(l, o, g, "\u2018", "`");
n(l, o, g, "$", "\\$");
n(w, o, g, "$", "\\$");
n(w, o, g, "$", "\\textdollar");
n(l, o, g, "%", "\\%");
n(w, o, g, "%", "\\%");
n(l, o, g, "_", "\\_");
n(w, o, g, "_", "\\_");
n(w, o, g, "_", "\\textunderscore");
n(l, o, g, "\u2220", "\\angle", !0);
n(l, o, g, "\u221E", "\\infty", !0);
n(l, o, g, "\u2032", "\\prime");
n(l, o, g, "\u25B3", "\\triangle");
n(l, o, g, "\u0393", "\\Gamma", !0);
n(l, o, g, "\u0394", "\\Delta", !0);
n(l, o, g, "\u0398", "\\Theta", !0);
n(l, o, g, "\u039B", "\\Lambda", !0);
n(l, o, g, "\u039E", "\\Xi", !0);
n(l, o, g, "\u03A0", "\\Pi", !0);
n(l, o, g, "\u03A3", "\\Sigma", !0);
n(l, o, g, "\u03A5", "\\Upsilon", !0);
n(l, o, g, "\u03A6", "\\Phi", !0);
n(l, o, g, "\u03A8", "\\Psi", !0);
n(l, o, g, "\u03A9", "\\Omega", !0);
n(l, o, g, "A", "\u0391");
n(l, o, g, "B", "\u0392");
n(l, o, g, "E", "\u0395");
n(l, o, g, "Z", "\u0396");
n(l, o, g, "H", "\u0397");
n(l, o, g, "I", "\u0399");
n(l, o, g, "K", "\u039A");
n(l, o, g, "M", "\u039C");
n(l, o, g, "N", "\u039D");
n(l, o, g, "O", "\u039F");
n(l, o, g, "P", "\u03A1");
n(l, o, g, "T", "\u03A4");
n(l, o, g, "X", "\u03A7");
n(l, o, g, "\xAC", "\\neg", !0);
n(l, o, g, "\xAC", "\\lnot");
n(l, o, g, "\u22A4", "\\top");
n(l, o, g, "\u22A5", "\\bot");
n(l, o, g, "\u2205", "\\emptyset");
n(l, d, g, "\u2205", "\\varnothing");
n(l, o, E, "\u03B1", "\\alpha", !0);
n(l, o, E, "\u03B2", "\\beta", !0);
n(l, o, E, "\u03B3", "\\gamma", !0);
n(l, o, E, "\u03B4", "\\delta", !0);
n(l, o, E, "\u03F5", "\\epsilon", !0);
n(l, o, E, "\u03B6", "\\zeta", !0);
n(l, o, E, "\u03B7", "\\eta", !0);
n(l, o, E, "\u03B8", "\\theta", !0);
n(l, o, E, "\u03B9", "\\iota", !0);
n(l, o, E, "\u03BA", "\\kappa", !0);
n(l, o, E, "\u03BB", "\\lambda", !0);
n(l, o, E, "\u03BC", "\\mu", !0);
n(l, o, E, "\u03BD", "\\nu", !0);
n(l, o, E, "\u03BE", "\\xi", !0);
n(l, o, E, "\u03BF", "\\omicron", !0);
n(l, o, E, "\u03C0", "\\pi", !0);
n(l, o, E, "\u03C1", "\\rho", !0);
n(l, o, E, "\u03C3", "\\sigma", !0);
n(l, o, E, "\u03C4", "\\tau", !0);
n(l, o, E, "\u03C5", "\\upsilon", !0);
n(l, o, E, "\u03D5", "\\phi", !0);
n(l, o, E, "\u03C7", "\\chi", !0);
n(l, o, E, "\u03C8", "\\psi", !0);
n(l, o, E, "\u03C9", "\\omega", !0);
n(l, o, E, "\u03B5", "\\varepsilon", !0);
n(l, o, E, "\u03D1", "\\vartheta", !0);
n(l, o, E, "\u03D6", "\\varpi", !0);
n(l, o, E, "\u03F1", "\\varrho", !0);
n(l, o, E, "\u03C2", "\\varsigma", !0);
n(l, o, E, "\u03C6", "\\varphi", !0);
n(l, o, D, "\u2217", "*", !0);
n(l, o, D, "+", "+");
n(l, o, D, "\u2212", "-", !0);
n(l, o, D, "\u22C5", "\\cdot", !0);
n(l, o, D, "\u2218", "\\circ", !0);
n(l, o, D, "\xF7", "\\div", !0);
n(l, o, D, "\xB1", "\\pm", !0);
n(l, o, D, "\xD7", "\\times", !0);
n(l, o, D, "\u2229", "\\cap", !0);
n(l, o, D, "\u222A", "\\cup", !0);
n(l, o, D, "\u2216", "\\setminus", !0);
n(l, o, D, "\u2227", "\\land");
n(l, o, D, "\u2228", "\\lor");
n(l, o, D, "\u2227", "\\wedge", !0);
n(l, o, D, "\u2228", "\\vee", !0);
n(l, o, g, "\u221A", "\\surd");
n(l, o, f0, "\u27E8", "\\langle", !0);
n(l, o, f0, "\u2223", "\\lvert");
n(l, o, f0, "\u2225", "\\lVert");
n(l, o, o0, "?", "?");
n(l, o, o0, "!", "!");
n(l, o, o0, "\u27E9", "\\rangle", !0);
n(l, o, o0, "\u2223", "\\rvert");
n(l, o, o0, "\u2225", "\\rVert");
n(l, o, f, "=", "=");
n(l, o, f, ":", ":");
n(l, o, f, "\u2248", "\\approx", !0);
n(l, o, f, "\u2245", "\\cong", !0);
n(l, o, f, "\u2265", "\\ge");
n(l, o, f, "\u2265", "\\geq", !0);
n(l, o, f, "\u2190", "\\gets");
n(l, o, f, ">", "\\gt", !0);
n(l, o, f, "\u2208", "\\in", !0);
n(l, o, f, "\uE020", "\\@not");
n(l, o, f, "\u2282", "\\subset", !0);
n(l, o, f, "\u2283", "\\supset", !0);
n(l, o, f, "\u2286", "\\subseteq", !0);
n(l, o, f, "\u2287", "\\supseteq", !0);
n(l, d, f, "\u2288", "\\nsubseteq", !0);
n(l, d, f, "\u2289", "\\nsupseteq", !0);
n(l, o, f, "\u22A8", "\\models");
n(l, o, f, "\u2190", "\\leftarrow", !0);
n(l, o, f, "\u2264", "\\le");
n(l, o, f, "\u2264", "\\leq", !0);
n(l, o, f, "<", "\\lt", !0);
n(l, o, f, "\u2192", "\\rightarrow", !0);
n(l, o, f, "\u2192", "\\to");
n(l, d, f, "\u2271", "\\ngeq", !0);
n(l, d, f, "\u2270", "\\nleq", !0);
n(l, o, R0, "\xA0", "\\ ");
n(l, o, R0, "\xA0", "\\space");
n(l, o, R0, "\xA0", "\\nobreakspace");
n(w, o, R0, "\xA0", "\\ ");
n(w, o, R0, "\xA0", " ");
n(w, o, R0, "\xA0", "\\space");
n(w, o, R0, "\xA0", "\\nobreakspace");
n(l, o, R0, "", "\\nobreak");
n(l, o, R0, "", "\\allowbreak");
n(l, o, ge, ",", ",");
n(l, o, ge, ";", ";");
n(l, d, D, "\u22BC", "\\barwedge", !0);
n(l, d, D, "\u22BB", "\\veebar", !0);
n(l, o, D, "\u2299", "\\odot", !0);
n(l, o, D, "\u2295", "\\oplus", !0);
n(l, o, D, "\u2297", "\\otimes", !0);
n(l, o, g, "\u2202", "\\partial", !0);
n(l, o, D, "\u2298", "\\oslash", !0);
n(l, d, D, "\u229A", "\\circledcirc", !0);
n(l, d, D, "\u22A1", "\\boxdot", !0);
n(l, o, D, "\u25B3", "\\bigtriangleup");
n(l, o, D, "\u25BD", "\\bigtriangledown");
n(l, o, D, "\u2020", "\\dagger");
n(l, o, D, "\u22C4", "\\diamond");
n(l, o, D, "\u22C6", "\\star");
n(l, o, D, "\u25C3", "\\triangleleft");
n(l, o, D, "\u25B9", "\\triangleright");
n(l, o, f0, "{", "\\{");
n(w, o, g, "{", "\\{");
n(w, o, g, "{", "\\textbraceleft");
n(l, o, o0, "}", "\\}");
n(w, o, g, "}", "\\}");
n(w, o, g, "}", "\\textbraceright");
n(l, o, f0, "{", "\\lbrace");
n(l, o, o0, "}", "\\rbrace");
n(l, o, f0, "[", "\\lbrack", !0);
n(w, o, g, "[", "\\lbrack", !0);
n(l, o, o0, "]", "\\rbrack", !0);
n(w, o, g, "]", "\\rbrack", !0);
n(l, o, f0, "(", "\\lparen", !0);
n(l, o, o0, ")", "\\rparen", !0);
n(w, o, g, "<", "\\textless", !0);
n(w, o, g, ">", "\\textgreater", !0);
n(l, o, f0, "\u230A", "\\lfloor", !0);
n(l, o, o0, "\u230B", "\\rfloor", !0);
n(l, o, f0, "\u2308", "\\lceil", !0);
n(l, o, o0, "\u2309", "\\rceil", !0);
n(l, o, g, "\\", "\\backslash");
n(l, o, g, "\u2223", "|");
n(l, o, g, "\u2223", "\\vert");
n(w, o, g, "|", "\\textbar", !0);
n(l, o, g, "\u2225", "\\|");
n(l, o, g, "\u2225", "\\Vert");
n(w, o, g, "\u2225", "\\textbardbl");
n(w, o, g, "~", "\\textasciitilde");
n(w, o, g, "\\", "\\textbackslash");
n(w, o, g, "^", "\\textasciicircum");
n(l, o, f, "\u2191", "\\uparrow", !0);
n(l, o, f, "\u21D1", "\\Uparrow", !0);
n(l, o, f, "\u2193", "\\downarrow", !0);
n(l, o, f, "\u21D3", "\\Downarrow", !0);
n(l, o, f, "\u2195", "\\updownarrow", !0);
n(l, o, f, "\u21D5", "\\Updownarrow", !0);
n(l, o, t0, "\u2210", "\\coprod");
n(l, o, t0, "\u22C1", "\\bigvee");
n(l, o, t0, "\u22C0", "\\bigwedge");
n(l, o, t0, "\u2A04", "\\biguplus");
n(l, o, t0, "\u22C2", "\\bigcap");
n(l, o, t0, "\u22C3", "\\bigcup");
n(l, o, t0, "\u222B", "\\int");
n(l, o, t0, "\u222B", "\\intop");
n(l, o, t0, "\u222C", "\\iint");
n(l, o, t0, "\u222D", "\\iiint");
n(l, o, t0, "\u220F", "\\prod");
n(l, o, t0, "\u2211", "\\sum");
n(l, o, t0, "\u2A02", "\\bigotimes");
n(l, o, t0, "\u2A01", "\\bigoplus");
n(l, o, t0, "\u2A00", "\\bigodot");
n(l, o, t0, "\u222E", "\\oint");
n(l, o, t0, "\u222F", "\\oiint");
n(l, o, t0, "\u2230", "\\oiiint");
n(l, o, t0, "\u2A06", "\\bigsqcup");
n(l, o, t0, "\u222B", "\\smallint");
n(w, o, ne, "\u2026", "\\textellipsis");
n(l, o, ne, "\u2026", "\\mathellipsis");
n(w, o, ne, "\u2026", "\\ldots", !0);
n(l, o, ne, "\u2026", "\\ldots", !0);
n(l, o, ne, "\u22EF", "\\@cdots", !0);
n(l, o, ne, "\u22F1", "\\ddots", !0);
n(l, o, g, "\u22EE", "\\varvdots");
n(w, o, g, "\u22EE", "\\varvdots");
n(l, o, j, "\u02CA", "\\acute");
n(l, o, j, "\u02CB", "\\grave");
n(l, o, j, "\xA8", "\\ddot");
n(l, o, j, "~", "\\tilde");
n(l, o, j, "\u02C9", "\\bar");
n(l, o, j, "\u02D8", "\\breve");
n(l, o, j, "\u02C7", "\\check");
n(l, o, j, "^", "\\hat");
n(l, o, j, "\u20D7", "\\vec");
n(l, o, j, "\u02D9", "\\dot");
n(l, o, j, "\u02DA", "\\mathring");
n(l, o, E, "\uE131", "\\@imath");
n(l, o, E, "\uE237", "\\@jmath");
n(l, o, g, "\u0131", "\u0131");
n(l, o, g, "\u0237", "\u0237");
n(w, o, g, "\u0131", "\\i", !0);
n(w, o, g, "\u0237", "\\j", !0);
n(w, o, g, "\xDF", "\\ss", !0);
n(w, o, g, "\xE6", "\\ae", !0);
n(w, o, g, "\u0153", "\\oe", !0);
n(w, o, g, "\xF8", "\\o", !0);
n(w, o, g, "\xC6", "\\AE", !0);
n(w, o, g, "\u0152", "\\OE", !0);
n(w, o, g, "\xD8", "\\O", !0);
n(w, o, j, "\u02CA", "\\'");
n(w, o, j, "\u02CB", "\\`");
n(w, o, j, "\u02C6", "\\^");
n(w, o, j, "\u02DC", "\\~");
n(w, o, j, "\u02C9", "\\=");
n(w, o, j, "\u02D8", "\\u");
n(w, o, j, "\u02D9", "\\.");
n(w, o, j, "\xB8", "\\c");
n(w, o, j, "\u02DA", "\\r");
n(w, o, j, "\u02C7", "\\v");
n(w, o, j, "\xA8", '\\"');
n(w, o, j, "\u02DD", "\\H");
n(w, o, j, "\u25EF", "\\textcircled");
var Zr = { "--": !0, "---": !0, "``": !0, "''": !0 };
n(w, o, g, "\u2013", "--", !0);
n(w, o, g, "\u2013", "\\textendash");
n(w, o, g, "\u2014", "---", !0);
n(w, o, g, "\u2014", "\\textemdash");
n(w, o, g, "\u2018", "`", !0);
n(w, o, g, "\u2018", "\\textquoteleft");
n(w, o, g, "\u2019", "'", !0);
n(w, o, g, "\u2019", "\\textquoteright");
n(w, o, g, "\u201C", "``", !0);
n(w, o, g, "\u201C", "\\textquotedblleft");
n(w, o, g, "\u201D", "''", !0);
n(w, o, g, "\u201D", "\\textquotedblright");
n(l, o, g, "\xB0", "\\degree", !0);
n(w, o, g, "\xB0", "\\degree");
n(w, o, g, "\xB0", "\\textdegree", !0);
n(l, o, g, "\xA3", "\\pounds");
n(l, o, g, "\xA3", "\\mathsterling", !0);
n(w, o, g, "\xA3", "\\pounds");
n(w, o, g, "\xA3", "\\textsterling", !0);
n(l, d, g, "\u2720", "\\maltese");
n(w, d, g, "\u2720", "\\maltese");
var mr = '0123456789/@."';
for (Me = 0; Me < mr.length; Me++)
    nt = mr.charAt(Me), n(l, o, g, nt, nt);
var nt, Me, cr = '0123456789!@*()-=+";:?/.,';
for (Te = 0; Te < cr.length; Te++)
    st = cr.charAt(Te), n(w, o, g, st, st);
var st, Te, He = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
for (Be = 0; Be < He.length; Be++)
    oe = He.charAt(Be), n(l, o, E, oe, oe), n(w, o, g, oe, oe);
var oe, Be;
n(l, d, g, "C", "\u2102");
n(w, d, g, "C", "\u2102");
n(l, d, g, "H", "\u210D");
n(w, d, g, "H", "\u210D");
n(l, d, g, "N", "\u2115");
n(w, d, g, "N", "\u2115");
n(l, d, g, "P", "\u2119");
n(w, d, g, "P", "\u2119");
n(l, d, g, "Q", "\u211A");
n(w, d, g, "Q", "\u211A");
n(l, d, g, "R", "\u211D");
n(w, d, g, "R", "\u211D");
n(l, d, g, "Z", "\u2124");
n(w, d, g, "Z", "\u2124");
n(l, o, E, "h", "\u210E");
n(w, o, E, "h", "\u210E");
var I;
for (i0 = 0; i0 < He.length; i0++)
    Z = He.charAt(i0), I = String.fromCharCode(55349, 56320 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56372 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56424 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56580 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56684 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56736 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56788 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56840 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56944 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), i0 < 26 && (I = String.fromCharCode(55349, 56632 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I), I = String.fromCharCode(55349, 56476 + i0), n(l, o, E, Z, I), n(w, o, g, Z, I));
var Z, i0;
I = "\u{1D55C}";
n(l, o, E, "k", I);
n(w, o, g, "k", I);
for (H0 = 0; H0 < 10; H0++)
    C0 = H0.toString(), I = String.fromCharCode(55349, 57294 + H0), n(l, o, E, C0, I), n(w, o, g, C0, I), I = String.fromCharCode(55349, 57314 + H0), n(l, o, E, C0, I), n(w, o, g, C0, I), I = String.fromCharCode(55349, 57324 + H0), n(l, o, E, C0, I), n(w, o, g, C0, I), I = String.fromCharCode(55349, 57334 + H0), n(l, o, E, C0, I), n(w, o, g, C0, I);
var C0, H0, kt = "\xD0\xDE\xFE";
for (Ce = 0; Ce < kt.length; Ce++)
    he = kt.charAt(Ce), n(l, o, E, he, he), n(w, o, g, he, he);
var he, Ce, St = { mathClass: "mathbf", textClass: "textbf", font: "Main-Bold" }, dr = { mathClass: "mathnormal", textClass: "textit", font: "Math-Italic" }, fr = { mathClass: "boldsymbol", textClass: "boldsymbol", font: "Main-BoldItalic" }, Ba = { mathClass: "mathscr", textClass: "textscr", font: "Script-Regular" }, W0 = { mathClass: "", textClass: "", font: "" }, vr = { mathClass: "mathfrak", textClass: "textfrak", font: "Fraktur-Regular" }, pr = { mathClass: "mathbb", textClass: "textbb", font: "AMS-Regular" }, gr = { mathClass: "mathboldfrak", textClass: "textboldfrak", font: "Fraktur-Regular" }, zt = { mathClass: "mathsf", textClass: "textsf", font: "SansSerif-Regular" }, At = { mathClass: "mathboldsf", textClass: "textboldsf", font: "SansSerif-Bold" }, br = { mathClass: "mathitsf", textClass: "textitsf", font: "SansSerif-Italic" }, Mt = { mathClass: "mathtt", textClass: "texttt", font: "Typewriter-Regular" }, yr = [St, St, dr, dr, fr, fr, Ba, W0, W0, W0, vr, vr, pr, pr, gr, gr, zt, zt, At, At, br, br, W0, W0, Mt, Mt], Ca = [St, W0, zt, At, Mt], Da = r => { var e = r.charCodeAt(0), t = r.charCodeAt(1), a = (e - 55296) * 1024 + (t - 56320) + 65536; if (119808 <= a && a < 120484) {
    var i = Math.floor((a - 119808) / 26);
    return yr[i];
}
else if (120782 <= a && a <= 120831) {
    var s = Math.floor((a - 120782) / 10);
    return Ca[s];
}
else {
    if (a === 120485 || a === 120486)
        return yr[0];
    if (120486 < a && a < 120782)
        return W0;
    throw new z("Unsupported character: " + r);
} }, Ye = function (e, t, a) { if (W[a][e]) {
    var i = W[a][e].replace;
    i && (e = i);
} return { value: e, metrics: Gt(e, t, a) }; }, s0 = function (e, t, a, i, s) { var u = Ye(e, t, a), h = u.metrics; e = u.value; var c; if (h) {
    var v = h.italic;
    (a === "text" || i && i.font === "mathit") && (v = 0), c = new u0(e, h.height, h.depth, v, h.skew, h.width, s);
}
else
    typeof console < "u" && console.warn("No character metrics " + ("for '" + e + "' in style '" + t + "' and mode '" + a + "'")), c = new u0(e, 0, 0, 0, 0, 0, s); if (i) {
    c.maxFontSize = i.sizeMultiplier, i.style.isTight() && c.classes.push("mtight");
    var p = i.getColor();
    p && (c.style.color = p);
} return c; }, Ut = function (e, t, a, i) { return i === void 0 && (i = []), a.font === "boldsymbol" && Ye(e, "Main-Bold", t).metrics ? s0(e, "Main-Bold", t, a, i.concat(["mathbf"])) : e === "\\" || W[t][e].font === "main" ? s0(e, "Main-Regular", t, a, i) : s0(e, "AMS-Regular", t, a, i.concat(["amsrm"])); }, qa = function (e, t, a) { return a !== "textord" && Ye(e, "Math-BoldItalic", t).metrics ? { fontName: "Math-BoldItalic", fontClass: "boldsymbol" } : { fontName: "Main-Bold", fontClass: "mathbf" }; }, $e = function (e, t, a) { var i = e.mode, s = e.text, u = ["mord"], { font: h, fontFamily: c, fontWeight: v, fontShape: p } = t, b = i === "math" || i === "text" && !!h, x = b ? h : c, y = "", T = ""; if (s.charCodeAt(0) === 55349) {
    var M = Da(s);
    y = M.font, T = M[i + "Class"];
} if (y)
    return s0(s, y, i, t, u.concat(T)); if (x) {
    var q, C;
    if (x === "boldsymbol") {
        var R = qa(s, i, a);
        q = R.fontName, C = [R.fontClass];
    }
    else
        b ? (q = Tt[h].fontName, C = [h]) : (q = De(c, v, p), C = [c, v, p]);
    if (Ye(s, q, i).metrics)
        return s0(s, q, i, t, u.concat(C));
    if (Zr.hasOwnProperty(s) && q.slice(0, 10) === "Typewriter") {
        for (var F = [], L = 0; L < s.length; L++)
            F.push(s0(s[L], q, i, t, u.concat(C)));
        return I0(F);
    }
} if (a === "mathord")
    return s0(s, "Math-Italic", i, t, u.concat(["mathnormal"])); if (a === "textord") {
    var H = W[i][s] && W[i][s].font;
    if (H === "ams") {
        var P = De("amsrm", v, p);
        return s0(s, P, i, t, u.concat("amsrm", v, p));
    }
    else if (H === "main" || !H) {
        var G = De("textrm", v, p);
        return s0(s, G, i, t, u.concat(v, p));
    }
    else {
        var Y = De(H, v, p);
        return s0(s, Y, i, t, u.concat(Y, v, p));
    }
}
else
    throw new Error("unexpected type: " + a + " in makeOrd"); }, Ea = (r, e) => { if (G0(r.classes) !== G0(e.classes) || r.skew !== e.skew || r.maxFontSize !== e.maxFontSize || r.italic !== 0 && r.hasClass("mathnormal"))
    return !1; if (r.classes.length === 1) {
    var t = r.classes[0];
    if (t === "mbin" || t === "mord")
        return !1;
} for (var a of Object.keys(r.style))
    if (r.style[a] !== e.style[a])
        return !1; for (var i of Object.keys(e.style))
    if (r.style[i] !== e.style[i])
        return !1; return !0; }, Kr = r => { for (var e = 0; e < r.length - 1; e++) {
    var t = r[e], a = r[e + 1];
    t instanceof u0 && a instanceof u0 && Ea(t, a) && (t.text += a.text, t.height = Math.max(t.height, a.height), t.depth = Math.max(t.depth, a.depth), t.italic = a.italic, r.splice(e + 1, 1), e--);
} return r; }, Vt = function (e) { for (var t = 0, a = 0, i = 0, s = 0; s < e.children.length; s++) {
    var u = e.children[s];
    u.height > t && (t = u.height), u.depth > a && (a = u.depth), u.maxFontSize > i && (i = u.maxFontSize);
} e.height = t, e.depth = a, e.maxFontSize = i; }, k = function (e, t, a, i) { var s = new U0(e, t, a, i); return Vt(s), s; }, V0 = (r, e, t, a) => new U0(r, e, t, a), ae = function (e, t, a) { var i = k([e], [], t); return i.height = Math.max(a || t.fontMetrics().defaultRuleThickness, t.minRuleThickness), i.style.borderBottomWidth = A(i.height), i.maxFontSize = 1, i; }, Ra = function (e, t, a, i) { var s = new re(e, t, a, i); return Vt(s), s; }, I0 = function (e) { var t = new P0(e); return Vt(t), t; }, ie = function (e, t) { return e instanceof P0 ? k([], [e], t) : e; }, Ia = function (e) { if (e.positionType === "individualShift") {
    for (var t = e.children, a = [t[0]], i = -t[0].shift - t[0].elem.depth, s = i, u = 1; u < t.length; u++) {
        var h = -t[u].shift - s - t[u].elem.depth, c = h - (t[u - 1].elem.height + t[u - 1].elem.depth);
        s = s + h, a.push({ type: "kern", size: c }), a.push(t[u]);
    }
    return { children: a, depth: i };
} var v; if (e.positionType === "top") {
    for (var p = e.positionData, b = 0; b < e.children.length; b++) {
        var x = e.children[b];
        p -= x.type === "kern" ? x.size : x.elem.height + x.elem.depth;
    }
    v = p;
}
else if (e.positionType === "bottom")
    v = -e.positionData;
else {
    var y = e.children[0];
    if (y.type !== "elem")
        throw new Error('First child must have type "elem".');
    if (e.positionType === "shift")
        v = -y.elem.depth - e.positionData;
    else if (e.positionType === "firstBaseline")
        v = -y.elem.depth;
    else
        throw new Error("Invalid positionType " + e.positionType + ".");
} return { children: e.children, depth: v }; }, V = function (e, t) { for (var { children: a, depth: i } = Ia(e), s = 0, u = 0; u < a.length; u++) {
    var h = a[u];
    if (h.type === "elem") {
        var c = h.elem;
        s = Math.max(s, c.maxFontSize, c.height);
    }
} s += 2; var v = k(["pstrut"], []); v.style.height = A(s); for (var p = [], b = i, x = i, y = i, T = 0; T < a.length; T++) {
    var M = a[T];
    if (M.type === "kern")
        y += M.size;
    else {
        var q = M.elem, C = M.wrapperClasses || [], R = M.wrapperStyle || {}, F = k(C, [v, q], void 0, R);
        F.style.top = A(-s - y - q.depth), M.marginLeft && (F.style.marginLeft = M.marginLeft), M.marginRight && (F.style.marginRight = M.marginRight), p.push(F), y += q.height + q.depth;
    }
    b = Math.min(b, y), x = Math.max(x, y);
} var L = k(["vlist"], p); L.style.height = A(x); var H; if (b < 0) {
    var P = k([], []), G = k(["vlist"], [P]);
    G.style.height = A(-b);
    var Y = k(["vlist-s"], [new u0("\u200B")]);
    H = [k(["vlist-r"], [L, Y]), k(["vlist-r"], [G])];
}
else
    H = [k(["vlist-r"], [L])]; var U = k(["vlist-t"], H); return H.length === 2 && U.classes.push("vlist-t2"), U.height = x, U.depth = -b, U; }, Jr = (r, e) => { var t = k(["mspace"], [], e), a = J(r, e); return t.style.marginRight = A(a), t; }, De = (r, e, t) => { var a, i; switch (r) {
    case "amsrm":
        a = "AMS";
        break;
    case "textrm":
        a = "Main";
        break;
    case "textsf":
        a = "SansSerif";
        break;
    case "texttt":
        a = "Typewriter";
        break;
    default: a = r;
} return e === "textbf" && t === "textit" ? i = "BoldItalic" : e === "textbf" ? i = "Bold" : t === "textit" ? i = "Italic" : i = "Regular", a + "-" + i; }, Tt = { mathbf: { variant: "bold", fontName: "Main-Bold" }, mathrm: { variant: "normal", fontName: "Main-Regular" }, textit: { variant: "italic", fontName: "Main-Italic" }, mathit: { variant: "italic", fontName: "Main-Italic" }, mathnormal: { variant: "italic", fontName: "Math-Italic" }, mathsfit: { variant: "sans-serif-italic", fontName: "SansSerif-Italic" }, mathbb: { variant: "double-struck", fontName: "AMS-Regular" }, mathcal: { variant: "script", fontName: "Caligraphic-Regular" }, mathfrak: { variant: "fraktur", fontName: "Fraktur-Regular" }, mathscr: { variant: "script", fontName: "Script-Regular" }, mathsf: { variant: "sans-serif", fontName: "SansSerif-Regular" }, mathtt: { variant: "monospace", fontName: "Typewriter-Regular" } }, Qr = { vec: ["vec", .471, .714], oiintSize1: ["oiintSize1", .957, .499], oiintSize2: ["oiintSize2", 1.472, .659], oiiintSize1: ["oiiintSize1", 1.304, .499], oiiintSize2: ["oiiintSize2", 1.98, .659] }, _r = function (e, t) { var [a, i, s] = Qr[e], u = new A0(a), h = new x0([u], { width: A(i), height: A(s), style: "width:" + A(i), viewBox: "0 0 " + 1e3 * i + " " + 1e3 * s, preserveAspectRatio: "xMinYMin" }), c = V0(["overlay"], [h], t); return c.height = s, c.style.height = A(s), c.style.width = A(i), c; }, K = { number: 3, unit: "mu" }, $0 = { number: 4, unit: "mu" }, D0 = { number: 5, unit: "mu" }, Na = { mord: { mop: K, mbin: $0, mrel: D0, minner: K }, mop: { mord: K, mop: K, mrel: D0, minner: K }, mbin: { mord: $0, mop: $0, mopen: $0, minner: $0 }, mrel: { mord: D0, mop: D0, mopen: D0, minner: D0 }, mopen: {}, mclose: { mop: K, mbin: $0, mrel: D0, minner: K }, mpunct: { mord: K, mop: K, mrel: D0, mopen: K, mclose: K, mpunct: K, minner: K }, minner: { mord: K, mop: K, mbin: $0, mrel: D0, mopen: K, mpunct: K, minner: K } }, Fa = { mord: { mop: K }, mop: { mord: K, mop: K }, mbin: {}, mrel: {}, mopen: {}, mclose: { mop: K }, mpunct: {}, minner: { mop: K } }, e1 = {}, Le = {}, Pe = {};
function B(r) { for (var { type: e, names: t, props: a, handler: i, htmlBuilder: s, mathmlBuilder: u } = r, h = { type: e, numArgs: a.numArgs, argTypes: a.argTypes, allowedInArgument: !!a.allowedInArgument, allowedInText: !!a.allowedInText, allowedInMath: a.allowedInMath === void 0 ? !0 : a.allowedInMath, numOptionalArgs: a.numOptionalArgs || 0, infix: !!a.infix, primitive: !!a.primitive, handler: i }, c = 0; c < t.length; ++c)
    e1[t[c]] = h; e && (s && (Le[e] = s), u && (Pe[e] = u)); }
function j0(r) { var { type: e, htmlBuilder: t, mathmlBuilder: a } = r; B({ type: e, names: [], props: { numArgs: 0 }, handler() { throw new Error("Should never be called."); }, htmlBuilder: t, mathmlBuilder: a }); }
var Ge = function (e) { return e.type === "ordgroup" && e.body.length === 1 ? e.body[0] : e; }, e0 = function (e) { return e.type === "ordgroup" ? e.body : [e]; }, Oa = new Set(["leftmost", "mbin", "mopen", "mrel", "mop", "mpunct"]), Ha = new Set(["rightmost", "mrel", "mclose", "mpunct"]), La = { display: N.DISPLAY, text: N.TEXT, script: N.SCRIPT, scriptscript: N.SCRIPTSCRIPT }, Pa = { mord: "mord", mop: "mop", mbin: "mbin", mrel: "mrel", mopen: "mopen", mclose: "mclose", mpunct: "mpunct", minner: "minner" }, a0 = function (e, t, a, i) { i === void 0 && (i = [null, null]); for (var s = [], u = 0; u < e.length; u++) {
    var h = X(e[u], t);
    if (h instanceof P0) {
        var c = h.children;
        s.push(...c);
    }
    else
        s.push(h);
} if (Kr(s), !a)
    return s; var v = t; if (e.length === 1) {
    var p = e[0];
    p.type === "sizing" ? v = t.havingSize(p.size) : p.type === "styling" && (v = t.havingStyle(La[p.style]));
} var b = k([i[0] || "leftmost"], [], t), x = k([i[1] || "rightmost"], [], t), y = a === "root"; return Bt(s, (T, M) => { var q = M.classes[0], C = T.classes[0]; q === "mbin" && Ha.has(C) ? M.classes[0] = "mord" : C === "mbin" && Oa.has(q) && (T.classes[0] = "mord"); }, { node: b }, x, y), Bt(s, (T, M) => { var q, C, R = Dt(M), F = Dt(T), L = R && F ? T.hasClass("mtight") ? (q = Fa[R]) == null ? void 0 : q[F] : (C = Na[R]) == null ? void 0 : C[F] : null; if (L)
    return Jr(L, v); }, { node: b }, x, y), s; }, Bt = function (e, t, a, i, s) { i && e.push(i); for (var u = 0; u < e.length; u++) {
    var h = e[u], c = t1(h);
    if (c) {
        Bt(c.children, t, a, null, s);
        continue;
    }
    var v = !h.hasClass("mspace");
    if (v) {
        var p = t(h, a.node);
        p && (a.insertAfter ? a.insertAfter(p) : (e.unshift(p), u++));
    }
    v ? a.node = h : s && h.hasClass("newline") && (a.node = k(["leftmost"])), a.insertAfter = (b => x => { e.splice(b + 1, 0, x), u++; })(u);
} i && e.pop(); }, t1 = function (e) { return e instanceof P0 || e instanceof re || e instanceof U0 && e.hasClass("enclosing") ? e : null; }, Ct = function (e, t) { var a = t1(e); if (a) {
    var i = a.children;
    if (i.length) {
        if (t === "right")
            return Ct(i[i.length - 1], "right");
        if (t === "left")
            return Ct(i[0], "left");
    }
} return e; }, Dt = function (e, t) { if (!e)
    return null; t && (e = Ct(e, t)); var a = e.classes[0]; return Pa[a] || null; }, pe = function (e, t) { var a = ["nulldelimiter"].concat(e.baseSizingClasses()); return k(t.concat(a)); }, X = function (e, t, a) { if (!e)
    return k(); if (Le[e.type]) {
    var i = Le[e.type](e, t);
    if (a && t.size !== a.size) {
        i = k(t.sizingClasses(a), [i], t);
        var s = t.sizeMultiplier / a.sizeMultiplier;
        i.height *= s, i.depth *= s;
    }
    return i;
}
else
    throw new z("Got group of unknown type: '" + e.type + "'"); };
function qe(r, e) { var t = k(["base"], r, e), a = k(["strut"]); return a.style.height = A(t.height + t.depth), t.depth && (a.style.verticalAlign = A(-t.depth)), t.children.unshift(a), t; }
function qt(r, e) { var t = null; r.length === 1 && r[0].type === "tag" && (t = r[0].tag, r = r[0].body); var a = a0(r, e, "root"), i; a.length === 2 && a[1].hasClass("tag") && (i = a.pop()); for (var s = [], u = [], h = 0; h < a.length; h++)
    if (u.push(a[h]), a[h].hasClass("mbin") || a[h].hasClass("mrel") || a[h].hasClass("allowbreak")) {
        for (var c = !1; h < a.length - 1 && a[h + 1].hasClass("mspace") && !a[h + 1].hasClass("newline");)
            h++, u.push(a[h]), a[h].hasClass("nobreak") && (c = !0);
        c || (s.push(qe(u, e)), u = []);
    }
    else
        a[h].hasClass("newline") && (u.pop(), u.length > 0 && (s.push(qe(u, e)), u = []), s.push(a[h])); u.length > 0 && s.push(qe(u, e)); var v; t ? (v = qe(a0(t, e, !0), e), v.classes = ["tag"], s.push(v)) : i && s.push(i); var p = k(["katex-html"], s); if (p.setAttribute("aria-hidden", "true"), v) {
    var b = v.children[0];
    b.style.height = A(p.height + p.depth), p.depth && (b.style.verticalAlign = A(-p.depth));
} return p; }
function r1(r) { return new P0(r); }
var S = class {
    constructor(e, t, a) { this.type = void 0, this.attributes = void 0, this.children = void 0, this.classes = void 0, this.type = e, this.attributes = {}, this.children = t || [], this.classes = a || []; }
    setAttribute(e, t) { this.attributes[e] = t; }
    getAttribute(e) { return this.attributes[e]; }
    toNode() { var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", this.type); for (var t in this.attributes)
        Object.prototype.hasOwnProperty.call(this.attributes, t) && e.setAttribute(t, this.attributes[t]); this.classes.length > 0 && (e.className = G0(this.classes)); for (var a = 0; a < this.children.length; a++)
        if (this.children[a] instanceof Q && this.children[a + 1] instanceof Q) {
            for (var i = this.children[a].toText() + this.children[++a].toText(); this.children[a + 1] instanceof Q;)
                i += this.children[++a].toText();
            e.appendChild(new Q(i).toNode());
        }
        else
            e.appendChild(this.children[a].toNode()); return e; }
    toMarkup() { var e = "<" + this.type; for (var t in this.attributes)
        Object.prototype.hasOwnProperty.call(this.attributes, t) && (e += " " + t + '="', e += n0(this.attributes[t]), e += '"'); this.classes.length > 0 && (e += ' class ="' + n0(G0(this.classes)) + '"'), e += ">"; for (var a = 0; a < this.children.length; a++)
        e += this.children[a].toMarkup(); return e += "</" + this.type + ">", e; }
    toText() { return this.children.map(e => e.toText()).join(""); }
}, Q = class {
    constructor(e) { this.text = void 0, this.text = e; }
    toNode() { return document.createTextNode(this.text); }
    toMarkup() { return n0(this.toText()); }
    toText() { return this.text; }
}, Ue = class {
    constructor(e) { this.width = void 0, this.character = void 0, this.width = e, e >= .05555 && e <= .05556 ? this.character = "\u200A" : e >= .1666 && e <= .1667 ? this.character = "\u2009" : e >= .2222 && e <= .2223 ? this.character = "\u2005" : e >= .2777 && e <= .2778 ? this.character = "\u2005\u200A" : e >= -.05556 && e <= -.05555 ? this.character = "\u200A\u2063" : e >= -.1667 && e <= -.1666 ? this.character = "\u2009\u2063" : e >= -.2223 && e <= -.2222 ? this.character = "\u205F\u2063" : e >= -.2778 && e <= -.2777 ? this.character = "\u2005\u2063" : this.character = null; }
    toNode() { if (this.character)
        return document.createTextNode(this.character); var e = document.createElementNS("http://www.w3.org/1998/Math/MathML", "mspace"); return e.setAttribute("width", A(this.width)), e; }
    toMarkup() { return this.character ? "<mtext>" + this.character + "</mtext>" : '<mspace width="' + A(this.width) + '"/>'; }
    toText() { return this.character ? this.character : " "; }
}, Ga = new Set(["\\imath", "\\jmath"]), Ua = new Set(["mrow", "mtable"]), g0 = function (e, t, a) { return W[t][e] && W[t][e].replace && e.charCodeAt(0) !== 55349 && !(Zr.hasOwnProperty(e) && a && (a.fontFamily && a.fontFamily.slice(4, 6) === "tt" || a.font && a.font.slice(4, 6) === "tt")) && (e = W[t][e].replace), new Q(e); }, Xt = function (e) { return e.length === 1 ? e[0] : new S("mrow", e); }, Va = { mathit: "italic", boldsymbol: r => r.type === "textord" ? "bold" : "bold-italic", mathbf: "bold", mathbb: "double-struck", mathsfit: "sans-serif-italic", mathfrak: "fraktur", mathscr: "script", mathcal: "script", mathsf: "sans-serif", mathtt: "monospace" }, Yt = (r, e) => { if (r.mode === "text") {
    if (e.fontFamily === "texttt")
        return "monospace";
    if (e.fontFamily === "textsf")
        return e.fontShape === "textit" && e.fontWeight === "textbf" ? "sans-serif-bold-italic" : e.fontShape === "textit" ? "sans-serif-italic" : e.fontWeight === "textbf" ? "bold-sans-serif" : "sans-serif";
    if (e.fontShape === "textit" && e.fontWeight === "textbf")
        return "bold-italic";
    if (e.fontShape === "textit")
        return "italic";
    if (e.fontWeight === "textbf")
        return "bold";
} var t = e.font; if (!t || t === "mathnormal")
    return null; var a = r.mode, i = Va[t]; if (i)
    return typeof i == "function" ? i(r) : i; var s = r.text; if (Ga.has(s))
    return null; if (W[a][s]) {
    var u = W[a][s].replace;
    u && (s = u);
} var h = Tt[t].fontName; return Gt(s, h, a) ? Tt[t].variant : null; };
function lt(r) { if (!r)
    return !1; if (r.type === "mi" && r.children.length === 1) {
    var e = r.children[0];
    return e instanceof Q && e.text === ".";
}
else if (r.type === "mo" && r.children.length === 1 && r.getAttribute("separator") === "true" && r.getAttribute("lspace") === "0em" && r.getAttribute("rspace") === "0em") {
    var t = r.children[0];
    return t instanceof Q && t.text === ",";
}
else
    return !1; }
var v0 = function (e, t, a) { if (e.length === 1) {
    var i = $(e[0], t);
    return a && i instanceof S && i.type === "mo" && (i.setAttribute("lspace", "0em"), i.setAttribute("rspace", "0em")), [i];
} for (var s = [], u, h = 0; h < e.length; h++) {
    var c = $(e[h], t);
    if (c instanceof S && u instanceof S) {
        if (c.type === "mtext" && u.type === "mtext" && c.getAttribute("mathvariant") === u.getAttribute("mathvariant")) {
            u.children.push(...c.children);
            continue;
        }
        else if (c.type === "mn" && u.type === "mn") {
            u.children.push(...c.children);
            continue;
        }
        else if (lt(c) && u.type === "mn") {
            u.children.push(...c.children);
            continue;
        }
        else if (c.type === "mn" && lt(u))
            c.children = [...u.children, ...c.children], s.pop();
        else if ((c.type === "msup" || c.type === "msub") && c.children.length >= 1 && (u.type === "mn" || lt(u))) {
            var v = c.children[0];
            v instanceof S && v.type === "mn" && (v.children = [...u.children, ...v.children], s.pop());
        }
        else if (u.type === "mi" && u.children.length === 1) {
            var p = u.children[0];
            if (p instanceof Q && p.text === "\u0338" && (c.type === "mo" || c.type === "mi" || c.type === "mn")) {
                var b = c.children[0];
                b instanceof Q && b.text.length > 0 && (b.text = b.text.slice(0, 1) + "\u0338" + b.text.slice(1), s.pop());
            }
        }
    }
    s.push(c), u = c;
} return s; }, X0 = function (e, t, a) { return Xt(v0(e, t, a)); }, $ = function (e, t) { if (!e)
    return new S("mrow"); if (Pe[e.type])
    return Pe[e.type](e, t); throw new z("Got group of unknown type: '" + e.type + "'"); };
function xr(r, e, t, a, i) { var s = v0(r, t), u; s.length === 1 && s[0] instanceof S && Ua.has(s[0].type) ? u = s[0] : u = new S("mrow", s); var h = new S("annotation", [new Q(e)]); h.setAttribute("encoding", "application/x-tex"); var c = new S("semantics", [u, h]), v = new S("math", [c]); v.setAttribute("xmlns", "http://www.w3.org/1998/Math/MathML"), a && v.setAttribute("display", "block"); var p = i ? "katex" : "katex-mathml"; return k([p], [v]); }
var Xa = [[1, 1, 1], [2, 1, 1], [3, 1, 1], [4, 2, 1], [5, 2, 1], [6, 3, 1], [7, 4, 2], [8, 6, 3], [9, 7, 6], [10, 8, 7], [11, 10, 9]], wr = [.5, .6, .7, .8, .9, 1, 1.2, 1.44, 1.728, 2.074, 2.488], kr = function (e, t) { return t.size < 2 ? e : Xa[e - 1][t.size - 1]; }, Ya = (() => { class r {
    constructor(t) { this.style = void 0, this.color = void 0, this.size = void 0, this.textSize = void 0, this.phantom = void 0, this.font = void 0, this.fontFamily = void 0, this.fontWeight = void 0, this.fontShape = void 0, this.sizeMultiplier = void 0, this.maxSize = void 0, this.minRuleThickness = void 0, this._fontMetrics = void 0, this.style = t.style, this.color = t.color, this.size = t.size || r.BASESIZE, this.textSize = t.textSize || this.size, this.phantom = !!t.phantom, this.font = t.font || "", this.fontFamily = t.fontFamily || "", this.fontWeight = t.fontWeight || "", this.fontShape = t.fontShape || "", this.sizeMultiplier = wr[this.size - 1], this.maxSize = t.maxSize, this.minRuleThickness = t.minRuleThickness, this._fontMetrics = void 0; }
    extend(t) { var a = { style: this.style, size: this.size, textSize: this.textSize, color: this.color, phantom: this.phantom, font: this.font, fontFamily: this.fontFamily, fontWeight: this.fontWeight, fontShape: this.fontShape, maxSize: this.maxSize, minRuleThickness: this.minRuleThickness }; return Object.assign(a, t), new r(a); }
    havingStyle(t) { return this.style === t ? this : this.extend({ style: t, size: kr(this.textSize, t) }); }
    havingCrampedStyle() { return this.havingStyle(this.style.cramp()); }
    havingSize(t) { return this.size === t && this.textSize === t ? this : this.extend({ style: this.style.text(), size: t, textSize: t, sizeMultiplier: wr[t - 1] }); }
    havingBaseStyle(t) { t = t || this.style.text(); var a = kr(r.BASESIZE, t); return this.size === a && this.textSize === r.BASESIZE && this.style === t ? this : this.extend({ style: t, size: a }); }
    havingBaseSizing() { var t; switch (this.style.id) {
        case 4:
        case 5:
            t = 3;
            break;
        case 6:
        case 7:
            t = 1;
            break;
        default: t = 6;
    } return this.extend({ style: this.style.text(), size: t }); }
    withColor(t) { return this.extend({ color: t }); }
    withPhantom() { return this.extend({ phantom: !0 }); }
    withFont(t) { return this.extend({ font: t }); }
    withTextFontFamily(t) { return this.extend({ fontFamily: t, font: "" }); }
    withTextFontWeight(t) { return this.extend({ fontWeight: t, font: "" }); }
    withTextFontShape(t) { return this.extend({ fontShape: t, font: "" }); }
    sizingClasses(t) { return t.size !== this.size ? ["sizing", "reset-size" + t.size, "size" + this.size] : []; }
    baseSizingClasses() { return this.size !== r.BASESIZE ? ["sizing", "reset-size" + this.size, "size" + r.BASESIZE] : []; }
    fontMetrics() { return this._fontMetrics || (this._fontMetrics = Ta(this.size)), this._fontMetrics; }
    getColor() { return this.phantom ? "transparent" : this.color; }
} return r.BASESIZE = 6, r; })(), a1 = function (e) { return new Ya({ style: e.displayMode ? N.DISPLAY : N.TEXT, maxSize: e.maxSize, minRuleThickness: e.minRuleThickness }); }, i1 = function (e, t) { if (t.displayMode) {
    var a = ["katex-display"];
    t.leqno && a.push("leqno"), t.fleqn && a.push("fleqn"), e = k(a, [e]);
} return e; }, $a = function (e, t, a) { var i = a1(a), s; if (a.output === "mathml")
    return xr(e, t, i, a.displayMode, !0); if (a.output === "html") {
    var u = qt(e, i);
    s = k(["katex"], [u]);
}
else {
    var h = xr(e, t, i, a.displayMode, !1), c = qt(e, i);
    s = k(["katex"], [h, c]);
} return i1(s, a); }, Wa = function (e, t, a) { var i = a1(a), s = qt(e, i), u = k(["katex"], [s]); return i1(u, a); }, ja = { widehat: "^", widecheck: "\u02C7", widetilde: "~", utilde: "~", overleftarrow: "\u2190", underleftarrow: "\u2190", xleftarrow: "\u2190", overrightarrow: "\u2192", underrightarrow: "\u2192", xrightarrow: "\u2192", underbrace: "\u23DF", overbrace: "\u23DE", underbracket: "\u23B5", overbracket: "\u23B4", overgroup: "\u23E0", undergroup: "\u23E1", overleftrightarrow: "\u2194", underleftrightarrow: "\u2194", xleftrightarrow: "\u2194", Overrightarrow: "\u21D2", xRightarrow: "\u21D2", overleftharpoon: "\u21BC", xleftharpoonup: "\u21BC", overrightharpoon: "\u21C0", xrightharpoonup: "\u21C0", xLeftarrow: "\u21D0", xLeftrightarrow: "\u21D4", xhookleftarrow: "\u21A9", xhookrightarrow: "\u21AA", xmapsto: "\u21A6", xrightharpoondown: "\u21C1", xleftharpoondown: "\u21BD", xrightleftharpoons: "\u21CC", xleftrightharpoons: "\u21CB", xtwoheadleftarrow: "\u219E", xtwoheadrightarrow: "\u21A0", xlongequal: "=", xtofrom: "\u21C4", xrightleftarrows: "\u21C4", xrightequilibrium: "\u21CC", xleftequilibrium: "\u21CB", "\\cdrightarrow": "\u2192", "\\cdleftarrow": "\u2190", "\\cdlongequal": "=" }, We = function (e) { var t = new S("mo", [new Q(ja[e.replace(/^\\/, "")])]); return t.setAttribute("stretchy", "true"), t; }, Za = { overrightarrow: [["rightarrow"], .888, 522, "xMaxYMin"], overleftarrow: [["leftarrow"], .888, 522, "xMinYMin"], underrightarrow: [["rightarrow"], .888, 522, "xMaxYMin"], underleftarrow: [["leftarrow"], .888, 522, "xMinYMin"], xrightarrow: [["rightarrow"], 1.469, 522, "xMaxYMin"], "\\cdrightarrow": [["rightarrow"], 3, 522, "xMaxYMin"], xleftarrow: [["leftarrow"], 1.469, 522, "xMinYMin"], "\\cdleftarrow": [["leftarrow"], 3, 522, "xMinYMin"], Overrightarrow: [["doublerightarrow"], .888, 560, "xMaxYMin"], xRightarrow: [["doublerightarrow"], 1.526, 560, "xMaxYMin"], xLeftarrow: [["doubleleftarrow"], 1.526, 560, "xMinYMin"], overleftharpoon: [["leftharpoon"], .888, 522, "xMinYMin"], xleftharpoonup: [["leftharpoon"], .888, 522, "xMinYMin"], xleftharpoondown: [["leftharpoondown"], .888, 522, "xMinYMin"], overrightharpoon: [["rightharpoon"], .888, 522, "xMaxYMin"], xrightharpoonup: [["rightharpoon"], .888, 522, "xMaxYMin"], xrightharpoondown: [["rightharpoondown"], .888, 522, "xMaxYMin"], xlongequal: [["longequal"], .888, 334, "xMinYMin"], "\\cdlongequal": [["longequal"], 3, 334, "xMinYMin"], xtwoheadleftarrow: [["twoheadleftarrow"], .888, 334, "xMinYMin"], xtwoheadrightarrow: [["twoheadrightarrow"], .888, 334, "xMaxYMin"], overleftrightarrow: [["leftarrow", "rightarrow"], .888, 522], overbrace: [["leftbrace", "midbrace", "rightbrace"], 1.6, 548], underbrace: [["leftbraceunder", "midbraceunder", "rightbraceunder"], 1.6, 548], underleftrightarrow: [["leftarrow", "rightarrow"], .888, 522], xleftrightarrow: [["leftarrow", "rightarrow"], 1.75, 522], xLeftrightarrow: [["doubleleftarrow", "doublerightarrow"], 1.75, 560], xrightleftharpoons: [["leftharpoondownplus", "rightharpoonplus"], 1.75, 716], xleftrightharpoons: [["leftharpoonplus", "rightharpoondownplus"], 1.75, 716], xhookleftarrow: [["leftarrow", "righthook"], 1.08, 522], xhookrightarrow: [["lefthook", "rightarrow"], 1.08, 522], overlinesegment: [["leftlinesegment", "rightlinesegment"], .888, 522], underlinesegment: [["leftlinesegment", "rightlinesegment"], .888, 522], overbracket: [["leftbracketover", "rightbracketover"], 1.6, 440], underbracket: [["leftbracketunder", "rightbracketunder"], 1.6, 410], overgroup: [["leftgroup", "rightgroup"], .888, 342], undergroup: [["leftgroupunder", "rightgroupunder"], .888, 342], xmapsto: [["leftmapsto", "rightarrow"], 1.5, 522], xtofrom: [["leftToFrom", "rightToFrom"], 1.75, 528], xrightleftarrows: [["baraboveleftarrow", "rightarrowabovebar"], 1.75, 901], xrightequilibrium: [["baraboveshortleftharpoon", "rightharpoonaboveshortbar"], 1.75, 716], xleftequilibrium: [["shortbaraboveleftharpoon", "shortrightharpoonabovebar"], 1.75, 716] }, Ka = new Set(["widehat", "widecheck", "widetilde", "utilde"]), je = function (e, t) {
    function a() {
        var h = 4e5, c = e.label.slice(1);
        if (Ka.has(c) && "base" in e) {
            var v = e.base.type === "ordgroup" ? e.base.body.length : 1, p, b, x;
            if (v > 5)
                c === "widehat" || c === "widecheck" ? (p = 420, h = 2364, x = .42, b = c + "4") : (p = 312, h = 2340, x = .34, b = "tilde4");
            else {
                var y = [1, 1, 2, 2, 3, 3][v];
                c === "widehat" || c === "widecheck" ? (h = [0, 1062, 2364, 2364, 2364][y], p = [0, 239, 300, 360, 420][y], x = [0, .24, .3, .3, .36, .42][y], b = c + y) : (h = [0, 600, 1033, 2339, 2340][y], p = [0, 260, 286, 306, 312][y], x = [0, .26, .286, .3, .306, .34][y], b = "tilde" + y);
            }
            var T = new A0(b), M = new x0([T], { width: "100%", height: A(x), viewBox: "0 0 " + h + " " + p, preserveAspectRatio: "none" });
            return { span: V0([], [M], t), minWidth: 0, height: x };
        }
        else {
            var q = [], C = Za[c];
            if (!C)
                throw new Error('No SVG data for "' + c + '".');
            var [R, F, L] = C, H = L / 1e3, P = R.length, G, Y;
            if (P === 1) {
                if (C.length !== 4)
                    throw new Error('Expected 4-tuple for single-path SVG data "' + c + '".');
                G = ["hide-tail"], Y = [C[3]];
            }
            else if (P === 2)
                G = ["halfarrow-left", "halfarrow-right"], Y = ["xMinYMin", "xMaxYMin"];
            else if (P === 3)
                G = ["brace-left", "brace-center", "brace-right"], Y = ["xMinYMin", "xMidYMin", "xMaxYMin"];
            else
                throw new Error(`Correct katexImagesData or update code here to support
                    ` + P + " children.");
            for (var U = 0; U < P; U++) {
                var h0 = new A0(R[U]), c0 = new x0([h0], { width: "400em", height: A(H), viewBox: "0 0 " + h + " " + L, preserveAspectRatio: Y[U] + " slice" }), _ = V0([G[U]], [c0], t);
                if (P === 1)
                    return { span: _, minWidth: F, height: H };
                _.style.height = A(H), q.push(_);
            }
            return { span: k(["stretchy"], q, t), minWidth: F, height: H };
        }
    }
    var { span: i, minWidth: s, height: u } = a();
    return i.height = u, i.style.height = A(u), s > 0 && (i.style.minWidth = A(s)), i;
}, Ja = function (e, t, a, i, s) { var u, h = e.height + e.depth + a + i; if (/fbox|color|angl/.test(t)) {
    if (u = k(["stretchy", t], [], s), t === "fbox") {
        var c = s.color && s.getColor();
        c && (u.style.borderColor = c);
    }
}
else {
    var v = [];
    /^[bx]cancel$/.test(t) && v.push(new ve({ x1: "0", y1: "0", x2: "100%", y2: "100%", "stroke-width": "0.046em" })), /^x?cancel$/.test(t) && v.push(new ve({ x1: "0", y1: "100%", x2: "100%", y2: "0", "stroke-width": "0.046em" }));
    var p = new x0(v, { width: "100%", height: A(h) });
    u = V0([], [p], s);
} return u.height = h, u.style.height = A(h), u; }, Qa = { bin: 1, close: 1, inner: 1, open: 1, punct: 1, rel: 1 }, _a = { "accent-token": 1, mathord: 1, "op-token": 1, spacing: 1, textord: 1 };
function e4(r) { return r in Qa; }
function O(r, e) { if (!r || r.type !== e)
    throw new Error("Expected node of type " + e + ", but got " + (r ? "node of type " + r.type : String(r))); return r; }
function Ze(r) { var e = Ke(r); if (!e)
    throw new Error("Expected node of symbol group type, but got " + (r ? "node of type " + r.type : String(r))); return e; }
function Ke(r) { return r && (r.type === "atom" || _a.hasOwnProperty(r.type)) ? r : null; }
var n1 = r => { if (r instanceof u0)
    return r; if (Aa(r) && r.children.length === 1)
    return n1(r.children[0]); }, $t = (r, e) => { var t, a, i; r && r.type === "supsub" ? (a = O(r.base, "accent"), t = a.base, r.base = t, i = za(X(r, e)), r.base = a) : (a = O(r, "accent"), t = a.base); var s = X(t, e.havingCrampedStyle()), u = a.isShifty && E0(t), h = 0; if (u) {
    var c, v;
    h = (c = (v = n1(s)) == null ? void 0 : v.skew) != null ? c : 0;
} var p = a.label === "\\c", b = p ? s.height + s.depth : Math.min(s.height, e.fontMetrics().xHeight), x; if (a.isStretchy)
    x = je(a, e), x = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: s }, { type: "elem", elem: x, wrapperClasses: ["svg-align"], wrapperStyle: h > 0 ? { width: "calc(100% - " + A(2 * h) + ")", marginLeft: A(2 * h) } : void 0 }] });
else {
    var y, T;
    a.label === "\\vec" ? (y = _r("vec", e), T = Qr.vec[1]) : (y = $e({ type: "textord", mode: a.mode, text: a.label }, e, "textord"), y = Sa(y), y.italic = 0, T = y.width, p && (b += y.depth)), x = k(["accent-body"], [y]);
    var M = a.label === "\\textcircled";
    M && (x.classes.push("accent-full"), b = s.height);
    var q = h;
    M || (q -= T / 2), x.style.left = A(q), a.label === "\\textcircled" && (x.style.top = ".2em"), x = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: s }, { type: "kern", size: -b }, { type: "elem", elem: x }] });
} var C = k(["mord", "accent"], [x], e); return i ? (i.children[0] = C, i.height = Math.max(C.height, i.height), i.classes[0] = "mord", i) : C; }, s1 = (r, e) => { var t = r.isStretchy ? We(r.label) : new S("mo", [g0(r.label, r.mode)]), a = new S("mover", [$(r.base, e), t]); return a.setAttribute("accent", "true"), a; }, t4 = new RegExp(["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring"].map(r => "\\" + r).join("|"));
B({ type: "accent", names: ["\\acute", "\\grave", "\\ddot", "\\tilde", "\\bar", "\\breve", "\\check", "\\hat", "\\vec", "\\dot", "\\mathring", "\\widecheck", "\\widehat", "\\widetilde", "\\overrightarrow", "\\overleftarrow", "\\Overrightarrow", "\\overleftrightarrow", "\\overgroup", "\\overlinesegment", "\\overleftharpoon", "\\overrightharpoon"], props: { numArgs: 1 }, handler: (r, e) => { var t = Ge(e[0]), a = !t4.test(r.funcName), i = !a || r.funcName === "\\widehat" || r.funcName === "\\widetilde" || r.funcName === "\\widecheck"; return { type: "accent", mode: r.parser.mode, label: r.funcName, isStretchy: a, isShifty: i, base: t }; }, htmlBuilder: $t, mathmlBuilder: s1 });
B({ type: "accent", names: ["\\'", "\\`", "\\^", "\\~", "\\=", "\\u", "\\.", '\\"', "\\c", "\\r", "\\H", "\\v", "\\textcircled"], props: { numArgs: 1, allowedInText: !0, allowedInMath: !0, argTypes: ["primitive"] }, handler: (r, e) => { var t = e[0], a = r.parser.mode; return a === "math" && (r.parser.settings.reportNonstrict("mathVsTextAccents", "LaTeX's accent " + r.funcName + " works only in text mode"), a = "text"), { type: "accent", mode: a, label: r.funcName, isStretchy: !1, isShifty: !0, base: t }; }, htmlBuilder: $t, mathmlBuilder: s1 });
B({ type: "accentUnder", names: ["\\underleftarrow", "\\underrightarrow", "\\underleftrightarrow", "\\undergroup", "\\underlinesegment", "\\utilde"], props: { numArgs: 1 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = e[0]; return { type: "accentUnder", mode: t.mode, label: a, base: i }; }, htmlBuilder: (r, e) => { var t = X(r.base, e), a = je(r, e), i = r.label === "\\utilde" ? .12 : 0, s = V({ positionType: "top", positionData: t.height, children: [{ type: "elem", elem: a, wrapperClasses: ["svg-align"] }, { type: "kern", size: i }, { type: "elem", elem: t }] }); return k(["mord", "accentunder"], [s], e); }, mathmlBuilder: (r, e) => { var t = We(r.label), a = new S("munder", [$(r.base, e), t]); return a.setAttribute("accentunder", "true"), a; } });
var Ee = r => { var e = new S("mpadded", r ? [r] : []); return e.setAttribute("width", "+0.6em"), e.setAttribute("lspace", "0.3em"), e; };
B({ type: "xArrow", names: ["\\xleftarrow", "\\xrightarrow", "\\xLeftarrow", "\\xRightarrow", "\\xleftrightarrow", "\\xLeftrightarrow", "\\xhookleftarrow", "\\xhookrightarrow", "\\xmapsto", "\\xrightharpoondown", "\\xrightharpoonup", "\\xleftharpoondown", "\\xleftharpoonup", "\\xrightleftharpoons", "\\xleftrightharpoons", "\\xlongequal", "\\xtwoheadrightarrow", "\\xtwoheadleftarrow", "\\xtofrom", "\\xrightleftarrows", "\\xrightequilibrium", "\\xleftequilibrium", "\\\\cdrightarrow", "\\\\cdleftarrow", "\\\\cdlongequal"], props: { numArgs: 1, numOptionalArgs: 1 }, handler(r, e, t) { var { parser: a, funcName: i } = r; return { type: "xArrow", mode: a.mode, label: i, body: e[0], below: t[0] }; }, htmlBuilder(r, e) { var t = e.style, a = e.havingStyle(t.sup()), i = ie(X(r.body, a, e), e), s = r.label.slice(0, 2) === "\\x" ? "x" : "cd"; i.classes.push(s + "-arrow-pad"); var u; r.below && (a = e.havingStyle(t.sub()), u = ie(X(r.below, a, e), e), u.classes.push(s + "-arrow-pad")); var h = je(r, e), c = -e.fontMetrics().axisHeight + .5 * h.height, v = -e.fontMetrics().axisHeight - .5 * h.height - .111; (i.depth > .25 || r.label === "\\xleftequilibrium") && (v -= i.depth); var p; if (u) {
        var b = -e.fontMetrics().axisHeight + u.height + .5 * h.height + .111;
        p = V({ positionType: "individualShift", children: [{ type: "elem", elem: i, shift: v }, { type: "elem", elem: h, shift: c, wrapperClasses: ["svg-align"] }, { type: "elem", elem: u, shift: b }] });
    }
    else
        p = V({ positionType: "individualShift", children: [{ type: "elem", elem: i, shift: v }, { type: "elem", elem: h, shift: c, wrapperClasses: ["svg-align"] }] }); return k(["mrel", "x-arrow"], [p], e); }, mathmlBuilder(r, e) { var t = We(r.label); t.setAttribute("minsize", r.label.charAt(0) === "x" ? "1.75em" : "3.0em"); var a; if (r.body) {
        var i = Ee($(r.body, e));
        if (r.below) {
            var s = Ee($(r.below, e));
            a = new S("munderover", [t, s, i]);
        }
        else
            a = new S("mover", [t, i]);
    }
    else if (r.below) {
        var u = Ee($(r.below, e));
        a = new S("munder", [t, u]);
    }
    else
        a = Ee(), a = new S("mover", [t, a]); return a; } });
function l1(r, e) { var t = a0(r.body, e, !0); return k([r.mclass], t, e); }
function u1(r, e) { var t, a = v0(r.body, e); return r.mclass === "minner" ? t = new S("mpadded", a) : r.mclass === "mord" ? r.isCharacterBox ? (t = a[0], t.type = "mi") : t = new S("mi", a) : (r.isCharacterBox ? (t = a[0], t.type = "mo") : t = new S("mo", a), r.mclass === "mbin" ? (t.attributes.lspace = "0.22em", t.attributes.rspace = "0.22em") : r.mclass === "mpunct" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0.17em") : r.mclass === "mopen" || r.mclass === "mclose" ? (t.attributes.lspace = "0em", t.attributes.rspace = "0em") : r.mclass === "minner" && (t.attributes.lspace = "0.0556em", t.attributes.width = "+0.1111em")), t; }
B({ type: "mclass", names: ["\\mathord", "\\mathbin", "\\mathrel", "\\mathopen", "\\mathclose", "\\mathpunct", "\\mathinner"], props: { numArgs: 1, primitive: !0 }, handler(r, e) { var { parser: t, funcName: a } = r, i = e[0]; return { type: "mclass", mode: t.mode, mclass: "m" + a.slice(5), body: e0(i), isCharacterBox: E0(i) }; }, htmlBuilder: l1, mathmlBuilder: u1 });
var Je = r => { var e = r.type === "ordgroup" && r.body.length ? r.body[0] : r; return e.type === "atom" && (e.family === "bin" || e.family === "rel") ? "m" + e.family : "mord"; };
B({ type: "mclass", names: ["\\@binrel"], props: { numArgs: 2 }, handler(r, e) { var { parser: t } = r; return { type: "mclass", mode: t.mode, mclass: Je(e[0]), body: e0(e[1]), isCharacterBox: E0(e[1]) }; } });
B({ type: "mclass", names: ["\\stackrel", "\\overset", "\\underset"], props: { numArgs: 2 }, handler(r, e) { var { parser: t, funcName: a } = r, i = e[1], s = e[0], u; a !== "\\stackrel" ? u = Je(i) : u = "mrel"; var h = { type: "op", mode: i.mode, limits: !0, alwaysHandleSupSub: !0, parentIsSupSub: !1, symbol: !1, suppressBaseShift: a !== "\\stackrel", body: e0(i) }, c = { type: "supsub", mode: s.mode, base: h, sup: a === "\\underset" ? null : s, sub: a === "\\underset" ? s : null }; return { type: "mclass", mode: t.mode, mclass: u, body: [c], isCharacterBox: E0(c) }; }, htmlBuilder: l1, mathmlBuilder: u1 });
B({ type: "pmb", names: ["\\pmb"], props: { numArgs: 1, allowedInText: !0 }, handler(r, e) { var { parser: t } = r; return { type: "pmb", mode: t.mode, mclass: Je(e[0]), body: e0(e[0]) }; }, htmlBuilder(r, e) { var t = a0(r.body, e, !0), a = k([r.mclass], t, e); return a.style.textShadow = "0.02em 0.01em 0.04px", a; }, mathmlBuilder(r, e) { var t = v0(r.body, e), a = new S("mstyle", t); return a.setAttribute("style", "text-shadow: 0.02em 0.01em 0.04px"), a; } });
var r4 = { ">": "\\\\cdrightarrow", "<": "\\\\cdleftarrow", "=": "\\\\cdlongequal", A: "\\uparrow", V: "\\downarrow", "|": "\\Vert", ".": "no arrow" }, Sr = () => ({ type: "styling", body: [], mode: "math", style: "display", resetFont: !0 }), zr = r => r.type === "textord" && r.text === "@", a4 = (r, e) => (r.type === "mathord" || r.type === "atom") && r.text === e;
function i4(r, e, t) { var a = r4[r]; switch (a) {
    case "\\\\cdrightarrow":
    case "\\\\cdleftarrow": return t.callFunction(a, [e[0]], [e[1]]);
    case "\\uparrow":
    case "\\downarrow": {
        var i = t.callFunction("\\\\cdleft", [e[0]], []), s = { type: "atom", text: a, mode: "math", family: "rel" }, u = t.callFunction("\\Big", [s], []), h = t.callFunction("\\\\cdright", [e[1]], []), c = { type: "ordgroup", mode: "math", body: [i, u, h] };
        return t.callFunction("\\\\cdparent", [c], []);
    }
    case "\\\\cdlongequal": return t.callFunction("\\\\cdlongequal", [], []);
    case "\\Vert": {
        var v = { type: "textord", text: "\\Vert", mode: "math" };
        return t.callFunction("\\Big", [v], []);
    }
    default: return { type: "textord", text: " ", mode: "math" };
} }
function n4(r) { var e = []; for (r.gullet.beginGroup(), r.gullet.macros.set("\\cr", "\\\\\\relax"), r.gullet.beginGroup();;) {
    e.push(r.parseExpression(!1, "\\\\")), r.gullet.endGroup(), r.gullet.beginGroup();
    var t = r.fetch().text;
    if (t === "&" || t === "\\\\")
        r.consume();
    else if (t === "\\end") {
        e[e.length - 1].length === 0 && e.pop();
        break;
    }
    else
        throw new z("Expected \\\\ or \\cr or \\end", r.nextToken);
} for (var a = [], i = [a], s = 0; s < e.length; s++) {
    for (var u = e[s], h = Sr(), c = 0; c < u.length; c++)
        if (!zr(u[c]))
            h.body.push(u[c]);
        else {
            a.push(h), c += 1;
            var v = Ze(u[c]).text, p = new Array(2);
            if (p[0] = { type: "ordgroup", mode: "math", body: [] }, p[1] = { type: "ordgroup", mode: "math", body: [] }, !"=|.".includes(v))
                if ("<>AV".includes(v))
                    for (var b = 0; b < 2; b++) {
                        for (var x = !0, y = c + 1; y < u.length; y++) {
                            if (a4(u[y], v)) {
                                x = !1, c = y;
                                break;
                            }
                            if (zr(u[y]))
                                throw new z("Missing a " + v + " character to complete a CD arrow.", u[y]);
                            p[b].body.push(u[y]);
                        }
                        if (x)
                            throw new z("Missing a " + v + " character to complete a CD arrow.", u[c]);
                    }
                else
                    throw new z('Expected one of "<>AV=|." after @', u[c]);
            var T = i4(v, p, r), M = { type: "styling", body: [T], mode: "math", style: "display", resetFont: !0 };
            a.push(M), h = Sr();
        }
    s % 2 === 0 ? a.push(h) : a.shift(), a = [], i.push(a);
} r.gullet.endGroup(), r.gullet.endGroup(); var q = new Array(i[0].length).fill({ type: "align", align: "c", pregap: .25, postgap: .25 }); return { type: "array", mode: "math", body: i, arraystretch: 1, addJot: !0, rowGaps: [null], cols: q, colSeparationType: "CD", hLinesBeforeRow: new Array(i.length + 1).fill([]) }; }
B({ type: "cdlabel", names: ["\\\\cdleft", "\\\\cdright"], props: { numArgs: 1 }, handler(r, e) { var { parser: t, funcName: a } = r; return { type: "cdlabel", mode: t.mode, side: a.slice(4), label: e[0] }; }, htmlBuilder(r, e) { var t = e.havingStyle(e.style.sup()), a = ie(X(r.label, t, e), e); return a.classes.push("cd-label-" + r.side), a.style.bottom = A(.8 - a.depth), a.height = 0, a.depth = 0, a; }, mathmlBuilder(r, e) { var t = new S("mrow", [$(r.label, e)]); return t = new S("mpadded", [t]), t.setAttribute("width", "0"), r.side === "left" && t.setAttribute("lspace", "-1width"), t.setAttribute("voffset", "0.7em"), t = new S("mstyle", [t]), t.setAttribute("displaystyle", "false"), t.setAttribute("scriptlevel", "1"), t; } });
B({ type: "cdlabelparent", names: ["\\\\cdparent"], props: { numArgs: 1 }, handler(r, e) { var { parser: t } = r; return { type: "cdlabelparent", mode: t.mode, fragment: e[0] }; }, htmlBuilder(r, e) { var t = ie(X(r.fragment, e), e); return t.classes.push("cd-vert-arrow"), t; }, mathmlBuilder(r, e) { return new S("mrow", [$(r.fragment, e)]); } });
B({ type: "textord", names: ["\\@char"], props: { numArgs: 1, allowedInText: !0 }, handler(r, e) { for (var { parser: t } = r, a = O(e[0], "ordgroup"), i = a.body, s = "", u = 0; u < i.length; u++) {
        var h = O(i[u], "textord");
        s += h.text;
    } var c = parseInt(s), v; if (isNaN(c))
        throw new z("\\@char has non-numeric argument " + s); if (c < 0 || c >= 1114111)
        throw new z("\\@char with invalid code point " + s); return c <= 65535 ? v = String.fromCharCode(c) : (c -= 65536, v = String.fromCharCode((c >> 10) + 55296, (c & 1023) + 56320)), { type: "textord", mode: t.mode, text: v }; } });
var o1 = (r, e) => { var t = a0(r.body, e.withColor(r.color), !1); return I0(t); }, h1 = (r, e) => { var t = v0(r.body, e.withColor(r.color)), a = new S("mstyle", t); return a.setAttribute("mathcolor", r.color), a; };
B({ type: "color", names: ["\\textcolor"], props: { numArgs: 2, allowedInText: !0, argTypes: ["color", "original"] }, handler(r, e) { var { parser: t } = r, a = O(e[0], "color-token").color, i = e[1]; return { type: "color", mode: t.mode, color: a, body: e0(i) }; }, htmlBuilder: o1, mathmlBuilder: h1 });
B({ type: "color", names: ["\\color"], props: { numArgs: 1, allowedInText: !0, argTypes: ["color"] }, handler(r, e) { var { parser: t, breakOnTokenText: a } = r, i = O(e[0], "color-token").color; t.gullet.macros.set("\\current@color", i); var s = t.parseExpression(!0, a); return { type: "color", mode: t.mode, color: i, body: s }; }, htmlBuilder: o1, mathmlBuilder: h1 });
B({ type: "cr", names: ["\\\\"], props: { numArgs: 0, numOptionalArgs: 0, allowedInText: !0 }, handler(r, e, t) { var { parser: a } = r, i = a.gullet.future().text === "[" ? a.parseSizeGroup(!0) : null, s = !a.settings.displayMode || !a.settings.useStrictBehavior("newLineInDisplayMode", "In LaTeX, \\\\ or \\newline does nothing in display mode"); return { type: "cr", mode: a.mode, newLine: s, size: i && O(i, "size").value }; }, htmlBuilder(r, e) { var t = k(["mspace"], [], e); return r.newLine && (t.classes.push("newline"), r.size && (t.style.marginTop = A(J(r.size, e)))), t; }, mathmlBuilder(r, e) { var t = new S("mspace"); return r.newLine && (t.setAttribute("linebreak", "newline"), r.size && t.setAttribute("height", A(J(r.size, e)))), t; } });
var Et = { "\\global": "\\global", "\\long": "\\\\globallong", "\\\\globallong": "\\\\globallong", "\\def": "\\gdef", "\\gdef": "\\gdef", "\\edef": "\\xdef", "\\xdef": "\\xdef", "\\let": "\\\\globallet", "\\futurelet": "\\\\globalfuture" }, m1 = r => { var e = r.text; if (/^(?:[\\{}$&#^_]|EOF)$/.test(e))
    throw new z("Expected a control sequence", r); return e; }, s4 = r => { var e = r.gullet.popToken(); return e.text === "=" && (e = r.gullet.popToken(), e.text === " " && (e = r.gullet.popToken())), e; }, c1 = (r, e, t, a) => { var i = r.gullet.macros.get(t.text); i == null && (t.noexpand = !0, i = { tokens: [t], numArgs: 0, unexpandable: !r.gullet.isExpandable(t.text) }), r.gullet.macros.set(e, i, a); };
B({ type: "internal", names: ["\\global", "\\long", "\\\\globallong"], props: { numArgs: 0, allowedInText: !0 }, handler(r) { var { parser: e, funcName: t } = r; e.consumeSpaces(); var a = e.fetch(); if (Et[a.text])
        return (t === "\\global" || t === "\\\\globallong") && (a.text = Et[a.text]), O(e.parseFunction(), "internal"); throw new z("Invalid token after macro prefix", a); } });
B({ type: "internal", names: ["\\def", "\\gdef", "\\edef", "\\xdef"], props: { numArgs: 0, allowedInText: !0, primitive: !0 }, handler(r) { var { parser: e, funcName: t } = r, a = e.gullet.popToken(), i = a.text; if (/^(?:[\\{}$&#^_]|EOF)$/.test(i))
        throw new z("Expected a control sequence", a); for (var s = 0, u, h = [[]]; e.gullet.future().text !== "{";)
        if (a = e.gullet.popToken(), a.text === "#") {
            if (e.gullet.future().text === "{") {
                u = e.gullet.future(), h[s].push("{");
                break;
            }
            if (a = e.gullet.popToken(), !/^[1-9]$/.test(a.text))
                throw new z('Invalid argument number "' + a.text + '"');
            if (parseInt(a.text) !== s + 1)
                throw new z('Argument number "' + a.text + '" out of order');
            s++, h.push([]);
        }
        else {
            if (a.text === "EOF")
                throw new z("Expected a macro definition");
            h[s].push(a.text);
        } var { tokens: c } = e.gullet.consumeArg(); return u && c.unshift(u), (t === "\\edef" || t === "\\xdef") && (c = e.gullet.expandTokens(c), c.reverse()), e.gullet.macros.set(i, { tokens: c, numArgs: s, delimiters: h }, t === Et[t]), { type: "internal", mode: e.mode }; } });
B({ type: "internal", names: ["\\let", "\\\\globallet"], props: { numArgs: 0, allowedInText: !0, primitive: !0 }, handler(r) { var { parser: e, funcName: t } = r, a = m1(e.gullet.popToken()); e.gullet.consumeSpaces(); var i = s4(e); return c1(e, a, i, t === "\\\\globallet"), { type: "internal", mode: e.mode }; } });
B({ type: "internal", names: ["\\futurelet", "\\\\globalfuture"], props: { numArgs: 0, allowedInText: !0, primitive: !0 }, handler(r) { var { parser: e, funcName: t } = r, a = m1(e.gullet.popToken()), i = e.gullet.popToken(), s = e.gullet.popToken(); return c1(e, a, s, t === "\\\\globalfuture"), e.gullet.pushToken(s), e.gullet.pushToken(i), { type: "internal", mode: e.mode }; } });
var me = function (e, t, a) { var i = W.math[e] && W.math[e].replace, s = Gt(i || e, t, a); if (!s)
    throw new Error("Unsupported symbol " + e + " and font size " + t + "."); return s; }, Wt = function (e, t, a, i) { var s = a.havingBaseStyle(t), u = k(i.concat(s.sizingClasses(a)), [e], a), h = s.sizeMultiplier / a.sizeMultiplier; return u.height *= h, u.depth *= h, u.maxFontSize = s.sizeMultiplier, u; }, d1 = function (e, t, a) { var i = t.havingBaseStyle(a), s = (1 - t.sizeMultiplier / i.sizeMultiplier) * t.fontMetrics().axisHeight; e.classes.push("delimcenter"), e.style.top = A(s), e.height -= s, e.depth += s; }, l4 = function (e, t, a, i, s, u) { var h = s0(e, "Main-Regular", s, i), c = Wt(h, t, i, u); return a && d1(c, i, t), c; }, u4 = function (e, t, a, i) { return s0(e, "Size" + t + "-Regular", a, i); }, f1 = function (e, t, a, i, s, u) { var h = u4(e, t, s, i), c = Wt(k(["delimsizing", "size" + t], [h], i), N.TEXT, i, u); return a && d1(c, i, N.TEXT), c; }, ut = function (e, t, a) { var i; t === "Size1-Regular" ? i = "delim-size1" : i = "delim-size4"; var s = k(["delimsizinginner", i], [k([], [s0(e, t, a)])]); return { type: "elem", elem: s }; }, ot = function (e, t, a) { var i = z0["Size4-Regular"][e.charCodeAt(0)] ? z0["Size4-Regular"][e.charCodeAt(0)][4] : z0["Size1-Regular"][e.charCodeAt(0)][4], s = new A0("inner", ga(e, Math.round(1e3 * t))), u = new x0([s], { width: A(i), height: A(t), style: "width:" + A(i), viewBox: "0 0 " + 1e3 * i + " " + Math.round(1e3 * t), preserveAspectRatio: "xMinYMin" }), h = V0([], [u], a); return h.height = t, h.style.height = A(t), h.style.width = A(i), { type: "elem", elem: h }; }, Rt = .008, Re = { type: "kern", size: -1 * Rt }, o4 = new Set(["|", "\\lvert", "\\rvert", "\\vert"]), h4 = new Set(["\\|", "\\lVert", "\\rVert", "\\Vert"]), v1 = function (e, t, a, i, s, u) { var h, c, v, p, b = "", x = 0; h = v = p = e, c = null; var y = "Size1-Regular"; e === "\\uparrow" ? v = p = "\u23D0" : e === "\\Uparrow" ? v = p = "\u2016" : e === "\\downarrow" ? h = v = "\u23D0" : e === "\\Downarrow" ? h = v = "\u2016" : e === "\\updownarrow" ? (h = "\\uparrow", v = "\u23D0", p = "\\downarrow") : e === "\\Updownarrow" ? (h = "\\Uparrow", v = "\u2016", p = "\\Downarrow") : o4.has(e) ? (v = "\u2223", b = "vert", x = 333) : h4.has(e) ? (v = "\u2225", b = "doublevert", x = 556) : e === "[" || e === "\\lbrack" ? (h = "\u23A1", v = "\u23A2", p = "\u23A3", y = "Size4-Regular", b = "lbrack", x = 667) : e === "]" || e === "\\rbrack" ? (h = "\u23A4", v = "\u23A5", p = "\u23A6", y = "Size4-Regular", b = "rbrack", x = 667) : e === "\\lfloor" || e === "\u230A" ? (v = h = "\u23A2", p = "\u23A3", y = "Size4-Regular", b = "lfloor", x = 667) : e === "\\lceil" || e === "\u2308" ? (h = "\u23A1", v = p = "\u23A2", y = "Size4-Regular", b = "lceil", x = 667) : e === "\\rfloor" || e === "\u230B" ? (v = h = "\u23A5", p = "\u23A6", y = "Size4-Regular", b = "rfloor", x = 667) : e === "\\rceil" || e === "\u2309" ? (h = "\u23A4", v = p = "\u23A5", y = "Size4-Regular", b = "rceil", x = 667) : e === "(" || e === "\\lparen" ? (h = "\u239B", v = "\u239C", p = "\u239D", y = "Size4-Regular", b = "lparen", x = 875) : e === ")" || e === "\\rparen" ? (h = "\u239E", v = "\u239F", p = "\u23A0", y = "Size4-Regular", b = "rparen", x = 875) : e === "\\{" || e === "\\lbrace" ? (h = "\u23A7", c = "\u23A8", p = "\u23A9", v = "\u23AA", y = "Size4-Regular") : e === "\\}" || e === "\\rbrace" ? (h = "\u23AB", c = "\u23AC", p = "\u23AD", v = "\u23AA", y = "Size4-Regular") : e === "\\lgroup" || e === "\u27EE" ? (h = "\u23A7", p = "\u23A9", v = "\u23AA", y = "Size4-Regular") : e === "\\rgroup" || e === "\u27EF" ? (h = "\u23AB", p = "\u23AD", v = "\u23AA", y = "Size4-Regular") : e === "\\lmoustache" || e === "\u23B0" ? (h = "\u23A7", p = "\u23AD", v = "\u23AA", y = "Size4-Regular") : (e === "\\rmoustache" || e === "\u23B1") && (h = "\u23AB", p = "\u23A9", v = "\u23AA", y = "Size4-Regular"); var T = me(h, y, s), M = T.height + T.depth, q = me(v, y, s), C = q.height + q.depth, R = me(p, y, s), F = R.height + R.depth, L = 0, H = 1; if (c !== null) {
    var P = me(c, y, s);
    L = P.height + P.depth, H = 2;
} var G = M + F + L, Y = Math.max(0, Math.ceil((t - G) / (H * C))), U = G + Y * H * C, h0 = i.fontMetrics().axisHeight; a && (h0 *= i.sizeMultiplier); var c0 = U / 2 - h0, _ = []; if (b.length > 0) {
    var le = U - M - F, w0 = Math.round(U * 1e3), b0 = ba(b, Math.round(le * 1e3)), N0 = new A0(b, b0), Z0 = A(x / 1e3), K0 = A(w0 / 1e3), rt = new x0([N0], { width: Z0, height: K0, viewBox: "0 0 " + x + " " + w0 }), F0 = V0([], [rt], i);
    F0.height = w0 / 1e3, F0.style.width = Z0, F0.style.height = K0, _.push({ type: "elem", elem: F0 });
}
else {
    if (_.push(ut(p, y, s)), _.push(Re), c === null) {
        var O0 = U - M - F + 2 * Rt;
        _.push(ot(v, O0, i));
    }
    else {
        var ue = (U - M - F - L) / 2 + 2 * Rt;
        _.push(ot(v, ue, i)), _.push(Re), _.push(ut(c, y, s)), _.push(Re), _.push(ot(v, ue, i));
    }
    _.push(Re), _.push(ut(h, y, s));
} var y0 = i.havingBaseStyle(N.TEXT), ye = V({ positionType: "bottom", positionData: c0, children: _ }); return Wt(k(["delimsizing", "mult"], [ye], y0), N.TEXT, i, u); }, ht = 80, mt = .08, ct = function (e, t, a, i, s) { var u = pa(e, i, a), h = new A0(e, u), c = new x0([h], { width: "400em", height: A(t), viewBox: "0 0 400000 " + a, preserveAspectRatio: "xMinYMin slice" }); return V0(["hide-tail"], [c], s); }, m4 = function (e, t) { var a = t.havingBaseSizing(), i = x1("\\surd", e * a.sizeMultiplier, y1, a), s = a.sizeMultiplier, u = Math.max(0, t.minRuleThickness - t.fontMetrics().sqrtRuleThickness), h, c, v, p, b; return i.type === "small" ? (p = 1e3 + 1e3 * u + ht, e < 1 ? s = 1 : e < 1.4 && (s = .7), c = (1 + u + mt) / s, v = (1 + u) / s, h = ct("sqrtMain", c, p, u, t), h.style.minWidth = "0.853em", b = .833 / s) : i.type === "large" ? (p = (1e3 + ht) * ce[i.size], v = (ce[i.size] + u) / s, c = (ce[i.size] + u + mt) / s, h = ct("sqrtSize" + i.size, c, p, u, t), h.style.minWidth = "1.02em", b = 1 / s) : (c = e + u + mt, v = e + u, p = Math.floor(1e3 * e + u) + ht, h = ct("sqrtTall", c, p, u, t), h.style.minWidth = "0.742em", b = 1.056), h.height = v, h.style.height = A(c), { span: h, advanceWidth: b, ruleWidth: (t.fontMetrics().sqrtRuleThickness + u) * s }; }, p1 = new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "\\surd"]), c4 = new Set(["\\uparrow", "\\downarrow", "\\updownarrow", "\\Uparrow", "\\Downarrow", "\\Updownarrow", "|", "\\|", "\\vert", "\\Vert", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1"]), g1 = new Set(["<", ">", "\\langle", "\\rangle", "/", "\\backslash", "\\lt", "\\gt"]), ce = [0, 1.2, 1.8, 2.4, 3], b1 = function (e, t, a, i, s) { if (e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle"), p1.has(e) || g1.has(e))
    return f1(e, t, !1, a, i, s); if (c4.has(e))
    return v1(e, ce[t], !1, a, i, s); throw new z("Illegal delimiter: '" + e + "'"); }, d4 = [{ type: "small", style: N.SCRIPTSCRIPT }, { type: "small", style: N.SCRIPT }, { type: "small", style: N.TEXT }, { type: "large", size: 1 }, { type: "large", size: 2 }, { type: "large", size: 3 }, { type: "large", size: 4 }], f4 = [{ type: "small", style: N.SCRIPTSCRIPT }, { type: "small", style: N.SCRIPT }, { type: "small", style: N.TEXT }, { type: "stack" }], y1 = [{ type: "small", style: N.SCRIPTSCRIPT }, { type: "small", style: N.SCRIPT }, { type: "small", style: N.TEXT }, { type: "large", size: 1 }, { type: "large", size: 2 }, { type: "large", size: 3 }, { type: "large", size: 4 }, { type: "stack" }], v4 = function (e) { if (e.type === "small")
    return "Main-Regular"; if (e.type === "large")
    return "Size" + e.size + "-Regular"; if (e.type === "stack")
    return "Size4-Regular"; var t = e.type; throw new Error("Add support for delim type '" + t + "' here."); }, x1 = function (e, t, a, i) { for (var s = Math.min(2, 3 - i.style.size), u = s; u < a.length; u++) {
    var h = a[u];
    if (h.type === "stack")
        break;
    var c = me(e, v4(h), "math"), v = c.height + c.depth;
    if (h.type === "small") {
        var p = i.havingBaseStyle(h.style);
        v *= p.sizeMultiplier;
    }
    if (v > t)
        return h;
} return a[a.length - 1]; }, It = function (e, t, a, i, s, u) { e === "<" || e === "\\lt" || e === "\u27E8" ? e = "\\langle" : (e === ">" || e === "\\gt" || e === "\u27E9") && (e = "\\rangle"); var h; g1.has(e) ? h = d4 : p1.has(e) ? h = y1 : h = f4; var c = x1(e, t, h, i); return c.type === "small" ? l4(e, c.style, a, i, s, u) : c.type === "large" ? f1(e, c.size, a, i, s, u) : v1(e, t, a, i, s, u); }, dt = function (e, t, a, i, s, u) { var h = i.fontMetrics().axisHeight * i.sizeMultiplier, c = 901, v = 5 / i.fontMetrics().ptPerEm, p = Math.max(t - h, a + h), b = Math.max(p / 500 * c, 2 * p - v); return It(e, b, !0, i, s, u); }, Ar = { "\\bigl": { mclass: "mopen", size: 1 }, "\\Bigl": { mclass: "mopen", size: 2 }, "\\biggl": { mclass: "mopen", size: 3 }, "\\Biggl": { mclass: "mopen", size: 4 }, "\\bigr": { mclass: "mclose", size: 1 }, "\\Bigr": { mclass: "mclose", size: 2 }, "\\biggr": { mclass: "mclose", size: 3 }, "\\Biggr": { mclass: "mclose", size: 4 }, "\\bigm": { mclass: "mrel", size: 1 }, "\\Bigm": { mclass: "mrel", size: 2 }, "\\biggm": { mclass: "mrel", size: 3 }, "\\Biggm": { mclass: "mrel", size: 4 }, "\\big": { mclass: "mord", size: 1 }, "\\Big": { mclass: "mord", size: 2 }, "\\bigg": { mclass: "mord", size: 3 }, "\\Bigg": { mclass: "mord", size: 4 } }, p4 = new Set(["(", "\\lparen", ")", "\\rparen", "[", "\\lbrack", "]", "\\rbrack", "\\{", "\\lbrace", "\\}", "\\rbrace", "\\lfloor", "\\rfloor", "\u230A", "\u230B", "\\lceil", "\\rceil", "\u2308", "\u2309", "<", ">", "\\langle", "\u27E8", "\\rangle", "\u27E9", "\\lt", "\\gt", "\\lvert", "\\rvert", "\\lVert", "\\rVert", "\\lgroup", "\\rgroup", "\u27EE", "\u27EF", "\\lmoustache", "\\rmoustache", "\u23B0", "\u23B1", "/", "\\backslash", "|", "\\vert", "\\|", "\\Vert", "\\uparrow", "\\Uparrow", "\\downarrow", "\\Downarrow", "\\updownarrow", "\\Updownarrow", "."]);
function Mr(r) { return "isMiddle" in r; }
function Qe(r, e) { var t = Ke(r); if (t && p4.has(t.text))
    return t; throw t ? new z("Invalid delimiter '" + t.text + "' after '" + e.funcName + "'", r) : new z("Invalid delimiter type '" + r.type + "'", r); }
B({ type: "delimsizing", names: ["\\bigl", "\\Bigl", "\\biggl", "\\Biggl", "\\bigr", "\\Bigr", "\\biggr", "\\Biggr", "\\bigm", "\\Bigm", "\\biggm", "\\Biggm", "\\big", "\\Big", "\\bigg", "\\Bigg"], props: { numArgs: 1, argTypes: ["primitive"] }, handler: (r, e) => { var t = Qe(e[0], r); return { type: "delimsizing", mode: r.parser.mode, size: Ar[r.funcName].size, mclass: Ar[r.funcName].mclass, delim: t.text }; }, htmlBuilder: (r, e) => r.delim === "." ? k([r.mclass]) : b1(r.delim, r.size, e, r.mode, [r.mclass]), mathmlBuilder: r => { var e = []; r.delim !== "." && e.push(g0(r.delim, r.mode)); var t = new S("mo", e); r.mclass === "mopen" || r.mclass === "mclose" ? t.setAttribute("fence", "true") : t.setAttribute("fence", "false"), t.setAttribute("stretchy", "true"); var a = A(ce[r.size]); return t.setAttribute("minsize", a), t.setAttribute("maxsize", a), t; } });
function Tr(r) { if (!r.body)
    throw new Error("Bug: The leftright ParseNode wasn't fully parsed."); }
B({ type: "leftright-right", names: ["\\right"], props: { numArgs: 1, primitive: !0 }, handler: (r, e) => { var t = r.parser.gullet.macros.get("\\current@color"); if (t && typeof t != "string")
        throw new z("\\current@color set to non-string in \\right"); return { type: "leftright-right", mode: r.parser.mode, delim: Qe(e[0], r).text, color: t }; } });
B({ type: "leftright", names: ["\\left"], props: { numArgs: 1, primitive: !0 }, handler: (r, e) => { var t = Qe(e[0], r), a = r.parser; ++a.leftrightDepth; var i = a.parseExpression(!1); --a.leftrightDepth, a.expect("\\right", !1); var s = O(a.parseFunction(), "leftright-right"); return { type: "leftright", mode: a.mode, body: i, left: t.text, right: s.delim, rightColor: s.color }; }, htmlBuilder: (r, e) => { Tr(r); for (var t = a0(r.body, e, !0, ["mopen", "mclose"]), a = 0, i = 0, s = !1, u = 0; u < t.length; u++) {
        var h = t[u];
        Mr(h) ? s = !0 : (a = Math.max(t[u].height, a), i = Math.max(t[u].depth, i));
    } a *= e.sizeMultiplier, i *= e.sizeMultiplier; var c; if (r.left === "." ? c = pe(e, ["mopen"]) : c = dt(r.left, a, i, e, r.mode, ["mopen"]), t.unshift(c), s)
        for (var v = 1; v < t.length; v++) {
            var p = t[v];
            if (Mr(p)) {
                var b = p.isMiddle;
                t[v] = dt(b.delim, a, i, b.options, r.mode, []);
            }
        } var x; if (r.right === ".")
        x = pe(e, ["mclose"]);
    else {
        var y = r.rightColor ? e.withColor(r.rightColor) : e;
        x = dt(r.right, a, i, y, r.mode, ["mclose"]);
    } return t.push(x), k(["minner"], t, e); }, mathmlBuilder: (r, e) => { Tr(r); var t = v0(r.body, e); if (r.left !== ".") {
        var a = new S("mo", [g0(r.left, r.mode)]);
        a.setAttribute("fence", "true"), t.unshift(a);
    } if (r.right !== ".") {
        var i = new S("mo", [g0(r.right, r.mode)]);
        i.setAttribute("fence", "true"), r.rightColor && i.setAttribute("mathcolor", r.rightColor), t.push(i);
    } return Xt(t); } });
B({ type: "middle", names: ["\\middle"], props: { numArgs: 1, primitive: !0 }, handler: (r, e) => { var t = Qe(e[0], r); if (!r.parser.leftrightDepth)
        throw new z("\\middle without preceding \\left", t); return { type: "middle", mode: r.parser.mode, delim: t.text }; }, htmlBuilder: (r, e) => { var t; return r.delim === "." ? t = pe(e, []) : (t = b1(r.delim, 1, e, r.mode, []), t.isMiddle = { delim: r.delim, options: e }), t; }, mathmlBuilder: (r, e) => { var t = r.delim === "\\vert" || r.delim === "|" ? g0("|", "text") : g0(r.delim, r.mode), a = new S("mo", [t]); return a.setAttribute("fence", "true"), a.setAttribute("lspace", "0.05em"), a.setAttribute("rspace", "0.05em"), a; } });
var _e = (r, e) => { var t = ie(X(r.body, e), e), a = r.label.slice(1), i = e.sizeMultiplier, s, u, h = E0(r.body); if (a === "sout")
    s = k(["stretchy", "sout"]), s.height = e.fontMetrics().defaultRuleThickness / i, u = -.5 * e.fontMetrics().xHeight;
else if (a === "phase") {
    var c = J({ number: .6, unit: "pt" }, e), v = J({ number: .35, unit: "ex" }, e), p = e.havingBaseSizing();
    i = i / p.sizeMultiplier;
    var b = t.height + t.depth + c + v;
    t.style.paddingLeft = A(b / 2 + c);
    var x = Math.floor(1e3 * b * i), y = fa(x), T = new x0([new A0("phase", y)], { width: "400em", height: A(x / 1e3), viewBox: "0 0 400000 " + x, preserveAspectRatio: "xMinYMin slice" });
    s = V0(["hide-tail"], [T], e), s.style.height = A(b), u = t.depth + c + v;
}
else {
    /cancel/.test(a) ? h || t.classes.push("cancel-pad") : a === "angl" ? t.classes.push("anglpad") : t.classes.push("boxpad");
    var M, q, C = 0;
    /box/.test(a) ? (C = Math.max(e.fontMetrics().fboxrule, e.minRuleThickness), M = e.fontMetrics().fboxsep + (a === "colorbox" ? 0 : C), q = M) : a === "angl" ? (C = Math.max(e.fontMetrics().defaultRuleThickness, e.minRuleThickness), M = 4 * C, q = Math.max(0, .25 - t.depth)) : (M = h ? .2 : 0, q = M), s = Ja(t, a, M, q, e), /fbox|boxed|fcolorbox/.test(a) ? (s.style.borderStyle = "solid", s.style.borderWidth = A(C)) : a === "angl" && C !== .049 && (s.style.borderTopWidth = A(C), s.style.borderRightWidth = A(C)), u = t.depth + q, r.backgroundColor && (s.style.backgroundColor = r.backgroundColor, r.borderColor && (s.style.borderColor = r.borderColor));
} var R; if (r.backgroundColor)
    R = V({ positionType: "individualShift", children: [{ type: "elem", elem: s, shift: u }, { type: "elem", elem: t, shift: 0 }] });
else {
    var F = /cancel|phase/.test(a) ? ["svg-align"] : [];
    R = V({ positionType: "individualShift", children: [{ type: "elem", elem: t, shift: 0 }, { type: "elem", elem: s, shift: u, wrapperClasses: F }] });
} return /cancel/.test(a) && (R.height = t.height, R.depth = t.depth), /cancel/.test(a) && !h ? k(["mord", "cancel-lap"], [R], e) : k(["mord"], [R], e); }, et = (r, e) => { var t, a = new S(r.label.includes("colorbox") ? "mpadded" : "menclose", [$(r.body, e)]); switch (r.label) {
    case "\\cancel":
        a.setAttribute("notation", "updiagonalstrike");
        break;
    case "\\bcancel":
        a.setAttribute("notation", "downdiagonalstrike");
        break;
    case "\\phase":
        a.setAttribute("notation", "phasorangle");
        break;
    case "\\sout":
        a.setAttribute("notation", "horizontalstrike");
        break;
    case "\\fbox":
        a.setAttribute("notation", "box");
        break;
    case "\\angl":
        a.setAttribute("notation", "actuarial");
        break;
    case "\\fcolorbox":
    case "\\colorbox":
        if (t = e.fontMetrics().fboxsep * e.fontMetrics().ptPerEm, a.setAttribute("width", "+" + 2 * t + "pt"), a.setAttribute("height", "+" + 2 * t + "pt"), a.setAttribute("lspace", t + "pt"), a.setAttribute("voffset", t + "pt"), r.label === "\\fcolorbox") {
            var i = Math.max(e.fontMetrics().fboxrule, e.minRuleThickness);
            a.setAttribute("style", "border: " + A(i) + " solid " + r.borderColor);
        }
        break;
    case "\\xcancel":
        a.setAttribute("notation", "updiagonalstrike downdiagonalstrike");
        break;
} return r.backgroundColor && a.setAttribute("mathbackground", r.backgroundColor), a; };
B({ type: "enclose", names: ["\\colorbox"], props: { numArgs: 2, allowedInText: !0, argTypes: ["color", "hbox"] }, handler(r, e, t) { var { parser: a, funcName: i } = r, s = O(e[0], "color-token").color, u = e[1]; return { type: "enclose", mode: a.mode, label: i, backgroundColor: s, body: u }; }, htmlBuilder: _e, mathmlBuilder: et });
B({ type: "enclose", names: ["\\fcolorbox"], props: { numArgs: 3, allowedInText: !0, argTypes: ["color", "color", "hbox"] }, handler(r, e, t) { var { parser: a, funcName: i } = r, s = O(e[0], "color-token").color, u = O(e[1], "color-token").color, h = e[2]; return { type: "enclose", mode: a.mode, label: i, backgroundColor: u, borderColor: s, body: h }; }, htmlBuilder: _e, mathmlBuilder: et });
B({ type: "enclose", names: ["\\fbox"], props: { numArgs: 1, argTypes: ["hbox"], allowedInText: !0 }, handler(r, e) { var { parser: t } = r; return { type: "enclose", mode: t.mode, label: "\\fbox", body: e[0] }; } });
B({ type: "enclose", names: ["\\cancel", "\\bcancel", "\\xcancel", "\\phase"], props: { numArgs: 1 }, handler(r, e) { var { parser: t, funcName: a } = r, i = e[0]; return { type: "enclose", mode: t.mode, label: a, body: i }; }, htmlBuilder: _e, mathmlBuilder: et });
B({ type: "enclose", names: ["\\sout"], props: { numArgs: 1, allowedInText: !0 }, handler(r, e) { var { parser: t, funcName: a } = r; t.mode === "math" && t.settings.reportNonstrict("mathVsSout", "LaTeX's \\sout works only in text mode"); var i = e[0]; return { type: "enclose", mode: t.mode, label: a, body: i }; }, htmlBuilder: _e, mathmlBuilder: et });
B({ type: "enclose", names: ["\\angl"], props: { numArgs: 1, argTypes: ["hbox"], allowedInText: !1 }, handler(r, e) { var { parser: t } = r; return { type: "enclose", mode: t.mode, label: "\\angl", body: e[0] }; } });
var w1 = {};
function M0(r) { for (var { type: e, names: t, props: a, handler: i, htmlBuilder: s, mathmlBuilder: u } = r, h = { type: e, numArgs: a.numArgs || 0, allowedInText: !1, numOptionalArgs: 0, handler: i }, c = 0; c < t.length; ++c)
    w1[t[c]] = h; s && (Le[e] = s), u && (Pe[e] = u); }
var k1 = {};
function m(r, e) { k1[r] = e; }
var m0 = class r {
    constructor(e, t, a) { this.lexer = void 0, this.start = void 0, this.end = void 0, this.lexer = e, this.start = t, this.end = a; }
    static range(e, t) { return t ? !e || !e.loc || !t.loc || e.loc.lexer !== t.loc.lexer ? null : new r(e.loc.lexer, e.loc.start, t.loc.end) : e && e.loc; }
}, d0 = class r {
    constructor(e, t) { this.text = void 0, this.loc = void 0, this.noexpand = void 0, this.treatAsRelax = void 0, this.text = e, this.loc = t; }
    range(e, t) { return new r(t, m0.range(this, e)); }
};
function Br(r) { var e = []; r.consumeSpaces(); var t = r.fetch().text; for (t === "\\relax" && (r.consume(), r.consumeSpaces(), t = r.fetch().text); t === "\\hline" || t === "\\hdashline";)
    r.consume(), e.push(t === "\\hdashline"), r.consumeSpaces(), t = r.fetch().text; return e; }
var tt = r => { var e = r.parser.settings; if (!e.displayMode)
    throw new z("{" + r.envName + "} can be used only in display mode."); }, g4 = new Set(["gather", "gather*"]);
function jt(r) { if (!r.includes("ed"))
    return !r.includes("*"); }
function Y0(r, e, t) { var { hskipBeforeAndAfter: a, addJot: i, cols: s, arraystretch: u, colSeparationType: h, autoTag: c, singleRow: v, emptySingleRow: p, maxNumCols: b, leqno: x } = e; if (r.gullet.beginGroup(), v || r.gullet.macros.set("\\cr", "\\\\\\relax"), !u) {
    var y = r.gullet.expandMacroAsText("\\arraystretch");
    if (y == null)
        u = 1;
    else if (u = parseFloat(y), !u || u < 0)
        throw new z("Invalid \\arraystretch: " + y);
} r.gullet.beginGroup(); var T = [], M = [T], q = [], C = [], R = c != null ? [] : void 0; function F() { c && r.gullet.macros.set("\\@eqnsw", "1", !0); } function L() { R && (r.gullet.macros.get("\\df@tag") ? (R.push(r.subparse([new d0("\\df@tag")])), r.gullet.macros.set("\\df@tag", void 0, !0)) : R.push(!!c && r.gullet.macros.get("\\@eqnsw") === "1")); } for (F(), C.push(Br(r));;) {
    var H = r.parseExpression(!1, v ? "\\end" : "\\\\");
    r.gullet.endGroup(), r.gullet.beginGroup();
    var P = { type: "ordgroup", mode: r.mode, body: H };
    t && (P = { type: "styling", mode: r.mode, style: t, resetFont: !0, body: [P] }), T.push(P);
    var G = r.fetch().text;
    if (G === "&") {
        if (b && T.length === b) {
            if (v || h)
                throw new z("Too many tab characters: &", r.nextToken);
            r.settings.reportNonstrict("textEnv", "Too few columns specified in the {array} column argument.");
        }
        r.consume();
    }
    else if (G === "\\end") {
        L(), T.length === 1 && P.type === "styling" && P.body.length === 1 && P.body[0].type === "ordgroup" && P.body[0].body.length === 0 && (M.length > 1 || !p) && M.pop(), C.length < M.length + 1 && C.push([]);
        break;
    }
    else if (G === "\\\\") {
        r.consume();
        var Y = void 0;
        r.gullet.future().text !== " " && (Y = r.parseSizeGroup(!0)), q.push(Y ? Y.value : null), L(), C.push(Br(r)), T = [], M.push(T), F();
    }
    else
        throw new z("Expected & or \\\\ or \\cr or \\end", r.nextToken);
} return r.gullet.endGroup(), r.gullet.endGroup(), { type: "array", mode: r.mode, addJot: i, arraystretch: u, body: M, cols: s, rowGaps: q, hskipBeforeAndAfter: a, hLinesBeforeRow: C, colSeparationType: h, tags: R, leqno: x }; }
function Zt(r) { return r.slice(0, 1) === "d" ? "display" : "text"; }
var T0 = function (e, t) { var a, i, s = e.body.length, u = e.hLinesBeforeRow, h = 0, c = new Array(s), v = [], p = Math.max(t.fontMetrics().arrayRuleWidth, t.minRuleThickness), b = 1 / t.fontMetrics().ptPerEm, x = 5 * b; if (e.colSeparationType && e.colSeparationType === "small") {
    var y = t.havingStyle(N.SCRIPT).sizeMultiplier;
    x = .2778 * (y / t.sizeMultiplier);
} var T = e.colSeparationType === "CD" ? J({ number: 3, unit: "ex" }, t) : 12 * b, M = 3 * b, q = e.arraystretch * T, C = .7 * q, R = .3 * q, F = 0; function L(Se) { for (var ze = 0; ze < Se.length; ++ze)
    ze > 0 && (F += .25), v.push({ pos: F, isDashed: Se[ze] }); } for (L(u[0]), a = 0; a < e.body.length; ++a) {
    var H = e.body[a], P = C, G = R;
    h < H.length && (h = H.length);
    var Y = { cells: new Array(H.length), height: 0, depth: 0, pos: 0 };
    for (i = 0; i < H.length; ++i) {
        var U = X(H[i], t);
        G < U.depth && (G = U.depth), P < U.height && (P = U.height), Y.cells[i] = U;
    }
    var h0 = e.rowGaps[a], c0 = 0;
    h0 && (c0 = J(h0, t), c0 > 0 && (c0 += R, G < c0 && (G = c0), c0 = 0)), e.addJot && a < e.body.length - 1 && (G += M), Y.height = P, Y.depth = G, F += P, Y.pos = F, F += G + c0, c[a] = Y, L(u[a + 1]);
} var _ = F / 2 + t.fontMetrics().axisHeight, le = e.cols || [], w0 = [], b0, N0, Z0 = []; if (e.tags && e.tags.some(Se => Se))
    for (a = 0; a < s; ++a) {
        var K0 = c[a], rt = K0.pos - _, F0 = e.tags[a], O0 = void 0;
        F0 === !0 ? O0 = k(["eqn-num"], [], t) : F0 === !1 ? O0 = k([], [], t) : O0 = k([], a0(F0, t, !0), t), O0.depth = K0.depth, O0.height = K0.height, Z0.push({ type: "elem", elem: O0, shift: rt });
    } for (i = 0, N0 = 0; i < h || N0 < le.length; ++i, ++N0) {
    for (var ue, y0 = le[N0], ye = !0; ((er = y0) == null ? void 0 : er.type) === "separator";) {
        var er;
        if (ye || (b0 = k(["arraycolsep"], []), b0.style.width = A(t.fontMetrics().doubleRuleSep), w0.push(b0)), y0.separator === "|" || y0.separator === ":") {
            var L1 = y0.separator === "|" ? "solid" : "dashed", J0 = k(["vertical-separator"], [], t);
            J0.style.height = A(F), J0.style.borderRightWidth = A(p), J0.style.borderRightStyle = L1, J0.style.margin = "0 " + A(-p / 2);
            var tr = F - _;
            tr && (J0.style.verticalAlign = A(-tr)), w0.push(J0);
        }
        else
            throw new z("Invalid separator type: " + y0.separator);
        N0++, y0 = le[N0], ye = !1;
    }
    if (!(i >= h)) {
        var Q0 = void 0;
        if (i > 0 || e.hskipBeforeAndAfter) {
            var rr, ar;
            Q0 = (rr = (ar = y0) == null ? void 0 : ar.pregap) != null ? rr : x, Q0 !== 0 && (b0 = k(["arraycolsep"], []), b0.style.width = A(Q0), w0.push(b0));
        }
        var ir = [];
        for (a = 0; a < s; ++a) {
            var xe = c[a], we = xe.cells[i];
            if (we) {
                var P1 = xe.pos - _;
                we.depth = xe.depth, we.height = xe.height, ir.push({ type: "elem", elem: we, shift: P1 });
            }
        }
        var G1 = V({ positionType: "individualShift", children: ir }), U1 = k(["col-align-" + (((ue = y0) == null ? void 0 : ue.align) || "c")], [G1]);
        if (w0.push(U1), i < h - 1 || e.hskipBeforeAndAfter) {
            var nr, sr;
            Q0 = (nr = (sr = y0) == null ? void 0 : sr.postgap) != null ? nr : x, Q0 !== 0 && (b0 = k(["arraycolsep"], []), b0.style.width = A(Q0), w0.push(b0));
        }
    }
} var ke = k(["mtable"], w0); if (v.length > 0) {
    for (var V1 = ae("hline", t, p), X1 = ae("hdashline", t, p), at = [{ type: "elem", elem: ke, shift: 0 }]; v.length > 0;) {
        var lr = v.pop(), ur = lr.pos - _;
        lr.isDashed ? at.push({ type: "elem", elem: X1, shift: ur }) : at.push({ type: "elem", elem: V1, shift: ur });
    }
    ke = V({ positionType: "individualShift", children: at });
} if (Z0.length === 0)
    return k(["mord"], [ke], t); var Y1 = V({ positionType: "individualShift", children: Z0 }), $1 = k(["tag"], [Y1], t); return I0([ke, $1]); }, b4 = { c: "center ", l: "left ", r: "right " }, B0 = function (e, t) { for (var a = [], i = new S("mtd", [], ["mtr-glue"]), s = new S("mtd", [], ["mml-eqn-num"]), u = 0; u < e.body.length; u++) {
    for (var h = e.body[u], c = [], v = 0; v < h.length; v++)
        c.push(new S("mtd", [$(h[v], t)]));
    e.tags && e.tags[u] && (c.unshift(i), c.push(i), e.leqno ? c.unshift(s) : c.push(s)), a.push(new S("mtr", c));
} var p = new S("mtable", a), b = e.arraystretch === .5 ? .1 : .16 + e.arraystretch - 1 + (e.addJot ? .09 : 0); p.setAttribute("rowspacing", A(b)); var x = "", y = ""; if (e.cols && e.cols.length > 0) {
    var T = e.cols, M = "", q = !1, C = 0, R = T.length;
    T[0].type === "separator" && (x += "top ", C = 1), T[T.length - 1].type === "separator" && (x += "bottom ", R -= 1);
    for (var F = C; F < R; F++) {
        var L = T[F];
        L.type === "align" ? (y += b4[L.align], q && (M += "none "), q = !0) : L.type === "separator" && q && (M += L.separator === "|" ? "solid " : "dashed ", q = !1);
    }
    p.setAttribute("columnalign", y.trim()), /[sd]/.test(M) && p.setAttribute("columnlines", M.trim());
} if (e.colSeparationType === "align") {
    for (var H = e.cols || [], P = "", G = 1; G < H.length; G++)
        P += G % 2 ? "0em " : "1em ";
    p.setAttribute("columnspacing", P.trim());
}
else
    e.colSeparationType === "alignat" || e.colSeparationType === "gather" ? p.setAttribute("columnspacing", "0em") : e.colSeparationType === "small" ? p.setAttribute("columnspacing", "0.2778em") : e.colSeparationType === "CD" ? p.setAttribute("columnspacing", "0.5em") : p.setAttribute("columnspacing", "1em"); var Y = "", U = e.hLinesBeforeRow; x += U[0].length > 0 ? "left " : "", x += U[U.length - 1].length > 0 ? "right " : ""; for (var h0 = 1; h0 < U.length - 1; h0++)
    Y += U[h0].length === 0 ? "none " : U[h0][0] ? "dashed " : "solid "; return /[sd]/.test(Y) && p.setAttribute("rowlines", Y.trim()), x !== "" && (p = new S("menclose", [p]), p.setAttribute("notation", x.trim())), e.arraystretch && e.arraystretch < 1 && (p = new S("mstyle", [p]), p.setAttribute("scriptlevel", "1")), p; }, S1 = function (e, t) { e.envName.includes("ed") || tt(e); var a = [], i = e.envName.includes("at") ? "alignat" : "align", s = e.envName === "split", u = Y0(e.parser, { cols: a, addJot: !0, autoTag: s ? void 0 : jt(e.envName), emptySingleRow: !0, colSeparationType: i, maxNumCols: s ? 2 : void 0, leqno: e.parser.settings.leqno }, "display"), h = 0, c = 0, v = { type: "ordgroup", mode: e.mode, body: [] }; if (t[0] && t[0].type === "ordgroup") {
    for (var p = "", b = 0; b < t[0].body.length; b++) {
        var x = O(t[0].body[b], "textord");
        p += x.text;
    }
    h = Number(p), c = h * 2;
} var y = !c; u.body.forEach(function (C) { for (var R = 1; R < C.length; R += 2) {
    var F = O(C[R], "styling"), L = O(F.body[0], "ordgroup");
    L.body.unshift(v);
} if (y)
    c < C.length && (c = C.length);
else {
    var H = C.length / 2;
    if (h < H)
        throw new z("Too many math in a row: " + ("expected " + h + ", but got " + H), C[0]);
} }); for (var T = 0; T < c; ++T) {
    var M = "r", q = 0;
    T % 2 === 1 ? M = "l" : T > 0 && y && (q = 1), a[T] = { type: "align", align: M, pregap: q, postgap: 0 };
} return u.colSeparationType = y ? "align" : "alignat", u; };
M0({ type: "array", names: ["array", "darray"], props: { numArgs: 1 }, handler(r, e) { var t = Ke(e[0]), a = t ? [e[0]] : O(e[0], "ordgroup").body, i = a.map(function (u) { var h = Ze(u), c = h.text; if ("lcr".includes(c))
        return { type: "align", align: c }; if (c === "|")
        return { type: "separator", separator: "|" }; if (c === ":")
        return { type: "separator", separator: ":" }; throw new z("Unknown column alignment: " + c, u); }), s = { cols: i, hskipBeforeAndAfter: !0, maxNumCols: i.length }; return Y0(r.parser, s, Zt(r.envName)); }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["matrix", "pmatrix", "bmatrix", "Bmatrix", "vmatrix", "Vmatrix", "matrix*", "pmatrix*", "bmatrix*", "Bmatrix*", "vmatrix*", "Vmatrix*"], props: { numArgs: 0 }, handler(r) { var e = { matrix: null, pmatrix: ["(", ")"], bmatrix: ["[", "]"], Bmatrix: ["\\{", "\\}"], vmatrix: ["|", "|"], Vmatrix: ["\\Vert", "\\Vert"] }[r.envName.replace("*", "")], t = "c", a = { hskipBeforeAndAfter: !1, cols: [{ type: "align", align: t }] }; if (r.envName.charAt(r.envName.length - 1) === "*") {
        var i = r.parser;
        if (i.consumeSpaces(), i.fetch().text === "[") {
            if (i.consume(), i.consumeSpaces(), t = i.fetch().text, !"lcr".includes(t))
                throw new z("Expected l or c or r", i.nextToken);
            i.consume(), i.consumeSpaces(), i.expect("]"), i.consume(), a.cols = [{ type: "align", align: t }];
        }
    } var s = Y0(r.parser, a, Zt(r.envName)), u = Math.max(0, ...s.body.map(h => h.length)); return s.cols = new Array(u).fill({ type: "align", align: t }), e ? { type: "leftright", mode: r.mode, body: [s], left: e[0], right: e[1], rightColor: void 0 } : s; }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["smallmatrix"], props: { numArgs: 0 }, handler(r) { var e = { arraystretch: .5 }, t = Y0(r.parser, e, "script"); return t.colSeparationType = "small", t; }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["subarray"], props: { numArgs: 1 }, handler(r, e) { var t = Ke(e[0]), a = t ? [e[0]] : O(e[0], "ordgroup").body, i = a.map(function (h) { var c = Ze(h), v = c.text; if ("lc".includes(v))
        return { type: "align", align: v }; throw new z("Unknown column alignment: " + v, h); }); if (i.length > 1)
        throw new z("{subarray} can contain only one column"); var s = { cols: i, hskipBeforeAndAfter: !1, arraystretch: .5 }, u = Y0(r.parser, s, "script"); if (u.body.length > 0 && u.body[0].length > 1)
        throw new z("{subarray} can contain only one column"); return u; }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["cases", "dcases", "rcases", "drcases"], props: { numArgs: 0 }, handler(r) { var e = { arraystretch: 1.2, cols: [{ type: "align", align: "l", pregap: 0, postgap: 1 }, { type: "align", align: "l", pregap: 0, postgap: 0 }] }, t = Y0(r.parser, e, Zt(r.envName)); return { type: "leftright", mode: r.mode, body: [t], left: r.envName.includes("r") ? "." : "\\{", right: r.envName.includes("r") ? "\\}" : ".", rightColor: void 0 }; }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["align", "align*", "aligned", "split"], props: { numArgs: 0 }, handler: S1, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["gathered", "gather", "gather*"], props: { numArgs: 0 }, handler(r) { g4.has(r.envName) && tt(r); var e = { cols: [{ type: "align", align: "c" }], addJot: !0, colSeparationType: "gather", autoTag: jt(r.envName), emptySingleRow: !0, leqno: r.parser.settings.leqno }; return Y0(r.parser, e, "display"); }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["alignat", "alignat*", "alignedat"], props: { numArgs: 1 }, handler: S1, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["equation", "equation*"], props: { numArgs: 0 }, handler(r) { tt(r); var e = { autoTag: jt(r.envName), emptySingleRow: !0, singleRow: !0, maxNumCols: 1, leqno: r.parser.settings.leqno }; return Y0(r.parser, e, "display"); }, htmlBuilder: T0, mathmlBuilder: B0 });
M0({ type: "array", names: ["CD"], props: { numArgs: 0 }, handler(r) { return tt(r), n4(r.parser); }, htmlBuilder: T0, mathmlBuilder: B0 });
m("\\nonumber", "\\gdef\\@eqnsw{0}");
m("\\notag", "\\nonumber");
B({ type: "text", names: ["\\hline", "\\hdashline"], props: { numArgs: 0, allowedInText: !0, allowedInMath: !0 }, handler(r, e) { throw new z(r.funcName + " valid only within array environment"); } });
var Cr = w1;
B({ type: "environment", names: ["\\begin", "\\end"], props: { numArgs: 1, argTypes: ["text"] }, handler(r, e) { var { parser: t, funcName: a } = r, i = e[0]; if (i.type !== "ordgroup")
        throw new z("Invalid environment name", i); for (var s = "", u = 0; u < i.body.length; ++u)
        s += O(i.body[u], "textord").text; if (a === "\\begin") {
        if (!Cr.hasOwnProperty(s))
            throw new z("No such environment: " + s, i);
        var h = Cr[s], { args: c, optArgs: v } = t.parseArguments("\\begin{" + s + "}", h), p = { mode: t.mode, envName: s, parser: t }, b = h.handler(p, c, v);
        t.expect("\\end", !1);
        var x = t.nextToken, y = O(t.parseFunction(), "environment");
        if (y.name !== s)
            throw new z("Mismatch: \\begin{" + s + "} matched by \\end{" + y.name + "}", x);
        return b;
    } return { type: "environment", mode: t.mode, name: s, nameGroup: i }; } });
var z1 = (r, e) => { var t = r.font, a = e.withFont(t); return X(r.body, a); }, A1 = (r, e) => { var t = r.font, a = e.withFont(t); return $(r.body, a); }, Dr = { "\\Bbb": "\\mathbb", "\\bold": "\\mathbf", "\\frak": "\\mathfrak" };
B({ type: "font", names: ["\\mathrm", "\\mathit", "\\mathbf", "\\mathnormal", "\\mathsfit", "\\mathbb", "\\mathcal", "\\mathfrak", "\\mathscr", "\\mathsf", "\\mathtt", "\\Bbb", "\\bold", "\\frak"], props: { numArgs: 1, allowedInArgument: !0 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = Ge(e[0]), s = a; return s in Dr && (s = Dr[s]), { type: "font", mode: t.mode, font: s.slice(1), body: i }; }, htmlBuilder: z1, mathmlBuilder: A1 });
B({ type: "mclass", names: ["\\boldsymbol", "\\bm"], props: { numArgs: 1 }, handler: (r, e) => { var { parser: t } = r, a = e[0]; return { type: "mclass", mode: t.mode, mclass: Je(a), body: [{ type: "font", mode: t.mode, font: "boldsymbol", body: a }], isCharacterBox: E0(a) }; } });
B({ type: "font", names: ["\\rm", "\\sf", "\\tt", "\\bf", "\\it", "\\cal"], props: { numArgs: 0, allowedInText: !0 }, handler: (r, e) => { var { parser: t, funcName: a, breakOnTokenText: i } = r, { mode: s } = t, u = t.parseExpression(!0, i); return { type: "font", mode: s, font: "math" + a.slice(1), body: { type: "ordgroup", mode: t.mode, body: u } }; }, htmlBuilder: z1, mathmlBuilder: A1 });
var y4 = (r, e) => { var t = e.style, a = t.fracNum(), i = t.fracDen(), s; s = e.havingStyle(a); var u = X(r.numer, s, e); if (r.continued) {
    var h = 8.5 / e.fontMetrics().ptPerEm, c = 3.5 / e.fontMetrics().ptPerEm;
    u.height = u.height < h ? h : u.height, u.depth = u.depth < c ? c : u.depth;
} s = e.havingStyle(i); var v = X(r.denom, s, e), p, b, x; r.hasBarLine ? (r.barSize ? (b = J(r.barSize, e), p = ae("frac-line", e, b)) : p = ae("frac-line", e), b = p.height, x = p.height) : (p = null, b = 0, x = e.fontMetrics().defaultRuleThickness); var y, T, M; t.size === N.DISPLAY.size ? (y = e.fontMetrics().num1, b > 0 ? T = 3 * x : T = 7 * x, M = e.fontMetrics().denom1) : (b > 0 ? (y = e.fontMetrics().num2, T = x) : (y = e.fontMetrics().num3, T = 3 * x), M = e.fontMetrics().denom2); var q; if (p) {
    var R = e.fontMetrics().axisHeight;
    y - u.depth - (R + .5 * b) < T && (y += T - (y - u.depth - (R + .5 * b))), R - .5 * b - (v.height - M) < T && (M += T - (R - .5 * b - (v.height - M)));
    var F = -(R - .5 * b);
    q = V({ positionType: "individualShift", children: [{ type: "elem", elem: v, shift: M }, { type: "elem", elem: p, shift: F }, { type: "elem", elem: u, shift: -y }] });
}
else {
    var C = y - u.depth - (v.height - M);
    C < T && (y += .5 * (T - C), M += .5 * (T - C)), q = V({ positionType: "individualShift", children: [{ type: "elem", elem: v, shift: M }, { type: "elem", elem: u, shift: -y }] });
} s = e.havingStyle(t), q.height *= s.sizeMultiplier / e.sizeMultiplier, q.depth *= s.sizeMultiplier / e.sizeMultiplier; var L; t.size === N.DISPLAY.size ? L = e.fontMetrics().delim1 : t.size === N.SCRIPTSCRIPT.size ? L = e.havingStyle(N.SCRIPT).fontMetrics().delim2 : L = e.fontMetrics().delim2; var H, P; return r.leftDelim == null ? H = pe(e, ["mopen"]) : H = It(r.leftDelim, L, !0, e.havingStyle(t), r.mode, ["mopen"]), r.continued ? P = k([]) : r.rightDelim == null ? P = pe(e, ["mclose"]) : P = It(r.rightDelim, L, !0, e.havingStyle(t), r.mode, ["mclose"]), k(["mord"].concat(s.sizingClasses(e)), [H, k(["mfrac"], [q]), P], e); }, x4 = (r, e) => { var t = new S("mfrac", [$(r.numer, e), $(r.denom, e)]); if (!r.hasBarLine)
    t.setAttribute("linethickness", "0px");
else if (r.barSize) {
    var a = J(r.barSize, e);
    t.setAttribute("linethickness", A(a));
} if (r.leftDelim != null || r.rightDelim != null) {
    var i = [];
    if (r.leftDelim != null) {
        var s = new S("mo", [new Q(r.leftDelim.replace("\\", ""))]);
        s.setAttribute("fence", "true"), i.push(s);
    }
    if (i.push(t), r.rightDelim != null) {
        var u = new S("mo", [new Q(r.rightDelim.replace("\\", ""))]);
        u.setAttribute("fence", "true"), i.push(u);
    }
    return Xt(i);
} return t; }, M1 = (r, e) => { if (!e)
    return r; var t = { type: "styling", mode: r.mode, style: e, body: [r] }; return t; };
B({ type: "genfrac", names: ["\\cfrac", "\\dfrac", "\\frac", "\\tfrac", "\\dbinom", "\\binom", "\\tbinom", "\\\\atopfrac", "\\\\bracefrac", "\\\\brackfrac"], props: { numArgs: 2, allowedInArgument: !0 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = e[0], s = e[1], u, h = null, c = null; switch (a) {
        case "\\cfrac":
        case "\\dfrac":
        case "\\frac":
        case "\\tfrac":
            u = !0;
            break;
        case "\\\\atopfrac":
            u = !1;
            break;
        case "\\dbinom":
        case "\\binom":
        case "\\tbinom":
            u = !1, h = "(", c = ")";
            break;
        case "\\\\bracefrac":
            u = !1, h = "\\{", c = "\\}";
            break;
        case "\\\\brackfrac":
            u = !1, h = "[", c = "]";
            break;
        default: throw new Error("Unrecognized genfrac command");
    } var v = a === "\\cfrac", p = null; return v || a.startsWith("\\d") ? p = "display" : a.startsWith("\\t") && (p = "text"), M1({ type: "genfrac", mode: t.mode, numer: i, denom: s, continued: v, hasBarLine: u, leftDelim: h, rightDelim: c, barSize: null }, p); }, htmlBuilder: y4, mathmlBuilder: x4 });
B({ type: "infix", names: ["\\over", "\\choose", "\\atop", "\\brace", "\\brack"], props: { numArgs: 0, infix: !0 }, handler(r) { var { parser: e, funcName: t, token: a } = r, i; switch (t) {
        case "\\over":
            i = "\\frac";
            break;
        case "\\choose":
            i = "\\binom";
            break;
        case "\\atop":
            i = "\\\\atopfrac";
            break;
        case "\\brace":
            i = "\\\\bracefrac";
            break;
        case "\\brack":
            i = "\\\\brackfrac";
            break;
        default: throw new Error("Unrecognized infix genfrac command");
    } return { type: "infix", mode: e.mode, replaceWith: i, token: a }; } });
var qr = ["display", "text", "script", "scriptscript"], Er = function (e) { var t = null; return e.length > 0 && (t = e, t = t === "." ? null : t), t; };
B({ type: "genfrac", names: ["\\genfrac"], props: { numArgs: 6, allowedInArgument: !0, argTypes: ["math", "math", "size", "text", "math", "math"] }, handler(r, e) { var { parser: t } = r, a = e[4], i = e[5], s = Ge(e[0]), u = s.type === "atom" && s.family === "open" ? Er(s.text) : null, h = Ge(e[1]), c = h.type === "atom" && h.family === "close" ? Er(h.text) : null, v = O(e[2], "size"), p, b = null; v.isBlank ? p = !0 : (b = v.value, p = b.number > 0); var x = null, y = e[3]; if (y.type === "ordgroup") {
        if (y.body.length > 0) {
            var T = O(y.body[0], "textord");
            x = qr[Number(T.text)];
        }
    }
    else
        y = O(y, "textord"), x = qr[Number(y.text)]; return M1({ type: "genfrac", mode: t.mode, numer: a, denom: i, continued: !1, hasBarLine: p, barSize: b, leftDelim: u, rightDelim: c }, x); } });
B({ type: "infix", names: ["\\above"], props: { numArgs: 1, argTypes: ["size"], infix: !0 }, handler(r, e) { var { parser: t, funcName: a, token: i } = r; return { type: "infix", mode: t.mode, replaceWith: "\\\\abovefrac", size: O(e[0], "size").value, token: i }; } });
B({ type: "genfrac", names: ["\\\\abovefrac"], props: { numArgs: 3, argTypes: ["math", "size", "math"] }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = e[0], s = O(e[1], "infix").size; if (!s)
        throw new Error("\\\\abovefrac expected size, but got " + String(s)); var u = e[2], h = s.number > 0; return { type: "genfrac", mode: t.mode, numer: i, denom: u, continued: !1, hasBarLine: h, barSize: s, leftDelim: null, rightDelim: null }; } });
var T1 = (r, e) => { var t = e.style, a, i; r.type === "supsub" ? (a = r.sup ? X(r.sup, e.havingStyle(t.sup()), e) : X(r.sub, e.havingStyle(t.sub()), e), i = O(r.base, "horizBrace")) : i = O(r, "horizBrace"); var s = X(i.base, e.havingBaseStyle(N.DISPLAY)), u = je(i, e), h; if (i.isOver ? h = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: s }, { type: "kern", size: .1 }, { type: "elem", elem: u, wrapperClasses: ["svg-align"] }] }) : h = V({ positionType: "bottom", positionData: s.depth + .1 + u.height, children: [{ type: "elem", elem: u, wrapperClasses: ["svg-align"] }, { type: "kern", size: .1 }, { type: "elem", elem: s }] }), a) {
    var c = k(["minner", i.isOver ? "mover" : "munder"], [h], e);
    i.isOver ? h = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: c }, { type: "kern", size: .2 }, { type: "elem", elem: a }] }) : h = V({ positionType: "bottom", positionData: c.depth + .2 + a.height + a.depth, children: [{ type: "elem", elem: a }, { type: "kern", size: .2 }, { type: "elem", elem: c }] });
} return k(["minner", i.isOver ? "mover" : "munder"], [h], e); }, w4 = (r, e) => { var t = We(r.label); return new S(r.isOver ? "mover" : "munder", [$(r.base, e), t]); };
B({ type: "horizBrace", names: ["\\overbrace", "\\underbrace", "\\overbracket", "\\underbracket"], props: { numArgs: 1 }, handler(r, e) { var { parser: t, funcName: a } = r; return { type: "horizBrace", mode: t.mode, label: a, isOver: a.includes("\\over"), base: e[0] }; }, htmlBuilder: T1, mathmlBuilder: w4 });
B({ type: "href", names: ["\\href"], props: { numArgs: 2, argTypes: ["url", "original"], allowedInText: !0 }, handler: (r, e) => { var { parser: t } = r, a = e[1], i = O(e[0], "url").url; return t.settings.isTrusted({ command: "\\href", url: i }) ? { type: "href", mode: t.mode, href: i, body: e0(a) } : t.formatUnsupportedCmd("\\href"); }, htmlBuilder: (r, e) => { var t = a0(r.body, e, !1); return Ra(r.href, [], t, e); }, mathmlBuilder: (r, e) => { var t = X0(r.body, e); return t instanceof S || (t = new S("mrow", [t])), t.setAttribute("href", r.href), t; } });
B({ type: "href", names: ["\\url"], props: { numArgs: 1, argTypes: ["url"], allowedInText: !0 }, handler: (r, e) => { var { parser: t } = r, a = O(e[0], "url").url; if (!t.settings.isTrusted({ command: "\\url", url: a }))
        return t.formatUnsupportedCmd("\\url"); for (var i = [], s = 0; s < a.length; s++) {
        var u = a[s];
        u === "~" && (u = "\\textasciitilde"), i.push({ type: "textord", mode: "text", text: u });
    } var h = { type: "text", mode: t.mode, font: "\\texttt", body: i }; return { type: "href", mode: t.mode, href: a, body: e0(h) }; } });
B({ type: "hbox", names: ["\\hbox"], props: { numArgs: 1, argTypes: ["text"], allowedInText: !0, primitive: !0 }, handler(r, e) { var { parser: t } = r; return { type: "hbox", mode: t.mode, body: e0(e[0]) }; }, htmlBuilder(r, e) { var t = a0(r.body, e.withFont(""), !1); return I0(t); }, mathmlBuilder(r, e) { return new S("mrow", v0(r.body, e.withFont(""))); } });
B({ type: "html", names: ["\\htmlClass", "\\htmlId", "\\htmlStyle", "\\htmlData"], props: { numArgs: 2, argTypes: ["raw", "original"], allowedInText: !0 }, handler: (r, e) => { var { parser: t, funcName: a, token: i } = r, s = O(e[0], "raw").string, u = e[1]; t.settings.strict && t.settings.reportNonstrict("htmlExtension", "HTML extension is disabled on strict mode"); var h, c = {}; switch (a) {
        case "\\htmlClass":
            c.class = s, h = { command: "\\htmlClass", class: s };
            break;
        case "\\htmlId":
            c.id = s, h = { command: "\\htmlId", id: s };
            break;
        case "\\htmlStyle":
            c.style = s, h = { command: "\\htmlStyle", style: s };
            break;
        case "\\htmlData": {
            for (var v = s.split(","), p = 0; p < v.length; p++) {
                var b = v[p], x = b.indexOf("=");
                if (x < 0)
                    throw new z("\\htmlData key/value '" + b + "' missing equals sign");
                var y = b.slice(0, x), T = b.slice(x + 1);
                c["data-" + y.trim()] = T;
            }
            h = { command: "\\htmlData", attributes: c };
            break;
        }
        default: throw new Error("Unrecognized html command");
    } return t.settings.isTrusted(h) ? { type: "html", mode: t.mode, attributes: c, body: e0(u) } : t.formatUnsupportedCmd(a); }, htmlBuilder: (r, e) => { var t = a0(r.body, e, !1), a = ["enclosing"]; r.attributes.class && a.push(...r.attributes.class.trim().split(/\s+/)); var i = k(a, t, e); for (var s in r.attributes)
        s !== "class" && r.attributes.hasOwnProperty(s) && i.setAttribute(s, r.attributes[s]); return i; }, mathmlBuilder: (r, e) => X0(r.body, e) });
B({ type: "htmlmathml", names: ["\\html@mathml"], props: { numArgs: 2, allowedInArgument: !0, allowedInText: !0 }, handler: (r, e) => { var { parser: t } = r; return { type: "htmlmathml", mode: t.mode, html: e0(e[0]), mathml: e0(e[1]) }; }, htmlBuilder: (r, e) => { var t = a0(r.html, e, !1); return I0(t); }, mathmlBuilder: (r, e) => X0(r.mathml, e) });
var ft = function (e) { if (/^[-+]? *(\d+(\.\d*)?|\.\d+)$/.test(e))
    return { number: +e, unit: "bp" }; var t = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(e); if (!t)
    throw new z("Invalid size: '" + e + "' in \\includegraphics"); var a = { number: +(t[1] + t[2]), unit: t[3] }; if (!Yr(a))
    throw new z("Invalid unit: '" + a.unit + "' in \\includegraphics."); return a; };
B({ type: "includegraphics", names: ["\\includegraphics"], props: { numArgs: 1, numOptionalArgs: 1, argTypes: ["raw", "url"], allowedInText: !1 }, handler: (r, e, t) => { var { parser: a } = r, i = { number: 0, unit: "em" }, s = { number: .9, unit: "em" }, u = { number: 0, unit: "em" }, h = ""; if (t[0])
        for (var c = O(t[0], "raw").string, v = c.split(","), p = 0; p < v.length; p++) {
            var b = v[p].split("=");
            if (b.length === 2) {
                var x = b[1].trim();
                switch (b[0].trim()) {
                    case "alt":
                        h = x;
                        break;
                    case "width":
                        i = ft(x);
                        break;
                    case "height":
                        s = ft(x);
                        break;
                    case "totalheight":
                        u = ft(x);
                        break;
                    default: throw new z("Invalid key: '" + b[0] + "' in \\includegraphics.");
                }
            }
        } var y = O(e[0], "url").url; return h === "" && (h = y, h = h.replace(/^.*[\\/]/, ""), h = h.substring(0, h.lastIndexOf("."))), a.settings.isTrusted({ command: "\\includegraphics", url: y }) ? { type: "includegraphics", mode: a.mode, alt: h, width: i, height: s, totalheight: u, src: y } : a.formatUnsupportedCmd("\\includegraphics"); }, htmlBuilder: (r, e) => { var t = J(r.height, e), a = 0; r.totalheight.number > 0 && (a = J(r.totalheight, e) - t); var i = 0; r.width.number > 0 && (i = J(r.width, e)); var s = { height: A(t + a) }; i > 0 && (s.width = A(i)), a > 0 && (s.verticalAlign = A(-a)); var u = new wt(r.src, r.alt, s); return u.height = t, u.depth = a, u; }, mathmlBuilder: (r, e) => { var t = new S("mglyph", []); t.setAttribute("alt", r.alt); var a = J(r.height, e), i = 0; if (r.totalheight.number > 0 && (i = J(r.totalheight, e) - a, t.setAttribute("valign", A(-i))), t.setAttribute("height", A(a + i)), r.width.number > 0) {
        var s = J(r.width, e);
        t.setAttribute("width", A(s));
    } return t.setAttribute("src", r.src), t; } });
B({ type: "kern", names: ["\\kern", "\\mkern", "\\hskip", "\\mskip"], props: { numArgs: 1, argTypes: ["size"], primitive: !0, allowedInText: !0 }, handler(r, e) { var { parser: t, funcName: a } = r, i = O(e[0], "size"); if (t.settings.strict) {
        var s = a[1] === "m", u = i.value.unit === "mu";
        s ? (u || t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " supports only mu units, " + ("not " + i.value.unit + " units")), t.mode !== "math" && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " works only in math mode")) : u && t.settings.reportNonstrict("mathVsTextUnits", "LaTeX's " + a + " doesn't support mu units");
    } return { type: "kern", mode: t.mode, dimension: i.value }; }, htmlBuilder(r, e) { return Jr(r.dimension, e); }, mathmlBuilder(r, e) { var t = J(r.dimension, e); return new Ue(t); } });
B({ type: "lap", names: ["\\mathllap", "\\mathrlap", "\\mathclap"], props: { numArgs: 1, allowedInText: !0 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = e[0]; return { type: "lap", mode: t.mode, alignment: a.slice(5), body: i }; }, htmlBuilder: (r, e) => { var t; r.alignment === "clap" ? (t = k([], [X(r.body, e)]), t = k(["inner"], [t], e)) : t = k(["inner"], [X(r.body, e)]); var a = k(["fix"], []), i = k([r.alignment], [t, a], e), s = k(["strut"]); return s.style.height = A(i.height + i.depth), i.depth && (s.style.verticalAlign = A(-i.depth)), i.children.unshift(s), i = k(["thinbox"], [i], e), k(["mord", "vbox"], [i], e); }, mathmlBuilder: (r, e) => { var t = new S("mpadded", [$(r.body, e)]); if (r.alignment !== "rlap") {
        var a = r.alignment === "llap" ? "-1" : "-0.5";
        t.setAttribute("lspace", a + "width");
    } return t.setAttribute("width", "0px"), t; } });
B({ type: "styling", names: ["\\(", "$"], props: { numArgs: 0, allowedInText: !0, allowedInMath: !1 }, handler(r, e) { var { funcName: t, parser: a } = r, i = a.mode; a.switchMode("math"); var s = t === "\\(" ? "\\)" : "$", u = a.parseExpression(!1, s); return a.expect(s), a.switchMode(i), { type: "styling", mode: a.mode, style: "text", resetFont: !0, body: u }; } });
B({ type: "text", names: ["\\)", "\\]"], props: { numArgs: 0, allowedInText: !0, allowedInMath: !1 }, handler(r, e) { throw new z("Mismatched " + r.funcName); } });
var Rr = (r, e) => { switch (e.style.size) {
    case N.DISPLAY.size: return r.display;
    case N.TEXT.size: return r.text;
    case N.SCRIPT.size: return r.script;
    case N.SCRIPTSCRIPT.size: return r.scriptscript;
    default: return r.text;
} };
B({ type: "mathchoice", names: ["\\mathchoice"], props: { numArgs: 4, primitive: !0 }, handler: (r, e) => { var { parser: t } = r; return { type: "mathchoice", mode: t.mode, display: e0(e[0]), text: e0(e[1]), script: e0(e[2]), scriptscript: e0(e[3]) }; }, htmlBuilder: (r, e) => { var t = Rr(r, e), a = a0(t, e, !1); return I0(a); }, mathmlBuilder: (r, e) => { var t = Rr(r, e); return X0(t, e); } });
var B1 = (r, e, t, a, i, s, u) => { r = k([], [r]); var h = t && E0(t), c, v; if (e) {
    var p = X(e, a.havingStyle(i.sup()), a);
    v = { elem: p, kern: Math.max(a.fontMetrics().bigOpSpacing1, a.fontMetrics().bigOpSpacing3 - p.depth) };
} if (t) {
    var b = X(t, a.havingStyle(i.sub()), a);
    c = { elem: b, kern: Math.max(a.fontMetrics().bigOpSpacing2, a.fontMetrics().bigOpSpacing4 - b.height) };
} var x; if (v && c) {
    var y = a.fontMetrics().bigOpSpacing5 + c.elem.height + c.elem.depth + c.kern + r.depth + u;
    x = V({ positionType: "bottom", positionData: y, children: [{ type: "kern", size: a.fontMetrics().bigOpSpacing5 }, { type: "elem", elem: c.elem, marginLeft: A(-s) }, { type: "kern", size: c.kern }, { type: "elem", elem: r }, { type: "kern", size: v.kern }, { type: "elem", elem: v.elem, marginLeft: A(s) }, { type: "kern", size: a.fontMetrics().bigOpSpacing5 }] });
}
else if (c) {
    var T = r.height - u;
    x = V({ positionType: "top", positionData: T, children: [{ type: "kern", size: a.fontMetrics().bigOpSpacing5 }, { type: "elem", elem: c.elem, marginLeft: A(-s) }, { type: "kern", size: c.kern }, { type: "elem", elem: r }] });
}
else if (v) {
    var M = r.depth + u;
    x = V({ positionType: "bottom", positionData: M, children: [{ type: "elem", elem: r }, { type: "kern", size: v.kern }, { type: "elem", elem: v.elem, marginLeft: A(s) }, { type: "kern", size: a.fontMetrics().bigOpSpacing5 }] });
}
else
    return r; var q = [x]; if (c && s !== 0 && !h) {
    var C = k(["mspace"], [], a);
    C.style.marginRight = A(s), q.unshift(C);
} return k(["mop", "op-limits"], q, a); }, C1 = new Set(["\\smallint"]), se = (r, e) => { var t, a, i = !1, s; r.type === "supsub" ? (t = r.sup, a = r.sub, s = O(r.base, "op"), i = !0) : s = O(r, "op"); var u = e.style, h = !1; u.size === N.DISPLAY.size && s.symbol && !C1.has(s.name) && (h = !0); var c, v; if (s.symbol) {
    var p = h ? "Size2-Regular" : "Size1-Regular", b = "";
    if ((s.name === "\\oiint" || s.name === "\\oiiint") && (b = s.name.slice(1), s.name = b === "oiint" ? "\\iint" : "\\iiint"), c = s0(s.name, p, "math", e, ["mop", "op-symbol", h ? "large-op" : "small-op"]), v = c.italic, b.length > 0) {
        var x = _r(b + "Size" + (h ? "2" : "1"), e);
        c = V({ positionType: "individualShift", children: [{ type: "elem", elem: c, shift: 0 }, { type: "elem", elem: x, shift: h ? .08 : 0 }] }), s.name = "\\" + b, c.classes.unshift("mop"), c.italic = v;
    }
}
else if (s.body) {
    var y = a0(s.body, e, !0);
    y.length === 1 && y[0] instanceof u0 ? (c = y[0], c.classes[0] = "mop") : c = k(["mop"], y, e);
}
else {
    for (var T = [], M = 1; M < s.name.length; M++)
        T.push(Ut(s.name[M], s.mode, e));
    c = k(["mop"], T, e);
} var q = 0, C = 0; if ((c instanceof u0 || s.name === "\\oiint" || s.name === "\\oiiint") && !s.suppressBaseShift) {
    var R;
    q = (c.height - c.depth) / 2 - e.fontMetrics().axisHeight, C = (R = c.italic) != null ? R : 0;
} return i ? B1(c, t, a, e, u, C, q) : (q && (c.style.position = "relative", c.style.top = A(q)), c); }, be = (r, e) => { var t; if (r.symbol)
    t = new S("mo", [g0(r.name, r.mode)]), C1.has(r.name) && t.setAttribute("largeop", "false");
else if (r.body)
    t = new S("mo", v0(r.body, e));
else {
    t = new S("mi", [new Q(r.name.slice(1))]);
    var a = new S("mo", [g0("\u2061", "text")]);
    r.parentIsSupSub ? t = new S("mrow", [t, a]) : t = r1([t, a]);
} return t; }, k4 = { "\u220F": "\\prod", "\u2210": "\\coprod", "\u2211": "\\sum", "\u22C0": "\\bigwedge", "\u22C1": "\\bigvee", "\u22C2": "\\bigcap", "\u22C3": "\\bigcup", "\u2A00": "\\bigodot", "\u2A01": "\\bigoplus", "\u2A02": "\\bigotimes", "\u2A04": "\\biguplus", "\u2A06": "\\bigsqcup" };
B({ type: "op", names: ["\\coprod", "\\bigvee", "\\bigwedge", "\\biguplus", "\\bigcap", "\\bigcup", "\\intop", "\\prod", "\\sum", "\\bigotimes", "\\bigoplus", "\\bigodot", "\\bigsqcup", "\\smallint", "\u220F", "\u2210", "\u2211", "\u22C0", "\u22C1", "\u22C2", "\u22C3", "\u2A00", "\u2A01", "\u2A02", "\u2A04", "\u2A06"], props: { numArgs: 0 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = a; return i.length === 1 && (i = k4[i]), { type: "op", mode: t.mode, limits: !0, parentIsSupSub: !1, symbol: !0, name: i }; }, htmlBuilder: se, mathmlBuilder: be });
B({ type: "op", names: ["\\mathop"], props: { numArgs: 1, primitive: !0 }, handler: (r, e) => { var { parser: t } = r, a = e[0]; return { type: "op", mode: t.mode, limits: !1, parentIsSupSub: !1, symbol: !1, body: e0(a) }; }, htmlBuilder: se, mathmlBuilder: be });
var S4 = { "\u222B": "\\int", "\u222C": "\\iint", "\u222D": "\\iiint", "\u222E": "\\oint", "\u222F": "\\oiint", "\u2230": "\\oiiint" };
B({ type: "op", names: ["\\arcsin", "\\arccos", "\\arctan", "\\arctg", "\\arcctg", "\\arg", "\\ch", "\\cos", "\\cosec", "\\cosh", "\\cot", "\\cotg", "\\coth", "\\csc", "\\ctg", "\\cth", "\\deg", "\\dim", "\\exp", "\\hom", "\\ker", "\\lg", "\\ln", "\\log", "\\sec", "\\sin", "\\sinh", "\\sh", "\\tan", "\\tanh", "\\tg", "\\th"], props: { numArgs: 0 }, handler(r) { var { parser: e, funcName: t } = r; return { type: "op", mode: e.mode, limits: !1, parentIsSupSub: !1, symbol: !1, name: t }; }, htmlBuilder: se, mathmlBuilder: be });
B({ type: "op", names: ["\\det", "\\gcd", "\\inf", "\\lim", "\\max", "\\min", "\\Pr", "\\sup"], props: { numArgs: 0 }, handler(r) { var { parser: e, funcName: t } = r; return { type: "op", mode: e.mode, limits: !0, parentIsSupSub: !1, symbol: !1, name: t }; }, htmlBuilder: se, mathmlBuilder: be });
B({ type: "op", names: ["\\int", "\\iint", "\\iiint", "\\oint", "\\oiint", "\\oiiint", "\u222B", "\u222C", "\u222D", "\u222E", "\u222F", "\u2230"], props: { numArgs: 0, allowedInArgument: !0 }, handler(r) { var { parser: e, funcName: t } = r, a = t; return a.length === 1 && (a = S4[a]), { type: "op", mode: e.mode, limits: !1, parentIsSupSub: !1, symbol: !0, name: a }; }, htmlBuilder: se, mathmlBuilder: be });
var D1 = (r, e) => { var t, a, i = !1, s; r.type === "supsub" ? (t = r.sup, a = r.sub, s = O(r.base, "operatorname"), i = !0) : s = O(r, "operatorname"); var u; if (s.body.length > 0) {
    for (var h = s.body.map(b => { var x = "text" in b ? b.text : void 0; return typeof x == "string" ? { type: "textord", mode: b.mode, text: x } : b; }), c = a0(h, e.withFont("mathrm"), !0), v = 0; v < c.length; v++) {
        var p = c[v];
        p instanceof u0 && (p.text = p.text.replace(/\u2212/, "-").replace(/\u2217/, "*"));
    }
    u = k(["mop"], c, e);
}
else
    u = k(["mop"], [], e); return i ? B1(u, t, a, e, e.style, 0, 0) : u; }, z4 = (r, e) => { for (var t = v0(r.body, e.withFont("mathrm")), a = !0, i = 0; i < t.length; i++) {
    var s = t[i];
    if (!(s instanceof Ue))
        if (s instanceof S)
            switch (s.type) {
                case "mi":
                case "mn":
                case "mspace":
                case "mtext": break;
                case "mo": {
                    var u = s.children[0];
                    s.children.length === 1 && u instanceof Q ? u.text = u.text.replace(/\u2212/, "-").replace(/\u2217/, "*") : a = !1;
                    break;
                }
                default: a = !1;
            }
        else
            a = !1;
} if (a) {
    var h = t.map(p => p.toText()).join("");
    t = [new Q(h)];
} var c = new S("mi", t); c.setAttribute("mathvariant", "normal"); var v = new S("mo", [g0("\u2061", "text")]); return r.parentIsSupSub ? new S("mrow", [c, v]) : r1([c, v]); };
B({ type: "operatorname", names: ["\\operatorname@", "\\operatornamewithlimits"], props: { numArgs: 1 }, handler: (r, e) => { var { parser: t, funcName: a } = r, i = e[0]; return { type: "operatorname", mode: t.mode, body: e0(i), alwaysHandleSupSub: a === "\\operatornamewithlimits", limits: !1, parentIsSupSub: !1 }; }, htmlBuilder: D1, mathmlBuilder: z4 });
m("\\operatorname", "\\@ifstar\\operatornamewithlimits\\operatorname@");
j0({ type: "ordgroup", htmlBuilder(r, e) { return r.semisimple ? I0(a0(r.body, e, !1)) : k(["mord"], a0(r.body, e, !0), e); }, mathmlBuilder(r, e) { return X0(r.body, e, !0); } });
B({ type: "overline", names: ["\\overline"], props: { numArgs: 1 }, handler(r, e) { var { parser: t } = r, a = e[0]; return { type: "overline", mode: t.mode, body: a }; }, htmlBuilder(r, e) { var t = X(r.body, e.havingCrampedStyle()), a = ae("overline-line", e), i = e.fontMetrics().defaultRuleThickness, s = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: t }, { type: "kern", size: 3 * i }, { type: "elem", elem: a }, { type: "kern", size: i }] }); return k(["mord", "overline"], [s], e); }, mathmlBuilder(r, e) { var t = new S("mo", [new Q("\u203E")]); t.setAttribute("stretchy", "true"); var a = new S("mover", [$(r.body, e), t]); return a.setAttribute("accent", "true"), a; } });
B({ type: "phantom", names: ["\\phantom"], props: { numArgs: 1, allowedInText: !0 }, handler: (r, e) => { var { parser: t } = r, a = e[0]; return { type: "phantom", mode: t.mode, body: e0(a) }; }, htmlBuilder: (r, e) => { var t = a0(r.body, e.withPhantom(), !1); return I0(t); }, mathmlBuilder: (r, e) => { var t = v0(r.body, e); return new S("mphantom", t); } });
m("\\hphantom", "\\smash{\\phantom{#1}}");
B({ type: "vphantom", names: ["\\vphantom"], props: { numArgs: 1, allowedInText: !0 }, handler: (r, e) => { var { parser: t } = r, a = e[0]; return { type: "vphantom", mode: t.mode, body: a }; }, htmlBuilder: (r, e) => { var t = k(["inner"], [X(r.body, e.withPhantom())]), a = k(["fix"], []); return k(["mord", "rlap"], [t, a], e); }, mathmlBuilder: (r, e) => { var t = v0(e0(r.body), e), a = new S("mphantom", t), i = new S("mpadded", [a]); return i.setAttribute("width", "0px"), i; } });
B({ type: "raisebox", names: ["\\raisebox"], props: { numArgs: 2, argTypes: ["size", "hbox"], allowedInText: !0 }, handler(r, e) { var { parser: t } = r, a = O(e[0], "size").value, i = e[1]; return { type: "raisebox", mode: t.mode, dy: a, body: i }; }, htmlBuilder(r, e) { var t = X(r.body, e), a = J(r.dy, e); return V({ positionType: "shift", positionData: -a, children: [{ type: "elem", elem: t }] }); }, mathmlBuilder(r, e) { var t = new S("mpadded", [$(r.body, e)]), a = r.dy.number + r.dy.unit; return t.setAttribute("voffset", a), t; } });
B({ type: "internal", names: ["\\relax"], props: { numArgs: 0, allowedInText: !0, allowedInArgument: !0 }, handler(r) { var { parser: e } = r; return { type: "internal", mode: e.mode }; } });
B({ type: "rule", names: ["\\rule"], props: { numArgs: 2, numOptionalArgs: 1, allowedInText: !0, allowedInMath: !0, argTypes: ["size", "size", "size"] }, handler(r, e, t) { var { parser: a } = r, i = t[0], s = O(e[0], "size"), u = O(e[1], "size"); return { type: "rule", mode: a.mode, shift: i && O(i, "size").value, width: s.value, height: u.value }; }, htmlBuilder(r, e) { var t = k(["mord", "rule"], [], e), a = J(r.width, e), i = J(r.height, e), s = r.shift ? J(r.shift, e) : 0; return t.style.borderRightWidth = A(a), t.style.borderTopWidth = A(i), t.style.bottom = A(s), t.width = a, t.height = i + s, t.depth = -s, t.maxFontSize = i * 1.125 * e.sizeMultiplier, t; }, mathmlBuilder(r, e) { var t = J(r.width, e), a = J(r.height, e), i = r.shift ? J(r.shift, e) : 0, s = e.color && e.getColor() || "black", u = new S("mspace"); u.setAttribute("mathbackground", s), u.setAttribute("width", A(t)), u.setAttribute("height", A(a)); var h = new S("mpadded", [u]); return i >= 0 ? h.setAttribute("height", A(i)) : (h.setAttribute("height", A(i)), h.setAttribute("depth", A(-i))), h.setAttribute("voffset", A(i)), h; } });
function q1(r, e, t) { for (var a = a0(r, e, !1), i = e.sizeMultiplier / t.sizeMultiplier, s = 0; s < a.length; s++) {
    var u = a[s].classes.indexOf("sizing");
    u < 0 ? Array.prototype.push.apply(a[s].classes, e.sizingClasses(t)) : a[s].classes[u + 1] === "reset-size" + e.size && (a[s].classes[u + 1] = "reset-size" + t.size), a[s].height *= i, a[s].depth *= i;
} return I0(a); }
var Ir = ["\\tiny", "\\sixptsize", "\\scriptsize", "\\footnotesize", "\\small", "\\normalsize", "\\large", "\\Large", "\\LARGE", "\\huge", "\\Huge"], A4 = (r, e) => { var t = e.havingSize(r.size); return q1(r.body, t, e); };
B({ type: "sizing", names: Ir, props: { numArgs: 0, allowedInText: !0 }, handler: (r, e) => { var { breakOnTokenText: t, funcName: a, parser: i } = r, s = i.parseExpression(!1, t); return { type: "sizing", mode: i.mode, size: Ir.indexOf(a) + 1, body: s }; }, htmlBuilder: A4, mathmlBuilder: (r, e) => { var t = e.havingSize(r.size), a = v0(r.body, t), i = new S("mstyle", a); return i.setAttribute("mathsize", A(t.sizeMultiplier)), i; } });
B({ type: "smash", names: ["\\smash"], props: { numArgs: 1, numOptionalArgs: 1, allowedInText: !0 }, handler: (r, e, t) => { var { parser: a } = r, i = !1, s = !1, u = t[0] && O(t[0], "ordgroup"); if (u)
        for (var h, c = 0; c < u.body.length; ++c) {
            var v = u.body[c];
            if (h = Ze(v).text, h === "t")
                i = !0;
            else if (h === "b")
                s = !0;
            else {
                i = !1, s = !1;
                break;
            }
        }
    else
        i = !0, s = !0; var p = e[0]; return { type: "smash", mode: a.mode, body: p, smashHeight: i, smashDepth: s }; }, htmlBuilder: (r, e) => { var t = k([], [X(r.body, e)]); if (!r.smashHeight && !r.smashDepth)
        return t; if (r.smashHeight && (t.height = 0), r.smashDepth && (t.depth = 0), r.smashHeight && r.smashDepth)
        return k(["mord", "smash"], [t], e); if (t.children)
        for (var a = 0; a < t.children.length; a++)
            r.smashHeight && (t.children[a].height = 0), r.smashDepth && (t.children[a].depth = 0); var i = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: t }] }); return k(["mord"], [i], e); }, mathmlBuilder: (r, e) => { var t = new S("mpadded", [$(r.body, e)]); return r.smashHeight && t.setAttribute("height", "0px"), r.smashDepth && t.setAttribute("depth", "0px"), t; } });
B({ type: "sqrt", names: ["\\sqrt"], props: { numArgs: 1, numOptionalArgs: 1 }, handler(r, e, t) { var { parser: a } = r, i = t[0], s = e[0]; return { type: "sqrt", mode: a.mode, body: s, index: i }; }, htmlBuilder(r, e) { var t = X(r.body, e.havingCrampedStyle()); t.height === 0 && (t.height = e.fontMetrics().xHeight), t = ie(t, e); var a = e.fontMetrics(), i = a.defaultRuleThickness, s = i; e.style.id < N.TEXT.id && (s = e.fontMetrics().xHeight); var u = i + s / 4, h = t.height + t.depth + u + i, { span: c, ruleWidth: v, advanceWidth: p } = m4(h, e), b = c.height - v; b > t.height + t.depth + u && (u = (u + b - t.height - t.depth) / 2); var x = c.height - t.height - u - v; t.style.paddingLeft = A(p); var y = V({ positionType: "firstBaseline", children: [{ type: "elem", elem: t, wrapperClasses: ["svg-align"] }, { type: "kern", size: -(t.height + x) }, { type: "elem", elem: c }, { type: "kern", size: v }] }); if (r.index) {
        var T = e.havingStyle(N.SCRIPTSCRIPT), M = X(r.index, T, e), q = .6 * (y.height - y.depth), C = V({ positionType: "shift", positionData: -q, children: [{ type: "elem", elem: M }] }), R = k(["root"], [C]);
        return k(["mord", "sqrt"], [R, y], e);
    }
    else
        return k(["mord", "sqrt"], [y], e); }, mathmlBuilder(r, e) { var { body: t, index: a } = r; return a ? new S("mroot", [$(t, e), $(a, e)]) : new S("msqrt", [$(t, e)]); } });
var Nt = { display: N.DISPLAY, text: N.TEXT, script: N.SCRIPT, scriptscript: N.SCRIPTSCRIPT };
function M4(r) { return r in Nt; }
B({ type: "styling", names: ["\\displaystyle", "\\textstyle", "\\scriptstyle", "\\scriptscriptstyle"], props: { numArgs: 0, allowedInText: !0, primitive: !0 }, handler(r, e) { var { breakOnTokenText: t, funcName: a, parser: i } = r, s = i.parseExpression(!0, t), u = a.slice(1, a.length - 5); if (!M4(u))
        throw new Error("Unknown style: " + u); return { type: "styling", mode: i.mode, style: u, body: s }; }, htmlBuilder(r, e) { var t = Nt[r.style], a = e.havingStyle(t); return r.resetFont && (a = a.withFont("")), q1(r.body, a, e); }, mathmlBuilder(r, e) { var t = Nt[r.style], a = e.havingStyle(t); r.resetFont && (a = a.withFont("")); var i = v0(r.body, a), s = new S("mstyle", i), u = { display: ["0", "true"], text: ["0", "false"], script: ["1", "false"], scriptscript: ["2", "false"] }, h = u[r.style]; return s.setAttribute("scriptlevel", h[0]), s.setAttribute("displaystyle", h[1]), s; } });
var T4 = function (e, t) { var a = e.base; if (a)
    if (a.type === "op") {
        var i = a.limits && (t.style.size === N.DISPLAY.size || a.alwaysHandleSupSub);
        return i ? se : null;
    }
    else if (a.type === "operatorname") {
        var s = a.alwaysHandleSupSub && (t.style.size === N.DISPLAY.size || a.limits);
        return s ? D1 : null;
    }
    else {
        if (a.type === "accent")
            return E0(a.base) ? $t : null;
        if (a.type === "horizBrace") {
            var u = !e.sub;
            return u === a.isOver ? T1 : null;
        }
        else
            return null;
    }
else
    return null; };
j0({ type: "supsub", htmlBuilder(r, e) { var t = T4(r, e); if (t)
        return t(r, e); var { base: a, sup: i, sub: s } = r, u = X(a, e), h, c, v = e.fontMetrics(), p = 0, b = 0, x = a && E0(a); if (i) {
        var y = e.havingStyle(e.style.sup());
        h = X(i, y, e), x || (p = u.height - y.fontMetrics().supDrop * y.sizeMultiplier / e.sizeMultiplier);
    } if (s) {
        var T = e.havingStyle(e.style.sub());
        c = X(s, T, e), x || (b = u.depth + T.fontMetrics().subDrop * T.sizeMultiplier / e.sizeMultiplier);
    } var M; e.style === N.DISPLAY ? M = v.sup1 : e.style.cramped ? M = v.sup3 : M = v.sup2; var q = e.sizeMultiplier, C = A(.5 / v.ptPerEm / q), R = null; if (c) {
        var F = r.base && r.base.type === "op" && r.base.name && (r.base.name === "\\oiint" || r.base.name === "\\oiiint");
        if (u instanceof u0 || F) {
            var L;
            R = A(-((L = u.italic) != null ? L : 0));
        }
    } var H; if (h && c) {
        p = Math.max(p, M, h.depth + .25 * v.xHeight), b = Math.max(b, v.sub2);
        var P = v.defaultRuleThickness, G = 4 * P;
        if (p - h.depth - (c.height - b) < G) {
            b = G - (p - h.depth) + c.height;
            var Y = .8 * v.xHeight - (p - h.depth);
            Y > 0 && (p += Y, b -= Y);
        }
        var U = [{ type: "elem", elem: c, shift: b, marginRight: C, marginLeft: R }, { type: "elem", elem: h, shift: -p, marginRight: C }];
        H = V({ positionType: "individualShift", children: U });
    }
    else if (c) {
        b = Math.max(b, v.sub1, c.height - .8 * v.xHeight);
        var h0 = [{ type: "elem", elem: c, marginLeft: R, marginRight: C }];
        H = V({ positionType: "shift", positionData: b, children: h0 });
    }
    else if (h)
        p = Math.max(p, M, h.depth + .25 * v.xHeight), H = V({ positionType: "shift", positionData: -p, children: [{ type: "elem", elem: h, marginRight: C }] });
    else
        throw new Error("supsub must have either sup or sub."); var c0 = Dt(u, "right") || "mord"; return k([c0], [u, k(["msupsub"], [H])], e); }, mathmlBuilder(r, e) { var t = !1, a, i; r.base && r.base.type === "horizBrace" && (i = !!r.sup, i === r.base.isOver && (t = !0, a = r.base.isOver)), r.base && (r.base.type === "op" || r.base.type === "operatorname") && (r.base.parentIsSupSub = !0); var s = [$(r.base, e)]; r.sub && s.push($(r.sub, e)), r.sup && s.push($(r.sup, e)); var u; if (t)
        u = a ? "mover" : "munder";
    else if (r.sub)
        if (r.sup) {
            var v = r.base;
            v && v.type === "op" && v.limits && e.style === N.DISPLAY || v && v.type === "operatorname" && v.alwaysHandleSupSub && (e.style === N.DISPLAY || v.limits) ? u = "munderover" : u = "msubsup";
        }
        else {
            var c = r.base;
            c && c.type === "op" && c.limits && (e.style === N.DISPLAY || c.alwaysHandleSupSub) || c && c.type === "operatorname" && c.alwaysHandleSupSub && (c.limits || e.style === N.DISPLAY) ? u = "munder" : u = "msub";
        }
    else {
        var h = r.base;
        h && h.type === "op" && h.limits && (e.style === N.DISPLAY || h.alwaysHandleSupSub) || h && h.type === "operatorname" && h.alwaysHandleSupSub && (h.limits || e.style === N.DISPLAY) ? u = "mover" : u = "msup";
    } return new S(u, s); } });
j0({ type: "atom", htmlBuilder(r, e) { return Ut(r.text, r.mode, e, ["m" + r.family]); }, mathmlBuilder(r, e) { var t = new S("mo", [g0(r.text, r.mode)]); if (r.family === "bin") {
        var a = Yt(r, e);
        a === "bold-italic" && t.setAttribute("mathvariant", a);
    }
    else
        r.family === "punct" ? t.setAttribute("separator", "true") : (r.family === "open" || r.family === "close") && t.setAttribute("stretchy", "false"); return t; } });
var E1 = { mi: "italic", mn: "normal", mtext: "normal" };
j0({ type: "mathord", htmlBuilder(r, e) { return $e(r, e, "mathord"); }, mathmlBuilder(r, e) { var t = new S("mi", [g0(r.text, r.mode, e)]), a = Yt(r, e) || "italic"; return a !== E1[t.type] && t.setAttribute("mathvariant", a), t; } });
j0({ type: "textord", htmlBuilder(r, e) { return $e(r, e, "textord"); }, mathmlBuilder(r, e) { var t = g0(r.text, r.mode, e), a = Yt(r, e) || "normal", i; return r.mode === "text" ? i = new S("mtext", [t]) : /[0-9]/.test(r.text) ? i = new S("mn", [t]) : r.text === "\\prime" ? i = new S("mo", [t]) : i = new S("mi", [t]), a !== E1[i.type] && i.setAttribute("mathvariant", a), i; } });
var vt = { "\\nobreak": "nobreak", "\\allowbreak": "allowbreak" }, pt = { " ": {}, "\\ ": {}, "~": { className: "nobreak" }, "\\space": {}, "\\nobreakspace": { className: "nobreak" } };
j0({ type: "spacing", htmlBuilder(r, e) { if (pt.hasOwnProperty(r.text)) {
        var t = pt[r.text].className || "";
        if (r.mode === "text") {
            var a = $e(r, e, "textord");
            return a.classes.push(t), a;
        }
        else
            return k(["mspace", t], [Ut(r.text, r.mode, e)], e);
    }
    else {
        if (vt.hasOwnProperty(r.text))
            return k(["mspace", vt[r.text]], [], e);
        throw new z('Unknown type of space "' + r.text + '"');
    } }, mathmlBuilder(r, e) { var t; if (pt.hasOwnProperty(r.text))
        t = new S("mtext", [new Q("\xA0")]);
    else {
        if (vt.hasOwnProperty(r.text))
            return new S("mspace");
        throw new z('Unknown type of space "' + r.text + '"');
    } return t; } });
var Nr = () => { var r = new S("mtd", []); return r.setAttribute("width", "50%"), r; };
j0({ type: "tag", mathmlBuilder(r, e) { var t = new S("mtable", [new S("mtr", [Nr(), new S("mtd", [X0(r.body, e)]), Nr(), new S("mtd", [X0(r.tag, e)])])]); return t.setAttribute("width", "100%"), t; } });
var Fr = { "\\text": void 0, "\\textrm": "textrm", "\\textsf": "textsf", "\\texttt": "texttt", "\\textnormal": "textrm" }, Or = { "\\textbf": "textbf", "\\textmd": "textmd" }, B4 = { "\\textit": "textit", "\\textup": "textup" }, Hr = (r, e) => { var t = r.font; if (t) {
    if (Fr[t])
        return e.withTextFontFamily(Fr[t]);
    if (Or[t])
        return e.withTextFontWeight(Or[t]);
    if (t === "\\emph")
        return e.fontShape === "textit" ? e.withTextFontShape("textup") : e.withTextFontShape("textit");
}
else
    return e; return e.withTextFontShape(B4[t]); };
B({ type: "text", names: ["\\text", "\\textrm", "\\textsf", "\\texttt", "\\textnormal", "\\textbf", "\\textmd", "\\textit", "\\textup", "\\emph"], props: { numArgs: 1, argTypes: ["text"], allowedInArgument: !0, allowedInText: !0 }, handler(r, e) { var { parser: t, funcName: a } = r, i = e[0]; return { type: "text", mode: t.mode, body: e0(i), font: a }; }, htmlBuilder(r, e) { var t = Hr(r, e), a = a0(r.body, t, !0); return k(["mord", "text"], a, t); }, mathmlBuilder(r, e) { var t = Hr(r, e); return X0(r.body, t); } });
B({ type: "underline", names: ["\\underline"], props: { numArgs: 1, allowedInText: !0 }, handler(r, e) { var { parser: t } = r; return { type: "underline", mode: t.mode, body: e[0] }; }, htmlBuilder(r, e) { var t = X(r.body, e), a = ae("underline-line", e), i = e.fontMetrics().defaultRuleThickness, s = V({ positionType: "top", positionData: t.height, children: [{ type: "kern", size: i }, { type: "elem", elem: a }, { type: "kern", size: 3 * i }, { type: "elem", elem: t }] }); return k(["mord", "underline"], [s], e); }, mathmlBuilder(r, e) { var t = new S("mo", [new Q("\u203E")]); t.setAttribute("stretchy", "true"); var a = new S("munder", [$(r.body, e), t]); return a.setAttribute("accentunder", "true"), a; } });
B({ type: "vcenter", names: ["\\vcenter"], props: { numArgs: 1, argTypes: ["original"], allowedInText: !1 }, handler(r, e) { var { parser: t } = r; return { type: "vcenter", mode: t.mode, body: e[0] }; }, htmlBuilder(r, e) { var t = X(r.body, e), a = e.fontMetrics().axisHeight, i = .5 * (t.height - a - (t.depth + a)); return V({ positionType: "shift", positionData: i, children: [{ type: "elem", elem: t }] }); }, mathmlBuilder(r, e) { var t = new S("mpadded", [$(r.body, e)], ["vcenter"]); return new S("mrow", [t]); } });
B({ type: "verb", names: ["\\verb"], props: { numArgs: 0, allowedInText: !0 }, handler(r, e, t) { throw new z("\\verb ended by end of line instead of matching delimiter"); }, htmlBuilder(r, e) { for (var t = Lr(r), a = [], i = e.havingStyle(e.style.text()), s = 0; s < t.length; s++) {
        var u = t[s];
        u === "~" && (u = "\\textasciitilde"), a.push(s0(u, "Typewriter-Regular", r.mode, i, ["mord", "texttt"]));
    } return k(["mord", "text"].concat(i.sizingClasses(e)), Kr(a), i); }, mathmlBuilder(r, e) { var t = new Q(Lr(r)), a = new S("mtext", [t]); return a.setAttribute("mathvariant", "monospace"), a; } });
var Lr = r => r.body.replace(/ /g, r.star ? "\u2423" : "\xA0"), L0 = e1, R1 = `[ \r
	]`, C4 = "\\\\[a-zA-Z@]+", D4 = "\\\\[^\uD800-\uDFFF]", q4 = "(" + C4 + ")" + R1 + "*", E4 = `\\\\(
|[ \r	]+
?)[ \r	]*`, Ft = "[\u0300-\u036F]", R4 = new RegExp(Ft + "+$"), I4 = "(" + R1 + "+)|" + (E4 + "|") + "([!-\\[\\]-\u2027\u202A-\uD7FF\uF900-\uFFFF]" + (Ft + "*") + "|[\uD800-\uDBFF][\uDC00-\uDFFF]" + (Ft + "*") + "|\\\\verb\\*([^]).*?\\4|\\\\verb([^*a-zA-Z]).*?\\5" + ("|" + q4) + ("|" + D4 + ")"), Ve = class {
    constructor(e, t) { this.input = void 0, this.settings = void 0, this.tokenRegex = void 0, this.catcodes = void 0, this.input = e, this.settings = t, this.tokenRegex = new RegExp(I4, "g"), this.catcodes = { "%": 14, "~": 13 }; }
    setCatcode(e, t) { this.catcodes[e] = t; }
    lex() {
        var e = this.input, t = this.tokenRegex.lastIndex;
        if (t === e.length)
            return new d0("EOF", new m0(this, t, t));
        var a = this.tokenRegex.exec(e);
        if (a === null || a.index !== t)
            throw new z("Unexpected character: '" + e[t] + "'", new d0(e[t], new m0(this, t, t + 1)));
        var i = a[6] || a[3] || (a[2] ? "\\ " : " ");
        if (this.catcodes[i] === 14) {
            var s = e.indexOf(`
`, this.tokenRegex.lastIndex);
            return s === -1 ? (this.tokenRegex.lastIndex = e.length, this.settings.reportNonstrict("commentAtEnd", "% comment has no terminating newline; LaTeX would fail because of commenting the end of math mode (e.g. $)")) : this.tokenRegex.lastIndex = s + 1, this.lex();
        }
        return new d0(i, new m0(this, t, this.tokenRegex.lastIndex));
    }
}, Ot = class {
    constructor(e, t) { e === void 0 && (e = {}), t === void 0 && (t = {}), this.current = void 0, this.builtins = void 0, this.undefStack = void 0, this.current = t, this.builtins = e, this.undefStack = []; }
    beginGroup() { this.undefStack.push({}); }
    endGroup() { if (this.undefStack.length === 0)
        throw new z("Unbalanced namespace destruction: attempt to pop global namespace; please report this as a bug"); var e = this.undefStack.pop(); for (var t in e)
        e.hasOwnProperty(t) && (e[t] == null ? delete this.current[t] : this.current[t] = e[t]); }
    endGroups() { for (; this.undefStack.length > 0;)
        this.endGroup(); }
    has(e) { return this.current.hasOwnProperty(e) || this.builtins.hasOwnProperty(e); }
    get(e) { return this.current.hasOwnProperty(e) ? this.current[e] : this.builtins[e]; }
    set(e, t, a) { if (a === void 0 && (a = !1), a) {
        for (var i = 0; i < this.undefStack.length; i++)
            delete this.undefStack[i][e];
        this.undefStack.length > 0 && (this.undefStack[this.undefStack.length - 1][e] = t);
    }
    else {
        var s = this.undefStack[this.undefStack.length - 1];
        s && !s.hasOwnProperty(e) && (s[e] = this.current[e]);
    } t == null ? delete this.current[e] : this.current[e] = t; }
}, N4 = k1;
m("\\noexpand", function (r) { var e = r.popToken(); return r.isExpandable(e.text) && (e.noexpand = !0, e.treatAsRelax = !0), { tokens: [e], numArgs: 0 }; });
m("\\expandafter", function (r) { var e = r.popToken(); return r.expandOnce(!0), { tokens: [e], numArgs: 0 }; });
m("\\@firstoftwo", function (r) { var e = r.consumeArgs(2); return { tokens: e[0], numArgs: 0 }; });
m("\\@secondoftwo", function (r) { var e = r.consumeArgs(2); return { tokens: e[1], numArgs: 0 }; });
m("\\@ifnextchar", function (r) { var e = r.consumeArgs(3); r.consumeSpaces(); var t = r.future(); return e[0].length === 1 && e[0][0].text === t.text ? { tokens: e[1], numArgs: 0 } : { tokens: e[2], numArgs: 0 }; });
m("\\@ifstar", "\\@ifnextchar *{\\@firstoftwo{#1}}");
m("\\TextOrMath", function (r) { var e = r.consumeArgs(2); return r.mode === "text" ? { tokens: e[0], numArgs: 0 } : { tokens: e[1], numArgs: 0 }; });
var Pr = { 0: 0, 1: 1, 2: 2, 3: 3, 4: 4, 5: 5, 6: 6, 7: 7, 8: 8, 9: 9, a: 10, A: 10, b: 11, B: 11, c: 12, C: 12, d: 13, D: 13, e: 14, E: 14, f: 15, F: 15 };
m("\\char", function (r) { var e = r.popToken(), t, a = 0; if (e.text === "'")
    t = 8, e = r.popToken();
else if (e.text === '"')
    t = 16, e = r.popToken();
else if (e.text === "`")
    if (e = r.popToken(), e.text[0] === "\\")
        a = e.text.charCodeAt(1);
    else {
        if (e.text === "EOF")
            throw new z("\\char` missing argument");
        a = e.text.charCodeAt(0);
    }
else
    t = 10; if (t) {
    if (a = Pr[e.text], a == null || a >= t)
        throw new z("Invalid base-" + t + " digit " + e.text);
    for (var i; (i = Pr[r.future().text]) != null && i < t;)
        a *= t, a += i, r.popToken();
} return "\\@char{" + a + "}"; });
var Kt = (r, e, t, a) => { var i = r.consumeArg().tokens; if (i.length !== 1)
    throw new z("\\newcommand's first argument must be a macro name"); var s = i[0].text, u = r.isDefined(s); if (u && !e)
    throw new z("\\newcommand{" + s + "} attempting to redefine " + (s + "; use \\renewcommand")); if (!u && !t)
    throw new z("\\renewcommand{" + s + "} when command " + s + " does not yet exist; use \\newcommand"); var h = 0; if (i = r.consumeArg().tokens, i.length === 1 && i[0].text === "[") {
    for (var c = "", v = r.expandNextToken(); v.text !== "]" && v.text !== "EOF";)
        c += v.text, v = r.expandNextToken();
    if (!c.match(/^\s*[0-9]+\s*$/))
        throw new z("Invalid number of arguments: " + c);
    h = parseInt(c), i = r.consumeArg().tokens;
} return u && a || r.macros.set(s, { tokens: i, numArgs: h }), ""; };
m("\\newcommand", r => Kt(r, !1, !0, !1));
m("\\renewcommand", r => Kt(r, !0, !1, !1));
m("\\providecommand", r => Kt(r, !0, !0, !0));
m("\\message", r => { var e = r.consumeArgs(1)[0]; return console.log(e.reverse().map(t => t.text).join("")), ""; });
m("\\errmessage", r => { var e = r.consumeArgs(1)[0]; return console.error(e.reverse().map(t => t.text).join("")), ""; });
m("\\show", r => { var e = r.popToken(), t = e.text; return console.log(e, r.macros.get(t), L0[t], W.math[t], W.text[t]), ""; });
m("\\bgroup", "{");
m("\\egroup", "}");
m("~", "\\nobreakspace");
m("\\lq", "`");
m("\\rq", "'");
m("\\aa", "\\r a");
m("\\AA", "\\r A");
m("\\textcopyright", "\\html@mathml{\\textcircled{c}}{\\char`\xA9}");
m("\\copyright", "\\TextOrMath{\\textcopyright}{\\text{\\textcopyright}}");
m("\\textregistered", "\\html@mathml{\\textcircled{\\scriptsize R}}{\\char`\xAE}");
m("\u212C", "\\mathscr{B}");
m("\u2130", "\\mathscr{E}");
m("\u2131", "\\mathscr{F}");
m("\u210B", "\\mathscr{H}");
m("\u2110", "\\mathscr{I}");
m("\u2112", "\\mathscr{L}");
m("\u2133", "\\mathscr{M}");
m("\u211B", "\\mathscr{R}");
m("\u212D", "\\mathfrak{C}");
m("\u210C", "\\mathfrak{H}");
m("\u2128", "\\mathfrak{Z}");
m("\\Bbbk", "\\Bbb{k}");
m("\\llap", "\\mathllap{\\textrm{#1}}");
m("\\rlap", "\\mathrlap{\\textrm{#1}}");
m("\\clap", "\\mathclap{\\textrm{#1}}");
m("\\mathstrut", "\\vphantom{(}");
m("\\underbar", "\\underline{\\text{#1}}");
m("\\not", '\\html@mathml{\\mathrel{\\mathrlap\\@not}\\nobreak}{\\char"338}');
m("\\neq", "\\html@mathml{\\mathrel{\\not=}}{\\mathrel{\\char`\u2260}}");
m("\\ne", "\\neq");
m("\u2260", "\\neq");
m("\\notin", "\\html@mathml{\\mathrel{{\\in}\\mathllap{/\\mskip1mu}}}{\\mathrel{\\char`\u2209}}");
m("\u2209", "\\notin");
m("\u2258", "\\html@mathml{\\mathrel{=\\kern{-1em}\\raisebox{0.4em}{$\\scriptsize\\frown$}}}{\\mathrel{\\char`\u2258}}");
m("\u2259", "\\html@mathml{\\stackrel{\\tiny\\wedge}{=}}{\\mathrel{\\char`\u2258}}");
m("\u225A", "\\html@mathml{\\stackrel{\\tiny\\vee}{=}}{\\mathrel{\\char`\u225A}}");
m("\u225B", "\\html@mathml{\\stackrel{\\scriptsize\\star}{=}}{\\mathrel{\\char`\u225B}}");
m("\u225D", "\\html@mathml{\\stackrel{\\tiny\\mathrm{def}}{=}}{\\mathrel{\\char`\u225D}}");
m("\u225E", "\\html@mathml{\\stackrel{\\tiny\\mathrm{m}}{=}}{\\mathrel{\\char`\u225E}}");
m("\u225F", "\\html@mathml{\\stackrel{\\tiny?}{=}}{\\mathrel{\\char`\u225F}}");
m("\u27C2", "\\perp");
m("\u203C", "\\mathclose{!\\mkern-0.8mu!}");
m("\u220C", "\\notni");
m("\u231C", "\\ulcorner");
m("\u231D", "\\urcorner");
m("\u231E", "\\llcorner");
m("\u231F", "\\lrcorner");
m("\xA9", "\\copyright");
m("\xAE", "\\textregistered");
m("\\ulcorner", '\\html@mathml{\\@ulcorner}{\\mathop{\\char"231c}}');
m("\\urcorner", '\\html@mathml{\\@urcorner}{\\mathop{\\char"231d}}');
m("\\llcorner", '\\html@mathml{\\@llcorner}{\\mathop{\\char"231e}}');
m("\\lrcorner", '\\html@mathml{\\@lrcorner}{\\mathop{\\char"231f}}');
m("\\vdots", "{\\varvdots\\rule{0pt}{15pt}}");
m("\u22EE", "\\vdots");
m("\\varGamma", "\\mathit{\\Gamma}");
m("\\varDelta", "\\mathit{\\Delta}");
m("\\varTheta", "\\mathit{\\Theta}");
m("\\varLambda", "\\mathit{\\Lambda}");
m("\\varXi", "\\mathit{\\Xi}");
m("\\varPi", "\\mathit{\\Pi}");
m("\\varSigma", "\\mathit{\\Sigma}");
m("\\varUpsilon", "\\mathit{\\Upsilon}");
m("\\varPhi", "\\mathit{\\Phi}");
m("\\varPsi", "\\mathit{\\Psi}");
m("\\varOmega", "\\mathit{\\Omega}");
m("\\substack", "\\begin{subarray}{c}#1\\end{subarray}");
m("\\colon", "\\nobreak\\mskip2mu\\mathpunct{}\\mathchoice{\\mkern-3mu}{\\mkern-3mu}{}{}{:}\\mskip6mu\\relax");
m("\\boxed", "\\fbox{$\\displaystyle{#1}$}");
m("\\iff", "\\DOTSB\\;\\Longleftrightarrow\\;");
m("\\implies", "\\DOTSB\\;\\Longrightarrow\\;");
m("\\impliedby", "\\DOTSB\\;\\Longleftarrow\\;");
m("\\dddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ...}}{#1}}");
m("\\ddddot", "{\\overset{\\raisebox{-0.1ex}{\\normalsize ....}}{#1}}");
var Gr = { ",": "\\dotsc", "\\not": "\\dotsb", "+": "\\dotsb", "=": "\\dotsb", "<": "\\dotsb", ">": "\\dotsb", "-": "\\dotsb", "*": "\\dotsb", ":": "\\dotsb", "\\DOTSB": "\\dotsb", "\\coprod": "\\dotsb", "\\bigvee": "\\dotsb", "\\bigwedge": "\\dotsb", "\\biguplus": "\\dotsb", "\\bigcap": "\\dotsb", "\\bigcup": "\\dotsb", "\\prod": "\\dotsb", "\\sum": "\\dotsb", "\\bigotimes": "\\dotsb", "\\bigoplus": "\\dotsb", "\\bigodot": "\\dotsb", "\\bigsqcup": "\\dotsb", "\\And": "\\dotsb", "\\longrightarrow": "\\dotsb", "\\Longrightarrow": "\\dotsb", "\\longleftarrow": "\\dotsb", "\\Longleftarrow": "\\dotsb", "\\longleftrightarrow": "\\dotsb", "\\Longleftrightarrow": "\\dotsb", "\\mapsto": "\\dotsb", "\\longmapsto": "\\dotsb", "\\hookrightarrow": "\\dotsb", "\\doteq": "\\dotsb", "\\mathbin": "\\dotsb", "\\mathrel": "\\dotsb", "\\relbar": "\\dotsb", "\\Relbar": "\\dotsb", "\\xrightarrow": "\\dotsb", "\\xleftarrow": "\\dotsb", "\\DOTSI": "\\dotsi", "\\int": "\\dotsi", "\\oint": "\\dotsi", "\\iint": "\\dotsi", "\\iiint": "\\dotsi", "\\iiiint": "\\dotsi", "\\idotsint": "\\dotsi", "\\DOTSX": "\\dotsx" }, F4 = new Set(["bin", "rel"]);
m("\\dots", function (r) { var e = "\\dotso", t = r.expandAfterFuture().text; return t in Gr ? e = Gr[t] : (t.slice(0, 4) === "\\not" || t in W.math && F4.has(W.math[t].group)) && (e = "\\dotsb"), e; });
var Jt = { ")": !0, "]": !0, "\\rbrack": !0, "\\}": !0, "\\rbrace": !0, "\\rangle": !0, "\\rceil": !0, "\\rfloor": !0, "\\rgroup": !0, "\\rmoustache": !0, "\\right": !0, "\\bigr": !0, "\\biggr": !0, "\\Bigr": !0, "\\Biggr": !0, $: !0, ";": !0, ".": !0, ",": !0 };
m("\\dotso", function (r) { var e = r.future().text; return e in Jt ? "\\ldots\\," : "\\ldots"; });
m("\\dotsc", function (r) { var e = r.future().text; return e in Jt && e !== "," ? "\\ldots\\," : "\\ldots"; });
m("\\cdots", function (r) { var e = r.future().text; return e in Jt ? "\\@cdots\\," : "\\@cdots"; });
m("\\dotsb", "\\cdots");
m("\\dotsm", "\\cdots");
m("\\dotsi", "\\!\\cdots");
m("\\dotsx", "\\ldots\\,");
m("\\DOTSI", "\\relax");
m("\\DOTSB", "\\relax");
m("\\DOTSX", "\\relax");
m("\\tmspace", "\\TextOrMath{\\kern#1#3}{\\mskip#1#2}\\relax");
m("\\,", "\\tmspace+{3mu}{.1667em}");
m("\\thinspace", "\\,");
m("\\>", "\\mskip{4mu}");
m("\\:", "\\tmspace+{4mu}{.2222em}");
m("\\medspace", "\\:");
m("\\;", "\\tmspace+{5mu}{.2777em}");
m("\\thickspace", "\\;");
m("\\!", "\\tmspace-{3mu}{.1667em}");
m("\\negthinspace", "\\!");
m("\\negmedspace", "\\tmspace-{4mu}{.2222em}");
m("\\negthickspace", "\\tmspace-{5mu}{.277em}");
m("\\enspace", "\\kern.5em ");
m("\\enskip", "\\hskip.5em\\relax");
m("\\quad", "\\hskip1em\\relax");
m("\\qquad", "\\hskip2em\\relax");
m("\\tag", "\\@ifstar\\tag@literal\\tag@paren");
m("\\tag@paren", "\\tag@literal{({#1})}");
m("\\tag@literal", r => { if (r.macros.get("\\df@tag"))
    throw new z("Multiple \\tag"); return "\\gdef\\df@tag{\\text{#1}}"; });
m("\\bmod", "\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}\\mathbin{\\rm mod}\\mathchoice{\\mskip1mu}{\\mskip1mu}{\\mskip5mu}{\\mskip5mu}");
m("\\pod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern8mu}{\\mkern8mu}{\\mkern8mu}(#1)");
m("\\pmod", "\\pod{{\\rm mod}\\mkern6mu#1}");
m("\\mod", "\\allowbreak\\mathchoice{\\mkern18mu}{\\mkern12mu}{\\mkern12mu}{\\mkern12mu}{\\rm mod}\\,\\,#1");
m("\\newline", "\\\\\\relax");
m("\\TeX", "\\textrm{\\html@mathml{T\\kern-.1667em\\raisebox{-.5ex}{E}\\kern-.125emX}{TeX}}");
var I1 = A(z0["Main-Regular"][84][1] - .7 * z0["Main-Regular"][65][1]);
m("\\LaTeX", "\\textrm{\\html@mathml{" + ("L\\kern-.36em\\raisebox{" + I1 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{LaTeX}}");
m("\\KaTeX", "\\textrm{\\html@mathml{" + ("K\\kern-.17em\\raisebox{" + I1 + "}{\\scriptstyle A}") + "\\kern-.15em\\TeX}{KaTeX}}");
m("\\hspace", "\\@ifstar\\@hspacer\\@hspace");
m("\\@hspace", "\\hskip #1\\relax");
m("\\@hspacer", "\\rule{0pt}{0pt}\\hskip #1\\relax");
m("\\ordinarycolon", ":");
m("\\vcentcolon", "\\mathrel{\\mathop\\ordinarycolon}");
m("\\dblcolon", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-.9mu}\\vcentcolon}}{\\mathop{\\char"2237}}');
m("\\coloneqq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2254}}');
m("\\Coloneqq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}=}}{\\mathop{\\char"2237\\char"3d}}');
m("\\coloneq", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"3a\\char"2212}}');
m("\\Coloneq", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\mathrel{-}}}{\\mathop{\\char"2237\\char"2212}}');
m("\\eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2255}}');
m("\\Eqqcolon", '\\html@mathml{\\mathrel{=\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"3d\\char"2237}}');
m("\\eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\vcentcolon}}{\\mathop{\\char"2239}}');
m("\\Eqcolon", '\\html@mathml{\\mathrel{\\mathrel{-}\\mathrel{\\mkern-1.2mu}\\dblcolon}}{\\mathop{\\char"2212\\char"2237}}');
m("\\colonapprox", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"3a\\char"2248}}');
m("\\Colonapprox", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\approx}}{\\mathop{\\char"2237\\char"2248}}');
m("\\colonsim", '\\html@mathml{\\mathrel{\\vcentcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"3a\\char"223c}}');
m("\\Colonsim", '\\html@mathml{\\mathrel{\\dblcolon\\mathrel{\\mkern-1.2mu}\\sim}}{\\mathop{\\char"2237\\char"223c}}');
m("\u2237", "\\dblcolon");
m("\u2239", "\\eqcolon");
m("\u2254", "\\coloneqq");
m("\u2255", "\\eqqcolon");
m("\u2A74", "\\Coloneqq");
m("\\ratio", "\\vcentcolon");
m("\\coloncolon", "\\dblcolon");
m("\\colonequals", "\\coloneqq");
m("\\coloncolonequals", "\\Coloneqq");
m("\\equalscolon", "\\eqqcolon");
m("\\equalscoloncolon", "\\Eqqcolon");
m("\\colonminus", "\\coloneq");
m("\\coloncolonminus", "\\Coloneq");
m("\\minuscolon", "\\eqcolon");
m("\\minuscoloncolon", "\\Eqcolon");
m("\\coloncolonapprox", "\\Colonapprox");
m("\\coloncolonsim", "\\Colonsim");
m("\\simcolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
m("\\simcoloncolon", "\\mathrel{\\sim\\mathrel{\\mkern-1.2mu}\\dblcolon}");
m("\\approxcolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\vcentcolon}");
m("\\approxcoloncolon", "\\mathrel{\\approx\\mathrel{\\mkern-1.2mu}\\dblcolon}");
m("\\notni", "\\html@mathml{\\not\\ni}{\\mathrel{\\char`\u220C}}");
m("\\limsup", "\\DOTSB\\operatorname*{lim\\,sup}");
m("\\liminf", "\\DOTSB\\operatorname*{lim\\,inf}");
m("\\injlim", "\\DOTSB\\operatorname*{inj\\,lim}");
m("\\projlim", "\\DOTSB\\operatorname*{proj\\,lim}");
m("\\varlimsup", "\\DOTSB\\operatorname*{\\overline{lim}}");
m("\\varliminf", "\\DOTSB\\operatorname*{\\underline{lim}}");
m("\\varinjlim", "\\DOTSB\\operatorname*{\\underrightarrow{lim}}");
m("\\varprojlim", "\\DOTSB\\operatorname*{\\underleftarrow{lim}}");
m("\\gvertneqq", "\\html@mathml{\\@gvertneqq}{\u2269}");
m("\\lvertneqq", "\\html@mathml{\\@lvertneqq}{\u2268}");
m("\\ngeqq", "\\html@mathml{\\@ngeqq}{\u2271}");
m("\\ngeqslant", "\\html@mathml{\\@ngeqslant}{\u2271}");
m("\\nleqq", "\\html@mathml{\\@nleqq}{\u2270}");
m("\\nleqslant", "\\html@mathml{\\@nleqslant}{\u2270}");
m("\\nshortmid", "\\html@mathml{\\@nshortmid}{\u2224}");
m("\\nshortparallel", "\\html@mathml{\\@nshortparallel}{\u2226}");
m("\\nsubseteqq", "\\html@mathml{\\@nsubseteqq}{\u2288}");
m("\\nsupseteqq", "\\html@mathml{\\@nsupseteqq}{\u2289}");
m("\\varsubsetneq", "\\html@mathml{\\@varsubsetneq}{\u228A}");
m("\\varsubsetneqq", "\\html@mathml{\\@varsubsetneqq}{\u2ACB}");
m("\\varsupsetneq", "\\html@mathml{\\@varsupsetneq}{\u228B}");
m("\\varsupsetneqq", "\\html@mathml{\\@varsupsetneqq}{\u2ACC}");
m("\\imath", "\\html@mathml{\\@imath}{\u0131}");
m("\\jmath", "\\html@mathml{\\@jmath}{\u0237}");
m("\\llbracket", "\\html@mathml{\\mathopen{[\\mkern-3.2mu[}}{\\mathopen{\\char`\u27E6}}");
m("\\rrbracket", "\\html@mathml{\\mathclose{]\\mkern-3.2mu]}}{\\mathclose{\\char`\u27E7}}");
m("\u27E6", "\\llbracket");
m("\u27E7", "\\rrbracket");
m("\\lBrace", "\\html@mathml{\\mathopen{\\{\\mkern-3.2mu[}}{\\mathopen{\\char`\u2983}}");
m("\\rBrace", "\\html@mathml{\\mathclose{]\\mkern-3.2mu\\}}}{\\mathclose{\\char`\u2984}}");
m("\u2983", "\\lBrace");
m("\u2984", "\\rBrace");
m("\\minuso", "\\mathbin{\\html@mathml{{\\mathrlap{\\mathchoice{\\kern{0.145em}}{\\kern{0.145em}}{\\kern{0.1015em}}{\\kern{0.0725em}}\\circ}{-}}}{\\char`\u29B5}}");
m("\u29B5", "\\minuso");
m("\\darr", "\\downarrow");
m("\\dArr", "\\Downarrow");
m("\\Darr", "\\Downarrow");
m("\\lang", "\\langle");
m("\\rang", "\\rangle");
m("\\uarr", "\\uparrow");
m("\\uArr", "\\Uparrow");
m("\\Uarr", "\\Uparrow");
m("\\N", "\\mathbb{N}");
m("\\R", "\\mathbb{R}");
m("\\Z", "\\mathbb{Z}");
m("\\alef", "\\aleph");
m("\\alefsym", "\\aleph");
m("\\Alpha", "\\mathrm{A}");
m("\\Beta", "\\mathrm{B}");
m("\\bull", "\\bullet");
m("\\Chi", "\\mathrm{X}");
m("\\clubs", "\\clubsuit");
m("\\cnums", "\\mathbb{C}");
m("\\Complex", "\\mathbb{C}");
m("\\Dagger", "\\ddagger");
m("\\diamonds", "\\diamondsuit");
m("\\empty", "\\emptyset");
m("\\Epsilon", "\\mathrm{E}");
m("\\Eta", "\\mathrm{H}");
m("\\exist", "\\exists");
m("\\harr", "\\leftrightarrow");
m("\\hArr", "\\Leftrightarrow");
m("\\Harr", "\\Leftrightarrow");
m("\\hearts", "\\heartsuit");
m("\\image", "\\Im");
m("\\infin", "\\infty");
m("\\Iota", "\\mathrm{I}");
m("\\isin", "\\in");
m("\\Kappa", "\\mathrm{K}");
m("\\larr", "\\leftarrow");
m("\\lArr", "\\Leftarrow");
m("\\Larr", "\\Leftarrow");
m("\\lrarr", "\\leftrightarrow");
m("\\lrArr", "\\Leftrightarrow");
m("\\Lrarr", "\\Leftrightarrow");
m("\\Mu", "\\mathrm{M}");
m("\\natnums", "\\mathbb{N}");
m("\\Nu", "\\mathrm{N}");
m("\\Omicron", "\\mathrm{O}");
m("\\plusmn", "\\pm");
m("\\rarr", "\\rightarrow");
m("\\rArr", "\\Rightarrow");
m("\\Rarr", "\\Rightarrow");
m("\\real", "\\Re");
m("\\reals", "\\mathbb{R}");
m("\\Reals", "\\mathbb{R}");
m("\\Rho", "\\mathrm{P}");
m("\\sdot", "\\cdot");
m("\\sect", "\\S");
m("\\spades", "\\spadesuit");
m("\\sub", "\\subset");
m("\\sube", "\\subseteq");
m("\\supe", "\\supseteq");
m("\\Tau", "\\mathrm{T}");
m("\\thetasym", "\\vartheta");
m("\\weierp", "\\wp");
m("\\Zeta", "\\mathrm{Z}");
m("\\argmin", "\\DOTSB\\operatorname*{arg\\,min}");
m("\\argmax", "\\DOTSB\\operatorname*{arg\\,max}");
m("\\plim", "\\DOTSB\\mathop{\\operatorname{plim}}\\limits");
m("\\bra", "\\mathinner{\\langle{#1}|}");
m("\\ket", "\\mathinner{|{#1}\\rangle}");
m("\\braket", "\\mathinner{\\langle{#1}\\rangle}");
m("\\Bra", "\\left\\langle#1\\right|");
m("\\Ket", "\\left|#1\\right\\rangle");
var N1 = r => e => { var t = e.consumeArg().tokens, a = e.consumeArg().tokens, i = e.consumeArg().tokens, s = e.consumeArg().tokens, u = e.macros.get("|"), h = e.macros.get("\\|"); e.macros.beginGroup(); var c = b => x => { r && (x.macros.set("|", u), i.length && x.macros.set("\\|", h)); var y = b; if (!b && i.length) {
    var T = x.future();
    T.text === "|" && (x.popToken(), y = !0);
} return { tokens: y ? i : a, numArgs: 0 }; }; e.macros.set("|", c(!1)), i.length && e.macros.set("\\|", c(!0)); var v = e.consumeArg().tokens, p = e.expandTokens([...s, ...v, ...t]); return e.macros.endGroup(), { tokens: p.reverse(), numArgs: 0 }; };
m("\\bra@ket", N1(!1));
m("\\bra@set", N1(!0));
m("\\Braket", "\\bra@ket{\\left\\langle}{\\,\\middle\\vert\\,}{\\,\\middle\\vert\\,}{\\right\\rangle}");
m("\\Set", "\\bra@set{\\left\\{\\:}{\\;\\middle\\vert\\;}{\\;\\middle\\Vert\\;}{\\:\\right\\}}");
m("\\set", "\\bra@set{\\{\\,}{\\mid}{}{\\,\\}}");
m("\\angln", "{\\angl n}");
m("\\blue", "\\textcolor{##6495ed}{#1}");
m("\\orange", "\\textcolor{##ffa500}{#1}");
m("\\pink", "\\textcolor{##ff00af}{#1}");
m("\\red", "\\textcolor{##df0030}{#1}");
m("\\green", "\\textcolor{##28ae7b}{#1}");
m("\\gray", "\\textcolor{gray}{#1}");
m("\\purple", "\\textcolor{##9d38bd}{#1}");
m("\\blueA", "\\textcolor{##ccfaff}{#1}");
m("\\blueB", "\\textcolor{##80f6ff}{#1}");
m("\\blueC", "\\textcolor{##63d9ea}{#1}");
m("\\blueD", "\\textcolor{##11accd}{#1}");
m("\\blueE", "\\textcolor{##0c7f99}{#1}");
m("\\tealA", "\\textcolor{##94fff5}{#1}");
m("\\tealB", "\\textcolor{##26edd5}{#1}");
m("\\tealC", "\\textcolor{##01d1c1}{#1}");
m("\\tealD", "\\textcolor{##01a995}{#1}");
m("\\tealE", "\\textcolor{##208170}{#1}");
m("\\greenA", "\\textcolor{##b6ffb0}{#1}");
m("\\greenB", "\\textcolor{##8af281}{#1}");
m("\\greenC", "\\textcolor{##74cf70}{#1}");
m("\\greenD", "\\textcolor{##1fab54}{#1}");
m("\\greenE", "\\textcolor{##0d923f}{#1}");
m("\\goldA", "\\textcolor{##ffd0a9}{#1}");
m("\\goldB", "\\textcolor{##ffbb71}{#1}");
m("\\goldC", "\\textcolor{##ff9c39}{#1}");
m("\\goldD", "\\textcolor{##e07d10}{#1}");
m("\\goldE", "\\textcolor{##a75a05}{#1}");
m("\\redA", "\\textcolor{##fca9a9}{#1}");
m("\\redB", "\\textcolor{##ff8482}{#1}");
m("\\redC", "\\textcolor{##f9685d}{#1}");
m("\\redD", "\\textcolor{##e84d39}{#1}");
m("\\redE", "\\textcolor{##bc2612}{#1}");
m("\\maroonA", "\\textcolor{##ffbde0}{#1}");
m("\\maroonB", "\\textcolor{##ff92c6}{#1}");
m("\\maroonC", "\\textcolor{##ed5fa6}{#1}");
m("\\maroonD", "\\textcolor{##ca337c}{#1}");
m("\\maroonE", "\\textcolor{##9e034e}{#1}");
m("\\purpleA", "\\textcolor{##ddd7ff}{#1}");
m("\\purpleB", "\\textcolor{##c6b9fc}{#1}");
m("\\purpleC", "\\textcolor{##aa87ff}{#1}");
m("\\purpleD", "\\textcolor{##7854ab}{#1}");
m("\\purpleE", "\\textcolor{##543b78}{#1}");
m("\\mintA", "\\textcolor{##f5f9e8}{#1}");
m("\\mintB", "\\textcolor{##edf2df}{#1}");
m("\\mintC", "\\textcolor{##e0e5cc}{#1}");
m("\\grayA", "\\textcolor{##f6f7f7}{#1}");
m("\\grayB", "\\textcolor{##f0f1f2}{#1}");
m("\\grayC", "\\textcolor{##e3e5e6}{#1}");
m("\\grayD", "\\textcolor{##d6d8da}{#1}");
m("\\grayE", "\\textcolor{##babec2}{#1}");
m("\\grayF", "\\textcolor{##888d93}{#1}");
m("\\grayG", "\\textcolor{##626569}{#1}");
m("\\grayH", "\\textcolor{##3b3e40}{#1}");
m("\\grayI", "\\textcolor{##21242c}{#1}");
m("\\kaBlue", "\\textcolor{##314453}{#1}");
m("\\kaGreen", "\\textcolor{##71B307}{#1}");
var F1 = { "^": !0, _: !0, "\\limits": !0, "\\nolimits": !0 }, Ht = class {
    constructor(e, t, a) { this.settings = void 0, this.expansionCount = void 0, this.lexer = void 0, this.macros = void 0, this.stack = void 0, this.mode = void 0, this.settings = t, this.expansionCount = 0, this.feed(e), this.macros = new Ot(N4, t.macros), this.mode = a, this.stack = []; }
    feed(e) { this.lexer = new Ve(e, this.settings); }
    switchMode(e) { this.mode = e; }
    beginGroup() { this.macros.beginGroup(); }
    endGroup() { this.macros.endGroup(); }
    endGroups() { this.macros.endGroups(); }
    future() { return this.stack.length === 0 && this.pushToken(this.lexer.lex()), this.stack[this.stack.length - 1]; }
    popToken() { return this.future(), this.stack.pop(); }
    pushToken(e) { this.stack.push(e); }
    pushTokens(e) { this.stack.push(...e); }
    scanArgument(e) { var t, a, i; if (e) {
        if (this.consumeSpaces(), this.future().text !== "[")
            return null;
        t = this.popToken(), { tokens: i, end: a } = this.consumeArg(["]"]);
    }
    else
        ({ tokens: i, start: t, end: a } = this.consumeArg()); return this.pushToken(new d0("EOF", a.loc)), this.pushTokens(i), new d0("", m0.range(t, a)); }
    consumeSpaces() { for (;;) {
        var e = this.future();
        if (e.text === " ")
            this.stack.pop();
        else
            break;
    } }
    consumeArg(e) { var t = [], a = e && e.length > 0; a || this.consumeSpaces(); var i = this.future(), s, u = 0, h = 0; do {
        if (s = this.popToken(), t.push(s), s.text === "{")
            ++u;
        else if (s.text === "}") {
            if (--u, u === -1)
                throw new z("Extra }", s);
        }
        else if (s.text === "EOF")
            throw new z("Unexpected end of input in a macro argument, expected '" + (e && a ? e[h] : "}") + "'", s);
        if (e && a)
            if ((u === 0 || u === 1 && e[h] === "{") && s.text === e[h]) {
                if (++h, h === e.length) {
                    t.splice(-h, h);
                    break;
                }
            }
            else
                h = 0;
    } while (u !== 0 || a); return i.text === "{" && t[t.length - 1].text === "}" && (t.pop(), t.shift()), t.reverse(), { tokens: t, start: i, end: s }; }
    consumeArgs(e, t) { if (t) {
        if (t.length !== e + 1)
            throw new z("The length of delimiters doesn't match the number of args!");
        for (var a = t[0], i = 0; i < a.length; i++) {
            var s = this.popToken();
            if (a[i] !== s.text)
                throw new z("Use of the macro doesn't match its definition", s);
        }
    } for (var u = [], h = 0; h < e; h++)
        u.push(this.consumeArg(t && t[h + 1]).tokens); return u; }
    countExpansion(e) { if (this.expansionCount += e, this.expansionCount > this.settings.maxExpand)
        throw new z("Too many expansions: infinite loop or need to increase maxExpand setting"); }
    expandOnce(e) { var t = this.popToken(), a = t.text, i = t.noexpand ? null : this._getExpansion(a); if (i == null || e && i.unexpandable) {
        if (e && i == null && a[0] === "\\" && !this.isDefined(a))
            throw new z("Undefined control sequence: " + a);
        return this.pushToken(t), !1;
    } this.countExpansion(1); var s = i.tokens, u = this.consumeArgs(i.numArgs, i.delimiters); if (i.numArgs) {
        s = s.slice();
        for (var h = s.length - 1; h >= 0; --h) {
            var c = s[h];
            if (c.text === "#") {
                if (h === 0)
                    throw new z("Incomplete placeholder at end of macro body", c);
                if (c = s[--h], c.text === "#")
                    s.splice(h + 1, 1);
                else if (/^[1-9]$/.test(c.text))
                    s.splice(h, 2, ...u[+c.text - 1]);
                else
                    throw new z("Not a valid argument number", c);
            }
        }
    } return this.pushTokens(s), s.length; }
    expandAfterFuture() { return this.expandOnce(), this.future(); }
    expandNextToken() { for (;;)
        if (this.expandOnce() === !1) {
            var e = this.stack.pop();
            return e.treatAsRelax && (e.text = "\\relax"), e;
        } }
    expandMacro(e) { return this.macros.has(e) ? this.expandTokens([new d0(e)]) : void 0; }
    expandTokens(e) { var t = [], a = this.stack.length; for (this.pushTokens(e); this.stack.length > a;)
        if (this.expandOnce(!0) === !1) {
            var i = this.stack.pop();
            i.treatAsRelax && (i.noexpand = !1, i.treatAsRelax = !1), t.push(i);
        } return this.countExpansion(t.length), t; }
    expandMacroAsText(e) { var t = this.expandMacro(e); return t && t.map(a => a.text).join(""); }
    _getExpansion(e) { var t = this.macros.get(e); if (t == null)
        return t; if (e.length === 1) {
        var a = this.lexer.catcodes[e];
        if (a != null && a !== 13)
            return;
    } var i = typeof t == "function" ? t(this) : t; if (typeof i == "string") {
        var s = 0;
        if (i.includes("#"))
            for (var u = i.replace(/##/g, ""); u.includes("#" + (s + 1));)
                ++s;
        for (var h = new Ve(i, this.settings), c = [], v = h.lex(); v.text !== "EOF";)
            c.push(v), v = h.lex();
        c.reverse();
        var p = { tokens: c, numArgs: s };
        return p;
    } return i; }
    isDefined(e) { return this.macros.has(e) || L0.hasOwnProperty(e) || W.math.hasOwnProperty(e) || W.text.hasOwnProperty(e) || F1.hasOwnProperty(e); }
    isExpandable(e) { var t = this.macros.get(e); return t != null ? typeof t == "string" || typeof t == "function" || !t.unexpandable : L0.hasOwnProperty(e) && !L0[e].primitive; }
}, Ur = /^[₊₋₌₍₎₀₁₂₃₄₅₆₇₈₉ₐₑₕᵢⱼₖₗₘₙₒₚᵣₛₜᵤᵥₓᵦᵧᵨᵩᵪ]/, Ie = Object.freeze({ "\u208A": "+", "\u208B": "-", "\u208C": "=", "\u208D": "(", "\u208E": ")", "\u2080": "0", "\u2081": "1", "\u2082": "2", "\u2083": "3", "\u2084": "4", "\u2085": "5", "\u2086": "6", "\u2087": "7", "\u2088": "8", "\u2089": "9", "\u2090": "a", "\u2091": "e", "\u2095": "h", "\u1D62": "i", "\u2C7C": "j", "\u2096": "k", "\u2097": "l", "\u2098": "m", "\u2099": "n", "\u2092": "o", "\u209A": "p", "\u1D63": "r", "\u209B": "s", "\u209C": "t", "\u1D64": "u", "\u1D65": "v", "\u2093": "x", "\u1D66": "\u03B2", "\u1D67": "\u03B3", "\u1D68": "\u03C1", "\u1D69": "\u03D5", "\u1D6A": "\u03C7", "\u207A": "+", "\u207B": "-", "\u207C": "=", "\u207D": "(", "\u207E": ")", "\u2070": "0", "\xB9": "1", "\xB2": "2", "\xB3": "3", "\u2074": "4", "\u2075": "5", "\u2076": "6", "\u2077": "7", "\u2078": "8", "\u2079": "9", "\u1D2C": "A", "\u1D2E": "B", "\u1D30": "D", "\u1D31": "E", "\u1D33": "G", "\u1D34": "H", "\u1D35": "I", "\u1D36": "J", "\u1D37": "K", "\u1D38": "L", "\u1D39": "M", "\u1D3A": "N", "\u1D3C": "O", "\u1D3E": "P", "\u1D3F": "R", "\u1D40": "T", "\u1D41": "U", "\u2C7D": "V", "\u1D42": "W", "\u1D43": "a", "\u1D47": "b", "\u1D9C": "c", "\u1D48": "d", "\u1D49": "e", "\u1DA0": "f", "\u1D4D": "g", \u02B0: "h", "\u2071": "i", \u02B2: "j", "\u1D4F": "k", \u02E1: "l", "\u1D50": "m", \u207F: "n", "\u1D52": "o", "\u1D56": "p", \u02B3: "r", \u02E2: "s", "\u1D57": "t", "\u1D58": "u", "\u1D5B": "v", \u02B7: "w", \u02E3: "x", \u02B8: "y", "\u1DBB": "z", "\u1D5D": "\u03B2", "\u1D5E": "\u03B3", "\u1D5F": "\u03B4", "\u1D60": "\u03D5", "\u1D61": "\u03C7", "\u1DBF": "\u03B8" }), gt = { "\u0301": { text: "\\'", math: "\\acute" }, "\u0300": { text: "\\`", math: "\\grave" }, "\u0308": { text: '\\"', math: "\\ddot" }, "\u0303": { text: "\\~", math: "\\tilde" }, "\u0304": { text: "\\=", math: "\\bar" }, "\u0306": { text: "\\u", math: "\\breve" }, "\u030C": { text: "\\v", math: "\\check" }, "\u0302": { text: "\\^", math: "\\hat" }, "\u0307": { text: "\\.", math: "\\dot" }, "\u030A": { text: "\\r", math: "\\mathring" }, "\u030B": { text: "\\H" }, "\u0327": { text: "\\c" } }, Vr = { \u00E1: "a\u0301", \u00E0: "a\u0300", \u00E4: "a\u0308", \u01DF: "a\u0308\u0304", \u00E3: "a\u0303", \u0101: "a\u0304", \u0103: "a\u0306", \u1EAF: "a\u0306\u0301", \u1EB1: "a\u0306\u0300", \u1EB5: "a\u0306\u0303", \u01CE: "a\u030C", \u00E2: "a\u0302", \u1EA5: "a\u0302\u0301", \u1EA7: "a\u0302\u0300", \u1EAB: "a\u0302\u0303", \u0227: "a\u0307", \u01E1: "a\u0307\u0304", \u00E5: "a\u030A", \u01FB: "a\u030A\u0301", \u1E03: "b\u0307", \u0107: "c\u0301", \u1E09: "c\u0327\u0301", \u010D: "c\u030C", \u0109: "c\u0302", \u010B: "c\u0307", \u00E7: "c\u0327", \u010F: "d\u030C", \u1E0B: "d\u0307", \u1E11: "d\u0327", \u00E9: "e\u0301", \u00E8: "e\u0300", \u00EB: "e\u0308", \u1EBD: "e\u0303", \u0113: "e\u0304", \u1E17: "e\u0304\u0301", \u1E15: "e\u0304\u0300", \u0115: "e\u0306", \u1E1D: "e\u0327\u0306", \u011B: "e\u030C", \u00EA: "e\u0302", \u1EBF: "e\u0302\u0301", \u1EC1: "e\u0302\u0300", \u1EC5: "e\u0302\u0303", \u0117: "e\u0307", \u0229: "e\u0327", \u1E1F: "f\u0307", \u01F5: "g\u0301", \u1E21: "g\u0304", \u011F: "g\u0306", \u01E7: "g\u030C", \u011D: "g\u0302", \u0121: "g\u0307", \u0123: "g\u0327", \u1E27: "h\u0308", \u021F: "h\u030C", \u0125: "h\u0302", \u1E23: "h\u0307", \u1E29: "h\u0327", \u00ED: "i\u0301", \u00EC: "i\u0300", \u00EF: "i\u0308", \u1E2F: "i\u0308\u0301", \u0129: "i\u0303", \u012B: "i\u0304", \u012D: "i\u0306", \u01D0: "i\u030C", \u00EE: "i\u0302", \u01F0: "j\u030C", \u0135: "j\u0302", \u1E31: "k\u0301", \u01E9: "k\u030C", \u0137: "k\u0327", \u013A: "l\u0301", \u013E: "l\u030C", \u013C: "l\u0327", \u1E3F: "m\u0301", \u1E41: "m\u0307", \u0144: "n\u0301", \u01F9: "n\u0300", \u00F1: "n\u0303", \u0148: "n\u030C", \u1E45: "n\u0307", \u0146: "n\u0327", \u00F3: "o\u0301", \u00F2: "o\u0300", \u00F6: "o\u0308", \u022B: "o\u0308\u0304", \u00F5: "o\u0303", \u1E4D: "o\u0303\u0301", \u1E4F: "o\u0303\u0308", \u022D: "o\u0303\u0304", \u014D: "o\u0304", \u1E53: "o\u0304\u0301", \u1E51: "o\u0304\u0300", \u014F: "o\u0306", \u01D2: "o\u030C", \u00F4: "o\u0302", \u1ED1: "o\u0302\u0301", \u1ED3: "o\u0302\u0300", \u1ED7: "o\u0302\u0303", \u022F: "o\u0307", \u0231: "o\u0307\u0304", \u0151: "o\u030B", \u1E55: "p\u0301", \u1E57: "p\u0307", \u0155: "r\u0301", \u0159: "r\u030C", \u1E59: "r\u0307", \u0157: "r\u0327", \u015B: "s\u0301", \u1E65: "s\u0301\u0307", \u0161: "s\u030C", \u1E67: "s\u030C\u0307", \u015D: "s\u0302", \u1E61: "s\u0307", \u015F: "s\u0327", \u1E97: "t\u0308", \u0165: "t\u030C", \u1E6B: "t\u0307", \u0163: "t\u0327", \u00FA: "u\u0301", \u00F9: "u\u0300", \u00FC: "u\u0308", \u01D8: "u\u0308\u0301", \u01DC: "u\u0308\u0300", \u01D6: "u\u0308\u0304", \u01DA: "u\u0308\u030C", \u0169: "u\u0303", \u1E79: "u\u0303\u0301", \u016B: "u\u0304", \u1E7B: "u\u0304\u0308", \u016D: "u\u0306", \u01D4: "u\u030C", \u00FB: "u\u0302", \u016F: "u\u030A", \u0171: "u\u030B", \u1E7D: "v\u0303", \u1E83: "w\u0301", \u1E81: "w\u0300", \u1E85: "w\u0308", \u0175: "w\u0302", \u1E87: "w\u0307", \u1E98: "w\u030A", \u1E8D: "x\u0308", \u1E8B: "x\u0307", \u00FD: "y\u0301", \u1EF3: "y\u0300", \u00FF: "y\u0308", \u1EF9: "y\u0303", \u0233: "y\u0304", \u0177: "y\u0302", \u1E8F: "y\u0307", \u1E99: "y\u030A", \u017A: "z\u0301", \u017E: "z\u030C", \u1E91: "z\u0302", \u017C: "z\u0307", \u00C1: "A\u0301", \u00C0: "A\u0300", \u00C4: "A\u0308", \u01DE: "A\u0308\u0304", \u00C3: "A\u0303", \u0100: "A\u0304", \u0102: "A\u0306", \u1EAE: "A\u0306\u0301", \u1EB0: "A\u0306\u0300", \u1EB4: "A\u0306\u0303", \u01CD: "A\u030C", \u00C2: "A\u0302", \u1EA4: "A\u0302\u0301", \u1EA6: "A\u0302\u0300", \u1EAA: "A\u0302\u0303", \u0226: "A\u0307", \u01E0: "A\u0307\u0304", \u00C5: "A\u030A", \u01FA: "A\u030A\u0301", \u1E02: "B\u0307", \u0106: "C\u0301", \u1E08: "C\u0327\u0301", \u010C: "C\u030C", \u0108: "C\u0302", \u010A: "C\u0307", \u00C7: "C\u0327", \u010E: "D\u030C", \u1E0A: "D\u0307", \u1E10: "D\u0327", \u00C9: "E\u0301", \u00C8: "E\u0300", \u00CB: "E\u0308", \u1EBC: "E\u0303", \u0112: "E\u0304", \u1E16: "E\u0304\u0301", \u1E14: "E\u0304\u0300", \u0114: "E\u0306", \u1E1C: "E\u0327\u0306", \u011A: "E\u030C", \u00CA: "E\u0302", \u1EBE: "E\u0302\u0301", \u1EC0: "E\u0302\u0300", \u1EC4: "E\u0302\u0303", \u0116: "E\u0307", \u0228: "E\u0327", \u1E1E: "F\u0307", \u01F4: "G\u0301", \u1E20: "G\u0304", \u011E: "G\u0306", \u01E6: "G\u030C", \u011C: "G\u0302", \u0120: "G\u0307", \u0122: "G\u0327", \u1E26: "H\u0308", \u021E: "H\u030C", \u0124: "H\u0302", \u1E22: "H\u0307", \u1E28: "H\u0327", \u00CD: "I\u0301", \u00CC: "I\u0300", \u00CF: "I\u0308", \u1E2E: "I\u0308\u0301", \u0128: "I\u0303", \u012A: "I\u0304", \u012C: "I\u0306", \u01CF: "I\u030C", \u00CE: "I\u0302", \u0130: "I\u0307", \u0134: "J\u0302", \u1E30: "K\u0301", \u01E8: "K\u030C", \u0136: "K\u0327", \u0139: "L\u0301", \u013D: "L\u030C", \u013B: "L\u0327", \u1E3E: "M\u0301", \u1E40: "M\u0307", \u0143: "N\u0301", \u01F8: "N\u0300", \u00D1: "N\u0303", \u0147: "N\u030C", \u1E44: "N\u0307", \u0145: "N\u0327", \u00D3: "O\u0301", \u00D2: "O\u0300", \u00D6: "O\u0308", \u022A: "O\u0308\u0304", \u00D5: "O\u0303", \u1E4C: "O\u0303\u0301", \u1E4E: "O\u0303\u0308", \u022C: "O\u0303\u0304", \u014C: "O\u0304", \u1E52: "O\u0304\u0301", \u1E50: "O\u0304\u0300", \u014E: "O\u0306", \u01D1: "O\u030C", \u00D4: "O\u0302", \u1ED0: "O\u0302\u0301", \u1ED2: "O\u0302\u0300", \u1ED6: "O\u0302\u0303", \u022E: "O\u0307", \u0230: "O\u0307\u0304", \u0150: "O\u030B", \u1E54: "P\u0301", \u1E56: "P\u0307", \u0154: "R\u0301", \u0158: "R\u030C", \u1E58: "R\u0307", \u0156: "R\u0327", \u015A: "S\u0301", \u1E64: "S\u0301\u0307", \u0160: "S\u030C", \u1E66: "S\u030C\u0307", \u015C: "S\u0302", \u1E60: "S\u0307", \u015E: "S\u0327", \u0164: "T\u030C", \u1E6A: "T\u0307", \u0162: "T\u0327", \u00DA: "U\u0301", \u00D9: "U\u0300", \u00DC: "U\u0308", \u01D7: "U\u0308\u0301", \u01DB: "U\u0308\u0300", \u01D5: "U\u0308\u0304", \u01D9: "U\u0308\u030C", \u0168: "U\u0303", \u1E78: "U\u0303\u0301", \u016A: "U\u0304", \u1E7A: "U\u0304\u0308", \u016C: "U\u0306", \u01D3: "U\u030C", \u00DB: "U\u0302", \u016E: "U\u030A", \u0170: "U\u030B", \u1E7C: "V\u0303", \u1E82: "W\u0301", \u1E80: "W\u0300", \u1E84: "W\u0308", \u0174: "W\u0302", \u1E86: "W\u0307", \u1E8C: "X\u0308", \u1E8A: "X\u0307", \u00DD: "Y\u0301", \u1EF2: "Y\u0300", \u0178: "Y\u0308", \u1EF8: "Y\u0303", \u0232: "Y\u0304", \u0176: "Y\u0302", \u1E8E: "Y\u0307", \u0179: "Z\u0301", \u017D: "Z\u030C", \u1E90: "Z\u0302", \u017B: "Z\u0307", \u03AC: "\u03B1\u0301", \u1F70: "\u03B1\u0300", \u1FB1: "\u03B1\u0304", \u1FB0: "\u03B1\u0306", \u03AD: "\u03B5\u0301", \u1F72: "\u03B5\u0300", \u03AE: "\u03B7\u0301", \u1F74: "\u03B7\u0300", \u03AF: "\u03B9\u0301", \u1F76: "\u03B9\u0300", \u03CA: "\u03B9\u0308", \u0390: "\u03B9\u0308\u0301", \u1FD2: "\u03B9\u0308\u0300", \u1FD1: "\u03B9\u0304", \u1FD0: "\u03B9\u0306", \u03CC: "\u03BF\u0301", \u1F78: "\u03BF\u0300", \u03CD: "\u03C5\u0301", \u1F7A: "\u03C5\u0300", \u03CB: "\u03C5\u0308", \u03B0: "\u03C5\u0308\u0301", \u1FE2: "\u03C5\u0308\u0300", \u1FE1: "\u03C5\u0304", \u1FE0: "\u03C5\u0306", \u03CE: "\u03C9\u0301", \u1F7C: "\u03C9\u0300", \u038E: "\u03A5\u0301", \u1FEA: "\u03A5\u0300", \u03AB: "\u03A5\u0308", \u1FE9: "\u03A5\u0304", \u1FE8: "\u03A5\u0306", \u038F: "\u03A9\u0301", \u1FFA: "\u03A9\u0300" }, Xe = class r {
    constructor(e, t) { this.mode = void 0, this.gullet = void 0, this.settings = void 0, this.leftrightDepth = void 0, this.nextToken = void 0, this.mode = "math", this.gullet = new Ht(e, t, this.mode), this.settings = t, this.leftrightDepth = 0, this.nextToken = null; }
    expect(e, t) { if (t === void 0 && (t = !0), this.fetch().text !== e)
        throw new z("Expected '" + e + "', got '" + this.fetch().text + "'", this.fetch()); t && this.consume(); }
    consume() { this.nextToken = null; }
    fetch() { return this.nextToken == null && (this.nextToken = this.gullet.expandNextToken()), this.nextToken; }
    switchMode(e) { this.mode = e, this.gullet.switchMode(e); }
    parse() { this.settings.globalGroup || this.gullet.beginGroup(), this.settings.colorIsTextColor && this.gullet.macros.set("\\color", "\\textcolor"); try {
        var e = this.parseExpression(!1);
        return this.expect("EOF"), this.settings.globalGroup || this.gullet.endGroup(), e;
    }
    finally {
        this.gullet.endGroups();
    } }
    subparse(e) { var t = this.nextToken; this.consume(), this.gullet.pushToken(new d0("}")), this.gullet.pushTokens(e); var a = this.parseExpression(!1); return this.expect("}"), this.nextToken = t, a; }
    parseExpression(e, t) { for (var a = [];;) {
        this.mode === "math" && this.consumeSpaces();
        var i = this.fetch();
        if (r.endOfExpression.has(i.text) || t && i.text === t || e && L0[i.text] && L0[i.text].infix)
            break;
        var s = this.parseAtom(t);
        if (s) {
            if (s.type === "internal")
                continue;
        }
        else
            break;
        a.push(s);
    } return this.mode === "text" && this.formLigatures(a), this.handleInfixNodes(a); }
    handleInfixNodes(e) { for (var t = -1, a, i = 0; i < e.length; i++) {
        var s = e[i];
        if (s.type === "infix") {
            if (t !== -1)
                throw new z("only one infix operator per group", s.token);
            t = i, a = s.replaceWith;
        }
    } if (t !== -1 && a) {
        var u, h, c = e.slice(0, t), v = e.slice(t + 1);
        c.length === 1 && c[0].type === "ordgroup" ? u = c[0] : u = { type: "ordgroup", mode: this.mode, body: c }, v.length === 1 && v[0].type === "ordgroup" ? h = v[0] : h = { type: "ordgroup", mode: this.mode, body: v };
        var p;
        return a === "\\\\abovefrac" ? p = this.callFunction(a, [u, e[t], h], []) : p = this.callFunction(a, [u, h], []), [p];
    }
    else
        return e; }
    handleSupSubscript(e) { var t = this.fetch(), a = t.text; this.consume(), this.consumeSpaces(); var i; do {
        var s;
        i = this.parseGroup(e);
    } while (((s = i) == null ? void 0 : s.type) === "internal"); if (!i)
        throw new z("Expected group after '" + a + "'", t); return i; }
    formatUnsupportedCmd(e) { for (var t = [], a = 0; a < e.length; a++)
        t.push({ type: "textord", mode: "text", text: e[a] }); var i = { type: "text", mode: this.mode, body: t }, s = { type: "color", mode: this.mode, color: this.settings.errorColor, body: [i] }; return s; }
    parseAtom(e) { var t = this.parseGroup("atom", e); if (t?.type === "internal" || this.mode === "text")
        return t; for (var a, i;;) {
        this.consumeSpaces();
        var s = this.fetch();
        if (s.text === "\\limits" || s.text === "\\nolimits") {
            if (t && t.type === "op") {
                var u = s.text === "\\limits";
                t.limits = u, t.alwaysHandleSupSub = !0;
            }
            else if (t && t.type === "operatorname")
                t.alwaysHandleSupSub && (t.limits = s.text === "\\limits");
            else
                throw new z("Limit controls must follow a math operator", s);
            this.consume();
        }
        else if (s.text === "^") {
            if (a)
                throw new z("Double superscript", s);
            a = this.handleSupSubscript("superscript");
        }
        else if (s.text === "_") {
            if (i)
                throw new z("Double subscript", s);
            i = this.handleSupSubscript("subscript");
        }
        else if (s.text === "'") {
            if (a)
                throw new z("Double superscript", s);
            var h = { type: "textord", mode: this.mode, text: "\\prime" }, c = [h];
            for (this.consume(); this.fetch().text === "'";)
                c.push(h), this.consume();
            this.fetch().text === "^" && c.push(this.handleSupSubscript("superscript")), a = { type: "ordgroup", mode: this.mode, body: c };
        }
        else if (Ie[s.text]) {
            var v = Ur.test(s.text), p = [];
            for (p.push(new d0(Ie[s.text])), this.consume();;) {
                var b = this.fetch().text;
                if (!Ie[b] || Ur.test(b) !== v)
                    break;
                p.unshift(new d0(Ie[b])), this.consume();
            }
            var x = this.subparse(p);
            v ? i = { type: "ordgroup", mode: "math", body: x } : a = { type: "ordgroup", mode: "math", body: x };
        }
        else
            break;
    } return a || i ? { type: "supsub", mode: this.mode, base: t, sup: a, sub: i } : t; }
    parseFunction(e, t) { var a = this.fetch(), i = a.text, s = L0[i]; if (!s)
        return null; if (this.consume(), t && t !== "atom" && !s.allowedInArgument)
        throw new z("Got function '" + i + "' with no arguments" + (t ? " as " + t : ""), a); if (this.mode === "text" && !s.allowedInText)
        throw new z("Can't use function '" + i + "' in text mode", a); if (this.mode === "math" && s.allowedInMath === !1)
        throw new z("Can't use function '" + i + "' in math mode", a); var { args: u, optArgs: h } = this.parseArguments(i, s); return this.callFunction(i, u, h, a, e); }
    callFunction(e, t, a, i, s) { var u = { funcName: e, parser: this, token: i, breakOnTokenText: s }, h = L0[e]; if (h && h.handler)
        return h.handler(u, t, a); throw new z("No function handler for " + e); }
    parseArguments(e, t) { var a = t.numArgs + t.numOptionalArgs; if (a === 0)
        return { args: [], optArgs: [] }; for (var i = [], s = [], u = 0; u < a; u++) {
        var h = t.argTypes && t.argTypes[u], c = u < t.numOptionalArgs;
        ("primitive" in t && t.primitive && h == null || t.type === "sqrt" && u === 1 && s[0] == null) && (h = "primitive");
        var v = this.parseGroupOfType("argument to '" + e + "'", h, c);
        if (c)
            s.push(v);
        else if (v != null)
            i.push(v);
        else
            throw new z("Null argument, please report this as a bug");
    } return { args: i, optArgs: s }; }
    parseGroupOfType(e, t, a) { switch (t) {
        case "color": return this.parseColorGroup(a);
        case "size": return this.parseSizeGroup(a);
        case "url": return this.parseUrlGroup(a);
        case "math":
        case "text": return this.parseArgumentGroup(a, t);
        case "hbox": {
            var i = this.parseArgumentGroup(a, "text");
            return i != null ? { type: "styling", mode: i.mode, body: [i], style: "text", resetFont: !0 } : null;
        }
        case "raw": {
            var s = this.parseStringGroup("raw", a);
            return s != null ? { type: "raw", mode: "text", string: s.text } : null;
        }
        case "primitive": {
            if (a)
                throw new z("A primitive argument cannot be optional");
            var u = this.parseGroup(e);
            if (u == null)
                throw new z("Expected group as " + e, this.fetch());
            return u;
        }
        case "original":
        case null:
        case void 0: return this.parseArgumentGroup(a);
        default: throw new z("Unknown group type as " + e, this.fetch());
    } }
    consumeSpaces() { for (; this.fetch().text === " ";)
        this.consume(); }
    parseStringGroup(e, t) { var a = this.gullet.scanArgument(t); if (a == null)
        return null; for (var i = "", s; (s = this.fetch()).text !== "EOF";)
        i += s.text, this.consume(); return this.consume(), a.text = i, a; }
    parseRegexGroup(e, t) { for (var a = this.fetch(), i = a, s = "", u; (u = this.fetch()).text !== "EOF" && e.test(s + u.text);)
        i = u, s += i.text, this.consume(); if (s === "")
        throw new z("Invalid " + t + ": '" + a.text + "'", a); return a.range(i, s); }
    parseColorGroup(e) { var t = this.parseStringGroup("color", e); if (t == null)
        return null; var a = /^(#[a-f0-9]{3,4}|#[a-f0-9]{6}|#[a-f0-9]{8}|[a-f0-9]{6}|[a-z]+)$/i.exec(t.text); if (!a)
        throw new z("Invalid color: '" + t.text + "'", t); var i = a[0]; return /^[0-9a-f]{6}$/i.test(i) && (i = "#" + i), { type: "color-token", mode: this.mode, color: i }; }
    parseSizeGroup(e) { var t, a = !1; if (this.gullet.consumeSpaces(), !e && this.gullet.future().text !== "{" ? t = this.parseRegexGroup(/^[-+]? *(?:$|\d+|\d+\.\d*|\.\d*) *[a-z]{0,2} *$/, "size") : t = this.parseStringGroup("size", e), !t)
        return null; !e && t.text.length === 0 && (t.text = "0pt", a = !0); var i = /([-+]?) *(\d+(?:\.\d*)?|\.\d+) *([a-z]{2})/.exec(t.text); if (!i)
        throw new z("Invalid size: '" + t.text + "'", t); var s = { number: +(i[1] + i[2]), unit: i[3] }; if (!Yr(s))
        throw new z("Invalid unit: '" + s.unit + "'", t); return { type: "size", mode: this.mode, value: s, isBlank: a }; }
    parseUrlGroup(e) { this.gullet.lexer.setCatcode("%", 13), this.gullet.lexer.setCatcode("~", 12); var t = this.parseStringGroup("url", e); if (this.gullet.lexer.setCatcode("%", 14), this.gullet.lexer.setCatcode("~", 13), t == null)
        return null; var a = t.text.replace(/\\([#$%&~_^{}])/g, "$1"); return { type: "url", mode: this.mode, url: a }; }
    parseArgumentGroup(e, t) { var a = this.gullet.scanArgument(e); if (a == null)
        return null; var i = this.mode; t && this.switchMode(t), this.gullet.beginGroup(); var s = this.parseExpression(!1, "EOF"); this.expect("EOF"), this.gullet.endGroup(); var u = { type: "ordgroup", mode: this.mode, loc: a.loc, body: s }; return t && this.switchMode(i), u; }
    parseGroup(e, t) { var a = this.fetch(), i = a.text, s; if (i === "{" || i === "\\begingroup") {
        this.consume();
        var u = i === "{" ? "}" : "\\endgroup";
        this.gullet.beginGroup();
        var h = this.parseExpression(!1, u), c = this.fetch();
        this.expect(u), this.gullet.endGroup(), s = { type: "ordgroup", mode: this.mode, loc: m0.range(a, c), body: h, semisimple: i === "\\begingroup" || void 0 };
    }
    else if (s = this.parseFunction(t, e) || this.parseSymbol(), s == null && i[0] === "\\" && !F1.hasOwnProperty(i)) {
        if (this.settings.throwOnError)
            throw new z("Undefined control sequence: " + i, a);
        s = this.formatUnsupportedCmd(i), this.consume();
    } return s; }
    formLigatures(e) { for (var t = e.length - 1, a = 0; a < t; ++a) {
        var i = e[a];
        if (i.type === "textord") {
            var s = i.text, u = e[a + 1];
            if (!(!u || u.type !== "textord")) {
                if (s === "-" && u.text === "-") {
                    var h = e[a + 2];
                    a + 1 < t && h && h.type === "textord" && h.text === "-" ? (e.splice(a, 3, { type: "textord", mode: "text", loc: m0.range(i, h), text: "---" }), t -= 2) : (e.splice(a, 2, { type: "textord", mode: "text", loc: m0.range(i, u), text: "--" }), t -= 1);
                }
                (s === "'" || s === "`") && u.text === s && (e.splice(a, 2, { type: "textord", mode: "text", loc: m0.range(i, u), text: s + s }), t -= 1);
            }
        }
    } }
    parseSymbol() {
        var e = this.fetch(), t = e.text;
        if (/^\\verb[^a-zA-Z]/.test(t)) {
            this.consume();
            var a = t.slice(5), i = a.charAt(0) === "*";
            if (i && (a = a.slice(1)), a.length < 2 || a.charAt(0) !== a.slice(-1))
                throw new z(`\\verb assertion failed --
                    please report what input caused this bug`);
            return a = a.slice(1, -1), { type: "verb", mode: "text", body: a, star: i };
        }
        Vr.hasOwnProperty(t[0]) && !W[this.mode][t[0]] && (this.settings.strict && this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Accented Unicode text character "' + t[0] + '" used in math mode', e), t = Vr[t[0]] + t.slice(1));
        var s = R4.exec(t);
        s && (t = t.substring(0, s.index), t === "i" ? t = "\u0131" : t === "j" && (t = "\u0237"));
        var u;
        if (W[this.mode][t]) {
            this.settings.strict && this.mode === "math" && kt.includes(t) && this.settings.reportNonstrict("unicodeTextInMathMode", 'Latin-1/Unicode text character "' + t[0] + '" used in math mode', e);
            var h = W[this.mode][t].group, c = m0.range(e), v;
            e4(h) ? v = { type: "atom", mode: this.mode, family: h, loc: c, text: t } : v = { type: h, mode: this.mode, loc: c, text: t }, u = v;
        }
        else if (t.charCodeAt(0) >= 128)
            this.settings.strict && (Xr(t.charCodeAt(0)) ? this.mode === "math" && this.settings.reportNonstrict("unicodeTextInMathMode", 'Unicode text character "' + t[0] + '" used in math mode', e) : this.settings.reportNonstrict("unknownSymbol", 'Unrecognized Unicode character "' + t[0] + '"' + (" (" + t.charCodeAt(0) + ")"), e)), u = { type: "textord", mode: "text", loc: m0.range(e), text: t };
        else
            return null;
        if (this.consume(), s)
            for (var p = 0; p < s[0].length; p++) {
                var b = s[0][p];
                if (!gt[b])
                    throw new z("Unknown accent ' " + b + "'", e);
                var x = gt[b][this.mode] || gt[b].text;
                if (!x)
                    throw new z("Accent " + b + " unsupported in " + this.mode + " mode", e);
                u = { type: "accent", mode: this.mode, loc: m0.range(e), label: x, isStretchy: !1, isShifty: !0, base: u };
            }
        return u;
    }
};
Xe.endOfExpression = new Set(["}", "\\endgroup", "\\end", "\\right", "&"]);
var Qt = function (e, t) { if (!(typeof e == "string" || e instanceof String))
    throw new TypeError("KaTeX can only parse string typed expression"); var a = new Xe(e, t); delete a.gullet.macros.current["\\df@tag"]; var i = a.parse(); if (delete a.gullet.macros.current["\\current@color"], delete a.gullet.macros.current["\\color"], a.gullet.macros.get("\\df@tag")) {
    if (!t.displayMode)
        throw new z("\\tag works only in display equations");
    i = [{ type: "tag", mode: "text", body: i, tag: a.subparse([new d0("\\df@tag")]) }];
} return i; }, O1 = function (e, t, a) { t.textContent = ""; var i = _t(e, a).toNode(); t.appendChild(i); };
typeof document < "u" && document.compatMode !== "CSS1Compat" && (typeof console < "u" && console.warn("Warning: KaTeX doesn't work in quirks mode. Make sure your website has a suitable doctype."), O1 = function () { throw new z("KaTeX doesn't work in quirks mode."); });
var O4 = function (e, t) { var a = _t(e, t).toMarkup(); return a; }, H4 = function (e, t) { var a = new de(t); return Qt(e, a); }, H1 = function (e, t, a) { if (a.throwOnError || !(e instanceof z))
    throw e; var i = k(["katex-error"], [new u0(t)]); return i.setAttribute("title", e.toString()), i.setAttribute("style", "color:" + a.errorColor), i; }, _t = function (e, t) { var a = new de(t); try {
    var i = Qt(e, a);
    return $a(i, e, a);
}
catch (s) {
    return H1(s, e, a);
} }, L4 = function (e, t) { var a = new de(t); try {
    var i = Qt(e, a);
    return Wa(i, e, a);
}
catch (s) {
    return H1(s, e, a);
} }, P4 = "0.16.47", G4 = { Span: U0, Anchor: re, SymbolNode: u0, SvgNode: x0, PathNode: A0, LineNode: ve }, U4 = { version: P4, render: O1, renderToString: O4, ParseError: z, SETTINGS_SCHEMA: bt, __parse: H4, __renderToDomTree: _t, __renderToHTMLTree: L4, __setFontMetrics: Ma, __defineSymbol: n, __defineFunction: B, __defineMacro: m, __domTree: G4 };
export { z as ParseError, bt as SETTINGS_SCHEMA, B as __defineFunction, m as __defineMacro, n as __defineSymbol, G4 as __domTree, H4 as __parse, _t as __renderToDomTree, L4 as __renderToHTMLTree, Ma as __setFontMetrics, U4 as default, O1 as render, O4 as renderToString, P4 as version };
