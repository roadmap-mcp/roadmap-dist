import { a as o } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var c = 1;
function i() { if (!(typeof globalThis > "u"))
    return globalThis; }
o(i, "getCaptureGlobal");
function p() { return !!i()?.mermaidCaptureSizes; }
o(p, "shouldCaptureSizes");
function u() { return typeof location > "u" ? "browser-dev" : `${location.pathname}${location.search}`; }
o(u, "capturedFromLocation");
function d(n, r) { let t = i(); if (!t)
    return; let e = r.node(), s = ((e && "ownerSVGElement" in e ? e.ownerSVGElement : null) ?? e)?.id ?? "(unknown)"; t.mermaidCapturedSizes ??= []; let a = { svgId: s, sizes: n }; t.mermaidCapturedSizes.push(a), t.mermaidLastCapturedSizes = a; }
o(d, "emitCapturedSizes");
function m(n, r) { let t = []; for (let e of r.nodes)
    e.isGroup || t.push({ id: e.id, width: e.width ?? 0, height: e.height ?? 0 }); t.length !== 0 && d({ metadata: { captureVersion: c, capturedAt: new Date().toISOString(), capturedFrom: u() }, nodes: t }, n); }
o(m, "captureNodeSizes");
export { m as captureNodeSizes, p as shouldCaptureSizes };
