import { a as t, b as s, c as o, d as a, e as m, g as d, u as c, w as u, y as T } from "@nf-internal/chunk-EPGORQP5";
var l = class extends u {
    static { t(this, "TreeViewValueConverter"); }
    runCustomConverter(r, e, n) { if (r.name === "INDENTATION")
        return e?.length || 0; if (r.name === "QUOTED_NAME")
        return e.substring(1, e.length - 1); if (r.name === "BARE_NAME")
        return e.replace(/[\t ]+$/, ""); if (r.name === "CLASS_ANNOTATION")
        return e.trim().substring(3).trim(); if (r.name === "ICON_ANNOTATION") {
        let i = e.trim();
        return i.substring(5, i.length - 1);
    } if (r.name === "DESC_ANNOTATION")
        return e.trim().substring(2).trim(); }
}, N = class extends T {
    static { t(this, "TreeViewTokenBuilder"); }
    constructor() { super(["treeView-beta"]); }
}, V = { parser: { TokenBuilder: t(() => new N, "TokenBuilder"), ValueConverter: t(() => new l, "ValueConverter") } };
function v(r = m) { let e = a(o(r), d), n = a(s({ shared: e }), c, V); return e.ServiceRegistry.register(n), { shared: e, TreeView: n }; }
t(v, "createTreeViewServices");
export { V as a, v as b };
