import { a as ue } from "@nf-internal/chunk-3UW5LP2A";
import { a as pe } from "@nf-internal/chunk-WVCFK4LD";
import { b as de, c as ge } from "@nf-internal/chunk-4PKWXC3U";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { H as M, _ as C, c as oe, d as ae, e as ce, k as B, u as le, x as he } from "@nf-internal/chunk-LEJRRF65";
import { b as T } from "@nf-internal/chunk-RZWXGGKD";
import { a as h } from "@nf-internal/chunk-YUSHYV7C";
import { f as se } from "@nf-internal/chunk-OSQMNGTH";
var k = [];
for (let e = 0; e < 256; ++e)
    k.push((e + 256).toString(16).slice(1));
function fe(e, i = 0) { return (k[e[i + 0]] + k[e[i + 1]] + k[e[i + 2]] + k[e[i + 3]] + "-" + k[e[i + 4]] + k[e[i + 5]] + "-" + k[e[i + 6]] + k[e[i + 7]] + "-" + k[e[i + 8]] + k[e[i + 9]] + "-" + k[e[i + 10]] + k[e[i + 11]] + k[e[i + 12]] + k[e[i + 13]] + k[e[i + 14]] + k[e[i + 15]]).toLowerCase(); }
var _e = new Uint8Array(16);
function q() { return crypto.getRandomValues(_e); }
function Se(e, i, l) { return !i && !e && crypto.randomUUID ? crypto.randomUUID() : xe(e, i, l); }
function xe(e, i, l) { e = e || {}; let a = e.random ?? e.rng?.() ?? q(); if (a.length < 16)
    throw new Error("Random bytes length must be >= 16"); if (a[6] = a[6] & 15 | 64, a[8] = a[8] & 63 | 128, i) {
    if (l = l || 0, l < 0 || l + 16 > i.length)
        throw new RangeError(`UUID byte range ${l}:${l + 15} is out of buffer bounds`);
    for (let t = 0; t < 16; ++t)
        i[l + t] = a[t];
    return i;
} return fe(a); }
var J = Se;
var K = (function () {
    var e = h(function (D, s, n, o) { for (n = n || {}, o = D.length; o--; n[D[o]] = s)
        ; return n; }, "o"), i = [1, 4], l = [1, 13], a = [1, 12], t = [1, 15], d = [1, 16], f = [1, 20], m = [1, 19], b = [6, 7, 8], O = [1, 26], w = [1, 24], R = [1, 25], g = [6, 7, 11], A = [1, 6, 13, 15, 16, 19, 22], Q = [1, 33], Z = [1, 34], $ = [1, 6, 7, 11, 13, 15, 16, 19, 22], j = { trace: h(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, mindMap: 4, spaceLines: 5, SPACELINE: 6, NL: 7, MINDMAP: 8, document: 9, stop: 10, EOF: 11, statement: 12, SPACELIST: 13, node: 14, ICON: 15, CLASS: 16, nodeWithId: 17, nodeWithoutId: 18, NODE_DSTART: 19, NODE_DESCR: 20, NODE_DEND: 21, NODE_ID: 22, $accept: 0, $end: 1 }, terminals_: { 2: "error", 6: "SPACELINE", 7: "NL", 8: "MINDMAP", 11: "EOF", 13: "SPACELIST", 15: "ICON", 16: "CLASS", 19: "NODE_DSTART", 20: "NODE_DESCR", 21: "NODE_DEND", 22: "NODE_ID" }, productions_: [0, [3, 1], [3, 2], [5, 1], [5, 2], [5, 2], [4, 2], [4, 3], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [9, 3], [9, 2], [12, 2], [12, 2], [12, 2], [12, 1], [12, 1], [12, 1], [12, 1], [12, 1], [14, 1], [14, 1], [18, 3], [17, 1], [17, 4]], performAction: h(function (s, n, o, c, p, r, U) { var u = r.length - 1; switch (p) {
            case 6:
            case 7: return c;
            case 8:
                c.getLogger().trace("Stop NL ");
                break;
            case 9:
                c.getLogger().trace("Stop EOF ");
                break;
            case 11:
                c.getLogger().trace("Stop NL2 ");
                break;
            case 12:
                c.getLogger().trace("Stop EOF2 ");
                break;
            case 15:
                c.getLogger().info("Node: ", r[u].id), c.addNode(r[u - 1].length, r[u].id, r[u].descr, r[u].type);
                break;
            case 16:
                c.getLogger().trace("Icon: ", r[u]), c.decorateNode({ icon: r[u] });
                break;
            case 17:
            case 21:
                c.decorateNode({ class: r[u] });
                break;
            case 18:
                c.getLogger().trace("SPACELIST");
                break;
            case 19:
                c.getLogger().trace("Node: ", r[u].id), c.addNode(0, r[u].id, r[u].descr, r[u].type);
                break;
            case 20:
                c.decorateNode({ icon: r[u] });
                break;
            case 25:
                c.getLogger().trace("node found ..", r[u - 2]), this.$ = { id: r[u - 1], descr: r[u - 1], type: c.getType(r[u - 2], r[u]) };
                break;
            case 26:
                this.$ = { id: r[u], descr: r[u], type: c.nodeType.DEFAULT };
                break;
            case 27:
                c.getLogger().trace("node found ..", r[u - 3]), this.$ = { id: r[u - 3], descr: r[u - 1], type: c.getType(r[u - 2], r[u]) };
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 8: i }, { 1: [3] }, { 1: [2, 1] }, { 4: 6, 6: [1, 7], 7: [1, 8], 8: i }, { 6: l, 7: [1, 10], 9: 9, 12: 11, 13: a, 14: 14, 15: t, 16: d, 17: 17, 18: 18, 19: f, 22: m }, e(b, [2, 3]), { 1: [2, 2] }, e(b, [2, 4]), e(b, [2, 5]), { 1: [2, 6], 6: l, 12: 21, 13: a, 14: 14, 15: t, 16: d, 17: 17, 18: 18, 19: f, 22: m }, { 6: l, 9: 22, 12: 11, 13: a, 14: 14, 15: t, 16: d, 17: 17, 18: 18, 19: f, 22: m }, { 6: O, 7: w, 10: 23, 11: R }, e(g, [2, 22], { 17: 17, 18: 18, 14: 27, 15: [1, 28], 16: [1, 29], 19: f, 22: m }), e(g, [2, 18]), e(g, [2, 19]), e(g, [2, 20]), e(g, [2, 21]), e(g, [2, 23]), e(g, [2, 24]), e(g, [2, 26], { 19: [1, 30] }), { 20: [1, 31] }, { 6: O, 7: w, 10: 32, 11: R }, { 1: [2, 7], 6: l, 12: 21, 13: a, 14: 14, 15: t, 16: d, 17: 17, 18: 18, 19: f, 22: m }, e(A, [2, 14], { 7: Q, 11: Z }), e($, [2, 8]), e($, [2, 9]), e($, [2, 10]), e(g, [2, 15]), e(g, [2, 16]), e(g, [2, 17]), { 20: [1, 35] }, { 21: [1, 36] }, e(A, [2, 13], { 7: Q, 11: Z }), e($, [2, 11]), e($, [2, 12]), { 21: [1, 37] }, e(g, [2, 25]), e(g, [2, 27])], defaultActions: { 2: [2, 1], 6: [2, 2] }, parseError: h(function (s, n) { if (n.recoverable)
            this.trace(s);
        else {
            var o = new Error(s);
            throw o.hash = n, o;
        } }, "parseError"), parse: h(function (s) {
            var n = this, o = [0], c = [], p = [null], r = [], U = this.table, u = "", V = 0, ee = 0, te = 0, ye = 2, ie = 1, ke = r.slice.call(arguments, 1), y = Object.create(this.lexer), L = { yy: {} };
            for (var H in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, H) && (L.yy[H] = this.yy[H]);
            y.setInput(s, L.yy), L.yy.lexer = y, L.yy.parser = this, typeof y.yylloc > "u" && (y.yylloc = {});
            var W = y.yylloc;
            r.push(W);
            var be = y.options && y.options.ranges;
            typeof L.yy.parseError == "function" ? this.parseError = L.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function Ee(_) { o.length = o.length - 2 * _, p.length = p.length - _, r.length = r.length - _; }
            h(Ee, "popStack");
            function ne() { var _; return _ = c.pop() || y.lex() || ie, typeof _ != "number" && (_ instanceof Array && (c = _, _ = c.pop()), _ = n.symbols_[_] || _), _; }
            h(ne, "lex");
            for (var E, X, v, S, Re, z, I = {}, F, x, re, G;;) {
                if (v = o[o.length - 1], this.defaultActions[v] ? S = this.defaultActions[v] : ((E === null || typeof E > "u") && (E = ne()), S = U[v] && U[v][E]), typeof S > "u" || !S.length || !S[0]) {
                    var Y = "";
                    G = [];
                    for (F in U[v])
                        this.terminals_[F] && F > ye && G.push("'" + this.terminals_[F] + "'");
                    y.showPosition ? Y = "Parse error on line " + (V + 1) + `:
` + y.showPosition() + `
Expecting ` + G.join(", ") + ", got '" + (this.terminals_[E] || E) + "'" : Y = "Parse error on line " + (V + 1) + ": Unexpected " + (E == ie ? "end of input" : "'" + (this.terminals_[E] || E) + "'"), this.parseError(Y, { text: y.match, token: this.terminals_[E] || E, line: y.yylineno, loc: W, expected: G });
                }
                if (S[0] instanceof Array && S.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + v + ", token: " + E);
                switch (S[0]) {
                    case 1:
                        o.push(E), p.push(y.yytext), r.push(y.yylloc), o.push(S[1]), E = null, X ? (E = X, X = null) : (ee = y.yyleng, u = y.yytext, V = y.yylineno, W = y.yylloc, te > 0 && te--);
                        break;
                    case 2:
                        if (x = this.productions_[S[1]][1], I.$ = p[p.length - x], I._$ = { first_line: r[r.length - (x || 1)].first_line, last_line: r[r.length - 1].last_line, first_column: r[r.length - (x || 1)].first_column, last_column: r[r.length - 1].last_column }, be && (I._$.range = [r[r.length - (x || 1)].range[0], r[r.length - 1].range[1]]), z = this.performAction.apply(I, [u, ee, V, L.yy, S[1], p, r].concat(ke)), typeof z < "u")
                            return z;
                        x && (o = o.slice(0, -1 * x * 2), p = p.slice(0, -1 * x), r = r.slice(0, -1 * x)), o.push(this.productions_[S[1]][0]), p.push(I.$), r.push(I._$), re = U[o[o.length - 2]][o[o.length - 1]], o.push(re);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, me = (function () {
        var D = { EOF: 1, parseError: h(function (n, o) { if (this.yy.parser)
                this.yy.parser.parseError(n, o);
            else
                throw new Error(n); }, "parseError"), setInput: h(function (s, n) { return this.yy = n || this.yy || {}, this._input = s, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: h(function () { var s = this._input[0]; this.yytext += s, this.yyleng++, this.offset++, this.match += s, this.matched += s; var n = s.match(/(?:\r\n?|\n).*/g); return n ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), s; }, "input"), unput: h(function (s) { var n = s.length, o = s.split(/(?:\r\n?|\n)/g); this._input = s + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - n), this.offset -= n; var c = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), o.length - 1 && (this.yylineno -= o.length - 1); var p = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: o ? (o.length === c.length ? this.yylloc.first_column : 0) + c[c.length - o.length].length - o[0].length : this.yylloc.first_column - n }, this.options.ranges && (this.yylloc.range = [p[0], p[0] + this.yyleng - n]), this.yyleng = this.yytext.length, this; }, "unput"), more: h(function () { return this._more = !0, this; }, "more"), reject: h(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: h(function (s) { this.unput(this.match.slice(s)); }, "less"), pastInput: h(function () { var s = this.matched.substr(0, this.matched.length - this.match.length); return (s.length > 20 ? "..." : "") + s.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: h(function () { var s = this.match; return s.length < 20 && (s += this._input.substr(0, 20 - s.length)), (s.substr(0, 20) + (s.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: h(function () {
                var s = this.pastInput(), n = new Array(s.length + 1).join("-");
                return s + this.upcomingInput() + `
` + n + "^";
            }, "showPosition"), test_match: h(function (s, n) { var o, c, p; if (this.options.backtrack_lexer && (p = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (p.yylloc.range = this.yylloc.range.slice(0))), c = s[0].match(/(?:\r\n?|\n).*/g), c && (this.yylineno += c.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: c ? c[c.length - 1].length - c[c.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + s[0].length }, this.yytext += s[0], this.match += s[0], this.matches = s, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(s[0].length), this.matched += s[0], o = this.performAction.call(this, this.yy, this, n, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), o)
                return o; if (this._backtrack) {
                for (var r in p)
                    this[r] = p[r];
                return !1;
            } return !1; }, "test_match"), next: h(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var s, n, o, c;
                this._more || (this.yytext = "", this.match = "");
                for (var p = this._currentRules(), r = 0; r < p.length; r++)
                    if (o = this._input.match(this.rules[p[r]]), o && (!n || o[0].length > n[0].length)) {
                        if (n = o, c = r, this.options.backtrack_lexer) {
                            if (s = this.test_match(o, p[r]), s !== !1)
                                return s;
                            if (this._backtrack) {
                                n = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return n ? (s = this.test_match(n, p[c]), s !== !1 ? s : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: h(function () { var n = this.next(); return n || this.lex(); }, "lex"), begin: h(function (n) { this.conditionStack.push(n); }, "begin"), popState: h(function () { var n = this.conditionStack.length - 1; return n > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: h(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: h(function (n) { return n = this.conditionStack.length - 1 - Math.abs(n || 0), n >= 0 ? this.conditionStack[n] : "INITIAL"; }, "topState"), pushState: h(function (n) { this.begin(n); }, "pushState"), stateStackSize: h(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: h(function (n, o, c, p) { var r = p; switch (c) {
                case 0:
                    return n.getLogger().trace("Found comment", o.yytext), 6;
                    break;
                case 1: return 8;
                case 2:
                    this.begin("CLASS");
                    break;
                case 3:
                    return this.popState(), 16;
                    break;
                case 4:
                    this.popState();
                    break;
                case 5:
                    n.getLogger().trace("Begin icon"), this.begin("ICON");
                    break;
                case 6:
                    return n.getLogger().trace("SPACELINE"), 6;
                    break;
                case 7: return 7;
                case 8: return 15;
                case 9:
                    n.getLogger().trace("end icon"), this.popState();
                    break;
                case 10:
                    return n.getLogger().trace("Exploding node"), this.begin("NODE"), 19;
                    break;
                case 11:
                    return n.getLogger().trace("Cloud"), this.begin("NODE"), 19;
                    break;
                case 12:
                    return n.getLogger().trace("Explosion Bang"), this.begin("NODE"), 19;
                    break;
                case 13:
                    return n.getLogger().trace("Cloud Bang"), this.begin("NODE"), 19;
                    break;
                case 14:
                    return this.begin("NODE"), 19;
                    break;
                case 15:
                    return this.begin("NODE"), 19;
                    break;
                case 16:
                    return this.begin("NODE"), 19;
                    break;
                case 17:
                    return this.begin("NODE"), 19;
                    break;
                case 18: return 13;
                case 19: return 22;
                case 20: return 11;
                case 21:
                    this.begin("NSTR2");
                    break;
                case 22: return "NODE_DESCR";
                case 23:
                    this.popState();
                    break;
                case 24:
                    n.getLogger().trace("Starting NSTR"), this.begin("NSTR");
                    break;
                case 25:
                    return n.getLogger().trace("description:", o.yytext), "NODE_DESCR";
                    break;
                case 26:
                    this.popState();
                    break;
                case 27:
                    return this.popState(), n.getLogger().trace("node end ))"), "NODE_DEND";
                    break;
                case 28:
                    return this.popState(), n.getLogger().trace("node end )"), "NODE_DEND";
                    break;
                case 29:
                    return this.popState(), n.getLogger().trace("node end ...", o.yytext), "NODE_DEND";
                    break;
                case 30:
                    return this.popState(), n.getLogger().trace("node end (("), "NODE_DEND";
                    break;
                case 31:
                    return this.popState(), n.getLogger().trace("node end (-"), "NODE_DEND";
                    break;
                case 32:
                    return this.popState(), n.getLogger().trace("node end (-"), "NODE_DEND";
                    break;
                case 33:
                    return this.popState(), n.getLogger().trace("node end (("), "NODE_DEND";
                    break;
                case 34:
                    return this.popState(), n.getLogger().trace("node end (("), "NODE_DEND";
                    break;
                case 35:
                    return n.getLogger().trace("Long description:", o.yytext), 20;
                    break;
                case 36:
                    return n.getLogger().trace("Long description:", o.yytext), 20;
                    break;
            } }, "anonymous"), rules: [/^(?:\s*%%.*)/i, /^(?:mindmap\b)/i, /^(?::::)/i, /^(?:.+)/i, /^(?:\n)/i, /^(?:::icon\()/i, /^(?:[\s]+[\n])/i, /^(?:[\n]+)/i, /^(?:[^\)]+)/i, /^(?:\))/i, /^(?:-\))/i, /^(?:\(-)/i, /^(?:\)\))/i, /^(?:\))/i, /^(?:\(\()/i, /^(?:\{\{)/i, /^(?:\()/i, /^(?:\[)/i, /^(?:[\s]+)/i, /^(?:[^\(\[\n\)\{\}]+)/i, /^(?:$)/i, /^(?:["][`])/i, /^(?:[^`"]+)/i, /^(?:[`]["])/i, /^(?:["])/i, /^(?:[^"]+)/i, /^(?:["])/i, /^(?:[\)]\))/i, /^(?:[\)])/i, /^(?:[\]])/i, /^(?:\}\})/i, /^(?:\(-)/i, /^(?:-\))/i, /^(?:\(\()/i, /^(?:\()/i, /^(?:[^\)\]\(\}]+)/i, /^(?:.+(?!\(\())/i], conditions: { CLASS: { rules: [3, 4], inclusive: !1 }, ICON: { rules: [8, 9], inclusive: !1 }, NSTR2: { rules: [22, 23], inclusive: !1 }, NSTR: { rules: [25, 26], inclusive: !1 }, NODE: { rules: [21, 24, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 5, 6, 7, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20], inclusive: !0 } } };
        return D;
    })();
    j.lexer = me;
    function P() { this.yy = {}; }
    return h(P, "Parser"), P.prototype = j, j.Parser = P, new P;
})();
K.parser = K;
var Ne = K, De = 12, N = { DEFAULT: 0, NO_BORDER: 0, ROUNDED_RECT: 1, RECT: 2, CIRCLE: 3, CLOUD: 4, BANG: 5, HEXAGON: 6 }, Le = class {
    constructor() { this.nodes = [], this.count = 0, this.elements = {}, this.getLogger = this.getLogger.bind(this), this.nodeType = N, this.clear(), this.getType = this.getType.bind(this), this.getElementById = this.getElementById.bind(this), this.getParent = this.getParent.bind(this), this.getMindmap = this.getMindmap.bind(this), this.addNode = this.addNode.bind(this), this.decorateNode = this.decorateNode.bind(this); }
    static { h(this, "MindmapDB"); }
    clear() { this.nodes = [], this.count = 0, this.elements = {}, this.baseLevel = void 0; }
    getParent(e) { for (let i = this.nodes.length - 1; i >= 0; i--)
        if (this.nodes[i].level < e)
            return this.nodes[i]; return null; }
    getMindmap() { return this.nodes.length > 0 ? this.nodes[0] : null; }
    addNode(e, i, l, a) { T.info("addNode", e, i, l, a); let t = !1; this.nodes.length === 0 ? (this.baseLevel = e, e = 0, t = !0) : this.baseLevel !== void 0 && (e = e - this.baseLevel, t = !1); let d = C(), f = d.mindmap?.padding ?? B.mindmap.padding; switch (a) {
        case this.nodeType.ROUNDED_RECT:
        case this.nodeType.RECT:
        case this.nodeType.HEXAGON:
            f *= 2;
            break;
    } let m = { id: this.count++, nodeId: M(i, d), level: e, descr: M(l, d), type: a, children: [], width: d.mindmap?.maxNodeWidth ?? B.mindmap.maxNodeWidth, padding: f, isRoot: t }, b = this.getParent(e); if (b)
        b.children.push(m), this.nodes.push(m);
    else if (t)
        this.nodes.push(m);
    else
        throw new Error(`There can be only one root. No parent could be found for ("${m.descr}")`); }
    getType(e, i) { switch (T.debug("In get type", e, i), e) {
        case "[": return this.nodeType.RECT;
        case "(": return i === ")" ? this.nodeType.ROUNDED_RECT : this.nodeType.CLOUD;
        case "((": return this.nodeType.CIRCLE;
        case ")": return this.nodeType.CLOUD;
        case "))": return this.nodeType.BANG;
        case "{{": return this.nodeType.HEXAGON;
        default: return this.nodeType.DEFAULT;
    } }
    setElementForId(e, i) { this.elements[e] = i; }
    getElementById(e) { return this.elements[e]; }
    decorateNode(e) { if (!e)
        return; let i = C(), l = this.nodes[this.nodes.length - 1]; e.icon && (l.icon = M(e.icon, i)), e.class && (l.class = M(e.class, i)); }
    type2Str(e) { switch (e) {
        case this.nodeType.DEFAULT: return "no-border";
        case this.nodeType.RECT: return "rect";
        case this.nodeType.ROUNDED_RECT: return "rounded-rect";
        case this.nodeType.CIRCLE: return "circle";
        case this.nodeType.CLOUD: return "cloud";
        case this.nodeType.BANG: return "bang";
        case this.nodeType.HEXAGON: return "hexgon";
        default: return "no-border";
    } }
    assignSections(e, i) { if (e.level === 0 ? e.section = void 0 : e.section = i, e.children)
        for (let [l, a] of e.children.entries()) {
            let t = e.level === 0 ? l % (De - 1) : i;
            this.assignSections(a, t);
        } }
    flattenNodes(e, i) { let l = C(), a = ["mindmap-node"]; e.isRoot === !0 ? a.push("section-root", "section--1") : e.section !== void 0 && a.push(`section-${e.section}`), e.class && a.push(e.class); let t = a.join(" "), d = h(m => { let O = (l.theme?.toLowerCase() ?? "").includes("redux"); switch (m) {
        case N.CIRCLE: return "mindmapCircle";
        case N.RECT: return "rect";
        case N.ROUNDED_RECT: return "rounded";
        case N.CLOUD: return "cloud";
        case N.BANG: return "bang";
        case N.HEXAGON: return "hexagon";
        case N.DEFAULT: return O ? "rounded" : "defaultMindmapNode";
        case N.NO_BORDER:
        default: return "rect";
    } }, "getShapeFromType"), f = { id: e.id.toString(), domId: "node_" + e.id.toString(), label: e.descr, labelType: "markdown", isGroup: !1, shape: d(e.type), width: e.width, height: e.height ?? 0, padding: e.padding, cssClasses: t, cssStyles: [], look: l.look, icon: e.icon, x: e.x, y: e.y, level: e.level, nodeId: e.nodeId, type: e.type, section: e.section }; if (i.push(f), e.children)
        for (let m of e.children)
            this.flattenNodes(m, i); }
    generateEdges(e, i) { if (!e.children)
        return; let l = C(); for (let a of e.children) {
        let t = "edge";
        a.section !== void 0 && (t += ` section-edge-${a.section}`);
        let d = e.level + 1;
        t += ` edge-depth-${d}`;
        let f = { id: `edge_${e.id}_${a.id}`, start: e.id.toString(), end: a.id.toString(), type: "normal", curve: "basis", thickness: "normal", look: l.look, classes: t, depth: e.level, section: a.section };
        i.push(f), this.generateEdges(a, i);
    } }
    getData() { let e = this.getMindmap(), i = C(), a = he().layout !== void 0, t = i; if (a || (t.layout = "cose-bilkent"), !e)
        return { nodes: [], edges: [], config: t }; T.debug("getData: mindmapRoot", e, i), this.assignSections(e); let d = [], f = []; this.flattenNodes(e, d), this.generateEdges(e, f), T.debug(`getData: processed ${d.length} nodes and ${f.length} edges`); let m = new Map; for (let b of d)
        m.set(b.id, { shape: b.shape, width: b.width, height: b.height, padding: b.padding }); return { nodes: d, edges: f, config: t, rootNode: e, markers: ["point"], direction: "TB", nodeSpacing: 50, rankSpacing: 50, shapes: Object.fromEntries(m), type: "mindmap", diagramId: "mindmap-" + J() }; }
    getLogger() { return T; }
}, ve = h((e, i, l, a) => se(null, null, function* () {
    T.debug(`Rendering mindmap diagram
` + e);
    let t = a.db, d = t.getData(), f = ue(i, d.config.securityLevel);
    if (d.type = a.type, d.layoutAlgorithm = ge(d.config.layout, { fallback: "cose-bilkent" }), d.diagramId = i, !t.getMindmap())
        return;
    d.nodes.forEach(g => { g.shape === "rounded" ? (g.radius = 15, g.taper = 15, g.stroke = "none", g.width = 0, g.padding = 15) : g.shape === "circle" ? g.padding = 10 : g.shape === "rect" ? (g.width = 0, g.padding = 10) : g.shape === "hexagon" && (g.width = 0, g.height = 0); }), yield de(d, f);
    let { themeVariables: b } = le(), { useGradient: O, gradientStart: w, gradientStop: R } = b;
    if (O && w && R) {
        let g = f.attr("id"), A = f.append("defs").append("linearGradient").attr("id", `${g}-gradient`).attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
        A.append("stop").attr("offset", "0%").attr("stop-color", w).attr("stop-opacity", 1), A.append("stop").attr("offset", "100%").attr("stop-color", R).attr("stop-opacity", 1);
    }
    pe(f, d.config.mindmap?.padding ?? B.mindmap.padding, "mindmapDiagram", d.config.mindmap?.useMaxWidth ?? B.mindmap.useMaxWidth);
}), "draw"), Te = { draw: ve }, Oe = h(e => {
    let { theme: i, look: l } = e, a = "";
    for (let t = 0; t < e.THEME_COLOR_LIMIT; t++)
        e["lineColor" + t] = e["lineColor" + t] || e["cScaleInv" + t], oe(e["lineColor" + t]) ? e["lineColor" + t] = ae(e["lineColor" + t], 20) : e["lineColor" + t] = ce(e["lineColor" + t], 20);
    for (let t = 0; t < e.THEME_COLOR_LIMIT; t++) {
        let d = "" + (l === "neo" ? Math.max(10 - (t - 1) * 2, 2) : 17 - 3 * t);
        a += `
    .section-${t - 1} rect, .section-${t - 1} path, .section-${t - 1} circle, .section-${t - 1} polygon, .section-${t - 1} path  {
      fill: ${e["cScale" + t]};
    }
    .section-${t - 1} text {
     fill: ${e["cScaleLabel" + t]};
    }
     .section-${t - 1} span {
     color: ${e["cScaleLabel" + t]};
    }
    .node-icon-${t - 1} {
      font-size: 40px;
      color: ${e["cScaleLabel" + t]};
    }
    .section-edge-${t - 1}{
      stroke: ${e["cScale" + t]};
    }
    .edge-depth-${t - 1}{
      stroke-width: ${d};
    }
    .section-${t - 1} line {
      stroke: ${e["cScaleInv" + t]} ;
      stroke-width: 3;
    }

    .disabled, .disabled circle, .disabled text {
      fill: lightgray;
    }
    .disabled text {
      fill: #efefef;
    }
    [data-look="neo"].mindmap-node.section-${t - 1} rect, [data-look="neo"].mindmap-node.section-${t - 1} path, [data-look="neo"].mindmap-node.section-${t - 1} circle, [data-look="neo"].mindmap-node.section-${t - 1} polygon {
      fill: ${i === "redux" || i === "redux-dark" || i === "neutral" ? e.mainBkg : e["cScale" + t]};
      stroke: ${i === "redux" || i === "redux-dark" ? e.nodeBorder : e["cScale" + t]};
      stroke-width: ${e.strokeWidth ?? 2}px;
    }
    [data-look="neo"].section-edge-${t - 1}{
      stroke: ${i?.includes("redux") || i === "neo-dark" ? e.nodeBorder : e["cScale" + t]};
    }
    [data-look="neo"].mindmap-node.section-${t - 1} text {
     fill: ${i === "redux" || i === "redux-dark" ? e.nodeBorder : e["cScaleLabel" + (i === "neutral" ? 1 : t)]};
    }
    `;
    }
    return a;
}, "genSections"), Ie = h((e, i, l) => {
    let a = "";
    for (let t = 0; t < e; t++)
        a += `
    [data-look="neo"].mindmap-node.section-${t - 1} rect, [data-look="neo"].mindmap-node.section-${t - 1} path, [data-look="neo"].mindmap-node.section-${t - 1} circle, [data-look="neo"].mindmap-node.section-${t - 1} polygon {
      stroke: url(${i}-gradient);
      fill: ${l};
    }
    .section-${t - 1} line {
      stroke-width: 0;
    }`;
    return a;
}, "genGradient"), Ce = h(e => {
    let { theme: i } = e, l = e.svgId, a = e.dropShadow ? e.dropShadow.replace("url(#drop-shadow)", `url(${l}-drop-shadow)`) : "none";
    return `
  .edge {
    stroke-width: 3;
  }
  ${Oe(e)}
  .section-root rect, .section-root path, .section-root circle, .section-root polygon  {
    fill: ${e.git0};
  }
  .section-root text {
    fill: ${e.gitBranchLabel0};
  }
  .section-root span {
    color: ${i?.includes("redux") ? e.nodeBorder : e.gitBranchLabel0};
  }
  .icon-container {
    height:100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }
  .edge {
    fill: none;
  }
  .mindmap-node-label {
    dy: 1em;
    alignment-baseline: middle;
    text-anchor: middle;
    dominant-baseline: middle;
    text-align: center;
  }
  [data-look="neo"].mindmap-node  {
    filter: ${a};
  }
  [data-look="neo"].mindmap-node.section-root rect, [data-look="neo"].mindmap-node.section-root path, [data-look="neo"].mindmap-node.section-root circle, [data-look="neo"].mindmap-node.section-root polygon  {
    fill: ${i?.includes("redux") ? e.mainBkg : e.git0};
  }
  [data-look="neo"].mindmap-node.section-root .text-inner-tspan {
    fill:  ${i?.includes("redux") ? e.nodeBorder : e["cScaleLabel" + (i === "neutral" ? 1 : 0)]};
  }
  ${e.useGradient && l && e.mainBkg ? Ie(e.THEME_COLOR_LIMIT, l, e.mainBkg) : ""}
`;
}, "getStyles"), we = Ce, nt = { get db() { return new Le; }, renderer: Te, parser: Ne, styles: we };
export { nt as diagram };
