import { a as st } from "@nf-internal/chunk-3UW5LP2A";
import { a as it } from "@nf-internal/chunk-WVCFK4LD";
import { b as et, c as tt } from "@nf-internal/chunk-4PKWXC3U";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { p as Je, s as $e } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { N as Ue, T as Ke, U as Ze, V as je, W as qe, X as We, Y as He, Z as Qe, _ as U, a as Pe, b as ze } from "@nf-internal/chunk-LEJRRF65";
import { b as A, h as Xe } from "@nf-internal/chunk-RZWXGGKD";
import { a as d, b as Ye } from "@nf-internal/chunk-YUSHYV7C";
import { a as Be, b as Ge, f as Fe } from "@nf-internal/chunk-OSQMNGTH";
var Oe = (function () {
    var t = d(function (M, a, o, h) { for (o = o || {}, h = M.length; h--; o[M[h]] = a)
        ; return o; }, "o"), n = [6, 9, 21, 23, 25, 27, 34, 37, 38, 39, 40, 41, 43, 46, 47, 51, 53, 54, 55], u = [2, 2], r = [1, 7], l = [1, 9], f = [1, 10], _ = [1, 11], p = [1, 12], S = [1, 30], b = [1, 23], k = [1, 24], x = [1, 25], B = [1, 26], Y = [1, 27], m = [1, 19], I = [1, 28], K = [1, 29], N = [1, 20], R = [1, 18], v = [1, 21], D = [1, 22], xe = [2, 6], c = [6, 9, 21, 23, 25, 27, 33, 34, 37, 38, 39, 40, 41, 43, 46, 47, 51, 53, 54, 55], de = [1, 36], be = [1, 37], pe = [1, 38], fe = [1, 39], ke = [1, 40], Z = [6, 9, 12, 14, 16, 19, 20, 21, 23, 25, 27, 33, 34, 37, 38, 39, 40, 41, 43, 46, 47, 50, 51, 53, 54, 55, 69, 70, 71, 72, 73], L = [1, 46], w = [1, 47], j = [1, 57], q = [43, 51, 53, 54, 55, 74, 75], W = [1, 70], H = [1, 68], V = [1, 65], Q = [1, 69], X = [1, 71], ee = [6, 9, 12, 16, 21, 23, 25, 27, 33, 34, 37, 38, 39, 40, 41, 43, 44, 45, 46, 47, 51, 52, 53, 54, 55, 69, 70, 71, 72, 73], te = [1, 78], se = [1, 77], ie = [1, 76], Ne = [69, 70, 71, 72, 73], Ce = [1, 91], Ae = [6, 9, 45, 50], P = [6, 9, 12, 44, 45, 50, 51, 52], re = [1, 101], ae = [1, 100], ne = [1, 99], J = [18, 61], Ie = [1, 110], Re = [1, 109], ve = [20, 43, 51, 53, 54, 55], ge = [18, 61, 64, 66], ye = { trace: d(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, ER_DIAGRAM: 4, document: 5, EOF: 6, line: 7, statement: 8, NEWLINE: 9, entityName: 10, relSpec: 11, COLON: 12, role: 13, STYLE_SEPARATOR: 14, idList: 15, BLOCK_START: 16, attributes: 17, BLOCK_STOP: 18, SQS: 19, SQE: 20, title: 21, title_value: 22, acc_title: 23, acc_title_value: 24, acc_descr: 25, acc_descr_value: 26, acc_descr_multiline_value: 27, direction: 28, classDefStatement: 29, classStatement: 30, styleStatement: 31, subgraphHeader: 32, END: 33, SUBGRAPH: 34, separator: 35, subgraphTitle: 36, direction_tb: 37, direction_bt: 38, direction_rl: 39, direction_lr: 40, CLASSDEF: 41, stylesOpt: 42, UNICODE_TEXT: 43, STYLE_TEXT: 44, COMMA: 45, CLASS: 46, STYLE: 47, style: 48, styleComponent: 49, SEMI: 50, NUM: 51, BRKT: 52, ENTITY_NAME: 53, DECIMAL_NUM: 54, ENTITY_ONE: 55, attribute: 56, attributeType: 57, attributeName: 58, attributeKeyTypeList: 59, attributeComment: 60, ATTRIBUTE_WORD: 61, "?": 62, attributeKeyType: 63, ",": 64, ATTRIBUTE_KEY: 65, COMMENT: 66, cardinality: 67, relType: 68, ZERO_OR_ONE: 69, ZERO_OR_MORE: 70, ONE_OR_MORE: 71, ONLY_ONE: 72, MD_PARENT: 73, NON_IDENTIFYING: 74, IDENTIFYING: 75, WORD: 76, $accept: 0, $end: 1 }, terminals_: { 2: "error", 4: "ER_DIAGRAM", 6: "EOF", 9: "NEWLINE", 12: "COLON", 14: "STYLE_SEPARATOR", 16: "BLOCK_START", 18: "BLOCK_STOP", 19: "SQS", 20: "SQE", 21: "title", 22: "title_value", 23: "acc_title", 24: "acc_title_value", 25: "acc_descr", 26: "acc_descr_value", 27: "acc_descr_multiline_value", 33: "END", 34: "SUBGRAPH", 37: "direction_tb", 38: "direction_bt", 39: "direction_rl", 40: "direction_lr", 41: "CLASSDEF", 43: "UNICODE_TEXT", 44: "STYLE_TEXT", 45: "COMMA", 46: "CLASS", 47: "STYLE", 50: "SEMI", 51: "NUM", 52: "BRKT", 53: "ENTITY_NAME", 54: "DECIMAL_NUM", 55: "ENTITY_ONE", 61: "ATTRIBUTE_WORD", 62: "?", 64: ",", 65: "ATTRIBUTE_KEY", 66: "COMMENT", 69: "ZERO_OR_ONE", 70: "ZERO_OR_MORE", 71: "ONE_OR_MORE", 72: "ONLY_ONE", 73: "MD_PARENT", 74: "NON_IDENTIFYING", 75: "IDENTIFYING", 76: "WORD" }, productions_: [0, [3, 3], [5, 0], [5, 2], [7, 1], [7, 1], [7, 1], [8, 5], [8, 9], [8, 7], [8, 7], [8, 4], [8, 6], [8, 3], [8, 5], [8, 1], [8, 3], [8, 7], [8, 9], [8, 6], [8, 8], [8, 4], [8, 6], [8, 2], [8, 2], [8, 2], [8, 1], [8, 1], [8, 1], [8, 1], [8, 1], [8, 3], [32, 3], [32, 6], [36, 1], [36, 2], [28, 1], [28, 1], [28, 1], [28, 1], [29, 4], [15, 1], [15, 1], [15, 3], [15, 3], [30, 3], [31, 4], [42, 1], [42, 3], [48, 1], [48, 2], [35, 1], [35, 1], [35, 1], [49, 1], [49, 1], [49, 1], [49, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [17, 1], [17, 2], [56, 2], [56, 3], [56, 3], [56, 4], [57, 1], [57, 2], [58, 1], [59, 1], [59, 3], [63, 1], [60, 1], [11, 3], [67, 1], [67, 1], [67, 1], [67, 1], [67, 1], [68, 1], [68, 1], [13, 1], [13, 1], [13, 1]], performAction: d(function (a, o, h, i, g, e, $) { var s = e.length - 1; switch (g) {
            case 1: break;
            case 2:
                this.$ = [];
                break;
            case 3:
                this.$ = e[s - 1].concat(e[s]);
                break;
            case 4:
                this.$ = e[s];
                break;
            case 5:
            case 6:
                this.$ = [];
                break;
            case 7:
                i.addEntity(e[s - 4]), i.addEntity(e[s - 2]), i.addRelationship(e[s - 4], e[s], e[s - 2], e[s - 3]), this.$ = [e[s - 4], e[s - 2]];
                break;
            case 8:
                i.addEntity(e[s - 8]), i.addEntity(e[s - 4]), i.addRelationship(e[s - 8], e[s], e[s - 4], e[s - 5]), i.setClass([e[s - 8]], e[s - 6]), i.setClass([e[s - 4]], e[s - 2]), this.$ = [e[s - 8], e[s - 4]];
                break;
            case 9:
                i.addEntity(e[s - 6]), i.addEntity(e[s - 2]), i.addRelationship(e[s - 6], e[s], e[s - 2], e[s - 3]), i.setClass([e[s - 6]], e[s - 4]), this.$ = [e[s - 6], e[s - 2]];
                break;
            case 10:
                i.addEntity(e[s - 6]), i.addEntity(e[s - 4]), i.addRelationship(e[s - 6], e[s], e[s - 4], e[s - 5]), i.setClass([e[s - 4]], e[s - 2]), this.$ = [e[s - 6], e[s - 4]];
                break;
            case 11:
                i.addEntity(e[s - 3]), i.addAttributes(e[s - 3], e[s - 1]), this.$ = [e[s - 3]];
                break;
            case 12:
                i.addEntity(e[s - 5]), i.addAttributes(e[s - 5], e[s - 1]), i.setClass([e[s - 5]], e[s - 3]), this.$ = [e[s - 5]];
                break;
            case 13:
                i.addEntity(e[s - 2]), this.$ = [e[s - 2]];
                break;
            case 14:
                i.addEntity(e[s - 4]), i.setClass([e[s - 4]], e[s - 2]), this.$ = [e[s - 4]];
                break;
            case 15:
                i.addEntity(e[s]), this.$ = [e[s]];
                break;
            case 16:
                i.addEntity(e[s - 2]), i.setClass([e[s - 2]], e[s]), this.$ = [e[s - 2]];
                break;
            case 17:
                i.addEntity(e[s - 6], e[s - 4]), i.addAttributes(e[s - 6], e[s - 1]), this.$ = [e[s - 6]];
                break;
            case 18:
                i.addEntity(e[s - 8], e[s - 6]), i.addAttributes(e[s - 8], e[s - 1]), i.setClass([e[s - 8]], e[s - 3]), this.$ = [e[s - 8]];
                break;
            case 19:
                i.addEntity(e[s - 5], e[s - 3]), this.$ = [e[s - 5]];
                break;
            case 20:
                i.addEntity(e[s - 7], e[s - 5]), i.setClass([e[s - 7]], e[s - 2]), this.$ = [e[s - 7]];
                break;
            case 21:
                i.addEntity(e[s - 3], e[s - 1]);
                break;
            case 22:
                i.addEntity(e[s - 5], e[s - 3]), i.setClass([e[s - 5]], e[s]);
                break;
            case 23:
            case 24:
                this.$ = e[s].trim(), i.setAccTitle(this.$);
                break;
            case 25:
            case 26:
                this.$ = e[s].trim(), i.setAccDescription(this.$);
                break;
            case 27:
                i.subgraphDepth ? this.$ = e[s] : (i.setDirection(e[s].value), this.$ = []);
                break;
            case 31:
                i.subgraphDepth = (i.subgraphDepth || 1) - 1, this.$ = i.addSubGraph({ text: e[s - 2].id }, e[s - 1], { text: e[s - 2].text });
                break;
            case 32:
                i.subgraphDepth = (i.subgraphDepth || 0) + 1, this.$ = { id: e[s - 1], text: e[s - 1] };
                break;
            case 33:
                i.subgraphDepth = (i.subgraphDepth || 0) + 1, this.$ = { id: e[s - 4], text: e[s - 2] };
                break;
            case 34:
            case 59:
            case 60:
            case 61:
            case 62:
            case 86:
                this.$ = e[s];
                break;
            case 35:
                this.$ = e[s - 1] + " " + e[s];
                break;
            case 36:
                this.$ = { stmt: "dir", value: "TB" };
                break;
            case 37:
                this.$ = { stmt: "dir", value: "BT" };
                break;
            case 38:
                this.$ = { stmt: "dir", value: "RL" };
                break;
            case 39:
                this.$ = { stmt: "dir", value: "LR" };
                break;
            case 40:
                this.$ = e[s - 3], i.addClass(e[s - 2], e[s - 1]);
                break;
            case 41:
            case 42:
            case 63:
            case 72:
                this.$ = [e[s]];
                break;
            case 43:
            case 44:
                this.$ = e[s - 2].concat([e[s]]);
                break;
            case 45:
                this.$ = e[s - 2], i.setClass(e[s - 1], e[s]);
                break;
            case 46:
                this.$ = e[s - 3], i.addCssStyles(e[s - 2], e[s - 1]);
                break;
            case 47:
                this.$ = [e[s]];
                break;
            case 48:
                e[s - 2].push(e[s]), this.$ = e[s - 2];
                break;
            case 50:
                this.$ = e[s - 1] + e[s];
                break;
            case 58:
            case 84:
            case 85:
                this.$ = e[s].replace(/"/g, "");
                break;
            case 64:
                e[s].push(e[s - 1]), this.$ = e[s];
                break;
            case 65:
                this.$ = { type: e[s - 1], name: e[s] };
                break;
            case 66:
                this.$ = { type: e[s - 2], name: e[s - 1], keys: e[s] };
                break;
            case 67:
                this.$ = { type: e[s - 2], name: e[s - 1], comment: e[s] };
                break;
            case 68:
                this.$ = { type: e[s - 3], name: e[s - 2], keys: e[s - 1], comment: e[s] };
                break;
            case 69:
            case 71:
            case 74:
                this.$ = e[s];
                break;
            case 70:
                this.$ = e[s - 1] + e[s];
                break;
            case 73:
                e[s - 2].push(e[s]), this.$ = e[s - 2];
                break;
            case 75:
                this.$ = e[s].replace(/"/g, "");
                break;
            case 76:
                this.$ = { cardA: e[s], relType: e[s - 1], cardB: e[s - 2] };
                break;
            case 77:
                this.$ = i.Cardinality.ZERO_OR_ONE;
                break;
            case 78:
                this.$ = i.Cardinality.ZERO_OR_MORE;
                break;
            case 79:
                this.$ = i.Cardinality.ONE_OR_MORE;
                break;
            case 80:
                this.$ = i.Cardinality.ONLY_ONE;
                break;
            case 81:
                this.$ = i.Cardinality.MD_PARENT;
                break;
            case 82:
                this.$ = i.Identification.NON_IDENTIFYING;
                break;
            case 83:
                this.$ = i.Identification.IDENTIFYING;
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: [1, 2] }, { 1: [3] }, t(n, u, { 5: 3 }), { 6: [1, 4], 7: 5, 8: 6, 9: r, 10: 8, 21: l, 23: f, 25: _, 27: p, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 34: S, 37: b, 38: k, 39: x, 40: B, 41: Y, 43: m, 46: I, 47: K, 51: N, 53: R, 54: v, 55: D }, t(n, xe, { 1: [2, 1] }), t(c, [2, 3]), t(c, [2, 4]), t(c, [2, 5]), t(c, [2, 15], { 11: 31, 67: 35, 14: [1, 32], 16: [1, 33], 19: [1, 34], 69: de, 70: be, 71: pe, 72: fe, 73: ke }), { 22: [1, 41] }, { 24: [1, 42] }, { 26: [1, 43] }, t(c, [2, 26]), t(c, [2, 27]), t(c, [2, 28]), t(c, [2, 29]), t(c, [2, 30]), t(c, u, { 5: 44 }), t(Z, [2, 58]), t(Z, [2, 59]), t(Z, [2, 60]), t(Z, [2, 61]), t(Z, [2, 62]), t(c, [2, 36]), t(c, [2, 37]), t(c, [2, 38]), t(c, [2, 39]), { 15: 45, 43: L, 44: w }, { 15: 48, 43: L, 44: w }, { 15: 49, 43: L, 44: w }, { 10: 50, 43: m, 51: N, 53: R, 54: v, 55: D }, { 10: 51, 43: m, 51: N, 53: R, 54: v, 55: D }, { 15: 52, 43: L, 44: w }, { 17: 53, 18: [1, 54], 56: 55, 57: 56, 61: j }, { 10: 58, 43: m, 51: N, 53: R, 54: v, 55: D }, { 68: 59, 74: [1, 60], 75: [1, 61] }, t(q, [2, 77]), t(q, [2, 78]), t(q, [2, 79]), t(q, [2, 80]), t(q, [2, 81]), t(c, [2, 23]), t(c, [2, 24]), t(c, [2, 25]), { 6: [1, 63], 7: 5, 8: 6, 9: r, 10: 8, 21: l, 23: f, 25: _, 27: p, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 33: [1, 62], 34: S, 37: b, 38: k, 39: x, 40: B, 41: Y, 43: m, 46: I, 47: K, 51: N, 53: R, 54: v, 55: D }, { 12: W, 42: 64, 44: H, 45: V, 48: 66, 49: 67, 51: Q, 52: X }, t(ee, [2, 41]), t(ee, [2, 42]), { 15: 72, 43: L, 44: w, 45: V }, { 12: W, 42: 73, 44: H, 45: V, 48: 66, 49: 67, 51: Q, 52: X }, { 6: te, 9: se, 19: [1, 75], 35: 74, 50: ie }, { 12: [1, 79], 14: [1, 80] }, t(c, [2, 16], { 67: 35, 11: 81, 16: [1, 82], 45: V, 69: de, 70: be, 71: pe, 72: fe, 73: ke }), { 18: [1, 83] }, t(c, [2, 13]), { 17: 84, 18: [2, 63], 56: 55, 57: 56, 61: j }, { 58: 85, 61: [1, 86] }, { 61: [2, 69], 62: [1, 87] }, { 20: [1, 88] }, { 67: 89, 69: de, 70: be, 71: pe, 72: fe, 73: ke }, t(Ne, [2, 82]), t(Ne, [2, 83]), t(c, [2, 31]), t(c, xe), { 6: te, 9: se, 35: 90, 45: Ce, 50: ie }, { 43: [1, 92], 44: [1, 93] }, t(Ae, [2, 47], { 49: 94, 12: W, 44: H, 51: Q, 52: X }), t(P, [2, 49]), t(P, [2, 54]), t(P, [2, 55]), t(P, [2, 56]), t(P, [2, 57]), t(c, [2, 45], { 45: V }), { 6: te, 9: se, 35: 95, 45: Ce, 50: ie }, t(c, [2, 32]), { 10: 97, 36: 96, 43: m, 51: N, 53: R, 54: v, 55: D }, t(c, [2, 51]), t(c, [2, 52]), t(c, [2, 53]), { 13: 98, 43: re, 53: ae, 76: ne }, { 15: 102, 43: L, 44: w }, { 10: 103, 43: m, 51: N, 53: R, 54: v, 55: D }, { 17: 104, 18: [1, 105], 56: 55, 57: 56, 61: j }, t(c, [2, 11]), { 18: [2, 64] }, t(J, [2, 65], { 59: 106, 60: 107, 63: 108, 65: Ie, 66: Re }), t([18, 61, 65, 66], [2, 71]), { 61: [2, 70] }, t(c, [2, 21], { 14: [1, 112], 16: [1, 111] }), t([43, 51, 53, 54, 55], [2, 76]), t(c, [2, 40]), { 12: W, 44: H, 48: 113, 49: 67, 51: Q, 52: X }, t(ee, [2, 43]), t(ee, [2, 44]), t(P, [2, 50]), t(c, [2, 46]), { 10: 115, 20: [1, 114], 43: m, 51: N, 53: R, 54: v, 55: D }, t(ve, [2, 34]), t(c, [2, 7]), t(c, [2, 84]), t(c, [2, 85]), t(c, [2, 86]), { 12: [1, 116], 45: V }, { 12: [1, 118], 14: [1, 117] }, { 18: [1, 119] }, t(c, [2, 14]), t(J, [2, 66], { 60: 120, 64: [1, 121], 66: Re }), t(J, [2, 67]), t(ge, [2, 72]), t(J, [2, 75]), t(ge, [2, 74]), { 17: 122, 18: [1, 123], 56: 55, 57: 56, 61: j }, { 15: 124, 43: L, 44: w }, t(Ae, [2, 48], { 49: 94, 12: W, 44: H, 51: Q, 52: X }), { 6: te, 9: se, 35: 125, 50: ie }, t(ve, [2, 35]), { 13: 126, 43: re, 53: ae, 76: ne }, { 15: 127, 43: L, 44: w }, { 13: 128, 43: re, 53: ae, 76: ne }, t(c, [2, 12]), t(J, [2, 68]), { 63: 129, 65: Ie }, { 18: [1, 130] }, t(c, [2, 19]), t(c, [2, 22], { 16: [1, 131], 45: V }), t(c, [2, 33]), t(c, [2, 10]), { 12: [1, 132], 45: V }, t(c, [2, 9]), t(ge, [2, 73]), t(c, [2, 17]), { 17: 133, 18: [1, 134], 56: 55, 57: 56, 61: j }, { 13: 135, 43: re, 53: ae, 76: ne }, { 18: [1, 136] }, t(c, [2, 20]), t(c, [2, 8]), t(c, [2, 18])], defaultActions: { 84: [2, 64], 87: [2, 70] }, parseError: d(function (a, o) { if (o.recoverable)
            this.trace(a);
        else {
            var h = new Error(a);
            throw h.hash = o, h;
        } }, "parseError"), parse: d(function (a) {
            var o = this, h = [0], i = [], g = [null], e = [], $ = this.table, s = "", le = 0, De = 0, Le = 0, ot = 2, we = 1, lt = e.slice.call(arguments, 1), y = Object.create(this.lexer), G = { yy: {} };
            for (var _e in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, _e) && (G.yy[_e] = this.yy[_e]);
            y.setInput(a, G.yy), G.yy.lexer = y, G.yy.parser = this, typeof y.yylloc > "u" && (y.yylloc = {});
            var me = y.yylloc;
            e.push(me);
            var ct = y.options && y.options.ranges;
            typeof G.yy.parseError == "function" ? this.parseError = G.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function ht(T) { h.length = h.length - 2 * T, g.length = g.length - T, e.length = e.length - T; }
            d(ht, "popStack");
            function Ve() { var T; return T = i.pop() || y.lex() || we, typeof T != "number" && (T instanceof Array && (i = T, T = i.pop()), T = o.symbols_[T] || T), T; }
            d(Ve, "lex");
            for (var E, Ee, F, O, gt, Se, z = {}, ce, C, Me, he;;) {
                if (F = h[h.length - 1], this.defaultActions[F] ? O = this.defaultActions[F] : ((E === null || typeof E > "u") && (E = Ve()), O = $[F] && $[F][E]), typeof O > "u" || !O.length || !O[0]) {
                    var Te = "";
                    he = [];
                    for (ce in $[F])
                        this.terminals_[ce] && ce > ot && he.push("'" + this.terminals_[ce] + "'");
                    y.showPosition ? Te = "Parse error on line " + (le + 1) + `:
` + y.showPosition() + `
Expecting ` + he.join(", ") + ", got '" + (this.terminals_[E] || E) + "'" : Te = "Parse error on line " + (le + 1) + ": Unexpected " + (E == we ? "end of input" : "'" + (this.terminals_[E] || E) + "'"), this.parseError(Te, { text: y.match, token: this.terminals_[E] || E, line: y.yylineno, loc: me, expected: he });
                }
                if (O[0] instanceof Array && O.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + F + ", token: " + E);
                switch (O[0]) {
                    case 1:
                        h.push(E), g.push(y.yytext), e.push(y.yylloc), h.push(O[1]), E = null, Ee ? (E = Ee, Ee = null) : (De = y.yyleng, s = y.yytext, le = y.yylineno, me = y.yylloc, Le > 0 && Le--);
                        break;
                    case 2:
                        if (C = this.productions_[O[1]][1], z.$ = g[g.length - C], z._$ = { first_line: e[e.length - (C || 1)].first_line, last_line: e[e.length - 1].last_line, first_column: e[e.length - (C || 1)].first_column, last_column: e[e.length - 1].last_column }, ct && (z._$.range = [e[e.length - (C || 1)].range[0], e[e.length - 1].range[1]]), Se = this.performAction.apply(z, [s, De, le, G.yy, O[1], g, e].concat(lt)), typeof Se < "u")
                            return Se;
                        C && (h = h.slice(0, -1 * C * 2), g = g.slice(0, -1 * C), e = e.slice(0, -1 * C)), h.push(this.productions_[O[1]][0]), g.push(z.$), e.push(z._$), Me = $[h[h.length - 2]][h[h.length - 1]], h.push(Me);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, nt = (function () {
        var M = { EOF: 1, parseError: d(function (o, h) { if (this.yy.parser)
                this.yy.parser.parseError(o, h);
            else
                throw new Error(o); }, "parseError"), setInput: d(function (a, o) { return this.yy = o || this.yy || {}, this._input = a, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: d(function () { var a = this._input[0]; this.yytext += a, this.yyleng++, this.offset++, this.match += a, this.matched += a; var o = a.match(/(?:\r\n?|\n).*/g); return o ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), a; }, "input"), unput: d(function (a) { var o = a.length, h = a.split(/(?:\r\n?|\n)/g); this._input = a + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - o), this.offset -= o; var i = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), h.length - 1 && (this.yylineno -= h.length - 1); var g = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: h ? (h.length === i.length ? this.yylloc.first_column : 0) + i[i.length - h.length].length - h[0].length : this.yylloc.first_column - o }, this.options.ranges && (this.yylloc.range = [g[0], g[0] + this.yyleng - o]), this.yyleng = this.yytext.length, this; }, "unput"), more: d(function () { return this._more = !0, this; }, "more"), reject: d(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: d(function (a) { this.unput(this.match.slice(a)); }, "less"), pastInput: d(function () { var a = this.matched.substr(0, this.matched.length - this.match.length); return (a.length > 20 ? "..." : "") + a.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: d(function () { var a = this.match; return a.length < 20 && (a += this._input.substr(0, 20 - a.length)), (a.substr(0, 20) + (a.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: d(function () {
                var a = this.pastInput(), o = new Array(a.length + 1).join("-");
                return a + this.upcomingInput() + `
` + o + "^";
            }, "showPosition"), test_match: d(function (a, o) { var h, i, g; if (this.options.backtrack_lexer && (g = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (g.yylloc.range = this.yylloc.range.slice(0))), i = a[0].match(/(?:\r\n?|\n).*/g), i && (this.yylineno += i.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: i ? i[i.length - 1].length - i[i.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + a[0].length }, this.yytext += a[0], this.match += a[0], this.matches = a, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(a[0].length), this.matched += a[0], h = this.performAction.call(this, this.yy, this, o, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), h)
                return h; if (this._backtrack) {
                for (var e in g)
                    this[e] = g[e];
                return !1;
            } return !1; }, "test_match"), next: d(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var a, o, h, i;
                this._more || (this.yytext = "", this.match = "");
                for (var g = this._currentRules(), e = 0; e < g.length; e++)
                    if (h = this._input.match(this.rules[g[e]]), h && (!o || h[0].length > o[0].length)) {
                        if (o = h, i = e, this.options.backtrack_lexer) {
                            if (a = this.test_match(h, g[e]), a !== !1)
                                return a;
                            if (this._backtrack) {
                                o = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return o ? (a = this.test_match(o, g[i]), a !== !1 ? a : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: d(function () { var o = this.next(); return o || this.lex(); }, "lex"), begin: d(function (o) { this.conditionStack.push(o); }, "begin"), popState: d(function () { var o = this.conditionStack.length - 1; return o > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: d(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: d(function (o) { return o = this.conditionStack.length - 1 - Math.abs(o || 0), o >= 0 ? this.conditionStack[o] : "INITIAL"; }, "topState"), pushState: d(function (o) { this.begin(o); }, "pushState"), stateStackSize: d(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: d(function (o, h, i, g) { var e = g; switch (i) {
                case 0:
                    return this.begin("acc_title"), 23;
                    break;
                case 1:
                    return this.popState(), "acc_title_value";
                    break;
                case 2:
                    return this.begin("acc_descr"), 25;
                    break;
                case 3:
                    return this.popState(), "acc_descr_value";
                    break;
                case 4:
                    this.begin("acc_descr_multiline");
                    break;
                case 5:
                    this.popState();
                    break;
                case 6: return "acc_descr_multiline_value";
                case 7: return 37;
                case 8: return 38;
                case 9: return 39;
                case 10: return 40;
                case 11: break;
                case 12: return 9;
                case 13: return 53;
                case 14: return 76;
                case 15: return 4;
                case 16:
                    return this.begin("block"), 16;
                    break;
                case 17: return 52;
                case 18: return 52;
                case 19: return 45;
                case 20: return 14;
                case 21: return 12;
                case 22: break;
                case 23: return 65;
                case 24: return 61;
                case 25: return 61;
                case 26:
                    this.begin("block_bq");
                    break;
                case 27: return 61;
                case 28:
                    this.popState();
                    break;
                case 29: return 66;
                case 30: break;
                case 31:
                    return this.popState(), 18;
                    break;
                case 32: return h.yytext[0];
                case 33: return 19;
                case 34: return 20;
                case 35:
                    return this.begin("style"), 47;
                    break;
                case 36:
                    return this.popState(), 9;
                    break;
                case 37: break;
                case 38: return 12;
                case 39: return 45;
                case 40: return 52;
                case 41:
                    return this.begin("style"), 41;
                    break;
                case 42: return 46;
                case 43: return 34;
                case 44: return 33;
                case 45: return 69;
                case 46: return 71;
                case 47: return 71;
                case 48: return 71;
                case 49: return 69;
                case 50: return 69;
                case 51: return 70;
                case 52: return 70;
                case 53: return 70;
                case 54: return 70;
                case 55: return 70;
                case 56: return 71;
                case 57: return 70;
                case 58: return 71;
                case 59: return 72;
                case 60: return 72;
                case 61: return 54;
                case 62: return 72;
                case 63: return 72;
                case 64: return 72;
                case 65: return 55;
                case 66: return 51;
                case 67: return 72;
                case 68: return 69;
                case 69: return 70;
                case 70: return 71;
                case 71: return 73;
                case 72: return 74;
                case 73: return 75;
                case 74: return 75;
                case 75: return 74;
                case 76: return 74;
                case 77: return 74;
                case 78: return 44;
                case 79: return 50;
                case 80: return 43;
                case 81: return h.yytext[0];
                case 82: return 6;
            } }, "anonymous"), rules: [/^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:.*direction\s+TB[^\n]*)/i, /^(?:.*direction\s+BT[^\n]*)/i, /^(?:.*direction\s+RL[^\n]*)/i, /^(?:.*direction\s+LR[^\n]*)/i, /^(?:[ \t\r]+)/i, /^(?:[\n]+)/i, /^(?:"[^"%\r\n\v\b\\]+")/i, /^(?:"[^"]*")/i, /^(?:erDiagram\b)/i, /^(?:\{)/i, /^(?:#)/i, /^(?:#)/i, /^(?:,)/i, /^(?::::)/i, /^(?::)/i, /^(?:\s+)/i, /^(?:\b((?:PK)|(?:FK)|(?:UK))\b)/i, /^(?:([^\s]*)[~].*[~]([^\s]*))/i, /^(?:([\*A-Za-z_\u00C0-\uFFFF][A-Za-z0-9\-\_\[\]\(\)\.,\u00C0-\uFFFF\*]*))/i, /^(?:[`])/i, /^(?:[^`]+)/i, /^(?:[`])/i, /^(?:"[^"]*")/i, /^(?:[\n]+)/i, /^(?:\})/i, /^(?:.)/i, /^(?:\[)/i, /^(?:\])/i, /^(?:style\b)/i, /^(?:[\n]+)/i, /^(?:\s+)/i, /^(?::)/i, /^(?:,)/i, /^(?:#)/i, /^(?:classDef\b)/i, /^(?:class\b)/i, /^(?:subgraph\b)/i, /^(?:end\b\s*)/i, /^(?:one or zero\b)/i, /^(?:one or more\b)/i, /^(?:one or many\b)/i, /^(?:1\+)/i, /^(?:\|o\b)/i, /^(?:zero or one\b)/i, /^(?:zero or more\b)/i, /^(?:zero or many\b)/i, /^(?:0\+)/i, /^(?:\}o\b)/i, /^(?:many\(0\))/i, /^(?:many\(1\))/i, /^(?:many\b)/i, /^(?:\}\|)/i, /^(?:one\b)/i, /^(?:only one\b)/i, /^(?:[0-9]+\.[0-9]+)/i, /^(?:1(?=\s+[A-Za-z_"']))/i, /^(?:1(?=\s+[0-9]))/i, /^(?:1(?=(--|\.\.|\.-|-\.)))/i, /^(?:1\b)/i, /^(?:[0-9]+)/i, /^(?:\|\|)/i, /^(?:o\|)/i, /^(?:o\{)/i, /^(?:\|\{)/i, /^(?:u(?=[\.\-\|]))/i, /^(?:\.\.)/i, /^(?:--)/i, /^(?:to\b)/i, /^(?:optionally to\b)/i, /^(?:\.-)/i, /^(?:-\.)/i, /^(?:([^\x00-\x7F]|\w|-|\*)+)/i, /^(?:;)/i, /^(?:([^\x00-\x7F]|\w|-|\*|\.)+)/i, /^(?:.)/i, /^(?:$)/i], conditions: { style: { rules: [36, 37, 38, 39, 40, 78, 79], inclusive: !1 }, acc_descr_multiline: { rules: [5, 6], inclusive: !1 }, acc_descr: { rules: [3], inclusive: !1 }, acc_title: { rules: [1], inclusive: !1 }, block_bq: { rules: [27, 28], inclusive: !1 }, block: { rules: [22, 23, 24, 25, 26, 29, 30, 31, 32], inclusive: !1 }, INITIAL: { rules: [0, 2, 4, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 33, 34, 35, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 80, 81, 82], inclusive: !0 } } };
        return M;
    })();
    ye.lexer = nt;
    function oe() { this.yy = {}; }
    return d(oe, "Parser"), oe.prototype = ye, ye.Parser = oe, new oe;
})();
Oe.parser = Oe;
var ut = Oe, dt = class {
    constructor() { this.entities = new Map, this.relationships = [], this.classes = new Map, this.subgraphDepth = 0, this.subGraphs = [], this.subGraphLookup = new Map, this.subCount = 0, this.direction = "TB", this.Cardinality = { ZERO_OR_ONE: "ZERO_OR_ONE", ZERO_OR_MORE: "ZERO_OR_MORE", ONE_OR_MORE: "ONE_OR_MORE", ONLY_ONE: "ONLY_ONE", MD_PARENT: "MD_PARENT" }, this.Identification = { NON_IDENTIFYING: "NON_IDENTIFYING", IDENTIFYING: "IDENTIFYING" }, this.setAccTitle = Ze, this.getAccTitle = je, this.setAccDescription = qe, this.getAccDescription = We, this.setDiagramTitle = He, this.getDiagramTitle = Qe, this.getConfig = d(() => U().er, "getConfig"), this.clear(), this.addEntity = this.addEntity.bind(this), this.addAttributes = this.addAttributes.bind(this), this.addRelationship = this.addRelationship.bind(this), this.setDirection = this.setDirection.bind(this), this.addCssStyles = this.addCssStyles.bind(this), this.addClass = this.addClass.bind(this), this.setClass = this.setClass.bind(this), this.setAccTitle = this.setAccTitle.bind(this), this.setAccDescription = this.setAccDescription.bind(this), this.addSubGraph = this.addSubGraph.bind(this); }
    static { d(this, "ErDB"); }
    addEntity(t, n = "") { return this.entities.has(t) ? !this.entities.get(t)?.alias && n && (this.entities.get(t).alias = n, A.info(`Add alias '${n}' to entity '${t}'`)) : (this.entities.set(t, { id: `entity-${t}-${this.entities.size}`, label: t, attributes: [], alias: n, shape: "erBox", look: U().look ?? "default", cssClasses: "default", cssStyles: [], labelType: "markdown" }), A.info("Added new entity :", t)), this.entities.get(t); }
    getEntity(t) { return this.entities.get(t); }
    getEntities() { return this.entities; }
    getClasses() { return this.classes; }
    addAttributes(t, n) { let u = this.addEntity(t), r; for (r = n.length - 1; r >= 0; r--)
        n[r].keys || (n[r].keys = []), n[r].comment || (n[r].comment = ""), u.attributes.push(n[r]), A.debug("Added attribute ", n[r].name); }
    addRelationship(t, n, u, r) { let l; if (this.subGraphLookup.has(t))
        l = t;
    else {
        let p = this.addEntity(t);
        if (!p)
            return;
        l = p.id;
    } let f; if (this.subGraphLookup.has(u))
        f = u;
    else {
        let p = this.addEntity(u);
        if (!p)
            return;
        f = p.id;
    } let _ = { entityA: l, roleA: n, entityB: f, relSpec: r }; this.relationships.push(_), A.debug("Added new relationship :", _); }
    getRelationships() { return this.relationships; }
    getDirection() { return this.direction; }
    setDirection(t) { this.direction = t; }
    getCompiledStyles(t) { let n = []; for (let u of t) {
        let r = this.classes.get(u);
        r?.styles && (n = [...n, ...r.styles ?? []].map(l => l.trim())), r?.textStyles && (n = [...n, ...r.textStyles ?? []].map(l => l.trim()));
    } return n; }
    addCssStyles(t, n) { for (let u of t) {
        let r = this.entities.get(u), l = this.subGraphLookup.get(u);
        if (n) {
            if (r)
                for (let f of n)
                    r.cssStyles.push(f);
            if (l) {
                l.cssStyles || (l.cssStyles = []);
                for (let f of n)
                    l.cssStyles.push(f);
            }
        }
    } }
    addClass(t, n) { t.forEach(u => { let r = this.classes.get(u); r === void 0 && (r = { id: u, styles: [], textStyles: [] }, this.classes.set(u, r)), n && n.forEach(function (l) { if (/color/.exec(l)) {
        let f = l.replace("fill", "bgFill");
        r.textStyles.push(f);
    } r.styles.push(l); }); }); }
    addSubGraph(t, n, u) { let r = t.text.trim(), l = u.text, _ = d(k => { let x = new Set, B; return { nodeList: k.filter(m => { if (m?.stmt)
            return m.stmt === "dir" && (B = m.value), !1; if (typeof m != "string")
            return !1; let I = m.trim(); return !I || x.has(I) ? !1 : (x.add(I), !0); }), dir: B }; }, "uniq")(n.flat()), p = _.nodeList, S = _.dir; r = r ?? "subGraph" + this.subCount, l = l || "", l = this.sanitizeText(l), this.subCount = this.subCount + 1; let b = { id: r, nodes: p, title: l.trim(), classes: [], cssStyles: [], dir: S, labelType: this.sanitizeNodeLabelType(u?.type) }; return A.info("Adding", b.id, b.nodes, b.dir), b.nodes = this.makeUniq(b, this.subGraphs).nodes, this.subGraphs.push(b), this.subGraphLookup.set(r, b), r; }
    getSubGraphs() { return this.subGraphs; }
    setClass(t, n) { for (let u of t) {
        let r = this.entities.get(u);
        if (r)
            for (let f of n)
                r.cssClasses += " " + f;
        let l = this.subGraphLookup.get(u);
        if (l)
            for (let f of n)
                l.classes.push(f);
    } }
    subgraphNodeCache(t) { let n = new Set; for (let u of t)
        for (let r of u.nodes)
            n.add(r); return n; }
    makeUniq(t, n) { let u = this.subgraphNodeCache(n), r = []; return t.nodes.forEach((l, f) => { u.has(l) ? A.warn(`Entity '${l}' already belongs to another subgraph and will be ignored`) : r.push(t.nodes[f]); }), { nodes: r }; }
    sanitizeText(t) { return Ue.sanitizeText(t, U()); }
    sanitizeNodeLabelType(t) { switch (t) {
        case "markdown":
        case "string":
        case "text": return t;
        default: return "markdown";
    } }
    clear() { this.entities = new Map, this.classes = new Map, this.relationships = [], this.subGraphs = [], this.subGraphLookup = new Map, this.subCount = 0, this.subgraphDepth = 0, Ke(); }
    getData() { let t = [], n = [], u = U(), r = this.getSubGraphs(), l = new Map, f = new Map; for (let b = r.length - 1; b >= 0; b--) {
        let k = r[b];
        k.nodes.length > 0 && f.set(k.id, !0);
        for (let x of k.nodes)
            l.set(x, k.id);
    } for (let b = r.length - 1; b >= 0; b--) {
        let k = r[b];
        t.push({ id: k.id, label: k.title, labelStyle: "", labelType: k.labelType, parentId: l.get(k.id), padding: 8, cssCompiledStyles: this.getCompiledStyles(k.classes), cssStyles: k.cssStyles, cssClasses: k.classes.join(" "), shape: "rect", dir: k.dir, isGroup: !0, look: u.look });
    } let _ = new Set(r.map(b => b.id)), p = 0; for (let b of this.entities.keys()) {
        if (_.has(b))
            continue;
        let k = this.entities.get(b);
        k && (k.cssCompiledStyles = this.getCompiledStyles(k.cssClasses.split(" ")), k.colorIndex = p++, t.push(Ge(Be({}, k), { parentId: l.get(b), isGroup: !1 })));
    } let S = 0; for (let b of this.relationships) {
        let k = { id: $e(b.entityA, b.entityB, { prefix: "id", counter: S++ }), type: "normal", curve: "basis", start: b.entityA, end: b.entityB, label: b.roleA, labelpos: "c", thickness: "normal", classes: "relationshipLine", arrowTypeStart: b.relSpec.cardB.toLowerCase(), arrowTypeEnd: b.relSpec.cardA.toLowerCase(), pattern: b.relSpec.relType == "IDENTIFYING" ? "solid" : "dashed", look: u.look, labelType: "markdown" };
        n.push(k);
    } return { nodes: t, edges: n, other: {}, config: u, direction: this.direction }; }
}, at = {};
Ye(at, { draw: () => bt });
var bt = d(function (t, n, u, r) { return Fe(this, null, function* () { A.info("REF0:"), A.info("Drawing er diagram (unified)", n); let { securityLevel: l, er: f, layout: _ } = U(), p = r.db.getData(), S = st(n, l); p.type = r.type, p.layoutAlgorithm = tt(_), p.config.flowchart.nodeSpacing = f?.nodeSpacing || 140, p.config.flowchart.rankSpacing = f?.rankSpacing || 80, p.direction = r.db.getDirection(); let { config: b } = p, { look: k } = b; k === "neo" ? p.markers = ["only_one_neo", "zero_or_one_neo", "one_or_more_neo", "zero_or_more_neo"] : p.markers = ["only_one", "zero_or_one", "one_or_more", "zero_or_more"], p.diagramId = n, yield et(p, S), p.layoutAlgorithm === "elk" && S.select(".edges").lower(); let x = S.selectAll('[id*="-background"]'); Array.from(x).length > 0 && x.each(function () { let Y = Xe(this), I = Y.attr("id").replace("-background", ""), K = S.select(`#${CSS.escape(I)}`); if (!K.empty()) {
    let N = K.attr("transform");
    Y.attr("transform", N);
} }); let B = 8; Je.insertTitle(S, "erDiagramTitleText", f?.titleTopMargin ?? 25, r.db.getDiagramTitle()), it(S, B, "erDiagram", f?.useMaxWidth ?? !0); }); }, "draw"), rt = d((t, n) => { let u = ze, r = u(t, "r"), l = u(t, "g"), f = u(t, "b"); return Pe(r, l, f, n); }, "fade"), ue = new Set(["redux-color", "redux-dark-color"]), pt = d(t => {
    let { theme: n, look: u, bkgColorArray: r, borderColorArray: l } = t;
    if (!ue.has(n))
        return "";
    let f = r?.length > 0, _ = "";
    for (let p = 0; p < t.THEME_COLOR_LIMIT; p++)
        _ += `

    [data-look="${u}"][data-color-id="color-${p}"].node path {
    stroke: ${l[p]};
    ${f ? `fill: ${r[p]};` : ""}
    }

    [data-look="${u}"][data-color-id="color-${p}"].node  rect {
    stroke: ${l[p]};
    ${f ? `fill: ${r[p]};` : ""}
     }
    `;
    return _;
}, "genColor"), ft = d(t => {
    let { look: n, theme: u, erEdgeLabelBackground: r, strokeWidth: l } = t;
    return `
    ${pt(t)}
  .entityBox {
    fill: ${t.mainBkg};
    stroke: ${t.nodeBorder};
  }

  .relationshipLabelBox {
    fill: ${t.tertiaryColor};
    opacity: 0.7;
    background-color: ${t.tertiaryColor};
      rect {
        opacity: 0.5;
      }
  }

  .labelBkg {
    background-color: ${ue.has(u) && r ? r : rt(t.tertiaryColor, .5)};
  }

  .edgeLabel {
    background-color: ${ue.has(u) && r ? r : t.edgeLabelBackground};
  }
  .edgeLabel .label rect {
    fill: ${ue.has(u) && r ? r : t.edgeLabelBackground};
  }
  .edgeLabel .label text {
    fill: ${t.textColor};
  }

  .edgeLabel .label {
    fill: ${t.nodeBorder};
    font-size: 14px;
  }

  .label {
    font-family: ${t.fontFamily};
    color: ${t.nodeTextColor || t.textColor};
  }

  .edge-pattern-dashed {
    stroke-dasharray: 8,8;
  }

  .node rect,
  .node circle,
  .node ellipse,
  .node polygon
  {
    fill: ${t.mainBkg};
    stroke: ${t.nodeBorder};
    stroke-width: ${n === "neo" ? l : "1px"};
  }

  .relationshipLine {
    stroke: ${t.lineColor};
    stroke-width: ${n === "neo" ? l : "1px"};
    fill: none;
  }

  .marker {
    fill: none !important;
    stroke: ${t.lineColor} !important;
    stroke-width: 1;
  }
  [data-look=neo].labelBkg {
    background-color: ${rt(t.tertiaryColor, .5)};
  }

  .cluster rect {
    fill: ${t.clusterBkg ?? t.mainBkg};
    stroke: ${t.clusterBorder ?? t.nodeBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${t.titleColor ?? t.textColor};
  }

  .cluster-label text {
    fill: ${t.titleColor ?? t.textColor};
  }
`;
}, "getStyles"), kt = ft, wt = { parser: ut, get db() { return new dt; }, renderer: at, styles: kt };
export { wt as diagram };
