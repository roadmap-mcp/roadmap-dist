import { a as rr } from "@nf-internal/chunk-HDKR6WI7";
import { a as tr, b as er, d as Ft, e as qt, f as dt, g as Ht } from "@nf-internal/chunk-X5ONEG5D";
import { a as $e, b as je } from "@nf-internal/chunk-GDGZBOQC";
import { c as Ze, n as ne, p as X } from "@nf-internal/chunk-FDRUJGNH";
import { a as yr } from "@nf-internal/chunk-2MBYSHM6";
import { $ as Qe, H as Dt, I as Fe, K as Z, L as mt, M as se, N, O as qe, T as He, U as ie, V as ze, W as Ue, X as Ge, Y as Xe, Z as Je, _ as $, h as Ke, u as Pt } from "@nf-internal/chunk-LEJRRF65";
import { b as tt, h as vt } from "@nf-internal/chunk-RZWXGGKD";
import { a as x } from "@nf-internal/chunk-YUSHYV7C";
import { a as Ye, b as We, e as br, f as st } from "@nf-internal/chunk-OSQMNGTH";
var de = br(yr(), 1);
var ce = (function () {
    var e = x(function (ft, S, v, w) { for (v = v || {}, w = ft.length; w--; v[ft[w]] = S)
        ; return v; }, "o"), t = [1, 2], a = [1, 3], r = [1, 4], i = [2, 4], o = [1, 9], s = [1, 11], c = [1, 12], u = [1, 14], d = [1, 15], p = [1, 17], _ = [1, 18], E = [1, 19], R = [1, 25], T = [1, 26], g = [1, 27], f = [1, 28], I = [1, 29], O = [1, 30], L = [1, 31], k = [1, 32], A = [1, 33], D = [1, 34], M = [1, 35], V = [1, 36], W = [1, 37], U = [1, 38], G = [1, 39], J = [1, 40], ot = [1, 42], et = [1, 43], z = [1, 44], it = [1, 45], rt = [1, 46], Y = [1, 47], C = [1, 4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 48, 49, 50, 51, 53, 54, 56, 61, 62, 63, 64, 73], kt = [1, 74], Mt = [1, 80], m = [1, 81], P = [1, 82], ht = [1, 83], at = [1, 84], K = [1, 85], Ot = [1, 86], Te = [1, 87], pe = [1, 88], Ee = [1, 89], ue = [1, 90], fe = [1, 91], _e = [1, 92], ge = [1, 93], xe = [1, 94], Ie = [1, 95], be = [1, 96], ye = [1, 97], Re = [1, 98], Oe = [1, 99], Le = [1, 100], me = [1, 101], Ae = [1, 102], Se = [1, 103], ke = [1, 104], Ne = [1, 105], we = [2, 78], Nt = [4, 5, 17, 51, 53, 54], Bt = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 51, 53, 54, 56, 61, 62, 63, 64, 73], Pe = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 50, 51, 53, 54, 56, 61, 62, 63, 64, 73], Qt = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 49, 51, 53, 54, 56, 61, 62, 63, 64, 73], De = [4, 5, 10, 14, 15, 17, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 48, 51, 53, 54, 56, 61, 62, 63, 64, 73], Zt = [5, 52], F = [70, 71, 72, 73], ct = [1, 151], $t = { trace: x(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, SPACE: 4, NEWLINE: 5, SD: 6, document: 7, line: 8, statement: 9, INVALID: 10, box_section: 11, box_line: 12, participant_statement: 13, create: 14, box: 15, restOfLine: 16, end: 17, signal: 18, autonumber: 19, NUM: 20, off: 21, activate: 22, actor: 23, deactivate: 24, note_statement: 25, links_statement: 26, link_statement: 27, properties_statement: 28, details_statement: 29, title: 30, legacy_title: 31, acc_title: 32, acc_title_value: 33, acc_descr: 34, acc_descr_value: 35, acc_descr_multiline_value: 36, loop: 37, rect: 38, opt: 39, alt: 40, else_sections: 41, par: 42, par_sections: 43, par_over: 44, critical: 45, option_sections: 46, break: 47, option: 48, and: 49, else: 50, participant: 51, AS: 52, participant_actor: 53, destroy: 54, actor_with_config: 55, note: 56, placement: 57, text2: 58, over: 59, actor_pair: 60, links: 61, link: 62, properties: 63, details: 64, spaceList: 65, ",": 66, left_of: 67, right_of: 68, signaltype: 69, "+": 70, "-": 71, "()": 72, ACTOR: 73, config_object: 74, CONFIG_START: 75, CONFIG_CONTENT: 76, CONFIG_END: 77, SOLID_OPEN_ARROW: 78, DOTTED_OPEN_ARROW: 79, SOLID_ARROW: 80, SOLID_ARROW_TOP: 81, SOLID_ARROW_BOTTOM: 82, STICK_ARROW_TOP: 83, STICK_ARROW_BOTTOM: 84, SOLID_ARROW_TOP_DOTTED: 85, SOLID_ARROW_BOTTOM_DOTTED: 86, STICK_ARROW_TOP_DOTTED: 87, STICK_ARROW_BOTTOM_DOTTED: 88, SOLID_ARROW_TOP_REVERSE: 89, SOLID_ARROW_BOTTOM_REVERSE: 90, STICK_ARROW_TOP_REVERSE: 91, STICK_ARROW_BOTTOM_REVERSE: 92, SOLID_ARROW_TOP_REVERSE_DOTTED: 93, SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 94, STICK_ARROW_TOP_REVERSE_DOTTED: 95, STICK_ARROW_BOTTOM_REVERSE_DOTTED: 96, BIDIRECTIONAL_SOLID_ARROW: 97, DOTTED_ARROW: 98, BIDIRECTIONAL_DOTTED_ARROW: 99, SOLID_CROSS: 100, DOTTED_CROSS: 101, SOLID_POINT: 102, DOTTED_POINT: 103, TXT: 104, $accept: 0, $end: 1 }, terminals_: { 2: "error", 4: "SPACE", 5: "NEWLINE", 6: "SD", 10: "INVALID", 14: "create", 15: "box", 16: "restOfLine", 17: "end", 19: "autonumber", 20: "NUM", 21: "off", 22: "activate", 24: "deactivate", 30: "title", 31: "legacy_title", 32: "acc_title", 33: "acc_title_value", 34: "acc_descr", 35: "acc_descr_value", 36: "acc_descr_multiline_value", 37: "loop", 38: "rect", 39: "opt", 40: "alt", 42: "par", 44: "par_over", 45: "critical", 47: "break", 48: "option", 49: "and", 50: "else", 51: "participant", 52: "AS", 53: "participant_actor", 54: "destroy", 56: "note", 59: "over", 61: "links", 62: "link", 63: "properties", 64: "details", 66: ",", 67: "left_of", 68: "right_of", 70: "+", 71: "-", 72: "()", 73: "ACTOR", 75: "CONFIG_START", 76: "CONFIG_CONTENT", 77: "CONFIG_END", 78: "SOLID_OPEN_ARROW", 79: "DOTTED_OPEN_ARROW", 80: "SOLID_ARROW", 81: "SOLID_ARROW_TOP", 82: "SOLID_ARROW_BOTTOM", 83: "STICK_ARROW_TOP", 84: "STICK_ARROW_BOTTOM", 85: "SOLID_ARROW_TOP_DOTTED", 86: "SOLID_ARROW_BOTTOM_DOTTED", 87: "STICK_ARROW_TOP_DOTTED", 88: "STICK_ARROW_BOTTOM_DOTTED", 89: "SOLID_ARROW_TOP_REVERSE", 90: "SOLID_ARROW_BOTTOM_REVERSE", 91: "STICK_ARROW_TOP_REVERSE", 92: "STICK_ARROW_BOTTOM_REVERSE", 93: "SOLID_ARROW_TOP_REVERSE_DOTTED", 94: "SOLID_ARROW_BOTTOM_REVERSE_DOTTED", 95: "STICK_ARROW_TOP_REVERSE_DOTTED", 96: "STICK_ARROW_BOTTOM_REVERSE_DOTTED", 97: "BIDIRECTIONAL_SOLID_ARROW", 98: "DOTTED_ARROW", 99: "BIDIRECTIONAL_DOTTED_ARROW", 100: "SOLID_CROSS", 101: "DOTTED_CROSS", 102: "SOLID_POINT", 103: "DOTTED_POINT", 104: "TXT" }, productions_: [0, [3, 2], [3, 2], [3, 2], [7, 0], [7, 2], [8, 2], [8, 1], [8, 1], [8, 1], [11, 0], [11, 2], [12, 2], [12, 1], [12, 1], [9, 1], [9, 2], [9, 4], [9, 2], [9, 4], [9, 3], [9, 3], [9, 2], [9, 3], [9, 3], [9, 2], [9, 2], [9, 2], [9, 2], [9, 2], [9, 1], [9, 1], [9, 2], [9, 2], [9, 1], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [9, 4], [46, 1], [46, 4], [43, 1], [43, 4], [41, 1], [41, 4], [13, 5], [13, 3], [13, 5], [13, 3], [13, 3], [13, 5], [13, 3], [13, 5], [13, 3], [25, 4], [25, 4], [26, 3], [27, 3], [28, 3], [29, 3], [65, 2], [65, 1], [60, 3], [60, 1], [57, 1], [57, 1], [18, 5], [18, 5], [18, 5], [18, 5], [18, 6], [18, 4], [55, 2], [74, 3], [23, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [69, 1], [58, 1]], performAction: x(function (S, v, w, b, q, n, wt) { var h = n.length - 1; switch (q) {
            case 3:
                return b.apply(n[h]), n[h];
                break;
            case 4:
            case 10:
                this.$ = [];
                break;
            case 5:
            case 11:
                n[h - 1].push(n[h]), this.$ = n[h - 1];
                break;
            case 6:
            case 7:
            case 12:
            case 13:
                this.$ = n[h];
                break;
            case 8:
            case 9:
            case 14:
                this.$ = [];
                break;
            case 16:
                n[h].type = "createParticipant", this.$ = n[h];
                break;
            case 17:
                n[h - 1].unshift({ type: "boxStart", boxData: b.parseBoxData(n[h - 2]) }), n[h - 1].push({ type: "boxEnd", boxText: n[h - 2] }), this.$ = n[h - 1];
                break;
            case 19:
                this.$ = { type: "sequenceIndex", sequenceIndex: Number(n[h - 2]), sequenceIndexStep: Number(n[h - 1]), sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
                break;
            case 20:
                this.$ = { type: "sequenceIndex", sequenceIndex: Number(n[h - 1]), sequenceIndexStep: 1, sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
                break;
            case 21:
                this.$ = { type: "sequenceIndex", sequenceVisible: !1, signalType: b.LINETYPE.AUTONUMBER };
                break;
            case 22:
                this.$ = { type: "sequenceIndex", sequenceVisible: !0, signalType: b.LINETYPE.AUTONUMBER };
                break;
            case 23:
                this.$ = { type: "activeStart", signalType: b.LINETYPE.ACTIVE_START, actor: n[h - 1].actor };
                break;
            case 24:
                this.$ = { type: "activeEnd", signalType: b.LINETYPE.ACTIVE_END, actor: n[h - 1].actor };
                break;
            case 30:
                b.setDiagramTitle(n[h].substring(6)), this.$ = n[h].substring(6);
                break;
            case 31:
                b.setDiagramTitle(n[h].substring(7)), this.$ = n[h].substring(7);
                break;
            case 32:
                this.$ = n[h].trim(), b.setAccTitle(this.$);
                break;
            case 33:
            case 34:
                this.$ = n[h].trim(), b.setAccDescription(this.$);
                break;
            case 35:
                n[h - 1].unshift({ type: "loopStart", loopText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.LOOP_START }), n[h - 1].push({ type: "loopEnd", loopText: n[h - 2], signalType: b.LINETYPE.LOOP_END }), this.$ = n[h - 1];
                break;
            case 36:
                n[h - 1].unshift({ type: "rectStart", color: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.RECT_START }), n[h - 1].push({ type: "rectEnd", color: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.RECT_END }), this.$ = n[h - 1];
                break;
            case 37:
                n[h - 1].unshift({ type: "optStart", optText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.OPT_START }), n[h - 1].push({ type: "optEnd", optText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.OPT_END }), this.$ = n[h - 1];
                break;
            case 38:
                n[h - 1].unshift({ type: "altStart", altText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.ALT_START }), n[h - 1].push({ type: "altEnd", signalType: b.LINETYPE.ALT_END }), this.$ = n[h - 1];
                break;
            case 39:
                n[h - 1].unshift({ type: "parStart", parText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.PAR_START }), n[h - 1].push({ type: "parEnd", signalType: b.LINETYPE.PAR_END }), this.$ = n[h - 1];
                break;
            case 40:
                n[h - 1].unshift({ type: "parStart", parText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.PAR_OVER_START }), n[h - 1].push({ type: "parEnd", signalType: b.LINETYPE.PAR_END }), this.$ = n[h - 1];
                break;
            case 41:
                n[h - 1].unshift({ type: "criticalStart", criticalText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.CRITICAL_START }), n[h - 1].push({ type: "criticalEnd", signalType: b.LINETYPE.CRITICAL_END }), this.$ = n[h - 1];
                break;
            case 42:
                n[h - 1].unshift({ type: "breakStart", breakText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.BREAK_START }), n[h - 1].push({ type: "breakEnd", optText: b.parseMessage(n[h - 2]), signalType: b.LINETYPE.BREAK_END }), this.$ = n[h - 1];
                break;
            case 44:
                this.$ = n[h - 3].concat([{ type: "option", optionText: b.parseMessage(n[h - 1]), signalType: b.LINETYPE.CRITICAL_OPTION }, n[h]]);
                break;
            case 46:
                this.$ = n[h - 3].concat([{ type: "and", parText: b.parseMessage(n[h - 1]), signalType: b.LINETYPE.PAR_AND }, n[h]]);
                break;
            case 48:
                this.$ = n[h - 3].concat([{ type: "else", altText: b.parseMessage(n[h - 1]), signalType: b.LINETYPE.ALT_ELSE }, n[h]]);
                break;
            case 49:
                n[h - 3].draw = "participant", n[h - 3].type = "addParticipant", n[h - 3].description = b.parseMessage(n[h - 1]), this.$ = n[h - 3];
                break;
            case 50:
                n[h - 1].draw = "participant", n[h - 1].type = "addParticipant", this.$ = n[h - 1];
                break;
            case 51:
                n[h - 3].draw = "actor", n[h - 3].type = "addParticipant", n[h - 3].description = b.parseMessage(n[h - 1]), this.$ = n[h - 3];
                break;
            case 52:
            case 57:
                n[h - 1].draw = "actor", n[h - 1].type = "addParticipant", this.$ = n[h - 1];
                break;
            case 53:
                n[h - 1].type = "destroyParticipant", this.$ = n[h - 1];
                break;
            case 54:
                n[h - 3].draw = "participant", n[h - 3].type = "addParticipant", n[h - 3].description = b.parseMessage(n[h - 1]), this.$ = n[h - 3];
                break;
            case 55:
                n[h - 1].draw = "participant", n[h - 1].type = "addParticipant", this.$ = n[h - 1];
                break;
            case 56:
                n[h - 3].draw = "actor", n[h - 3].type = "addParticipant", n[h - 3].description = b.parseMessage(n[h - 1]), this.$ = n[h - 3];
                break;
            case 58:
                this.$ = [n[h - 1], { type: "addNote", placement: n[h - 2], actor: n[h - 1].actor, text: n[h] }];
                break;
            case 59:
                n[h - 2] = [].concat(n[h - 1], n[h - 1]).slice(0, 2), n[h - 2][0] = n[h - 2][0].actor, n[h - 2][1] = n[h - 2][1].actor, this.$ = [n[h - 1], { type: "addNote", placement: b.PLACEMENT.OVER, actor: n[h - 2].slice(0, 2), text: n[h] }];
                break;
            case 60:
                this.$ = [n[h - 1], { type: "addLinks", actor: n[h - 1].actor, text: n[h] }];
                break;
            case 61:
                this.$ = [n[h - 1], { type: "addALink", actor: n[h - 1].actor, text: n[h] }];
                break;
            case 62:
                this.$ = [n[h - 1], { type: "addProperties", actor: n[h - 1].actor, text: n[h] }];
                break;
            case 63:
                this.$ = [n[h - 1], { type: "addDetails", actor: n[h - 1].actor, text: n[h] }];
                break;
            case 66:
                this.$ = [n[h - 2], n[h]];
                break;
            case 67:
                this.$ = n[h];
                break;
            case 68:
                this.$ = b.PLACEMENT.LEFTOF;
                break;
            case 69:
                this.$ = b.PLACEMENT.RIGHTOF;
                break;
            case 70:
                this.$ = [n[h - 4], n[h - 1], { type: "addMessage", from: n[h - 4].actor, to: n[h - 1].actor, signalType: n[h - 3], msg: n[h], activate: !0 }, { type: "activeStart", signalType: b.LINETYPE.ACTIVE_START, actor: n[h - 1].actor }];
                break;
            case 71:
                this.$ = [n[h - 4], n[h - 1], { type: "addMessage", from: n[h - 4].actor, to: n[h - 1].actor, signalType: n[h - 3], msg: n[h] }, { type: "activeEnd", signalType: b.LINETYPE.ACTIVE_END, actor: n[h - 4].actor }];
                break;
            case 72:
                this.$ = [n[h - 4], n[h - 1], { type: "addMessage", from: n[h - 4].actor, to: n[h - 1].actor, signalType: n[h - 3], msg: n[h], activate: !0, centralConnection: b.LINETYPE.CENTRAL_CONNECTION }, { type: "centralConnection", signalType: b.LINETYPE.CENTRAL_CONNECTION, actor: n[h - 1].actor }];
                break;
            case 73:
                this.$ = [n[h - 4], n[h - 1], { type: "addMessage", from: n[h - 4].actor, to: n[h - 1].actor, signalType: n[h - 2], msg: n[h], activate: !1, centralConnection: b.LINETYPE.CENTRAL_CONNECTION_REVERSE }, { type: "centralConnectionReverse", signalType: b.LINETYPE.CENTRAL_CONNECTION_REVERSE, actor: n[h - 4].actor }];
                break;
            case 74:
                this.$ = [n[h - 5], n[h - 1], { type: "addMessage", from: n[h - 5].actor, to: n[h - 1].actor, signalType: n[h - 3], msg: n[h], activate: !0, centralConnection: b.LINETYPE.CENTRAL_CONNECTION_DUAL }, { type: "centralConnection", signalType: b.LINETYPE.CENTRAL_CONNECTION, actor: n[h - 1].actor }, { type: "centralConnectionReverse", signalType: b.LINETYPE.CENTRAL_CONNECTION_REVERSE, actor: n[h - 5].actor }];
                break;
            case 75:
                this.$ = [n[h - 3], n[h - 1], { type: "addMessage", from: n[h - 3].actor, to: n[h - 1].actor, signalType: n[h - 2], msg: n[h] }];
                break;
            case 76:
                this.$ = { type: "addParticipant", actor: n[h - 1], config: n[h] };
                break;
            case 77:
                this.$ = n[h - 1].trim();
                break;
            case 78:
                this.$ = { type: "addParticipant", actor: n[h] };
                break;
            case 79:
                this.$ = b.LINETYPE.SOLID_OPEN;
                break;
            case 80:
                this.$ = b.LINETYPE.DOTTED_OPEN;
                break;
            case 81:
                this.$ = b.LINETYPE.SOLID;
                break;
            case 82:
                this.$ = b.LINETYPE.SOLID_TOP;
                break;
            case 83:
                this.$ = b.LINETYPE.SOLID_BOTTOM;
                break;
            case 84:
                this.$ = b.LINETYPE.STICK_TOP;
                break;
            case 85:
                this.$ = b.LINETYPE.STICK_BOTTOM;
                break;
            case 86:
                this.$ = b.LINETYPE.SOLID_TOP_DOTTED;
                break;
            case 87:
                this.$ = b.LINETYPE.SOLID_BOTTOM_DOTTED;
                break;
            case 88:
                this.$ = b.LINETYPE.STICK_TOP_DOTTED;
                break;
            case 89:
                this.$ = b.LINETYPE.STICK_BOTTOM_DOTTED;
                break;
            case 90:
                this.$ = b.LINETYPE.SOLID_ARROW_TOP_REVERSE;
                break;
            case 91:
                this.$ = b.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE;
                break;
            case 92:
                this.$ = b.LINETYPE.STICK_ARROW_TOP_REVERSE;
                break;
            case 93:
                this.$ = b.LINETYPE.STICK_ARROW_BOTTOM_REVERSE;
                break;
            case 94:
                this.$ = b.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED;
                break;
            case 95:
                this.$ = b.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED;
                break;
            case 96:
                this.$ = b.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED;
                break;
            case 97:
                this.$ = b.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED;
                break;
            case 98:
                this.$ = b.LINETYPE.BIDIRECTIONAL_SOLID;
                break;
            case 99:
                this.$ = b.LINETYPE.DOTTED;
                break;
            case 100:
                this.$ = b.LINETYPE.BIDIRECTIONAL_DOTTED;
                break;
            case 101:
                this.$ = b.LINETYPE.SOLID_CROSS;
                break;
            case 102:
                this.$ = b.LINETYPE.DOTTED_CROSS;
                break;
            case 103:
                this.$ = b.LINETYPE.SOLID_POINT;
                break;
            case 104:
                this.$ = b.LINETYPE.DOTTED_POINT;
                break;
            case 105:
                this.$ = b.parseMessage(n[h].trim().substring(1));
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: t, 5: a, 6: r }, { 1: [3] }, { 3: 5, 4: t, 5: a, 6: r }, { 3: 6, 4: t, 5: a, 6: r }, e([1, 4, 5, 10, 14, 15, 19, 22, 24, 30, 31, 32, 34, 36, 37, 38, 39, 40, 42, 44, 45, 47, 51, 53, 54, 56, 61, 62, 63, 64, 73], i, { 7: 7 }), { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 3], 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, e(C, [2, 5]), { 9: 48, 13: 13, 14: u, 15: d, 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, e(C, [2, 7]), e(C, [2, 8]), e(C, [2, 9]), e(C, [2, 15]), { 13: 49, 51: U, 53: G, 54: J }, { 16: [1, 50] }, { 5: [1, 51] }, { 5: [1, 54], 20: [1, 52], 21: [1, 53] }, { 23: 55, 73: Y }, { 23: 56, 73: Y }, { 5: [1, 57] }, { 5: [1, 58] }, { 5: [1, 59] }, { 5: [1, 60] }, { 5: [1, 61] }, e(C, [2, 30]), e(C, [2, 31]), { 33: [1, 62] }, { 35: [1, 63] }, e(C, [2, 34]), { 16: [1, 64] }, { 16: [1, 65] }, { 16: [1, 66] }, { 16: [1, 67] }, { 16: [1, 68] }, { 16: [1, 69] }, { 16: [1, 70] }, { 16: [1, 71] }, { 23: 72, 55: 73, 73: kt }, { 23: 75, 55: 76, 73: kt }, { 23: 77, 73: Y }, { 69: 78, 72: [1, 79], 78: Mt, 79: m, 80: P, 81: ht, 82: at, 83: K, 84: Ot, 85: Te, 86: pe, 87: Ee, 88: ue, 89: fe, 90: _e, 91: ge, 92: xe, 93: Ie, 94: be, 95: ye, 96: Re, 97: Oe, 98: Le, 99: me, 100: Ae, 101: Se, 102: ke, 103: Ne }, { 57: 106, 59: [1, 107], 67: [1, 108], 68: [1, 109] }, { 23: 110, 73: Y }, { 23: 111, 73: Y }, { 23: 112, 73: Y }, { 23: 113, 73: Y }, e([5, 66, 72, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100, 101, 102, 103, 104], we), e(C, [2, 6]), e(C, [2, 16]), e(Nt, [2, 10], { 11: 114 }), e(C, [2, 18]), { 5: [1, 116], 20: [1, 115] }, { 5: [1, 117] }, e(C, [2, 22]), { 5: [1, 118] }, { 5: [1, 119] }, e(C, [2, 25]), e(C, [2, 26]), e(C, [2, 27]), e(C, [2, 28]), e(C, [2, 29]), e(C, [2, 32]), e(C, [2, 33]), e(Bt, i, { 7: 120 }), e(Bt, i, { 7: 121 }), e(Bt, i, { 7: 122 }), e(Pe, i, { 41: 123, 7: 124 }), e(Qt, i, { 43: 125, 7: 126 }), e(Qt, i, { 7: 126, 43: 127 }), e(De, i, { 46: 128, 7: 129 }), e(Bt, i, { 7: 130 }), { 5: [1, 132], 52: [1, 131] }, { 5: [1, 134], 52: [1, 133] }, e(Zt, we, { 74: 135, 75: [1, 136] }), { 5: [1, 138], 52: [1, 137] }, { 5: [1, 140], 52: [1, 139] }, { 5: [1, 141] }, { 23: 145, 70: [1, 142], 71: [1, 143], 72: [1, 144], 73: Y }, { 69: 146, 78: Mt, 79: m, 80: P, 81: ht, 82: at, 83: K, 84: Ot, 85: Te, 86: pe, 87: Ee, 88: ue, 89: fe, 90: _e, 91: ge, 92: xe, 93: Ie, 94: be, 95: ye, 96: Re, 97: Oe, 98: Le, 99: me, 100: Ae, 101: Se, 102: ke, 103: Ne }, e(F, [2, 79]), e(F, [2, 80]), e(F, [2, 81]), e(F, [2, 82]), e(F, [2, 83]), e(F, [2, 84]), e(F, [2, 85]), e(F, [2, 86]), e(F, [2, 87]), e(F, [2, 88]), e(F, [2, 89]), e(F, [2, 90]), e(F, [2, 91]), e(F, [2, 92]), e(F, [2, 93]), e(F, [2, 94]), e(F, [2, 95]), e(F, [2, 96]), e(F, [2, 97]), e(F, [2, 98]), e(F, [2, 99]), e(F, [2, 100]), e(F, [2, 101]), e(F, [2, 102]), e(F, [2, 103]), e(F, [2, 104]), { 23: 147, 73: Y }, { 23: 149, 60: 148, 73: Y }, { 73: [2, 68] }, { 73: [2, 69] }, { 58: 150, 104: ct }, { 58: 152, 104: ct }, { 58: 153, 104: ct }, { 58: 154, 104: ct }, { 4: [1, 157], 5: [1, 159], 12: 156, 13: 158, 17: [1, 155], 51: U, 53: G, 54: J }, { 5: [1, 160] }, e(C, [2, 20]), e(C, [2, 21]), e(C, [2, 23]), e(C, [2, 24]), { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [1, 161], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [1, 162], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [1, 163], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 17: [1, 164] }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [2, 47], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 50: [1, 165], 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 17: [1, 166] }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [2, 45], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 49: [1, 167], 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 17: [1, 168] }, { 17: [1, 169] }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [2, 43], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 48: [1, 170], 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 4: o, 5: s, 8: 8, 9: 10, 10: c, 13: 13, 14: u, 15: d, 17: [1, 171], 18: 16, 19: p, 22: _, 23: 41, 24: E, 25: 20, 26: 21, 27: 22, 28: 23, 29: 24, 30: R, 31: T, 32: g, 34: f, 36: I, 37: O, 38: L, 39: k, 40: A, 42: D, 44: M, 45: V, 47: W, 51: U, 53: G, 54: J, 56: ot, 61: et, 62: z, 63: it, 64: rt, 73: Y }, { 16: [1, 172] }, e(C, [2, 50]), { 16: [1, 173] }, e(C, [2, 55]), e(Zt, [2, 76]), { 76: [1, 174] }, { 16: [1, 175] }, e(C, [2, 52]), { 16: [1, 176] }, e(C, [2, 57]), e(C, [2, 53]), { 23: 177, 73: Y }, { 23: 178, 73: Y }, { 23: 179, 73: Y }, { 58: 180, 104: ct }, { 23: 181, 72: [1, 182], 73: Y }, { 58: 183, 104: ct }, { 58: 184, 104: ct }, { 66: [1, 185], 104: [2, 67] }, { 5: [2, 60] }, { 5: [2, 105] }, { 5: [2, 61] }, { 5: [2, 62] }, { 5: [2, 63] }, e(C, [2, 17]), e(Nt, [2, 11]), { 13: 186, 51: U, 53: G, 54: J }, e(Nt, [2, 13]), e(Nt, [2, 14]), e(C, [2, 19]), e(C, [2, 35]), e(C, [2, 36]), e(C, [2, 37]), e(C, [2, 38]), { 16: [1, 187] }, e(C, [2, 39]), { 16: [1, 188] }, e(C, [2, 40]), e(C, [2, 41]), { 16: [1, 189] }, e(C, [2, 42]), { 5: [1, 190] }, { 5: [1, 191] }, { 77: [1, 192] }, { 5: [1, 193] }, { 5: [1, 194] }, { 58: 195, 104: ct }, { 58: 196, 104: ct }, { 58: 197, 104: ct }, { 5: [2, 75] }, { 58: 198, 104: ct }, { 23: 199, 73: Y }, { 5: [2, 58] }, { 5: [2, 59] }, { 23: 200, 73: Y }, e(Nt, [2, 12]), e(Pe, i, { 7: 124, 41: 201 }), e(Qt, i, { 7: 126, 43: 202 }), e(De, i, { 7: 129, 46: 203 }), e(C, [2, 49]), e(C, [2, 54]), e(Zt, [2, 77]), e(C, [2, 51]), e(C, [2, 56]), { 5: [2, 70] }, { 5: [2, 71] }, { 5: [2, 72] }, { 5: [2, 73] }, { 58: 204, 104: ct }, { 104: [2, 66] }, { 17: [2, 48] }, { 17: [2, 46] }, { 17: [2, 44] }, { 5: [2, 74] }], defaultActions: { 5: [2, 1], 6: [2, 2], 108: [2, 68], 109: [2, 69], 150: [2, 60], 151: [2, 105], 152: [2, 61], 153: [2, 62], 154: [2, 63], 180: [2, 75], 183: [2, 58], 184: [2, 59], 195: [2, 70], 196: [2, 71], 197: [2, 72], 198: [2, 73], 200: [2, 66], 201: [2, 48], 202: [2, 46], 203: [2, 44], 204: [2, 74] }, parseError: x(function (S, v) { if (v.recoverable)
            this.trace(S);
        else {
            var w = new Error(S);
            throw w.hash = v, w;
        } }, "parseError"), parse: x(function (S) {
            var v = this, w = [0], b = [], q = [null], n = [], wt = this.table, h = "", Yt = 0, ve = 0, Ce = 0, _r = 2, Me = 1, gr = n.slice.call(arguments, 1), Q = Object.create(this.lexer), xt = { yy: {} };
            for (var jt in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, jt) && (xt.yy[jt] = this.yy[jt]);
            Q.setInput(S, xt.yy), xt.yy.lexer = Q, xt.yy.parser = this, typeof Q.yylloc > "u" && (Q.yylloc = {});
            var te = Q.yylloc;
            n.push(te);
            var xr = Q.options && Q.options.ranges;
            typeof xt.yy.parseError == "function" ? this.parseError = xt.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function Ir(nt) { w.length = w.length - 2 * nt, q.length = q.length - nt, n.length = n.length - nt; }
            x(Ir, "popStack");
            function Be() { var nt; return nt = b.pop() || Q.lex() || Me, typeof nt != "number" && (nt instanceof Array && (b = nt, nt = b.pop()), nt = v.symbols_[nt] || nt), nt; }
            x(Be, "lex");
            for (var j, ee, It, lt, _a, re, Lt = {}, Wt, pt, Ve, Kt;;) {
                if (It = w[w.length - 1], this.defaultActions[It] ? lt = this.defaultActions[It] : ((j === null || typeof j > "u") && (j = Be()), lt = wt[It] && wt[It][j]), typeof lt > "u" || !lt.length || !lt[0]) {
                    var ae = "";
                    Kt = [];
                    for (Wt in wt[It])
                        this.terminals_[Wt] && Wt > _r && Kt.push("'" + this.terminals_[Wt] + "'");
                    Q.showPosition ? ae = "Parse error on line " + (Yt + 1) + `:
` + Q.showPosition() + `
Expecting ` + Kt.join(", ") + ", got '" + (this.terminals_[j] || j) + "'" : ae = "Parse error on line " + (Yt + 1) + ": Unexpected " + (j == Me ? "end of input" : "'" + (this.terminals_[j] || j) + "'"), this.parseError(ae, { text: Q.match, token: this.terminals_[j] || j, line: Q.yylineno, loc: te, expected: Kt });
                }
                if (lt[0] instanceof Array && lt.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + It + ", token: " + j);
                switch (lt[0]) {
                    case 1:
                        w.push(j), q.push(Q.yytext), n.push(Q.yylloc), w.push(lt[1]), j = null, ee ? (j = ee, ee = null) : (ve = Q.yyleng, h = Q.yytext, Yt = Q.yylineno, te = Q.yylloc, Ce > 0 && Ce--);
                        break;
                    case 2:
                        if (pt = this.productions_[lt[1]][1], Lt.$ = q[q.length - pt], Lt._$ = { first_line: n[n.length - (pt || 1)].first_line, last_line: n[n.length - 1].last_line, first_column: n[n.length - (pt || 1)].first_column, last_column: n[n.length - 1].last_column }, xr && (Lt._$.range = [n[n.length - (pt || 1)].range[0], n[n.length - 1].range[1]]), re = this.performAction.apply(Lt, [h, ve, Yt, xt.yy, lt[1], q, n].concat(gr)), typeof re < "u")
                            return re;
                        pt && (w = w.slice(0, -1 * pt * 2), q = q.slice(0, -1 * pt), n = n.slice(0, -1 * pt)), w.push(this.productions_[lt[1]][0]), q.push(Lt.$), n.push(Lt._$), Ve = wt[w[w.length - 2]][w[w.length - 1]], w.push(Ve);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, fr = (function () {
        var ft = { EOF: 1, parseError: x(function (v, w) { if (this.yy.parser)
                this.yy.parser.parseError(v, w);
            else
                throw new Error(v); }, "parseError"), setInput: x(function (S, v) { return this.yy = v || this.yy || {}, this._input = S, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: x(function () { var S = this._input[0]; this.yytext += S, this.yyleng++, this.offset++, this.match += S, this.matched += S; var v = S.match(/(?:\r\n?|\n).*/g); return v ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), S; }, "input"), unput: x(function (S) { var v = S.length, w = S.split(/(?:\r\n?|\n)/g); this._input = S + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - v), this.offset -= v; var b = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), w.length - 1 && (this.yylineno -= w.length - 1); var q = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: w ? (w.length === b.length ? this.yylloc.first_column : 0) + b[b.length - w.length].length - w[0].length : this.yylloc.first_column - v }, this.options.ranges && (this.yylloc.range = [q[0], q[0] + this.yyleng - v]), this.yyleng = this.yytext.length, this; }, "unput"), more: x(function () { return this._more = !0, this; }, "more"), reject: x(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: x(function (S) { this.unput(this.match.slice(S)); }, "less"), pastInput: x(function () { var S = this.matched.substr(0, this.matched.length - this.match.length); return (S.length > 20 ? "..." : "") + S.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: x(function () { var S = this.match; return S.length < 20 && (S += this._input.substr(0, 20 - S.length)), (S.substr(0, 20) + (S.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: x(function () {
                var S = this.pastInput(), v = new Array(S.length + 1).join("-");
                return S + this.upcomingInput() + `
` + v + "^";
            }, "showPosition"), test_match: x(function (S, v) { var w, b, q; if (this.options.backtrack_lexer && (q = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (q.yylloc.range = this.yylloc.range.slice(0))), b = S[0].match(/(?:\r\n?|\n).*/g), b && (this.yylineno += b.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: b ? b[b.length - 1].length - b[b.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + S[0].length }, this.yytext += S[0], this.match += S[0], this.matches = S, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(S[0].length), this.matched += S[0], w = this.performAction.call(this, this.yy, this, v, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), w)
                return w; if (this._backtrack) {
                for (var n in q)
                    this[n] = q[n];
                return !1;
            } return !1; }, "test_match"), next: x(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var S, v, w, b;
                this._more || (this.yytext = "", this.match = "");
                for (var q = this._currentRules(), n = 0; n < q.length; n++)
                    if (w = this._input.match(this.rules[q[n]]), w && (!v || w[0].length > v[0].length)) {
                        if (v = w, b = n, this.options.backtrack_lexer) {
                            if (S = this.test_match(w, q[n]), S !== !1)
                                return S;
                            if (this._backtrack) {
                                v = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return v ? (S = this.test_match(v, q[b]), S !== !1 ? S : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: x(function () { var v = this.next(); return v || this.lex(); }, "lex"), begin: x(function (v) { this.conditionStack.push(v); }, "begin"), popState: x(function () { var v = this.conditionStack.length - 1; return v > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: x(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: x(function (v) { return v = this.conditionStack.length - 1 - Math.abs(v || 0), v >= 0 ? this.conditionStack[v] : "INITIAL"; }, "topState"), pushState: x(function (v) { this.begin(v); }, "pushState"), stateStackSize: x(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: x(function (v, w, b, q) { var n = q; switch (b) {
                case 0: return 5;
                case 1: break;
                case 2: break;
                case 3: break;
                case 4: break;
                case 5: break;
                case 6: return 20;
                case 7:
                    return this.begin("CONFIG"), 75;
                    break;
                case 8: return 76;
                case 9:
                    return this.popState(), this.begin("ALIAS"), 77;
                    break;
                case 10:
                    return this.popState(), this.popState(), 77;
                    break;
                case 11:
                    return w.yytext = w.yytext.trim(), 73;
                    break;
                case 12:
                    return w.yytext = w.yytext.trim(), this.begin("ALIAS"), 73;
                    break;
                case 13:
                    return w.yytext = w.yytext.trim(), this.popState(), 73;
                    break;
                case 14:
                    return this.popState(), 10;
                    break;
                case 15:
                    return w.yytext = w.yytext.trim(), this.popState(), 10;
                    break;
                case 16:
                    return this.begin("LINE"), 15;
                    break;
                case 17:
                    return this.begin("ID"), 51;
                    break;
                case 18:
                    return this.begin("ID"), 53;
                    break;
                case 19: return 14;
                case 20:
                    return this.begin("ID"), 54;
                    break;
                case 21:
                    return this.popState(), this.popState(), this.begin("LINE"), 52;
                    break;
                case 22:
                    return this.popState(), this.popState(), 5;
                    break;
                case 23:
                    return this.begin("LINE"), 37;
                    break;
                case 24:
                    return this.begin("LINE"), 38;
                    break;
                case 25:
                    return this.begin("LINE"), 39;
                    break;
                case 26:
                    return this.begin("LINE"), 40;
                    break;
                case 27:
                    return this.begin("LINE"), 50;
                    break;
                case 28:
                    return this.begin("LINE"), 42;
                    break;
                case 29:
                    return this.begin("LINE"), 44;
                    break;
                case 30:
                    return this.begin("LINE"), 49;
                    break;
                case 31:
                    return this.begin("LINE"), 45;
                    break;
                case 32:
                    return this.begin("LINE"), 48;
                    break;
                case 33:
                    return this.begin("LINE"), 47;
                    break;
                case 34:
                    return this.popState(), 16;
                    break;
                case 35: return 17;
                case 36: return 67;
                case 37: return 68;
                case 38: return 61;
                case 39: return 62;
                case 40: return 63;
                case 41: return 64;
                case 42: return 59;
                case 43: return 56;
                case 44:
                    return this.begin("ID"), 22;
                    break;
                case 45:
                    return this.begin("ID"), 24;
                    break;
                case 46: return 30;
                case 47: return 31;
                case 48:
                    return this.begin("acc_title"), 32;
                    break;
                case 49:
                    return this.popState(), "acc_title_value";
                    break;
                case 50:
                    return this.begin("acc_descr"), 34;
                    break;
                case 51:
                    return this.popState(), "acc_descr_value";
                    break;
                case 52:
                    this.begin("acc_descr_multiline");
                    break;
                case 53:
                    this.popState();
                    break;
                case 54: return "acc_descr_multiline_value";
                case 55: return 6;
                case 56: return 19;
                case 57: return 21;
                case 58: return 66;
                case 59: return 5;
                case 60:
                    return w.yytext = w.yytext.trim(), 73;
                    break;
                case 61: return 80;
                case 62: return 97;
                case 63: return 98;
                case 64: return 99;
                case 65: return 78;
                case 66: return 79;
                case 67: return 100;
                case 68: return 101;
                case 69: return 102;
                case 70: return 103;
                case 71: return 85;
                case 72: return 86;
                case 73: return 87;
                case 74: return 88;
                case 75: return 93;
                case 76: return 94;
                case 77: return 95;
                case 78: return 96;
                case 79: return 81;
                case 80: return 82;
                case 81: return 83;
                case 82: return 84;
                case 83: return 89;
                case 84: return 90;
                case 85: return 91;
                case 86: return 92;
                case 87: return 104;
                case 88: return 104;
                case 89: return 70;
                case 90: return 71;
                case 91: return 72;
                case 92: return 5;
                case 93: return 10;
            } }, "anonymous"), rules: [/^(?:[\n]+)/i, /^(?:\s+)/i, /^(?:((?!\n)\s)+)/i, /^(?:#[^\n]*)/i, /^(?:%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:([0-9]+(\.[0-9]{1,2})?|\.[0-9]{1,2})(?=[ \n]+))/i, /^(?:@\{)/i, /^(?:[^\}]+)/i, /^(?:\}(?=\s+as\s))/i, /^(?:\})/i, /^(?:[^\<->\->:\n,;@\s]+(?=@\{))/i, /^(?:[^<>:\n,;@\s]+(?=\s+as\s))/i, /^(?:[^<>:\n,;@]+(?=\s*[\n;#]|$))/i, /^(?:[^<>:\n,;@]*<[^\n]*)/i, /^(?:[^\n]+)/i, /^(?:box\b)/i, /^(?:participant\b)/i, /^(?:actor\b)/i, /^(?:create\b)/i, /^(?:destroy\b)/i, /^(?:as\b)/i, /^(?:(?:))/i, /^(?:loop\b)/i, /^(?:rect\b)/i, /^(?:opt\b)/i, /^(?:alt\b)/i, /^(?:else\b)/i, /^(?:par\b)/i, /^(?:par_over\b)/i, /^(?:and\b)/i, /^(?:critical\b)/i, /^(?:option\b)/i, /^(?:break\b)/i, /^(?:(?:[:]?(?:no)?wrap)?[^#\n;]*)/i, /^(?:end\b)/i, /^(?:left of\b)/i, /^(?:right of\b)/i, /^(?:links\b)/i, /^(?:link\b)/i, /^(?:properties\b)/i, /^(?:details\b)/i, /^(?:over\b)/i, /^(?:note\b)/i, /^(?:activate\b)/i, /^(?:deactivate\b)/i, /^(?:title\s[^#\n;]+)/i, /^(?:title:\s[^#\n;]+)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?:sequenceDiagram\b)/i, /^(?:autonumber\b)/i, /^(?:off\b)/i, /^(?:,)/i, /^(?:;)/i, /^(?:[^\/\\\+\()\+<\->\->:\n,;]+((?!(-x|--x|-\)|--\)|-\|\\|-\\|-\/|-\/\/|-\|\/|\/\|-|\\\|-|\/\/-|\\\\-|\/\|-|--\|\\|--|\(\)))[\-]*[^\+<\->\->:\n,;]+)*)/i, /^(?:->>)/i, /^(?:<<->>)/i, /^(?:-->>)/i, /^(?:<<-->>)/i, /^(?:->)/i, /^(?:-->)/i, /^(?:-[x])/i, /^(?:--[x])/i, /^(?:-[\)])/i, /^(?:--[\)])/i, /^(?:--\|\\)/i, /^(?:--\|\/)/i, /^(?:--\\\\)/i, /^(?:--\/\/)/i, /^(?:\/\|--)/i, /^(?:\\\|--)/i, /^(?:\/\/--)/i, /^(?:\\\\--)/i, /^(?:-\|\\)/i, /^(?:-\|\/)/i, /^(?:-\\\\)/i, /^(?:-\/\/)/i, /^(?:\/\|-)/i, /^(?:\\\|-)/i, /^(?:\/\/-)/i, /^(?:\\\\-)/i, /^(?::(?:(?:no)?wrap)?[^#\n;]*)/i, /^(?::)/i, /^(?:\+)/i, /^(?:-)/i, /^(?:\(\))/i, /^(?:$)/i, /^(?:.)/i], conditions: { acc_descr_multiline: { rules: [53, 54], inclusive: !1 }, acc_descr: { rules: [51], inclusive: !1 }, acc_title: { rules: [49], inclusive: !1 }, ID: { rules: [2, 3, 7, 11, 12, 13, 14, 15], inclusive: !1 }, ALIAS: { rules: [2, 3, 21, 22], inclusive: !1 }, LINE: { rules: [2, 3, 34], inclusive: !1 }, CONFIG: { rules: [8, 9, 10], inclusive: !1 }, CONFIG_DATA: { rules: [], inclusive: !1 }, INITIAL: { rules: [0, 1, 3, 4, 5, 6, 16, 17, 18, 19, 20, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 50, 52, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93], inclusive: !0 } } };
        return ft;
    })();
    $t.lexer = fr;
    function Vt() { this.yy = {}; }
    return x(Vt, "Parser"), Vt.prototype = $t, $t.Parser = Vt, new Vt;
})();
ce.parser = ce;
var Rr = ce, Or = { SOLID: 0, DOTTED: 1, NOTE: 2, SOLID_CROSS: 3, DOTTED_CROSS: 4, SOLID_OPEN: 5, DOTTED_OPEN: 6, LOOP_START: 10, LOOP_END: 11, ALT_START: 12, ALT_ELSE: 13, ALT_END: 14, OPT_START: 15, OPT_END: 16, ACTIVE_START: 17, ACTIVE_END: 18, PAR_START: 19, PAR_AND: 20, PAR_END: 21, RECT_START: 22, RECT_END: 23, SOLID_POINT: 24, DOTTED_POINT: 25, AUTONUMBER: 26, CRITICAL_START: 27, CRITICAL_OPTION: 28, CRITICAL_END: 29, BREAK_START: 30, BREAK_END: 31, PAR_OVER_START: 32, BIDIRECTIONAL_SOLID: 33, BIDIRECTIONAL_DOTTED: 34, SOLID_TOP: 41, SOLID_BOTTOM: 42, STICK_TOP: 43, STICK_BOTTOM: 44, SOLID_ARROW_TOP_REVERSE: 45, SOLID_ARROW_BOTTOM_REVERSE: 46, STICK_ARROW_TOP_REVERSE: 47, STICK_ARROW_BOTTOM_REVERSE: 48, SOLID_TOP_DOTTED: 51, SOLID_BOTTOM_DOTTED: 52, STICK_TOP_DOTTED: 53, STICK_BOTTOM_DOTTED: 54, SOLID_ARROW_TOP_REVERSE_DOTTED: 55, SOLID_ARROW_BOTTOM_REVERSE_DOTTED: 56, STICK_ARROW_TOP_REVERSE_DOTTED: 57, STICK_ARROW_BOTTOM_REVERSE_DOTTED: 58, CENTRAL_CONNECTION: 59, CENTRAL_CONNECTION_REVERSE: 60, CENTRAL_CONNECTION_DUAL: 61 }, Lr = { FILLED: 0, OPEN: 1 }, mr = { LEFTOF: 0, RIGHTOF: 1, OVER: 2 }, zt = { ACTOR: "actor", BOUNDARY: "boundary", COLLECTIONS: "collections", CONTROL: "control", DATABASE: "database", ENTITY: "entity", PARTICIPANT: "participant", QUEUE: "queue" }, Ar = class {
    constructor() { this.state = new rr(() => ({ prevActor: void 0, actors: new Map, createdActors: new Map, destroyedActors: new Map, boxes: [], messages: [], notes: [], sequenceNumbersEnabled: !1, wrapEnabled: void 0, currentBox: void 0, lastCreated: void 0, lastDestroyed: void 0 })), this.setAccTitle = ie, this.setAccDescription = Ue, this.setDiagramTitle = Xe, this.getAccTitle = ze, this.getAccDescription = Ge, this.getDiagramTitle = Je, this.apply = this.apply.bind(this), this.parseBoxData = this.parseBoxData.bind(this), this.parseMessage = this.parseMessage.bind(this), this.clear(), this.setWrap($().wrap), this.LINETYPE = Or, this.ARROWTYPE = Lr, this.PLACEMENT = mr; }
    static { x(this, "SequenceDB"); }
    addBox(e) { this.state.records.boxes.push({ name: e.text, wrap: e.wrap ?? this.autoWrap(), fill: e.color, actorKeys: [] }), this.state.records.currentBox = this.state.records.boxes.slice(-1)[0]; }
    addActor(e, t, a, r, i) {
        let o = this.state.records.currentBox, s;
        if (i !== void 0) {
            let u;
            i.includes(`
`) ? u = i + `
` : u = `{
` + i + `
}`, s = je(u, { schema: $e });
        }
        r = s?.type ?? r, s?.alias && (!a || a.text === t) && (a = { text: s.alias, wrap: a?.wrap, type: r });
        let c = this.state.records.actors.get(e);
        if (c) {
            if (this.state.records.currentBox && c.box && this.state.records.currentBox !== c.box)
                throw new Error(`A same participant should only be defined in one Box: ${c.name} can't be in '${c.box.name}' and in '${this.state.records.currentBox.name}' at the same time.`);
            if (o = c.box ? c.box : this.state.records.currentBox, c.box = o, c && t === c.name && a == null)
                return;
        }
        if (a?.text == null && (a = { text: t, type: r }), (r == null || a.text == null) && (a = { text: t, type: r }), this.state.records.actors.set(e, { box: o, name: t, description: a.text, wrap: a.wrap ?? this.autoWrap(), prevActor: this.state.records.prevActor, links: {}, properties: {}, actorCnt: null, rectData: null, type: r ?? "participant" }), this.state.records.prevActor) {
            let u = this.state.records.actors.get(this.state.records.prevActor);
            u && (u.nextActor = e);
        }
        this.state.records.currentBox && this.state.records.currentBox.actorKeys.push(e), this.state.records.prevActor = e;
    }
    activationCount(e) { let t, a = 0; if (!e)
        return 0; for (t = 0; t < this.state.records.messages.length; t++)
        this.state.records.messages[t].type === this.LINETYPE.ACTIVE_START && this.state.records.messages[t].from === e && a++, this.state.records.messages[t].type === this.LINETYPE.ACTIVE_END && this.state.records.messages[t].from === e && a--; return a; }
    addMessage(e, t, a, r) { this.state.records.messages.push({ id: this.state.records.messages.length.toString(), from: e, to: t, message: a.text, wrap: a.wrap ?? this.autoWrap(), answer: r }); }
    addSignal(e, t, a, r, i = !1, o) { if (r === this.LINETYPE.ACTIVE_END && this.activationCount(e ?? "") < 1) {
        let c = new Error("Trying to inactivate an inactive participant (" + e + ")");
        throw c.hash = { text: "->>-", token: "->>-", line: "1", loc: { first_line: 1, last_line: 1, first_column: 1, last_column: 1 }, expected: ["'ACTIVE_PARTICIPANT'"] }, c;
    } return this.state.records.messages.push({ id: this.state.records.messages.length.toString(), from: e, to: t, message: a?.text ?? "", wrap: a?.wrap ?? this.autoWrap(), type: r, activate: i, centralConnection: o ?? 0 }), !0; }
    hasAtLeastOneBox() { return this.state.records.boxes.length > 0; }
    hasAtLeastOneBoxWithTitle() { return this.state.records.boxes.some(e => e.name); }
    getMessages() { return this.state.records.messages; }
    getBoxes() { return this.state.records.boxes; }
    getActors() { return this.state.records.actors; }
    getCreatedActors() { return this.state.records.createdActors; }
    getDestroyedActors() { return this.state.records.destroyedActors; }
    getActor(e) { return this.state.records.actors.get(e); }
    getActorKeys() { return [...this.state.records.actors.keys()]; }
    enableSequenceNumbers() { this.state.records.sequenceNumbersEnabled = !0; }
    disableSequenceNumbers() { this.state.records.sequenceNumbersEnabled = !1; }
    showSequenceNumbers() { return this.state.records.sequenceNumbersEnabled; }
    setWrap(e) { this.state.records.wrapEnabled = e; }
    extractWrap(e) { if (e === void 0)
        return {}; e = e.trim(); let t = /^:?wrap:/.exec(e) !== null ? !0 : /^:?nowrap:/.exec(e) !== null ? !1 : void 0; return { cleanedText: (t === void 0 ? e : e.replace(/^:?(?:no)?wrap:/, "")).trim(), wrap: t }; }
    autoWrap() { return this.state.records.wrapEnabled !== void 0 ? this.state.records.wrapEnabled : $().sequence?.wrap ?? !1; }
    clear() { this.state.reset(), He(); }
    parseMessage(e) { let t = e.trim(), { wrap: a, cleanedText: r } = this.extractWrap(t), i = { text: r, wrap: a }; return tt.debug(`parseMessage: ${JSON.stringify(i)}`), i; }
    parseBoxData(e) { let t = /^((?:rgba?|hsla?)\s*\(.*\)|\w*)(.*)$/.exec(e), a = t?.[1] ? t[1].trim() : "transparent", r = t?.[2] ? t[2].trim() : void 0; if (window?.CSS)
        window.CSS.supports("color", a) || (a = "transparent", r = e.trim());
    else {
        let s = new Option().style;
        s.color = a, s.color !== a && (a = "transparent", r = e.trim());
    } let { wrap: i, cleanedText: o } = this.extractWrap(r); return { text: o ? Dt(o, $()) : void 0, color: a, wrap: i }; }
    addNote(e, t, a) { let r = { actor: e, placement: t, message: a.text, wrap: a.wrap ?? this.autoWrap() }, i = [].concat(e, e); this.state.records.notes.push(r), this.state.records.messages.push({ id: this.state.records.messages.length.toString(), from: i[0], to: i[1], message: a.text, wrap: a.wrap ?? this.autoWrap(), type: this.LINETYPE.NOTE, placement: t }); }
    addLinks(e, t) { let a = this.getActor(e); try {
        let r = Dt(t.text, $());
        r = r.replace(/&equals;/g, "="), r = r.replace(/&amp;/g, "&");
        let i = JSON.parse(r);
        this.insertLinks(a, i);
    }
    catch (r) {
        tt.error("error while parsing actor link text", r);
    } }
    addALink(e, t) { let a = this.getActor(e); try {
        let r = {}, i = Dt(t.text, $()), o = i.indexOf("@");
        i = i.replace(/&equals;/g, "="), i = i.replace(/&amp;/g, "&");
        let s = i.slice(0, o - 1).trim(), c = i.slice(o + 1).trim();
        r[s] = c, this.insertLinks(a, r);
    }
    catch (r) {
        tt.error("error while parsing actor link text", r);
    } }
    insertLinks(e, t) { if (e.links == null)
        e.links = t;
    else
        for (let a in t)
            e.links[a] = t[a]; }
    addProperties(e, t) { let a = this.getActor(e); try {
        let r = Dt(t.text, $()), i = JSON.parse(r);
        this.insertProperties(a, i);
    }
    catch (r) {
        tt.error("error while parsing actor properties text", r);
    } }
    insertProperties(e, t) { if (e.properties == null)
        e.properties = t;
    else
        for (let a in t)
            e.properties[a] = t[a]; }
    boxEnd() { this.state.records.currentBox = void 0; }
    addDetails(e, t) { let a = this.getActor(e), r = document.getElementById(t.text); try {
        let i = r.innerHTML, o = JSON.parse(i);
        o.properties && this.insertProperties(a, o.properties), o.links && this.insertLinks(a, o.links);
    }
    catch (i) {
        tt.error("error while parsing actor details text", i);
    } }
    getActorProperty(e, t) { if (e?.properties !== void 0)
        return e.properties[t]; }
    apply(e) { if (Array.isArray(e))
        e.forEach(t => { this.apply(t); });
    else
        switch (e.type) {
            case "sequenceIndex":
                this.state.records.messages.push({ id: this.state.records.messages.length.toString(), from: void 0, to: void 0, message: { start: e.sequenceIndex, step: e.sequenceIndexStep, visible: e.sequenceVisible }, wrap: !1, type: e.signalType });
                break;
            case "addParticipant":
                this.addActor(e.actor, e.actor, e.description, e.draw, e.config);
                break;
            case "createParticipant":
                if (this.state.records.actors.has(e.actor))
                    throw new Error("It is not possible to have actors with the same id, even if one is destroyed before the next is created. Use 'AS' aliases to simulate the behavior");
                this.state.records.lastCreated = e.actor, this.addActor(e.actor, e.actor, e.description, e.draw, e.config), this.state.records.createdActors.set(e.actor, this.state.records.messages.length);
                break;
            case "destroyParticipant":
                this.state.records.lastDestroyed = e.actor, this.state.records.destroyedActors.set(e.actor, this.state.records.messages.length);
                break;
            case "activeStart":
                this.addSignal(e.actor, void 0, void 0, e.signalType);
                break;
            case "centralConnection":
                this.addSignal(e.actor, void 0, void 0, e.signalType);
                break;
            case "centralConnectionReverse":
                this.addSignal(e.actor, void 0, void 0, e.signalType);
                break;
            case "activeEnd":
                this.addSignal(e.actor, void 0, void 0, e.signalType);
                break;
            case "addNote":
                this.addNote(e.actor, e.placement, e.text);
                break;
            case "addLinks":
                this.addLinks(e.actor, e.text);
                break;
            case "addALink":
                this.addALink(e.actor, e.text);
                break;
            case "addProperties":
                this.addProperties(e.actor, e.text);
                break;
            case "addDetails":
                this.addDetails(e.actor, e.text);
                break;
            case "addMessage":
                if (this.state.records.lastCreated) {
                    if (e.to !== this.state.records.lastCreated)
                        throw new Error("The created participant " + this.state.records.lastCreated.name + " does not have an associated creating message after its declaration. Please check the sequence diagram.");
                    this.state.records.lastCreated = void 0;
                }
                else if (this.state.records.lastDestroyed) {
                    if (e.to !== this.state.records.lastDestroyed && e.from !== this.state.records.lastDestroyed)
                        throw new Error("The destroyed participant " + this.state.records.lastDestroyed.name + " does not have an associated destroying message after its declaration. Please check the sequence diagram.");
                    this.state.records.lastDestroyed = void 0;
                }
                this.addSignal(e.from, e.to, e.msg, e.signalType, e.activate, e.centralConnection);
                break;
            case "boxStart":
                this.addBox(e.boxData);
                break;
            case "boxEnd":
                this.boxEnd();
                break;
            case "loopStart":
                this.addSignal(void 0, void 0, e.loopText, e.signalType);
                break;
            case "loopEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "rectStart":
                this.addSignal(void 0, void 0, e.color, e.signalType);
                break;
            case "rectEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "optStart":
                this.addSignal(void 0, void 0, e.optText, e.signalType);
                break;
            case "optEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "altStart":
                this.addSignal(void 0, void 0, e.altText, e.signalType);
                break;
            case "else":
                this.addSignal(void 0, void 0, e.altText, e.signalType);
                break;
            case "altEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "setAccTitle":
                ie(e.text);
                break;
            case "parStart":
                this.addSignal(void 0, void 0, e.parText, e.signalType);
                break;
            case "and":
                this.addSignal(void 0, void 0, e.parText, e.signalType);
                break;
            case "parEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "criticalStart":
                this.addSignal(void 0, void 0, e.criticalText, e.signalType);
                break;
            case "option":
                this.addSignal(void 0, void 0, e.optionText, e.signalType);
                break;
            case "criticalEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
            case "breakStart":
                this.addSignal(void 0, void 0, e.breakText, e.signalType);
                break;
            case "breakEnd":
                this.addSignal(void 0, void 0, void 0, e.signalType);
                break;
        } }
    getConfig() { return $().sequence; }
}, Sr = x(e => {
    let t = e.dropShadow ?? "none", { look: a } = $();
    return `.actor {
    stroke: ${e.actorBorder};
    fill: ${e.actorBkg};
    stroke-width: ${e.strokeWidth ?? 1};
  }

  rect.actor.outer-path[data-look="neo"] {
      filter: ${t};
  }

  rect.note[data-look="neo"] {
      stroke:${e.noteBorderColor};
      fill:${e.noteBkgColor};
      filter: ${t};
  }

  text.actor > tspan {
    fill: ${e.actorTextColor};
    stroke: none;
  }

  .actor-line {
    stroke: ${e.actorLineColor};
  }

  .innerArc {
    stroke-width: 1.5;
    stroke-dasharray: none;
  }

  .messageLine0 {
    stroke-width: 1.5;
    stroke-dasharray: none;
    stroke: ${e.signalColor};
  }

  .messageLine1 {
    stroke-width: 1.5;
    stroke-dasharray: 2, 2;
    stroke: ${e.signalColor};
  }

  [id$="-arrowhead"] path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .sequenceNumber {
    fill: ${e.sequenceNumberColor};
  }

  [id$="-sequencenumber"] {
    fill: ${e.signalColor};
  }

  [id$="-crosshead"] path {
    fill: ${e.signalColor};
    stroke: ${e.signalColor};
  }

  .messageText {
    fill: ${e.signalTextColor};
    stroke: none;
  }

  .labelBox {
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBkgColor};
    filter: ${a === "neo" ? t : "none"};
  }

  .labelText, .labelText > tspan {
    fill: ${e.labelTextColor};
    stroke: none;
  }

  .loopText, .loopText > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .sectionTitle, .sectionTitle > tspan {
    fill: ${e.loopTextColor};
    stroke: none;
  }

  .loopLine {
    stroke-width: 2px;
    stroke-dasharray: 2, 2;
    stroke: ${e.labelBoxBorderColor};
    fill: ${e.labelBoxBorderColor};
  }

  .note {
    //stroke: #decc93;
    stroke: ${e.noteBorderColor};
    fill: ${e.noteBkgColor};
  }

  .noteText, .noteText > tspan {
    fill: ${e.noteTextColor};
    stroke: none;
    ${e.noteFontWeight ? `font-weight: ${e.noteFontWeight};` : ""}
  }

  .activation0 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation1 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .activation2 {
    fill: ${e.activationBkgColor};
    stroke: ${e.activationBorderColor};
  }

  .actorPopupMenu {
    position: absolute;
  }

  .actorPopupMenuPanel {
    position: absolute;
    fill: ${e.actorBkg};
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
    filter: drop-shadow(3px 5px 2px rgb(0 0 0 / 0.4));
}
  .actor-man circle, line {
    fill: ${e.actorBkg};
    stroke-width: 2px;
  }

  g rect.rect {
    filter: ${t};
    stroke: ${e.nodeBorder};
  }
`;
}, "getStyles"), kr = Sr, bt = 36, _t = "actor-top", gt = "actor-bottom", Gt = "actor-box", yt = "actor-man", Et = new Set(["redux-color", "redux-dark-color"]), Ct = x(function (e, t) { let a = tr(e, t); return Pt().look === "neo" && a.attr("data-look", "neo"), a; }, "drawRect"), Nr = x(function (e, t, a, r, i) { if (t.links === void 0 || t.links === null || Object.keys(t.links).length === 0)
    return { height: 0, width: 0 }; let o = t.links, s = t.actorCnt, c = t.rectData; var u = "none"; i && (u = "block !important"); let d = e.append("g"); d.attr("id", "actor" + s + "_popup"), d.attr("class", "actorPopupMenu"), d.attr("display", u); var p = ""; c.class !== void 0 && (p = " " + c.class); let _ = c.width > a ? c.width : a, E = d.append("rect"); if (E.attr("class", "actorPopupMenuPanel" + p), E.attr("x", c.x), E.attr("y", c.height), E.attr("fill", c.fill), E.attr("stroke", c.stroke), E.attr("width", _), E.attr("height", c.height), E.attr("rx", c.rx), E.attr("ry", c.ry), o != null) {
    var R = 20;
    for (let f in o) {
        var T = d.append("a"), g = (0, de.sanitizeUrl)(o[f]);
        T.attr("xlink:href", g), T.attr("target", "_blank"), jr(r)(f, T, c.x + 10, c.height + R, _, 20, { class: "actor" }, r), R += 30;
    }
} return E.attr("height", R), { height: c.height + R, width: _ }; }, "drawPopup"), Xt = x(function (e) { return "var pu = document.getElementById('" + e + "'); if (pu != null) { pu.style.display = pu.style.display == 'block' ? 'none' : 'block'; }"; }, "popupMenuToggle"), Ut = x(function (e, t, a = null) { return st(this, null, function* () { let r = e.append("foreignObject"), i = yield se(t.text, Pt()), s = r.append("xhtml:div").attr("style", "width: fit-content;").attr("xmlns", "http://www.w3.org/1999/xhtml").html(i).node().getBoundingClientRect(); if (r.attr("height", Math.round(s.height)).attr("width", Math.round(s.width)), t.class === "noteText") {
    let c = e.node().firstChild;
    c.setAttribute("height", s.height + 2 * t.textMargin);
    let u = c.getBBox();
    r.attr("x", Math.round(u.x + u.width / 2 - s.width / 2)).attr("y", Math.round(u.y + u.height / 2 - s.height / 2));
}
else if (a) {
    let { startx: c, stopx: u, starty: d } = a;
    if (c > u) {
        let p = c;
        c = u, u = p;
    }
    r.attr("x", Math.round(c + Math.abs(c - u) / 2 - s.width / 2)), t.class === "loopText" ? r.attr("y", Math.round(d)) : r.attr("y", Math.round(d - s.height));
} return [r]; }); }, "drawKatex"), St = x(function (e, t) { let a = 0, r = 0, i = t.text.split(N.lineBreakRegex), [o, s] = ne(t.fontSize), c = [], u = 0, d = x(() => t.y, "yfunc"); if (t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0)
    switch (t.valign) {
        case "top":
        case "start":
            d = x(() => Math.round(t.y + t.textMargin), "yfunc");
            break;
        case "middle":
        case "center":
            d = x(() => Math.round(t.y + (a + r + t.textMargin) / 2), "yfunc");
            break;
        case "bottom":
        case "end":
            d = x(() => Math.round(t.y + (a + r + 2 * t.textMargin) - t.textMargin), "yfunc");
            break;
    } if (t.anchor !== void 0 && t.textMargin !== void 0 && t.width !== void 0)
    switch (t.anchor) {
        case "left":
        case "start":
            t.x = Math.round(t.x + t.textMargin), t.anchor = "start", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
            break;
        case "middle":
        case "center":
            t.x = Math.round(t.x + t.width / 2), t.anchor = "middle", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
            break;
        case "right":
        case "end":
            t.x = Math.round(t.x + t.width - t.textMargin), t.anchor = "end", t.dominantBaseline = "middle", t.alignmentBaseline = "middle";
            break;
    } for (let [p, _] of i.entries()) {
    t.textMargin !== void 0 && t.textMargin === 0 && o !== void 0 && (u = p * o);
    let E = e.append("text");
    E.attr("x", t.x), E.attr("y", d()), t.anchor !== void 0 && E.attr("text-anchor", t.anchor).attr("dominant-baseline", t.dominantBaseline).attr("alignment-baseline", t.alignmentBaseline), t.fontFamily !== void 0 && E.style("font-family", t.fontFamily), s !== void 0 && E.style("font-size", s), t.fontWeight !== void 0 && E.style("font-weight", t.fontWeight), t.fill !== void 0 && E.attr("fill", t.fill), t.class !== void 0 && E.attr("class", t.class), t.dy !== void 0 ? E.attr("dy", t.dy) : u !== 0 && E.attr("dy", u);
    let R = _ || Ze;
    if (t.tspan) {
        let T = E.append("tspan");
        T.attr("x", t.x), t.fill !== void 0 && T.attr("fill", t.fill), T.text(R);
    }
    else
        E.text(R);
    t.valign !== void 0 && t.textMargin !== void 0 && t.textMargin > 0 && (r += (E._groups || E)[0][0].getBBox().height, a = r), c.push(E);
} return c; }, "drawText"), ir = x(function (e, t) { function a(i, o, s, c, u) { return i + "," + o + " " + (i + s) + "," + o + " " + (i + s) + "," + (o + c - u) + " " + (i + s - u * 1.2) + "," + (o + c) + " " + i + "," + (o + c); } x(a, "genPoints"); let r = e.append("polygon"); return r.attr("points", a(t.x, t.y, t.width, t.height, 7)), r.attr("class", "labelBox"), t.y = t.y + t.height / 2, St(e, t), r; }, "drawLabel"), B = -1, nr = x((e, t, a, r) => { e.select && a.forEach(i => { let o = t.get(i), s = e.select("#actor" + o.actorCnt); !r.mirrorActors && o.stopy ? s.attr("y2", o.stopy + o.height / 2) : r.mirrorActors && s.attr("y2", o.stopy); }); }, "fixLifeLineHeights"), wr = x(function (e, t, a, r, i) { let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + t.height, { look: u, theme: d, themeVariables: p } = a, { bkgColorArray: _, borderColorArray: E } = p, R = e.append("g").lower(); var T = R; r || (B++, Object.keys(t.links || {}).length && !a.forceMenus && T.attr("onclick", Xt(`actor${B}_popup`)).attr("cursor", "pointer"), T.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), T = R.append("g"), t.actorCnt = B, t.links != null && T.attr("id", "root-" + B), u === "neo" && T.attr("data-look", "neo")); let g = dt(); var f = "actor"; t.properties?.class ? f = t.properties.class : g.fill = "#eaeaea", r ? f += ` ${gt}` : f += ` ${_t}`, g.x = t.x, g.y = o, g.width = t.width, g.height = t.height, g.class = f, g.rx = 3, g.ry = 3, g.name = t.name, u === "neo" && (g.rx = 6, g.ry = 6); let I = Ct(T, g), O = i.get(t.name) ?? 0; if (Et.has(d) && (I.style("stroke", E[O % E.length]), I.style("fill", _[O % E.length])), u === "neo" && I.attr("filter", "url(#drop-shadow)"), t.rectData = g, t.properties?.icon) {
    let k = t.properties.icon.trim();
    k.charAt(0) === "@" ? qt(T, g.x + g.width - 20, g.y + 10, k.substr(1)) : Ft(T, g.x + g.width - 20, g.y + 10, k);
} r || (T.attr("data-et", "participant"), T.attr("data-type", "participant"), T.attr("data-id", t.name)), ut(a, Z(t.description))(t.description, T, g.x, g.y, g.width, g.height, { class: `actor ${Gt}` }, a); let L = t.height; if (I.node) {
    let k = I.node().getBBox();
    t.height = k.height, L = k.height;
} return L; }, "drawActorTypeParticipant"), Pr = x(function (e, t, a, r, i) { let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + t.height, { look: u, theme: d, themeVariables: p } = a, { bkgColorArray: _, borderColorArray: E } = p, R = e.append("g").lower(); var T = R; r || (B++, Object.keys(t.links || {}).length && !a.forceMenus && T.attr("onclick", Xt(`actor${B}_popup`)).attr("cursor", "pointer"), T.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), T = R.append("g"), t.actorCnt = B, t.links != null && T.attr("id", "root-" + B), u === "neo" && T.attr("data-look", "neo")); let g = dt(); var f = "actor"; t.properties?.class ? f = t.properties.class : g.fill = "#eaeaea", r ? f += ` ${gt}` : f += ` ${_t}`, g.x = t.x, g.y = o, g.width = t.width, g.height = t.height, g.class = f, g.name = t.name; let I = 6, O = We(Ye({}, g), { x: g.x + -I, y: g.y + +I, class: "actor" }), L = Ct(T, g), k = Ct(T, O); t.rectData = g, u === "neo" && T.attr("filter", "url(#drop-shadow)"); let A = i.get(t.name) ?? 0; if (Et.has(d) && (L.style("stroke", E[A % E.length]), L.style("fill", _[A % E.length]), k.style("stroke", E[A % E.length]), k.style("fill", _[A % E.length])), t.properties?.icon) {
    let M = t.properties.icon.trim();
    M.charAt(0) === "@" ? qt(T, g.x + g.width - 20, g.y + 10, M.substr(1)) : Ft(T, g.x + g.width - 20, g.y + 10, M);
} ut(a, Z(t.description))(t.description, T, g.x - I, g.y + I, g.width, g.height, { class: `actor ${Gt}` }, a); let D = t.height; if (L.node) {
    let M = L.node().getBBox();
    t.height = M.height, D = M.height;
} return r || (T.attr("data-et", "participant"), T.attr("data-type", "collections"), T.attr("data-id", t.name)), D; }, "drawActorTypeCollections"), Dr = x(function (e, t, a, r, i) {
    let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + t.height, { look: u, theme: d, themeVariables: p } = a, { bkgColorArray: _, borderColorArray: E } = p, R = e.append("g").lower(), T = R;
    r || (B++, Object.keys(t.links || {}).length && !a.forceMenus && T.attr("onclick", Xt(`actor${B}_popup`)).attr("cursor", "pointer"), T.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), T = R.append("g"), t.actorCnt = B, t.links != null && T.attr("id", "root-" + B), u === "neo" && T.attr("data-look", "neo"));
    let g = dt(), f = "actor";
    t.properties?.class ? f = t.properties.class : g.fill = "#eaeaea", r ? f += ` ${gt}` : f += ` ${_t}`, T.attr("class", f), g.x = t.x, g.y = o, g.width = t.width, g.height = t.height, g.name = t.name;
    let I = g.height / 2, O = I / (2.5 + g.height / 50), L = T.append("g"), k = T.append("g"), A = `M ${g.x},${g.y + I}
    a ${O},${I} 0 0 0 0,${g.height}
    h ${g.width - 2 * O}
    a ${O},${I} 0 0 0 0,-${g.height}
    Z
  `;
    L.append("path").attr("d", A), k.append("path").attr("d", `M ${g.x},${g.y + I}
      a ${O},${I} 0 0 0 0,${g.height}`), L.attr("transform", `translate(${O}, ${-(g.height / 2)})`), k.attr("transform", `translate(${g.width - O}, ${-g.height / 2})`), t.rectData = g, u === "neo" && L.attr("filter", "url(#drop-shadow)");
    let D = i.get(t.name) ?? 0;
    if (Et.has(d) && (L.style("stroke", E[D % E.length]), L.style("fill", _[D % E.length]), k.style("stroke", E[D % E.length]), k.style("fill", _[D % E.length])), t.properties?.icon) {
        let W = t.properties.icon.trim(), U = g.x + g.width - 20, G = g.y + 10;
        W.charAt(0) === "@" ? qt(T, U, G, W.substr(1)) : Ft(T, U, G, W);
    }
    ut(a, Z(t.description))(t.description, T, g.x, g.y, g.width, g.height, { class: `actor ${Gt}` }, a);
    let M = t.height, V = L.select("path:last-child");
    if (V.node()) {
        let W = V.node().getBBox();
        t.height = W.height, M = W.height;
    }
    return r || (T.attr("data-et", "participant"), T.attr("data-type", "queue"), T.attr("data-id", t.name)), M;
}, "drawActorTypeQueue"), vr = x(function (e, t, a, r, i, o) { let s = r ? t.stopy : t.starty, c = t.x + t.width / 2, u = s + 75, { look: d, theme: p, themeVariables: _ } = a, { bkgColorArray: E, borderColorArray: R, actorBorder: T, actorBkg: g } = _, f = e.append("g").lower(); r || (B++, f.append("line").attr("id", "actor" + B).attr("x1", c).attr("y1", u).attr("x2", c).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = B); let I = e.append("g"), O = yt; r ? O += ` ${gt}` : O += ` ${_t}`, I.attr("class", O), I.attr("name", t.name); let L = dt(); L.x = t.x, L.y = s, L.fill = "#eaeaea", L.width = t.width, L.height = t.height, L.class = "actor"; let k = t.x + t.width / 2, A = s + 32, D = 22; I.append("defs").append("marker").attr("id", i + "-filled-head-control").attr("refX", 11).attr("refY", 5.8).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "172.5").attr("stroke-width", 1.2).append("path").attr("d", "M 14.4 5.6 L 7.2 10.4 L 8.8 5.6 L 7.2 0.8 Z"), I.append("circle").attr("cx", k).attr("cy", A).attr("r", D).attr("filter", `${d === "neo" ? "url(#drop-shadow)" : ""}`), I.append("line").attr("marker-end", "url(#" + i + "-filled-head-control)").attr("transform", `translate(${k}, ${A - D})`); let M = o.get(t.name) ?? 0; Et.has(p) ? (I.style("stroke", R[M % R.length]), I.style("fill", E[M % R.length])) : (I.style("stroke", T), I.style("fill", g)); let V = I.node().getBBox(); return t.height = V.height + 2 * (a?.sequence?.labelBoxHeight ?? 0), ut(a, Z(t.description))(t.description, I, L.x, L.y + D + (r ? 5 : 12), L.width, L.height, { class: `actor ${yt}` }, a), r || (I.attr("data-et", "participant"), I.attr("data-type", "control"), I.attr("data-id", t.name)), t.height; }, "drawActorTypeControl"), Cr = x(function (e, t, a, r, i) { let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + 75, { look: u, theme: d, themeVariables: p } = a, { bkgColorArray: _, borderColorArray: E } = p, R = e.append("g").lower(), T = e.append("g"), g = "actor"; r ? g += ` ${gt}` : g += ` ${_t}`, T.attr("class", g), T.attr("name", t.name); let f = dt(); f.x = t.x, f.y = o, f.fill = "#eaeaea", f.width = t.width, f.height = t.height, f.class = "actor"; let I = t.x + t.width / 2, O = o + (r ? 10 : 25), L = 22; T.append("circle").attr("cx", I).attr("cy", O).attr("r", L).attr("width", t.width).attr("height", t.height), T.append("line").attr("x1", I - L).attr("x2", I + L).attr("y1", O + L).attr("y2", O + L).attr("stroke-width", 2), u === "neo" && T.attr("filter", "url(#drop-shadow)"); let k = i.get(t.name) ?? 0; Et.has(d) && (T.style("stroke", E[k % E.length]), T.style("fill", _[k % E.length])); let A = T.node().getBBox(); return t.height = A.height + (a?.sequence?.labelBoxHeight ?? 0), r || (B++, R.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = B), ut(a, Z(t.description))(t.description, T, f.x, f.y + (r ? 15 : 30), f.width, f.height, { class: `actor ${yt}` }, a), r ? T.attr("transform", `translate(0, ${L})`) : (T.attr("transform", `translate(0, ${L / 2 - 5})`), T.attr("data-et", "participant"), T.attr("data-type", "entity"), T.attr("data-id", t.name)), t.height; }, "drawActorTypeEntity"), Mr = x(function (e, t, a, r, i) {
    let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + t.height + 2 * a.boxTextMargin, { theme: u, themeVariables: d, look: p } = a, { bkgColorArray: _, borderColorArray: E, actorBorder: R } = d, T = e.append("g").lower(), g = T;
    r || (B++, Object.keys(t.links || {}).length && !a.forceMenus && g.attr("onclick", Xt(`actor${B}_popup`)).attr("cursor", "pointer"), g.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), g = T.append("g"), t.actorCnt = B, t.links != null && g.attr("id", "root-" + B), p === "neo" && g.attr("data-look", "neo"));
    let f = dt(), I = "actor";
    t.properties?.class ? I = t.properties.class : f.fill = "#eaeaea", r ? I += ` ${gt}` : I += ` ${_t}`, f.x = t.x, f.y = o, f.width = t.width, f.height = t.height, f.class = I, f.name = t.name, f.x = t.x, f.y = o;
    let O = f.width / 3, L = f.width / 3, k = O / 2, A = k / (2.5 + O / 50), D = g.append("g");
    D.attr("class", I);
    let M = `
  M ${f.x},${f.y + A}
  a ${k},${A} 0 0 0 ${O},0
  a ${k},${A} 0 0 0 -${O},0
  l 0,${L - 2 * A}
  a ${k},${A} 0 0 0 ${O},0
  l 0,-${L - 2 * A}
`;
    D.append("path").attr("d", M), p === "neo" && D.attr("filter", "url(#drop-shadow)");
    let V = i.get(t.name) ?? 0;
    Et.has(u) ? (D.style("stroke", E[V % E.length]), D.style("fill", _[V % E.length])) : D.style("stroke", R), D.attr("transform", `translate(${O}, ${A})`), t.rectData = f, ut(a, Z(t.description))(t.description, g, f.x, f.y + 35, f.width, f.height, { class: `actor ${Gt}` }, a);
    let W = D.select("path:last-child");
    if (W.node()) {
        let U = W.node().getBBox();
        t.height = U.height + (a.sequence.labelBoxHeight ?? 0);
    }
    return r || (g.attr("data-et", "participant"), g.attr("data-type", "database"), g.attr("data-id", t.name)), t.height;
}, "drawActorTypeDatabase"), Br = x(function (e, t, a, r, i) { let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + 80, u = 22, d = e.append("g").lower(), { look: p, theme: _, themeVariables: E } = a, { bkgColorArray: R, borderColorArray: T, actorBorder: g } = E; r || (B++, d.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = B); let f = e.append("g"), I = yt; r ? I += ` ${gt}` : I += ` ${_t}`, f.attr("class", I), f.attr("name", t.name); let O = dt(); O.x = t.x, O.y = o, O.fill = "#eaeaea", O.width = t.width, O.height = t.height, O.class = "actor", f.append("line").attr("id", "actor-man-torso" + B).attr("x1", t.x + t.width / 2 - u * 2.5).attr("y1", o + 12).attr("x2", t.x + t.width / 2 - 15).attr("y2", o + 12), f.append("line").attr("id", "actor-man-arms" + B).attr("x1", t.x + t.width / 2 - u * 2.5).attr("y1", o + 2).attr("x2", t.x + t.width / 2 - u * 2.5).attr("y2", o + 22), f.append("circle").attr("cx", t.x + t.width / 2).attr("cy", o + 12).attr("r", u), p === "neo" && f.attr("filter", "url(#drop-shadow)"); let L = i.get(t.name) ?? 0; Et.has(_) ? (f.style("stroke", T[L % T.length]), f.style("fill", R[L % T.length])) : f.style("stroke", g); let k = f.node().getBBox(); return t.height = k.height + (a.sequence.labelBoxHeight ?? 0), ut(a, Z(t.description))(t.description, f, O.x, O.y + 15, O.width, O.height, { class: `actor ${yt}` }, a), f.attr("transform", `translate(0,${u / 2 + 10})`), r || (f.attr("data-et", "participant"), f.attr("data-type", "boundary"), f.attr("data-id", t.name)), t.height; }, "drawActorTypeBoundary"), Vr = x(function (e, t, a, r, i) { let o = r ? t.stopy : t.starty, s = t.x + t.width / 2, c = o + 80, { look: u, theme: d, themeVariables: p } = a, { bkgColorArray: _, borderColorArray: E, actorBorder: R } = p, T = e.append("g").lower(); r || (B++, T.append("line").attr("id", "actor" + B).attr("x1", s).attr("y1", c).attr("x2", s).attr("y2", 2e3).attr("class", "actor-line 200").attr("stroke-width", "0.5px").attr("stroke", "#999").attr("name", t.name).attr("data-et", "life-line").attr("data-id", t.name), t.actorCnt = B); let g = e.append("g"), f = yt; r ? f += ` ${gt}` : f += ` ${_t}`, g.attr("class", f), g.attr("name", t.name), r || g.attr("data-et", "participant").attr("data-type", "actor").attr("data-id", t.name); let I = u === "neo" ? .5 : 1, O = u === "neo" ? o + (1 - I) * 30 : o; g.append("line").attr("id", "actor-man-torso" + B).attr("x1", s).attr("y1", O + 25 * I).attr("x2", s).attr("y2", O + 45 * I), g.append("line").attr("id", "actor-man-arms" + B).attr("x1", s - bt / 2 * I).attr("y1", O + 33 * I).attr("x2", s + bt / 2 * I).attr("y2", O + 33 * I), g.append("line").attr("x1", s - bt / 2 * I).attr("y1", O + 60 * I).attr("x2", s).attr("y2", O + 45 * I), g.append("line").attr("x1", s).attr("y1", O + 45 * I).attr("x2", s + (bt / 2 - 2) * I).attr("y2", O + 60 * I); let L = g.append("circle"); L.attr("cx", t.x + t.width / 2), L.attr("cy", O + 10 * I), L.attr("r", 15 * I), L.attr("width", t.width * I), L.attr("height", t.height * I); let k = g.node().getBBox(); t.height = k.height; let A = dt(); A.x = t.x, A.y = O, A.fill = "#eaeaea", A.width = t.width, A.height = t.height / I, A.class = "actor", A.rx = 3, A.ry = 3; let D = i.get(t.name) ?? 0; return Et.has(d) ? (g.style("stroke", E[D % E.length]), g.style("fill", _[D % E.length])) : g.style("stroke", R), ut(a, Z(t.description))(t.description, g, A.x, O + 35 * I - (u === "neo" ? 10 : 0), A.width, A.height, { class: `actor ${yt}` }, a), t.height; }, "drawActorTypeActor"), Yr = x(function (e, t, a, r, i, o, s) { return st(this, null, function* () { let c = s ?? new Map([...o.db.getActors().values()].map((u, d) => [u.name, d])); switch (t.type) {
    case "actor": return yield Vr(e, t, a, r, c);
    case "participant": return yield wr(e, t, a, r, c);
    case "boundary": return yield Br(e, t, a, r, c);
    case "control": return yield vr(e, t, a, r, i, c);
    case "entity": return yield Cr(e, t, a, r, c);
    case "database": return yield Mr(e, t, a, r, c);
    case "collections": return yield Pr(e, t, a, r, c);
    case "queue": return yield Dr(e, t, a, r, c);
} }); }, "drawActor"), Wr = x(function (e, t, a) { let i = e.append("g"); or(i, t), t.name && ut(a)(t.name, i, t.x, t.y + a.boxTextMargin + (t.textMaxHeight || 0) / 2, t.width, 0, { class: "text" }, a), i.lower(); }, "drawBox"), Kr = x(function (e) { return e.append("g"); }, "anchorElement"), Fr = x(function (e, t, a, r, i, o, s) { let { theme: c, themeVariables: u } = r, { bkgColorArray: d, borderColorArray: p, mainBkg: _ } = u, E = dt(), R = t.anchored, T = t.actor; E.x = t.startx, E.y = t.starty, E.class = "activation" + i % 3, E.width = t.stopx - t.startx, E.height = a - t.starty; let g = Ct(R, E), I = (s ?? new Map([...o.db.getActors().values()].map((O, L) => [O.name, L]))).get(T) ?? 0; Et.has(c) && (g.style("stroke", p[I % p.length]), g.style("fill", d[I % p.length] ?? _)); }, "drawActivation"), qr = x(function (e, t, a, r, i) { return st(this, null, function* () { let { boxMargin: o, boxTextMargin: s, labelBoxHeight: c, labelBoxWidth: u, messageFontFamily: d, messageFontSize: p, messageFontWeight: _ } = r, E = e.append("g").attr("data-et", "control-structure").attr("data-id", "i" + i.id), R = x(function (f, I, O, L) { return E.append("line").attr("x1", f).attr("y1", I).attr("x2", O).attr("y2", L).attr("class", "loopLine"); }, "drawLoopLine"); R(t.startx, t.starty, t.stopx, t.starty), R(t.stopx, t.starty, t.stopx, t.stopy), R(t.startx, t.stopy, t.stopx, t.stopy), R(t.startx, t.starty, t.startx, t.stopy), t.sections !== void 0 && t.sections.forEach(function (f) { R(t.startx, f.y, t.stopx, f.y).style("stroke-dasharray", "3, 3"); }); let T = Ht(); T.text = a, T.x = t.startx, T.y = t.starty, T.fontFamily = d, T.fontSize = p, T.fontWeight = _, T.anchor = "middle", T.valign = "middle", T.tspan = !1, T.width = Math.max(u ?? 0, 50), T.height = c + (r.look === "neo" ? 15 : 0) || 20, T.textMargin = s, T.class = "labelText", ir(E, T), T = cr(), T.text = t.title, T.x = t.startx + u / 2 + (t.stopx - t.startx) / 2, T.y = t.starty + o + s, T.anchor = "middle", T.valign = "middle", T.textMargin = s, T.class = "loopText", T.fontFamily = d, T.fontSize = p, T.fontWeight = _, T.wrap = !0; let g = Z(T.text) ? yield Ut(E, T, t) : St(E, T); if (t.sectionTitles !== void 0) {
    for (let [f, I] of Object.entries(t.sectionTitles))
        if (I.message) {
            T.text = I.message, T.x = t.startx + (t.stopx - t.startx) / 2, T.y = t.sections[f].y + o + s, T.class = "sectionTitle", T.anchor = "middle", T.valign = "middle", T.tspan = !1, T.fontFamily = d, T.fontSize = p, T.fontWeight = _, T.wrap = t.wrap, Z(T.text) ? (t.starty = t.sections[f].y, yield Ut(E, T, t)) : St(E, T);
            let O = Math.round(g.map(L => (L._groups || L)[0][0].getBBox().height).reduce((L, k) => L + k));
            t.sections[f].height += O - (o + s);
        }
} return t.height = Math.round(t.stopy - t.starty), E; }); }, "drawLoop"), or = x(function (e, t) { er(e, t); }, "drawBackgroundRect"), Hr = x(function (e, t) { e.append("defs").append("symbol").attr("id", t + "-database").attr("fill-rule", "evenodd").attr("clip-rule", "evenodd").append("path").attr("transform", "scale(.5)").attr("d", "M12.258.001l.256.004.255.005.253.008.251.01.249.012.247.015.246.016.242.019.241.02.239.023.236.024.233.027.231.028.229.031.225.032.223.034.22.036.217.038.214.04.211.041.208.043.205.045.201.046.198.048.194.05.191.051.187.053.183.054.18.056.175.057.172.059.168.06.163.061.16.063.155.064.15.066.074.033.073.033.071.034.07.034.069.035.068.035.067.035.066.035.064.036.064.036.062.036.06.036.06.037.058.037.058.037.055.038.055.038.053.038.052.038.051.039.05.039.048.039.047.039.045.04.044.04.043.04.041.04.04.041.039.041.037.041.036.041.034.041.033.042.032.042.03.042.029.042.027.042.026.043.024.043.023.043.021.043.02.043.018.044.017.043.015.044.013.044.012.044.011.045.009.044.007.045.006.045.004.045.002.045.001.045v17l-.001.045-.002.045-.004.045-.006.045-.007.045-.009.044-.011.045-.012.044-.013.044-.015.044-.017.043-.018.044-.02.043-.021.043-.023.043-.024.043-.026.043-.027.042-.029.042-.03.042-.032.042-.033.042-.034.041-.036.041-.037.041-.039.041-.04.041-.041.04-.043.04-.044.04-.045.04-.047.039-.048.039-.05.039-.051.039-.052.038-.053.038-.055.038-.055.038-.058.037-.058.037-.06.037-.06.036-.062.036-.064.036-.064.036-.066.035-.067.035-.068.035-.069.035-.07.034-.071.034-.073.033-.074.033-.15.066-.155.064-.16.063-.163.061-.168.06-.172.059-.175.057-.18.056-.183.054-.187.053-.191.051-.194.05-.198.048-.201.046-.205.045-.208.043-.211.041-.214.04-.217.038-.22.036-.223.034-.225.032-.229.031-.231.028-.233.027-.236.024-.239.023-.241.02-.242.019-.246.016-.247.015-.249.012-.251.01-.253.008-.255.005-.256.004-.258.001-.258-.001-.256-.004-.255-.005-.253-.008-.251-.01-.249-.012-.247-.015-.245-.016-.243-.019-.241-.02-.238-.023-.236-.024-.234-.027-.231-.028-.228-.031-.226-.032-.223-.034-.22-.036-.217-.038-.214-.04-.211-.041-.208-.043-.204-.045-.201-.046-.198-.048-.195-.05-.19-.051-.187-.053-.184-.054-.179-.056-.176-.057-.172-.059-.167-.06-.164-.061-.159-.063-.155-.064-.151-.066-.074-.033-.072-.033-.072-.034-.07-.034-.069-.035-.068-.035-.067-.035-.066-.035-.064-.036-.063-.036-.062-.036-.061-.036-.06-.037-.058-.037-.057-.037-.056-.038-.055-.038-.053-.038-.052-.038-.051-.039-.049-.039-.049-.039-.046-.039-.046-.04-.044-.04-.043-.04-.041-.04-.04-.041-.039-.041-.037-.041-.036-.041-.034-.041-.033-.042-.032-.042-.03-.042-.029-.042-.027-.042-.026-.043-.024-.043-.023-.043-.021-.043-.02-.043-.018-.044-.017-.043-.015-.044-.013-.044-.012-.044-.011-.045-.009-.044-.007-.045-.006-.045-.004-.045-.002-.045-.001-.045v-17l.001-.045.002-.045.004-.045.006-.045.007-.045.009-.044.011-.045.012-.044.013-.044.015-.044.017-.043.018-.044.02-.043.021-.043.023-.043.024-.043.026-.043.027-.042.029-.042.03-.042.032-.042.033-.042.034-.041.036-.041.037-.041.039-.041.04-.041.041-.04.043-.04.044-.04.046-.04.046-.039.049-.039.049-.039.051-.039.052-.038.053-.038.055-.038.056-.038.057-.037.058-.037.06-.037.061-.036.062-.036.063-.036.064-.036.066-.035.067-.035.068-.035.069-.035.07-.034.072-.034.072-.033.074-.033.151-.066.155-.064.159-.063.164-.061.167-.06.172-.059.176-.057.179-.056.184-.054.187-.053.19-.051.195-.05.198-.048.201-.046.204-.045.208-.043.211-.041.214-.04.217-.038.22-.036.223-.034.226-.032.228-.031.231-.028.234-.027.236-.024.238-.023.241-.02.243-.019.245-.016.247-.015.249-.012.251-.01.253-.008.255-.005.256-.004.258-.001.258.001zm-9.258 20.499v.01l.001.021.003.021.004.022.005.021.006.022.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.023.018.024.019.024.021.024.022.025.023.024.024.025.052.049.056.05.061.051.066.051.07.051.075.051.079.052.084.052.088.052.092.052.097.052.102.051.105.052.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.048.144.049.147.047.152.047.155.047.16.045.163.045.167.043.171.043.176.041.178.041.183.039.187.039.19.037.194.035.197.035.202.033.204.031.209.03.212.029.216.027.219.025.222.024.226.021.23.02.233.018.236.016.24.015.243.012.246.01.249.008.253.005.256.004.259.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.021.224-.024.22-.026.216-.027.212-.028.21-.031.205-.031.202-.034.198-.034.194-.036.191-.037.187-.039.183-.04.179-.04.175-.042.172-.043.168-.044.163-.045.16-.046.155-.046.152-.047.148-.048.143-.049.139-.049.136-.05.131-.05.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.053.083-.051.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.05.023-.024.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.023.01-.022.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.127l-.077.055-.08.053-.083.054-.085.053-.087.052-.09.052-.093.051-.095.05-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.045-.118.044-.12.043-.122.042-.124.042-.126.041-.128.04-.13.04-.132.038-.134.038-.135.037-.138.037-.139.035-.142.035-.143.034-.144.033-.147.032-.148.031-.15.03-.151.03-.153.029-.154.027-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.01-.179.008-.179.008-.181.006-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.006-.179-.008-.179-.008-.178-.01-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.027-.153-.029-.151-.03-.15-.03-.148-.031-.146-.032-.145-.033-.143-.034-.141-.035-.14-.035-.137-.037-.136-.037-.134-.038-.132-.038-.13-.04-.128-.04-.126-.041-.124-.042-.122-.042-.12-.044-.117-.043-.116-.045-.113-.045-.112-.046-.109-.047-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.05-.093-.052-.09-.051-.087-.052-.085-.053-.083-.054-.08-.054-.077-.054v4.127zm0-5.654v.011l.001.021.003.021.004.021.005.022.006.022.007.022.009.022.01.022.011.023.012.023.013.023.015.024.016.023.017.024.018.024.019.024.021.024.022.024.023.025.024.024.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.052.11.051.114.051.119.052.123.05.127.051.131.05.135.049.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.044.171.042.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.022.23.02.233.018.236.016.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.012.241-.015.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.048.139-.05.136-.049.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.051.051-.049.023-.025.023-.024.021-.025.02-.024.019-.024.018-.024.017-.024.015-.023.014-.023.013-.024.012-.022.01-.023.01-.023.008-.022.006-.022.006-.022.004-.021.004-.022.001-.021.001-.021v-4.139l-.077.054-.08.054-.083.054-.085.052-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.044-.118.044-.12.044-.122.042-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.035-.143.033-.144.033-.147.033-.148.031-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.009-.179.009-.179.007-.181.007-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.007-.179-.007-.179-.009-.178-.009-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.031-.146-.033-.145-.033-.143-.033-.141-.035-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.04-.126-.041-.124-.042-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.051-.093-.051-.09-.051-.087-.053-.085-.052-.083-.054-.08-.054-.077-.054v4.139zm0-5.666v.011l.001.02.003.022.004.021.005.022.006.021.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.024.018.023.019.024.021.025.022.024.023.024.024.025.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.051.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.043.171.043.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.021.23.02.233.018.236.017.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.013.241-.014.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.049.139-.049.136-.049.131-.051.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.049.023-.025.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.022.01-.023.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.153l-.077.054-.08.054-.083.053-.085.053-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.048-.105.048-.106.048-.109.046-.111.046-.114.046-.115.044-.118.044-.12.043-.122.043-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.034-.143.034-.144.033-.147.032-.148.032-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.024-.161.024-.162.023-.163.023-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.01-.178.01-.179.009-.179.007-.181.006-.182.006-.182.004-.184.003-.184.001-.185.001-.185-.001-.184-.001-.184-.003-.182-.004-.182-.006-.181-.006-.179-.007-.179-.009-.178-.01-.176-.01-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.023-.162-.023-.161-.024-.159-.024-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.032-.146-.032-.145-.033-.143-.034-.141-.034-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.041-.126-.041-.124-.041-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.048-.105-.048-.102-.048-.1-.05-.097-.049-.095-.051-.093-.051-.09-.052-.087-.052-.085-.053-.083-.053-.08-.054-.077-.054v4.153zm8.74-8.179l-.257.004-.254.005-.25.008-.247.011-.244.012-.241.014-.237.016-.233.018-.231.021-.226.022-.224.023-.22.026-.216.027-.212.028-.21.031-.205.032-.202.033-.198.034-.194.036-.191.038-.187.038-.183.04-.179.041-.175.042-.172.043-.168.043-.163.045-.16.046-.155.046-.152.048-.148.048-.143.048-.139.049-.136.05-.131.05-.126.051-.123.051-.118.051-.114.052-.11.052-.106.052-.101.052-.096.052-.092.052-.088.052-.083.052-.079.052-.074.051-.07.052-.065.051-.06.05-.056.05-.051.05-.023.025-.023.024-.021.024-.02.025-.019.024-.018.024-.017.023-.015.024-.014.023-.013.023-.012.023-.01.023-.01.022-.008.022-.006.023-.006.021-.004.022-.004.021-.001.021-.001.021.001.021.001.021.004.021.004.022.006.021.006.023.008.022.01.022.01.023.012.023.013.023.014.023.015.024.017.023.018.024.019.024.02.025.021.024.023.024.023.025.051.05.056.05.06.05.065.051.07.052.074.051.079.052.083.052.088.052.092.052.096.052.101.052.106.052.11.052.114.052.118.051.123.051.126.051.131.05.136.05.139.049.143.048.148.048.152.048.155.046.16.046.163.045.168.043.172.043.175.042.179.041.183.04.187.038.191.038.194.036.198.034.202.033.205.032.21.031.212.028.216.027.22.026.224.023.226.022.231.021.233.018.237.016.241.014.244.012.247.011.25.008.254.005.257.004.26.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.022.224-.023.22-.026.216-.027.212-.028.21-.031.205-.032.202-.033.198-.034.194-.036.191-.038.187-.038.183-.04.179-.041.175-.042.172-.043.168-.043.163-.045.16-.046.155-.046.152-.048.148-.048.143-.048.139-.049.136-.05.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.05.051-.05.023-.025.023-.024.021-.024.02-.025.019-.024.018-.024.017-.023.015-.024.014-.023.013-.023.012-.023.01-.023.01-.022.008-.022.006-.023.006-.021.004-.022.004-.021.001-.021.001-.021-.001-.021-.001-.021-.004-.021-.004-.022-.006-.021-.006-.023-.008-.022-.01-.022-.01-.023-.012-.023-.013-.023-.014-.023-.015-.024-.017-.023-.018-.024-.019-.024-.02-.025-.021-.024-.023-.024-.023-.025-.051-.05-.056-.05-.06-.05-.065-.051-.07-.052-.074-.051-.079-.052-.083-.052-.088-.052-.092-.052-.096-.052-.101-.052-.106-.052-.11-.052-.114-.052-.118-.051-.123-.051-.126-.051-.131-.05-.136-.05-.139-.049-.143-.048-.148-.048-.152-.048-.155-.046-.16-.046-.163-.045-.168-.043-.172-.043-.175-.042-.179-.041-.183-.04-.187-.038-.191-.038-.194-.036-.198-.034-.202-.033-.205-.032-.21-.031-.212-.028-.216-.027-.22-.026-.224-.023-.226-.022-.231-.021-.233-.018-.237-.016-.241-.014-.244-.012-.247-.011-.25-.008-.254-.005-.257-.004-.26-.001-.26.001z"); }, "insertDatabaseIcon"), zr = x(function (e, t) { e.append("defs").append("symbol").attr("id", t + "-computer").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M2 2v13h20v-13h-20zm18 11h-16v-9h16v9zm-10.228 6l.466-1h3.524l.467 1h-4.457zm14.228 3h-24l2-6h2.104l-1.33 4h18.45l-1.297-4h2.073l2 6zm-5-10h-14v-7h14v7z"); }, "insertComputerIcon"), Ur = x(function (e, t) { e.append("defs").append("symbol").attr("id", t + "-clock").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.848 12.459c.202.038.202.333.001.372-1.907.361-6.045 1.111-6.547 1.111-.719 0-1.301-.582-1.301-1.301 0-.512.77-5.447 1.125-7.445.034-.192.312-.181.343.014l.985 6.238 5.394 1.011z"); }, "insertClockIcon"), Gr = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-arrowhead").attr("refX", 7.9).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M -1 0 L 10 5 L 0 10 z"); }, "insertArrowHead"), Xr = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-filled-head").attr("refX", 15.5).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z"); }, "insertArrowFilledHead"), Jr = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-sequencenumber").attr("refX", 15).attr("refY", 15).attr("markerWidth", 60).attr("markerHeight", 40).attr("orient", "auto").append("circle").attr("cx", 15).attr("cy", 15).attr("r", 6); }, "insertSequenceNumber"), Qr = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-crosshead").attr("markerWidth", 15).attr("markerHeight", 8).attr("orient", "auto").attr("refX", 4).attr("refY", 4.5).append("path").attr("fill", "none").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1pt").attr("d", "M 1,2 L 6,7 M 6,2 L 1,7"); }, "insertArrowCrossHead"), Zr = x(function (e, t) { let { theme: a } = t; e.append("defs").append("filter").attr("id", "drop-shadow").attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${a === "redux" || a === "redux-color" ? "#000000" : "#FFFFFF"}`); }, "insertDropShadow"), cr = x(function () { return { x: 0, y: 0, fill: void 0, anchor: void 0, style: "#666", width: void 0, height: void 0, textMargin: 0, rx: 0, ry: 0, tspan: !0, valign: void 0 }; }, "getTextObj"), $r = x(function () { return { x: 0, y: 0, fill: "#EDF2AE", stroke: "#666", width: 100, anchor: "start", height: 100, rx: 0, ry: 0 }; }, "getNoteRect"), ut = (function () { function e(o, s, c, u, d, p, _) { let E = s.append("text").attr("x", c + d / 2).attr("y", u + p / 2 + 5).style("text-anchor", "middle").text(o); i(E, _); } x(e, "byText"); function t(o, s, c, u, d, p, _, E) { let { actorFontSize: R, actorFontFamily: T, actorFontWeight: g } = E, [f, I] = ne(R), O = o.split(N.lineBreakRegex); for (let L = 0; L < O.length; L++) {
    let k = L * f - f * (O.length - 1) / 2, A = s.append("text").attr("x", c + d / 2).attr("y", u).style("text-anchor", "middle").style("font-size", I).style("font-weight", g).style("font-family", T);
    A.append("tspan").attr("x", c + d / 2).attr("dy", k).text(O[L]), A.attr("y", u + p / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), i(A, _);
} } x(t, "byTspan"); function a(o, s, c, u, d, p, _, E) { let R = s.append("switch"), g = R.append("foreignObject").attr("x", c).attr("y", u).attr("width", d).attr("height", p).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%"); g.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(o), t(o, R, c, u, d, p, _, E), i(g, _); } x(a, "byFo"); function r(o, s, c, u, d, p, _, E) { return st(this, null, function* () { let R = yield mt(o, Pt()), T = s.append("switch"), f = T.append("foreignObject").attr("x", c + d / 2 - R.width / 2).attr("y", u + p / 2 - R.height / 2).attr("width", R.width).attr("height", R.height).append("xhtml:div").style("height", "100%").style("width", "100%"); f.append("div").style("text-align", "center").style("vertical-align", "middle").html(yield se(o, Pt())), t(o, T, c, u, d, p, _, E), i(f, _); }); } x(r, "byKatex"); function i(o, s) { for (let c in s)
    s.hasOwnProperty(c) && o.attr(c, s[c]); } return x(i, "_setTextAttrs"), function (o, s = !1) { return s ? r : o.textPlacement === "fo" ? a : o.textPlacement === "old" ? e : t; }; })(), jr = (function () { function e(i, o, s, c, u, d, p) { let _ = o.append("text").attr("x", s).attr("y", c).style("text-anchor", "start").text(i); r(_, p); } x(e, "byText"); function t(i, o, s, c, u, d, p, _) { let { actorFontSize: E, actorFontFamily: R, actorFontWeight: T } = _, g = i.split(N.lineBreakRegex); for (let f = 0; f < g.length; f++) {
    let I = f * E - E * (g.length - 1) / 2, O = o.append("text").attr("x", s).attr("y", c).style("text-anchor", "start").style("font-size", E).style("font-weight", T).style("font-family", R);
    O.append("tspan").attr("x", s).attr("dy", I).text(g[f]), O.attr("y", c + d / 2).attr("dominant-baseline", "central").attr("alignment-baseline", "central"), r(O, p);
} } x(t, "byTspan"); function a(i, o, s, c, u, d, p, _) { let E = o.append("switch"), T = E.append("foreignObject").attr("x", s).attr("y", c).attr("width", u).attr("height", d).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%"); T.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(i), t(i, E, s, c, u, d, p, _), r(T, p); } x(a, "byFo"); function r(i, o) { for (let s in o)
    o.hasOwnProperty(s) && i.attr(s, o[s]); } return x(r, "_setTextAttrs"), function (i) { return i.textPlacement === "fo" ? a : i.textPlacement === "old" ? e : t; }; })(), ta = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-solidTopArrowHead").attr("refX", 7.9).attr("refY", 7.25).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 8 L 0 8 z"); }, "insertSolidTopArrowHead"), ea = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-solidBottomArrowHead").attr("refX", 7.9).attr("refY", .75).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 10 0 L 0 8 z"); }, "insertSolidBottomArrowHead"), ra = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-stickTopArrowHead").attr("refX", 7.5).attr("refY", 7).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 0 L 7 7").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none"); }, "insertStickTopArrowHead"), aa = x(function (e, t) { e.append("defs").append("marker").attr("id", t + "-stickBottomArrowHead").attr("refX", 7.5).attr("refY", 0).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto-start-reverse").append("path").attr("d", "M 0 7 L 7 0").attr("stroke", "black").attr("stroke-width", 1.5).attr("fill", "none"); }, "insertStickBottomArrowHead"), H = { drawRect: Ct, drawText: St, drawLabel: ir, drawActor: Yr, drawBox: Wr, drawPopup: Nr, anchorElement: Kr, drawActivation: Fr, drawLoop: qr, drawBackgroundRect: or, insertArrowHead: Gr, insertArrowFilledHead: Xr, insertSequenceNumber: Jr, insertArrowCrossHead: Qr, insertDatabaseIcon: Hr, insertComputerIcon: zr, insertClockIcon: Ur, getTextObj: cr, getNoteRect: $r, fixLifeLineHeights: nr, sanitizeUrl: de.sanitizeUrl, insertDropShadow: Zr, insertSolidTopArrowHead: ta, insertSolidBottomArrowHead: ea, insertStickTopArrowHead: ra, insertStickBottomArrowHead: aa }, l = {}, y = { data: { startx: void 0, stopx: void 0, starty: void 0, stopy: void 0 }, verticalPos: 0, sequenceItems: [], activations: [], models: { getHeight: x(function () { return Math.max.apply(null, this.actors.length === 0 ? [0] : this.actors.map(e => e.height || 0)) + (this.loops.length === 0 ? 0 : this.loops.map(e => e.height || 0).reduce((e, t) => e + t)) + (this.messages.length === 0 ? 0 : this.messages.map(e => e.height || 0).reduce((e, t) => e + t)) + (this.notes.length === 0 ? 0 : this.notes.map(e => e.height || 0).reduce((e, t) => e + t)); }, "getHeight"), clear: x(function () { this.actors = [], this.boxes = [], this.loops = [], this.messages = [], this.notes = []; }, "clear"), addBox: x(function (e) { this.boxes.push(e); }, "addBox"), addActor: x(function (e) { this.actors.push(e); }, "addActor"), addLoop: x(function (e) { this.loops.push(e); }, "addLoop"), addMessage: x(function (e) { this.messages.push(e); }, "addMessage"), addNote: x(function (e) { this.notes.push(e); }, "addNote"), lastActor: x(function () { return this.actors[this.actors.length - 1]; }, "lastActor"), lastLoop: x(function () { return this.loops[this.loops.length - 1]; }, "lastLoop"), lastMessage: x(function () { return this.messages[this.messages.length - 1]; }, "lastMessage"), lastNote: x(function () { return this.notes[this.notes.length - 1]; }, "lastNote"), actors: [], boxes: [], loops: [], messages: [], notes: [] }, init: x(function () { this.sequenceItems = [], this.activations = [], this.models.clear(), this.data = { startx: void 0, stopx: void 0, starty: void 0, stopy: void 0 }, this.verticalPos = 0, dr($()); }, "init"), updateVal: x(function (e, t, a, r) { e[t] === void 0 ? e[t] = a : e[t] = r(a, e[t]); }, "updateVal"), updateBounds: x(function (e, t, a, r) { let i = this, o = 0; function s(c) { return x(function (d) { o++; let p = i.sequenceItems.length - o + 1; i.updateVal(d, "starty", t - p * l.boxMargin, Math.min), i.updateVal(d, "stopy", r + p * l.boxMargin, Math.max), i.updateVal(y.data, "startx", e - p * l.boxMargin, Math.min), i.updateVal(y.data, "stopx", a + p * l.boxMargin, Math.max), c !== "activation" && (i.updateVal(d, "startx", e - p * l.boxMargin, Math.min), i.updateVal(d, "stopx", a + p * l.boxMargin, Math.max), i.updateVal(y.data, "starty", t - p * l.boxMargin, Math.min), i.updateVal(y.data, "stopy", r + p * l.boxMargin, Math.max)); }, "updateItemBounds"); } x(s, "updateFn"), this.sequenceItems.forEach(s()), this.activations.forEach(s("activation")); }, "updateBounds"), insert: x(function (e, t, a, r) { let i = N.getMin(e, a), o = N.getMax(e, a), s = N.getMin(t, r), c = N.getMax(t, r); this.updateVal(y.data, "startx", i, Math.min), this.updateVal(y.data, "starty", s, Math.min), this.updateVal(y.data, "stopx", o, Math.max), this.updateVal(y.data, "stopy", c, Math.max), this.updateBounds(i, s, o, c); }, "insert"), newActivation: x(function (e, t, a) { let r = a.get(e.from), i = Jt(e.from).length || 0, o = r.x + r.width / 2 + (i - 1) * l.activationWidth / 2; this.activations.push({ startx: o, starty: this.verticalPos + 2, stopx: o + l.activationWidth, stopy: void 0, actor: e.from, anchored: H.anchorElement(t) }); }, "newActivation"), endActivation: x(function (e) { let t = this.activations.map(function (a) { return a.actor; }).lastIndexOf(e.from); return this.activations.splice(t, 1)[0]; }, "endActivation"), createLoop: x(function (e = { message: void 0, wrap: !1, width: void 0 }, t) { return { startx: void 0, starty: this.verticalPos, stopx: void 0, stopy: void 0, title: e.message, wrap: e.wrap, width: e.width, height: 0, fill: t }; }, "createLoop"), newLoop: x(function (e = { message: void 0, wrap: !1, width: void 0 }, t) { this.sequenceItems.push(this.createLoop(e, t)); }, "newLoop"), endLoop: x(function () { return this.sequenceItems.pop(); }, "endLoop"), isLoopOverlap: x(function () { return this.sequenceItems.length ? this.sequenceItems[this.sequenceItems.length - 1].overlap : !1; }, "isLoopOverlap"), addSectionToLoop: x(function (e) { let t = this.sequenceItems.pop(); t.sections = t.sections || [], t.sectionTitles = t.sectionTitles || [], t.sections.push({ y: y.getVerticalPos(), height: 0 }), t.sectionTitles.push(e), this.sequenceItems.push(t); }, "addSectionToLoop"), saveVerticalPos: x(function () { this.isLoopOverlap() && (this.savedVerticalPos = this.verticalPos); }, "saveVerticalPos"), resetVerticalPos: x(function () { this.isLoopOverlap() && (this.verticalPos = this.savedVerticalPos); }, "resetVerticalPos"), bumpVerticalPos: x(function (e) { this.verticalPos = this.verticalPos + e, this.data.stopy = N.getMax(this.data.stopy, this.verticalPos); }, "bumpVerticalPos"), getVerticalPos: x(function () { return this.verticalPos; }, "getVerticalPos"), getBounds: x(function () { return { bounds: this.data, models: this.models }; }, "getBounds") }, sa = x(function (e, t, a) { return st(this, null, function* () { y.bumpVerticalPos(l.boxMargin), t.height = l.boxMargin, t.starty = y.getVerticalPos(); let r = dt(); r.x = t.startx, r.y = t.starty, r.width = t.width || l.width, r.class = "note"; let i = e.append("g"); i.attr("data-et", "note"), i.attr("data-id", "i" + a); let o = H.drawRect(i, r), s = Ht(); s.x = t.startx, s.y = t.starty, s.width = r.width, s.dy = "1em", s.text = t.message, s.class = "noteText", s.fontFamily = l.noteFontFamily, s.fontSize = l.noteFontSize, s.fontWeight = l.noteFontWeight, s.anchor = l.noteAlign, s.textMargin = l.noteMargin, s.valign = "center"; let c = Z(s.text) ? yield Ut(i, s) : St(i, s), u = Math.round(c.map(d => (d._groups || d)[0][0].getBBox().height).reduce((d, p) => d + p)); o.attr("height", u + 2 * l.noteMargin), t.height += u + 2 * l.noteMargin, y.bumpVerticalPos(u + 2 * l.noteMargin), t.stopy = t.starty + u + 2 * l.noteMargin, t.stopx = t.startx + r.width, y.insert(t.startx, t.starty, t.stopx, t.stopy), y.models.addNote(t); }); }, "drawNote"), ar = x(function (e, t, a, r, i, o, s) { let c = r.db.getActors(), u = c.get(t.from), d = c.get(t.to), p = a.sequenceVisible, _ = u.x + u.width / 2, E = d.x + d.width / 2, R = _ <= E, T = ur(t, r), g = e.append("g"), f = 16.5, I = x((D, M) => { let V = D ? f : -f; return M ? -V : V; }, "getCircleOffset"), O = x(D => { g.append("circle").attr("cx", D).attr("cy", s).attr("r", 5).attr("width", 10).attr("height", 10); }, "drawCircle"), { CENTRAL_CONNECTION: L, CENTRAL_CONNECTION_REVERSE: k, CENTRAL_CONNECTION_DUAL: A } = r.db.LINETYPE; if (p)
    switch (t.centralConnection) {
        case L:
            T && (E += I(R, !0));
            break;
        case k:
            T || (_ += I(R, !1));
            break;
        case A:
            T ? E += I(R, !0) : _ += I(R, !1);
            break;
    } switch (t.centralConnection) {
    case L:
        O(E);
        break;
    case k:
        O(_);
        break;
    case A:
        O(_), O(E);
        break;
} }, "drawCentralConnection"), Rt = x(e => ({ fontFamily: e.messageFontFamily, fontSize: e.messageFontSize, fontWeight: e.messageFontWeight }), "messageFont"), At = x(e => ({ fontFamily: e.noteFontFamily, fontSize: e.noteFontSize, fontWeight: e.noteFontWeight }), "noteFont"), le = x(e => ({ fontFamily: e.actorFontFamily, fontSize: e.actorFontSize, fontWeight: e.actorFontWeight }), "actorFont");
function lr(e, t) { return st(this, null, function* () { y.bumpVerticalPos(10); let { startx: a, stopx: r, message: i } = t, o = N.splitBreaks(i).length, s = Z(i), c = s ? yield mt(i, $()) : X.calculateTextDimensions(i, Rt(l)); if (!s) {
    let _ = c.height / o;
    t.height += _, y.bumpVerticalPos(_);
} let u, d = c.height - 10, p = c.width; if (a === r) {
    u = y.getVerticalPos() + d, l.rightAngles || (d += l.boxMargin, u = y.getVerticalPos() + d), d += 30;
    let _ = N.getMax(p / 2, l.width / 2);
    y.insert(a - _, y.getVerticalPos() - 10 + d, r + _, y.getVerticalPos() + 30 + d);
}
else
    d += l.boxMargin, u = y.getVerticalPos() + d, y.insert(a, u - 10, r, u); return y.bumpVerticalPos(d), t.height += d, t.stopy = t.starty + t.height, y.insert(t.fromBounds, t.starty, t.toBounds, t.stopy), u; }); }
x(lr, "boundMessage");
var ia = x(function (e, t, a, r, i, o) { return st(this, null, function* () { let { startx: s, stopx: c, starty: u, message: d, type: p, sequenceIndex: _, sequenceVisible: E } = t, R = X.calculateTextDimensions(d, Rt(l)), T = Ht(); T.x = Math.min(s, c), T.y = u + 10, T.width = Math.abs(c - s), T.class = "messageText", T.dy = "1em", T.text = d, T.fontFamily = l.messageFontFamily, T.fontSize = l.messageFontSize, T.fontWeight = l.messageFontWeight, T.anchor = l.messageAlign, T.valign = "center", T.textMargin = l.wrapPadding, T.tspan = !1, Z(T.text) ? yield Ut(e, T, { startx: s, stopx: c, starty: a }) : St(e, T); let g = R.width, f; if (s === c) {
    let O = E || l.showSequenceNumbers, L = ur(i, r), k = pa(i, r), A = s + (O && (L || k) ? 10 : 0);
    l.rightAngles ? f = e.append("path").attr("d", `M  ${A},${a} H ${s + N.getMax(l.width / 2, g / 2)} V ${a + 25} H ${s}`) : f = e.append("path").attr("d", "M " + A + "," + a + " C " + (A + 60) + "," + (a - 10) + " " + (s + 60) + "," + (a + 30) + " " + s + "," + (a + 20)), oe(i, r) && ar(e, i, t, r, s, c, a);
}
else
    f = e.append("line"), f.attr("x1", s), f.attr("y1", a), f.attr("x2", c), f.attr("y2", a), oe(i, r) && ar(e, i, t, r, s, c, a); p === r.db.LINETYPE.DOTTED || p === r.db.LINETYPE.DOTTED_CROSS || p === r.db.LINETYPE.DOTTED_POINT || p === r.db.LINETYPE.DOTTED_OPEN || p === r.db.LINETYPE.BIDIRECTIONAL_DOTTED || p === r.db.LINETYPE.SOLID_TOP_DOTTED || p === r.db.LINETYPE.SOLID_BOTTOM_DOTTED || p === r.db.LINETYPE.STICK_TOP_DOTTED || p === r.db.LINETYPE.STICK_BOTTOM_DOTTED || p === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || p === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || p === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || p === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED ? (f.style("stroke-dasharray", "3, 3"), f.attr("class", "messageLine1")) : f.attr("class", "messageLine0"), f.attr("data-et", "message"), f.attr("data-id", "i" + t.id), f.attr("data-from", t.from), f.attr("data-to", t.to); let I = ""; if (l.arrowMarkerAbsolute && (I = Fe(!0)), f.attr("stroke-width", 2), f.attr("stroke", "none"), f.style("fill", "none"), (p === r.db.LINETYPE.SOLID_TOP || p === r.db.LINETYPE.SOLID_TOP_DOTTED) && f.attr("marker-end", "url(" + I + "#" + o + "-solidTopArrowHead)"), (p === r.db.LINETYPE.SOLID_BOTTOM || p === r.db.LINETYPE.SOLID_BOTTOM_DOTTED) && f.attr("marker-end", "url(" + I + "#" + o + "-solidBottomArrowHead)"), (p === r.db.LINETYPE.STICK_TOP || p === r.db.LINETYPE.STICK_TOP_DOTTED) && f.attr("marker-end", "url(" + I + "#" + o + "-stickTopArrowHead)"), (p === r.db.LINETYPE.STICK_BOTTOM || p === r.db.LINETYPE.STICK_BOTTOM_DOTTED) && f.attr("marker-end", "url(" + I + "#" + o + "-stickBottomArrowHead)"), (p === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || p === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED) && f.attr("marker-start", "url(" + I + "#" + o + "-solidBottomArrowHead)"), (p === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || p === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED) && f.attr("marker-start", "url(" + I + "#" + o + "-solidTopArrowHead)"), (p === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE || p === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED) && f.attr("marker-start", "url(" + I + "#" + o + "-stickBottomArrowHead)"), (p === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || p === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED) && f.attr("marker-start", "url(" + I + "#" + o + "-stickTopArrowHead)"), (p === r.db.LINETYPE.SOLID || p === r.db.LINETYPE.DOTTED) && f.attr("marker-end", "url(" + I + "#" + o + "-arrowhead)"), (p === r.db.LINETYPE.BIDIRECTIONAL_SOLID || p === r.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (f.attr("marker-start", "url(" + I + "#" + o + "-arrowhead)"), f.attr("marker-end", "url(" + I + "#" + o + "-arrowhead)")), (p === r.db.LINETYPE.SOLID_POINT || p === r.db.LINETYPE.DOTTED_POINT) && f.attr("marker-end", "url(" + I + "#" + o + "-filled-head)"), (p === r.db.LINETYPE.SOLID_CROSS || p === r.db.LINETYPE.DOTTED_CROSS) && f.attr("marker-end", "url(" + I + "#" + o + "-crosshead)"), E || l.showSequenceNumbers) {
    let O = p === r.db.LINETYPE.BIDIRECTIONAL_SOLID || p === r.db.LINETYPE.BIDIRECTIONAL_DOTTED, L = p === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE || p === r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED || p === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE || p === r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED || p === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE || p === r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED || p === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE || p === r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, k = 6, A = oe(i, r), D = s, M = c;
    O ? (s < c ? D = s + k * 2 : (D = s - k + (A ? -5 : 0), D += i?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_DUAL || i?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), f.attr("x1", D)) : L ? (c > s ? M = c - 2 * k : (M = c - k, D += i?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_DUAL || i?.centralConnection === r.db.LINETYPE.CENTRAL_CONNECTION_REVERSE ? -7.5 : 0), M += A ? 15 : 0, f.attr("x2", M), f.attr("x1", D)) : f.attr("x1", s + k);
    let V = 0, W = s === c, U = s <= c;
    W ? V = t.fromBounds + 1 : L ? V = U ? t.toBounds - 1 : t.fromBounds + 1 : V = U ? t.fromBounds + 1 : t.toBounds - 1;
    let G = "12px", J = _.toString().length;
    J > 5 ? G = "7px" : J > 3 && (G = "9px"), e.append("line").attr("x1", V).attr("y1", a).attr("x2", V).attr("y2", a).attr("stroke-width", 0).attr("marker-start", "url(" + I + "#" + o + "-sequencenumber)"), e.append("text").attr("x", V).attr("y", a + 4).attr("font-family", "sans-serif").attr("font-size", G).attr("text-anchor", "middle").attr("class", "sequenceNumber").text(_);
} }); }, "drawMessage"), na = x(function (e, t, a, r, i, o, s) { let c = 0, u = 0, d, p = 0; for (let _ of r) {
    let E = t.get(_), R = E.box;
    d && d != R && (s || y.models.addBox(d), u += l.boxMargin + d.margin), R && R != d && (s || (R.x = c + u, R.y = i), u += R.margin), E.width = N.getMax(E.width || l.width, l.width), E.height = N.getMax(E.height || l.height, l.height), E.margin = E.margin || l.actorMargin, p = N.getMax(p, E.height), a.get(E.name) && (u += E.width / 2), E.x = c + u, E.starty = y.getVerticalPos(), y.insert(E.x, i, E.x + E.width, E.height), c += E.width + u, E.box && (E.box.width = c + R.margin - E.box.x), u = E.margin, d = E.box, y.models.addActor(E);
} d && !s && y.models.addBox(d), y.bumpVerticalPos(p); }, "addActorRenderingData"), he = x(function (e, t, a, r, i, o, s) { return st(this, null, function* () { if (r) {
    let c = 0;
    y.bumpVerticalPos(l.boxMargin * 2);
    for (let u of a) {
        let d = t.get(u);
        d.stopy || (d.stopy = y.getVerticalPos());
        let p = yield H.drawActor(e, d, l, !0, i, o, s);
        c = N.getMax(c, p);
    }
    y.bumpVerticalPos(c + l.boxMargin);
}
else
    for (let c of a) {
        let u = t.get(c);
        yield H.drawActor(e, u, l, !1, i, o, s);
    } }); }, "drawActors"), hr = x(function (e, t, a, r) { let i = 0, o = 0; for (let s of a) {
    let c = t.get(s), u = ca(c), d = H.drawPopup(e, c, u, l, l.forceMenus, r);
    d.height > i && (i = d.height), d.width + c.x > o && (o = d.width + c.x);
} return { maxHeight: i, maxWidth: o }; }, "drawActorsPopup"), dr = x(function (e) { Ke(l, e), e.fontFamily && (l.actorFontFamily = l.noteFontFamily = l.messageFontFamily = e.fontFamily), e.fontSize && (l.actorFontSize = l.noteFontSize = l.messageFontSize = e.fontSize), e.fontWeight && (l.actorFontWeight = l.noteFontWeight = l.messageFontWeight = e.fontWeight); }, "setConf"), Jt = x(function (e) { return y.activations.filter(function (t) { return t.actor === e; }); }, "actorActivations"), sr = x(function (e, t) { let a = t.get(e), r = Jt(e), i = r.reduce(function (s, c) { return N.getMin(s, c.startx); }, a.x + a.width / 2 - 1), o = r.reduce(function (s, c) { return N.getMax(s, c.stopx); }, a.x + a.width / 2 + 1); return [i, o]; }, "activationBounds");
function Tt(e, t, a, r, i) { y.bumpVerticalPos(a); let o = r; if (t.id && t.message && e[t.id]) {
    let s = e[t.id].width, c = Rt(l);
    t.message = X.wrapLabel(`[${t.message}]`, s - 2 * l.wrapPadding, c), t.width = s, t.wrap = !0;
    let u = X.calculateTextDimensions(t.message, c), d = N.getMax(u.height, l.labelBoxHeight);
    o = r + d, tt.debug(`${d} - ${t.message}`);
} i(t), y.bumpVerticalPos(o); }
x(Tt, "adjustLoopHeightForWrap");
function Tr(e, t, a, r, i, o, s) { function c(p, _) { p.x < i.get(e.from).x ? (y.insert(t.stopx - _, t.starty, t.startx, t.stopy + p.height / 2 + l.noteMargin), t.stopx = t.stopx + _) : (y.insert(t.startx, t.starty, t.stopx + _, t.stopy + p.height / 2 + l.noteMargin), t.stopx = t.stopx - _); } x(c, "receiverAdjustment"); function u(p, _) { p.x < i.get(e.to).x ? (y.insert(t.startx - _, t.starty, t.stopx, t.stopy + p.height / 2 + l.noteMargin), t.startx = t.startx + _) : (y.insert(t.stopx, t.starty, t.startx + _, t.stopy + p.height / 2 + l.noteMargin), t.startx = t.startx - _); } x(u, "senderAdjustment"); let d = [zt.ACTOR, zt.CONTROL, zt.ENTITY, zt.DATABASE]; if (o.get(e.to) == r) {
    let p = i.get(e.to), _ = d.includes(p.type) ? bt / 2 + 3 : p.width / 2 + 3;
    c(p, _), p.starty = a - p.height / 2, y.bumpVerticalPos(p.height / 2);
}
else if (s.get(e.from) == r) {
    let p = i.get(e.from);
    if (l.mirrorActors) {
        let _ = d.includes(p.type) ? bt / 2 : p.width / 2;
        u(p, _);
    }
    p.stopy = a - p.height / 2, y.bumpVerticalPos(p.height / 2);
}
else if (s.get(e.to) == r) {
    let p = i.get(e.to);
    if (l.mirrorActors) {
        let _ = d.includes(p.type) ? bt / 2 + 3 : p.width / 2 + 3;
        c(p, _);
    }
    p.stopy = a - p.height / 2, y.bumpVerticalPos(p.height / 2);
} }
x(Tr, "adjustCreatedDestroyedData");
var oa = x(function (e, t, a, r) { return st(this, null, function* () { let { securityLevel: i, sequence: o, look: s, themeVariables: c } = $(); l = o; let u; i === "sandbox" && (u = vt("#i" + t)); let d = i === "sandbox" ? vt(u.nodes()[0].contentDocument.body) : vt("body"), p = i === "sandbox" ? u.nodes()[0].contentDocument : document; y.init(), tt.debug(r.db); let _ = i === "sandbox" ? d.select(`[id="${t}"]`) : vt(`[id="${t}"]`), E = r.db.getActors(), R = r.db.getCreatedActors(), T = r.db.getDestroyedActors(), g = r.db.getBoxes(), f = r.db.getActorKeys(), I = r.db.getMessages(), O = r.db.getDiagramTitle(), L = r.db.hasAtLeastOneBox(), k = r.db.hasAtLeastOneBoxWithTitle(), A = yield pr(E, I, r); if (l.height = yield Er(E, A, g), H.insertComputerIcon(_, t), H.insertDatabaseIcon(_, t), H.insertClockIcon(_, t), L && (y.bumpVerticalPos(l.boxMargin), k && y.bumpVerticalPos(g[0].textMaxHeight)), l.hideUnusedParticipants === !0) {
    let m = new Set;
    I.forEach(P => { m.add(P.from), m.add(P.to); }), f = f.filter(P => m.has(P));
} let D = new Map(f.map((m, P) => [E.get(m)?.name ?? m, P])); na(_, E, R, f, 0, I, !1); let M = yield ua(I, E, A, r); H.insertArrowHead(_, t), H.insertArrowCrossHead(_, t), H.insertArrowFilledHead(_, t), H.insertSequenceNumber(_, t), H.insertSolidTopArrowHead(_, t), H.insertSolidBottomArrowHead(_, t), H.insertStickTopArrowHead(_, t), H.insertStickBottomArrowHead(_, t), s === "neo" && H.insertDropShadow(_, l); function V(m, P) { let ht = y.endActivation(m); ht.starty + 18 > P && (ht.starty = P - 6, P += 12), H.drawActivation(_, ht, P, l, Jt(m.from).length, r, D), y.insert(ht.startx, P - 10, ht.stopx, P); } x(V, "activeEnd"); let W = 1, U = 1, G = [], J = [], ot = 0; for (let m of I) {
    let P, ht, at;
    switch (m.type) {
        case r.db.LINETYPE.NOTE:
            y.resetVerticalPos(), ht = m.noteModel, yield sa(_, ht, m.id);
            break;
        case r.db.LINETYPE.ACTIVE_START:
            y.newActivation(m, _, E);
            break;
        case r.db.LINETYPE.CENTRAL_CONNECTION:
            y.newActivation(m, _, E);
            break;
        case r.db.LINETYPE.CENTRAL_CONNECTION_REVERSE:
            y.newActivation(m, _, E);
            break;
        case r.db.LINETYPE.ACTIVE_END:
            V(m, y.getVerticalPos());
            break;
        case r.db.LINETYPE.LOOP_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K));
            break;
        case r.db.LINETYPE.LOOP_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "loop", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        case r.db.LINETYPE.RECT_START:
            Tt(M, m, l.boxMargin, l.boxMargin, K => { let Ot = K.message; Ot || (Ot = c?.rectBkgColor || c?.actorBkg || "rgba(128, 128, 128, 0.5)"), y.newLoop(void 0, Ot); });
            break;
        case r.db.LINETYPE.RECT_END:
            P = y.endLoop(), J.push(P), y.models.addLoop(P), y.bumpVerticalPos(P.stopy - y.getVerticalPos());
            break;
        case r.db.LINETYPE.OPT_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K));
            break;
        case r.db.LINETYPE.OPT_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "opt", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        case r.db.LINETYPE.ALT_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K));
            break;
        case r.db.LINETYPE.ALT_ELSE:
            Tt(M, m, l.boxMargin + l.boxTextMargin, l.boxMargin, K => y.addSectionToLoop(K));
            break;
        case r.db.LINETYPE.ALT_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "alt", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        case r.db.LINETYPE.PAR_START:
        case r.db.LINETYPE.PAR_OVER_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K)), y.saveVerticalPos();
            break;
        case r.db.LINETYPE.PAR_AND:
            Tt(M, m, l.boxMargin + l.boxTextMargin, l.boxMargin, K => y.addSectionToLoop(K));
            break;
        case r.db.LINETYPE.PAR_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "par", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        case r.db.LINETYPE.AUTONUMBER:
            W = m.message.start || W, U = m.message.step || U, m.message.visible ? r.db.enableSequenceNumbers() : r.db.disableSequenceNumbers();
            break;
        case r.db.LINETYPE.CRITICAL_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K));
            break;
        case r.db.LINETYPE.CRITICAL_OPTION:
            Tt(M, m, l.boxMargin + l.boxTextMargin, l.boxMargin, K => y.addSectionToLoop(K));
            break;
        case r.db.LINETYPE.CRITICAL_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "critical", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        case r.db.LINETYPE.BREAK_START:
            Tt(M, m, l.boxMargin, l.boxMargin + l.boxTextMargin, K => y.newLoop(K));
            break;
        case r.db.LINETYPE.BREAK_END:
            P = y.endLoop(), yield H.drawLoop(_, P, "break", l, m), y.bumpVerticalPos(P.stopy - y.getVerticalPos()), y.models.addLoop(P);
            break;
        default: try {
            at = m.msgModel, at.starty = y.getVerticalPos(), at.sequenceIndex = W, at.sequenceVisible = r.db.showSequenceNumbers(), at.id = m.id, at.from = m.from, at.to = m.to;
            let K = yield lr(_, at);
            Tr(m, at, K, ot, E, R, T), G.push({ messageModel: at, lineStartY: K, msg: m }), y.models.addMessage(at);
        }
        catch (K) {
            tt.error("error while drawing message", K);
        }
    }
    [r.db.LINETYPE.SOLID_OPEN, r.db.LINETYPE.DOTTED_OPEN, r.db.LINETYPE.SOLID, r.db.LINETYPE.SOLID_TOP, r.db.LINETYPE.SOLID_BOTTOM, r.db.LINETYPE.STICK_TOP, r.db.LINETYPE.STICK_BOTTOM, r.db.LINETYPE.SOLID_TOP_DOTTED, r.db.LINETYPE.SOLID_BOTTOM_DOTTED, r.db.LINETYPE.STICK_TOP_DOTTED, r.db.LINETYPE.STICK_BOTTOM_DOTTED, r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE, r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE, r.db.LINETYPE.STICK_ARROW_TOP_REVERSE, r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE, r.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED, r.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED, r.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED, r.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, r.db.LINETYPE.DOTTED, r.db.LINETYPE.SOLID_CROSS, r.db.LINETYPE.DOTTED_CROSS, r.db.LINETYPE.SOLID_POINT, r.db.LINETYPE.DOTTED_POINT, r.db.LINETYPE.BIDIRECTIONAL_SOLID, r.db.LINETYPE.BIDIRECTIONAL_DOTTED].includes(m.type) && (W = Math.round((W + U) * 100) / 100), ot++;
} tt.debug("createdActors", R), tt.debug("destroyedActors", T), yield he(_, E, f, !1, t, r, D); for (let m of G)
    yield ia(_, m.messageModel, m.lineStartY, r, m.msg, t); l.mirrorActors && (yield he(_, E, f, !0, t, r, D)), J.forEach(m => H.drawBackgroundRect(_, m)), nr(_, E, f, l); for (let m of y.models.boxes) {
    m.height = y.getVerticalPos() - m.y, y.insert(m.x, m.y, m.x + m.width, m.height);
    let P = l.boxMargin * 2;
    m.startx = m.x - P, m.starty = m.y - P * .25, m.stopx = m.startx + m.width + 2 * P, m.stopy = m.starty + m.height + P * .75, m.stroke = "rgb(0,0,0, 0.5)", H.drawBox(_, m, l);
} L && y.bumpVerticalPos(l.boxMargin); let et = hr(_, E, f, p), { bounds: z } = y.getBounds(); z.startx === void 0 && (z.startx = 0), z.starty === void 0 && (z.starty = 0), z.stopx === void 0 && (z.stopx = 0), z.stopy === void 0 && (z.stopy = 0); let it = z.stopy - z.starty; it < et.maxHeight && (it = et.maxHeight); let rt = it + 2 * l.diagramMarginY; l.mirrorActors && (rt = rt - l.boxMargin + l.bottomMarginAdj); let Y = z.stopx - z.startx; Y < et.maxWidth && (Y = et.maxWidth); let C = Y + 2 * l.diagramMarginX; O && _.append("text").text(O).attr("x", (z.stopx - z.startx) / 2 - 2 * l.diagramMarginX).attr("y", -25), qe(_, rt, C, l.useMaxWidth); let kt = O ? 40 : 0, Mt = E.size && s === "neo" ? 30 : 0; _.attr("viewBox", z.startx - l.diagramMarginX + " -" + (l.diagramMarginY + kt) + " " + C + " " + (rt + kt + Mt)), tt.debug("models:", y.models); }); }, "draw");
function pr(e, t, a) { return st(this, null, function* () { let r = {}; for (let i of t)
    if (e.get(i.to) && e.get(i.from)) {
        let o = e.get(i.to);
        if (i.placement === a.db.PLACEMENT.LEFTOF && !o.prevActor || i.placement === a.db.PLACEMENT.RIGHTOF && !o.nextActor)
            continue;
        let s = i.placement !== void 0, c = !s, u = s ? At(l) : Rt(l), d = i.wrap ? X.wrapLabel(i.message, l.width - 2 * l.wrapPadding, u) : i.message, _ = (Z(d) ? yield mt(i.message, $()) : X.calculateTextDimensions(d, u)).width + 2 * l.wrapPadding;
        c && i.from === o.nextActor ? r[i.to] = N.getMax(r[i.to] || 0, _) : c && i.from === o.prevActor ? r[i.from] = N.getMax(r[i.from] || 0, _) : c && i.from === i.to ? (r[i.from] = N.getMax(r[i.from] || 0, _ / 2), r[i.to] = N.getMax(r[i.to] || 0, _ / 2)) : i.placement === a.db.PLACEMENT.RIGHTOF ? r[i.from] = N.getMax(r[i.from] || 0, _) : i.placement === a.db.PLACEMENT.LEFTOF ? r[o.prevActor] = N.getMax(r[o.prevActor] || 0, _) : i.placement === a.db.PLACEMENT.OVER && (o.prevActor && (r[o.prevActor] = N.getMax(r[o.prevActor] || 0, _ / 2)), o.nextActor && (r[i.from] = N.getMax(r[i.from] || 0, _ / 2)));
    } return tt.debug("maxMessageWidthPerActor:", r), r; }); }
x(pr, "getMaxMessageWidthPerActor");
var ca = x(function (e) { let t = 0, a = le(l); for (let r in e.links) {
    let o = X.calculateTextDimensions(r, a).width + 2 * l.wrapPadding + 2 * l.boxMargin;
    t < o && (t = o);
} return t; }, "getRequiredPopupWidth");
function Er(e, t, a) { return st(this, null, function* () { let r = 0; for (let o of e.keys()) {
    let s = e.get(o);
    s.wrap && (s.description = X.wrapLabel(s.description, l.width - 2 * l.wrapPadding, le(l)));
    let c = Z(s.description) ? yield mt(s.description, $()) : X.calculateTextDimensions(s.description, le(l));
    s.width = s.wrap ? l.width : N.getMax(l.width, c.width + 2 * l.wrapPadding), s.height = s.wrap ? N.getMax(c.height, l.height) : l.height, r = N.getMax(r, s.height);
} for (let o in t) {
    let s = e.get(o);
    if (!s)
        continue;
    let c = e.get(s.nextActor);
    if (!c) {
        let _ = t[o] + l.actorMargin - s.width / 2;
        s.margin = N.getMax(_, l.actorMargin);
        continue;
    }
    let d = t[o] + l.actorMargin - s.width / 2 - c.width / 2;
    s.margin = N.getMax(d, l.actorMargin);
} let i = 0; return a.forEach(o => { let s = Rt(l), c = o.actorKeys.reduce((_, E) => _ += e.get(E).width + (e.get(E).margin || 0), 0), u = l.boxMargin * 8; c += u, c -= 2 * l.boxTextMargin, o.wrap && (o.name = X.wrapLabel(o.name, c - 2 * l.wrapPadding, s)); let d = X.calculateTextDimensions(o.name, s); i = N.getMax(d.height, i); let p = N.getMax(c, d.width + 2 * l.wrapPadding); if (o.margin = l.boxTextMargin, c < p) {
    let _ = (p - c) / 2;
    o.margin += _;
} }), a.forEach(o => o.textMaxHeight = i), N.getMax(r, l.height); }); }
x(Er, "calculateActorMargins");
var la = x(function (e, t, a) { return st(this, null, function* () { let r = t.get(e.from), i = t.get(e.to), o = r.x, s = i.x, c = e.wrap && e.message, u = Z(e.message) ? yield mt(e.message, $()) : X.calculateTextDimensions(c ? X.wrapLabel(e.message, l.width, At(l)) : e.message, At(l)), d = { width: c ? l.width : N.getMax(l.width, u.width + 2 * l.noteMargin), height: 0, startx: r.x, stopx: 0, starty: 0, stopy: 0, message: e.message }; return e.placement === a.db.PLACEMENT.RIGHTOF ? (d.width = c ? N.getMax(l.width, u.width) : N.getMax(r.width / 2 + i.width / 2, u.width + 2 * l.noteMargin), d.startx = o + (r.width + l.actorMargin) / 2) : e.placement === a.db.PLACEMENT.LEFTOF ? (d.width = c ? N.getMax(l.width, u.width + 2 * l.noteMargin) : N.getMax(r.width / 2 + i.width / 2, u.width + 2 * l.noteMargin), d.startx = o - d.width + (r.width - l.actorMargin) / 2) : e.to === e.from ? (u = X.calculateTextDimensions(c ? X.wrapLabel(e.message, N.getMax(l.width, r.width), At(l)) : e.message, At(l)), d.width = c ? N.getMax(l.width, r.width) : N.getMax(r.width, l.width, u.width + 2 * l.noteMargin), d.startx = o + (r.width - d.width) / 2) : (d.width = Math.abs(o + r.width / 2 - (s + i.width / 2)) + l.actorMargin, d.startx = o < s ? o + r.width / 2 - l.actorMargin / 2 : s + i.width / 2 - l.actorMargin / 2), c && (d.message = X.wrapLabel(e.message, d.width - 2 * l.wrapPadding, At(l))), tt.debug(`NM:[${d.startx},${d.stopx},${d.starty},${d.stopy}:${d.width},${d.height}=${e.message}]`), d; }); }, "buildNoteModel"), ha = 4, da = 6, oe = x(function (e, t) { let { CENTRAL_CONNECTION: a, CENTRAL_CONNECTION_REVERSE: r, CENTRAL_CONNECTION_DUAL: i } = t.db.LINETYPE; return [a, r, i].includes(e.centralConnection); }, "hasCentralConnection"), Ta = x(function (e, t, a) { let { CENTRAL_CONNECTION_REVERSE: r, CENTRAL_CONNECTION_DUAL: i, BIDIRECTIONAL_SOLID: o, BIDIRECTIONAL_DOTTED: s } = t.db.LINETYPE, c = 0; return (e.centralConnection === r || e.centralConnection === i) && (c += ha), (e.centralConnection === r || e.centralConnection === i) && (e.type === o || e.type === s) && (c += a ? 0 : -da), c; }, "calculateCentralConnectionOffset"), ur = x(function (e, t) { let { SOLID_ARROW_TOP_REVERSE: a, SOLID_ARROW_TOP_REVERSE_DOTTED: r, SOLID_ARROW_BOTTOM_REVERSE: i, SOLID_ARROW_BOTTOM_REVERSE_DOTTED: o, STICK_ARROW_TOP_REVERSE: s, STICK_ARROW_TOP_REVERSE_DOTTED: c, STICK_ARROW_BOTTOM_REVERSE: u, STICK_ARROW_BOTTOM_REVERSE_DOTTED: d } = t.db.LINETYPE; return [a, r, i, o, s, c, u, d].includes(e.type); }, "isReverseArrowType"), pa = x(function (e, t) { let { BIDIRECTIONAL_SOLID: a, BIDIRECTIONAL_DOTTED: r } = t.db.LINETYPE; return [a, r].includes(e.type); }, "isBidirectionalArrowType"), Ea = x(function (e, t, a) { let { look: r } = $(); if (![a.db.LINETYPE.SOLID_OPEN, a.db.LINETYPE.DOTTED_OPEN, a.db.LINETYPE.SOLID, a.db.LINETYPE.SOLID_TOP, a.db.LINETYPE.SOLID_BOTTOM, a.db.LINETYPE.STICK_TOP, a.db.LINETYPE.STICK_BOTTOM, a.db.LINETYPE.SOLID_TOP_DOTTED, a.db.LINETYPE.SOLID_BOTTOM_DOTTED, a.db.LINETYPE.STICK_TOP_DOTTED, a.db.LINETYPE.STICK_BOTTOM_DOTTED, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE, a.db.LINETYPE.STICK_ARROW_TOP_REVERSE, a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED, a.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED, a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, a.db.LINETYPE.DOTTED, a.db.LINETYPE.SOLID_CROSS, a.db.LINETYPE.DOTTED_CROSS, a.db.LINETYPE.SOLID_POINT, a.db.LINETYPE.DOTTED_POINT, a.db.LINETYPE.BIDIRECTIONAL_SOLID, a.db.LINETYPE.BIDIRECTIONAL_DOTTED].includes(e.type))
    return {}; let [i, o] = sr(e.from, t), [s, c] = sr(e.to, t), u = i <= s, d = u ? o : i, p = u ? s : c; r === "neo" && (e.type !== a.db.LINETYPE.SOLID_OPEN && (p += u ? -3 : 3), (e.type === a.db.LINETYPE.BIDIRECTIONAL_SOLID || e.type === a.db.LINETYPE.BIDIRECTIONAL_DOTTED) && (d += u ? 3 : -3)), d += Ta(e, a, u); let _ = Math.abs(s - c) > 2, E = x(f => u ? -f : f, "adjustValue"); e.from === e.to ? p = d : (e.activate && !_ && (p += E(l.activationWidth / 2 - 1)), [a.db.LINETYPE.SOLID_OPEN, a.db.LINETYPE.DOTTED_OPEN, a.db.LINETYPE.STICK_TOP, a.db.LINETYPE.STICK_BOTTOM, a.db.LINETYPE.STICK_TOP_DOTTED, a.db.LINETYPE.STICK_BOTTOM_DOTTED, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED, a.db.LINETYPE.STICK_ARROW_TOP_REVERSE, a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE, a.db.LINETYPE.STICK_ARROW_TOP_REVERSE_DOTTED, a.db.LINETYPE.STICK_ARROW_BOTTOM_REVERSE_DOTTED, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE].includes(e.type) || (p += E(3)), [a.db.LINETYPE.BIDIRECTIONAL_SOLID, a.db.LINETYPE.BIDIRECTIONAL_DOTTED, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE_DOTTED, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE_DOTTED, a.db.LINETYPE.SOLID_ARROW_TOP_REVERSE, a.db.LINETYPE.SOLID_ARROW_BOTTOM_REVERSE].includes(e.type) && (d -= E(3))); let R = [i, o, s, c], T = Math.abs(d - p); e.wrap && e.message && (e.message = X.wrapLabel(e.message, N.getMax(T + 2 * l.wrapPadding, l.width), Rt(l))); let g = X.calculateTextDimensions(e.message, Rt(l)); return { width: N.getMax(e.wrap ? 0 : g.width + 2 * l.wrapPadding, T + 2 * l.wrapPadding, l.width), height: 0, startx: d, stopx: p, starty: 0, stopy: 0, message: e.message, type: e.type, wrap: e.wrap, fromBounds: Math.min.apply(null, R), toBounds: Math.max.apply(null, R) }; }, "buildMessageModel"), ua = x(function (e, t, a, r) { return st(this, null, function* () { let i = {}, o = [], s, c, u; for (let d of e) {
    switch (d.type) {
        case r.db.LINETYPE.LOOP_START:
        case r.db.LINETYPE.ALT_START:
        case r.db.LINETYPE.OPT_START:
        case r.db.LINETYPE.PAR_START:
        case r.db.LINETYPE.PAR_OVER_START:
        case r.db.LINETYPE.CRITICAL_START:
        case r.db.LINETYPE.BREAK_START:
            o.push({ id: d.id, msg: d.message, from: Number.MAX_SAFE_INTEGER, to: Number.MIN_SAFE_INTEGER, width: 0 });
            break;
        case r.db.LINETYPE.ALT_ELSE:
        case r.db.LINETYPE.PAR_AND:
        case r.db.LINETYPE.CRITICAL_OPTION:
            d.message && (s = o.pop(), i[s.id] = s, i[d.id] = s, o.push(s));
            break;
        case r.db.LINETYPE.LOOP_END:
        case r.db.LINETYPE.ALT_END:
        case r.db.LINETYPE.OPT_END:
        case r.db.LINETYPE.PAR_END:
        case r.db.LINETYPE.CRITICAL_END:
        case r.db.LINETYPE.BREAK_END:
            s = o.pop(), i[s.id] = s;
            break;
        case r.db.LINETYPE.ACTIVE_START:
            {
                let _ = t.get(d.from ? d.from : d.to.actor), E = Jt(d.from ? d.from : d.to.actor).length, R = _.x + _.width / 2 + (E - 1) * l.activationWidth / 2, T = { startx: R, stopx: R + l.activationWidth, actor: d.from, enabled: !0 };
                y.activations.push(T);
            }
            break;
        case r.db.LINETYPE.ACTIVE_END:
            {
                let _ = y.activations.map(E => E.actor).lastIndexOf(d.from);
                y.activations.splice(_, 1).splice(0, 1);
            }
            break;
    }
    d.placement !== void 0 ? (c = yield la(d, t, r), d.noteModel = c, o.forEach(_ => { s = _, s.from = N.getMin(s.from, c.startx), s.to = N.getMax(s.to, c.startx + c.width), s.width = N.getMax(s.width, Math.abs(s.from - s.to)) - l.labelBoxWidth; })) : (u = Ea(d, t, r), d.msgModel = u, u.startx && u.stopx && o.length > 0 && o.forEach(_ => { if (s = _, u.startx === u.stopx) {
        let E = t.get(d.from), R = t.get(d.to);
        s.from = N.getMin(E.x - u.width / 2, E.x - E.width / 2, s.from), s.to = N.getMax(R.x + u.width / 2, R.x + E.width / 2, s.to), s.width = N.getMax(s.width, Math.abs(s.to - s.from)) - l.labelBoxWidth;
    }
    else
        s.from = N.getMin(u.startx, s.from), s.to = N.getMax(u.stopx, s.to), s.width = N.getMax(s.width, u.width) - l.labelBoxWidth; }));
} return y.activations = [], tt.debug("Loop type widths:", i), i; }); }, "calculateLoopBounds"), fa = { bounds: y, drawActors: he, drawActorsPopup: hr, setConf: dr, draw: oa }, ma = { parser: Rr, get db() { return new Ar; }, renderer: fa, styles: kr, init: x(e => { e.sequence || (e.sequence = {}), e.wrap && (e.sequence.wrap = e.wrap, Qe({ sequence: { wrap: e.wrap } })); }, "init") };
export { ma as diagram };
