import { a as r, b as s, c as l, d as a, e as c, g as v, j as u, x as E, y as m } from "@nf-internal/chunk-EPGORQP5";
var V = class extends m {
    static { r(this, "EventModelingTokenBuilder"); }
    constructor() { super(["eventmodeling"]); }
}, S = new Set(["cmd", "command"]), y = new Set(["evt", "event"]), d = new Set(["rmo", "readmodel"]), h = new Set(["pcr", "processor"]), M = new Set(["ui"]);
function T(e) { let t = e.validation.EventModelingValidator, o = e.validation.ValidationRegistry; if (o) {
    let i = { EmTimeFrame: t.checkSourceFrameTypes.bind(t), EmResetFrame: t.checkSourceFrameTypes.bind(t) };
    o.register(i, t);
} }
r(T, "registerValidationChecks");
var k = class {
    static { r(this, "EventModelingValidator"); }
    checkSourceFrameTypes(e, t) { e.sourceFrames.length !== 0 && (S.has(e.modelEntityType) ? this.validateSources(e, new Set([...M, ...h]), "command", "ui or processor", t) : y.has(e.modelEntityType) ? this.validateSources(e, S, "event", "command", t) : d.has(e.modelEntityType) ? this.validateSources(e, y, "read model", "event", t) : h.has(e.modelEntityType) ? this.validateSources(e, d, "processor", "read model", t) : M.has(e.modelEntityType) && this.validateSources(e, d, "ui", "read model", t)); }
    validateSources(e, t, o, i, g) { for (let p of e.sourceFrames) {
        let n = p.ref;
        n !== void 0 && !t.has(n.modelEntityType) && g("error", `A ${o} can only receive input from a ${i}, not from '${n.modelEntityType}'.`, { node: e, property: "sourceFrames" });
    } }
}, C = { parser: { TokenBuilder: r(() => new V, "TokenBuilder"), ValueConverter: r(() => new E, "ValueConverter") }, validation: { EventModelingValidator: r(() => new k, "EventModelingValidator") } };
function w(e = c) { let t = a(l(e), v), o = a(s({ shared: t }), u, C); return t.ServiceRegistry.register(o), T(o), { shared: t, EventModel: o }; }
r(w, "createEventModelingServices");
export { C as a, w as b };
