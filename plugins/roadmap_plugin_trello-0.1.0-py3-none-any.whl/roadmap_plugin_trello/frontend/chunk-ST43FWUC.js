import { a as _t } from "@nf-internal/chunk-JKFADCWD";
import { e as I } from "@nf-internal/chunk-VEDGZ2C2";
import { a as Lt } from "@nf-internal/chunk-PRKFGJVH";
import { c as xt, d as bt } from "@nf-internal/chunk-GP7LUXUQ";
import { b as nt, d as Mt } from "@nf-internal/chunk-3SXY7Q5B";
import { p as A, t as wt } from "@nf-internal/chunk-FDRUJGNH";
import { _ as Y, u as X, y as at } from "@nf-internal/chunk-LEJRRF65";
import { $ as gt, G as J, H as lt, J as ct, K as dt, L as et, P as pt, S as ht, W as ft, X as mt, Y as kt, Z as ut, _ as yt, b, h as W } from "@nf-internal/chunk-RZWXGGKD";
import { a as p } from "@nf-internal/chunk-YUSHYV7C";
import { a as ot, f as it } from "@nf-internal/chunk-OSQMNGTH";
var N = p((r, t) => { if (t)
    return "translate(" + -r.width / 2 + ", " + -r.height / 2 + ")"; let a = r.x ?? 0, e = r.y ?? 0; return "translate(" + -(a + r.width / 2) + ", " + -(e + r.height / 2) + ")"; }, "computeLabelTransform"), v = { aggregation: 17.25, extension: 17.25, composition: 17.25, dependency: 6, lollipop: 13.5, arrow_point: 4, arrow_barb: 0, arrow_barb_neo: 5.5 }, St = { arrow_point: 4, arrow_cross: 12.5, arrow_circle: 12.5 };
function Q(r, t) { if (r === void 0 || t === void 0)
    return { angle: 0, deltaX: 0, deltaY: 0 }; r = x(r), t = x(t); let [a, e] = [r.x, r.y], [o, s] = [t.x, t.y], n = o - a, i = s - e; return { angle: Math.atan(i / n), deltaX: n, deltaY: i }; }
p(Q, "calculateDeltaAndAngle");
var x = p(r => Array.isArray(r) ? { x: r[0], y: r[1] } : r, "pointTransformer"), Bt = p(r => ({ x: p(function (t, a, e) { let o = 0, s = x(e[0]).x < x(e[e.length - 1]).x ? "left" : "right"; if (a === 0 && Object.hasOwn(v, r.arrowTypeStart)) {
        let { angle: c, deltaX: y } = Q(e[0], e[1]);
        o = v[r.arrowTypeStart] * Math.cos(c) * (y >= 0 ? 1 : -1);
    }
    else if (a === e.length - 1 && Object.hasOwn(v, r.arrowTypeEnd)) {
        let { angle: c, deltaX: y } = Q(e[e.length - 1], e[e.length - 2]);
        o = v[r.arrowTypeEnd] * Math.cos(c) * (y >= 0 ? 1 : -1);
    } let n = Math.abs(x(t).x - x(e[e.length - 1]).x), i = Math.abs(x(t).y - x(e[e.length - 1]).y), d = Math.abs(x(t).x - x(e[0]).x), m = Math.abs(x(t).y - x(e[0]).y), l = v[r.arrowTypeStart], f = v[r.arrowTypeEnd], h = 1; if (n < f && n > 0 && i < f) {
        let c = f + h - n;
        c *= s === "right" ? -1 : 1, o -= c;
    } if (d < l && d > 0 && m < l) {
        let c = l + h - d;
        c *= s === "right" ? -1 : 1, o += c;
    } return x(t).x + o; }, "x"), y: p(function (t, a, e) { let o = 0, s = x(e[0]).y < x(e[e.length - 1]).y ? "down" : "up"; if (a === 0 && Object.hasOwn(v, r.arrowTypeStart)) {
        let { angle: c, deltaY: y } = Q(e[0], e[1]);
        o = v[r.arrowTypeStart] * Math.abs(Math.sin(c)) * (y >= 0 ? 1 : -1);
    }
    else if (a === e.length - 1 && Object.hasOwn(v, r.arrowTypeEnd)) {
        let { angle: c, deltaY: y } = Q(e[e.length - 1], e[e.length - 2]);
        o = v[r.arrowTypeEnd] * Math.abs(Math.sin(c)) * (y >= 0 ? 1 : -1);
    } let n = Math.abs(x(t).y - x(e[e.length - 1]).y), i = Math.abs(x(t).x - x(e[e.length - 1]).x), d = Math.abs(x(t).y - x(e[0]).y), m = Math.abs(x(t).x - x(e[0]).x), l = v[r.arrowTypeStart], f = v[r.arrowTypeEnd], h = 1; if (n < f && n > 0 && i < f) {
        let c = f + h - n;
        c *= s === "up" ? -1 : 1, o -= c;
    } if (d < l && d > 0 && m < l) {
        let c = l + h - d;
        c *= s === "up" ? -1 : 1, o += c;
    } return x(t).y + o; }, "y") }), "getLineFunctionsWithOffset"), Ct = p((r, t, a, e, o, s = !1, n) => { t.arrowTypeStart && vt(r, "start", t.arrowTypeStart, a, e, o, s, n), t.arrowTypeEnd && vt(r, "end", t.arrowTypeEnd, a, e, o, s, n); }, "addEdgeMarkers"), zt = { arrow_cross: { type: "cross", fill: !1 }, arrow_point: { type: "point", fill: !0 }, arrow_barb: { type: "barb", fill: !0 }, arrow_barb_neo: { type: "barb", fill: !0 }, arrow_circle: { type: "circle", fill: !1 }, aggregation: { type: "aggregation", fill: !1 }, extension: { type: "extension", fill: !1 }, composition: { type: "composition", fill: !0 }, dependency: { type: "dependency", fill: !0 }, lollipop: { type: "lollipop", fill: !1 }, only_one: { type: "onlyOne", fill: !1 }, zero_or_one: { type: "zeroOrOne", fill: !1 }, one_or_more: { type: "oneOrMore", fill: !1 }, zero_or_more: { type: "zeroOrMore", fill: !1 }, requirement_arrow: { type: "requirement_arrow", fill: !1 }, requirement_contains: { type: "requirement_contains", fill: !1 } }, Rt = ["cross", "point", "circle", "lollipop", "aggregation", "extension", "composition", "dependency", "barb"], vt = p((r, t, a, e, o, s, n = !1, i) => { if (!a || a === "none")
    return; let d = zt[a], m = d && Rt.includes(d.type); if (!d) {
    b.warn(`Unknown arrow type: ${a}`);
    return;
} let l = d.type, c = `${o}_${s}-${l}${t === "start" ? "Start" : "End"}${n && m ? "-margin" : ""}`; if (i && i.trim() !== "") {
    let y = i.replace(/[^\dA-Za-z]/g, "_"), g = `${c}_${y}`;
    if (!document.getElementById(g)) {
        let k = document.getElementById(c);
        if (k) {
            let M = k.cloneNode(!0);
            M.id = g, M.querySelectorAll("path, circle, line").forEach(B => { B.setAttribute("stroke", i), d.fill && B.setAttribute("fill", i); }), k.parentNode?.appendChild(M);
        }
    }
    r.attr(`marker-${t}`, `url(${e}#${g})`);
}
else
    r.attr(`marker-${t}`, `url(${e}#${c})`); }, "addEdgeMarker"), qt = p(r => typeof r == "string" ? r : Y()?.flowchart?.curve, "resolveEdgeCurveType"), G = new Map, _ = new Map, Or = p(() => { G.clear(), _.clear(); }, "clear"), Er = p(r => !!(r.label || r.startLabelLeft || r.startLabelRight || r.endLabelLeft || r.endLabelRight), "hasEdgeLabel"), D = p(r => r ? typeof r == "string" ? r : r.reduce((t, a) => t + ";" + a, "") : "", "getLabelStyles"), Ur = p((r, t) => it(null, null, function* () { let a = Y(), e = at(a), { labelStyles: o } = bt(t); t.labelStyle = o; let s = r.insert("g").attr("class", "edgeLabel"), n = s.insert("g").attr("class", "label").attr("data-id", t.id), i = t.labelType === "markdown", m = yield Mt(r, t.label, { style: D(t.labelStyle), useHtmlLabels: e, addSvgBackground: !0, isNode: !1, markdown: i, width: i ? void 0 : void 0 }, a); n.node().appendChild(m), b.info("abc82", t, t.labelType); let l, f; if (e) {
    let c = m.children[0], y = W(m);
    l = yield nt.measure(() => c.getBoundingClientRect()), f = l, y.attr("width", l.width), y.attr("height", l.height);
}
else {
    let c = W(m).select("text").node();
    yield nt.measure(() => { l = m.getBBox(), c && typeof c.getBBox == "function" ? f = c.getBBox() : f = l; });
} n.attr("transform", N(f, e)), G.set(t.id, s), t.width = l.width, t.height = l.height; let h; if (t.startLabelLeft) {
    let c = r.insert("g").attr("class", "edgeTerminals"), y = c.insert("g").attr("class", "inner"), g = yield I(y, t.startLabelLeft, D(t.labelStyle) || "", !1, !1);
    h = g;
    let k = g.getBBox();
    if (e) {
        let M = g.children[0], u = W(g);
        k = M.getBoundingClientRect(), u.attr("width", k.width), u.attr("height", k.height);
    }
    y.attr("transform", N(k, e)), _.get(t.id) || _.set(t.id, {}), _.get(t.id).startLeft = c, Z(h, t.startLabelLeft);
} if (t.startLabelRight) {
    let c = r.insert("g").attr("class", "edgeTerminals"), y = c.insert("g").attr("class", "inner"), g = yield I(y, t.startLabelRight, D(t.labelStyle) || "", !1, !1);
    h = g;
    let k = g.getBBox();
    if (e) {
        let M = g.children[0], u = W(g);
        k = M.getBoundingClientRect(), u.attr("width", k.width), u.attr("height", k.height);
    }
    y.attr("transform", N(k, e)), _.get(t.id) || _.set(t.id, {}), _.get(t.id).startRight = c, Z(h, t.startLabelRight);
} if (t.endLabelLeft) {
    let c = r.insert("g").attr("class", "edgeTerminals"), y = c.insert("g").attr("class", "inner"), g = yield I(c, t.endLabelLeft, D(t.labelStyle) || "", !1, !1);
    h = g;
    let k = g.getBBox();
    if (e) {
        let M = g.children[0], u = W(g);
        k = M.getBoundingClientRect(), u.attr("width", k.width), u.attr("height", k.height);
    }
    y.attr("transform", N(k, e)), _.get(t.id) || _.set(t.id, {}), _.get(t.id).endLeft = c, Z(h, t.endLabelLeft);
} if (t.endLabelRight) {
    let c = r.insert("g").attr("class", "edgeTerminals"), y = c.insert("g").attr("class", "inner"), g = yield I(c, t.endLabelRight, D(t.labelStyle) || "", !1, !1);
    h = g;
    let k = g.getBBox();
    if (e) {
        let M = g.children[0], u = W(g);
        k = M.getBoundingClientRect(), u.attr("width", k.width), u.attr("height", k.height);
    }
    y.attr("transform", N(k, e)), _.get(t.id) || _.set(t.id, {}), _.get(t.id).endRight = c, Z(h, t.endLabelRight);
} return m; }), "insertEdgeLabel");
function Z(r, t) { at(Y()) && r && (r.style.width = t.length * 9 + "px", r.style.height = "12px"); }
p(Z, "setTerminalWidth");
var $r = p((r, t) => { b.debug("Moving label abc88 ", r.id, r.label, G.get(r.id), t); let a = t.updatedPath ? t.updatedPath : t.originalPath, e = Y(), { subGraphTitleTotalMargin: o } = _t(e); if (r.label) {
    let s = G.get(r.id), n = r.x, i = r.y;
    if (a) {
        let d = A.calcLabelPosition(a);
        b.debug("Moving label " + r.label + " from (", n, ",", i, ") to (", d.x, ",", d.y, ") abc88"), t.updatedPath && (n = d.x, i = d.y);
    }
    s.attr("transform", `translate(${n}, ${i + o / 2})`);
} if (r.startLabelLeft) {
    let s = _.get(r.id).startLeft, n = r.x, i = r.y;
    if (a) {
        let d = A.calcTerminalLabelPosition(r.arrowTypeStart ? 10 : 0, "start_left", a);
        n = d.x, i = d.y;
    }
    s.attr("transform", `translate(${n}, ${i})`);
} if (r.startLabelRight) {
    let s = _.get(r.id).startRight, n = r.x, i = r.y;
    if (a) {
        let d = A.calcTerminalLabelPosition(r.arrowTypeStart ? 10 : 0, "start_right", a);
        n = d.x, i = d.y;
    }
    s.attr("transform", `translate(${n}, ${i})`);
} if (r.endLabelLeft) {
    let s = _.get(r.id).endLeft, n = r.x, i = r.y;
    if (a) {
        let d = A.calcTerminalLabelPosition(r.arrowTypeEnd ? 10 : 0, "end_left", a);
        n = d.x, i = d.y;
    }
    s.attr("transform", `translate(${n}, ${i})`);
} if (r.endLabelRight) {
    let s = _.get(r.id).endRight, n = r.x, i = r.y;
    if (a) {
        let d = A.calcTerminalLabelPosition(r.arrowTypeEnd ? 10 : 0, "end_right", a);
        n = d.x, i = d.y;
    }
    s.attr("transform", `translate(${n}, ${i})`);
} }, "positionEdgeLabel"), Pt = p((r, t) => { if (!r?.isLabelEdge || !r?.id?.endsWith("-to-label") || !Array.isArray(t) || t.length !== 2)
    return t; let [a, e] = t, o = Math.abs(e.x - a.x), s = Math.abs(e.y - a.y); return o < .001 || s < .001 ? t : s >= o ? [a, { x: a.x, y: e.y }, e] : [a, { x: e.x, y: a.y }, e]; }, "orthogonalizeToLabelClippedPoints"), It = p((r, t) => { let a = r.x, e = r.y, o = Math.abs(t.x - a), s = Math.abs(t.y - e), n = r.width / 2, i = r.height / 2; return o >= n || s >= i; }, "outsideNode"), Nt = p((r, t, a) => {
    b.debug(`intersection calc abc89:
  outsidePoint: ${JSON.stringify(t)}
  insidePoint : ${JSON.stringify(a)}
  node        : x:${r.x} y:${r.y} w:${r.width} h:${r.height}`);
    let e = r.x, o = r.y, s = Math.abs(e - a.x), n = r.width / 2, i = a.x < t.x ? n - s : n + s, d = r.height / 2, m = Math.abs(t.y - a.y), l = Math.abs(t.x - a.x);
    if (Math.abs(o - t.y) * n > Math.abs(e - t.x) * d) {
        let f = a.y < t.y ? t.y - d - o : o - d - t.y;
        i = l * f / m;
        let h = { x: a.x < t.x ? a.x + i : a.x - l + i, y: a.y < t.y ? a.y + m - f : a.y - m + f };
        return i === 0 && (h.x = t.x, h.y = t.y), l === 0 && (h.x = t.x), m === 0 && (h.y = t.y), b.debug(`abc89 top/bottom calc, Q ${m}, q ${f}, R ${l}, r ${i}`, h), h;
    }
    else {
        a.x < t.x ? i = t.x - n - e : i = e - n - t.x;
        let f = m * i / l, h = a.x < t.x ? a.x + l - i : a.x - l + i, c = a.y < t.y ? a.y + f : a.y - f;
        return b.debug(`sides calc abc89, Q ${m}, q ${f}, R ${l}, r ${i}`, { _x: h, _y: c }), i === 0 && (h = t.x, c = t.y), l === 0 && (h = t.x), m === 0 && (c = t.y), { x: h, y: c };
    }
}, "intersection"), Ot = p((r, t) => { b.warn("abc88 cutPathAtIntersect", r, t); let a = [], e = r[0], o = !1; return r.forEach(s => { if (b.info("abc88 checking point", s, t), !It(t, s) && !o) {
    let n = Nt(t, e, s);
    b.debug("abc88 inside", s, e, n), b.debug("abc88 intersection", n, t);
    let i = !1;
    a.forEach(d => { i = i || d.x === n.x && d.y === n.y; }), a.some(d => d.x === n.x && d.y === n.y) ? b.warn("abc88 no intersect", n, a) : a.push(n), o = !0;
}
else
    b.warn("abc88 outside", s, e), e = s, o || a.push(s); }), b.debug("returning points", a), a; }, "cutPathAtIntersect");
function Ut(r) { let t = [], a = []; for (let e = 1; e < r.length - 1; e++) {
    let o = r[e - 1], s = r[e], n = r[e + 1];
    (o.x === s.x && s.y === n.y && Math.abs(s.x - n.x) > 5 && Math.abs(s.y - o.y) > 5 || o.y === s.y && s.x === n.x && Math.abs(s.x - o.x) > 5 && Math.abs(s.y - n.y) > 5) && (t.push(s), a.push(e));
} return { cornerPoints: t, cornerPointPositions: a }; }
p(Ut, "extractCornerPoints");
var Et = p(function (r, t, a) { let e = t.x - r.x, o = t.y - r.y, s = Math.sqrt(e * e + o * o), n = a / s; return { x: t.x - n * e, y: t.y - n * o }; }, "findAdjacentPoint"), Dt = p(function (r) { let { cornerPointPositions: t } = Ut(r), a = []; for (let e = 0; e < r.length; e++)
    if (t.includes(e)) {
        let o = r[e - 1], s = r[e + 1], n = r[e], i = Et(o, n, 5), d = Et(s, n, 5), m = d.x - i.x, l = d.y - i.y;
        a.push(i);
        let f = Math.sqrt(2) * 2, h = { x: n.x, y: n.y };
        if (Math.abs(s.x - o.x) > 10 && Math.abs(s.y - o.y) >= 10) {
            b.debug("Corner point fixing", Math.abs(s.x - o.x), Math.abs(s.y - o.y));
            let c = 5;
            n.x === i.x ? h = { x: m < 0 ? i.x - c + f : i.x + c - f, y: l < 0 ? i.y - f : i.y + f } : h = { x: m < 0 ? i.x - f : i.x + f, y: l < 0 ? i.y - c + f : i.y + c - f };
        }
        else
            b.debug("Corner point skipping fixing", Math.abs(s.x - o.x), Math.abs(s.y - o.y));
        a.push(h, d);
    }
    else
        a.push(r[e]); return a; }, "fixCorners"), Qt = p((r, t, a) => { let e = r - t - a, o = 2, s = 2, n = o + s, i = Math.floor(e / n), d = Number.isFinite(i) ? Math.max(0, i) : 0, m = Array(d).fill(`${o} ${s}`).join(" "); return `0 ${t} ${m} ${a}`; }, "generateDashArray"), Xr = p(function (r, t, a, e, o, s, n, i = !1) { if (!n)
    throw new Error(`insertEdge: missing diagramId for edge "${t.id}" \u2014 edge IDs require a diagram prefix for uniqueness`); let { handDrawnSeed: d, layout: m } = Y(), l = t.points, f = !1, h = o; var c = s; let y = []; for (let w in t.cssCompiledStyles)
    xt(w) || y.push(t.cssCompiledStyles[w]); if (m === "swimlane") {
    if (c.intersect && h.intersect && Array.isArray(l) && l.length >= 2)
        if (l.length === 2)
            l = [h.intersect(l[0]), c.intersect(l[1])];
        else {
            let w = l.slice(1, -1), $ = w[0], O = w[w.length - 1], E = .5, z = Math.abs(l[l.length - 1].x - O.x) < E && Math.abs(l[l.length - 1].y - O.y) < E, T = h.intersect($), H = z ? O : c.intersect(O), R = Math.abs(H.x - O.x) < E && Math.abs(H.y - O.y) < E, Ht = Math.abs(T.x - $.x) < E && Math.abs(T.y - $.y) < E ? [] : [T], At = R ? [] : [H];
            l = [...Ht, ...w, ...At];
        }
    l = Pt(t, l);
}
else
    c.intersect && h.intersect && !i && (l = l.slice(1, t.points.length - 1), l.unshift(h.intersect(l[0])), l.push(c.intersect(l[l.length - 1]))); let g = btoa(JSON.stringify(l)); t.toCluster && (b.info("to cluster abc88", a.get(t.toCluster)), l = Ot(t.points, a.get(t.toCluster).node), f = !0), t.fromCluster && (b.debug("from cluster abc88", a.get(t.fromCluster), JSON.stringify(l, null, 2)), l = Ot(l.reverse(), a.get(t.fromCluster).node).reverse(), f = !0); let k = l.filter(w => !Number.isNaN(w.y)), M = qt(t.curve); M !== "rounded" && (k = Dt(k)); let u = J; switch (M) {
    case "linear":
        u = J;
        break;
    case "basis":
        u = et;
        break;
    case "cardinal":
        u = pt;
        break;
    case "bumpX":
        u = ct;
        break;
    case "bumpY":
        u = dt;
        break;
    case "catmullRom":
        u = ht;
        break;
    case "monotoneX":
        u = ft;
        break;
    case "monotoneY":
        u = mt;
        break;
    case "natural":
        u = kt;
        break;
    case "step":
        u = ut;
        break;
    case "stepAfter":
        u = gt;
        break;
    case "stepBefore":
        u = yt;
        break;
    case "rounded":
        u = J;
        break;
    default: u = et;
} let { x: B, y: K } = Bt(t), P = lt().x(B).y(K).curve(u), S; switch (t.thickness) {
    case "normal":
        S = "edge-thickness-normal";
        break;
    case "thick":
        S = "edge-thickness-thick";
        break;
    case "invisible":
        S = "edge-thickness-invisible";
        break;
    default: S = "edge-thickness-normal";
} switch (t.pattern) {
    case "solid":
        S += " edge-pattern-solid";
        break;
    case "dotted":
        S += " edge-pattern-dotted";
        break;
    case "dashed":
        S += " edge-pattern-dashed";
        break;
    default: S += " edge-pattern-solid";
} let L, j = M === "rounded" ? $t(Xt(k, t), 5) : P(k), U = Array.isArray(t.style) ? t.style : [t.style], V = U.find(w => w?.startsWith("stroke:")), C = ""; t.animate && (C = "edge-animation-fast"), t.animation && (C = "edge-animation-" + t.animation); let tt = !1; if (t.look === "handDrawn") {
    let w = Lt.svg(r);
    Object.assign([], k);
    let $ = w.path(j, { roughness: .3, seed: d });
    S += " transition", L = W($).select("path").attr("id", `${n}-${t.id}`).attr("class", " " + S + (t.classes ? " " + t.classes : "") + (C ? " " + C : "")).attr("style", U ? U.reduce((E, z) => E + ";" + z, "") : "");
    let O = L.attr("d");
    L.attr("d", O), r.node().appendChild(L.node());
}
else {
    let w = y.join(";"), $ = U ? U.reduce((R, q) => R + q + ";", "") : "", O = (w ? w + ";" + $ + ";" : $) + ";" + (U ? U.reduce((R, q) => R + ";" + q, "") : "");
    L = r.append("path").attr("d", j).attr("id", `${n}-${t.id}`).attr("class", " " + S + (t.classes ? " " + t.classes : "") + (C ? " " + C : "")).attr("style", O), V = O.match(/stroke:([^;]+)/)?.[1], tt = t.animate === !0 || !!t.animation || w.includes("animation");
    let E = L.node(), z = typeof E.getTotalLength == "function" ? E.getTotalLength() : 0, T = St[t.arrowTypeStart] || 0, H = St[t.arrowTypeEnd] || 0;
    if (t.look === "neo" && !tt) {
        let q = `stroke-dasharray: ${t.pattern === "dotted" || t.pattern === "dashed" ? Qt(z, T, H) : `0 ${T} ${z - T - H} ${H}`}; stroke-dashoffset: 0;`;
        L.attr("style", q + L.attr("style"));
    }
} L.attr("data-edge", !0), L.attr("data-et", "edge"), L.attr("data-id", t.id), L.attr("data-points", g), L.attr("data-look", wt(t.look)), t.showPoints && k.forEach(w => { r.append("circle").style("stroke", "red").style("fill", "red").attr("r", 1).attr("cx", w.x).attr("cy", w.y); }); let F = ""; (Y().flowchart.arrowMarkerAbsolute || Y().state.arrowMarkerAbsolute) && (F = window.location.protocol + "//" + window.location.host + window.location.pathname + window.location.search, F = F.replace(/\(/g, "\\(").replace(/\)/g, "\\)")), b.info("arrowTypeStart", t.arrowTypeStart), b.info("arrowTypeEnd", t.arrowTypeEnd); let Yt = !tt && t?.look === "neo"; Ct(L, t, F, n, e, Yt, V); let Wt = Math.floor(l.length / 2), Tt = l[Wt]; A.isLabelCoordinateInPath(Tt, L.attr("d")) || (f = !0); let rt = {}; return f && (rt.updatedPath = l), rt.originalPath = t.points, rt; }, "insertEdge");
function $t(r, t) { if (r.length < 2)
    return ""; let a = "", e = r.length, o = 1e-5; for (let s = 0; s < e; s++) {
    let n = r[s], i = r[s - 1], d = r[s + 1];
    if (s === 0)
        a += `M${n.x},${n.y}`;
    else if (s === e - 1)
        a += `L${n.x},${n.y}`;
    else {
        let m = n.x - i.x, l = n.y - i.y, f = d.x - n.x, h = d.y - n.y, c = Math.hypot(m, l), y = Math.hypot(f, h);
        if (c < o || y < o) {
            a += `L${n.x},${n.y}`;
            continue;
        }
        let g = m / c, k = l / c, M = f / y, u = h / y, B = g * M + k * u, K = Math.max(-1, Math.min(1, B)), P = Math.acos(K);
        if (P < o || Math.abs(Math.PI - P) < o) {
            a += `L${n.x},${n.y}`;
            continue;
        }
        let S = Math.min(t / Math.sin(P / 2), c / 2, y / 2), L = n.x - g * S, j = n.y - k * S, U = n.x + M * S, V = n.y + u * S;
        a += `L${L},${j}`, a += `Q${n.x},${n.y} ${U},${V}`;
    }
} return a; }
p($t, "generateRoundedPath");
function st(r, t) { if (!r || !t)
    return { angle: 0, deltaX: 0, deltaY: 0 }; let a = t.x - r.x, e = t.y - r.y; return { angle: Math.atan2(e, a), deltaX: a, deltaY: e }; }
p(st, "calculateDeltaAndAngle");
function Xt(r, t) { let a = r.map(o => ot({}, o)); if (r.length >= 2 && v[t.arrowTypeStart]) {
    let o = v[t.arrowTypeStart], s = r[0], n = r[1], { angle: i } = st(s, n), d = o * Math.cos(i), m = o * Math.sin(i);
    a[0].x = s.x + d, a[0].y = s.y + m;
} let e = r.length; if (e >= 2 && v[t.arrowTypeEnd]) {
    let o = v[t.arrowTypeEnd], s = r[e - 1], n = r[e - 2], { angle: i } = st(n, s), d = o * Math.cos(i), m = o * Math.sin(i);
    a[e - 1].x = s.x - d, a[e - 1].y = s.y - m;
} return a; }
p(Xt, "applyMarkerOffsetsToPoints");
var Zt = p((r, t, a, e) => { t.forEach(o => { ur[o](r, a, e); }); }, "insertMarkers"), jt = p((r, t, a) => { b.trace("Making markers for ", a), r.append("defs").append("marker").attr("id", a + "_" + t + "-extensionStart").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 1,7 L18,13 V 1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-extensionEnd").attr("class", "marker extension " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 1,1 V 13 L18,7 Z"), r.append("marker").attr("id", a + "_" + t + "-extensionStart-margin").attr("class", "marker extension " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").attr("viewBox", "0 0 20 14").append("polygon").attr("points", "10,7 18,13 18,1").style("stroke-width", 2).style("stroke-dasharray", "0"), r.append("defs").append("marker").attr("id", a + "_" + t + "-extensionEnd-margin").attr("class", "marker extension " + t).attr("refX", 9).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").attr("viewBox", "0 0 20 14").append("polygon").attr("points", "10,1 10,13 18,7").style("stroke-width", 2).style("stroke-dasharray", "0"); }, "extension"), Vt = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-compositionStart").attr("class", "marker composition " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-compositionEnd").attr("class", "marker composition " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-compositionStart-margin").attr("class", "marker composition " + t).attr("refX", 15).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 0).attr("viewBox", "0 0 15 15").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-compositionEnd-margin").attr("class", "marker composition " + t).attr("refX", 3.5).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 0).attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"); }, "composition"), Ft = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationStart").attr("class", "marker aggregation " + t).attr("refX", 18).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationEnd").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationStart-margin").attr("class", "marker aggregation " + t).attr("refX", 15).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 2).attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-aggregationEnd-margin").attr("class", "marker aggregation " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 2).attr("d", "M 18,7 L9,13 L1,7 L9,1 Z"); }, "aggregation"), Jt = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyStart").attr("class", "marker dependency " + t).attr("refX", 6).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyEnd").attr("class", "marker dependency " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyStart-margin").attr("class", "marker dependency " + t).attr("refX", 4).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 0).attr("d", "M 5,7 L9,13 L1,7 L9,1 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-dependencyEnd-margin").attr("class", "marker dependency " + t).attr("refX", 16).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").style("stroke-width", 0).attr("d", "M 18,7 L9,13 L14,7 L9,1 Z"); }, "dependency"), Gt = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopStart").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), r.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopEnd").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6), r.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopStart-margin").attr("class", "marker lollipop " + t).attr("refX", 13).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6).attr("stroke-width", 2), r.append("defs").append("marker").attr("id", a + "_" + t + "-lollipopEnd-margin").attr("class", "marker lollipop " + t).attr("refX", 1).attr("refY", 7).attr("markerWidth", 190).attr("markerHeight", 240).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("circle").attr("fill", "transparent").attr("cx", 7).attr("cy", 7).attr("r", 6).attr("stroke-width", 2); }, "lollipop"), Kt = p((r, t, a) => { r.append("marker").attr("id", a + "_" + t + "-pointEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-pointStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 4.5).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 8).attr("markerHeight", 8).attr("orient", "auto").append("path").attr("d", "M 0 5 L 10 10 L 10 0 z").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-pointEnd-margin").attr("class", "marker " + t).attr("viewBox", "0 0 11.5 14").attr("refX", 11.5).attr("refY", 7).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 10.5).attr("markerHeight", 14).attr("orient", "auto").append("path").attr("d", "M 0 0 L 11.5 7 L 0 14 z").attr("class", "arrowMarkerPath").style("stroke-width", 0).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-pointStart-margin").attr("class", "marker " + t).attr("viewBox", "0 0 11.5 14").attr("refX", 1).attr("refY", 7).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11.5).attr("markerHeight", 14).attr("orient", "auto").append("polygon").attr("points", "0,7 11.5,14 11.5,0").attr("class", "arrowMarkerPath").style("stroke-width", 0).style("stroke-dasharray", "1,0"); }, "point"), tr = p((r, t, a) => { r.append("marker").attr("id", a + "_" + t + "-circleEnd").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", 11).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-circleStart").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 1).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-circleEnd-margin").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refY", 5).attr("refX", 12.25).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 14).attr("markerHeight", 14).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 0).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-circleStart-margin").attr("class", "marker " + t).attr("viewBox", "0 0 10 10").attr("refX", -2).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 14).attr("markerHeight", 14).attr("orient", "auto").append("circle").attr("cx", "5").attr("cy", "5").attr("r", "5").attr("class", "arrowMarkerPath").style("stroke-width", 0).style("stroke-dasharray", "1,0"); }, "circle"), rr = p((r, t, a) => { r.append("marker").attr("id", a + "_" + t + "-crossEnd").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", 12).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-crossStart").attr("class", "marker cross " + t).attr("viewBox", "0 0 11 11").attr("refX", -1).attr("refY", 5.2).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 11).attr("markerHeight", 11).attr("orient", "auto").append("path").attr("d", "M 1,1 l 9,9 M 10,1 l -9,9").attr("class", "arrowMarkerPath").style("stroke-width", 2).style("stroke-dasharray", "1,0"), r.append("marker").attr("id", a + "_" + t + "-crossEnd-margin").attr("class", "marker cross " + t).attr("viewBox", "0 0 15 15").attr("refX", 17.7).attr("refY", 7.5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 1,1 L 14,14 M 1,14 L 14,1").attr("class", "arrowMarkerPath").style("stroke-width", 2.5), r.append("marker").attr("id", a + "_" + t + "-crossStart-margin").attr("class", "marker cross " + t).attr("viewBox", "0 0 15 15").attr("refX", -3.5).attr("refY", 7.5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 1,1 L 14,14 M 1,14 L 14,1").attr("class", "arrowMarkerPath").style("stroke-width", 2.5).style("stroke-dasharray", "1,0"); }, "cross"), ar = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z"); }, "barb"), er = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { transitionColor: s } = o; r.append("defs").append("marker").attr("id", a + "_" + t + "-barbEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "strokeWidth").attr("orient", "auto").append("path").attr("d", "M 19,7 L11,14 L13,7 L11,0 Z"), r.append("defs").append("marker").attr("id", a + "_" + t + "-barbEnd-margin").attr("refX", 17).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 14).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M 19,7 L11,14 L13,7 L11,0 Z").attr("fill", `${s}`); }, "barbNeo"), nr = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18"), r.append("defs").append("marker").attr("id", a + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18"); }, "only_one"), sr = p((r, t, a) => { let e = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto"); e.append("circle").attr("fill", "white").attr("cx", 21).attr("cy", 9).attr("r", 6), e.append("path").attr("d", "M9,0 L9,18"); let o = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto"); o.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 9).attr("r", 6), o.append("path").attr("d", "M21,0 L21,18"); }, "zero_or_one"), or = p((r, t, a) => { r.append("defs").append("marker").attr("id", a + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27"), r.append("defs").append("marker").attr("id", a + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18"); }, "one_or_more"), ir = p((r, t, a) => { let e = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto"); e.append("circle").attr("fill", "white").attr("cx", 48).attr("cy", 18).attr("r", 6), e.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18"); let o = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto"); o.append("circle").attr("fill", "white").attr("cx", 9).attr("cy", 18).attr("r", 6), o.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18"); }, "zero_or_more"), lr = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { strokeWidth: s } = o; r.append("defs").append("marker").attr("id", a + "_" + t + "-onlyOneStart").attr("class", "marker onlyOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M9,0 L9,18 M15,0 L15,18").attr("stroke-width", `${s}`), r.append("defs").append("marker").attr("id", a + "_" + t + "-onlyOneEnd").attr("class", "marker onlyOne " + t).attr("refX", 18).attr("refY", 9).attr("markerWidth", 18).attr("markerHeight", 18).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M3,0 L3,18 M9,0 L9,18").attr("stroke-width", `${s}`); }, "only_one_neo"), cr = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { strokeWidth: s, mainBkg: n } = o, i = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrOneStart").attr("class", "marker zeroOrOne " + t).attr("refX", 0).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse"); i.append("circle").attr("fill", n ?? "white").attr("cx", 21).attr("cy", 9).attr("stroke-width", `${s}`).attr("r", 6), i.append("path").attr("d", "M9,0 L9,18").attr("stroke-width", `${s}`); let d = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrOneEnd").attr("class", "marker zeroOrOne " + t).attr("refX", 30).attr("refY", 9).attr("markerWidth", 30).attr("markerHeight", 18).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto"); d.append("circle").attr("fill", n ?? "white").attr("cx", 9).attr("cy", 9).attr("stroke-width", `${s}`).attr("r", 6), d.append("path").attr("d", "M21,0 L21,18").attr("stroke-width", `${s}`); }, "zero_or_one_neo"), dr = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { strokeWidth: s } = o; r.append("defs").append("marker").attr("id", a + "_" + t + "-oneOrMoreStart").attr("class", "marker oneOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("path").attr("d", "M0,18 Q 18,0 36,18 Q 18,36 0,18 M42,9 L42,27").attr("stroke-width", `${s}`), r.append("defs").append("marker").attr("id", a + "_" + t + "-oneOrMoreEnd").attr("class", "marker oneOrMore " + t).attr("refX", 27).attr("refY", 18).attr("markerWidth", 45).attr("markerHeight", 36).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto").append("path").attr("d", "M3,9 L3,27 M9,18 Q27,0 45,18 Q27,36 9,18").attr("stroke-width", `${s}`); }, "one_or_more_neo"), pr = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { strokeWidth: s, mainBkg: n } = o, i = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrMoreStart").attr("class", "marker zeroOrMore " + t).attr("refX", 18).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("markerUnits", "userSpaceOnUse").attr("orient", "auto"); i.append("circle").attr("fill", n ?? "white").attr("cx", 45.5).attr("cy", 18).attr("r", 6).attr("stroke-width", `${s}`), i.append("path").attr("d", "M0,18 Q18,0 36,18 Q18,36 0,18").attr("stroke-width", `${s}`); let d = r.append("defs").append("marker").attr("id", a + "_" + t + "-zeroOrMoreEnd").attr("class", "marker zeroOrMore " + t).attr("refX", 39).attr("refY", 18).attr("markerWidth", 57).attr("markerHeight", 36).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse"); d.append("circle").attr("fill", n ?? "white").attr("cx", 11).attr("cy", 18).attr("r", 6).attr("stroke-width", `${s}`), d.append("path").attr("d", "M21,18 Q39,0 57,18 Q39,36 21,18").attr("stroke-width", `${s}`); }, "zero_or_more_neo"), hr = p((r, t, a) => {
    r.append("defs").append("marker").attr("id", a + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("path").attr("d", `M0,0
      L20,10
      M20,10
      L0,20`);
}, "requirement_arrow"), fr = p((r, t, a) => {
    let e = X(), { themeVariables: o } = e, { strokeWidth: s } = o;
    r.append("defs").append("marker").attr("id", a + "_" + t + "-requirement_arrowEnd").attr("refX", 20).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").attr("stroke-width", `${s}`).attr("viewBox", "0 0 25 20").append("path").attr("d", `M0,0
      L20,10
      M20,10
      L0,20`).attr("stroke-linejoin", "miter");
}, "requirement_arrow_neo"), mr = p((r, t, a) => { let e = r.append("defs").append("marker").attr("id", a + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").append("g"); e.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), e.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), e.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10); }, "requirement_contains"), kr = p((r, t, a) => { let e = X(), { themeVariables: o } = e, { strokeWidth: s } = o, n = r.append("defs").append("marker").attr("id", a + "_" + t + "-requirement_containsStart").attr("refX", 0).attr("refY", 10).attr("markerWidth", 20).attr("markerHeight", 20).attr("orient", "auto").attr("markerUnits", "userSpaceOnUse").append("g"); n.append("circle").attr("cx", 10).attr("cy", 10).attr("r", 9).attr("fill", "none"), n.append("line").attr("x1", 1).attr("x2", 19).attr("y1", 10).attr("y2", 10), n.append("line").attr("y1", 1).attr("y2", 19).attr("x1", 10).attr("x2", 10), n.selectAll("*").attr("stroke-width", `${s}`); }, "requirement_contains_neo"), ur = { extension: jt, composition: Vt, aggregation: Ft, dependency: Jt, lollipop: Gt, point: Kt, circle: tr, cross: rr, barb: ar, barbNeo: er, only_one: nr, zero_or_one: sr, one_or_more: or, zero_or_more: ir, only_one_neo: lr, zero_or_one_neo: cr, one_or_more_neo: dr, zero_or_more_neo: pr, requirement_arrow: hr, requirement_contains: mr, requirement_arrow_neo: fr, requirement_contains_neo: kr }, Yr = Zt;
export { v as a, G as b, _ as c, Or as d, Er as e, Ur as f, $r as g, Xr as h, Yr as i };
