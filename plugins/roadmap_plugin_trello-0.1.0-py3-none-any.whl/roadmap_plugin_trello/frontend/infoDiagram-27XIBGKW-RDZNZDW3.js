import { a as p } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import { a as s } from "@nf-internal/chunk-YQ6X4GJP";
import { O as i } from "@nf-internal/chunk-LEJRRF65";
import { b as a } from "@nf-internal/chunk-RZWXGGKD";
import { a as r } from "@nf-internal/chunk-YUSHYV7C";
import { f as n } from "@nf-internal/chunk-OSQMNGTH";
var m = { parse: r(e => n(null, null, function* () { let t = yield p("info", e); a.debug(t); }), "parse") }, v = { version: "11.17.2" }, d = r(() => v.version, "getVersion"), f = { getVersion: d }, c = r((e, t, g) => {
    a.debug(`rendering info diagram
` + e);
    let o = s(t);
    i(o, 100, 400, !0), o.append("g").append("text").attr("x", 100).attr("y", 40).attr("class", "version").attr("font-size", 32).style("text-anchor", "middle").text(`v${g}`);
}, "draw"), u = { draw: c }, S = { parser: m, db: f, renderer: u };
export { S as diagram };
