import { a as ye } from "@nf-internal/chunk-HDKR6WI7";
import { a as xe } from "@nf-internal/chunk-CDENLQJG";
import { a as ue } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import { h as fe, o as $e, p as pe } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { N as E, T as se, U as ne, V as ce, W as ie, X as de, Y as he, Z as le, _ as q, ca as me, k as oe, u as z } from "@nf-internal/chunk-LEJRRF65";
import { b as w, h as ge } from "@nf-internal/chunk-RZWXGGKD";
import { a as l } from "@nf-internal/chunk-YUSHYV7C";
import { a as F, b as re, f as ae } from "@nf-internal/chunk-OSQMNGTH";
var x = { NORMAL: 0, REVERSE: 1, HIGHLIGHT: 2, MERGE: 3, CHERRY_PICK: 4 }, Me = oe.gitGraph, D = l(() => $e(F(F({}, Me), z().gitGraph)), "getConfig"), d = new ye(() => { let e = D(), t = e.mainBranchName, r = e.mainBranchOrder; return { mainBranchName: t, commits: new Map, head: null, branchConfig: new Map([[t, { name: t, order: r }]]), branches: new Map([[t, null]]), currBranch: t, direction: "LR", seq: 0, options: {} }; });
function K() { return fe({ length: 7 }); }
l(K, "getID");
function we(e, t) { let r = Object.create(null); return e.reduce((s, n) => { let i = t(n); return r[i] || (r[i] = !0, s.push(n)), s; }, []); }
l(we, "uniqBy");
var Pe = l(function (e) { d.records.direction = e; }, "setDirection"), Re = l(function (e) { w.debug("options str", e), e = e?.trim(), e = e || "{}"; try {
    d.records.options = JSON.parse(e);
}
catch (t) {
    w.error("error while parsing gitGraph options", t.message);
} }, "setOptions"), Oe = l(function () { return d.records.options; }, "getOptions"), Ie = l(function (e) { let t = e.msg, r = e.id, s = e.type, n = e.tags; w.info("commit", t, r, s, n), w.debug("Entering commit:", t, r, s, n); let i = D(); r = E.sanitizeText(r, i), t = E.sanitizeText(t, i), n = n?.map(a => E.sanitizeText(a, i)); let o = { id: r || d.records.seq + "-" + K(), message: t, seq: d.records.seq++, type: s ?? x.NORMAL, tags: n ?? [], parents: d.records.head == null ? [] : [d.records.head.id], branch: d.records.currBranch }; d.records.head = o, w.info("main branch", i.mainBranchName), d.records.commits.has(o.id) && w.warn(`Commit ID ${o.id} already exists`), d.records.commits.set(o.id, o), d.records.branches.set(d.records.currBranch, o.id), w.debug("in pushCommit " + o.id); }, "commit"), _e = l(function (e) { let t = e.name, r = e.order; if (t = E.sanitizeText(t, D()), d.records.branches.has(t))
    throw new Error(`Trying to create an existing branch. (Help: Either use a new name if you want create a new branch or try using "checkout ${t}")`); d.records.branches.set(t, d.records.head != null ? d.records.head.id : null), d.records.branchConfig.set(t, { name: t, order: r }), Be(t), w.debug("in createBranch"); }, "branch"), Ge = l(e => { let t = e.branch, r = e.id, s = e.type, n = e.tags, i = D(); t = E.sanitizeText(t, i), r && (r = E.sanitizeText(r, i)); let o = d.records.branches.get(d.records.currBranch), a = d.records.branches.get(t), h = o ? d.records.commits.get(o) : void 0, g = a ? d.records.commits.get(a) : void 0; if (h && g && h.branch === t)
    throw new Error(`Cannot merge branch '${t}' into itself.`); if (d.records.currBranch === t) {
    let c = new Error('Incorrect usage of "merge". Cannot merge a branch to itself');
    throw c.hash = { text: `merge ${t}`, token: `merge ${t}`, expected: ["branch abc"] }, c;
} if (h === void 0 || !h) {
    let c = new Error(`Incorrect usage of "merge". Current branch (${d.records.currBranch})has no commits`);
    throw c.hash = { text: `merge ${t}`, token: `merge ${t}`, expected: ["commit"] }, c;
} if (!d.records.branches.has(t)) {
    let c = new Error('Incorrect usage of "merge". Branch to be merged (' + t + ") does not exist");
    throw c.hash = { text: `merge ${t}`, token: `merge ${t}`, expected: [`branch ${t}`] }, c;
} if (g === void 0 || !g) {
    let c = new Error('Incorrect usage of "merge". Branch to be merged (' + t + ") has no commits");
    throw c.hash = { text: `merge ${t}`, token: `merge ${t}`, expected: ['"commit"'] }, c;
} if (h === g) {
    let c = new Error('Incorrect usage of "merge". Both branches have same head');
    throw c.hash = { text: `merge ${t}`, token: `merge ${t}`, expected: ["branch abc"] }, c;
} if (r && d.records.commits.has(r)) {
    let c = new Error('Incorrect usage of "merge". Commit with id:' + r + " already exists, use different custom id");
    throw c.hash = { text: `merge ${t} ${r} ${s} ${n?.join(" ")}`, token: `merge ${t} ${r} ${s} ${n?.join(" ")}`, expected: [`merge ${t} ${r}_UNIQUE ${s} ${n?.join(" ")}`] }, c;
} let f = a || "", m = { id: r || `${d.records.seq}-${K()}`, message: `merged branch ${t} into ${d.records.currBranch}`, seq: d.records.seq++, parents: d.records.head == null ? [] : [d.records.head.id, f], branch: d.records.currBranch, type: x.MERGE, customType: s, customId: !!r, tags: n ?? [] }; d.records.head = m, d.records.commits.set(m.id, m), d.records.branches.set(d.records.currBranch, m.id), w.debug(d.records.branches), w.debug("in mergeBranch"); }, "merge"), De = l(function (e) { let t = e.id, r = e.targetId, s = e.tags, n = e.parent; w.debug("Entering cherryPick:", t, r, s); let i = D(); if (t = E.sanitizeText(t, i), r = E.sanitizeText(r, i), s = s?.map(h => E.sanitizeText(h, i)), n = E.sanitizeText(n, i), !t || !d.records.commits.has(t)) {
    let h = new Error('Incorrect usage of "cherryPick". Source commit id should exist and provided');
    throw h.hash = { text: `cherryPick ${t} ${r}`, token: `cherryPick ${t} ${r}`, expected: ["cherry-pick abc"] }, h;
} let o = d.records.commits.get(t); if (o === void 0 || !o)
    throw new Error('Incorrect usage of "cherryPick". Source commit id should exist and provided'); if (n && !(Array.isArray(o.parents) && o.parents.includes(n)))
    throw new Error("Invalid operation: The specified parent commit is not an immediate parent of the cherry-picked commit."); let a = o.branch; if (o.type === x.MERGE && !n)
    throw new Error("Incorrect usage of cherry-pick: If the source commit is a merge commit, an immediate parent commit must be specified."); if (!r || !d.records.commits.has(r)) {
    if (a === d.records.currBranch) {
        let m = new Error('Incorrect usage of "cherryPick". Source commit is already on current branch');
        throw m.hash = { text: `cherryPick ${t} ${r}`, token: `cherryPick ${t} ${r}`, expected: ["cherry-pick abc"] }, m;
    }
    let h = d.records.branches.get(d.records.currBranch);
    if (h === void 0 || !h) {
        let m = new Error(`Incorrect usage of "cherry-pick". Current branch (${d.records.currBranch})has no commits`);
        throw m.hash = { text: `cherryPick ${t} ${r}`, token: `cherryPick ${t} ${r}`, expected: ["cherry-pick abc"] }, m;
    }
    let g = d.records.commits.get(h);
    if (g === void 0 || !g) {
        let m = new Error(`Incorrect usage of "cherry-pick". Current branch (${d.records.currBranch})has no commits`);
        throw m.hash = { text: `cherryPick ${t} ${r}`, token: `cherryPick ${t} ${r}`, expected: ["cherry-pick abc"] }, m;
    }
    let f = { id: d.records.seq + "-" + K(), message: `cherry-picked ${o?.message} into ${d.records.currBranch}`, seq: d.records.seq++, parents: d.records.head == null ? [] : [d.records.head.id, o.id], branch: d.records.currBranch, type: x.CHERRY_PICK, tags: s ? s.filter(Boolean) : [`cherry-pick:${o.id}${o.type === x.MERGE ? `|parent:${n}` : ""}`] };
    d.records.head = f, d.records.commits.set(f.id, f), d.records.branches.set(d.records.currBranch, f.id), w.debug(d.records.branches), w.debug("in cherryPick");
} }, "cherryPick"), Be = l(function (e) { if (e = E.sanitizeText(e, D()), d.records.branches.has(e)) {
    d.records.currBranch = e;
    let t = d.records.branches.get(d.records.currBranch);
    t === void 0 || !t ? d.records.head = null : d.records.head = d.records.commits.get(t) ?? null;
}
else {
    let t = new Error(`Trying to checkout branch which is not yet created. (Help try using "branch ${e}")`);
    throw t.hash = { text: `checkout ${e}`, token: `checkout ${e}`, expected: [`branch ${e}`] }, t;
} }, "checkout");
function X(e, t, r) { let s = e.indexOf(t); s === -1 ? e.push(r) : e.splice(s, 1, r); }
l(X, "upsert");
function Q(e) { let t = e.reduce((n, i) => n.seq > i.seq ? n : i, e[0]), r = ""; e.forEach(function (n) { n === t ? r += "	*" : r += "	|"; }); let s = [r, t.id, t.seq]; for (let n in d.records.branches)
    d.records.branches.get(n) === t.id && s.push(n); if (w.debug(s.join(" ")), t.parents && t.parents.length == 2 && t.parents[0] && t.parents[1]) {
    let n = d.records.commits.get(t.parents[0]);
    X(e, t, n), t.parents[1] && e.push(d.records.commits.get(t.parents[1]));
}
else {
    if (t.parents.length == 0)
        return;
    if (t.parents[0]) {
        let n = d.records.commits.get(t.parents[0]);
        X(e, t, n);
    }
} e = we(e, n => n.id), Q(e); }
l(Q, "prettyPrintCommitHistory");
var We = l(function () { w.debug(d.records.commits); let e = ke()[0]; Q([e]); }, "prettyPrint"), qe = l(function () { d.reset(), se(); }, "clear"), Ae = l(function () { return [...d.records.branchConfig.values()].map((t, r) => t.order !== null && t.order !== void 0 ? t : re(F({}, t), { order: parseFloat(`0.${r}`) })).sort((t, r) => (t.order ?? 0) - (r.order ?? 0)).map(({ name: t }) => ({ name: t })); }, "getBranchesAsObjArray"), He = l(function () { return d.records.branches; }, "getBranches"), Se = l(function () { return d.records.commits; }, "getCommits"), ke = l(function () { let e = [...d.records.commits.values()]; return e.forEach(function (t) { w.debug(t.id); }), e.sort((t, r) => t.seq - r.seq), e; }, "getCommitsArray"), Ne = l(function () { return d.records.currBranch; }, "getCurrentBranch"), Fe = l(function () { return d.records.direction; }, "getDirection"), ze = l(function () { return d.records.head; }, "getHead"), Ce = { commitType: x, getConfig: D, setDirection: Pe, setOptions: Re, getOptions: Oe, commit: Ie, branch: _e, merge: Ge, cherryPick: De, checkout: Be, prettyPrint: We, clear: qe, getBranchesAsObjArray: Ae, getBranches: He, getCommits: Se, getCommitsArray: ke, getCurrentBranch: Ne, getDirection: Fe, getHead: ze, setAccTitle: ne, getAccTitle: ce, getAccDescription: de, setAccDescription: ie, setDiagramTitle: he, getDiagramTitle: le }, Ye = l((e, t) => { xe(e, t), e.dir && t.setDirection(e.dir); for (let r of e.statements)
    je(r, t); }, "populate"), je = l((e, t) => { let s = { Commit: l(n => t.commit(Ke(n)), "Commit"), Branch: l(n => t.branch(Ue(n)), "Branch"), Merge: l(n => t.merge(Ve(n)), "Merge"), Checkout: l(n => t.checkout(Ze(n)), "Checkout"), CherryPicking: l(n => t.cherryPick(Xe(n)), "CherryPicking") }[e.$type]; s ? s(e) : w.error(`Unknown statement type: ${e.$type}`); }, "parseStatement"), Ke = l(e => ({ id: e.id, msg: e.message ?? "", type: e.type !== void 0 ? x[e.type] : x.NORMAL, tags: e.tags ?? void 0 }), "parseCommit"), Ue = l(e => ({ name: e.name, order: e.order ?? 0 }), "parseBranch"), Ve = l(e => ({ branch: e.branch, id: e.id ?? "", type: e.type !== void 0 ? x[e.type] : void 0, tags: e.tags ?? void 0 }), "parseMerge"), Ze = l(e => e.branch, "parseCheckout"), Xe = l(e => ({ id: e.id, targetId: "", tags: e.tags?.length === 0 ? void 0 : e.tags, parent: e.parent }), "parseCherryPicking"), Je = { parse: l(e => ae(null, null, function* () { let t = yield ue("gitGraph", e); w.debug(t), Ye(t, Ce); }), "parse") }, O = 10, I = 40, L = 4, P = 2, _ = 8, U = new Set(["redux", "redux-dark", "redux-color", "redux-dark-color"]), J = 12, ee = new Set(["redux-color", "redux-dark-color"]), Qe = new Set(["dark", "redux-dark", "redux-dark-color", "neo-dark"]), G = l((e, t, r = !1) => r && e > 0 ? (e - 1) % (t - 1) + 1 : e % t, "calcColorIndex"), C = new Map, v = new Map, Y = 30, H = new Map, j = [], R = 0, p = "LR", et = l(() => { C.clear(), v.clear(), H.clear(), R = 0, j = [], p = "LR"; }, "clear"), ve = l(e => { let t = document.createElementNS("http://www.w3.org/2000/svg", "text"); return (typeof e == "string" ? e.split(/\\n|\n|<br\s*\/?>/gi) : e).forEach(s => { let n = document.createElementNS("http://www.w3.org/2000/svg", "tspan"); n.setAttributeNS("http://www.w3.org/XML/1998/namespace", "xml:space", "preserve"), n.setAttribute("dy", "1em"), n.setAttribute("x", "0"), n.setAttribute("class", "row"), n.textContent = s.trim(), t.appendChild(n); }), t; }, "drawText"), Ee = l(e => { let t, r, s; return p === "BT" ? (r = l((n, i) => n <= i, "comparisonFunc"), s = 1 / 0) : (r = l((n, i) => n >= i, "comparisonFunc"), s = 0), e.forEach(n => { let i = p === "TB" || p == "BT" ? v.get(n)?.y : v.get(n)?.x; i !== void 0 && r(i, s) && (t = n, s = i); }), t; }, "findClosestParent"), tt = l(e => { let t = "", r = 1 / 0; return e.forEach(s => { let n = v.get(s).y; n <= r && (t = s, r = n); }), t || void 0; }, "findClosestParentBT"), rt = l((e, t, r) => { let s = r, n = r, i = []; e.forEach(o => { let a = t.get(o); if (!a)
    throw new Error(`Commit not found for key ${o}`); a.parents.length ? (s = ot(a), n = Math.max(s, n)) : i.push(a), st(a, s); }), s = n, i.forEach(o => { nt(o, s, r); }), e.forEach(o => { let a = t.get(o); if (a?.parents.length) {
    let h = tt(a.parents);
    s = v.get(h).y - I, s <= n && (n = s);
    let g = C.get(a.branch).pos, f = s - O;
    v.set(a.id, { x: g, y: f });
} }); }, "setParallelBTPos"), at = l(e => { let t = Ee(e.parents.filter(s => s !== null)); if (!t)
    throw new Error(`Closest parent not found for commit ${e.id}`); let r = v.get(t)?.y; if (r === void 0)
    throw new Error(`Closest parent position not found for commit ${e.id}`); return r; }, "findClosestParentPos"), ot = l(e => at(e) + I, "calculateCommitPosition"), st = l((e, t) => { let r = C.get(e.branch); if (!r)
    throw new Error(`Branch not found for commit ${e.id}`); let s = r.pos, n = t + O; return v.set(e.id, { x: s, y: n }), { x: s, y: n }; }, "setCommitPosition"), nt = l((e, t, r) => { let s = C.get(e.branch); if (!s)
    throw new Error(`Branch not found for commit ${e.id}`); let n = t + r, i = s.pos; v.set(e.id, { x: i, y: n }); }, "setRootPosition"), ct = l((e, t, r, s, n, i) => { let { theme: o } = q(), a = U.has(o ?? ""), h = ee.has(o ?? ""), g = Qe.has(o ?? ""); if (i === x.HIGHLIGHT)
    e.append("rect").attr("x", r.x - 10 + (a ? 3 : 0)).attr("y", r.y - 10 + (a ? 3 : 0)).attr("width", a ? 14 : 20).attr("height", a ? 14 : 20).attr("class", `commit ${t.id} commit-highlight${G(n, _, h)} ${s}-outer`), e.append("rect").attr("x", r.x - 6 + (a ? 2 : 0)).attr("y", r.y - 6 + (a ? 2 : 0)).attr("width", a ? 8 : 12).attr("height", a ? 8 : 12).attr("class", `commit ${t.id} commit${G(n, _, h)} ${s}-inner`);
else if (i === x.CHERRY_PICK)
    e.append("circle").attr("cx", r.x).attr("cy", r.y).attr("r", a ? 7 : 10).attr("class", `commit ${t.id} ${s}`), e.append("circle").attr("cx", r.x - 3).attr("cy", r.y + 2).attr("r", a ? 2.5 : 2.75).attr("fill", g ? "#000000" : "#fff").attr("class", `commit ${t.id} ${s}`), e.append("circle").attr("cx", r.x + 3).attr("cy", r.y + 2).attr("r", a ? 2.5 : 2.75).attr("fill", g ? "#000000" : "#fff").attr("class", `commit ${t.id} ${s}`), e.append("line").attr("x1", r.x + 3).attr("y1", r.y + 1).attr("x2", r.x).attr("y2", r.y - 5).attr("stroke", g ? "#000000" : "#fff").attr("class", `commit ${t.id} ${s}`), e.append("line").attr("x1", r.x - 3).attr("y1", r.y + 1).attr("x2", r.x).attr("y2", r.y - 5).attr("stroke", g ? "#000000" : "#fff").attr("class", `commit ${t.id} ${s}`);
else {
    let f = e.append("circle");
    if (f.attr("cx", r.x), f.attr("cy", r.y), f.attr("r", a ? 7 : 10), f.attr("class", `commit ${t.id} commit${G(n, _, h)}`), i === x.MERGE) {
        let m = e.append("circle");
        m.attr("cx", r.x), m.attr("cy", r.y), m.attr("r", a ? 5 : 6), m.attr("class", `commit ${s} ${t.id} commit${G(n, _, h)}`);
    }
    if (i === x.REVERSE) {
        let m = e.append("path"), c = a ? 4 : 5;
        m.attr("d", `M ${r.x - c},${r.y - c}L${r.x + c},${r.y + c}M${r.x - c},${r.y + c}L${r.x + c},${r.y - c}`).attr("class", `commit ${s} ${t.id} commit${G(n, _, h)}`);
    }
} }, "drawCommitBullet"), it = l((e, t, r, s, n) => { if (t.type !== x.CHERRY_PICK && (t.customId && t.type === x.MERGE || t.type !== x.MERGE) && n.showCommitLabel) {
    let i = e.append("g"), o = i.insert("rect").attr("class", "commit-label-bkg"), a = i.append("text").attr("x", s).attr("y", r.y + 25).attr("class", "commit-label").text(t.id), h = a.node()?.getBBox();
    if (h && (o.attr("x", r.posWithOffset - h.width / 2 - P).attr("y", r.y + 13.5).attr("width", h.width + 2 * P).attr("height", h.height + 2 * P), p === "TB" || p === "BT" ? (o.attr("x", r.x - (h.width + 4 * L + 5)).attr("y", r.y - 12), a.attr("x", r.x - (h.width + 4 * L)).attr("y", r.y + h.height - 12)) : a.attr("x", r.posWithOffset - h.width / 2), n.rotateCommitLabel))
        if (p === "TB" || p === "BT")
            a.attr("transform", "rotate(-45, " + r.x + ", " + r.y + ")"), o.attr("transform", "rotate(-45, " + r.x + ", " + r.y + ")");
        else {
            let g = -7.5 - (h.width + 10) / 25 * 9.5, f = 10 + h.width / 25 * 8.5;
            i.attr("transform", "translate(" + g + ", " + f + ") rotate(-45, " + s + ", " + r.y + ")");
        }
} }, "drawCommitLabel"), dt = l((e, t, r, s) => {
    if (t.tags.length > 0) {
        let n = 0, i = 0, o = 0, a = [];
        for (let h of t.tags.reverse()) {
            let g = e.insert("polygon"), f = e.append("circle"), m = e.append("text").attr("y", r.y - 16 - n).attr("class", "tag-label").text(h), c = m.node()?.getBBox();
            if (!c)
                throw new Error("Tag bbox not found");
            i = Math.max(i, c.width), o = Math.max(o, c.height), m.attr("x", r.posWithOffset - c.width / 2), a.push({ tag: m, hole: f, rect: g, yOffset: n }), n += 20;
        }
        for (let { tag: h, hole: g, rect: f, yOffset: m } of a) {
            let c = o / 2, y = r.y - 19.2 - m;
            if (f.attr("class", "tag-label-bkg").attr("points", `
      ${s - i / 2 - L / 2},${y + P}  
      ${s - i / 2 - L / 2},${y - P}
      ${r.posWithOffset - i / 2 - L},${y - c - P}
      ${r.posWithOffset + i / 2 + L},${y - c - P}
      ${r.posWithOffset + i / 2 + L},${y + c + P}
      ${r.posWithOffset - i / 2 - L},${y + c + P}`), g.attr("cy", y).attr("cx", s - i / 2 + L / 2).attr("r", 1.5).attr("class", "tag-hole"), p === "TB" || p === "BT") {
                let $ = s + m;
                f.attr("class", "tag-label-bkg").attr("points", `
        ${r.x},${$ + 2}
        ${r.x},${$ - 2}
        ${r.x + O},${$ - c - 2}
        ${r.x + O + i + 4},${$ - c - 2}
        ${r.x + O + i + 4},${$ + c + 2}
        ${r.x + O},${$ + c + 2}`).attr("transform", "translate(12,12) rotate(45, " + r.x + "," + s + ")"), g.attr("cx", r.x + L / 2).attr("cy", $).attr("transform", "translate(12,12) rotate(45, " + r.x + "," + s + ")"), h.attr("x", r.x + 5).attr("y", $ + 3).attr("transform", "translate(14,14) rotate(45, " + r.x + "," + s + ")");
            }
        }
    }
}, "drawCommitTags"), ht = l(e => { switch (e.customType ?? e.type) {
    case x.NORMAL: return "commit-normal";
    case x.REVERSE: return "commit-reverse";
    case x.HIGHLIGHT: return "commit-highlight";
    case x.MERGE: return "commit-merge";
    case x.CHERRY_PICK: return "commit-cherry-pick";
    default: return "commit-normal";
} }, "getCommitClassType"), lt = l((e, t, r, s) => { let n = { x: 0, y: 0 }; if (e.parents.length > 0) {
    let i = Ee(e.parents);
    if (i) {
        let o = s.get(i) ?? n;
        return t === "TB" ? o.y + I : t === "BT" ? (s.get(e.id) ?? n).y - I : o.x + I;
    }
}
else
    return t === "TB" ? Y : t === "BT" ? (s.get(e.id) ?? n).y - I : 0; return 0; }, "calculatePosition"), mt = l((e, t, r) => { let s = p === "BT" && r ? t : t + O, n = C.get(e.branch)?.pos, i = p === "TB" || p === "BT" ? C.get(e.branch)?.pos : s; if (i === void 0 || n === void 0)
    throw new Error(`Position were undefined for commit ${e.id}`); let o = U.has(q().theme ?? ""), a = p === "TB" || p === "BT" ? s : n + (o ? J / 2 + 1 : -2); return { x: i, y: a, posWithOffset: s }; }, "getCommitPosition"), be = l((e, t, r, s) => { let n = e.append("g").attr("class", "commit-bullets"), i = e.append("g").attr("class", "commit-labels"), o = p === "TB" || p === "BT" ? Y : 0, a = [...t.keys()], h = s.parallelCommits ?? !1, g = l((m, c) => { let y = t.get(m)?.seq, $ = t.get(c)?.seq; return y !== void 0 && $ !== void 0 ? y - $ : 0; }, "sortKeys"), f = a.sort(g); p === "BT" && (h && rt(f, t, o), f = f.reverse()), f.forEach(m => { let c = t.get(m); if (!c)
    throw new Error(`Commit not found for key ${m}`); h && (o = lt(c, p, o, v)); let y = mt(c, o, h); if (r) {
    let $ = ht(c), u = c.customType ?? c.type, b = C.get(c.branch)?.index ?? 0;
    ct(n, c, y, $, b, u), it(i, c, y, o, s), dt(i, c, y, o);
} p === "TB" || p === "BT" ? v.set(c.id, { x: y.x, y: y.posWithOffset }) : v.set(c.id, { x: y.posWithOffset, y: y.y }), o = p === "BT" && h ? o + I : o + I + O, o > R && (R = o); }); }, "drawCommits"), gt = l((e, t, r, s, n) => { let o = (p === "TB" || p === "BT" ? r.x < s.x : r.y < s.y) ? t.branch : e.branch, a = l(g => g.branch === o, "isOnBranchToGetCurve"), h = l(g => g.seq > e.seq && g.seq < t.seq, "isBetweenCommits"); return [...n.values()].some(g => h(g) && a(g)); }, "shouldRerouteArrow"), S = l((e, t, r = 0) => { let s = e + Math.abs(e - t) / 2; if (r > 5)
    return s; if (j.every(o => Math.abs(o - s) >= 10))
    return j.push(s), s; let i = Math.abs(e - t); return S(e, t - i / 5, r + 1); }, "findLane"), ft = l((e, t, r, s) => { let { theme: n } = q(), i = ee.has(n ?? ""), o = v.get(t.id), a = v.get(r.id); if (o === void 0 || a === void 0)
    throw new Error(`Commit positions not found for commits ${t.id} and ${r.id}`); let h = gt(t, r, o, a, s), g = "", f = "", m = 0, c = 0, y = C.get(r.branch)?.index; r.type === x.MERGE && t.id !== r.parents[0] && (y = C.get(t.branch)?.index); let $; if (h) {
    g = "A 10 10, 0, 0, 0,", f = "A 10 10, 0, 0, 1,", m = 10, c = 10;
    let u = o.y < a.y ? S(o.y, a.y) : S(a.y, o.y), b = o.x < a.x ? S(o.x, a.x) : S(a.x, o.x);
    p === "TB" ? o.x < a.x ? $ = `M ${o.x} ${o.y} L ${b - m} ${o.y} ${f} ${b} ${o.y + c} L ${b} ${a.y - m} ${g} ${b + c} ${a.y} L ${a.x} ${a.y}` : (y = C.get(t.branch)?.index, $ = `M ${o.x} ${o.y} L ${b + m} ${o.y} ${g} ${b} ${o.y + c} L ${b} ${a.y - m} ${f} ${b - c} ${a.y} L ${a.x} ${a.y}`) : p === "BT" ? o.x < a.x ? $ = `M ${o.x} ${o.y} L ${b - m} ${o.y} ${g} ${b} ${o.y - c} L ${b} ${a.y + m} ${f} ${b + c} ${a.y} L ${a.x} ${a.y}` : (y = C.get(t.branch)?.index, $ = `M ${o.x} ${o.y} L ${b + m} ${o.y} ${f} ${b} ${o.y - c} L ${b} ${a.y + m} ${g} ${b - c} ${a.y} L ${a.x} ${a.y}`) : o.y < a.y ? $ = `M ${o.x} ${o.y} L ${o.x} ${u - m} ${g} ${o.x + c} ${u} L ${a.x - m} ${u} ${f} ${a.x} ${u + c} L ${a.x} ${a.y}` : (y = C.get(t.branch)?.index, $ = `M ${o.x} ${o.y} L ${o.x} ${u + m} ${f} ${o.x + c} ${u} L ${a.x - m} ${u} ${g} ${a.x} ${u - c} L ${a.x} ${a.y}`);
}
else
    g = "A 20 20, 0, 0, 0,", f = "A 20 20, 0, 0, 1,", m = 20, c = 20, p === "TB" ? (o.x < a.x && (r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${o.x} ${a.y - m} ${g} ${o.x + c} ${a.y} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${a.x - m} ${o.y} ${f} ${a.x} ${o.y + c} L ${a.x} ${a.y}`), o.x > a.x && (g = "A 20 20, 0, 0, 0,", f = "A 20 20, 0, 0, 1,", m = 20, c = 20, r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${o.x} ${a.y - m} ${f} ${o.x - c} ${a.y} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${a.x + m} ${o.y} ${g} ${a.x} ${o.y + c} L ${a.x} ${a.y}`), o.x === a.x && ($ = `M ${o.x} ${o.y} L ${a.x} ${a.y}`)) : p === "BT" ? (o.x < a.x && (r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${o.x} ${a.y + m} ${f} ${o.x + c} ${a.y} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${a.x - m} ${o.y} ${g} ${a.x} ${o.y - c} L ${a.x} ${a.y}`), o.x > a.x && (g = "A 20 20, 0, 0, 0,", f = "A 20 20, 0, 0, 1,", m = 20, c = 20, r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${o.x} ${a.y + m} ${g} ${o.x - c} ${a.y} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${a.x + m} ${o.y} ${f} ${a.x} ${o.y - c} L ${a.x} ${a.y}`), o.x === a.x && ($ = `M ${o.x} ${o.y} L ${a.x} ${a.y}`)) : (o.y < a.y && (r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${a.x - m} ${o.y} ${f} ${a.x} ${o.y + c} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${o.x} ${a.y - m} ${g} ${o.x + c} ${a.y} L ${a.x} ${a.y}`), o.y > a.y && (r.type === x.MERGE && t.id !== r.parents[0] ? $ = `M ${o.x} ${o.y} L ${a.x - m} ${o.y} ${g} ${a.x} ${o.y - c} L ${a.x} ${a.y}` : $ = `M ${o.x} ${o.y} L ${o.x} ${a.y + m} ${f} ${o.x + c} ${a.y} L ${a.x} ${a.y}`), o.y === a.y && ($ = `M ${o.x} ${o.y} L ${a.x} ${a.y}`)); if ($ === void 0)
    throw new Error("Line definition not found"); e.append("path").attr("d", $).attr("class", "arrow arrow" + G(y, _, i)); }, "drawArrow"), $t = l((e, t) => { let r = e.append("g").attr("class", "commit-arrows"); [...t.keys()].forEach(s => { let n = t.get(s); n.parents && n.parents.length > 0 && n.parents.forEach(i => { ft(r, t.get(i), n, t); }); }); }, "drawArrows"), pt = l((e, t, r, s) => { let { look: n, theme: i, themeVariables: o } = q(), { dropShadow: a, THEME_COLOR_LIMIT: h } = o, g = U.has(i ?? ""), f = ee.has(i ?? ""), m = e.append("g"); t.forEach((c, y) => { let $ = G(y, g ? h : _, f), u = C.get(c.name)?.pos; if (u === void 0)
    throw new Error(`Position not found for branch ${c.name}`); let b = p === "TB" || p === "BT" ? u : g ? u + J / 2 + 1 : u - 2, B = m.append("line"); B.attr("x1", 0), B.attr("y1", b), B.attr("x2", R), B.attr("y2", b), B.attr("class", "branch branch" + $), p === "TB" ? (B.attr("y1", Y), B.attr("x1", u), B.attr("y2", R), B.attr("x2", u)) : p === "BT" && (B.attr("y1", R), B.attr("x1", u), B.attr("y2", Y), B.attr("x2", u)), j.push(b); let V = c.name, A = ve(V), T = m.insert("rect"), M = m.insert("g").attr("class", "branchLabel").insert("g").attr("class", "label branch-label" + $); M.node().appendChild(A); let k = A.getBBox(), te = g ? 0 : 4, N = g ? 16 : 0, W = g ? J : 0; n === "neo" && T.attr("data-look", "neo"), T.attr("class", "branchLabelBkg label" + $).attr("style", n === "neo" ? `filter:${g ? `url(#${s}-drop-shadow)` : a}` : "").attr("rx", te).attr("ry", te).attr("x", -k.width - 4 - (r.rotateCommitLabel === !0 ? 30 : 0)).attr("y", -k.height / 2 + 10).attr("width", k.width + 18 + N).attr("height", k.height + 4 + W), M.attr("transform", "translate(" + (-k.width - 14 - (r.rotateCommitLabel === !0 ? 30 : 0) + N / 2) + ", " + (b - k.height / 2 - 2) + ")"), p === "TB" ? (T.attr("x", u - k.width / 2 - 10).attr("y", 0), M.attr("transform", "translate(" + (u - k.width / 2 - 5) + ", 0)"), g && (T.attr("transform", `translate(${-N / 2 - 3}, ${-W - 10})`), M.attr("transform", "translate(" + (u - k.width / 2 - 5) + ", " + (-W * 2 + 7) + ")"))) : p === "BT" ? (T.attr("x", u - k.width / 2 - 10).attr("y", R), M.attr("transform", "translate(" + (u - k.width / 2 - 5) + ", " + R + ")"), g && (T.attr("transform", `translate(${-N / 2 - 3}, ${W + 10})`), M.attr("transform", "translate(" + (u - k.width / 2 - 5) + ", " + (R + W * 2 + 4) + ")"))) : T.attr("transform", "translate(-19, " + (b - 12 - W / 2) + ")"); }); }, "drawBranches"), yt = l(function (e, t, r, s, n) { return C.set(e, { pos: t, index: r }), t += 50 + (n ? 40 : 0) + (p === "TB" || p === "BT" ? s.width / 2 : 0), t; }, "setBranchPosition"), xt = l(function (e, t, r, s) {
    et(), w.debug("in gitgraph renderer", e + `
`, "id:", t, r);
    let n = s.db;
    if (!n.getConfig) {
        w.error("getConfig method is not available on db");
        return;
    }
    let i = n.getConfig(), o = i.rotateCommitLabel ?? !1;
    H = n.getCommits();
    let a = n.getBranchesAsObjArray();
    p = n.getDirection();
    let h = ge(`[id="${t}"]`), { look: g, theme: f, themeVariables: m } = q(), { useGradient: c, gradientStart: y, gradientStop: $, filterColor: u } = m;
    if (c) {
        let B = h.append("defs").append("linearGradient").attr("id", t + "-gradient").attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
        B.append("stop").attr("offset", "0%").attr("stop-color", y).attr("stop-opacity", 1), B.append("stop").attr("offset", "100%").attr("stop-color", $).attr("stop-opacity", 1);
    }
    g === "neo" && U.has(f ?? "") && h.append("defs").append("filter").attr("id", t + "-drop-shadow").attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", u);
    let b = 0;
    a.forEach((B, V) => { let A = ve(B.name), T = h.append("g"), Z = T.insert("g").attr("class", "branchLabel"), M = Z.insert("g").attr("class", "label branch-label"); M.node()?.appendChild(A); let k = A.getBBox(); b = yt(B.name, b, V, k, o), M.remove(), Z.remove(), T.remove(); }), be(h, H, !1, i), i.showBranches && pt(h, a, i, t), $t(h, H), be(h, H, !0, i), pe.insertTitle(h, "gitTitleText", i.titleTopMargin ?? 0, n.getDiagramTitle()), me(void 0, h, i.diagramPadding, i.useMaxWidth);
}, "draw"), ut = { draw: xt }, Te = 8, Le = new Set(["redux", "redux-dark", "redux-color", "redux-dark-color"]), bt = new Set(["redux-color", "redux-dark-color"]), wt = new Set(["neo", "neo-dark"]), Bt = new Set(["dark", "redux-dark", "redux-dark-color", "neo-dark"]), kt = new Set(["redux", "redux-dark", "redux-color", "redux-dark-color", "neo", "neo-dark"]), Ct = l(e => {
    let { svgId: t } = e, r = "";
    if (e.useGradient && t)
        for (let s = 0; s < e.THEME_COLOR_LIMIT; s++)
            r += `
      .label${s}  { fill: ${e.mainBkg}; stroke: url(${t}-gradient); stroke-width: ${e.strokeWidth};}
             `;
    return r;
}, "genGitGraphGradient"), vt = l(e => {
    let t = z(), { theme: r, themeVariables: s } = t, { borderColorArray: n } = s, i = Le.has(r);
    if (wt.has(r)) {
        let o = "";
        for (let a = 0; a < e.THEME_COLOR_LIMIT; a++)
            if (a === 0)
                o += `
        .branch-label${a} { fill: ${e.nodeBorder};}
        .commit${a} { stroke: ${e.nodeBorder};   }
        .commit-highlight${a} { stroke: ${e.nodeBorder}; fill: ${e.nodeBorder}; }
        .arrow${a} { stroke: ${e.nodeBorder}; }
        .commit-bullets { fill: ${e.nodeBorder}; }
        .commit-cherry-pick${a} { stroke: ${e.nodeBorder}; }
        ${Ct(e)}`;
            else {
                let h = a % Te;
                o += `
        .branch-label${a} { fill: ${e["gitBranchLabel" + h]}; }
        .commit${a} { stroke: ${e["git" + h]}; fill: ${e["git" + h]}; }
        .commit-highlight${a} { stroke: ${e["gitInv" + h]}; fill: ${e["gitInv" + h]}; }
        .arrow${a} { stroke: ${e["git" + h]}; }
        `;
            }
        return o;
    }
    else if (bt.has(r)) {
        let o = "";
        for (let a = 0; a < e.THEME_COLOR_LIMIT; a++)
            if (a === 0)
                o += `
        .branch-label${a} { fill: ${e.nodeBorder}; ${i ? `font-weight:${e.noteFontWeight}` : ""} }
        .commit${a} { stroke: ${e.nodeBorder}; }
        .commit-highlight${a} { stroke: ${e.nodeBorder}; fill: ${e.mainBkg}; }
        .label${a}  { fill: ${e.mainBkg}; stroke: ${e.nodeBorder}; stroke-width: ${e.strokeWidth}; ${i ? `font-weight:${e.noteFontWeight}` : ""} }
        .arrow${a} { stroke: ${e.nodeBorder}; }
        .commit-bullets { fill: ${e.nodeBorder}; }
        `;
            else {
                let h = a % n.length;
                o += `
        .branch-label${a} { fill: ${e.nodeBorder}; ${i ? `font-weight:${e.noteFontWeight}` : ""} }
        .commit${a} { stroke: ${n[h]}; fill: ${n[h]}; }
        .commit-highlight${a} { stroke: ${n[h]}; fill: ${n[h]}; }
        .label${a}  { fill: ${Bt.has(r) ? e.mainBkg : n[h]}; stroke: ${n[h]};  stroke-width: ${e.strokeWidth}; }
        .arrow${a} { stroke: ${n[h]}; }
        `;
            }
        return o;
    }
    else {
        let o = "";
        for (let a = 0; a < e.THEME_COLOR_LIMIT; a++)
            o += `
        .branch-label${a} { fill: ${e.nodeBorder}; ${i ? `font-weight:${e.noteFontWeight}` : ""} }
        .commit${a} { stroke: ${e.nodeBorder};   }
        .commit-highlight${a} { stroke: ${e.nodeBorder}; fill: ${e.nodeBorder}; }
        .label${a}  { fill: ${e.mainBkg}; stroke: ${e.nodeBorder}; stroke-width: ${e.strokeWidth}; ${i ? `font-weight:${e.noteFontWeight}` : ""}}
        .arrow${a} { stroke: ${e.nodeBorder}; }
        .commit-bullets { fill: ${e.nodeBorder}; }
        .commit-cherry-pick${a} { stroke: ${e.nodeBorder}; }
        `;
        return o;
    }
}, "genColor"), Et = l(e => `${Array.from({ length: e.THEME_COLOR_LIMIT }, (t, r) => r).map(t => {
    let r = t % Te;
    return `
        .branch-label${t} { fill: ${e["gitBranchLabel" + r]}; }
        .commit${t} { stroke: ${e["git" + r]}; fill: ${e["git" + r]}; }
        .commit-highlight${t} { stroke: ${e["gitInv" + r]}; fill: ${e["gitInv" + r]}; }
        .label${t}  { fill: ${e["git" + r]}; }
        .arrow${t} { stroke: ${e["git" + r]}; }
        `;
}).join(`
`)}`, "normalTheme"), Tt = l(e => {
    let t = z(), { theme: r } = t, s = kt.has(r);
    return `
  .commit-id,
  .commit-msg,
  .branch-label {
    fill: lightgrey;
    color: lightgrey;
    font-family: 'trebuchet ms', verdana, arial, sans-serif;
    font-family: var(--mermaid-font-family);
  }
  
  ${s ? vt(e) : Et(e)}

  .branch {
    stroke-width: ${e.strokeWidth};
    stroke: ${e.commitLineColor ?? e.lineColor};
    stroke-dasharray:  ${s ? "4 2" : "2"};
  }
  .commit-label { font-size: ${e.commitLabelFontSize}; fill: ${s ? e.nodeBorder : e.commitLabelColor}; ${s ? `font-weight:${e.noteFontWeight};` : ""}}
  .commit-label-bkg { font-size: ${e.commitLabelFontSize}; fill: ${s ? "transparent" : e.commitLabelBackground}; opacity: ${s ? "" : .5};  }
  .tag-label { font-size: ${e.tagLabelFontSize}; fill: ${e.tagLabelColor};}
  .tag-label-bkg { fill: ${s ? e.mainBkg : e.tagLabelBackground}; stroke: ${s ? e.nodeBorder : e.tagLabelBorder}; ${s ? `filter:${e.dropShadow}` : ""}  }
  .tag-hole { fill: ${e.textColor}; }

  .commit-merge {
    stroke: ${s ? e.mainBkg : e.primaryColor};
    fill: ${s ? e.mainBkg : e.primaryColor};
  }
  .commit-reverse {
    stroke: ${s ? e.mainBkg : e.primaryColor};
    fill: ${s ? e.mainBkg : e.primaryColor};
    stroke-width: ${s ? e.strokeWidth : 3};
  }
  .commit-highlight-outer {
  }
  .commit-highlight-inner {
    stroke: ${s ? e.mainBkg : e.primaryColor};
    fill: ${s ? e.mainBkg : e.primaryColor};
  }

  .arrow {
    /* Intentional: neo themes keep the bold 8px arrow (like classic themes); only redux-geometry themes use the thinner options.strokeWidth. */
    stroke-width: ${Le.has(r) ? e.strokeWidth : 8};
    stroke-linecap: round;
    fill: none
  }
  .gitTitleText {
    text-anchor: middle;
    font-size: 18px;
    fill: ${e.textColor};
  }
`;
}, "getStyles"), Lt = Tt, Wt = { parser: Je, db: Ce, renderer: ut, styles: Lt };
export { Wt as diagram };
