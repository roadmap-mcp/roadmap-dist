import { C as x } from "@nf-internal/chunk-LUZVEH3G";
import { a as O, b as F } from "@nf-internal/chunk-PFHS2QSV";
import { b as S, c as y, d as j, e as P, f as k, h as H, i as z } from "@nf-internal/chunk-ST43FWUC";
import { a as $, b as A, d as _, e as D } from "@nf-internal/chunk-JKFADCWD";
import { a as G } from "@nf-internal/chunk-VEDGZ2C2";
import { p as w } from "@nf-internal/chunk-FDRUJGNH";
import { _ as X, u as M } from "@nf-internal/chunk-LEJRRF65";
import { b as l } from "@nf-internal/chunk-RZWXGGKD";
import { a as u } from "@nf-internal/chunk-YUSHYV7C";
import { a as h, b as B, f as m } from "@nf-internal/chunk-OSQMNGTH";
function W(e, { edgePathsClass: n = "edges edgePaths" } = {}) { let t = e.insert("g").attr("class", "root"), s = t.insert("g").attr("class", "clusters"), r = t.insert("g").attr("class", n), i = t.insert("g").attr("class", "edgeLabels"), a = t.insert("g").attr("class", "nodes"); return { clusters: s, edgePaths: r, edgeLabels: i, nodes: a, rootGroups: t }; }
u(W, "createLayoutElementGroups");
function q(e, n) { return m(this, null, function* () { if (n.label) {
    let { shapeSvg: t, bbox: s } = yield G(e, n);
    n.labelBBox = { width: s.width, height: s.height }, t.remove();
}
else
    n.labelBBox = { width: 0, height: 0 }; }); }
u(q, "measureGroupLabel");
function K(e, n, t) { return m(this, null, function* () { let s = yield A(e, n, t), r = s.node()?.getBBox() ?? { width: 0, height: 0 }; return n.width = r.width, n.height = r.height, s; }); }
u(K, "insertMeasuredNode");
function Q(e, n) { return m(this, null, function* () { let t = new x({ multigraph: !0, compound: !0 }), s = [...n.edges], r = X(), i = W(e), { edgeLabels: a, nodes: f } = i, o = new Map, g = e.node() != null; yield Promise.all(n.nodes.map(d => m(null, null, function* () { if (d.isGroup)
    g && (yield q(f, d)), t.setNode(d.id, h({}, d));
else {
    if (g) {
        let C = yield K(f, d, { config: r, dir: d.dir });
        o.set(d.id, C);
    }
    t.setNode(d.id, h({}, d));
} }))); for (let d of s)
    g && P(d) && (yield k(a, d)), t.setEdge(d.start, d.end, h({}, d), d.id), n.edges.some(E => E.id === d.id) || n.edges.push(d); if (globalThis.mermaidCaptureSizes) {
    let { captureNodeSizes: d } = yield import("@nf-internal/sizeCapture-INFHLROL-3WDZBHFC");
    d(e, n);
} return { graph: t, groups: i, nodeElements: o }; }); }
u(Q, "createGraphWithElements");
var c = new Map, b = new Map, U = new Map, ge = u(() => { b.clear(), U.clear(), c.clear(); }, "clear"), v = u((e, n) => { let t = b.get(n) || []; return l.trace("In isDescendant", n, " ", e, " = ", t.includes(e)), t.includes(e); }, "isDescendant"), me = u((e, n) => { let t = b.get(n) || []; return l.info("Descendants of ", n, " is ", t), l.info("Edge is ", e), e.v === n || e.w === n ? !1 : t ? t.includes(e.v) || v(e.v, n) || v(e.w, n) || t.includes(e.w) : (l.debug("Tilt, ", n, ",not in descendants"), !1); }, "edgeInCluster"), V = u((e, n, t, s) => { l.debug("Copying children of ", e, "root", s, "data", n.node(e), s); let r = n.children(e) || []; e !== s && r.push(e), l.debug("Copying (nodes) clusterId", e, "nodes", r), r.forEach(i => { if (n.children(i).length > 0)
    V(i, n, t, s);
else {
    let a = n.node(i);
    l.info("cp ", i, " to ", s, " with parent ", e), t.setNode(i, a), s !== n.parent(i) && (l.debug("Setting parent", i, n.parent(i)), t.setParent(i, n.parent(i))), e !== s && i !== e ? (l.debug("Setting parent", i, e), t.setParent(i, e)) : (l.info("In copy ", e, "root", s, "data", n.node(e), s), l.debug("Not Setting parent for node=", i, "cluster!==rootId", e !== s, "node!==clusterId", i !== e));
    let f = n.edges(i);
    l.debug("Copying Edges", f), f.forEach(o => { l.info("Edge", o); let g = n.edge(o.v, o.w, o.name); l.info("Edge data", g, s); try {
        me(o, s) ? (l.info("Copying as ", o.v, o.w, g, o.name), t.setEdge(o.v, o.w, g, o.name), l.info("newGraph edges ", t.edges(), t.edge(t.edges()[0]))) : l.info("Skipping copy of edge ", o.v, "-->", o.w, " rootId: ", s, " clusterId:", e);
    }
    catch (d) {
        l.error(d);
    } });
} l.debug("Removing node", i), n.removeNode(i); }); }, "copy"), Y = u((e, n) => { let t = n.children(e), s = [...t]; for (let r of t)
    U.set(r, e), s = [...s, ...Y(r, n)]; return s; }, "extractDescendants"), be = u((e, n, t) => { let s = e.edges().filter(o => o.v === n || o.w === n), r = e.edges().filter(o => o.v === t || o.w === t), i = s.map(o => ({ v: o.v === n ? t : o.v, w: o.w === n ? n : o.w })), a = r.map(o => ({ v: o.v, w: o.w })); return i.filter(o => a.some(g => o.v === g.v && o.w === g.w)); }, "findCommonEdges"), N = u((e, n, t) => { let s = n.children(e); if (l.trace("Searching children of id ", e, s), s.length < 1)
    return e; let r; for (let i of s) {
    let a = N(i, n, t), f = be(n, t, a);
    if (a)
        if (f.length > 0)
            r = a;
        else
            return a;
} return r; }, "findNonClusterChild"), J = u(e => !c.has(e) || !c.get(e).externalConnections ? e : c.has(e) ? c.get(e).id : e, "getAnchorId"), De = u((e, n) => { if (!e || n > 10) {
    l.debug("Opting out, no graph ");
    return;
}
else
    l.debug("Opting in, graph "); e.nodes().forEach(function (t) { e.children(t).length > 0 && (l.debug("Cluster identified", t, " Replacement id in edges: ", N(t, e, t)), b.set(t, Y(t, e)), c.set(t, { id: N(t, e, t), clusterData: e.node(t) })); }), e.nodes().forEach(function (t) { let s = e.children(t), r = e.edges(); s.length > 0 ? (l.debug("Cluster identified", t, b), r.forEach(i => { let a = v(i.v, t), f = v(i.w, t); a ^ f && (l.debug("Edge: ", i, " leaves cluster ", t), l.debug("Descendants of XXX ", t, ": ", b.get(t)), c.get(t).externalConnections = !0); })) : l.debug("Not a cluster ", t, b); }); for (let t of c.keys()) {
    let s = c.get(t).id, r = e.parent(s);
    r !== t && c.has(r) && !c.get(r).externalConnections && (c.get(t).id = r);
    let i = e.edges().some(a => a.v === t);
    if (s && c.get(t)?.externalConnections && i && ee(e, s, t)) {
        let a = he(e, t, e.parent(s));
        a && (c.get(t).id = a);
    }
} e.edges().forEach(function (t) { let s = e.edge(t); l.debug("Edge " + t.v + " -> " + t.w + ": " + JSON.stringify(t)), l.debug("Edge " + t.v + " -> " + t.w + ": " + JSON.stringify(e.edge(t))); let r = t.v, i = t.w; if (l.debug("Fix XXX", c, "ids:", t.v, t.w, "Translating: ", c.get(t.v), " --- ", c.get(t.w)), c.get(t.v) || c.get(t.w)) {
    if (l.debug("Fixing and trying - removing XXX", t.v, t.w, t.name), r = J(t.v), i = J(t.w), e.removeEdge(t.v, t.w, t.name), r !== t.v) {
        let a = e.parent(r);
        c.get(a).externalConnections = !0, s.fromCluster = t.v;
    }
    if (i !== t.w) {
        let a = e.parent(i);
        c.get(a).externalConnections = !0, s.toCluster = t.w;
    }
    l.debug("Fix Replacing with XXX", r, i, t.name), e.setEdge(r, i, s, t.name);
} }), Z(e, 0), l.trace(c); }, "adjustClustersAndEdges"), Z = u((e, n) => { if (n > 10) {
    l.error("Bailing out");
    return;
} let t = e.nodes(), s = !1; for (let r of t) {
    let i = e.children(r);
    s = s || i.length > 0;
} if (!s) {
    l.debug("Done, no node has children", e.nodes());
    return;
} l.debug("Nodes = ", t, n); for (let r of t)
    if (l.debug("Extracting node", r, c, c.has(r) && !c.get(r).externalConnections, !e.parent(r), e.node(r), e.children("D"), " Depth ", n), !c.has(r))
        l.debug("Not a cluster", r, n);
    else if (!c.get(r).externalConnections && e.children(r) && e.children(r).length > 0) {
        l.debug("Cluster without external connections, without a parent and with children", r, n);
        let a = e.graph().rankdir === "TB" ? "LR" : "TB";
        c.get(r)?.clusterData?.dir && (a = c.get(r).clusterData.dir, l.debug("Fixing dir", c.get(r).clusterData.dir, a));
        let f = new x({ multigraph: !0, compound: !0 }).setGraph({ rankdir: a, nodesep: 50, ranksep: 50, marginx: 8, marginy: 8 }).setDefaultEdgeLabel(function () { return {}; });
        V(r, e, f, r), e.setNode(r, { clusterNode: !0, id: r, clusterData: c.get(r).clusterData, label: c.get(r).label, graph: f });
    }
    else
        l.debug("Cluster ** ", r, " **not meeting the criteria !externalConnections:", !c.get(r).externalConnections, " no parent: ", !e.parent(r), " children ", e.children(r) && e.children(r).length > 0, e.children("D"), n), l.debug(c); t = e.nodes(), l.debug("New list of nodes", t); for (let r of t) {
    let i = e.node(r);
    l.debug(" Now next level", r, i), i?.clusterNode && Z(i.graph, n + 1);
} }, "extractor"), I = u((e, n) => { if (n.length === 0)
    return []; let t = Object.assign([], n); return n.forEach(s => { let r = e.children(s), i = I(e, r); t = [...t, ...i]; }), t; }, "sorter"), Se = u(e => I(e, e.children()), "sortNodesByHierarchy"), ee = u((e, n, t) => { let s = e.parent(n); for (; s && s !== t;) {
    let r = c.get(s);
    if (r && !r.externalConnections)
        return !0;
    s = e.parent(s);
} return !1; }, "isNodeInExtractableCluster"), he = u((e, n, t) => { let s = e.children(n) ?? []; for (let r of s) {
    if (r === t || v(r, t))
        continue;
    let i = N(r, e, n);
    if (i && !ee(e, i, n))
        return i;
} return null; }, "findSafeAnchorNode");
function we({ prepareLayout: e, measureLayout: n, runLayoutCore: t, paintLayout: s, afterPaint: r, paintOptions: i }) { let a = n ?? ne; return u(function (o, g, d, C) { return m(this, null, function* () { let E = g.select("g"); (d?.insertMarkers ?? z)(E, o.markers, o.type, o.diagramId), te(); let p = { element: E, helpers: d, options: C }; p.preparedLayout = yield e?.(o, p); let ue = yield a(o, p), T = yield t(o, p), L = B(h({}, p), { measure: ue }); s ? yield s(o, L, T) : yield re(o, L, i), yield r?.(o, L, T); }); }, "render"); }
u(we, "createCommonLayoutRenderer");
function te() { _(), j(), F(), ge(); }
u(te, "clearLayoutRenderState");
function ne(t, s) { return m(this, arguments, function* (e, { element: n }) { return yield Q(n, e); }); }
u(ne, "defaultMeasureLayout");
function re(s, r) { return m(this, arguments, function* (e, n, t = {}) { let { measure: i } = n, { groups: a } = i; for (let o of t.getNodes?.(e, n) ?? e.nodes)
    t.skipNode?.(o, n) || (yield se(a, o, n, t)); let f = oe(e.nodes); for (let o of e.edges)
    ae(o, t) || (yield le(a, o, f, e, t, n)); }); }
u(re, "paintLayoutData");
function se(e, n, t, s) { return m(this, null, function* () { n.clusterNode ? D(n) : ie(n, t, s) ? yield O(e.clusters, n) : D(n); }); }
u(se, "paintLayoutNode");
function ie(e, n, t) { return e.isGroup === !0 && (t.isCluster?.(e, n) ?? !0); }
u(ie, "shouldPaintAsCluster");
function oe(e) { let n = new Map; for (let t of e)
    t?.id && n.set(t.id, t); return n; }
u(oe, "buildNodeLookup");
function ae(e, n) { return e.isLayoutOnly || !!n.skipEdge?.(e); }
u(ae, "shouldSkipPaintEdge");
function le(e, n, t, s, r, i) { return m(this, null, function* () { let a = H(e.edgePaths, h({}, n), r.clusterDb ?? new Map, s.type, R(n.start, n, t, i, r), R(n.end, n, t, i, r), s.diagramId, ce(n, r)); P(n) && (S.has(n.id) || (yield k(e.edgeLabels, n)), fe(n, a)); }); }
u(le, "paintLayoutEdge");
function R(e, n, t, s, r) { return r.getEdgeNode?.(e, n, s) ?? (e ? t.get(e) ?? {} : {}); }
u(R, "getRenderedNode");
function ce(e, n) { return typeof n.skipIntersect == "function" ? n.skipIntersect(e) : n.skipIntersect ?? !1; }
u(ce, "shouldSkipIntersect");
function fe(e, n) { let t = n?.updatedPath ?? n?.originalPath, s = M(), { subGraphTitleTotalMargin: r } = $({ flowchart: s.flowchart ?? {} }); if (e.label) {
    let i = S.get(e.id), a = e.x, f = e.y;
    if (t) {
        let o = w.calcLabelPosition(t);
        l.debug("Moving label " + e.label + " from (", a, ",", f, ") to (", o.x, ",", o.y, ") abc88"), n?.updatedPath && (a = o.x, f = o.y);
    }
    i.attr("transform", `translate(${a}, ${f + r / 2})`);
} if (e?.startLabelLeft) {
    let i = y.get(e.id).startLeft, a = e?.x, f = e?.y;
    if (t) {
        let o = w.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_left", t);
        a = o.x, f = o.y;
    }
    i.attr("transform", `translate(${a}, ${f})`);
} if (e.startLabelRight) {
    let i = y.get(e.id).startRight, a = e.x, f = e.y;
    if (t) {
        let o = w.calcTerminalLabelPosition(e.arrowTypeStart ? 10 : 0, "start_right", t);
        a = o.x, f = o.y;
    }
    i.attr("transform", `translate(${a}, ${f})`);
} if (e.endLabelLeft) {
    let i = y.get(e.id).endLeft, a = e.x, f = e.y;
    if (t) {
        let o = w.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_left", t);
        a = o.x, f = o.y;
    }
    i.attr("transform", `translate(${a}, ${f})`);
} if (e.endLabelRight) {
    let i = y.get(e.id).endRight, a = e.x, f = e.y;
    if (t) {
        let o = w.calcTerminalLabelPosition(e.arrowTypeEnd ? 10 : 0, "end_right", t);
        a = o.x, f = o.y;
    }
    i.attr("transform", `translate(${a}, ${f})`);
} }
u(fe, "positionRenderedEdgeLabel");
export { W as a, K as b, c, N as d, De as e, Se as f, we as g, te as h, ne as i, re as j };
