import { a as t, b as s, c as u, d as i, e as n, g as o, h as l, w as d, y as h } from "@nf-internal/chunk-EPGORQP5";
var m = class extends h {
    static { t(this, "ArchitectureTokenBuilder"); }
    constructor() { super(["architecture"]); }
}, A = class extends d {
    static { t(this, "ArchitectureValueConverter"); }
    runCustomConverter(c, r, a) { if (c.name === "ARCH_ICON")
        return r.replace(/[()]/g, "").trim(); if (c.name === "ARCH_TEXT_ICON")
        return r.replace(/["()]/g, ""); if (c.name === "ARCH_TITLE") {
        let e = r.replace(/^\[|]$/g, "").trim();
        return (e.startsWith('"') && e.endsWith('"') || e.startsWith("'") && e.endsWith("'")) && (e = e.slice(1, -1), e = e.replace(/\\"/g, '"').replace(/\\'/g, "'")), e.trim();
    } }
}, C = { parser: { TokenBuilder: t(() => new m, "TokenBuilder"), ValueConverter: t(() => new A, "ValueConverter") } };
function v(c = n) { let r = i(u(c), o), a = i(s({ shared: r }), l, C); return r.ServiceRegistry.register(a), { shared: r, Architecture: a }; }
t(v, "createArchitectureServices");
export { C as a, v as b };
