import { a as $ } from "@nf-internal/chunk-QLER3HO2";
import { i as q, l as K, r as X } from "@nf-internal/chunk-UYYL2GTR";
import "@nf-internal/chunk-FVDLKYOC";
import { b as Q, c as W } from "@nf-internal/chunk-SMAQMSIK";
import { a as te, b as E } from "@nf-internal/chunk-AWGKBVI5";
import { a as j } from "@nf-internal/chunk-7RHXFCZM";
import "@nf-internal/chunk-5HDY5C2T";
import { c as V } from "@nf-internal/chunk-6QY5OUOO";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-OSQMNGTH";
import * as s from "@angular/core";
import { InjectionToken as H, inject as l, ElementRef as p, TemplateRef as C, booleanAttribute as g, IterableDiffers as T, ViewContainerRef as O, afterNextRender as x, ChangeDetectorRef as oe, Injector as ie, DOCUMENT as se, EventEmitter as ne, HostAttributeToken as re } from "@angular/core";
import { Subject as S, BehaviorSubject as ae, isObservable as le, of as Y, combineLatest as N, animationFrameScheduler as ce, asapScheduler as de } from "rxjs";
import { takeUntil as D, auditTime as ue } from "rxjs/operators";
import "@angular/common";
var he = [[["caption"]], [["colgroup"], ["col"]], "*"], fe = ["caption", "colgroup, col", "*"];
function _e(i, a) { i & 1 && s.\u0275\u0275projection(0, 2); }
function me(i, a) { i & 1 && (s.\u0275\u0275elementStart(0, "thead", 0), s.\u0275\u0275elementContainer(1, 1), s.\u0275\u0275elementEnd(), s.\u0275\u0275elementStart(2, "tbody", 0), s.\u0275\u0275elementContainer(3, 2)(4, 3), s.\u0275\u0275elementEnd(), s.\u0275\u0275elementStart(5, "tfoot", 0), s.\u0275\u0275elementContainer(6, 4), s.\u0275\u0275elementEnd()); }
function ye(i, a) { i & 1 && s.\u0275\u0275elementContainer(0, 1)(1, 2)(2, 3)(3, 4); }
function we(i, a) { if (i & 1 && (s.\u0275\u0275elementStart(0, "th", 3), s.\u0275\u0275text(1), s.\u0275\u0275elementEnd()), i & 2) {
    let e = s.\u0275\u0275nextContext();
    s.\u0275\u0275styleProp("text-align", e.justify), s.\u0275\u0275advance(), s.\u0275\u0275textInterpolate1(" ", e.headerText, " ");
} }
function Re(i, a) { if (i & 1 && (s.\u0275\u0275elementStart(0, "td", 4), s.\u0275\u0275text(1), s.\u0275\u0275elementEnd()), i & 2) {
    let e = a.$implicit, t = s.\u0275\u0275nextContext();
    s.\u0275\u0275styleProp("text-align", t.justify), s.\u0275\u0275advance(), s.\u0275\u0275textInterpolate1(" ", t.dataAccessor(e, t.name), " ");
} }
var R = new H("CDK_TABLE"), pe = new H("text-column-options"), I = (() => { class i {
    template = l(C);
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkCellDef", ""]] });
} return i; })(), A = (() => { class i {
    template = l(C);
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkHeaderCellDef", ""]] });
} return i; })(), Ce = (() => { class i {
    template = l(C);
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkFooterCellDef", ""]] });
} return i; })(), k = (() => { class i {
    _table = l(R, { optional: !0 });
    _hasStickyChanged = !1;
    get name() { return this._name; }
    set name(e) { this._setNameInput(e); }
    _name;
    get sticky() { return this._sticky; }
    set sticky(e) { e !== this._sticky && (this._sticky = e, this._hasStickyChanged = !0); }
    _sticky = !1;
    get stickyEnd() { return this._stickyEnd; }
    set stickyEnd(e) { e !== this._stickyEnd && (this._stickyEnd = e, this._hasStickyChanged = !0); }
    _stickyEnd = !1;
    cell;
    headerCell;
    footerCell;
    cssClassFriendlyName;
    _columnCssClassName;
    constructor() { }
    hasStickyChanged() { let e = this._hasStickyChanged; return this.resetStickyChanged(), e; }
    resetStickyChanged() { this._hasStickyChanged = !1; }
    _updateColumnCssClassName() { this._columnCssClassName = [`cdk-column-${this.cssClassFriendlyName}`]; }
    _setNameInput(e) { e && (this._name = e, this.cssClassFriendlyName = e.replace(/[^a-z0-9_-]/gi, "-"), this._updateColumnCssClassName()); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkColumnDef", ""]], contentQueries: function (t, o, n) { if (t & 1 && s.\u0275\u0275contentQuery(n, I, 5)(n, A, 5)(n, Ce, 5), t & 2) {
            let r;
            s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o.cell = r.first), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o.headerCell = r.first), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o.footerCell = r.first);
        } }, inputs: { name: [0, "cdkColumnDef", "name"], sticky: [2, "sticky", "sticky", g], stickyEnd: [2, "stickyEnd", "stickyEnd", g] } });
} return i; })(), v = class {
    constructor(a, e) { e.nativeElement.classList.add(...a._columnCssClassName); }
}, ge = (() => { class i extends v {
    constructor() { super(l(k), l(p)); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["cdk-header-cell"], ["th", "cdk-header-cell", ""]], hostAttrs: ["role", "columnheader", 1, "cdk-header-cell"], features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), Ze = (() => { class i extends v {
    constructor() { let e = l(k), t = l(p); super(e, t); let o = e._table?._getCellRole(); o && t.nativeElement.setAttribute("role", o); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["cdk-footer-cell"], ["td", "cdk-footer-cell", ""]], hostAttrs: [1, "cdk-footer-cell"], features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), De = (() => { class i extends v {
    constructor() { let e = l(k), t = l(p); super(e, t); let o = e._table?._getCellRole(); o && t.nativeElement.setAttribute("role", o); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["cdk-cell"], ["td", "cdk-cell", ""]], hostAttrs: [1, "cdk-cell"], features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), Ge = "<ng-container cdkCellOutlet></ng-container>", z = (() => { class i {
    template = l(C);
    _differs = l(T);
    columns;
    _columnsDiffer;
    constructor() { }
    ngOnChanges(e) { if (!this._columnsDiffer) {
        let t = e.columns && e.columns.currentValue || [];
        this._columnsDiffer = this._differs.find(t).create(), this._columnsDiffer.diff(t);
    } }
    getColumnsDiff() { return this._columnsDiffer.diff(this.columns); }
    extractCellTemplate(e) { return this instanceof J ? e.headerCell.template : this instanceof ee ? e.footerCell.template : e.cell.template; }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, features: [s.\u0275\u0275NgOnChangesFeature] });
} return i; })(), J = (() => { class i extends z {
    _table = l(R, { optional: !0 });
    _hasStickyChanged = !1;
    get sticky() { return this._sticky; }
    set sticky(e) { e !== this._sticky && (this._sticky = e, this._hasStickyChanged = !0); }
    _sticky = !1;
    constructor() { super(l(C), l(T)); }
    ngOnChanges(e) { super.ngOnChanges(e); }
    hasStickyChanged() { let e = this._hasStickyChanged; return this.resetStickyChanged(), e; }
    resetStickyChanged() { this._hasStickyChanged = !1; }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkHeaderRowDef", ""]], inputs: { columns: [0, "cdkHeaderRowDef", "columns"], sticky: [2, "cdkHeaderRowDefSticky", "sticky", g] }, features: [s.\u0275\u0275InheritDefinitionFeature, s.\u0275\u0275NgOnChangesFeature] });
} return i; })(), ee = (() => { class i extends z {
    _table = l(R, { optional: !0 });
    _hasStickyChanged = !1;
    get sticky() { return this._sticky; }
    set sticky(e) { e !== this._sticky && (this._sticky = e, this._hasStickyChanged = !0); }
    _sticky = !1;
    constructor() { super(l(C), l(T)); }
    ngOnChanges(e) { super.ngOnChanges(e); }
    hasStickyChanged() { let e = this._hasStickyChanged; return this.resetStickyChanged(), e; }
    resetStickyChanged() { this._hasStickyChanged = !1; }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkFooterRowDef", ""]], inputs: { columns: [0, "cdkFooterRowDef", "columns"], sticky: [2, "cdkFooterRowDefSticky", "sticky", g] }, features: [s.\u0275\u0275InheritDefinitionFeature, s.\u0275\u0275NgOnChangesFeature] });
} return i; })(), ke = (() => { class i extends z {
    _table = l(R, { optional: !0 });
    when;
    constructor() { super(l(C), l(T)); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkRowDef", ""]], inputs: { columns: [0, "cdkRowDefColumns", "columns"], when: [0, "cdkRowDefWhen", "when"] }, features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), b = (() => { class i {
    _viewContainer = l(O);
    cells;
    context;
    static mostRecentCellOutlet = null;
    constructor() { i.mostRecentCellOutlet = this; }
    ngOnDestroy() { i.mostRecentCellOutlet === this && (i.mostRecentCellOutlet = null); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkCellOutlet", ""]] });
} return i; })(), Je = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-header-row"], ["tr", "cdk-header-row", ""]], hostAttrs: ["role", "row", 1, "cdk-header-row"], decls: 1, vars: 0, consts: [["cdkCellOutlet", ""]], template: function (t, o) { t & 1 && s.\u0275\u0275elementContainer(0, 0); }, dependencies: [b], encapsulation: 2 });
} return i; })(), et = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-footer-row"], ["tr", "cdk-footer-row", ""]], hostAttrs: ["role", "row", 1, "cdk-footer-row"], decls: 1, vars: 0, consts: [["cdkCellOutlet", ""]], template: function (t, o) { t & 1 && s.\u0275\u0275elementContainer(0, 0); }, dependencies: [b], encapsulation: 2 });
} return i; })(), tt = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-row"], ["tr", "cdk-row", ""]], hostAttrs: ["role", "row", 1, "cdk-row"], decls: 1, vars: 0, consts: [["cdkCellOutlet", ""]], template: function (t, o) { t & 1 && s.\u0275\u0275elementContainer(0, 0); }, dependencies: [b], encapsulation: 2 });
} return i; })(), Se = (() => { class i {
    templateRef = l(C);
    _contentClassNames = ["cdk-no-data-row", "cdk-row"];
    _cellClassNames = ["cdk-cell", "cdk-no-data-cell"];
    _cellSelector = "td, cdk-cell, [cdk-cell], .cdk-cell";
    constructor() { }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["ng-template", "cdkNoDataRow", ""]] });
} return i; })(), Z = ["top", "bottom", "left", "right"], L = class {
    _isNativeHtmlTable;
    _stickCellCss;
    _isBrowser;
    _needsPositionStickyOnElement;
    direction;
    _positionListener;
    _tableInjector;
    _elemSizeCache = new WeakMap;
    _resizeObserver = globalThis?.ResizeObserver ? new globalThis.ResizeObserver(a => this._updateCachedSizes(a)) : null;
    _updatedStickyColumnsParamsToReplay = [];
    _stickyColumnsReplayTimeout = null;
    _cachedCellWidths = [];
    _borderCellCss;
    _destroyed = !1;
    constructor(a, e, t = !0, o = !0, n, r, c) { this._isNativeHtmlTable = a, this._stickCellCss = e, this._isBrowser = t, this._needsPositionStickyOnElement = o, this.direction = n, this._positionListener = r, this._tableInjector = c, this._borderCellCss = { top: `${e}-border-elem-top`, bottom: `${e}-border-elem-bottom`, left: `${e}-border-elem-left`, right: `${e}-border-elem-right` }; }
    clearStickyPositioning(a, e) { (e.includes("left") || e.includes("right")) && this._removeFromStickyColumnReplayQueue(a); let t = []; for (let o of a)
        o.nodeType === o.ELEMENT_NODE && t.push(o, ...Array.from(o.children)); x({ write: () => { for (let o of t)
            this._removeStickyStyle(o, e); } }, { injector: this._tableInjector }); }
    updateStickyColumns(a, e, t, o = !0, n = !0) { if (!a.length || !this._isBrowser || !(e.some(w => w) || t.some(w => w))) {
        this._positionListener?.stickyColumnsUpdated({ sizes: [] }), this._positionListener?.stickyEndColumnsUpdated({ sizes: [] });
        return;
    } let r = a[0], c = r.children.length, d = this.direction === "rtl", u = d ? "right" : "left", h = d ? "left" : "right", y = e.lastIndexOf(!0), f = t.indexOf(!0), _, P, B; n && this._updateStickyColumnReplayQueue({ rows: [...a], stickyStartStates: [...e], stickyEndStates: [...t] }), x({ earlyRead: () => { _ = this._getCellWidths(r, o), P = this._getStickyStartColumnPositions(_, e), B = this._getStickyEndColumnPositions(_, t); }, write: () => { for (let w of a)
            for (let m = 0; m < c; m++) {
                let U = w.children[m];
                e[m] && this._addStickyStyle(U, u, P[m], m === y), t[m] && this._addStickyStyle(U, h, B[m], m === f);
            } this._positionListener && _.some(w => !!w) && (this._positionListener.stickyColumnsUpdated({ sizes: y === -1 ? [] : _.slice(0, y + 1).map((w, m) => e[m] ? w : null) }), this._positionListener.stickyEndColumnsUpdated({ sizes: f === -1 ? [] : _.slice(f).map((w, m) => t[m + f] ? w : null).reverse() })); } }, { injector: this._tableInjector }); }
    stickRows(a, e, t) { if (!this._isBrowser)
        return; let o = t === "bottom" ? a.slice().reverse() : a, n = t === "bottom" ? e.slice().reverse() : e, r = [], c = [], d = []; x({ earlyRead: () => { for (let u = 0, h = 0; u < o.length; u++) {
            if (!n[u])
                continue;
            r[u] = h;
            let y = o[u];
            d[u] = this._isNativeHtmlTable ? Array.from(y.children) : [y];
            let f = this._retrieveElementSize(y).height;
            h += f, c[u] = f;
        } }, write: () => { let u = n.lastIndexOf(!0); for (let h = 0; h < o.length; h++) {
            if (!n[h])
                continue;
            let y = r[h], f = h === u;
            for (let _ of d[h])
                this._addStickyStyle(_, t, y, f);
        } t === "top" ? this._positionListener?.stickyHeaderRowsUpdated({ sizes: c, offsets: r, elements: d }) : this._positionListener?.stickyFooterRowsUpdated({ sizes: c, offsets: r, elements: d }); } }, { injector: this._tableInjector }); }
    updateStickyFooterContainer(a, e) { this._isNativeHtmlTable && x({ write: () => { let t = a.querySelector("tfoot"); t && (e.some(o => !o) ? this._removeStickyStyle(t, ["bottom"]) : this._addStickyStyle(t, "bottom", 0, !1)); } }, { injector: this._tableInjector }); }
    destroy() { this._stickyColumnsReplayTimeout && clearTimeout(this._stickyColumnsReplayTimeout), this._resizeObserver?.disconnect(), this._destroyed = !0; }
    _removeStickyStyle(a, e) { if (!a.classList.contains(this._stickCellCss))
        return; for (let o of e)
        a.style[o] = "", a.classList.remove(this._borderCellCss[o]); Z.some(o => e.indexOf(o) === -1 && a.style[o]) ? a.style.zIndex = this._getCalculatedZIndex(a) : (a.style.zIndex = "", this._needsPositionStickyOnElement && (a.style.position = ""), a.classList.remove(this._stickCellCss)); }
    _addStickyStyle(a, e, t, o) { a.classList.add(this._stickCellCss), o && a.classList.add(this._borderCellCss[e]), a.style[e] = `${t}px`, a.style.zIndex = this._getCalculatedZIndex(a), this._needsPositionStickyOnElement && (a.style.cssText += "position: -webkit-sticky; position: sticky; "); }
    _getCalculatedZIndex(a) { let e = { top: 100, bottom: 10, left: 1, right: 1 }, t = 0; for (let o of Z)
        a.style[o] && (t += e[o]); return t ? `${t}` : ""; }
    _getCellWidths(a, e = !0) { if (!e && this._cachedCellWidths.length)
        return this._cachedCellWidths; let t = [], o = a.children; for (let n = 0; n < o.length; n++) {
        let r = o[n];
        t.push(this._retrieveElementSize(r).width);
    } return this._cachedCellWidths = t, t; }
    _getStickyStartColumnPositions(a, e) { let t = [], o = 0; for (let n = 0; n < a.length; n++)
        e[n] && (t[n] = o, o += a[n]); return t; }
    _getStickyEndColumnPositions(a, e) { let t = [], o = 0; for (let n = a.length; n > 0; n--)
        e[n] && (t[n] = o, o += a[n]); return t; }
    _retrieveElementSize(a) { let e = this._elemSizeCache.get(a); if (e)
        return e; let t = a.getBoundingClientRect(), o = { width: t.width, height: t.height }; return this._resizeObserver && (this._elemSizeCache.set(a, o), this._resizeObserver.observe(a, { box: "border-box" })), o; }
    _updateStickyColumnReplayQueue(a) { this._removeFromStickyColumnReplayQueue(a.rows), this._stickyColumnsReplayTimeout || this._updatedStickyColumnsParamsToReplay.push(a); }
    _removeFromStickyColumnReplayQueue(a) { let e = new Set(a); for (let t of this._updatedStickyColumnsParamsToReplay)
        t.rows = t.rows.filter(o => !e.has(o)); this._updatedStickyColumnsParamsToReplay = this._updatedStickyColumnsParamsToReplay.filter(t => !!t.rows.length); }
    _updateCachedSizes(a) { let e = !1; for (let t of a) {
        let o = t.borderBoxSize?.length ? { width: t.borderBoxSize[0].inlineSize, height: t.borderBoxSize[0].blockSize } : { width: t.contentRect.width, height: t.contentRect.height };
        o.width !== this._elemSizeCache.get(t.target)?.width && ve(t.target) && (e = !0), this._elemSizeCache.set(t.target, o);
    } e && this._updatedStickyColumnsParamsToReplay.length && (this._stickyColumnsReplayTimeout && clearTimeout(this._stickyColumnsReplayTimeout), this._stickyColumnsReplayTimeout = setTimeout(() => { if (!this._destroyed) {
        for (let t of this._updatedStickyColumnsParamsToReplay)
            this.updateStickyColumns(t.rows, t.stickyStartStates, t.stickyEndStates, !0, !1);
        this._updatedStickyColumnsParamsToReplay = [], this._stickyColumnsReplayTimeout = null;
    } }, 0)); }
};
function ve(i) { return ["cdk-cell", "cdk-header-cell", "cdk-footer-cell"].some(a => i.classList.contains(a)); }
var F = new H("STICKY_POSITIONING_LISTENER"), ot = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["cdk-table", "recycleRows", ""], ["table", "cdk-table", "", "recycleRows", ""]] });
} return i; })(), be = (() => { class i {
    viewContainer = l(O);
    elementRef = l(p);
    constructor() { let e = l(R); e._rowOutlet = this, e._outletAssigned(); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "rowOutlet", ""]] });
} return i; })(), Te = (() => { class i {
    viewContainer = l(O);
    elementRef = l(p);
    constructor() { let e = l(R); e._headerRowOutlet = this, e._outletAssigned(); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "headerRowOutlet", ""]] });
} return i; })(), Oe = (() => { class i {
    viewContainer = l(O);
    elementRef = l(p);
    constructor() { let e = l(R); e._footerRowOutlet = this, e._outletAssigned(); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "footerRowOutlet", ""]] });
} return i; })(), Ee = (() => { class i {
    viewContainer = l(O);
    elementRef = l(p);
    constructor() { let e = l(R); e._noDataRowOutlet = this, e._outletAssigned(); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "noDataRowOutlet", ""]] });
} return i; })(), xe = (() => {
    class i {
        _differs = l(T);
        _changeDetectorRef = l(oe);
        _elementRef = l(p);
        _dir = l(V, { optional: !0 });
        _platform = l(j);
        _viewRepeater;
        _viewportRuler = l(q);
        _injector = l(ie);
        _virtualScrollViewport = l(K, { optional: !0, host: !0 });
        _positionListener = l(F, { optional: !0 }) || l(F, { optional: !0, skipSelf: !0 });
        _document = l(se);
        _data;
        _renderedRange;
        _onDestroy = new S;
        _renderRows;
        _renderChangeSubscription = null;
        _columnDefsByName = new Map;
        _rowDefs;
        _headerRowDefs;
        _footerRowDefs;
        _dataDiffer;
        _defaultRowDef = null;
        _customColumnDefs = new Set;
        _customRowDefs = new Set;
        _customHeaderRowDefs = new Set;
        _customFooterRowDefs = new Set;
        _customNoDataRow = null;
        _headerRowDefChanged = !0;
        _footerRowDefChanged = !0;
        _stickyColumnStylesNeedReset = !0;
        _forceRecalculateCellWidths = !0;
        _cachedRenderRowsMap = new Map;
        _isNativeHtmlTable;
        _stickyStyler;
        stickyCssClass = "cdk-table-sticky";
        needsPositionStickyOnElement = !0;
        _isServer;
        _isShowingNoDataRow = !1;
        _hasAllOutlets = !1;
        _hasInitialized = !1;
        _headerRowStickyUpdates = new S;
        _footerRowStickyUpdates = new S;
        _disableVirtualScrolling = !1;
        _getCellRole() { if (this._cellRoleInternal === void 0) {
            let e = this._elementRef.nativeElement.getAttribute("role");
            return e === "grid" || e === "treegrid" ? "gridcell" : "cell";
        } return this._cellRoleInternal; }
        _cellRoleInternal = void 0;
        get trackBy() { return this._trackByFn; }
        set trackBy(e) { this._trackByFn = e; }
        _trackByFn;
        get dataSource() { return this._dataSource; }
        set dataSource(e) { this._dataSource !== e && (this._switchDataSource(e), this._changeDetectorRef.markForCheck()); }
        _dataSource;
        _dataSourceChanges = new S;
        _dataStream = new S;
        get multiTemplateDataRows() { return this._multiTemplateDataRows; }
        set multiTemplateDataRows(e) { this._multiTemplateDataRows = e, this._rowOutlet && this._rowOutlet.viewContainer.length && (this._forceRenderDataRows(), this.updateStickyColumnStyles()); }
        _multiTemplateDataRows = !1;
        get fixedLayout() { return this._virtualScrollEnabled() ? !0 : this._fixedLayout; }
        set fixedLayout(e) { this._fixedLayout = e, this._forceRecalculateCellWidths = !0, this._stickyColumnStylesNeedReset = !0; }
        _fixedLayout = !1;
        recycleRows = !1;
        contentChanged = new ne;
        viewChange = new ae({ start: 0, end: Number.MAX_VALUE });
        _rowOutlet;
        _headerRowOutlet;
        _footerRowOutlet;
        _noDataRowOutlet;
        _contentColumnDefs;
        _contentRowDefs;
        _contentHeaderRowDefs;
        _contentFooterRowDefs;
        _noDataRow;
        constructor() { l(new re("role"), { optional: !0 }) || this._elementRef.nativeElement.setAttribute("role", "table"), this._isServer = !this._platform.isBrowser, this._isNativeHtmlTable = this._elementRef.nativeElement.nodeName === "TABLE", this._dataDiffer = this._differs.find([]).create((t, o) => this.trackBy ? this.trackBy(o.dataIndex, o.data) : o); }
        ngOnInit() { this._setupStickyStyler(), this._viewportRuler.change().pipe(D(this._onDestroy)).subscribe(() => { this._forceRecalculateCellWidths = !0; }); }
        ngAfterContentInit() { this._viewRepeater = this.recycleRows || this._virtualScrollEnabled() ? new W : new $, this._virtualScrollEnabled() && this._setupVirtualScrolling(this._virtualScrollViewport), this._hasInitialized = !0; }
        ngAfterContentChecked() { this._canRender() && this._render(); }
        ngOnDestroy() { this._stickyStyler?.destroy(), [this._rowOutlet?.viewContainer, this._headerRowOutlet?.viewContainer, this._footerRowOutlet?.viewContainer, this._cachedRenderRowsMap, this._customColumnDefs, this._customRowDefs, this._customHeaderRowDefs, this._customFooterRowDefs, this._columnDefsByName].forEach(e => { e?.clear(); }), this._headerRowDefs = [], this._footerRowDefs = [], this._defaultRowDef = null, this._headerRowStickyUpdates.complete(), this._footerRowStickyUpdates.complete(), this._onDestroy.next(), this._onDestroy.complete(), E(this.dataSource) && this.dataSource.disconnect(this); }
        renderRows() { this._renderRows = this._getAllRenderRows(); let e = this._dataDiffer.diff(this._renderRows); if (!e) {
            this._updateNoDataRow(), this.contentChanged.next();
            return;
        } let t = this._rowOutlet.viewContainer; this._viewRepeater.applyChanges(e, t, (o, n, r) => this._getEmbeddedViewArgs(o.item, r), o => o.item.data, o => { o.operation === Q.INSERTED && o.context && this._renderCellTemplateForItem(o.record.item.rowDef, o.context); }), this._updateRowIndexContext(), e.forEachIdentityChange(o => { let n = t.get(o.currentIndex); n.context.$implicit = o.item.data; }), this._updateNoDataRow(), this.contentChanged.next(), this.updateStickyColumnStyles(); }
        addColumnDef(e) { this._customColumnDefs.add(e); }
        removeColumnDef(e) { this._customColumnDefs.delete(e); }
        addRowDef(e) { this._customRowDefs.add(e); }
        removeRowDef(e) { this._customRowDefs.delete(e); }
        addHeaderRowDef(e) { this._customHeaderRowDefs.add(e), this._headerRowDefChanged = !0; }
        removeHeaderRowDef(e) { this._customHeaderRowDefs.delete(e), this._headerRowDefChanged = !0; }
        addFooterRowDef(e) { this._customFooterRowDefs.add(e), this._footerRowDefChanged = !0; }
        removeFooterRowDef(e) { this._customFooterRowDefs.delete(e), this._footerRowDefChanged = !0; }
        setNoDataRow(e) { this._customNoDataRow = e; }
        updateStickyHeaderRowStyles() { let e = this._getRenderedRows(this._headerRowOutlet); if (this._isNativeHtmlTable) {
            let o = G(this._headerRowOutlet, "thead");
            o && (o.style.display = e.length ? "" : "none");
        } let t = this._headerRowDefs.map(o => o.sticky); this._stickyStyler.clearStickyPositioning(e, ["top"]), this._stickyStyler.stickRows(e, t, "top"), this._headerRowDefs.forEach(o => o.resetStickyChanged()); }
        updateStickyFooterRowStyles() { let e = this._getRenderedRows(this._footerRowOutlet); if (this._isNativeHtmlTable) {
            let o = G(this._footerRowOutlet, "tfoot");
            o && (o.style.display = e.length ? "" : "none");
        } let t = this._footerRowDefs.map(o => o.sticky); this._stickyStyler.clearStickyPositioning(e, ["bottom"]), this._stickyStyler.stickRows(e, t, "bottom"), this._stickyStyler.updateStickyFooterContainer(this._elementRef.nativeElement, t), this._footerRowDefs.forEach(o => o.resetStickyChanged()); }
        updateStickyColumnStyles() { let e = this._getRenderedRows(this._headerRowOutlet), t = this._getRenderedRows(this._rowOutlet), o = this._getRenderedRows(this._footerRowOutlet); (this._isNativeHtmlTable && !this.fixedLayout || this._stickyColumnStylesNeedReset) && (this._stickyStyler.clearStickyPositioning([...e, ...t, ...o], ["left", "right"]), this._stickyColumnStylesNeedReset = !1), e.forEach((n, r) => { this._addStickyColumnStyles([n], this._headerRowDefs[r]); }), this._rowDefs.forEach(n => { let r = []; for (let c = 0; c < t.length; c++)
            this._renderRows[c].rowDef === n && r.push(t[c]); this._addStickyColumnStyles(r, n); }), o.forEach((n, r) => { this._addStickyColumnStyles([n], this._footerRowDefs[r]); }), Array.from(this._columnDefsByName.values()).forEach(n => n.resetStickyChanged()); }
        stickyColumnsUpdated(e) { this._positionListener?.stickyColumnsUpdated(e); }
        stickyEndColumnsUpdated(e) { this._positionListener?.stickyEndColumnsUpdated(e); }
        stickyHeaderRowsUpdated(e) { this._headerRowStickyUpdates.next(e), this._positionListener?.stickyHeaderRowsUpdated(e); }
        stickyFooterRowsUpdated(e) { this._footerRowStickyUpdates.next(e), this._positionListener?.stickyFooterRowsUpdated(e); }
        _outletAssigned() { !this._hasAllOutlets && this._rowOutlet && this._headerRowOutlet && this._footerRowOutlet && this._noDataRowOutlet && (this._hasAllOutlets = !0, this._canRender() && this._render()); }
        _canRender() { return this._hasAllOutlets && this._hasInitialized; }
        _render() { this._cacheRowDefs(), this._cacheColumnDefs(), !this._headerRowDefs.length && !this._footerRowDefs.length && this._rowDefs.length; let t = this._renderUpdatedColumns() || this._headerRowDefChanged || this._footerRowDefChanged; this._stickyColumnStylesNeedReset = this._stickyColumnStylesNeedReset || t, this._forceRecalculateCellWidths = t, this._headerRowDefChanged && (this._forceRenderHeaderRows(), this._headerRowDefChanged = !1), this._footerRowDefChanged && (this._forceRenderFooterRows(), this._footerRowDefChanged = !1), this.dataSource && this._rowDefs.length > 0 && !this._renderChangeSubscription ? this._observeRenderChanges() : this._stickyColumnStylesNeedReset && this.updateStickyColumnStyles(), this._checkStickyStates(); }
        _getAllRenderRows() { if (!Array.isArray(this._data) || !this._renderedRange)
            return []; let e = [], t = Math.min(this._data.length, this._renderedRange.end), o = this._cachedRenderRowsMap; this._cachedRenderRowsMap = new Map; for (let n = this._renderedRange.start; n < t; n++) {
            let r = this._data[n], c = this._getRenderRowsForData(r, n, o.get(r));
            this._cachedRenderRowsMap.has(r) || this._cachedRenderRowsMap.set(r, new WeakMap);
            for (let d = 0; d < c.length; d++) {
                let u = c[d], h = this._cachedRenderRowsMap.get(u.data);
                h.has(u.rowDef) ? h.get(u.rowDef).push(u) : h.set(u.rowDef, [u]), e.push(u);
            }
        } return e; }
        _getRenderRowsForData(e, t, o) { return this._getRowDefs(e, t).map(r => { let c = o && o.has(r) ? o.get(r) : []; if (c.length) {
            let d = c.shift();
            return d.dataIndex = t, d;
        }
        else
            return { data: e, rowDef: r, dataIndex: t }; }); }
        _cacheColumnDefs() { this._columnDefsByName.clear(), M(this._getOwnDefs(this._contentColumnDefs), this._customColumnDefs).forEach(t => { this._columnDefsByName.has(t.name), this._columnDefsByName.set(t.name, t); }); }
        _cacheRowDefs() { this._headerRowDefs = M(this._getOwnDefs(this._contentHeaderRowDefs), this._customHeaderRowDefs), this._footerRowDefs = M(this._getOwnDefs(this._contentFooterRowDefs), this._customFooterRowDefs), this._rowDefs = M(this._getOwnDefs(this._contentRowDefs), this._customRowDefs); let e = this._rowDefs.filter(t => !t.when); this._defaultRowDef = e[0]; }
        _renderUpdatedColumns() { let e = (r, c) => { let d = !!c.getColumnsDiff(); return r || d; }, t = this._rowDefs.reduce(e, !1); t && this._forceRenderDataRows(); let o = this._headerRowDefs.reduce(e, !1); o && this._forceRenderHeaderRows(); let n = this._footerRowDefs.reduce(e, !1); return n && this._forceRenderFooterRows(), t || o || n; }
        _switchDataSource(e) { this._data = [], E(this.dataSource) && this.dataSource.disconnect(this), this._renderChangeSubscription && (this._renderChangeSubscription.unsubscribe(), this._renderChangeSubscription = null), e || (this._dataDiffer && this._dataDiffer.diff([]), this._rowOutlet && this._rowOutlet.viewContainer.clear()), this._dataSource = e; }
        _observeRenderChanges() { if (!this.dataSource)
            return; let e; E(this.dataSource) ? e = this.dataSource.connect(this) : le(this.dataSource) ? e = this.dataSource : Array.isArray(this.dataSource) && (e = Y(this.dataSource)), this._renderChangeSubscription = N([e, this.viewChange]).pipe(D(this._onDestroy)).subscribe(([t, o]) => { this._data = t || [], this._renderedRange = o, this._dataStream.next(t), this.renderRows(); }); }
        _forceRenderHeaderRows() { this._headerRowOutlet.viewContainer.length > 0 && this._headerRowOutlet.viewContainer.clear(), this._headerRowDefs.forEach((e, t) => this._renderRow(this._headerRowOutlet, e, t)), this.updateStickyHeaderRowStyles(); }
        _forceRenderFooterRows() { this._footerRowOutlet.viewContainer.length > 0 && this._footerRowOutlet.viewContainer.clear(), this._footerRowDefs.forEach((e, t) => this._renderRow(this._footerRowOutlet, e, t)), this.updateStickyFooterRowStyles(); }
        _addStickyColumnStyles(e, t) { let o = Array.from(t?.columns || []).map(c => { let d = this._columnDefsByName.get(c); return d; }), n = o.map(c => c.sticky), r = o.map(c => c.stickyEnd); this._stickyStyler.updateStickyColumns(e, n, r, !this.fixedLayout || this._forceRecalculateCellWidths); }
        _getRenderedRows(e) { let t = []; for (let o = 0; o < e.viewContainer.length; o++) {
            let n = e.viewContainer.get(o);
            t.push(n.rootNodes[0]);
        } return t; }
        _getRowDefs(e, t) { if (this._rowDefs.length === 1)
            return [this._rowDefs[0]]; let o = []; if (this.multiTemplateDataRows)
            o = this._rowDefs.filter(n => !n.when || n.when(t, e));
        else {
            let n = this._rowDefs.find(r => r.when && r.when(t, e)) || this._defaultRowDef;
            n && o.push(n);
        } return o.length, o; }
        _getEmbeddedViewArgs(e, t) { let o = e.rowDef, n = { $implicit: e.data }; return { templateRef: o.template, context: n, index: t }; }
        _renderRow(e, t, o, n = {}) { let r = e.viewContainer.createEmbeddedView(t.template, n, o); return this._renderCellTemplateForItem(t, n), r; }
        _renderCellTemplateForItem(e, t) { for (let o of this._getCellTemplates(e))
            b.mostRecentCellOutlet && b.mostRecentCellOutlet._viewContainer.createEmbeddedView(o, t); this._changeDetectorRef.markForCheck(); }
        _updateRowIndexContext() { let e = this._rowOutlet.viewContainer; for (let t = 0, o = e.length; t < o; t++) {
            let r = e.get(t).context;
            r.count = o, r.first = t === 0, r.last = t === o - 1, r.even = t % 2 === 0, r.odd = !r.even, this.multiTemplateDataRows ? (r.dataIndex = this._renderRows[t].dataIndex, r.renderIndex = t) : r.index = this._renderRows[t].dataIndex;
        } }
        _getCellTemplates(e) { return !e || !e.columns ? [] : Array.from(e.columns, t => { let o = this._columnDefsByName.get(t); return e.extractCellTemplate(o); }); }
        _forceRenderDataRows() { this._dataDiffer.diff([]), this._rowOutlet.viewContainer.clear(), this.renderRows(); }
        _checkStickyStates() { let e = (t, o) => t || o.hasStickyChanged(); this._headerRowDefs.reduce(e, !1) && this.updateStickyHeaderRowStyles(), this._footerRowDefs.reduce(e, !1) && this.updateStickyFooterRowStyles(), Array.from(this._columnDefsByName.values()).reduce(e, !1) && (this._stickyColumnStylesNeedReset = !0, this.updateStickyColumnStyles()); }
        _setupStickyStyler() { let e = this._dir ? this._dir.value : "ltr", t = this._injector; this._stickyStyler = new L(this._isNativeHtmlTable, this.stickyCssClass, this._platform.isBrowser, this.needsPositionStickyOnElement, e, this, t), (this._dir ? this._dir.change : Y()).pipe(D(this._onDestroy)).subscribe(o => { this._stickyStyler.direction = o, this.updateStickyColumnStyles(); }); }
        _setupVirtualScrolling(e) { let t = typeof requestAnimationFrame < "u" ? ce : de; this.viewChange.next({ start: 0, end: 0 }), e.renderedRangeStream.pipe(ue(0, t), D(this._onDestroy)).subscribe(this.viewChange), e.attach({ dataStream: this._dataStream, measureRangeSize: (o, n) => this._measureRangeSize(o, n) }), N([e.renderedContentOffset, this._headerRowStickyUpdates]).pipe(D(this._onDestroy)).subscribe(([o, n]) => { if (!(!n.sizes || !n.offsets || !n.elements))
            for (let r = 0; r < n.elements.length; r++) {
                let c = n.elements[r];
                if (c) {
                    let d = n.offsets[r], u = o !== 0 ? Math.max(o - d, d) : -d;
                    for (let h of c)
                        h.style.top = `${-u}px`;
                }
            } }), N([e.renderedContentOffset, this._footerRowStickyUpdates]).pipe(D(this._onDestroy)).subscribe(([o, n]) => { if (!(!n.sizes || !n.offsets || !n.elements))
            for (let r = 0; r < n.elements.length; r++) {
                let c = n.elements[r];
                if (c)
                    for (let d of c)
                        d.style.bottom = `${o + n.offsets[r]}px`;
            } }); }
        _getOwnDefs(e) { return e.filter(t => !t._table || t._table === this); }
        _updateNoDataRow() { let e = this._customNoDataRow || this._noDataRow; if (!e)
            return; let t = this._rowOutlet.viewContainer.length === 0; if (t === this._isShowingNoDataRow)
            return; let o = this._noDataRowOutlet.viewContainer; if (t) {
            let n = o.createEmbeddedView(e.templateRef), r = n.rootNodes[0];
            if (n.rootNodes.length === 1 && r?.nodeType === this._document.ELEMENT_NODE) {
                r.setAttribute("role", "row"), r.classList.add(...e._contentClassNames);
                let c = r.querySelectorAll(e._cellSelector);
                for (let d = 0; d < c.length; d++)
                    c[d].classList.add(...e._cellClassNames);
            }
        }
        else
            o.clear(); this._isShowingNoDataRow = t, this._changeDetectorRef.markForCheck(); }
        _measureRangeSize(e, t) { if (e.start >= e.end || t !== "vertical")
            return 0; let o = this.viewChange.value, n = this._rowOutlet.viewContainer; e.start < o.start || e.end > o.end; let r = e.start - o.start, c = e.end - e.start, d, u; for (let f = 0; f < c; f++) {
            let _ = n.get(f + r);
            if (_ && _.rootNodes.length) {
                d = u = _.rootNodes[0];
                break;
            }
        } for (let f = c - 1; f > -1; f--) {
            let _ = n.get(f + r);
            if (_ && _.rootNodes.length) {
                u = _.rootNodes[_.rootNodes.length - 1];
                break;
            }
        } let h = d?.getBoundingClientRect?.(), y = u?.getBoundingClientRect?.(); return h && y ? y.bottom - h.top : 0; }
        _virtualScrollEnabled() { return !this._disableVirtualScrolling && this._virtualScrollViewport != null; }
        static \u0275fac = function (t) { return new (t || i); };
        static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-table"], ["table", "cdk-table", ""]], contentQueries: function (t, o, n) { if (t & 1 && s.\u0275\u0275contentQuery(n, Se, 5)(n, k, 5)(n, ke, 5)(n, J, 5)(n, ee, 5), t & 2) {
                let r;
                s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o._noDataRow = r.first), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o._contentColumnDefs = r), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o._contentRowDefs = r), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o._contentHeaderRowDefs = r), s.\u0275\u0275queryRefresh(r = s.\u0275\u0275loadQuery()) && (o._contentFooterRowDefs = r);
            } }, hostAttrs: [1, "cdk-table"], hostVars: 2, hostBindings: function (t, o) { t & 2 && s.\u0275\u0275classProp("cdk-table-fixed-layout", o.fixedLayout); }, inputs: { trackBy: "trackBy", dataSource: "dataSource", multiTemplateDataRows: [2, "multiTemplateDataRows", "multiTemplateDataRows", g], fixedLayout: [2, "fixedLayout", "fixedLayout", g], recycleRows: [2, "recycleRows", "recycleRows", g] }, outputs: { contentChanged: "contentChanged" }, exportAs: ["cdkTable"], features: [s.\u0275\u0275ProvidersFeature([{ provide: R, useExisting: i }, { provide: F, useValue: null }])], ngContentSelectors: fe, decls: 5, vars: 2, consts: [["role", "rowgroup"], ["headerRowOutlet", ""], ["rowOutlet", ""], ["noDataRowOutlet", ""], ["footerRowOutlet", ""]], template: function (t, o) { t & 1 && (s.\u0275\u0275projectionDef(he), s.\u0275\u0275projection(0), s.\u0275\u0275projection(1, 1), s.\u0275\u0275conditionalCreate(2, _e, 1, 0), s.\u0275\u0275conditionalCreate(3, me, 7, 0)(4, ye, 4, 0)), t & 2 && (s.\u0275\u0275advance(2), s.\u0275\u0275conditional(o._isServer ? 2 : -1), s.\u0275\u0275advance(), s.\u0275\u0275conditional(o._isNativeHtmlTable ? 3 : 4)); }, dependencies: [Te, be, Ee, Oe], styles: [`.cdk-table-fixed-layout {
  table-layout: fixed;
}
`], encapsulation: 2 });
    }
    return i;
})();
function M(i, a) { return i.concat(Array.from(a)); }
function G(i, a) { let e = a.toUpperCase(), t = i.viewContainer.element.nativeElement; for (; t;) {
    let o = t.nodeType === 1 ? t.nodeName : null;
    if (o === e)
        return t;
    if (o === "TABLE")
        break;
    t = t.parentNode;
} return null; }
var it = (() => { class i {
    _table = l(xe, { optional: !0 });
    _options = l(pe, { optional: !0 });
    get name() { return this._name; }
    set name(e) { this._name = e, this._syncColumnDefName(); }
    _name;
    headerText;
    dataAccessor;
    justify = "start";
    columnDef;
    cell;
    headerCell;
    constructor() { this._options = this._options || {}; }
    ngOnInit() { this._syncColumnDefName(), this.headerText === void 0 && (this.headerText = this._createDefaultHeaderText()), this.dataAccessor || (this.dataAccessor = this._options.defaultDataAccessor || ((e, t) => e[t])), this._table && (this.columnDef.cell = this.cell, this.columnDef.headerCell = this.headerCell, this._table.addColumnDef(this.columnDef)); }
    ngOnDestroy() { this._table && this._table.removeColumnDef(this.columnDef); }
    _createDefaultHeaderText() { let e = this.name; return this._options && this._options.defaultHeaderTextTransform ? this._options.defaultHeaderTextTransform(e) : e[0].toUpperCase() + e.slice(1); }
    _syncColumnDefName() { this.columnDef && (this.columnDef.name = this.name); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275cmp = s.\u0275\u0275defineComponent({ type: i, selectors: [["cdk-text-column"]], viewQuery: function (t, o) { if (t & 1 && s.\u0275\u0275viewQuery(k, 7)(I, 7)(A, 7), t & 2) {
            let n;
            s.\u0275\u0275queryRefresh(n = s.\u0275\u0275loadQuery()) && (o.columnDef = n.first), s.\u0275\u0275queryRefresh(n = s.\u0275\u0275loadQuery()) && (o.cell = n.first), s.\u0275\u0275queryRefresh(n = s.\u0275\u0275loadQuery()) && (o.headerCell = n.first);
        } }, inputs: { name: "name", headerText: "headerText", dataAccessor: "dataAccessor", justify: "justify" }, decls: 3, vars: 0, consts: [["cdkColumnDef", ""], ["cdk-header-cell", "", 3, "text-align", 4, "cdkHeaderCellDef"], ["cdk-cell", "", 3, "text-align", 4, "cdkCellDef"], ["cdk-header-cell", ""], ["cdk-cell", ""]], template: function (t, o) { t & 1 && (s.\u0275\u0275elementContainerStart(0, 0), s.\u0275\u0275template(1, we, 2, 3, "th", 1)(2, Re, 2, 3, "td", 2), s.\u0275\u0275elementContainerEnd()); }, dependencies: [k, A, ge, I, De], encapsulation: 2 });
} return i; })();
var st = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275mod = s.\u0275\u0275defineNgModule({ type: i });
    static \u0275inj = s.\u0275\u0275defineInjector({ imports: [X] });
} return i; })();
export { v as BaseCdkCell, z as BaseRowDef, Ge as CDK_ROW_TEMPLATE, R as CDK_TABLE, De as CdkCell, I as CdkCellDef, b as CdkCellOutlet, k as CdkColumnDef, Ze as CdkFooterCell, Ce as CdkFooterCellDef, et as CdkFooterRow, ee as CdkFooterRowDef, ge as CdkHeaderCell, A as CdkHeaderCellDef, Je as CdkHeaderRow, J as CdkHeaderRowDef, Se as CdkNoDataRow, ot as CdkRecycleRows, tt as CdkRow, ke as CdkRowDef, xe as CdkTable, st as CdkTableModule, it as CdkTextColumn, be as DataRowOutlet, te as DataSource, Oe as FooterRowOutlet, Te as HeaderRowOutlet, Ee as NoDataRowOutlet, F as STICKY_POSITIONING_LISTENER, pe as TEXT_COLUMN_OPTIONS };
