import { H as se, O as oe, T as le, U as he, V as ce, W as de, X as ue, Y as xe, Z as Dt, _ as mt, i as re, k as D } from "@nf-internal/chunk-LEJRRF65";
import { b as dt, h as qt, o as zt } from "@nf-internal/chunk-RZWXGGKD";
import { a as s } from "@nf-internal/chunk-YUSHYV7C";
import { a as O } from "@nf-internal/chunk-OSQMNGTH";
var Vt = (function () {
    var t = s(function (j, r, l, u) { for (l = l || {}, u = j.length; u--; l[j[u]] = r)
        ; return l; }, "o"), a = [1, 3], p = [1, 4], f = [1, 5], o = [1, 6], x = [1, 7], _ = [1, 4, 5, 10, 12, 13, 14, 15, 18, 25, 35, 37, 39, 41, 42, 48, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 63, 64, 65, 66, 67], h = [1, 4, 5, 10, 12, 13, 14, 15, 18, 25, 28, 35, 37, 39, 41, 42, 48, 50, 51, 52, 53, 54, 55, 56, 57, 60, 61, 63, 64, 65, 66, 67], c = [55, 56, 57], k = [2, 36], m = [1, 37], q = [1, 36], y = [1, 38], b = [1, 35], T = [1, 43], g = [1, 41], A = [1, 45], ut = [1, 14], xt = [1, 23], ft = [1, 18], gt = [1, 19], lt = [1, 20], _t = [1, 21], ht = [1, 22], i = [1, 24], wt = [1, 25], Bt = [1, 26], Rt = [1, 27], Nt = [1, 28], Wt = [1, 29], U = [1, 32], Q = [1, 33], F = [1, 34], P = [1, 39], v = [1, 40], C = [1, 42], L = [1, 44], X = [1, 63], M = [1, 62], E = [4, 5, 8, 10, 12, 13, 14, 15, 18, 44, 47, 49, 55, 56, 57, 63, 64, 65, 66, 67], Ut = [1, 66], Qt = [1, 67], Ot = [1, 68], Ht = [1, 69], Xt = [1, 70], Mt = [1, 71], Yt = [1, 72], jt = [1, 73], Gt = [1, 74], Kt = [1, 75], Zt = [1, 76], Jt = [1, 77], B = [4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 18], Z = [1, 91], J = [1, 92], $ = [1, 93], tt = [1, 100], et = [1, 94], it = [1, 97], at = [1, 95], nt = [1, 96], rt = [1, 98], st = [1, 99], At = [1, 103], $t = [10, 55, 56, 57], N = [4, 5, 6, 8, 10, 11, 13, 17, 18, 19, 20, 55, 56, 57], Ft = { trace: s(function () { }, "trace"), yy: {}, symbols_: { error: 2, idStringToken: 3, ALPHA: 4, NUM: 5, NODE_STRING: 6, DOWN: 7, MINUS: 8, DEFAULT: 9, COMMA: 10, COLON: 11, AMP: 12, BRKT: 13, MULT: 14, UNICODE_TEXT: 15, styleComponent: 16, UNIT: 17, SPACE: 18, STYLE: 19, PCT: 20, idString: 21, style: 22, stylesOpt: 23, classDefStatement: 24, CLASSDEF: 25, start: 26, eol: 27, QUADRANT: 28, document: 29, line: 30, statement: 31, axisDetails: 32, quadrantDetails: 33, points: 34, title: 35, title_value: 36, acc_title: 37, acc_title_value: 38, acc_descr: 39, acc_descr_value: 40, acc_descr_multiline_value: 41, section: 42, text: 43, point_start: 44, point_x: 45, point_y: 46, class_name: 47, "X-AXIS": 48, "AXIS-TEXT-DELIMITER": 49, "Y-AXIS": 50, QUADRANT_1: 51, QUADRANT_2: 52, QUADRANT_3: 53, QUADRANT_4: 54, NEWLINE: 55, SEMI: 56, EOF: 57, alphaNumToken: 58, textNoTagsToken: 59, STR: 60, MD_STR: 61, alphaNum: 62, PUNCTUATION: 63, PLUS: 64, EQUALS: 65, DOT: 66, UNDERSCORE: 67, $accept: 0, $end: 1 }, terminals_: { 2: "error", 4: "ALPHA", 5: "NUM", 6: "NODE_STRING", 7: "DOWN", 8: "MINUS", 9: "DEFAULT", 10: "COMMA", 11: "COLON", 12: "AMP", 13: "BRKT", 14: "MULT", 15: "UNICODE_TEXT", 17: "UNIT", 18: "SPACE", 19: "STYLE", 20: "PCT", 25: "CLASSDEF", 28: "QUADRANT", 35: "title", 36: "title_value", 37: "acc_title", 38: "acc_title_value", 39: "acc_descr", 40: "acc_descr_value", 41: "acc_descr_multiline_value", 42: "section", 44: "point_start", 45: "point_x", 46: "point_y", 47: "class_name", 48: "X-AXIS", 49: "AXIS-TEXT-DELIMITER", 50: "Y-AXIS", 51: "QUADRANT_1", 52: "QUADRANT_2", 53: "QUADRANT_3", 54: "QUADRANT_4", 55: "NEWLINE", 56: "SEMI", 57: "EOF", 60: "STR", 61: "MD_STR", 63: "PUNCTUATION", 64: "PLUS", 65: "EQUALS", 66: "DOT", 67: "UNDERSCORE" }, productions_: [0, [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [3, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [16, 1], [21, 1], [21, 2], [22, 1], [22, 2], [23, 1], [23, 3], [24, 5], [26, 2], [26, 2], [26, 2], [29, 0], [29, 2], [30, 2], [31, 0], [31, 1], [31, 2], [31, 1], [31, 1], [31, 1], [31, 2], [31, 2], [31, 2], [31, 1], [31, 1], [34, 4], [34, 5], [34, 5], [34, 6], [32, 4], [32, 3], [32, 2], [32, 4], [32, 3], [32, 2], [33, 2], [33, 2], [33, 2], [33, 2], [27, 1], [27, 1], [27, 1], [43, 1], [43, 2], [43, 1], [43, 1], [62, 1], [62, 2], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [58, 1], [59, 1], [59, 1], [59, 1]], performAction: s(function (r, l, u, d, S, e, ct) { var n = e.length - 1; switch (S) {
            case 23:
                this.$ = e[n];
                break;
            case 24:
                this.$ = e[n - 1] + "" + e[n];
                break;
            case 26:
                this.$ = e[n - 1] + e[n];
                break;
            case 27:
                this.$ = [e[n].trim()];
                break;
            case 28:
                e[n - 2].push(e[n].trim()), this.$ = e[n - 2];
                break;
            case 29:
                this.$ = e[n - 4], d.addClass(e[n - 2], e[n]);
                break;
            case 37:
                this.$ = [];
                break;
            case 42:
                this.$ = e[n].trim(), d.setDiagramTitle(this.$);
                break;
            case 43:
                this.$ = e[n].trim(), d.setAccTitle(this.$);
                break;
            case 44:
            case 45:
                this.$ = e[n].trim(), d.setAccDescription(this.$);
                break;
            case 46:
                d.addSection(e[n].substr(8)), this.$ = e[n].substr(8);
                break;
            case 47:
                d.addPoint(e[n - 3], "", e[n - 1], e[n], []);
                break;
            case 48:
                d.addPoint(e[n - 4], e[n - 3], e[n - 1], e[n], []);
                break;
            case 49:
                d.addPoint(e[n - 4], "", e[n - 2], e[n - 1], e[n]);
                break;
            case 50:
                d.addPoint(e[n - 5], e[n - 4], e[n - 2], e[n - 1], e[n]);
                break;
            case 51:
                d.setXAxisLeftText(e[n - 2]), d.setXAxisRightText(e[n]);
                break;
            case 52:
                e[n - 1].text += " \u27F6 ", d.setXAxisLeftText(e[n - 1]);
                break;
            case 53:
                d.setXAxisLeftText(e[n]);
                break;
            case 54:
                d.setYAxisBottomText(e[n - 2]), d.setYAxisTopText(e[n]);
                break;
            case 55:
                e[n - 1].text += " \u27F6 ", d.setYAxisBottomText(e[n - 1]);
                break;
            case 56:
                d.setYAxisBottomText(e[n]);
                break;
            case 57:
                d.setQuadrant1Text(e[n]);
                break;
            case 58:
                d.setQuadrant2Text(e[n]);
                break;
            case 59:
                d.setQuadrant3Text(e[n]);
                break;
            case 60:
                d.setQuadrant4Text(e[n]);
                break;
            case 64:
                this.$ = { text: e[n], type: "text" };
                break;
            case 65:
                this.$ = { text: e[n - 1].text + "" + e[n], type: e[n - 1].type };
                break;
            case 66:
                this.$ = { text: e[n], type: "text" };
                break;
            case 67:
                this.$ = { text: e[n], type: "markdown" };
                break;
            case 68:
                this.$ = e[n];
                break;
            case 69:
                this.$ = e[n - 1] + "" + e[n];
                break;
        } }, "anonymous"), table: [{ 18: a, 26: 1, 27: 2, 28: p, 55: f, 56: o, 57: x }, { 1: [3] }, { 18: a, 26: 8, 27: 2, 28: p, 55: f, 56: o, 57: x }, { 18: a, 26: 9, 27: 2, 28: p, 55: f, 56: o, 57: x }, t(_, [2, 33], { 29: 10 }), t(h, [2, 61]), t(h, [2, 62]), t(h, [2, 63]), { 1: [2, 30] }, { 1: [2, 31] }, t(c, k, { 30: 11, 31: 12, 24: 13, 32: 15, 33: 16, 34: 17, 43: 30, 58: 31, 1: [2, 32], 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 18: ut, 25: xt, 35: ft, 37: gt, 39: lt, 41: _t, 42: ht, 48: i, 50: wt, 51: Bt, 52: Rt, 53: Nt, 54: Wt, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }), t(_, [2, 34]), { 27: 46, 55: f, 56: o, 57: x }, t(c, [2, 37]), t(c, k, { 24: 13, 32: 15, 33: 16, 34: 17, 43: 30, 58: 31, 31: 47, 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 18: ut, 25: xt, 35: ft, 37: gt, 39: lt, 41: _t, 42: ht, 48: i, 50: wt, 51: Bt, 52: Rt, 53: Nt, 54: Wt, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 39]), t(c, [2, 40]), t(c, [2, 41]), { 36: [1, 48] }, { 38: [1, 49] }, { 40: [1, 50] }, t(c, [2, 45]), t(c, [2, 46]), { 18: [1, 51] }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 52, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 53, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 54, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 55, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 56, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 43: 57, 58: 31, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }, { 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 44: [1, 58], 47: [1, 59], 58: 61, 59: 60, 63: F, 64: P, 65: v, 66: C, 67: L }, t(E, [2, 64]), t(E, [2, 66]), t(E, [2, 67]), t(E, [2, 70]), t(E, [2, 71]), t(E, [2, 72]), t(E, [2, 73]), t(E, [2, 74]), t(E, [2, 75]), t(E, [2, 76]), t(E, [2, 77]), t(E, [2, 78]), t(E, [2, 79]), t(E, [2, 80]), t(E, [2, 81]), t(_, [2, 35]), t(c, [2, 38]), t(c, [2, 42]), t(c, [2, 43]), t(c, [2, 44]), { 3: 65, 4: Ut, 5: Qt, 6: Ot, 7: Ht, 8: Xt, 9: Mt, 10: Yt, 11: jt, 12: Gt, 13: Kt, 14: Zt, 15: Jt, 21: 64 }, t(c, [2, 53], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 49: [1, 78], 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 56], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 49: [1, 79], 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 57], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 58], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 59], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 60], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), { 45: [1, 80] }, { 44: [1, 81] }, t(E, [2, 65]), t(E, [2, 82]), t(E, [2, 83]), t(E, [2, 84]), { 3: 83, 4: Ut, 5: Qt, 6: Ot, 7: Ht, 8: Xt, 9: Mt, 10: Yt, 11: jt, 12: Gt, 13: Kt, 14: Zt, 15: Jt, 18: [1, 82] }, t(B, [2, 23]), t(B, [2, 1]), t(B, [2, 2]), t(B, [2, 3]), t(B, [2, 4]), t(B, [2, 5]), t(B, [2, 6]), t(B, [2, 7]), t(B, [2, 8]), t(B, [2, 9]), t(B, [2, 10]), t(B, [2, 11]), t(B, [2, 12]), t(c, [2, 52], { 58: 31, 43: 84, 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 55], { 58: 31, 43: 85, 4: m, 5: q, 10: y, 12: b, 13: T, 14: g, 15: A, 60: U, 61: Q, 63: F, 64: P, 65: v, 66: C, 67: L }), { 46: [1, 86] }, { 45: [1, 87] }, { 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 16: 90, 17: at, 18: nt, 19: rt, 20: st, 22: 89, 23: 88 }, t(B, [2, 24]), t(c, [2, 51], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 54], { 59: 60, 58: 61, 4: m, 5: q, 8: X, 10: y, 12: b, 13: T, 14: g, 15: A, 18: M, 63: F, 64: P, 65: v, 66: C, 67: L }), t(c, [2, 47], { 22: 89, 16: 90, 23: 101, 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 17: at, 18: nt, 19: rt, 20: st }), { 46: [1, 102] }, t(c, [2, 29], { 10: At }), t($t, [2, 27], { 16: 104, 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 17: at, 18: nt, 19: rt, 20: st }), t(N, [2, 25]), t(N, [2, 13]), t(N, [2, 14]), t(N, [2, 15]), t(N, [2, 16]), t(N, [2, 17]), t(N, [2, 18]), t(N, [2, 19]), t(N, [2, 20]), t(N, [2, 21]), t(N, [2, 22]), t(c, [2, 49], { 10: At }), t(c, [2, 48], { 22: 89, 16: 90, 23: 105, 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 17: at, 18: nt, 19: rt, 20: st }), { 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 16: 90, 17: at, 18: nt, 19: rt, 20: st, 22: 106 }, t(N, [2, 26]), t(c, [2, 50], { 10: At }), t($t, [2, 28], { 16: 104, 4: Z, 5: J, 6: $, 8: tt, 11: et, 13: it, 17: at, 18: nt, 19: rt, 20: st })], defaultActions: { 8: [2, 30], 9: [2, 31] }, parseError: s(function (r, l) { if (l.recoverable)
            this.trace(r);
        else {
            var u = new Error(r);
            throw u.hash = l, u;
        } }, "parseError"), parse: s(function (r) {
            var l = this, u = [0], d = [], S = [null], e = [], ct = this.table, n = "", yt = 0, te = 0, ee = 0, Le = 2, ie = 1, Ee = e.slice.call(arguments, 1), z = Object.create(this.lexer), G = { yy: {} };
            for (var Pt in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, Pt) && (G.yy[Pt] = this.yy[Pt]);
            z.setInput(r, G.yy), G.yy.lexer = z, G.yy.parser = this, typeof z.yylloc > "u" && (z.yylloc = {});
            var vt = z.yylloc;
            e.push(vt);
            var De = z.options && z.options.ranges;
            typeof G.yy.parseError == "function" ? this.parseError = G.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function ze(R) { u.length = u.length - 2 * R, S.length = S.length - R, e.length = e.length - R; }
            s(ze, "popStack");
            function ae() { var R; return R = d.pop() || z.lex() || ie, typeof R != "number" && (R instanceof Array && (d = R, R = d.pop()), R = l.symbols_[R] || R), R; }
            s(ae, "lex");
            for (var I, Ct, K, W, We, Lt, ot = {}, bt, Y, ne, Tt;;) {
                if (K = u[u.length - 1], this.defaultActions[K] ? W = this.defaultActions[K] : ((I === null || typeof I > "u") && (I = ae()), W = ct[K] && ct[K][I]), typeof W > "u" || !W.length || !W[0]) {
                    var Et = "";
                    Tt = [];
                    for (bt in ct[K])
                        this.terminals_[bt] && bt > Le && Tt.push("'" + this.terminals_[bt] + "'");
                    z.showPosition ? Et = "Parse error on line " + (yt + 1) + `:
` + z.showPosition() + `
Expecting ` + Tt.join(", ") + ", got '" + (this.terminals_[I] || I) + "'" : Et = "Parse error on line " + (yt + 1) + ": Unexpected " + (I == ie ? "end of input" : "'" + (this.terminals_[I] || I) + "'"), this.parseError(Et, { text: z.match, token: this.terminals_[I] || I, line: z.yylineno, loc: vt, expected: Tt });
                }
                if (W[0] instanceof Array && W.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + K + ", token: " + I);
                switch (W[0]) {
                    case 1:
                        u.push(I), S.push(z.yytext), e.push(z.yylloc), u.push(W[1]), I = null, Ct ? (I = Ct, Ct = null) : (te = z.yyleng, n = z.yytext, yt = z.yylineno, vt = z.yylloc, ee > 0 && ee--);
                        break;
                    case 2:
                        if (Y = this.productions_[W[1]][1], ot.$ = S[S.length - Y], ot._$ = { first_line: e[e.length - (Y || 1)].first_line, last_line: e[e.length - 1].last_line, first_column: e[e.length - (Y || 1)].first_column, last_column: e[e.length - 1].last_column }, De && (ot._$.range = [e[e.length - (Y || 1)].range[0], e[e.length - 1].range[1]]), Lt = this.performAction.apply(ot, [n, te, yt, G.yy, W[1], S, e].concat(Ee)), typeof Lt < "u")
                            return Lt;
                        Y && (u = u.slice(0, -1 * Y * 2), S = S.slice(0, -1 * Y), e = e.slice(0, -1 * Y)), u.push(this.productions_[W[1]][0]), S.push(ot.$), e.push(ot._$), ne = ct[u[u.length - 2]][u[u.length - 1]], u.push(ne);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, Ce = (function () {
        var j = { EOF: 1, parseError: s(function (l, u) { if (this.yy.parser)
                this.yy.parser.parseError(l, u);
            else
                throw new Error(l); }, "parseError"), setInput: s(function (r, l) { return this.yy = l || this.yy || {}, this._input = r, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: s(function () { var r = this._input[0]; this.yytext += r, this.yyleng++, this.offset++, this.match += r, this.matched += r; var l = r.match(/(?:\r\n?|\n).*/g); return l ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), r; }, "input"), unput: s(function (r) { var l = r.length, u = r.split(/(?:\r\n?|\n)/g); this._input = r + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - l), this.offset -= l; var d = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), u.length - 1 && (this.yylineno -= u.length - 1); var S = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: u ? (u.length === d.length ? this.yylloc.first_column : 0) + d[d.length - u.length].length - u[0].length : this.yylloc.first_column - l }, this.options.ranges && (this.yylloc.range = [S[0], S[0] + this.yyleng - l]), this.yyleng = this.yytext.length, this; }, "unput"), more: s(function () { return this._more = !0, this; }, "more"), reject: s(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: s(function (r) { this.unput(this.match.slice(r)); }, "less"), pastInput: s(function () { var r = this.matched.substr(0, this.matched.length - this.match.length); return (r.length > 20 ? "..." : "") + r.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: s(function () { var r = this.match; return r.length < 20 && (r += this._input.substr(0, 20 - r.length)), (r.substr(0, 20) + (r.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: s(function () {
                var r = this.pastInput(), l = new Array(r.length + 1).join("-");
                return r + this.upcomingInput() + `
` + l + "^";
            }, "showPosition"), test_match: s(function (r, l) { var u, d, S; if (this.options.backtrack_lexer && (S = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (S.yylloc.range = this.yylloc.range.slice(0))), d = r[0].match(/(?:\r\n?|\n).*/g), d && (this.yylineno += d.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: d ? d[d.length - 1].length - d[d.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + r[0].length }, this.yytext += r[0], this.match += r[0], this.matches = r, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(r[0].length), this.matched += r[0], u = this.performAction.call(this, this.yy, this, l, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), u)
                return u; if (this._backtrack) {
                for (var e in S)
                    this[e] = S[e];
                return !1;
            } return !1; }, "test_match"), next: s(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var r, l, u, d;
                this._more || (this.yytext = "", this.match = "");
                for (var S = this._currentRules(), e = 0; e < S.length; e++)
                    if (u = this._input.match(this.rules[S[e]]), u && (!l || u[0].length > l[0].length)) {
                        if (l = u, d = e, this.options.backtrack_lexer) {
                            if (r = this.test_match(u, S[e]), r !== !1)
                                return r;
                            if (this._backtrack) {
                                l = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return l ? (r = this.test_match(l, S[d]), r !== !1 ? r : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: s(function () { var l = this.next(); return l || this.lex(); }, "lex"), begin: s(function (l) { this.conditionStack.push(l); }, "begin"), popState: s(function () { var l = this.conditionStack.length - 1; return l > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: s(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: s(function (l) { return l = this.conditionStack.length - 1 - Math.abs(l || 0), l >= 0 ? this.conditionStack[l] : "INITIAL"; }, "topState"), pushState: s(function (l) { this.begin(l); }, "pushState"), stateStackSize: s(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: s(function (l, u, d, S) { var e = S; switch (d) {
                case 0: break;
                case 1: break;
                case 2: return 55;
                case 3: break;
                case 4:
                    return this.begin("title"), 35;
                    break;
                case 5:
                    return this.popState(), "title_value";
                    break;
                case 6:
                    return this.begin("acc_title"), 37;
                    break;
                case 7:
                    return this.popState(), "acc_title_value";
                    break;
                case 8:
                    return this.begin("acc_descr"), 39;
                    break;
                case 9:
                    return this.popState(), "acc_descr_value";
                    break;
                case 10:
                    this.begin("acc_descr_multiline");
                    break;
                case 11:
                    this.popState();
                    break;
                case 12: return "acc_descr_multiline_value";
                case 13: return 48;
                case 14: return 50;
                case 15: return 49;
                case 16: return 51;
                case 17: return 52;
                case 18: return 53;
                case 19: return 54;
                case 20: return 25;
                case 21:
                    this.begin("md_string");
                    break;
                case 22: return "MD_STR";
                case 23:
                    this.popState();
                    break;
                case 24:
                    this.begin("string");
                    break;
                case 25:
                    this.popState();
                    break;
                case 26: return "STR";
                case 27:
                    this.begin("class_name");
                    break;
                case 28:
                    return this.popState(), 47;
                    break;
                case 29:
                    return this.begin("point_start"), 44;
                    break;
                case 30:
                    return this.begin("point_x"), 45;
                    break;
                case 31:
                    this.popState();
                    break;
                case 32:
                    this.popState(), this.begin("point_y");
                    break;
                case 33:
                    return this.popState(), 46;
                    break;
                case 34: return 28;
                case 35: return 4;
                case 36: return 15;
                case 37: return 11;
                case 38: return 64;
                case 39: return 10;
                case 40: return 65;
                case 41: return 65;
                case 42: return 14;
                case 43: return 13;
                case 44: return 67;
                case 45: return 66;
                case 46: return 12;
                case 47: return 8;
                case 48: return 5;
                case 49: return 18;
                case 50: return 56;
                case 51: return 63;
                case 52: return 57;
            } }, "anonymous"), rules: [/^(?:%%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[\n\r]+)/i, /^(?:%%[^\n]*)/i, /^(?:title\b)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:[\}])/i, /^(?:[^\}]*)/i, /^(?: *x-axis *)/i, /^(?: *y-axis *)/i, /^(?: *--+> *)/i, /^(?: *quadrant-1 *)/i, /^(?: *quadrant-2 *)/i, /^(?: *quadrant-3 *)/i, /^(?: *quadrant-4 *)/i, /^(?:classDef\b)/i, /^(?:["][`])/i, /^(?:[^`"]+)/i, /^(?:[`]["])/i, /^(?:["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?::::)/i, /^(?:^\w+)/i, /^(?:\s*:\s*\[\s*)/i, /^(?:(1)|(0(.\d+)?))/i, /^(?:\s*\] *)/i, /^(?:\s*,\s*)/i, /^(?:(1)|(0(.\d+)?))/i, /^(?: *quadrantChart *)/i, /^(?:[A-Za-z]+)/i, /^(?:[^\x00-\x7F]+)/i, /^(?::)/i, /^(?:\+)/i, /^(?:,)/i, /^(?:=)/i, /^(?:=)/i, /^(?:\*)/i, /^(?:#)/i, /^(?:[\_])/i, /^(?:\.)/i, /^(?:&)/i, /^(?:-)/i, /^(?:[0-9]+)/i, /^(?:\s)/i, /^(?:;)/i, /^(?:[!"#$%&'*+,-.`?\\_/])/i, /^(?:$)/i], conditions: { class_name: { rules: [28], inclusive: !1 }, point_y: { rules: [33], inclusive: !1 }, point_x: { rules: [32], inclusive: !1 }, point_start: { rules: [30, 31], inclusive: !1 }, acc_descr_multiline: { rules: [11, 12], inclusive: !1 }, acc_descr: { rules: [9], inclusive: !1 }, acc_title: { rules: [7], inclusive: !1 }, title: { rules: [5], inclusive: !1 }, md_string: { rules: [22, 23], inclusive: !1 }, string: { rules: [25, 26], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 6, 8, 10, 13, 14, 15, 16, 17, 18, 19, 20, 21, 24, 27, 29, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52], inclusive: !0 } } };
        return j;
    })();
    Ft.lexer = Ce;
    function pt() { this.yy = {}; }
    return s(pt, "Parser"), pt.prototype = Ft, Ft.Parser = pt, new pt;
})();
Vt.parser = Vt;
var Ve = Vt, w = re(), Ie = class {
    constructor() { this.classes = new Map, this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData(); }
    static { s(this, "QuadrantBuilder"); }
    getDefaultData() { return { titleText: "", quadrant1Text: "", quadrant2Text: "", quadrant3Text: "", quadrant4Text: "", xAxisLeftText: "", xAxisRightText: "", yAxisBottomText: "", yAxisTopText: "", points: [] }; }
    getDefaultConfig() { return { showXAxis: !0, showYAxis: !0, showTitle: !0, chartHeight: D.quadrantChart?.chartWidth || 500, chartWidth: D.quadrantChart?.chartHeight || 500, titlePadding: D.quadrantChart?.titlePadding || 10, titleFontSize: D.quadrantChart?.titleFontSize || 20, quadrantPadding: D.quadrantChart?.quadrantPadding || 5, xAxisLabelPadding: D.quadrantChart?.xAxisLabelPadding || 5, yAxisLabelPadding: D.quadrantChart?.yAxisLabelPadding || 5, xAxisLabelFontSize: D.quadrantChart?.xAxisLabelFontSize || 16, yAxisLabelFontSize: D.quadrantChart?.yAxisLabelFontSize || 16, quadrantLabelFontSize: D.quadrantChart?.quadrantLabelFontSize || 16, quadrantTextTopPadding: D.quadrantChart?.quadrantTextTopPadding || 5, pointTextPadding: D.quadrantChart?.pointTextPadding || 5, pointLabelFontSize: D.quadrantChart?.pointLabelFontSize || 12, pointRadius: D.quadrantChart?.pointRadius || 5, xAxisPosition: D.quadrantChart?.xAxisPosition || "top", yAxisPosition: D.quadrantChart?.yAxisPosition || "left", quadrantInternalBorderStrokeWidth: D.quadrantChart?.quadrantInternalBorderStrokeWidth || 1, quadrantExternalBorderStrokeWidth: D.quadrantChart?.quadrantExternalBorderStrokeWidth || 2 }; }
    getDefaultThemeConfig() { return { quadrant1Fill: w.quadrant1Fill, quadrant2Fill: w.quadrant2Fill, quadrant3Fill: w.quadrant3Fill, quadrant4Fill: w.quadrant4Fill, quadrant1TextFill: w.quadrant1TextFill, quadrant2TextFill: w.quadrant2TextFill, quadrant3TextFill: w.quadrant3TextFill, quadrant4TextFill: w.quadrant4TextFill, quadrantPointFill: w.quadrantPointFill, quadrantPointTextFill: w.quadrantPointTextFill, quadrantXAxisTextFill: w.quadrantXAxisTextFill, quadrantYAxisTextFill: w.quadrantYAxisTextFill, quadrantTitleFill: w.quadrantTitleFill, quadrantInternalBorderStrokeFill: w.quadrantInternalBorderStrokeFill, quadrantExternalBorderStrokeFill: w.quadrantExternalBorderStrokeFill }; }
    clear() { this.config = this.getDefaultConfig(), this.themeConfig = this.getDefaultThemeConfig(), this.data = this.getDefaultData(), this.classes = new Map, dt.info("clear called"); }
    setData(t) { this.data = O(O({}, this.data), t); }
    addPoints(t) { this.data.points = [...t, ...this.data.points]; }
    addClass(t, a) { this.classes.set(t, a); }
    setConfig(t) { dt.trace("setConfig called with: ", t), this.config = O(O({}, this.config), t); }
    setThemeConfig(t) { dt.trace("setThemeConfig called with: ", t), this.themeConfig = O(O({}, this.themeConfig), t); }
    calculateSpace(t, a, p, f) { let o = this.config.xAxisLabelPadding * 2 + this.config.xAxisLabelFontSize, x = { top: t === "top" && a ? o : 0, bottom: t === "bottom" && a ? o : 0 }, _ = this.config.yAxisLabelPadding * 2 + this.config.yAxisLabelFontSize, h = { left: this.config.yAxisPosition === "left" && p ? _ : 0, right: this.config.yAxisPosition === "right" && p ? _ : 0 }, c = this.config.titleFontSize + this.config.titlePadding * 2, k = { top: f ? c : 0 }, m = this.config.quadrantPadding + h.left, q = this.config.quadrantPadding + x.top + k.top, y = this.config.chartWidth - this.config.quadrantPadding * 2 - h.left - h.right, b = this.config.chartHeight - this.config.quadrantPadding * 2 - x.top - x.bottom - k.top, T = y / 2, g = b / 2; return { xAxisSpace: x, yAxisSpace: h, titleSpace: k, quadrantSpace: { quadrantLeft: m, quadrantTop: q, quadrantWidth: y, quadrantHalfWidth: T, quadrantHeight: b, quadrantHalfHeight: g } }; }
    getAxisLabels(t, a, p, f) { let { quadrantSpace: o, titleSpace: x } = f, { quadrantHalfHeight: _, quadrantHeight: h, quadrantLeft: c, quadrantHalfWidth: k, quadrantTop: m, quadrantWidth: q } = o, y = !!this.data.xAxisRightText, b = !!this.data.yAxisTopText, T = []; return this.data.xAxisLeftText && a && T.push({ text: this.data.xAxisLeftText, fill: this.themeConfig.quadrantXAxisTextFill, x: c + (y ? k / 2 : 0), y: t === "top" ? this.config.xAxisLabelPadding + x.top : this.config.xAxisLabelPadding + m + h + this.config.quadrantPadding, fontSize: this.config.xAxisLabelFontSize, verticalPos: y ? "center" : "left", horizontalPos: "top", rotation: 0 }), this.data.xAxisRightText && a && T.push({ text: this.data.xAxisRightText, fill: this.themeConfig.quadrantXAxisTextFill, x: c + k + (y ? k / 2 : 0), y: t === "top" ? this.config.xAxisLabelPadding + x.top : this.config.xAxisLabelPadding + m + h + this.config.quadrantPadding, fontSize: this.config.xAxisLabelFontSize, verticalPos: y ? "center" : "left", horizontalPos: "top", rotation: 0 }), this.data.yAxisBottomText && p && T.push({ text: this.data.yAxisBottomText, fill: this.themeConfig.quadrantYAxisTextFill, x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + c + q + this.config.quadrantPadding, y: m + h - (b ? _ / 2 : 0), fontSize: this.config.yAxisLabelFontSize, verticalPos: b ? "center" : "left", horizontalPos: "top", rotation: -90 }), this.data.yAxisTopText && p && T.push({ text: this.data.yAxisTopText, fill: this.themeConfig.quadrantYAxisTextFill, x: this.config.yAxisPosition === "left" ? this.config.yAxisLabelPadding : this.config.yAxisLabelPadding + c + q + this.config.quadrantPadding, y: m + _ - (b ? _ / 2 : 0), fontSize: this.config.yAxisLabelFontSize, verticalPos: b ? "center" : "left", horizontalPos: "top", rotation: -90 }), T; }
    getQuadrants(t) { let { quadrantSpace: a } = t, { quadrantHalfHeight: p, quadrantLeft: f, quadrantHalfWidth: o, quadrantTop: x } = a, _ = [{ text: { text: this.data.quadrant1Text, fill: this.themeConfig.quadrant1TextFill, x: 0, y: 0, fontSize: this.config.quadrantLabelFontSize, verticalPos: "center", horizontalPos: "middle", rotation: 0 }, x: f + o, y: x, width: o, height: p, fill: this.themeConfig.quadrant1Fill }, { text: { text: this.data.quadrant2Text, fill: this.themeConfig.quadrant2TextFill, x: 0, y: 0, fontSize: this.config.quadrantLabelFontSize, verticalPos: "center", horizontalPos: "middle", rotation: 0 }, x: f, y: x, width: o, height: p, fill: this.themeConfig.quadrant2Fill }, { text: { text: this.data.quadrant3Text, fill: this.themeConfig.quadrant3TextFill, x: 0, y: 0, fontSize: this.config.quadrantLabelFontSize, verticalPos: "center", horizontalPos: "middle", rotation: 0 }, x: f, y: x + p, width: o, height: p, fill: this.themeConfig.quadrant3Fill }, { text: { text: this.data.quadrant4Text, fill: this.themeConfig.quadrant4TextFill, x: 0, y: 0, fontSize: this.config.quadrantLabelFontSize, verticalPos: "center", horizontalPos: "middle", rotation: 0 }, x: f + o, y: x + p, width: o, height: p, fill: this.themeConfig.quadrant4Fill }]; for (let h of _)
        h.text.x = h.x + h.width / 2, this.data.points.length === 0 ? (h.text.y = h.y + h.height / 2, h.text.horizontalPos = "middle") : (h.text.y = h.y + this.config.quadrantTextTopPadding, h.text.horizontalPos = "top"); return _; }
    getQuadrantPoints(t) { let { quadrantSpace: a } = t, { quadrantHeight: p, quadrantLeft: f, quadrantTop: o, quadrantWidth: x } = a, _ = zt().domain([0, 1]).range([f, x + f]), h = zt().domain([0, 1]).range([p + o, o]); return this.data.points.map(k => { let m = this.classes.get(k.className); return m && (k = O(O({}, m), k)), { x: _(k.x), y: h(k.y), fill: k.color ?? this.themeConfig.quadrantPointFill, radius: k.radius ?? this.config.pointRadius, text: { text: k.text, fill: this.themeConfig.quadrantPointTextFill, x: _(k.x), y: h(k.y) + this.config.pointTextPadding, verticalPos: "center", horizontalPos: "top", fontSize: this.config.pointLabelFontSize, rotation: 0 }, strokeColor: k.strokeColor ?? this.themeConfig.quadrantPointFill, strokeWidth: k.strokeWidth ?? "0px" }; }); }
    getBorders(t) { let a = this.config.quadrantExternalBorderStrokeWidth / 2, { quadrantSpace: p } = t, { quadrantHalfHeight: f, quadrantHeight: o, quadrantLeft: x, quadrantHalfWidth: _, quadrantTop: h, quadrantWidth: c } = p; return [{ strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill, strokeWidth: this.config.quadrantExternalBorderStrokeWidth, x1: x - a, y1: h, x2: x + c + a, y2: h }, { strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill, strokeWidth: this.config.quadrantExternalBorderStrokeWidth, x1: x + c, y1: h + a, x2: x + c, y2: h + o - a }, { strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill, strokeWidth: this.config.quadrantExternalBorderStrokeWidth, x1: x - a, y1: h + o, x2: x + c + a, y2: h + o }, { strokeFill: this.themeConfig.quadrantExternalBorderStrokeFill, strokeWidth: this.config.quadrantExternalBorderStrokeWidth, x1: x, y1: h + a, x2: x, y2: h + o - a }, { strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill, strokeWidth: this.config.quadrantInternalBorderStrokeWidth, x1: x + _, y1: h + a, x2: x + _, y2: h + o - a }, { strokeFill: this.themeConfig.quadrantInternalBorderStrokeFill, strokeWidth: this.config.quadrantInternalBorderStrokeWidth, x1: x + a, y1: h + f, x2: x + c - a, y2: h + f }]; }
    getTitle(t) { if (t)
        return { text: this.data.titleText, fill: this.themeConfig.quadrantTitleFill, fontSize: this.config.titleFontSize, horizontalPos: "top", verticalPos: "center", rotation: 0, y: this.config.titlePadding, x: this.config.chartWidth / 2 }; }
    build() { let t = this.config.showXAxis && !!(this.data.xAxisLeftText || this.data.xAxisRightText), a = this.config.showYAxis && !!(this.data.yAxisTopText || this.data.yAxisBottomText), p = this.config.showTitle && !!this.data.titleText, f = this.data.points.length > 0 ? "bottom" : this.config.xAxisPosition, o = this.calculateSpace(f, t, a, p); return { points: this.getQuadrantPoints(o), quadrants: this.getQuadrants(o), axisLabels: this.getAxisLabels(f, t, a, o), borderLines: this.getBorders(o), title: this.getTitle(p) }; }
}, kt = class extends Error {
    static { s(this, "InvalidStyleError"); }
    constructor(t, a, p) { super(`value for ${t} ${a} is invalid, please use a valid ${p}`), this.name = "InvalidStyleError"; }
};
function It(t) { return !/^#?([\dA-Fa-f]{6}|[\dA-Fa-f]{3})$/.test(t); }
s(It, "validateHexCode");
function fe(t) { return !/^\d+$/.test(t); }
s(fe, "validateNumber");
function ge(t) { return !/^\d+px$/.test(t); }
s(ge, "validateSizeInPixels");
function H(t) { return se(t.trim(), mt()); }
s(H, "textSanitizer");
var V = new Ie;
function pe(t) { V.setData({ quadrant1Text: H(t.text) }); }
s(pe, "setQuadrant1Text");
function ye(t) { V.setData({ quadrant2Text: H(t.text) }); }
s(ye, "setQuadrant2Text");
function be(t) { V.setData({ quadrant3Text: H(t.text) }); }
s(be, "setQuadrant3Text");
function Te(t) { V.setData({ quadrant4Text: H(t.text) }); }
s(Te, "setQuadrant4Text");
function me(t) { V.setData({ xAxisLeftText: H(t.text) }); }
s(me, "setXAxisLeftText");
function qe(t) { V.setData({ xAxisRightText: H(t.text) }); }
s(qe, "setXAxisRightText");
function ke(t) { V.setData({ yAxisTopText: H(t.text) }); }
s(ke, "setYAxisTopText");
function Se(t) { V.setData({ yAxisBottomText: H(t.text) }); }
s(Se, "setYAxisBottomText");
function St(t) { let a = {}; for (let p of t) {
    let [f, o] = p.trim().split(/\s*:\s*/);
    if (f === "radius") {
        if (fe(o))
            throw new kt(f, o, "number");
        a.radius = parseInt(o);
    }
    else if (f === "color") {
        if (It(o))
            throw new kt(f, o, "hex code");
        a.color = o;
    }
    else if (f === "stroke-color") {
        if (It(o))
            throw new kt(f, o, "hex code");
        a.strokeColor = o;
    }
    else if (f === "stroke-width") {
        if (ge(o))
            throw new kt(f, o, "number of pixels (eg. 10px)");
        a.strokeWidth = o;
    }
    else
        throw new Error(`style named ${f} is not supported.`);
} return a; }
s(St, "parseStyles");
function _e(t, a, p, f, o) { let x = St(o); V.addPoints([O({ x: p, y: f, text: H(t.text), className: a }, x)]); }
s(_e, "addPoint");
function Ae(t, a) { V.addClass(t, St(a)); }
s(Ae, "addClass");
function Fe(t) { V.setConfig({ chartWidth: t }); }
s(Fe, "setWidth");
function Pe(t) { V.setConfig({ chartHeight: t }); }
s(Pe, "setHeight");
function ve() { let t = mt(), { themeVariables: a, quadrantChart: p } = t; return p && V.setConfig(p), V.setThemeConfig({ quadrant1Fill: a.quadrant1Fill, quadrant2Fill: a.quadrant2Fill, quadrant3Fill: a.quadrant3Fill, quadrant4Fill: a.quadrant4Fill, quadrant1TextFill: a.quadrant1TextFill, quadrant2TextFill: a.quadrant2TextFill, quadrant3TextFill: a.quadrant3TextFill, quadrant4TextFill: a.quadrant4TextFill, quadrantPointFill: a.quadrantPointFill, quadrantPointTextFill: a.quadrantPointTextFill, quadrantXAxisTextFill: a.quadrantXAxisTextFill, quadrantYAxisTextFill: a.quadrantYAxisTextFill, quadrantExternalBorderStrokeFill: a.quadrantExternalBorderStrokeFill, quadrantInternalBorderStrokeFill: a.quadrantInternalBorderStrokeFill, quadrantTitleFill: a.quadrantTitleFill }), V.setData({ titleText: Dt() }), V.build(); }
s(ve, "getQuadrantData");
var we = s(function () { V.clear(), le(); }, "clear"), Be = { setWidth: Fe, setHeight: Pe, setQuadrant1Text: pe, setQuadrant2Text: ye, setQuadrant3Text: be, setQuadrant4Text: Te, setXAxisLeftText: me, setXAxisRightText: qe, setYAxisTopText: ke, setYAxisBottomText: Se, parseStyles: St, addPoint: _e, addClass: Ae, getQuadrantData: ve, clear: we, setAccTitle: he, getAccTitle: ce, setDiagramTitle: xe, getDiagramTitle: Dt, getAccDescription: ue, setAccDescription: de }, Re = s((t, a, p, f) => {
    function o(i) { return i === "top" ? "hanging" : "middle"; }
    s(o, "getDominantBaseLine");
    function x(i) { return i === "left" ? "start" : "middle"; }
    s(x, "getTextAnchor");
    function _(i) { return `translate(${i.x}, ${i.y}) rotate(${i.rotation || 0})`; }
    s(_, "getTransformation");
    let h = mt();
    dt.debug(`Rendering quadrant chart
` + t);
    let c = h.securityLevel, k;
    c === "sandbox" && (k = qt("#i" + a));
    let q = (c === "sandbox" ? qt(k.nodes()[0].contentDocument.body) : qt("body")).select(`[id="${a}"]`), y = q.append("g").attr("class", "main"), b = h.quadrantChart?.chartWidth ?? 500, T = h.quadrantChart?.chartHeight ?? 500;
    oe(q, T, b, h.quadrantChart?.useMaxWidth ?? !0), q.attr("viewBox", "0 0 " + b + " " + T), f.db.setHeight(T), f.db.setWidth(b);
    let g = f.db.getQuadrantData(), A = y.append("g").attr("class", "quadrants"), ut = y.append("g").attr("class", "border"), xt = y.append("g").attr("class", "data-points"), ft = y.append("g").attr("class", "labels"), gt = y.append("g").attr("class", "title");
    g.title && gt.append("text").attr("x", 0).attr("y", 0).attr("fill", g.title.fill).attr("font-size", g.title.fontSize).attr("dominant-baseline", o(g.title.horizontalPos)).attr("text-anchor", x(g.title.verticalPos)).attr("transform", _(g.title)).text(g.title.text), g.borderLines && ut.selectAll("line").data(g.borderLines).enter().append("line").attr("x1", i => i.x1).attr("y1", i => i.y1).attr("x2", i => i.x2).attr("y2", i => i.y2).style("stroke", i => i.strokeFill).style("stroke-width", i => i.strokeWidth);
    let lt = A.selectAll("g.quadrant").data(g.quadrants).enter().append("g").attr("class", "quadrant");
    lt.append("rect").attr("x", i => i.x).attr("y", i => i.y).attr("width", i => i.width).attr("height", i => i.height).attr("fill", i => i.fill), lt.append("text").attr("x", 0).attr("y", 0).attr("fill", i => i.text.fill).attr("font-size", i => i.text.fontSize).attr("dominant-baseline", i => o(i.text.horizontalPos)).attr("text-anchor", i => x(i.text.verticalPos)).attr("transform", i => _(i.text)).text(i => i.text.text), ft.selectAll("g.label").data(g.axisLabels).enter().append("g").attr("class", "label").append("text").attr("x", 0).attr("y", 0).text(i => i.text).attr("fill", i => i.fill).attr("font-size", i => i.fontSize).attr("dominant-baseline", i => o(i.horizontalPos)).attr("text-anchor", i => x(i.verticalPos)).attr("transform", i => _(i));
    let ht = xt.selectAll("g.data-point").data(g.points).enter().append("g").attr("class", "data-point");
    ht.append("circle").attr("cx", i => i.x).attr("cy", i => i.y).attr("r", i => i.radius).attr("fill", i => i.fill).attr("stroke", i => i.strokeColor).attr("stroke-width", i => i.strokeWidth), ht.append("text").attr("x", 0).attr("y", 0).text(i => i.text.text).attr("fill", i => i.text.fill).attr("font-size", i => i.text.fontSize).attr("dominant-baseline", i => o(i.text.horizontalPos)).attr("text-anchor", i => x(i.text.verticalPos)).attr("transform", i => _(i.text));
}, "draw"), Ne = { draw: Re }, Me = { parser: Ve, db: Be, renderer: Ne, styles: s(() => "", "styles") };
export { Me as diagram };
