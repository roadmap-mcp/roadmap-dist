import { a as e, b as d, c as o, d as a, e as n, g as i, o as u, x as l, y as s } from "@nf-internal/chunk-EPGORQP5";
var m = class extends s {
    static { e(this, "RadarTokenBuilder"); }
    constructor() { super(["radar-beta"]); }
}, v = { parser: { TokenBuilder: e(() => new m, "TokenBuilder"), ValueConverter: e(() => new l, "ValueConverter") } };
function R(c = n) { let r = a(o(c), i), t = a(d({ shared: r }), u, v); return r.ServiceRegistry.register(t), { shared: r, Radar: t }; }
e(R, "createRadarServices");
export { v as a, R as b };
