import { a as dt } from "@nf-internal/chunk-YQ6X4GJP";
import { a as ft } from "@nf-internal/chunk-PRKFGJVH";
import { n as yt } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { N as nt, O as at, T as rt, U as lt, V as ot, W as ht, X as ct, Y as Q, Z as ut, _ as J } from "@nf-internal/chunk-LEJRRF65";
import "@nf-internal/chunk-RZWXGGKD";
import { a as l } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var et = (function () {
    var t = l(function (M, e, s, i) { for (s = s || {}, i = M.length; i--; s[M[i]] = e)
        ; return s; }, "o"), d = [1, 4], a = [1, 14], r = [1, 12], o = [1, 13], y = [6, 7, 8], p = [1, 20], u = [1, 18], w = [1, 19], c = [6, 7, 11], m = [1, 6, 13, 14], k = [1, 23], _ = [1, 24], x = [1, 6, 7, 11, 13, 14], N = { trace: l(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, ishikawa: 4, spaceLines: 5, SPACELINE: 6, NL: 7, ISHIKAWA: 8, document: 9, stop: 10, EOF: 11, statement: 12, SPACELIST: 13, TEXT: 14, $accept: 0, $end: 1 }, terminals_: { 2: "error", 6: "SPACELINE", 7: "NL", 8: "ISHIKAWA", 11: "EOF", 13: "SPACELIST", 14: "TEXT" }, productions_: [0, [3, 1], [3, 2], [5, 1], [5, 2], [5, 2], [4, 2], [4, 3], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [9, 3], [9, 2], [12, 2], [12, 1], [12, 1], [12, 1]], performAction: l(function (e, s, i, h, f, n, v) { var b = n.length - 1; switch (f) {
            case 6:
            case 7: return h;
            case 15:
                h.addNode(n[b - 1].length, n[b].trim());
                break;
            case 16:
                h.addNode(0, n[b].trim());
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 8: d }, { 1: [3] }, { 1: [2, 1] }, { 4: 6, 6: [1, 7], 7: [1, 8], 8: d }, { 6: a, 7: [1, 10], 9: 9, 12: 11, 13: r, 14: o }, t(y, [2, 3]), { 1: [2, 2] }, t(y, [2, 4]), t(y, [2, 5]), { 1: [2, 6], 6: a, 12: 15, 13: r, 14: o }, { 6: a, 9: 16, 12: 11, 13: r, 14: o }, { 6: p, 7: u, 10: 17, 11: w }, t(c, [2, 18], { 14: [1, 21] }), t(c, [2, 16]), t(c, [2, 17]), { 6: p, 7: u, 10: 22, 11: w }, { 1: [2, 7], 6: a, 12: 15, 13: r, 14: o }, t(m, [2, 14], { 7: k, 11: _ }), t(x, [2, 8]), t(x, [2, 9]), t(x, [2, 10]), t(c, [2, 15]), t(m, [2, 13], { 7: k, 11: _ }), t(x, [2, 11]), t(x, [2, 12])], defaultActions: { 2: [2, 1], 6: [2, 2] }, parseError: l(function (e, s) { if (s.recoverable)
            this.trace(e);
        else {
            var i = new Error(e);
            throw i.hash = s, i;
        } }, "parseError"), parse: l(function (e) {
            var s = this, i = [0], h = [], f = [null], n = [], v = this.table, b = "", I = 0, S = 0, A = 0, L = 2, O = 1, Z = n.slice.call(arguments, 1), g = Object.create(this.lexer), E = { yy: {} };
            for (var V in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, V) && (E.yy[V] = this.yy[V]);
            g.setInput(e, E.yy), E.yy.lexer = g, E.yy.parser = this, typeof g.yylloc > "u" && (g.yylloc = {});
            var R = g.yylloc;
            n.push(R);
            var X = g.options && g.options.ranges;
            typeof E.yy.parseError == "function" ? this.parseError = E.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function xt(P) { i.length = i.length - 2 * P, f.length = f.length - P, n.length = n.length - P; }
            l(xt, "popStack");
            function it() { var P; return P = h.pop() || g.lex() || O, typeof P != "number" && (P instanceof Array && (h = P, P = h.pop()), P = s.symbols_[P] || P), P; }
            l(it, "lex");
            for (var T, Y, W, B, Vt, K, F = {}, H, C, st, G;;) {
                if (W = i[i.length - 1], this.defaultActions[W] ? B = this.defaultActions[W] : ((T === null || typeof T > "u") && (T = it()), B = v[W] && v[W][T]), typeof B > "u" || !B.length || !B[0]) {
                    var q = "";
                    G = [];
                    for (H in v[W])
                        this.terminals_[H] && H > L && G.push("'" + this.terminals_[H] + "'");
                    g.showPosition ? q = "Parse error on line " + (I + 1) + `:
` + g.showPosition() + `
Expecting ` + G.join(", ") + ", got '" + (this.terminals_[T] || T) + "'" : q = "Parse error on line " + (I + 1) + ": Unexpected " + (T == O ? "end of input" : "'" + (this.terminals_[T] || T) + "'"), this.parseError(q, { text: g.match, token: this.terminals_[T] || T, line: g.yylineno, loc: R, expected: G });
                }
                if (B[0] instanceof Array && B.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + W + ", token: " + T);
                switch (B[0]) {
                    case 1:
                        i.push(T), f.push(g.yytext), n.push(g.yylloc), i.push(B[1]), T = null, Y ? (T = Y, Y = null) : (S = g.yyleng, b = g.yytext, I = g.yylineno, R = g.yylloc, A > 0 && A--);
                        break;
                    case 2:
                        if (C = this.productions_[B[1]][1], F.$ = f[f.length - C], F._$ = { first_line: n[n.length - (C || 1)].first_line, last_line: n[n.length - 1].last_line, first_column: n[n.length - (C || 1)].first_column, last_column: n[n.length - 1].last_column }, X && (F._$.range = [n[n.length - (C || 1)].range[0], n[n.length - 1].range[1]]), K = this.performAction.apply(F, [b, S, I, E.yy, B[1], f, n].concat(Z)), typeof K < "u")
                            return K;
                        C && (i = i.slice(0, -1 * C * 2), f = f.slice(0, -1 * C), n = n.slice(0, -1 * C)), i.push(this.productions_[B[1]][0]), f.push(F.$), n.push(F._$), st = v[i[i.length - 2]][i[i.length - 1]], i.push(st);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, D = (function () {
        var M = { EOF: 1, parseError: l(function (s, i) { if (this.yy.parser)
                this.yy.parser.parseError(s, i);
            else
                throw new Error(s); }, "parseError"), setInput: l(function (e, s) { return this.yy = s || this.yy || {}, this._input = e, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: l(function () { var e = this._input[0]; this.yytext += e, this.yyleng++, this.offset++, this.match += e, this.matched += e; var s = e.match(/(?:\r\n?|\n).*/g); return s ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), e; }, "input"), unput: l(function (e) { var s = e.length, i = e.split(/(?:\r\n?|\n)/g); this._input = e + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - s), this.offset -= s; var h = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), i.length - 1 && (this.yylineno -= i.length - 1); var f = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: i ? (i.length === h.length ? this.yylloc.first_column : 0) + h[h.length - i.length].length - i[0].length : this.yylloc.first_column - s }, this.options.ranges && (this.yylloc.range = [f[0], f[0] + this.yyleng - s]), this.yyleng = this.yytext.length, this; }, "unput"), more: l(function () { return this._more = !0, this; }, "more"), reject: l(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: l(function (e) { this.unput(this.match.slice(e)); }, "less"), pastInput: l(function () { var e = this.matched.substr(0, this.matched.length - this.match.length); return (e.length > 20 ? "..." : "") + e.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: l(function () { var e = this.match; return e.length < 20 && (e += this._input.substr(0, 20 - e.length)), (e.substr(0, 20) + (e.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: l(function () {
                var e = this.pastInput(), s = new Array(e.length + 1).join("-");
                return e + this.upcomingInput() + `
` + s + "^";
            }, "showPosition"), test_match: l(function (e, s) { var i, h, f; if (this.options.backtrack_lexer && (f = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (f.yylloc.range = this.yylloc.range.slice(0))), h = e[0].match(/(?:\r\n?|\n).*/g), h && (this.yylineno += h.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: h ? h[h.length - 1].length - h[h.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + e[0].length }, this.yytext += e[0], this.match += e[0], this.matches = e, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(e[0].length), this.matched += e[0], i = this.performAction.call(this, this.yy, this, s, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), i)
                return i; if (this._backtrack) {
                for (var n in f)
                    this[n] = f[n];
                return !1;
            } return !1; }, "test_match"), next: l(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var e, s, i, h;
                this._more || (this.yytext = "", this.match = "");
                for (var f = this._currentRules(), n = 0; n < f.length; n++)
                    if (i = this._input.match(this.rules[f[n]]), i && (!s || i[0].length > s[0].length)) {
                        if (s = i, h = n, this.options.backtrack_lexer) {
                            if (e = this.test_match(i, f[n]), e !== !1)
                                return e;
                            if (this._backtrack) {
                                s = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return s ? (e = this.test_match(s, f[h]), e !== !1 ? e : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: l(function () { var s = this.next(); return s || this.lex(); }, "lex"), begin: l(function (s) { this.conditionStack.push(s); }, "begin"), popState: l(function () { var s = this.conditionStack.length - 1; return s > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: l(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: l(function (s) { return s = this.conditionStack.length - 1 - Math.abs(s || 0), s >= 0 ? this.conditionStack[s] : "INITIAL"; }, "topState"), pushState: l(function (s) { this.begin(s); }, "pushState"), stateStackSize: l(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: l(function (s, i, h, f) { var n = f; switch (h) {
                case 0: return 6;
                case 1: return 8;
                case 2: return 8;
                case 3: return 6;
                case 4: return 7;
                case 5: return 13;
                case 6: return 14;
                case 7: return 11;
            } }, "anonymous"), rules: [/^(?:\s*%%.*)/i, /^(?:ishikawa-beta\b)/i, /^(?:ishikawa\b)/i, /^(?:[\s]+[\n])/i, /^(?:[\n]+)/i, /^(?:[\s]+)/i, /^(?:[^\n]+)/i, /^(?:$)/i], conditions: { INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7], inclusive: !0 } } };
        return M;
    })();
    N.lexer = D;
    function $() { this.yy = {}; }
    return l($, "Parser"), $.prototype = N, N.Parser = $, new $;
})();
et.parser = et;
var vt = et, St = class {
    constructor() { this.stack = [], this.clear = this.clear.bind(this), this.addNode = this.addNode.bind(this), this.getRoot = this.getRoot.bind(this); }
    static { l(this, "IshikawaDB"); }
    clear() { this.root = void 0, this.stack = [], this.baseLevel = void 0, rt(); }
    getRoot() { return this.root; }
    addNode(t, d) { let a = nt.sanitizeText(d, J()); if (!this.root) {
        this.root = { text: a, children: [] }, this.stack = [{ level: 0, node: this.root }], Q(a);
        return;
    } this.baseLevel ??= t; let r = t - this.baseLevel + 1; for (r <= 0 && (r = 1); this.stack.length > 1 && this.stack[this.stack.length - 1].level >= r;)
        this.stack.pop(); let o = this.stack[this.stack.length - 1].node, y = { text: a, children: [] }; o.children.push(y), this.stack.push({ level: r, node: y }); }
    getAccTitle() { return ot(); }
    setAccTitle(t) { lt(t); }
    getAccDescription() { return ct(); }
    setAccDescription(t) { ht(t); }
    getDiagramTitle() { return ut(); }
    setDiagramTitle(t) { Q(t); }
}, Et = 14, j = 250, $t = 30, At = 60, It = 5, bt = 82 * Math.PI / 180, pt = Math.cos(bt), gt = Math.sin(bt), kt = l((t, d, a) => { let r = t.node().getBBox(), o = r.width + d * 2, y = r.height + d * 2; at(t, y, o, a), t.attr("viewBox", `${r.x - d} ${r.y - d} ${o} ${y}`); }, "applyPaddedViewBox"), Lt = l((t, d, a, r) => { let y = r.db.getRoot(); if (!y)
    return; let p = J(), { look: u, handDrawnSeed: w, themeVariables: c } = p, m = yt(p.fontSize)[0] ?? Et, k = u === "handDrawn", _ = y.children ?? [], x = p.ishikawa?.diagramPadding ?? 20, N = p.ishikawa?.useMaxWidth ?? !1, D = dt(d), $ = D.append("g").attr("class", "ishikawa"), M = k ? ft.svg(D.node()) : void 0, e = M ? { roughSvg: M, seed: w ?? 0, lineColor: c?.lineColor ?? "#333", fillColor: c?.mainBkg ?? "#fff" } : void 0, s = `ishikawa-arrow-${d}`; k || $.append("defs").append("marker").attr("id", s).attr("viewBox", "0 0 10 10").attr("refX", 0).attr("refY", 5).attr("markerWidth", 6).attr("markerHeight", 6).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 Z").attr("class", "ishikawa-arrow"); let i = 0, h = j, f = k ? void 0 : z($, i, h, i, h, "ishikawa-spine"); if (Tt($, i, h, y.text, m, e), !_.length) {
    k && z($, i, h, i, h, "ishikawa-spine", e), kt(D, x, N);
    return;
} i -= 20; let n = _.filter((g, E) => E % 2 === 0), v = _.filter((g, E) => E % 2 === 1), b = mt(n), I = mt(v), S = b.total + I.total, A = j, L = j; if (S > 0) {
    let g = j * 2, E = j * .3;
    A = Math.max(E, g * (b.total / S)), L = Math.max(E, g * (I.total / S));
} let O = m * 2; A = Math.max(A, b.max * O), L = Math.max(L, I.max * O), h = Math.max(A, j), f && f.attr("y1", h).attr("y2", h), $.select(".ishikawa-head-group").attr("transform", `translate(0,${h})`); let Z = Math.ceil(_.length / 2); for (let g = 0; g < Z; g++) {
    let E = $.append("g").attr("class", "ishikawa-pair");
    for (let [V, R, X] of [[_[g * 2], -1, A], [_[g * 2 + 1], 1, L]])
        V && Bt(E, V, i, h, R, X, m, e);
    i = E.selectAll("text").nodes().reduce((V, R) => Math.min(V, R.getBBox().x), 1 / 0);
} if (k)
    z($, i, h, 0, h, "ishikawa-spine", e);
else {
    f.attr("x1", i);
    let g = `url(#${s})`;
    $.selectAll("line.ishikawa-branch, line.ishikawa-sub-branch").attr("marker-start", g);
} kt(D, x, N); }, "draw"), mt = l(t => { let d = l(a => a.children.reduce((r, o) => r + 1 + d(o), 0), "countDescendants"); return t.reduce((a, r) => { let o = d(r); return a.total += o, a.max = Math.max(a.max, o), a; }, { total: 0, max: 0 }); }, "sideStats"), Tt = l((t, d, a, r, o, y) => { let p = Math.max(6, Math.floor(110 / (o * .6))), u = t.append("g").attr("class", "ishikawa-head-group").attr("transform", `translate(${d},${a})`), w = U(u, _t(r, p), 0, 0, "ishikawa-head-label", "start", o), c = w.node().getBBox(), m = Math.max(60, c.width + 6), k = Math.max(40, c.height * 2 + 40), _ = `M 0 ${-k / 2} L 0 ${k / 2} Q ${m * 2.4} 0 0 ${-k / 2} Z`; if (y) {
    let x = y.roughSvg.path(_, { roughness: 1.5, seed: y.seed, fill: y.fillColor, fillStyle: "hachure", fillWeight: 2.5, hachureGap: 5, stroke: y.lineColor, strokeWidth: 2 });
    u.insert(() => x, ":first-child").attr("class", "ishikawa-head");
}
else
    u.insert("path", ":first-child").attr("class", "ishikawa-head").attr("d", _); w.attr("transform", `translate(${(m - c.width) / 2 - c.x + 3},${-c.y - c.height / 2})`); }, "drawHead"), Mt = l((t, d) => { let a = [], r = [], o = l((y, p, u) => { let w = d === -1 ? [...y].reverse() : y; for (let c of w) {
    let m = a.length, k = c.children ?? [];
    a.push({ depth: u, text: _t(c.text, 15), parentIndex: p, childCount: k.length }), u % 2 === 0 ? (r.push(m), k.length && o(k, m, u + 1)) : (k.length && o(k, m, u + 1), r.push(m));
} }, "walk"); return o(t, -1, 2), { entries: a, yOrder: r }; }, "flattenTree"), Pt = l((t, d, a, r, o, y, p) => { let u = t.append("g").attr("class", "ishikawa-label-group"), c = U(u, d, a, r + 11 * o, "ishikawa-label cause", "middle", y).node().getBBox(); if (p) {
    let m = p.roughSvg.rectangle(c.x - 20, c.y - 2, c.width + 40, c.height + 4, { roughness: 1.5, seed: p.seed, fill: p.fillColor, fillStyle: "hachure", fillWeight: 2.5, hachureGap: 5, stroke: p.lineColor, strokeWidth: 2 });
    u.insert(() => m, ":first-child").attr("class", "ishikawa-label-box");
}
else
    u.insert("rect", ":first-child").attr("class", "ishikawa-label-box").attr("x", c.x - 20).attr("y", c.y - 2).attr("width", c.width + 40).attr("height", c.height + 4); }, "drawCauseLabel"), tt = l((t, d, a, r, o, y) => { let p = Math.sqrt(r * r + o * o); if (p === 0)
    return; let u = r / p, w = o / p, c = 6, m = -w * c, k = u * c, _ = d, x = a, N = `M ${_} ${x} L ${_ - u * c * 2 + m} ${x - w * c * 2 + k} L ${_ - u * c * 2 - m} ${x - w * c * 2 - k} Z`, D = y.roughSvg.path(N, { roughness: 1, seed: y.seed, fill: y.lineColor, fillStyle: "solid", stroke: y.lineColor, strokeWidth: 1 }); t.append(() => D); }, "drawArrowMarker"), Bt = l((t, d, a, r, o, y, p, u) => { let w = d.children ?? [], c = y * (w.length ? 1 : .2), m = -pt * c, k = gt * c * o, _ = a + m, x = r + k; if (z(t, a, r, _, x, "ishikawa-branch", u), u && tt(t, a, r, a - _, r - x, u), Pt(t, d.text, _, x, o, p, u), !w.length)
    return; let { entries: N, yOrder: D } = Mt(w, o), $ = N.length, M = new Array($); for (let [f, n] of D.entries())
    M[n] = r + k * ((f + 1) / ($ + 1)); let e = new Map; e.set(-1, { x0: a, y0: r, x1: _, y1: x, childCount: w.length, childrenDrawn: 0 }); let s = -pt, i = gt * o, h = o < 0 ? "ishikawa-label up" : "ishikawa-label down"; for (let [f, n] of N.entries()) {
    let v = M[f], b = e.get(n.parentIndex), I = t.append("g").attr("class", "ishikawa-sub-group"), S = 0, A = 0, L = 0;
    if (n.depth % 2 === 0) {
        let O = b.y1 - b.y0;
        S = wt(b.x0, b.x1, O ? (v - b.y0) / O : .5), A = v, L = S - (n.childCount > 0 ? At + n.childCount * It : $t), z(I, S, v, L, v, "ishikawa-sub-branch", u), u && tt(I, S, v, 1, 0, u), U(I, n.text, L, v, "ishikawa-label align", "end", p);
    }
    else {
        let O = b.childrenDrawn++;
        S = wt(b.x0, b.x1, (b.childCount - O) / (b.childCount + 1)), A = b.y0, L = S + s * ((v - A) / i), z(I, S, A, L, v, "ishikawa-sub-branch", u), u && tt(I, S, A, S - L, A - v, u), U(I, n.text, L, v, h, "end", p);
    }
    n.childCount > 0 && e.set(f, { x0: S, y0: A, x1: L, y1: v, childCount: n.childCount, childrenDrawn: 0 });
} }, "drawBranch"), Nt = l(t => t.split(/<br\s*\/?>|\n/), "splitLines"), _t = l((t, d) => {
    if (t.length <= d)
        return t;
    let a = [];
    for (let r of t.split(/\s+/)) {
        let o = a.length - 1;
        o >= 0 && a[o].length + 1 + r.length <= d ? a[o] += " " + r : a.push(r);
    }
    return a.join(`
`);
}, "wrapText"), U = l((t, d, a, r, o, y, p) => { let u = Nt(d), w = p * 1.05, c = t.append("text").attr("class", o).attr("text-anchor", y).attr("x", a).attr("y", r - (u.length - 1) * w / 2); for (let [m, k] of u.entries())
    c.append("tspan").attr("x", a).attr("dy", m === 0 ? 0 : w).text(k); return c; }, "drawMultilineText"), wt = l((t, d, a) => t + (d - t) * a, "lerp"), z = l((t, d, a, r, o, y, p) => { if (p) {
    let u = p.roughSvg.line(d, a, r, o, { roughness: 1.5, seed: p.seed, stroke: p.lineColor, strokeWidth: 2 });
    t.append(() => u).attr("class", y);
    return;
} return t.append("line").attr("class", y).attr("x1", d).attr("y1", a).attr("x2", r).attr("y2", o); }, "drawLine"), Dt = { draw: Lt }, Ot = l(t => `
.ishikawa .ishikawa-spine,
.ishikawa .ishikawa-branch,
.ishikawa .ishikawa-sub-branch {
  stroke: ${t.lineColor};
  stroke-width: 2;
  fill: none;
}

.ishikawa .ishikawa-sub-branch {
  stroke-width: 1;
}

.ishikawa .ishikawa-arrow {
  fill: ${t.lineColor};
}

.ishikawa .ishikawa-head {
  fill: ${t.mainBkg};
  stroke: ${t.lineColor};
  stroke-width: 2;
}

.ishikawa .ishikawa-label-box {
  fill: ${t.mainBkg};
  stroke: ${t.lineColor};
  stroke-width: 2;
}

.ishikawa text {
  font-family: ${t.fontFamily};
  font-size: ${t.fontSize};
  fill: ${t.textColor};
}

.ishikawa .ishikawa-head-label {
  font-weight: 600;
  text-anchor: middle;
  dominant-baseline: middle;
  font-size: 14px;
}

.ishikawa .ishikawa-label {
  text-anchor: end;
}

.ishikawa .ishikawa-label.cause {
  text-anchor: middle;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.align {
  text-anchor: end;
  dominant-baseline: middle;
}

.ishikawa .ishikawa-label.up {
  dominant-baseline: baseline;
}

.ishikawa .ishikawa-label.down {
  dominant-baseline: hanging;
}
`, "getStyles"), Ct = Ot, Gt = { parser: vt, get db() { return new St; }, renderer: Dt, styles: Ct };
export { Gt as diagram };
