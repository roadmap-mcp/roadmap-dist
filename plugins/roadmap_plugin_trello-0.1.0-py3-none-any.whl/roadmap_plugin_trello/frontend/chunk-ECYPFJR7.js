import { a as o, b as d, c, d as i, e as l, g as u, r as v, w as m, y as h } from "@nf-internal/chunk-EPGORQP5";
var f = class extends h {
    static { o(this, "RailroadTokenBuilder"); }
    constructor() { super(["railroad-beta"]); }
}, R = o(a => {
    let e = a.slice(1, -1), r = "";
    for (let t = 0; t < e.length; t++) {
        let n = e[t];
        if (n === "\\" && t + 1 < e.length) {
            t++;
            let s = e[t];
            switch (s) {
                case "n":
                    r += `
`;
                    break;
                case "r":
                    r += "\r";
                    break;
                case "t":
                    r += "	";
                    break;
                default: r += s;
            }
            continue;
        }
        r += n;
    }
    return r;
}, "decodeEscapedString"), p = class extends m {
    static { o(this, "RailroadValueConverter"); }
    runConverter(a, e, r) { let t = super.runConverter(a, e, r); if (a.name === "TITLE" && typeof t == "string") {
        let n = t.trim();
        if (n.startsWith('"') && n.endsWith('"') || n.startsWith("'") && n.endsWith("'"))
            return R(n);
    } return t; }
    runCustomConverter(a, e, r) { if (a.name === "RR_STRING")
        return R(e); }
}, C = { parser: { TokenBuilder: o(() => new f, "TokenBuilder"), ValueConverter: o(() => new p, "ValueConverter") } };
function S(a = l) { let e = i(c(a), u), r = i(d({ shared: e }), v, C); return e.ServiceRegistry.register(r), { shared: e, Railroad: r }; }
o(S, "createRailroadServices");
export { C as a, S as b };
