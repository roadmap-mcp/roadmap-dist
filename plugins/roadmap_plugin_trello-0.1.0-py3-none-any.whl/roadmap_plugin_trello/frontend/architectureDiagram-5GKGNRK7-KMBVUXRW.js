import { a as je } from "@nf-internal/chunk-CDENLQJG";
import { a as _e } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import { a as Ne } from "@nf-internal/chunk-ZB4R55K4";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import { a as ke } from "@nf-internal/chunk-YQ6X4GJP";
import { d as ce } from "@nf-internal/chunk-3SXY7Q5B";
import { a as qe, b as Qe, d as fe } from "@nf-internal/chunk-ZBOYDPPL";
import { o as Je, s as Ke } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { H as Ue, P as Ye, T as Xe, U as He, V as We, W as Ve, X as ze, Y as $e, Z as Be, _ as le, k as Pe, u as Ge } from "@nf-internal/chunk-LEJRRF65";
import { b as Te, h as Ze } from "@nf-internal/chunk-RZWXGGKD";
import { a as ft } from "@nf-internal/chunk-YUSHYV7C";
import { a as ie, b as me, d as Ee, e as mr, f as kt } from "@nf-internal/chunk-OSQMNGTH";
var we = Ee((ne, Le) => { (function (C, N) { typeof ne == "object" && typeof Le == "object" ? Le.exports = N() : typeof define == "function" && define.amd ? define([], N) : typeof ne == "object" ? ne.layoutBase = N() : C.layoutBase = N(); })(ne, function () { return (function (E) { var C = {}; function N(g) { if (C[g])
    return C[g].exports; var s = C[g] = { i: g, l: !1, exports: {} }; return E[g].call(s.exports, s, s.exports, N), s.l = !0, s.exports; } return N.m = E, N.c = C, N.i = function (g) { return g; }, N.d = function (g, s, a) { N.o(g, s) || Object.defineProperty(g, s, { configurable: !1, enumerable: !0, get: a }); }, N.n = function (g) { var s = g && g.__esModule ? function () { return g.default; } : function () { return g; }; return N.d(s, "a", s), s; }, N.o = function (g, s) { return Object.prototype.hasOwnProperty.call(g, s); }, N.p = "", N(N.s = 28); })([(function (E, C, N) {
        "use strict";
        function g() { }
        g.QUALITY = 1, g.DEFAULT_CREATE_BENDS_AS_NEEDED = !1, g.DEFAULT_INCREMENTAL = !1, g.DEFAULT_ANIMATION_ON_LAYOUT = !0, g.DEFAULT_ANIMATION_DURING_LAYOUT = !1, g.DEFAULT_ANIMATION_PERIOD = 50, g.DEFAULT_UNIFORM_LEAF_NODE_SIZES = !1, g.DEFAULT_GRAPH_MARGIN = 15, g.NODE_DIMENSIONS_INCLUDE_LABELS = !1, g.SIMPLE_NODE_SIZE = 40, g.SIMPLE_NODE_HALF_SIZE = g.SIMPLE_NODE_SIZE / 2, g.EMPTY_COMPOUND_NODE_SIZE = 40, g.MIN_EDGE_LENGTH = 1, g.WORLD_BOUNDARY = 1e6, g.INITIAL_WORLD_BOUNDARY = g.WORLD_BOUNDARY / 1e3, g.WORLD_CENTER_X = 1200, g.WORLD_CENTER_Y = 900, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = N(2), s = N(8), a = N(9);
        function i(f, e, u) { g.call(this, u), this.isOverlapingSourceAndTarget = !1, this.vGraphObject = u, this.bendpoints = [], this.source = f, this.target = e; }
        i.prototype = Object.create(g.prototype);
        for (var n in g)
            i[n] = g[n];
        i.prototype.getSource = function () { return this.source; }, i.prototype.getTarget = function () { return this.target; }, i.prototype.isInterGraph = function () { return this.isInterGraph; }, i.prototype.getLength = function () { return this.length; }, i.prototype.isOverlapingSourceAndTarget = function () { return this.isOverlapingSourceAndTarget; }, i.prototype.getBendpoints = function () { return this.bendpoints; }, i.prototype.getLca = function () { return this.lca; }, i.prototype.getSourceInLca = function () { return this.sourceInLca; }, i.prototype.getTargetInLca = function () { return this.targetInLca; }, i.prototype.getOtherEnd = function (f) { if (this.source === f)
            return this.target; if (this.target === f)
            return this.source; throw "Node is not incident with this edge"; }, i.prototype.getOtherEndInGraph = function (f, e) { for (var u = this.getOtherEnd(f), r = e.getGraphManager().getRoot();;) {
            if (u.getOwner() == e)
                return u;
            if (u.getOwner() == r)
                break;
            u = u.getOwner().getParent();
        } return null; }, i.prototype.updateLength = function () { var f = new Array(4); this.isOverlapingSourceAndTarget = s.getIntersection(this.target.getRect(), this.source.getRect(), f), this.isOverlapingSourceAndTarget || (this.lengthX = f[0] - f[2], this.lengthY = f[1] - f[3], Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY)); }, i.prototype.updateLengthSimple = function () { this.lengthX = this.target.getCenterX() - this.source.getCenterX(), this.lengthY = this.target.getCenterY() - this.source.getCenterY(), Math.abs(this.lengthX) < 1 && (this.lengthX = a.sign(this.lengthX)), Math.abs(this.lengthY) < 1 && (this.lengthY = a.sign(this.lengthY)), this.length = Math.sqrt(this.lengthX * this.lengthX + this.lengthY * this.lengthY); }, E.exports = i;
    }), (function (E, C, N) {
        "use strict";
        function g(s) { this.vGraphObject = s; }
        E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = N(2), s = N(10), a = N(13), i = N(0), n = N(16), f = N(5);
        function e(r, t, l, c) { l == null && c == null && (c = t), g.call(this, c), r.graphManager != null && (r = r.graphManager), this.estimatedSize = s.MIN_VALUE, this.inclusionTreeDepth = s.MAX_VALUE, this.vGraphObject = c, this.edges = [], this.graphManager = r, l != null && t != null ? this.rect = new a(t.x, t.y, l.width, l.height) : this.rect = new a; }
        e.prototype = Object.create(g.prototype);
        for (var u in g)
            e[u] = g[u];
        e.prototype.getEdges = function () { return this.edges; }, e.prototype.getChild = function () { return this.child; }, e.prototype.getOwner = function () { return this.owner; }, e.prototype.getWidth = function () { return this.rect.width; }, e.prototype.setWidth = function (r) { this.rect.width = r; }, e.prototype.getHeight = function () { return this.rect.height; }, e.prototype.setHeight = function (r) { this.rect.height = r; }, e.prototype.getCenterX = function () { return this.rect.x + this.rect.width / 2; }, e.prototype.getCenterY = function () { return this.rect.y + this.rect.height / 2; }, e.prototype.getCenter = function () { return new f(this.rect.x + this.rect.width / 2, this.rect.y + this.rect.height / 2); }, e.prototype.getLocation = function () { return new f(this.rect.x, this.rect.y); }, e.prototype.getRect = function () { return this.rect; }, e.prototype.getDiagonal = function () { return Math.sqrt(this.rect.width * this.rect.width + this.rect.height * this.rect.height); }, e.prototype.getHalfTheDiagonal = function () { return Math.sqrt(this.rect.height * this.rect.height + this.rect.width * this.rect.width) / 2; }, e.prototype.setRect = function (r, t) { this.rect.x = r.x, this.rect.y = r.y, this.rect.width = t.width, this.rect.height = t.height; }, e.prototype.setCenter = function (r, t) { this.rect.x = r - this.rect.width / 2, this.rect.y = t - this.rect.height / 2; }, e.prototype.setLocation = function (r, t) { this.rect.x = r, this.rect.y = t; }, e.prototype.moveBy = function (r, t) { this.rect.x += r, this.rect.y += t; }, e.prototype.getEdgeListToNode = function (r) { var t = [], l, c = this; return c.edges.forEach(function (h) { if (h.target == r) {
            if (h.source != c)
                throw "Incorrect edge source!";
            t.push(h);
        } }), t; }, e.prototype.getEdgesBetween = function (r) { var t = [], l, c = this; return c.edges.forEach(function (h) { if (!(h.source == c || h.target == c))
            throw "Incorrect edge source and/or target"; (h.target == r || h.source == r) && t.push(h); }), t; }, e.prototype.getNeighborsList = function () { var r = new Set, t = this; return t.edges.forEach(function (l) { if (l.source == t)
            r.add(l.target);
        else {
            if (l.target != t)
                throw "Incorrect incidency!";
            r.add(l.source);
        } }), r; }, e.prototype.withChildren = function () { var r = new Set, t, l; if (r.add(this), this.child != null)
            for (var c = this.child.getNodes(), h = 0; h < c.length; h++)
                t = c[h], l = t.withChildren(), l.forEach(function (w) { r.add(w); }); return r; }, e.prototype.getNoOfChildren = function () { var r = 0, t; if (this.child == null)
            r = 1;
        else
            for (var l = this.child.getNodes(), c = 0; c < l.length; c++)
                t = l[c], r += t.getNoOfChildren(); return r == 0 && (r = 1), r; }, e.prototype.getEstimatedSize = function () { if (this.estimatedSize == s.MIN_VALUE)
            throw "assert failed"; return this.estimatedSize; }, e.prototype.calcEstimatedSize = function () { return this.child == null ? this.estimatedSize = (this.rect.width + this.rect.height) / 2 : (this.estimatedSize = this.child.calcEstimatedSize(), this.rect.width = this.estimatedSize, this.rect.height = this.estimatedSize, this.estimatedSize); }, e.prototype.scatter = function () { var r, t, l = -i.INITIAL_WORLD_BOUNDARY, c = i.INITIAL_WORLD_BOUNDARY; r = i.WORLD_CENTER_X + n.nextDouble() * (c - l) + l; var h = -i.INITIAL_WORLD_BOUNDARY, w = i.INITIAL_WORLD_BOUNDARY; t = i.WORLD_CENTER_Y + n.nextDouble() * (w - h) + h, this.rect.x = r, this.rect.y = t; }, e.prototype.updateBounds = function () { if (this.getChild() == null)
            throw "assert failed"; if (this.getChild().getNodes().length != 0) {
            var r = this.getChild();
            if (r.updateBounds(!0), this.rect.x = r.getLeft(), this.rect.y = r.getTop(), this.setWidth(r.getRight() - r.getLeft()), this.setHeight(r.getBottom() - r.getTop()), i.NODE_DIMENSIONS_INCLUDE_LABELS) {
                var t = r.getRight() - r.getLeft(), l = r.getBottom() - r.getTop();
                this.labelWidth && (this.labelPosHorizontal == "left" ? (this.rect.x -= this.labelWidth, this.setWidth(t + this.labelWidth)) : this.labelPosHorizontal == "center" && this.labelWidth > t ? (this.rect.x -= (this.labelWidth - t) / 2, this.setWidth(this.labelWidth)) : this.labelPosHorizontal == "right" && this.setWidth(t + this.labelWidth)), this.labelHeight && (this.labelPosVertical == "top" ? (this.rect.y -= this.labelHeight, this.setHeight(l + this.labelHeight)) : this.labelPosVertical == "center" && this.labelHeight > l ? (this.rect.y -= (this.labelHeight - l) / 2, this.setHeight(this.labelHeight)) : this.labelPosVertical == "bottom" && this.setHeight(l + this.labelHeight));
            }
        } }, e.prototype.getInclusionTreeDepth = function () { if (this.inclusionTreeDepth == s.MAX_VALUE)
            throw "assert failed"; return this.inclusionTreeDepth; }, e.prototype.transform = function (r) { var t = this.rect.x; t > i.WORLD_BOUNDARY ? t = i.WORLD_BOUNDARY : t < -i.WORLD_BOUNDARY && (t = -i.WORLD_BOUNDARY); var l = this.rect.y; l > i.WORLD_BOUNDARY ? l = i.WORLD_BOUNDARY : l < -i.WORLD_BOUNDARY && (l = -i.WORLD_BOUNDARY); var c = new f(t, l), h = r.inverseTransformPoint(c); this.setLocation(h.x, h.y); }, e.prototype.getLeft = function () { return this.rect.x; }, e.prototype.getRight = function () { return this.rect.x + this.rect.width; }, e.prototype.getTop = function () { return this.rect.y; }, e.prototype.getBottom = function () { return this.rect.y + this.rect.height; }, e.prototype.getParent = function () { return this.owner == null ? null : this.owner.getParent(); }, E.exports = e;
    }), (function (E, C, N) {
        "use strict";
        var g = N(0);
        function s() { }
        for (var a in g)
            s[a] = g[a];
        s.MAX_ITERATIONS = 2500, s.DEFAULT_EDGE_LENGTH = 50, s.DEFAULT_SPRING_STRENGTH = .45, s.DEFAULT_REPULSION_STRENGTH = 4500, s.DEFAULT_GRAVITY_STRENGTH = .4, s.DEFAULT_COMPOUND_GRAVITY_STRENGTH = 1, s.DEFAULT_GRAVITY_RANGE_FACTOR = 3.8, s.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = 1.5, s.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION = !0, s.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION = !0, s.DEFAULT_COOLING_FACTOR_INCREMENTAL = .3, s.COOLING_ADAPTATION_FACTOR = .33, s.ADAPTATION_LOWER_NODE_LIMIT = 1e3, s.ADAPTATION_UPPER_NODE_LIMIT = 5e3, s.MAX_NODE_DISPLACEMENT_INCREMENTAL = 100, s.MAX_NODE_DISPLACEMENT = s.MAX_NODE_DISPLACEMENT_INCREMENTAL * 3, s.MIN_REPULSION_DIST = s.DEFAULT_EDGE_LENGTH / 10, s.CONVERGENCE_CHECK_PERIOD = 100, s.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = .1, s.MIN_EDGE_LENGTH = 1, s.GRID_CALCULATION_CHECK_PERIOD = 10, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        function g(s, a) { s == null && a == null ? (this.x = 0, this.y = 0) : (this.x = s, this.y = a); }
        g.prototype.getX = function () { return this.x; }, g.prototype.getY = function () { return this.y; }, g.prototype.setX = function (s) { this.x = s; }, g.prototype.setY = function (s) { this.y = s; }, g.prototype.getDifference = function (s) { return new DimensionD(this.x - s.x, this.y - s.y); }, g.prototype.getCopy = function () { return new g(this.x, this.y); }, g.prototype.translate = function (s) { return this.x += s.width, this.y += s.height, this; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = N(2), s = N(10), a = N(0), i = N(7), n = N(3), f = N(1), e = N(13), u = N(12), r = N(11);
        function t(c, h, w) { g.call(this, w), this.estimatedSize = s.MIN_VALUE, this.margin = a.DEFAULT_GRAPH_MARGIN, this.edges = [], this.nodes = [], this.isConnected = !1, this.parent = c, h != null && h instanceof i ? this.graphManager = h : h != null && h instanceof Layout && (this.graphManager = h.graphManager); }
        t.prototype = Object.create(g.prototype);
        for (var l in g)
            t[l] = g[l];
        t.prototype.getNodes = function () { return this.nodes; }, t.prototype.getEdges = function () { return this.edges; }, t.prototype.getGraphManager = function () { return this.graphManager; }, t.prototype.getParent = function () { return this.parent; }, t.prototype.getLeft = function () { return this.left; }, t.prototype.getRight = function () { return this.right; }, t.prototype.getTop = function () { return this.top; }, t.prototype.getBottom = function () { return this.bottom; }, t.prototype.isConnected = function () { return this.isConnected; }, t.prototype.add = function (c, h, w) { if (h == null && w == null) {
            var p = c;
            if (this.graphManager == null)
                throw "Graph has no graph mgr!";
            if (this.getNodes().indexOf(p) > -1)
                throw "Node already in graph!";
            return p.owner = this, this.getNodes().push(p), p;
        }
        else {
            var y = c;
            if (!(this.getNodes().indexOf(h) > -1 && this.getNodes().indexOf(w) > -1))
                throw "Source or target not in graph!";
            if (!(h.owner == w.owner && h.owner == this))
                throw "Both owners must be this graph!";
            return h.owner != w.owner ? null : (y.source = h, y.target = w, y.isInterGraph = !1, this.getEdges().push(y), h.edges.push(y), w != h && w.edges.push(y), y);
        } }, t.prototype.remove = function (c) { var h = c; if (c instanceof n) {
            if (h == null)
                throw "Node is null!";
            if (!(h.owner != null && h.owner == this))
                throw "Owner graph is invalid!";
            if (this.graphManager == null)
                throw "Owner graph manager is invalid!";
            for (var w = h.edges.slice(), p, y = w.length, L = 0; L < y; L++)
                p = w[L], p.isInterGraph ? this.graphManager.remove(p) : p.source.owner.remove(p);
            var I = this.nodes.indexOf(h);
            if (I == -1)
                throw "Node not in owner node list!";
            this.nodes.splice(I, 1);
        }
        else if (c instanceof f) {
            var p = c;
            if (p == null)
                throw "Edge is null!";
            if (!(p.source != null && p.target != null))
                throw "Source and/or target is null!";
            if (!(p.source.owner != null && p.target.owner != null && p.source.owner == this && p.target.owner == this))
                throw "Source and/or target owner is invalid!";
            var M = p.source.edges.indexOf(p), S = p.target.edges.indexOf(p);
            if (!(M > -1 && S > -1))
                throw "Source and/or target doesn't know this edge!";
            p.source.edges.splice(M, 1), p.target != p.source && p.target.edges.splice(S, 1);
            var I = p.source.owner.getEdges().indexOf(p);
            if (I == -1)
                throw "Not in owner's edge list!";
            p.source.owner.getEdges().splice(I, 1);
        } }, t.prototype.updateLeftTop = function () { for (var c = s.MAX_VALUE, h = s.MAX_VALUE, w, p, y, L = this.getNodes(), I = L.length, M = 0; M < I; M++) {
            var S = L[M];
            w = S.getTop(), p = S.getLeft(), c > w && (c = w), h > p && (h = p);
        } return c == s.MAX_VALUE ? null : (L[0].getParent().paddingLeft != null ? y = L[0].getParent().paddingLeft : y = this.margin, this.left = h - y, this.top = c - y, new u(this.left, this.top)); }, t.prototype.updateBounds = function (c) { for (var h = s.MAX_VALUE, w = -s.MAX_VALUE, p = s.MAX_VALUE, y = -s.MAX_VALUE, L, I, M, S, X, G = this.nodes, Q = G.length, O = 0; O < Q; O++) {
            var H = G[O];
            c && H.child != null && H.updateBounds(), L = H.getLeft(), I = H.getRight(), M = H.getTop(), S = H.getBottom(), h > L && (h = L), w < I && (w = I), p > M && (p = M), y < S && (y = S);
        } var o = new e(h, p, w - h, y - p); h == s.MAX_VALUE && (this.left = this.parent.getLeft(), this.right = this.parent.getRight(), this.top = this.parent.getTop(), this.bottom = this.parent.getBottom()), G[0].getParent().paddingLeft != null ? X = G[0].getParent().paddingLeft : X = this.margin, this.left = o.x - X, this.right = o.x + o.width + X, this.top = o.y - X, this.bottom = o.y + o.height + X; }, t.calculateBounds = function (c) { for (var h = s.MAX_VALUE, w = -s.MAX_VALUE, p = s.MAX_VALUE, y = -s.MAX_VALUE, L, I, M, S, X = c.length, G = 0; G < X; G++) {
            var Q = c[G];
            L = Q.getLeft(), I = Q.getRight(), M = Q.getTop(), S = Q.getBottom(), h > L && (h = L), w < I && (w = I), p > M && (p = M), y < S && (y = S);
        } var O = new e(h, p, w - h, y - p); return O; }, t.prototype.getInclusionTreeDepth = function () { return this == this.graphManager.getRoot() ? 1 : this.parent.getInclusionTreeDepth(); }, t.prototype.getEstimatedSize = function () { if (this.estimatedSize == s.MIN_VALUE)
            throw "assert failed"; return this.estimatedSize; }, t.prototype.calcEstimatedSize = function () { for (var c = 0, h = this.nodes, w = h.length, p = 0; p < w; p++) {
            var y = h[p];
            c += y.calcEstimatedSize();
        } return c == 0 ? this.estimatedSize = a.EMPTY_COMPOUND_NODE_SIZE : this.estimatedSize = c / Math.sqrt(this.nodes.length), this.estimatedSize; }, t.prototype.updateConnected = function () { var c = this; if (this.nodes.length == 0) {
            this.isConnected = !0;
            return;
        } var h = new r, w = new Set, p = this.nodes[0], y, L, I = p.withChildren(); for (I.forEach(function (O) { h.push(O), w.add(O); }); h.length !== 0;) {
            p = h.shift(), y = p.getEdges();
            for (var M = y.length, S = 0; S < M; S++) {
                var X = y[S];
                if (L = X.getOtherEndInGraph(p, this), L != null && !w.has(L)) {
                    var G = L.withChildren();
                    G.forEach(function (O) { h.push(O), w.add(O); });
                }
            }
        } if (this.isConnected = !1, w.size >= this.nodes.length) {
            var Q = 0;
            w.forEach(function (O) { O.owner == c && Q++; }), Q == this.nodes.length && (this.isConnected = !0);
        } }, E.exports = t;
    }), (function (E, C, N) {
        "use strict";
        var g, s = N(1);
        function a(i) { g = N(6), this.layout = i, this.graphs = [], this.edges = []; }
        a.prototype.addRoot = function () { var i = this.layout.newGraph(), n = this.layout.newNode(null), f = this.add(i, n); return this.setRootGraph(f), this.rootGraph; }, a.prototype.add = function (i, n, f, e, u) { if (f == null && e == null && u == null) {
            if (i == null)
                throw "Graph is null!";
            if (n == null)
                throw "Parent node is null!";
            if (this.graphs.indexOf(i) > -1)
                throw "Graph already in this graph mgr!";
            if (this.graphs.push(i), i.parent != null)
                throw "Already has a parent!";
            if (n.child != null)
                throw "Already has a child!";
            return i.parent = n, n.child = i, i;
        }
        else {
            u = f, e = n, f = i;
            var r = e.getOwner(), t = u.getOwner();
            if (!(r != null && r.getGraphManager() == this))
                throw "Source not in this graph mgr!";
            if (!(t != null && t.getGraphManager() == this))
                throw "Target not in this graph mgr!";
            if (r == t)
                return f.isInterGraph = !1, r.add(f, e, u);
            if (f.isInterGraph = !0, f.source = e, f.target = u, this.edges.indexOf(f) > -1)
                throw "Edge already in inter-graph edge list!";
            if (this.edges.push(f), !(f.source != null && f.target != null))
                throw "Edge source and/or target is null!";
            if (!(f.source.edges.indexOf(f) == -1 && f.target.edges.indexOf(f) == -1))
                throw "Edge already in source and/or target incidency list!";
            return f.source.edges.push(f), f.target.edges.push(f), f;
        } }, a.prototype.remove = function (i) { if (i instanceof g) {
            var n = i;
            if (n.getGraphManager() != this)
                throw "Graph not in this graph mgr";
            if (!(n == this.rootGraph || n.parent != null && n.parent.graphManager == this))
                throw "Invalid parent node!";
            var f = [];
            f = f.concat(n.getEdges());
            for (var e, u = f.length, r = 0; r < u; r++)
                e = f[r], n.remove(e);
            var t = [];
            t = t.concat(n.getNodes());
            var l;
            u = t.length;
            for (var r = 0; r < u; r++)
                l = t[r], n.remove(l);
            n == this.rootGraph && this.setRootGraph(null);
            var c = this.graphs.indexOf(n);
            this.graphs.splice(c, 1), n.parent = null;
        }
        else if (i instanceof s) {
            if (e = i, e == null)
                throw "Edge is null!";
            if (!e.isInterGraph)
                throw "Not an inter-graph edge!";
            if (!(e.source != null && e.target != null))
                throw "Source and/or target is null!";
            if (!(e.source.edges.indexOf(e) != -1 && e.target.edges.indexOf(e) != -1))
                throw "Source and/or target doesn't know this edge!";
            var c = e.source.edges.indexOf(e);
            if (e.source.edges.splice(c, 1), c = e.target.edges.indexOf(e), e.target.edges.splice(c, 1), !(e.source.owner != null && e.source.owner.getGraphManager() != null))
                throw "Edge owner graph or owner graph manager is null!";
            if (e.source.owner.getGraphManager().edges.indexOf(e) == -1)
                throw "Not in owner graph manager's edge list!";
            var c = e.source.owner.getGraphManager().edges.indexOf(e);
            e.source.owner.getGraphManager().edges.splice(c, 1);
        } }, a.prototype.updateBounds = function () { this.rootGraph.updateBounds(!0); }, a.prototype.getGraphs = function () { return this.graphs; }, a.prototype.getAllNodes = function () { if (this.allNodes == null) {
            for (var i = [], n = this.getGraphs(), f = n.length, e = 0; e < f; e++)
                i = i.concat(n[e].getNodes());
            this.allNodes = i;
        } return this.allNodes; }, a.prototype.resetAllNodes = function () { this.allNodes = null; }, a.prototype.resetAllEdges = function () { this.allEdges = null; }, a.prototype.resetAllNodesToApplyGravitation = function () { this.allNodesToApplyGravitation = null; }, a.prototype.getAllEdges = function () { if (this.allEdges == null) {
            for (var i = [], n = this.getGraphs(), f = n.length, e = 0; e < n.length; e++)
                i = i.concat(n[e].getEdges());
            i = i.concat(this.edges), this.allEdges = i;
        } return this.allEdges; }, a.prototype.getAllNodesToApplyGravitation = function () { return this.allNodesToApplyGravitation; }, a.prototype.setAllNodesToApplyGravitation = function (i) { if (this.allNodesToApplyGravitation != null)
            throw "assert failed"; this.allNodesToApplyGravitation = i; }, a.prototype.getRoot = function () { return this.rootGraph; }, a.prototype.setRootGraph = function (i) { if (i.getGraphManager() != this)
            throw "Root not in this graph mgr!"; this.rootGraph = i, i.parent == null && (i.parent = this.layout.newNode("Root node")); }, a.prototype.getLayout = function () { return this.layout; }, a.prototype.isOneAncestorOfOther = function (i, n) { if (!(i != null && n != null))
            throw "assert failed"; if (i == n)
            return !0; var f = i.getOwner(), e; do {
            if (e = f.getParent(), e == null)
                break;
            if (e == n)
                return !0;
            if (f = e.getOwner(), f == null)
                break;
        } while (!0); f = n.getOwner(); do {
            if (e = f.getParent(), e == null)
                break;
            if (e == i)
                return !0;
            if (f = e.getOwner(), f == null)
                break;
        } while (!0); return !1; }, a.prototype.calcLowestCommonAncestors = function () { for (var i, n, f, e, u, r = this.getAllEdges(), t = r.length, l = 0; l < t; l++) {
            if (i = r[l], n = i.source, f = i.target, i.lca = null, i.sourceInLca = n, i.targetInLca = f, n == f) {
                i.lca = n.getOwner();
                continue;
            }
            for (e = n.getOwner(); i.lca == null;) {
                for (i.targetInLca = f, u = f.getOwner(); i.lca == null;) {
                    if (u == e) {
                        i.lca = u;
                        break;
                    }
                    if (u == this.rootGraph)
                        break;
                    if (i.lca != null)
                        throw "assert failed";
                    i.targetInLca = u.getParent(), u = i.targetInLca.getOwner();
                }
                if (e == this.rootGraph)
                    break;
                i.lca == null && (i.sourceInLca = e.getParent(), e = i.sourceInLca.getOwner());
            }
            if (i.lca == null)
                throw "assert failed";
        } }, a.prototype.calcLowestCommonAncestor = function (i, n) { if (i == n)
            return i.getOwner(); var f = i.getOwner(); do {
            if (f == null)
                break;
            var e = n.getOwner();
            do {
                if (e == null)
                    break;
                if (e == f)
                    return e;
                e = e.getParent().getOwner();
            } while (!0);
            f = f.getParent().getOwner();
        } while (!0); return f; }, a.prototype.calcInclusionTreeDepths = function (i, n) { i == null && n == null && (i = this.rootGraph, n = 1); for (var f, e = i.getNodes(), u = e.length, r = 0; r < u; r++)
            f = e[r], f.inclusionTreeDepth = n, f.child != null && this.calcInclusionTreeDepths(f.child, n + 1); }, a.prototype.includesInvalidEdge = function () { for (var i, n = [], f = this.edges.length, e = 0; e < f; e++)
            i = this.edges[e], this.isOneAncestorOfOther(i.source, i.target) && n.push(i); for (var e = 0; e < n.length; e++)
            this.remove(n[e]); return !1; }, E.exports = a;
    }), (function (E, C, N) {
        "use strict";
        var g = N(12);
        function s() { }
        s.calcSeparationAmount = function (a, i, n, f) { if (!a.intersects(i))
            throw "assert failed"; var e = new Array(2); this.decideDirectionsForOverlappingNodes(a, i, e), n[0] = Math.min(a.getRight(), i.getRight()) - Math.max(a.x, i.x), n[1] = Math.min(a.getBottom(), i.getBottom()) - Math.max(a.y, i.y), a.getX() <= i.getX() && a.getRight() >= i.getRight() ? n[0] += Math.min(i.getX() - a.getX(), a.getRight() - i.getRight()) : i.getX() <= a.getX() && i.getRight() >= a.getRight() && (n[0] += Math.min(a.getX() - i.getX(), i.getRight() - a.getRight())), a.getY() <= i.getY() && a.getBottom() >= i.getBottom() ? n[1] += Math.min(i.getY() - a.getY(), a.getBottom() - i.getBottom()) : i.getY() <= a.getY() && i.getBottom() >= a.getBottom() && (n[1] += Math.min(a.getY() - i.getY(), i.getBottom() - a.getBottom())); var u = Math.abs((i.getCenterY() - a.getCenterY()) / (i.getCenterX() - a.getCenterX())); i.getCenterY() === a.getCenterY() && i.getCenterX() === a.getCenterX() && (u = 1); var r = u * n[0], t = n[1] / u; n[0] < t ? t = n[0] : r = n[1], n[0] = -1 * e[0] * (t / 2 + f), n[1] = -1 * e[1] * (r / 2 + f); }, s.decideDirectionsForOverlappingNodes = function (a, i, n) { a.getCenterX() < i.getCenterX() ? n[0] = -1 : n[0] = 1, a.getCenterY() < i.getCenterY() ? n[1] = -1 : n[1] = 1; }, s.getIntersection2 = function (a, i, n) { var f = a.getCenterX(), e = a.getCenterY(), u = i.getCenterX(), r = i.getCenterY(); if (a.intersects(i))
            return n[0] = f, n[1] = e, n[2] = u, n[3] = r, !0; var t = a.getX(), l = a.getY(), c = a.getRight(), h = a.getX(), w = a.getBottom(), p = a.getRight(), y = a.getWidthHalf(), L = a.getHeightHalf(), I = i.getX(), M = i.getY(), S = i.getRight(), X = i.getX(), G = i.getBottom(), Q = i.getRight(), O = i.getWidthHalf(), H = i.getHeightHalf(), o = !1, m = !1; if (f === u) {
            if (e > r)
                return n[0] = f, n[1] = l, n[2] = u, n[3] = G, !1;
            if (e < r)
                return n[0] = f, n[1] = w, n[2] = u, n[3] = M, !1;
        }
        else if (e === r) {
            if (f > u)
                return n[0] = t, n[1] = e, n[2] = S, n[3] = r, !1;
            if (f < u)
                return n[0] = c, n[1] = e, n[2] = I, n[3] = r, !1;
        }
        else {
            var v = a.height / a.width, T = i.height / i.width, d = (r - e) / (u - f), x = void 0, D = void 0, P = void 0, F = void 0, R = void 0, k = void 0;
            if (-v === d ? f > u ? (n[0] = h, n[1] = w, o = !0) : (n[0] = c, n[1] = l, o = !0) : v === d && (f > u ? (n[0] = t, n[1] = l, o = !0) : (n[0] = p, n[1] = w, o = !0)), -T === d ? u > f ? (n[2] = X, n[3] = G, m = !0) : (n[2] = S, n[3] = M, m = !0) : T === d && (u > f ? (n[2] = I, n[3] = M, m = !0) : (n[2] = Q, n[3] = G, m = !0)), o && m)
                return !1;
            if (f > u ? e > r ? (x = this.getCardinalDirection(v, d, 4), D = this.getCardinalDirection(T, d, 2)) : (x = this.getCardinalDirection(-v, d, 3), D = this.getCardinalDirection(-T, d, 1)) : e > r ? (x = this.getCardinalDirection(-v, d, 1), D = this.getCardinalDirection(-T, d, 3)) : (x = this.getCardinalDirection(v, d, 2), D = this.getCardinalDirection(T, d, 4)), !o)
                switch (x) {
                    case 1:
                        F = l, P = f + -L / d, n[0] = P, n[1] = F;
                        break;
                    case 2:
                        P = p, F = e + y * d, n[0] = P, n[1] = F;
                        break;
                    case 3:
                        F = w, P = f + L / d, n[0] = P, n[1] = F;
                        break;
                    case 4:
                        P = h, F = e + -y * d, n[0] = P, n[1] = F;
                        break;
                }
            if (!m)
                switch (D) {
                    case 1:
                        k = M, R = u + -H / d, n[2] = R, n[3] = k;
                        break;
                    case 2:
                        R = Q, k = r + O * d, n[2] = R, n[3] = k;
                        break;
                    case 3:
                        k = G, R = u + H / d, n[2] = R, n[3] = k;
                        break;
                    case 4:
                        R = X, k = r + -O * d, n[2] = R, n[3] = k;
                        break;
                }
        } return !1; }, s.getCardinalDirection = function (a, i, n) { return a > i ? n : 1 + n % 4; }, s.getIntersection = function (a, i, n, f) { if (f == null)
            return this.getIntersection2(a, i, n); var e = a.x, u = a.y, r = i.x, t = i.y, l = n.x, c = n.y, h = f.x, w = f.y, p = void 0, y = void 0, L = void 0, I = void 0, M = void 0, S = void 0, X = void 0, G = void 0, Q = void 0; return L = t - u, M = e - r, X = r * u - e * t, I = w - c, S = l - h, G = h * c - l * w, Q = L * S - I * M, Q === 0 ? null : (p = (M * G - S * X) / Q, y = (I * X - L * G) / Q, new g(p, y)); }, s.angleOfVector = function (a, i, n, f) { var e = void 0; return a !== n ? (e = Math.atan((f - i) / (n - a)), n < a ? e += Math.PI : f < i && (e += this.TWO_PI)) : f < i ? e = this.ONE_AND_HALF_PI : e = this.HALF_PI, e; }, s.doIntersect = function (a, i, n, f) { var e = a.x, u = a.y, r = i.x, t = i.y, l = n.x, c = n.y, h = f.x, w = f.y, p = (r - e) * (w - c) - (h - l) * (t - u); if (p === 0)
            return !1; var y = ((w - c) * (h - e) + (l - h) * (w - u)) / p, L = ((u - t) * (h - e) + (r - e) * (w - u)) / p; return 0 < y && y < 1 && 0 < L && L < 1; }, s.findCircleLineIntersections = function (a, i, n, f, e, u, r) { var t = (n - a) * (n - a) + (f - i) * (f - i), l = 2 * ((a - e) * (n - a) + (i - u) * (f - i)), c = (a - e) * (a - e) + (i - u) * (i - u) - r * r, h = l * l - 4 * t * c; if (h >= 0) {
            var w = (-l + Math.sqrt(l * l - 4 * t * c)) / (2 * t), p = (-l - Math.sqrt(l * l - 4 * t * c)) / (2 * t), y = null;
            return w >= 0 && w <= 1 ? [w] : p >= 0 && p <= 1 ? [p] : y;
        }
        else
            return null; }, s.HALF_PI = .5 * Math.PI, s.ONE_AND_HALF_PI = 1.5 * Math.PI, s.TWO_PI = 2 * Math.PI, s.THREE_PI = 3 * Math.PI, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        function g() { }
        g.sign = function (s) { return s > 0 ? 1 : s < 0 ? -1 : 0; }, g.floor = function (s) { return s < 0 ? Math.ceil(s) : Math.floor(s); }, g.ceil = function (s) { return s < 0 ? Math.floor(s) : Math.ceil(s); }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        function g() { }
        g.MAX_VALUE = 2147483647, g.MIN_VALUE = -2147483648, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = (function () { function e(u, r) { for (var t = 0; t < r.length; t++) {
            var l = r[t];
            l.enumerable = l.enumerable || !1, l.configurable = !0, "value" in l && (l.writable = !0), Object.defineProperty(u, l.key, l);
        } } return function (u, r, t) { return r && e(u.prototype, r), t && e(u, t), u; }; })();
        function s(e, u) { if (!(e instanceof u))
            throw new TypeError("Cannot call a class as a function"); }
        var a = function (u) { return { value: u, next: null, prev: null }; }, i = function (u, r, t, l) { return u !== null ? u.next = r : l.head = r, t !== null ? t.prev = r : l.tail = r, r.prev = u, r.next = t, l.length++, r; }, n = function (u, r) { var t = u.prev, l = u.next; return t !== null ? t.next = l : r.head = l, l !== null ? l.prev = t : r.tail = t, u.prev = u.next = null, r.length--, u; }, f = (function () { function e(u) { var r = this; s(this, e), this.length = 0, this.head = null, this.tail = null, u?.forEach(function (t) { return r.push(t); }); } return g(e, [{ key: "size", value: function () { return this.length; } }, { key: "insertBefore", value: function (r, t) { return i(t.prev, a(r), t, this); } }, { key: "insertAfter", value: function (r, t) { return i(t, a(r), t.next, this); } }, { key: "insertNodeBefore", value: function (r, t) { return i(t.prev, r, t, this); } }, { key: "insertNodeAfter", value: function (r, t) { return i(t, r, t.next, this); } }, { key: "push", value: function (r) { return i(this.tail, a(r), null, this); } }, { key: "unshift", value: function (r) { return i(null, a(r), this.head, this); } }, { key: "remove", value: function (r) { return n(r, this); } }, { key: "pop", value: function () { return n(this.tail, this).value; } }, { key: "popNode", value: function () { return n(this.tail, this); } }, { key: "shift", value: function () { return n(this.head, this).value; } }, { key: "shiftNode", value: function () { return n(this.head, this); } }, { key: "get_object_at", value: function (r) { if (r <= this.length()) {
                    for (var t = 1, l = this.head; t < r;)
                        l = l.next, t++;
                    return l.value;
                } } }, { key: "set_object_at", value: function (r, t) { if (r <= this.length()) {
                    for (var l = 1, c = this.head; l < r;)
                        c = c.next, l++;
                    c.value = t;
                } } }]), e; })();
        E.exports = f;
    }), (function (E, C, N) {
        "use strict";
        function g(s, a, i) { this.x = null, this.y = null, s == null && a == null && i == null ? (this.x = 0, this.y = 0) : typeof s == "number" && typeof a == "number" && i == null ? (this.x = s, this.y = a) : s.constructor.name == "Point" && a == null && i == null && (i = s, this.x = i.x, this.y = i.y); }
        g.prototype.getX = function () { return this.x; }, g.prototype.getY = function () { return this.y; }, g.prototype.getLocation = function () { return new g(this.x, this.y); }, g.prototype.setLocation = function (s, a, i) { s.constructor.name == "Point" && a == null && i == null ? (i = s, this.setLocation(i.x, i.y)) : typeof s == "number" && typeof a == "number" && i == null && (parseInt(s) == s && parseInt(a) == a ? this.move(s, a) : (this.x = Math.floor(s + .5), this.y = Math.floor(a + .5))); }, g.prototype.move = function (s, a) { this.x = s, this.y = a; }, g.prototype.translate = function (s, a) { this.x += s, this.y += a; }, g.prototype.equals = function (s) { if (s.constructor.name == "Point") {
            var a = s;
            return this.x == a.x && this.y == a.y;
        } return this == s; }, g.prototype.toString = function () { return new g().constructor.name + "[x=" + this.x + ",y=" + this.y + "]"; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        function g(s, a, i, n) { this.x = 0, this.y = 0, this.width = 0, this.height = 0, s != null && a != null && i != null && n != null && (this.x = s, this.y = a, this.width = i, this.height = n); }
        g.prototype.getX = function () { return this.x; }, g.prototype.setX = function (s) { this.x = s; }, g.prototype.getY = function () { return this.y; }, g.prototype.setY = function (s) { this.y = s; }, g.prototype.getWidth = function () { return this.width; }, g.prototype.setWidth = function (s) { this.width = s; }, g.prototype.getHeight = function () { return this.height; }, g.prototype.setHeight = function (s) { this.height = s; }, g.prototype.getRight = function () { return this.x + this.width; }, g.prototype.getBottom = function () { return this.y + this.height; }, g.prototype.intersects = function (s) { return !(this.getRight() < s.x || this.getBottom() < s.y || s.getRight() < this.x || s.getBottom() < this.y); }, g.prototype.getCenterX = function () { return this.x + this.width / 2; }, g.prototype.getMinX = function () { return this.getX(); }, g.prototype.getMaxX = function () { return this.getX() + this.width; }, g.prototype.getCenterY = function () { return this.y + this.height / 2; }, g.prototype.getMinY = function () { return this.getY(); }, g.prototype.getMaxY = function () { return this.getY() + this.height; }, g.prototype.getWidthHalf = function () { return this.width / 2; }, g.prototype.getHeightHalf = function () { return this.height / 2; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = typeof Symbol == "function" && typeof Symbol.iterator == "symbol" ? function (a) { return typeof a; } : function (a) { return a && typeof Symbol == "function" && a.constructor === Symbol && a !== Symbol.prototype ? "symbol" : typeof a; };
        function s() { }
        s.lastID = 0, s.createID = function (a) { return s.isPrimitive(a) ? a : (a.uniqueID != null || (a.uniqueID = s.getString(), s.lastID++), a.uniqueID); }, s.getString = function (a) { return a == null && (a = s.lastID), "Object#" + a; }, s.isPrimitive = function (a) { var i = typeof a > "u" ? "undefined" : g(a); return a == null || i != "object" && i != "function"; }, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        function g(l) { if (Array.isArray(l)) {
            for (var c = 0, h = Array(l.length); c < l.length; c++)
                h[c] = l[c];
            return h;
        }
        else
            return Array.from(l); }
        var s = N(0), a = N(7), i = N(3), n = N(1), f = N(6), e = N(5), u = N(17), r = N(29);
        function t(l) { r.call(this), this.layoutQuality = s.QUALITY, this.createBendsAsNeeded = s.DEFAULT_CREATE_BENDS_AS_NEEDED, this.incremental = s.DEFAULT_INCREMENTAL, this.animationOnLayout = s.DEFAULT_ANIMATION_ON_LAYOUT, this.animationDuringLayout = s.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = s.DEFAULT_ANIMATION_PERIOD, this.uniformLeafNodeSizes = s.DEFAULT_UNIFORM_LEAF_NODE_SIZES, this.edgeToDummyNodes = new Map, this.graphManager = new a(this), this.isLayoutFinished = !1, this.isSubLayout = !1, this.isRemoteUse = !1, l != null && (this.isRemoteUse = l); }
        t.RANDOM_SEED = 1, t.prototype = Object.create(r.prototype), t.prototype.getGraphManager = function () { return this.graphManager; }, t.prototype.getAllNodes = function () { return this.graphManager.getAllNodes(); }, t.prototype.getAllEdges = function () { return this.graphManager.getAllEdges(); }, t.prototype.getAllNodesToApplyGravitation = function () { return this.graphManager.getAllNodesToApplyGravitation(); }, t.prototype.newGraphManager = function () { var l = new a(this); return this.graphManager = l, l; }, t.prototype.newGraph = function (l) { return new f(null, this.graphManager, l); }, t.prototype.newNode = function (l) { return new i(this.graphManager, l); }, t.prototype.newEdge = function (l) { return new n(null, null, l); }, t.prototype.checkLayoutSuccess = function () { return this.graphManager.getRoot() == null || this.graphManager.getRoot().getNodes().length == 0 || this.graphManager.includesInvalidEdge(); }, t.prototype.runLayout = function () { this.isLayoutFinished = !1, this.tilingPreLayout && this.tilingPreLayout(), this.initParameters(); var l; return this.checkLayoutSuccess() ? l = !1 : l = this.layout(), s.ANIMATE === "during" ? !1 : (l && (this.isSubLayout || this.doPostLayout()), this.tilingPostLayout && this.tilingPostLayout(), this.isLayoutFinished = !0, l); }, t.prototype.doPostLayout = function () { this.incremental || this.transform(), this.update(); }, t.prototype.update2 = function () { if (this.createBendsAsNeeded && (this.createBendpointsFromDummyNodes(), this.graphManager.resetAllEdges()), !this.isRemoteUse) {
            for (var l, c = this.graphManager.getAllEdges(), h = 0; h < c.length; h++)
                l = c[h];
            for (var w, p = this.graphManager.getRoot().getNodes(), h = 0; h < p.length; h++)
                w = p[h];
            this.update(this.graphManager.getRoot());
        } }, t.prototype.update = function (l) { if (l == null)
            this.update2();
        else if (l instanceof i) {
            var c = l;
            if (c.getChild() != null)
                for (var h = c.getChild().getNodes(), w = 0; w < h.length; w++)
                    update(h[w]);
            if (c.vGraphObject != null) {
                var p = c.vGraphObject;
                p.update(c);
            }
        }
        else if (l instanceof n) {
            var y = l;
            if (y.vGraphObject != null) {
                var L = y.vGraphObject;
                L.update(y);
            }
        }
        else if (l instanceof f) {
            var I = l;
            if (I.vGraphObject != null) {
                var M = I.vGraphObject;
                M.update(I);
            }
        } }, t.prototype.initParameters = function () { this.isSubLayout || (this.layoutQuality = s.QUALITY, this.animationDuringLayout = s.DEFAULT_ANIMATION_DURING_LAYOUT, this.animationPeriod = s.DEFAULT_ANIMATION_PERIOD, this.animationOnLayout = s.DEFAULT_ANIMATION_ON_LAYOUT, this.incremental = s.DEFAULT_INCREMENTAL, this.createBendsAsNeeded = s.DEFAULT_CREATE_BENDS_AS_NEEDED, this.uniformLeafNodeSizes = s.DEFAULT_UNIFORM_LEAF_NODE_SIZES), this.animationDuringLayout && (this.animationOnLayout = !1); }, t.prototype.transform = function (l) { if (l == null)
            this.transform(new e(0, 0));
        else {
            var c = new u, h = this.graphManager.getRoot().updateLeftTop();
            if (h != null) {
                c.setWorldOrgX(l.x), c.setWorldOrgY(l.y), c.setDeviceOrgX(h.x), c.setDeviceOrgY(h.y);
                for (var w = this.getAllNodes(), p, y = 0; y < w.length; y++)
                    p = w[y], p.transform(c);
            }
        } }, t.prototype.positionNodesRandomly = function (l) { if (l == null)
            this.positionNodesRandomly(this.getGraphManager().getRoot()), this.getGraphManager().getRoot().updateBounds(!0);
        else
            for (var c, h, w = l.getNodes(), p = 0; p < w.length; p++)
                c = w[p], h = c.getChild(), h == null || h.getNodes().length == 0 ? c.scatter() : (this.positionNodesRandomly(h), c.updateBounds()); }, t.prototype.getFlatForest = function () { for (var l = [], c = !0, h = this.graphManager.getRoot().getNodes(), w = !0, p = 0; p < h.length; p++)
            h[p].getChild() != null && (w = !1); if (!w)
            return l; var y = new Set, L = [], I = new Map, M = []; for (M = M.concat(h); M.length > 0 && c;) {
            for (L.push(M[0]); L.length > 0 && c;) {
                var S = L[0];
                L.splice(0, 1), y.add(S);
                for (var X = S.getEdges(), p = 0; p < X.length; p++) {
                    var G = X[p].getOtherEnd(S);
                    if (I.get(S) != G)
                        if (!y.has(G))
                            L.push(G), I.set(G, S);
                        else {
                            c = !1;
                            break;
                        }
                }
            }
            if (!c)
                l = [];
            else {
                var Q = [].concat(g(y));
                l.push(Q);
                for (var p = 0; p < Q.length; p++) {
                    var O = Q[p], H = M.indexOf(O);
                    H > -1 && M.splice(H, 1);
                }
                y = new Set, I = new Map;
            }
        } return l; }, t.prototype.createDummyNodesForBendpoints = function (l) { for (var c = [], h = l.source, w = this.graphManager.calcLowestCommonAncestor(l.source, l.target), p = 0; p < l.bendpoints.length; p++) {
            var y = this.newNode(null);
            y.setRect(new Point(0, 0), new Dimension(1, 1)), w.add(y);
            var L = this.newEdge(null);
            this.graphManager.add(L, h, y), c.add(y), h = y;
        } var L = this.newEdge(null); return this.graphManager.add(L, h, l.target), this.edgeToDummyNodes.set(l, c), l.isInterGraph() ? this.graphManager.remove(l) : w.remove(l), c; }, t.prototype.createBendpointsFromDummyNodes = function () { var l = []; l = l.concat(this.graphManager.getAllEdges()), l = [].concat(g(this.edgeToDummyNodes.keys())).concat(l); for (var c = 0; c < l.length; c++) {
            var h = l[c];
            if (h.bendpoints.length > 0) {
                for (var w = this.edgeToDummyNodes.get(h), p = 0; p < w.length; p++) {
                    var y = w[p], L = new e(y.getCenterX(), y.getCenterY()), I = h.bendpoints.get(p);
                    I.x = L.x, I.y = L.y, y.getOwner().remove(y);
                }
                this.graphManager.add(h, h.source, h.target);
            }
        } }, t.transform = function (l, c, h, w) { if (h != null && w != null) {
            var p = c;
            if (l <= 50) {
                var y = c / h;
                p -= (c - y) / 50 * (50 - l);
            }
            else {
                var L = c * w;
                p += (L - c) / 50 * (l - 50);
            }
            return p;
        }
        else {
            var I, M;
            return l <= 50 ? (I = 9 * c / 500, M = c / 10) : (I = 9 * c / 50, M = -8 * c), I * l + M;
        } }, t.findCenterOfTree = function (l) { var c = []; c = c.concat(l); var h = [], w = new Map, p = !1, y = null; (c.length == 1 || c.length == 2) && (p = !0, y = c[0]); for (var L = 0; L < c.length; L++) {
            var I = c[L], M = I.getNeighborsList().size;
            w.set(I, I.getNeighborsList().size), M == 1 && h.push(I);
        } var S = []; for (S = S.concat(h); !p;) {
            var X = [];
            X = X.concat(S), S = [];
            for (var L = 0; L < c.length; L++) {
                var I = c[L], G = c.indexOf(I);
                G >= 0 && c.splice(G, 1);
                var Q = I.getNeighborsList();
                Q.forEach(function (o) { if (h.indexOf(o) < 0) {
                    var m = w.get(o), v = m - 1;
                    v == 1 && S.push(o), w.set(o, v);
                } });
            }
            h = h.concat(S), (c.length == 1 || c.length == 2) && (p = !0, y = c[0]);
        } return y; }, t.prototype.setGraphManager = function (l) { this.graphManager = l; }, E.exports = t;
    }), (function (E, C, N) {
        "use strict";
        function g() { }
        g.seed = 1, g.x = 0, g.nextDouble = function () { return g.x = Math.sin(g.seed++) * 1e4, g.x - Math.floor(g.x); }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = N(5);
        function s(a, i) { this.lworldOrgX = 0, this.lworldOrgY = 0, this.ldeviceOrgX = 0, this.ldeviceOrgY = 0, this.lworldExtX = 1, this.lworldExtY = 1, this.ldeviceExtX = 1, this.ldeviceExtY = 1; }
        s.prototype.getWorldOrgX = function () { return this.lworldOrgX; }, s.prototype.setWorldOrgX = function (a) { this.lworldOrgX = a; }, s.prototype.getWorldOrgY = function () { return this.lworldOrgY; }, s.prototype.setWorldOrgY = function (a) { this.lworldOrgY = a; }, s.prototype.getWorldExtX = function () { return this.lworldExtX; }, s.prototype.setWorldExtX = function (a) { this.lworldExtX = a; }, s.prototype.getWorldExtY = function () { return this.lworldExtY; }, s.prototype.setWorldExtY = function (a) { this.lworldExtY = a; }, s.prototype.getDeviceOrgX = function () { return this.ldeviceOrgX; }, s.prototype.setDeviceOrgX = function (a) { this.ldeviceOrgX = a; }, s.prototype.getDeviceOrgY = function () { return this.ldeviceOrgY; }, s.prototype.setDeviceOrgY = function (a) { this.ldeviceOrgY = a; }, s.prototype.getDeviceExtX = function () { return this.ldeviceExtX; }, s.prototype.setDeviceExtX = function (a) { this.ldeviceExtX = a; }, s.prototype.getDeviceExtY = function () { return this.ldeviceExtY; }, s.prototype.setDeviceExtY = function (a) { this.ldeviceExtY = a; }, s.prototype.transformX = function (a) { var i = 0, n = this.lworldExtX; return n != 0 && (i = this.ldeviceOrgX + (a - this.lworldOrgX) * this.ldeviceExtX / n), i; }, s.prototype.transformY = function (a) { var i = 0, n = this.lworldExtY; return n != 0 && (i = this.ldeviceOrgY + (a - this.lworldOrgY) * this.ldeviceExtY / n), i; }, s.prototype.inverseTransformX = function (a) { var i = 0, n = this.ldeviceExtX; return n != 0 && (i = this.lworldOrgX + (a - this.ldeviceOrgX) * this.lworldExtX / n), i; }, s.prototype.inverseTransformY = function (a) { var i = 0, n = this.ldeviceExtY; return n != 0 && (i = this.lworldOrgY + (a - this.ldeviceOrgY) * this.lworldExtY / n), i; }, s.prototype.inverseTransformPoint = function (a) { var i = new g(this.inverseTransformX(a.x), this.inverseTransformY(a.y)); return i; }, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        function g(r) { if (Array.isArray(r)) {
            for (var t = 0, l = Array(r.length); t < r.length; t++)
                l[t] = r[t];
            return l;
        }
        else
            return Array.from(r); }
        var s = N(15), a = N(4), i = N(0), n = N(8), f = N(9);
        function e() { s.call(this), this.useSmartIdealEdgeLengthCalculation = a.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = a.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = a.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = a.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = a.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.coolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.initialCoolingFactor = a.DEFAULT_COOLING_FACTOR_INCREMENTAL, this.totalDisplacement = 0, this.oldTotalDisplacement = 0, this.maxIterations = a.MAX_ITERATIONS; }
        e.prototype = Object.create(s.prototype);
        for (var u in s)
            e[u] = s[u];
        e.prototype.initParameters = function () { s.prototype.initParameters.call(this, arguments), this.totalIterations = 0, this.notAnimatedIterations = 0, this.useFRGridVariant = a.DEFAULT_USE_SMART_REPULSION_RANGE_CALCULATION, this.grid = []; }, e.prototype.calcIdealEdgeLengths = function () { for (var r, t, l, c, h, w, p, y = this.getGraphManager().getAllEdges(), L = 0; L < y.length; L++)
            r = y[L], t = r.idealLength, r.isInterGraph && (c = r.getSource(), h = r.getTarget(), w = r.getSourceInLca().getEstimatedSize(), p = r.getTargetInLca().getEstimatedSize(), this.useSmartIdealEdgeLengthCalculation && (r.idealLength += w + p - 2 * i.SIMPLE_NODE_SIZE), l = r.getLca().getInclusionTreeDepth(), r.idealLength += t * a.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR * (c.getInclusionTreeDepth() + h.getInclusionTreeDepth() - 2 * l)); }, e.prototype.initSpringEmbedder = function () { var r = this.getAllNodes().length; this.incremental ? (r > a.ADAPTATION_LOWER_NODE_LIMIT && (this.coolingFactor = Math.max(this.coolingFactor * a.COOLING_ADAPTATION_FACTOR, this.coolingFactor - (r - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * this.coolingFactor * (1 - a.COOLING_ADAPTATION_FACTOR))), this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT_INCREMENTAL) : (r > a.ADAPTATION_LOWER_NODE_LIMIT ? this.coolingFactor = Math.max(a.COOLING_ADAPTATION_FACTOR, 1 - (r - a.ADAPTATION_LOWER_NODE_LIMIT) / (a.ADAPTATION_UPPER_NODE_LIMIT - a.ADAPTATION_LOWER_NODE_LIMIT) * (1 - a.COOLING_ADAPTATION_FACTOR)) : this.coolingFactor = 1, this.initialCoolingFactor = this.coolingFactor, this.maxNodeDisplacement = a.MAX_NODE_DISPLACEMENT), this.maxIterations = Math.max(this.getAllNodes().length * 5, this.maxIterations), this.displacementThresholdPerNode = 3 * a.DEFAULT_EDGE_LENGTH / 100, this.totalDisplacementThreshold = this.displacementThresholdPerNode * this.getAllNodes().length, this.repulsionRange = this.calcRepulsionRange(); }, e.prototype.calcSpringForces = function () { for (var r = this.getAllEdges(), t, l = 0; l < r.length; l++)
            t = r[l], this.calcSpringForce(t, t.idealLength); }, e.prototype.calcRepulsionForces = function () { var r = arguments.length > 0 && arguments[0] !== void 0 ? arguments[0] : !0, t = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : !1, l, c, h, w, p = this.getAllNodes(), y; if (this.useFRGridVariant)
            for (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && r && this.updateGrid(), y = new Set, l = 0; l < p.length; l++)
                h = p[l], this.calculateRepulsionForceOfANode(h, y, r, t), y.add(h);
        else
            for (l = 0; l < p.length; l++)
                for (h = p[l], c = l + 1; c < p.length; c++)
                    w = p[c], h.getOwner() == w.getOwner() && this.calcRepulsionForce(h, w); }, e.prototype.calcGravitationalForces = function () { for (var r, t = this.getAllNodesToApplyGravitation(), l = 0; l < t.length; l++)
            r = t[l], this.calcGravitationalForce(r); }, e.prototype.moveNodes = function () { for (var r = this.getAllNodes(), t, l = 0; l < r.length; l++)
            t = r[l], t.move(); }, e.prototype.calcSpringForce = function (r, t) { var l = r.getSource(), c = r.getTarget(), h, w, p, y; if (this.uniformLeafNodeSizes && l.getChild() == null && c.getChild() == null)
            r.updateLengthSimple();
        else if (r.updateLength(), r.isOverlapingSourceAndTarget)
            return; h = r.getLength(), h != 0 && (w = r.edgeElasticity * (h - t), p = w * (r.lengthX / h), y = w * (r.lengthY / h), l.springForceX += p, l.springForceY += y, c.springForceX -= p, c.springForceY -= y); }, e.prototype.calcRepulsionForce = function (r, t) { var l = r.getRect(), c = t.getRect(), h = new Array(2), w = new Array(4), p, y, L, I, M, S, X; if (l.intersects(c)) {
            n.calcSeparationAmount(l, c, h, a.DEFAULT_EDGE_LENGTH / 2), S = 2 * h[0], X = 2 * h[1];
            var G = r.noOfChildren * t.noOfChildren / (r.noOfChildren + t.noOfChildren);
            r.repulsionForceX -= G * S, r.repulsionForceY -= G * X, t.repulsionForceX += G * S, t.repulsionForceY += G * X;
        }
        else
            this.uniformLeafNodeSizes && r.getChild() == null && t.getChild() == null ? (p = c.getCenterX() - l.getCenterX(), y = c.getCenterY() - l.getCenterY()) : (n.getIntersection(l, c, w), p = w[2] - w[0], y = w[3] - w[1]), Math.abs(p) < a.MIN_REPULSION_DIST && (p = f.sign(p) * a.MIN_REPULSION_DIST), Math.abs(y) < a.MIN_REPULSION_DIST && (y = f.sign(y) * a.MIN_REPULSION_DIST), L = p * p + y * y, I = Math.sqrt(L), M = (r.nodeRepulsion / 2 + t.nodeRepulsion / 2) * r.noOfChildren * t.noOfChildren / L, S = M * p / I, X = M * y / I, r.repulsionForceX -= S, r.repulsionForceY -= X, t.repulsionForceX += S, t.repulsionForceY += X; }, e.prototype.calcGravitationalForce = function (r) { var t, l, c, h, w, p, y, L; t = r.getOwner(), l = (t.getRight() + t.getLeft()) / 2, c = (t.getTop() + t.getBottom()) / 2, h = r.getCenterX() - l, w = r.getCenterY() - c, p = Math.abs(h) + r.getWidth() / 2, y = Math.abs(w) + r.getHeight() / 2, r.getOwner() == this.graphManager.getRoot() ? (L = t.getEstimatedSize() * this.gravityRangeFactor, (p > L || y > L) && (r.gravitationForceX = -this.gravityConstant * h, r.gravitationForceY = -this.gravityConstant * w)) : (L = t.getEstimatedSize() * this.compoundGravityRangeFactor, (p > L || y > L) && (r.gravitationForceX = -this.gravityConstant * h * this.compoundGravityConstant, r.gravitationForceY = -this.gravityConstant * w * this.compoundGravityConstant)); }, e.prototype.isConverged = function () { var r, t = !1; return this.totalIterations > this.maxIterations / 3 && (t = Math.abs(this.totalDisplacement - this.oldTotalDisplacement) < 2), r = this.totalDisplacement < this.totalDisplacementThreshold, this.oldTotalDisplacement = this.totalDisplacement, r || t; }, e.prototype.animate = function () { this.animationDuringLayout && !this.isSubLayout && (this.notAnimatedIterations == this.animationPeriod ? (this.update(), this.notAnimatedIterations = 0) : this.notAnimatedIterations++); }, e.prototype.calcNoOfChildrenForAllNodes = function () { for (var r, t = this.graphManager.getAllNodes(), l = 0; l < t.length; l++)
            r = t[l], r.noOfChildren = r.getNoOfChildren(); }, e.prototype.calcGrid = function (r) { var t = 0, l = 0; t = parseInt(Math.ceil((r.getRight() - r.getLeft()) / this.repulsionRange)), l = parseInt(Math.ceil((r.getBottom() - r.getTop()) / this.repulsionRange)); for (var c = new Array(t), h = 0; h < t; h++)
            c[h] = new Array(l); for (var h = 0; h < t; h++)
            for (var w = 0; w < l; w++)
                c[h][w] = new Array; return c; }, e.prototype.addNodeToGrid = function (r, t, l) { var c = 0, h = 0, w = 0, p = 0; c = parseInt(Math.floor((r.getRect().x - t) / this.repulsionRange)), h = parseInt(Math.floor((r.getRect().width + r.getRect().x - t) / this.repulsionRange)), w = parseInt(Math.floor((r.getRect().y - l) / this.repulsionRange)), p = parseInt(Math.floor((r.getRect().height + r.getRect().y - l) / this.repulsionRange)); for (var y = c; y <= h; y++)
            for (var L = w; L <= p; L++)
                this.grid[y][L].push(r), r.setGridCoordinates(c, h, w, p); }, e.prototype.updateGrid = function () { var r, t, l = this.getAllNodes(); for (this.grid = this.calcGrid(this.graphManager.getRoot()), r = 0; r < l.length; r++)
            t = l[r], this.addNodeToGrid(t, this.graphManager.getRoot().getLeft(), this.graphManager.getRoot().getTop()); }, e.prototype.calculateRepulsionForceOfANode = function (r, t, l, c) { if (this.totalIterations % a.GRID_CALCULATION_CHECK_PERIOD == 1 && l || c) {
            var h = new Set;
            r.surrounding = new Array;
            for (var w, p = this.grid, y = r.startX - 1; y < r.finishX + 2; y++)
                for (var L = r.startY - 1; L < r.finishY + 2; L++)
                    if (!(y < 0 || L < 0 || y >= p.length || L >= p[0].length)) {
                        for (var I = 0; I < p[y][L].length; I++)
                            if (w = p[y][L][I], !(r.getOwner() != w.getOwner() || r == w) && !t.has(w) && !h.has(w)) {
                                var M = Math.abs(r.getCenterX() - w.getCenterX()) - (r.getWidth() / 2 + w.getWidth() / 2), S = Math.abs(r.getCenterY() - w.getCenterY()) - (r.getHeight() / 2 + w.getHeight() / 2);
                                M <= this.repulsionRange && S <= this.repulsionRange && h.add(w);
                            }
                    }
            r.surrounding = [].concat(g(h));
        } for (y = 0; y < r.surrounding.length; y++)
            this.calcRepulsionForce(r, r.surrounding[y]); }, e.prototype.calcRepulsionRange = function () { return 0; }, E.exports = e;
    }), (function (E, C, N) {
        "use strict";
        var g = N(1), s = N(4);
        function a(n, f, e) { g.call(this, n, f, e), this.idealLength = s.DEFAULT_EDGE_LENGTH, this.edgeElasticity = s.DEFAULT_SPRING_STRENGTH; }
        a.prototype = Object.create(g.prototype);
        for (var i in g)
            a[i] = g[i];
        E.exports = a;
    }), (function (E, C, N) {
        "use strict";
        var g = N(3), s = N(4);
        function a(n, f, e, u) { g.call(this, n, f, e, u), this.nodeRepulsion = s.DEFAULT_REPULSION_STRENGTH, this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0, this.startX = 0, this.finishX = 0, this.startY = 0, this.finishY = 0, this.surrounding = []; }
        a.prototype = Object.create(g.prototype);
        for (var i in g)
            a[i] = g[i];
        a.prototype.setGridCoordinates = function (n, f, e, u) { this.startX = n, this.finishX = f, this.startY = e, this.finishY = u; }, E.exports = a;
    }), (function (E, C, N) {
        "use strict";
        function g(s, a) { this.width = 0, this.height = 0, s !== null && a !== null && (this.height = a, this.width = s); }
        g.prototype.getWidth = function () { return this.width; }, g.prototype.setWidth = function (s) { this.width = s; }, g.prototype.getHeight = function () { return this.height; }, g.prototype.setHeight = function (s) { this.height = s; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = N(14);
        function s() { this.map = {}, this.keys = []; }
        s.prototype.put = function (a, i) { var n = g.createID(a); this.contains(n) || (this.map[n] = i, this.keys.push(a)); }, s.prototype.contains = function (a) { var i = g.createID(a); return this.map[a] != null; }, s.prototype.get = function (a) { var i = g.createID(a); return this.map[i]; }, s.prototype.keySet = function () { return this.keys; }, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        var g = N(14);
        function s() { this.set = {}; }
        s.prototype.add = function (a) { var i = g.createID(a); this.contains(i) || (this.set[i] = a); }, s.prototype.remove = function (a) { delete this.set[g.createID(a)]; }, s.prototype.clear = function () { this.set = {}; }, s.prototype.contains = function (a) { return this.set[g.createID(a)] == a; }, s.prototype.isEmpty = function () { return this.size() === 0; }, s.prototype.size = function () { return Object.keys(this.set).length; }, s.prototype.addAllTo = function (a) { for (var i = Object.keys(this.set), n = i.length, f = 0; f < n; f++)
            a.push(this.set[i[f]]); }, s.prototype.size = function () { return Object.keys(this.set).length; }, s.prototype.addAll = function (a) { for (var i = a.length, n = 0; n < i; n++) {
            var f = a[n];
            this.add(f);
        } }, E.exports = s;
    }), (function (E, C, N) {
        "use strict";
        function g() { }
        g.multMat = function (s, a) { for (var i = [], n = 0; n < s.length; n++) {
            i[n] = [];
            for (var f = 0; f < a[0].length; f++) {
                i[n][f] = 0;
                for (var e = 0; e < s[0].length; e++)
                    i[n][f] += s[n][e] * a[e][f];
            }
        } return i; }, g.transpose = function (s) { for (var a = [], i = 0; i < s[0].length; i++) {
            a[i] = [];
            for (var n = 0; n < s.length; n++)
                a[i][n] = s[n][i];
        } return a; }, g.multCons = function (s, a) { for (var i = [], n = 0; n < s.length; n++)
            i[n] = s[n] * a; return i; }, g.minusOp = function (s, a) { for (var i = [], n = 0; n < s.length; n++)
            i[n] = s[n] - a[n]; return i; }, g.dotProduct = function (s, a) { for (var i = 0, n = 0; n < s.length; n++)
            i += s[n] * a[n]; return i; }, g.mag = function (s) { return Math.sqrt(this.dotProduct(s, s)); }, g.normalize = function (s) { for (var a = [], i = this.mag(s), n = 0; n < s.length; n++)
            a[n] = s[n] / i; return a; }, g.multGamma = function (s) { for (var a = [], i = 0, n = 0; n < s.length; n++)
            i += s[n]; i *= -1 / s.length; for (var f = 0; f < s.length; f++)
            a[f] = i + s[f]; return a; }, g.multL = function (s, a, i) { for (var n = [], f = [], e = [], u = 0; u < a[0].length; u++) {
            for (var r = 0, t = 0; t < a.length; t++)
                r += -.5 * a[t][u] * s[t];
            f[u] = r;
        } for (var l = 0; l < i.length; l++) {
            for (var c = 0, h = 0; h < i.length; h++)
                c += i[l][h] * f[h];
            e[l] = c;
        } for (var w = 0; w < a.length; w++) {
            for (var p = 0, y = 0; y < a[0].length; y++)
                p += a[w][y] * e[y];
            n[w] = p;
        } return n; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = (function () { function n(f, e) { for (var u = 0; u < e.length; u++) {
            var r = e[u];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(f, r.key, r);
        } } return function (f, e, u) { return e && n(f.prototype, e), u && n(f, u), f; }; })();
        function s(n, f) { if (!(n instanceof f))
            throw new TypeError("Cannot call a class as a function"); }
        var a = N(11), i = (function () { function n(f, e) { s(this, n), (e !== null || e !== void 0) && (this.compareFunction = this._defaultCompareFunction); var u = void 0; f instanceof a ? u = f.size() : u = f.length, this._quicksort(f, 0, u - 1); } return g(n, [{ key: "_quicksort", value: function (e, u, r) { if (u < r) {
                    var t = this._partition(e, u, r);
                    this._quicksort(e, u, t), this._quicksort(e, t + 1, r);
                } } }, { key: "_partition", value: function (e, u, r) { for (var t = this._get(e, u), l = u, c = r;;) {
                    for (; this.compareFunction(t, this._get(e, c));)
                        c--;
                    for (; this.compareFunction(this._get(e, l), t);)
                        l++;
                    if (l < c)
                        this._swap(e, l, c), l++, c--;
                    else
                        return c;
                } } }, { key: "_get", value: function (e, u) { return e instanceof a ? e.get_object_at(u) : e[u]; } }, { key: "_set", value: function (e, u, r) { e instanceof a ? e.set_object_at(u, r) : e[u] = r; } }, { key: "_swap", value: function (e, u, r) { var t = this._get(e, u); this._set(e, u, this._get(e, r)), this._set(e, r, t); } }, { key: "_defaultCompareFunction", value: function (e, u) { return u > e; } }]), n; })();
        E.exports = i;
    }), (function (E, C, N) {
        "use strict";
        function g() { }
        g.svd = function (s) { this.U = null, this.V = null, this.s = null, this.m = 0, this.n = 0, this.m = s.length, this.n = s[0].length; var a = Math.min(this.m, this.n); this.s = (function (Ot) { for (var Nt = []; Ot-- > 0;)
            Nt.push(0); return Nt; })(Math.min(this.m + 1, this.n)), this.U = (function (Ot) { var Nt = function Bt(Rt) { if (Rt.length == 0)
            return 0; for (var Xt = [], zt = 0; zt < Rt[0]; zt++)
            Xt.push(Bt(Rt.slice(1))); return Xt; }; return Nt(Ot); })([this.m, a]), this.V = (function (Ot) { var Nt = function Bt(Rt) { if (Rt.length == 0)
            return 0; for (var Xt = [], zt = 0; zt < Rt[0]; zt++)
            Xt.push(Bt(Rt.slice(1))); return Xt; }; return Nt(Ot); })([this.n, this.n]); for (var i = (function (Ot) { for (var Nt = []; Ot-- > 0;)
            Nt.push(0); return Nt; })(this.n), n = (function (Ot) { for (var Nt = []; Ot-- > 0;)
            Nt.push(0); return Nt; })(this.m), f = !0, e = !0, u = Math.min(this.m - 1, this.n), r = Math.max(0, Math.min(this.n - 2, this.m)), t = 0; t < Math.max(u, r); t++) {
            if (t < u) {
                this.s[t] = 0;
                for (var l = t; l < this.m; l++)
                    this.s[t] = g.hypot(this.s[t], s[l][t]);
                if (this.s[t] !== 0) {
                    s[t][t] < 0 && (this.s[t] = -this.s[t]);
                    for (var c = t; c < this.m; c++)
                        s[c][t] /= this.s[t];
                    s[t][t] += 1;
                }
                this.s[t] = -this.s[t];
            }
            for (var h = t + 1; h < this.n; h++) {
                if ((function (Ot, Nt) { return Ot && Nt; })(t < u, this.s[t] !== 0)) {
                    for (var w = 0, p = t; p < this.m; p++)
                        w += s[p][t] * s[p][h];
                    w = -w / s[t][t];
                    for (var y = t; y < this.m; y++)
                        s[y][h] += w * s[y][t];
                }
                i[h] = s[t][h];
            }
            if ((function (Ot, Nt) { return Ot && Nt; })(f, t < u))
                for (var L = t; L < this.m; L++)
                    this.U[L][t] = s[L][t];
            if (t < r) {
                i[t] = 0;
                for (var I = t + 1; I < this.n; I++)
                    i[t] = g.hypot(i[t], i[I]);
                if (i[t] !== 0) {
                    i[t + 1] < 0 && (i[t] = -i[t]);
                    for (var M = t + 1; M < this.n; M++)
                        i[M] /= i[t];
                    i[t + 1] += 1;
                }
                if (i[t] = -i[t], (function (Ot, Nt) { return Ot && Nt; })(t + 1 < this.m, i[t] !== 0)) {
                    for (var S = t + 1; S < this.m; S++)
                        n[S] = 0;
                    for (var X = t + 1; X < this.n; X++)
                        for (var G = t + 1; G < this.m; G++)
                            n[G] += i[X] * s[G][X];
                    for (var Q = t + 1; Q < this.n; Q++)
                        for (var O = -i[Q] / i[t + 1], H = t + 1; H < this.m; H++)
                            s[H][Q] += O * n[H];
                }
                if (e)
                    for (var o = t + 1; o < this.n; o++)
                        this.V[o][t] = i[o];
            }
        } var m = Math.min(this.n, this.m + 1); if (u < this.n && (this.s[u] = s[u][u]), this.m < m && (this.s[m - 1] = 0), r + 1 < m && (i[r] = s[r][m - 1]), i[m - 1] = 0, f) {
            for (var v = u; v < a; v++) {
                for (var T = 0; T < this.m; T++)
                    this.U[T][v] = 0;
                this.U[v][v] = 1;
            }
            for (var d = u - 1; d >= 0; d--)
                if (this.s[d] !== 0) {
                    for (var x = d + 1; x < a; x++) {
                        for (var D = 0, P = d; P < this.m; P++)
                            D += this.U[P][d] * this.U[P][x];
                        D = -D / this.U[d][d];
                        for (var F = d; F < this.m; F++)
                            this.U[F][x] += D * this.U[F][d];
                    }
                    for (var R = d; R < this.m; R++)
                        this.U[R][d] = -this.U[R][d];
                    this.U[d][d] = 1 + this.U[d][d];
                    for (var k = 0; k < d - 1; k++)
                        this.U[k][d] = 0;
                }
                else {
                    for (var tt = 0; tt < this.m; tt++)
                        this.U[tt][d] = 0;
                    this.U[d][d] = 1;
                }
        } if (e)
            for (var b = this.n - 1; b >= 0; b--) {
                if ((function (Ot, Nt) { return Ot && Nt; })(b < r, i[b] !== 0))
                    for (var _ = b + 1; _ < a; _++) {
                        for (var $ = 0, A = b + 1; A < this.n; A++)
                            $ += this.V[A][b] * this.V[A][_];
                        $ = -$ / this.V[b + 1][b];
                        for (var Y = b + 1; Y < this.n; Y++)
                            this.V[Y][_] += $ * this.V[Y][b];
                    }
                for (var W = 0; W < this.n; W++)
                    this.V[W][b] = 0;
                this.V[b][b] = 1;
            } for (var K = m - 1, st = 0, Lt = Math.pow(2, -52), St = Math.pow(2, -966); m > 0;) {
            var J = void 0, Ut = void 0;
            for (J = m - 2; J >= -1 && J !== -1; J--)
                if (Math.abs(i[J]) <= St + Lt * (Math.abs(this.s[J]) + Math.abs(this.s[J + 1]))) {
                    i[J] = 0;
                    break;
                }
            if (J === m - 2)
                Ut = 4;
            else {
                var At = void 0;
                for (At = m - 1; At >= J && At !== J; At--) {
                    var at = (At !== m ? Math.abs(i[At]) : 0) + (At !== J + 1 ? Math.abs(i[At - 1]) : 0);
                    if (Math.abs(this.s[At]) <= St + Lt * at) {
                        this.s[At] = 0;
                        break;
                    }
                }
                At === J ? Ut = 3 : At === m - 1 ? Ut = 1 : (Ut = 2, J = At);
            }
            switch (J++, Ut) {
                case 1:
                    {
                        var et = i[m - 2];
                        i[m - 2] = 0;
                        for (var pt = m - 2; pt >= J; pt--) {
                            var mt = g.hypot(this.s[pt], et), wt = this.s[pt] / mt, Et = et / mt;
                            if (this.s[pt] = mt, pt !== J && (et = -Et * i[pt - 1], i[pt - 1] = wt * i[pt - 1]), e)
                                for (var Tt = 0; Tt < this.n; Tt++)
                                    mt = wt * this.V[Tt][pt] + Et * this.V[Tt][m - 1], this.V[Tt][m - 1] = -Et * this.V[Tt][pt] + wt * this.V[Tt][m - 1], this.V[Tt][pt] = mt;
                        }
                    }
                    break;
                case 2:
                    {
                        var Dt = i[J - 1];
                        i[J - 1] = 0;
                        for (var It = J; It < m; It++) {
                            var Wt = g.hypot(this.s[It], Dt), Pt = this.s[It] / Wt, Yt = Dt / Wt;
                            if (this.s[It] = Wt, Dt = -Yt * i[It], i[It] = Pt * i[It], f)
                                for (var bt = 0; bt < this.m; bt++)
                                    Wt = Pt * this.U[bt][It] + Yt * this.U[bt][J - 1], this.U[bt][J - 1] = -Yt * this.U[bt][It] + Pt * this.U[bt][J - 1], this.U[bt][It] = Wt;
                        }
                    }
                    break;
                case 3:
                    {
                        var U = Math.max(Math.max(Math.max(Math.max(Math.abs(this.s[m - 1]), Math.abs(this.s[m - 2])), Math.abs(i[m - 2])), Math.abs(this.s[J])), Math.abs(i[J])), V = this.s[m - 1] / U, z = this.s[m - 2] / U, B = i[m - 2] / U, Z = this.s[J] / U, j = i[J] / U, ut = ((z + V) * (z - V) + B * B) / 2, ct = V * B * (V * B), q = 0;
                        (function (Ot, Nt) { return Ot || Nt; })(ut !== 0, ct !== 0) && (q = Math.sqrt(ut * ut + ct), ut < 0 && (q = -q), q = ct / (ut + q));
                        for (var ht = (Z + V) * (Z - V) + q, gt = Z * j, rt = J; rt < m - 1; rt++) {
                            var vt = g.hypot(ht, gt), Mt = ht / vt, ot = gt / vt;
                            if (rt !== J && (i[rt - 1] = vt), ht = Mt * this.s[rt] + ot * i[rt], i[rt] = Mt * i[rt] - ot * this.s[rt], gt = ot * this.s[rt + 1], this.s[rt + 1] = Mt * this.s[rt + 1], e)
                                for (var it = 0; it < this.n; it++)
                                    vt = Mt * this.V[it][rt] + ot * this.V[it][rt + 1], this.V[it][rt + 1] = -ot * this.V[it][rt] + Mt * this.V[it][rt + 1], this.V[it][rt] = vt;
                            if (vt = g.hypot(ht, gt), Mt = ht / vt, ot = gt / vt, this.s[rt] = vt, ht = Mt * i[rt] + ot * this.s[rt + 1], this.s[rt + 1] = -ot * i[rt] + Mt * this.s[rt + 1], gt = ot * i[rt + 1], i[rt + 1] = Mt * i[rt + 1], f && rt < this.m - 1)
                                for (var dt = 0; dt < this.m; dt++)
                                    vt = Mt * this.U[dt][rt] + ot * this.U[dt][rt + 1], this.U[dt][rt + 1] = -ot * this.U[dt][rt] + Mt * this.U[dt][rt + 1], this.U[dt][rt] = vt;
                        }
                        i[m - 2] = ht, st = st + 1;
                    }
                    break;
                case 4:
                    {
                        if (this.s[J] <= 0 && (this.s[J] = this.s[J] < 0 ? -this.s[J] : 0, e))
                            for (var nt = 0; nt <= K; nt++)
                                this.V[nt][J] = -this.V[nt][J];
                        for (; J < K && !(this.s[J] >= this.s[J + 1]);) {
                            var lt = this.s[J];
                            if (this.s[J] = this.s[J + 1], this.s[J + 1] = lt, e && J < this.n - 1)
                                for (var Ft = 0; Ft < this.n; Ft++)
                                    lt = this.V[Ft][J + 1], this.V[Ft][J + 1] = this.V[Ft][J], this.V[Ft][J] = lt;
                            if (f && J < this.m - 1)
                                for (var xt = 0; xt < this.m; xt++)
                                    lt = this.U[xt][J + 1], this.U[xt][J + 1] = this.U[xt][J], this.U[xt][J] = lt;
                            J++;
                        }
                        st = 0, m--;
                    }
                    break;
            }
        } var Vt = { U: this.U, V: this.V, S: this.s }; return Vt; }, g.hypot = function (s, a) { var i = void 0; return Math.abs(s) > Math.abs(a) ? (i = a / s, i = Math.abs(s) * Math.sqrt(1 + i * i)) : a != 0 ? (i = s / a, i = Math.abs(a) * Math.sqrt(1 + i * i)) : i = 0, i; }, E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        var g = (function () { function i(n, f) { for (var e = 0; e < f.length; e++) {
            var u = f[e];
            u.enumerable = u.enumerable || !1, u.configurable = !0, "value" in u && (u.writable = !0), Object.defineProperty(n, u.key, u);
        } } return function (n, f, e) { return f && i(n.prototype, f), e && i(n, e), n; }; })();
        function s(i, n) { if (!(i instanceof n))
            throw new TypeError("Cannot call a class as a function"); }
        var a = (function () { function i(n, f) { var e = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : 1, u = arguments.length > 3 && arguments[3] !== void 0 ? arguments[3] : -1, r = arguments.length > 4 && arguments[4] !== void 0 ? arguments[4] : -1; s(this, i), this.sequence1 = n, this.sequence2 = f, this.match_score = e, this.mismatch_penalty = u, this.gap_penalty = r, this.iMax = n.length + 1, this.jMax = f.length + 1, this.grid = new Array(this.iMax); for (var t = 0; t < this.iMax; t++) {
            this.grid[t] = new Array(this.jMax);
            for (var l = 0; l < this.jMax; l++)
                this.grid[t][l] = 0;
        } this.tracebackGrid = new Array(this.iMax); for (var c = 0; c < this.iMax; c++) {
            this.tracebackGrid[c] = new Array(this.jMax);
            for (var h = 0; h < this.jMax; h++)
                this.tracebackGrid[c][h] = [null, null, null];
        } this.alignments = [], this.score = -1, this.computeGrids(); } return g(i, [{ key: "getScore", value: function () { return this.score; } }, { key: "getAlignments", value: function () { return this.alignments; } }, { key: "computeGrids", value: function () { for (var f = 1; f < this.jMax; f++)
                    this.grid[0][f] = this.grid[0][f - 1] + this.gap_penalty, this.tracebackGrid[0][f] = [!1, !1, !0]; for (var e = 1; e < this.iMax; e++)
                    this.grid[e][0] = this.grid[e - 1][0] + this.gap_penalty, this.tracebackGrid[e][0] = [!1, !0, !1]; for (var u = 1; u < this.iMax; u++)
                    for (var r = 1; r < this.jMax; r++) {
                        var t = void 0;
                        this.sequence1[u - 1] === this.sequence2[r - 1] ? t = this.grid[u - 1][r - 1] + this.match_score : t = this.grid[u - 1][r - 1] + this.mismatch_penalty;
                        var l = this.grid[u - 1][r] + this.gap_penalty, c = this.grid[u][r - 1] + this.gap_penalty, h = [t, l, c], w = this.arrayAllMaxIndexes(h);
                        this.grid[u][r] = h[w[0]], this.tracebackGrid[u][r] = [w.includes(0), w.includes(1), w.includes(2)];
                    } this.score = this.grid[this.iMax - 1][this.jMax - 1]; } }, { key: "alignmentTraceback", value: function () { var f = []; for (f.push({ pos: [this.sequence1.length, this.sequence2.length], seq1: "", seq2: "" }); f[0];) {
                    var e = f[0], u = this.tracebackGrid[e.pos[0]][e.pos[1]];
                    u[0] && f.push({ pos: [e.pos[0] - 1, e.pos[1] - 1], seq1: this.sequence1[e.pos[0] - 1] + e.seq1, seq2: this.sequence2[e.pos[1] - 1] + e.seq2 }), u[1] && f.push({ pos: [e.pos[0] - 1, e.pos[1]], seq1: this.sequence1[e.pos[0] - 1] + e.seq1, seq2: "-" + e.seq2 }), u[2] && f.push({ pos: [e.pos[0], e.pos[1] - 1], seq1: "-" + e.seq1, seq2: this.sequence2[e.pos[1] - 1] + e.seq2 }), e.pos[0] === 0 && e.pos[1] === 0 && this.alignments.push({ sequence1: e.seq1, sequence2: e.seq2 }), f.shift();
                } return this.alignments; } }, { key: "getAllIndexes", value: function (f, e) { for (var u = [], r = -1; (r = f.indexOf(e, r + 1)) !== -1;)
                    u.push(r); return u; } }, { key: "arrayAllMaxIndexes", value: function (f) { return this.getAllIndexes(f, Math.max.apply(null, f)); } }]), i; })();
        E.exports = a;
    }), (function (E, C, N) {
        "use strict";
        var g = function () { };
        g.FDLayout = N(18), g.FDLayoutConstants = N(4), g.FDLayoutEdge = N(19), g.FDLayoutNode = N(20), g.DimensionD = N(21), g.HashMap = N(22), g.HashSet = N(23), g.IGeometry = N(8), g.IMath = N(9), g.Integer = N(10), g.Point = N(12), g.PointD = N(5), g.RandomSeed = N(16), g.RectangleD = N(13), g.Transform = N(17), g.UniqueIDGeneretor = N(14), g.Quicksort = N(25), g.LinkedList = N(11), g.LGraphObject = N(2), g.LGraph = N(6), g.LEdge = N(1), g.LGraphManager = N(7), g.LNode = N(3), g.Layout = N(15), g.LayoutConstants = N(0), g.NeedlemanWunsch = N(27), g.Matrix = N(24), g.SVD = N(26), E.exports = g;
    }), (function (E, C, N) {
        "use strict";
        function g() { this.listeners = []; }
        var s = g.prototype;
        s.addListener = function (a, i) { this.listeners.push({ event: a, callback: i }); }, s.removeListener = function (a, i) { for (var n = this.listeners.length; n >= 0; n--) {
            var f = this.listeners[n];
            f.event === a && f.callback === i && this.listeners.splice(n, 1);
        } }, s.emit = function (a, i) { for (var n = 0; n < this.listeners.length; n++) {
            var f = this.listeners[n];
            a === f.event && f.callback(i);
        } }, E.exports = g;
    })]); }); });
var Ce = Ee((ae, Me) => { (function (C, N) { typeof ae == "object" && typeof Me == "object" ? Me.exports = N(we()) : typeof define == "function" && define.amd ? define(["layout-base"], N) : typeof ae == "object" ? ae.coseBase = N(we()) : C.coseBase = N(C.layoutBase); })(ae, function (E) { return (() => {
    "use strict";
    var C = { 45: ((a, i, n) => { var f = {}; f.layoutBase = n(551), f.CoSEConstants = n(806), f.CoSEEdge = n(767), f.CoSEGraph = n(880), f.CoSEGraphManager = n(578), f.CoSELayout = n(765), f.CoSENode = n(991), f.ConstraintHandler = n(902), a.exports = f; }), 806: ((a, i, n) => { var f = n(551).FDLayoutConstants; function e() { } for (var u in f)
            e[u] = f[u]; e.DEFAULT_USE_MULTI_LEVEL_SCALING = !1, e.DEFAULT_RADIAL_SEPARATION = f.DEFAULT_EDGE_LENGTH, e.DEFAULT_COMPONENT_SEPERATION = 60, e.TILE = !0, e.TILING_PADDING_VERTICAL = 10, e.TILING_PADDING_HORIZONTAL = 10, e.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, e.ENFORCE_CONSTRAINTS = !0, e.APPLY_LAYOUT = !0, e.RELAX_MOVEMENT_ON_CONSTRAINTS = !0, e.TREE_REDUCTION_ON_INCREMENTAL = !0, e.PURE_INCREMENTAL = e.DEFAULT_INCREMENTAL, a.exports = e; }), 767: ((a, i, n) => { var f = n(551).FDLayoutEdge; function e(r, t, l) { f.call(this, r, t, l); } e.prototype = Object.create(f.prototype); for (var u in f)
            e[u] = f[u]; a.exports = e; }), 880: ((a, i, n) => { var f = n(551).LGraph; function e(r, t, l) { f.call(this, r, t, l); } e.prototype = Object.create(f.prototype); for (var u in f)
            e[u] = f[u]; a.exports = e; }), 578: ((a, i, n) => { var f = n(551).LGraphManager; function e(r) { f.call(this, r); } e.prototype = Object.create(f.prototype); for (var u in f)
            e[u] = f[u]; a.exports = e; }), 765: ((a, i, n) => { var f = n(551).FDLayout, e = n(578), u = n(880), r = n(991), t = n(767), l = n(806), c = n(902), h = n(551).FDLayoutConstants, w = n(551).LayoutConstants, p = n(551).Point, y = n(551).PointD, L = n(551).DimensionD, I = n(551).Layout, M = n(551).Integer, S = n(551).IGeometry, X = n(551).LGraph, G = n(551).Transform, Q = n(551).LinkedList; function O() { f.call(this), this.toBeTiled = {}, this.constraints = {}; } O.prototype = Object.create(f.prototype); for (var H in f)
            O[H] = f[H]; O.prototype.newGraphManager = function () { var o = new e(this); return this.graphManager = o, o; }, O.prototype.newGraph = function (o) { return new u(null, this.graphManager, o); }, O.prototype.newNode = function (o) { return new r(this.graphManager, o); }, O.prototype.newEdge = function (o) { return new t(null, null, o); }, O.prototype.initParameters = function () { f.prototype.initParameters.call(this, arguments), this.isSubLayout || (l.DEFAULT_EDGE_LENGTH < 10 ? this.idealEdgeLength = 10 : this.idealEdgeLength = l.DEFAULT_EDGE_LENGTH, this.useSmartIdealEdgeLengthCalculation = l.DEFAULT_USE_SMART_IDEAL_EDGE_LENGTH_CALCULATION, this.gravityConstant = h.DEFAULT_GRAVITY_STRENGTH, this.compoundGravityConstant = h.DEFAULT_COMPOUND_GRAVITY_STRENGTH, this.gravityRangeFactor = h.DEFAULT_GRAVITY_RANGE_FACTOR, this.compoundGravityRangeFactor = h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR, this.prunedNodesAll = [], this.growTreeIterations = 0, this.afterGrowthIterations = 0, this.isTreeGrowing = !1, this.isGrowthFinished = !1); }, O.prototype.initSpringEmbedder = function () { f.prototype.initSpringEmbedder.call(this), this.coolingCycle = 0, this.maxCoolingCycle = this.maxIterations / h.CONVERGENCE_CHECK_PERIOD, this.finalTemperature = .04, this.coolingAdjuster = 1; }, O.prototype.layout = function () { var o = w.DEFAULT_CREATE_BENDS_AS_NEEDED; return o && (this.createBendpoints(), this.graphManager.resetAllEdges()), this.level = 0, this.classicLayout(); }, O.prototype.classicLayout = function () { if (this.nodesWithGravity = this.calculateNodesToApplyGravitationTo(), this.graphManager.setAllNodesToApplyGravitation(this.nodesWithGravity), this.calcNoOfChildrenForAllNodes(), this.graphManager.calcLowestCommonAncestors(), this.graphManager.calcInclusionTreeDepths(), this.graphManager.getRoot().calcEstimatedSize(), this.calcIdealEdgeLengths(), this.incremental) {
            if (l.TREE_REDUCTION_ON_INCREMENTAL) {
                this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                var m = new Set(this.getAllNodes()), v = this.nodesWithGravity.filter(function (x) { return m.has(x); });
                this.graphManager.setAllNodesToApplyGravitation(v);
            }
        }
        else {
            var o = this.getFlatForest();
            if (o.length > 0)
                this.positionNodesRadially(o);
            else {
                this.reduceTrees(), this.graphManager.resetAllNodesToApplyGravitation();
                var m = new Set(this.getAllNodes()), v = this.nodesWithGravity.filter(function (T) { return m.has(T); });
                this.graphManager.setAllNodesToApplyGravitation(v), this.positionNodesRandomly();
            }
        } return Object.keys(this.constraints).length > 0 && (c.handleConstraints(this), this.initConstraintVariables()), this.initSpringEmbedder(), l.APPLY_LAYOUT && this.runSpringEmbedder(), !0; }, O.prototype.tick = function () { if (this.totalIterations++, this.totalIterations === this.maxIterations && !this.isTreeGrowing && !this.isGrowthFinished)
            if (this.prunedNodesAll.length > 0)
                this.isTreeGrowing = !0;
            else
                return !0; if (this.totalIterations % h.CONVERGENCE_CHECK_PERIOD == 0 && !this.isTreeGrowing && !this.isGrowthFinished) {
            if (this.isConverged())
                if (this.prunedNodesAll.length > 0)
                    this.isTreeGrowing = !0;
                else
                    return !0;
            this.coolingCycle++, this.layoutQuality == 0 ? this.coolingAdjuster = this.coolingCycle : this.layoutQuality == 1 && (this.coolingAdjuster = this.coolingCycle / 3), this.coolingFactor = Math.max(this.initialCoolingFactor - Math.pow(this.coolingCycle, Math.log(100 * (this.initialCoolingFactor - this.finalTemperature)) / Math.log(this.maxCoolingCycle)) / 100 * this.coolingAdjuster, this.finalTemperature), this.animationPeriod = Math.ceil(this.initialAnimationPeriod * Math.sqrt(this.coolingFactor));
        } if (this.isTreeGrowing) {
            if (this.growTreeIterations % 10 == 0)
                if (this.prunedNodesAll.length > 0) {
                    this.graphManager.updateBounds(), this.updateGrid(), this.growTree(this.prunedNodesAll), this.graphManager.resetAllNodesToApplyGravitation();
                    var o = new Set(this.getAllNodes()), m = this.nodesWithGravity.filter(function (d) { return o.has(d); });
                    this.graphManager.setAllNodesToApplyGravitation(m), this.graphManager.updateBounds(), this.updateGrid(), l.PURE_INCREMENTAL ? this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 : this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL;
                }
                else
                    this.isTreeGrowing = !1, this.isGrowthFinished = !0;
            this.growTreeIterations++;
        } if (this.isGrowthFinished) {
            if (this.isConverged())
                return !0;
            this.afterGrowthIterations % 10 == 0 && (this.graphManager.updateBounds(), this.updateGrid()), l.PURE_INCREMENTAL ? this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL / 2 * ((100 - this.afterGrowthIterations) / 100) : this.coolingFactor = h.DEFAULT_COOLING_FACTOR_INCREMENTAL * ((100 - this.afterGrowthIterations) / 100), this.afterGrowthIterations++;
        } var v = !this.isTreeGrowing && !this.isGrowthFinished, T = this.growTreeIterations % 10 == 1 && this.isTreeGrowing || this.afterGrowthIterations % 10 == 1 && this.isGrowthFinished; return this.totalDisplacement = 0, this.graphManager.updateBounds(), this.calcSpringForces(), this.calcRepulsionForces(v, T), this.calcGravitationalForces(), this.moveNodes(), this.animate(), !1; }, O.prototype.getPositionsData = function () { for (var o = this.graphManager.getAllNodes(), m = {}, v = 0; v < o.length; v++) {
            var T = o[v].rect, d = o[v].id;
            m[d] = { id: d, x: T.getCenterX(), y: T.getCenterY(), w: T.width, h: T.height };
        } return m; }, O.prototype.runSpringEmbedder = function () { this.initialAnimationPeriod = 25, this.animationPeriod = this.initialAnimationPeriod; var o = !1; if (h.ANIMATE === "during")
            this.emit("layoutstarted");
        else {
            for (; !o;)
                o = this.tick();
            this.graphManager.updateBounds();
        } }, O.prototype.moveNodes = function () { for (var o = this.getAllNodes(), m, v = 0; v < o.length; v++)
            m = o[v], m.calculateDisplacement(); Object.keys(this.constraints).length > 0 && this.updateDisplacements(); for (var v = 0; v < o.length; v++)
            m = o[v], m.move(); }, O.prototype.initConstraintVariables = function () { var o = this; this.idToNodeMap = new Map, this.fixedNodeSet = new Set; for (var m = this.graphManager.getAllNodes(), v = 0; v < m.length; v++) {
            var T = m[v];
            this.idToNodeMap.set(T.id, T);
        } var d = function A(Y) { for (var W = Y.getChild().getNodes(), K, st = 0, Lt = 0; Lt < W.length; Lt++)
            K = W[Lt], K.getChild() == null ? o.fixedNodeSet.has(K.id) && (st += 100) : st += A(K); return st; }; if (this.constraints.fixedNodeConstraint) {
            this.constraints.fixedNodeConstraint.forEach(function (W) { o.fixedNodeSet.add(W.nodeId); });
            for (var m = this.graphManager.getAllNodes(), T, v = 0; v < m.length; v++)
                if (T = m[v], T.getChild() != null) {
                    var x = d(T);
                    x > 0 && (T.fixedNodeWeight = x);
                }
        } if (this.constraints.relativePlacementConstraint) {
            var D = new Map, P = new Map;
            if (this.dummyToNodeForVerticalAlignment = new Map, this.dummyToNodeForHorizontalAlignment = new Map, this.fixedNodesOnHorizontal = new Set, this.fixedNodesOnVertical = new Set, this.fixedNodeSet.forEach(function (A) { o.fixedNodesOnHorizontal.add(A), o.fixedNodesOnVertical.add(A); }), this.constraints.alignmentConstraint) {
                if (this.constraints.alignmentConstraint.vertical)
                    for (var F = this.constraints.alignmentConstraint.vertical, v = 0; v < F.length; v++)
                        this.dummyToNodeForVerticalAlignment.set("dummy" + v, []), F[v].forEach(function (Y) { D.set(Y, "dummy" + v), o.dummyToNodeForVerticalAlignment.get("dummy" + v).push(Y), o.fixedNodeSet.has(Y) && o.fixedNodesOnHorizontal.add("dummy" + v); });
                if (this.constraints.alignmentConstraint.horizontal)
                    for (var R = this.constraints.alignmentConstraint.horizontal, v = 0; v < R.length; v++)
                        this.dummyToNodeForHorizontalAlignment.set("dummy" + v, []), R[v].forEach(function (Y) { P.set(Y, "dummy" + v), o.dummyToNodeForHorizontalAlignment.get("dummy" + v).push(Y), o.fixedNodeSet.has(Y) && o.fixedNodesOnVertical.add("dummy" + v); });
            }
            if (l.RELAX_MOVEMENT_ON_CONSTRAINTS)
                this.shuffle = function (A) { var Y, W, K; for (K = A.length - 1; K >= 2 * A.length / 3; K--)
                    Y = Math.floor(Math.random() * (K + 1)), W = A[K], A[K] = A[Y], A[Y] = W; return A; }, this.nodesInRelativeHorizontal = [], this.nodesInRelativeVertical = [], this.nodeToRelativeConstraintMapHorizontal = new Map, this.nodeToRelativeConstraintMapVertical = new Map, this.nodeToTempPositionMapHorizontal = new Map, this.nodeToTempPositionMapVertical = new Map, this.constraints.relativePlacementConstraint.forEach(function (A) { if (A.left) {
                    var Y = D.has(A.left) ? D.get(A.left) : A.left, W = D.has(A.right) ? D.get(A.right) : A.right;
                    o.nodesInRelativeHorizontal.includes(Y) || (o.nodesInRelativeHorizontal.push(Y), o.nodeToRelativeConstraintMapHorizontal.set(Y, []), o.dummyToNodeForVerticalAlignment.has(Y) ? o.nodeToTempPositionMapHorizontal.set(Y, o.idToNodeMap.get(o.dummyToNodeForVerticalAlignment.get(Y)[0]).getCenterX()) : o.nodeToTempPositionMapHorizontal.set(Y, o.idToNodeMap.get(Y).getCenterX())), o.nodesInRelativeHorizontal.includes(W) || (o.nodesInRelativeHorizontal.push(W), o.nodeToRelativeConstraintMapHorizontal.set(W, []), o.dummyToNodeForVerticalAlignment.has(W) ? o.nodeToTempPositionMapHorizontal.set(W, o.idToNodeMap.get(o.dummyToNodeForVerticalAlignment.get(W)[0]).getCenterX()) : o.nodeToTempPositionMapHorizontal.set(W, o.idToNodeMap.get(W).getCenterX())), o.nodeToRelativeConstraintMapHorizontal.get(Y).push({ right: W, gap: A.gap }), o.nodeToRelativeConstraintMapHorizontal.get(W).push({ left: Y, gap: A.gap });
                }
                else {
                    var K = P.has(A.top) ? P.get(A.top) : A.top, st = P.has(A.bottom) ? P.get(A.bottom) : A.bottom;
                    o.nodesInRelativeVertical.includes(K) || (o.nodesInRelativeVertical.push(K), o.nodeToRelativeConstraintMapVertical.set(K, []), o.dummyToNodeForHorizontalAlignment.has(K) ? o.nodeToTempPositionMapVertical.set(K, o.idToNodeMap.get(o.dummyToNodeForHorizontalAlignment.get(K)[0]).getCenterY()) : o.nodeToTempPositionMapVertical.set(K, o.idToNodeMap.get(K).getCenterY())), o.nodesInRelativeVertical.includes(st) || (o.nodesInRelativeVertical.push(st), o.nodeToRelativeConstraintMapVertical.set(st, []), o.dummyToNodeForHorizontalAlignment.has(st) ? o.nodeToTempPositionMapVertical.set(st, o.idToNodeMap.get(o.dummyToNodeForHorizontalAlignment.get(st)[0]).getCenterY()) : o.nodeToTempPositionMapVertical.set(st, o.idToNodeMap.get(st).getCenterY())), o.nodeToRelativeConstraintMapVertical.get(K).push({ bottom: st, gap: A.gap }), o.nodeToRelativeConstraintMapVertical.get(st).push({ top: K, gap: A.gap });
                } });
            else {
                var k = new Map, tt = new Map;
                this.constraints.relativePlacementConstraint.forEach(function (A) { if (A.left) {
                    var Y = D.has(A.left) ? D.get(A.left) : A.left, W = D.has(A.right) ? D.get(A.right) : A.right;
                    k.has(Y) ? k.get(Y).push(W) : k.set(Y, [W]), k.has(W) ? k.get(W).push(Y) : k.set(W, [Y]);
                }
                else {
                    var K = P.has(A.top) ? P.get(A.top) : A.top, st = P.has(A.bottom) ? P.get(A.bottom) : A.bottom;
                    tt.has(K) ? tt.get(K).push(st) : tt.set(K, [st]), tt.has(st) ? tt.get(st).push(K) : tt.set(st, [K]);
                } });
                var b = function (Y, W) { var K = [], st = [], Lt = new Q, St = new Set, J = 0; return Y.forEach(function (Ut, At) { if (!St.has(At)) {
                    K[J] = [], st[J] = !1;
                    var at = At;
                    for (Lt.push(at), St.add(at), K[J].push(at); Lt.length != 0;) {
                        at = Lt.shift(), W.has(at) && (st[J] = !0);
                        var et = Y.get(at);
                        et.forEach(function (pt) { St.has(pt) || (Lt.push(pt), St.add(pt), K[J].push(pt)); });
                    }
                    J++;
                } }), { components: K, isFixed: st }; }, _ = b(k, o.fixedNodesOnHorizontal);
                this.componentsOnHorizontal = _.components, this.fixedComponentsOnHorizontal = _.isFixed;
                var $ = b(tt, o.fixedNodesOnVertical);
                this.componentsOnVertical = $.components, this.fixedComponentsOnVertical = $.isFixed;
            }
        } }, O.prototype.updateDisplacements = function () { var o = this; if (this.constraints.fixedNodeConstraint && this.constraints.fixedNodeConstraint.forEach(function ($) { var A = o.idToNodeMap.get($.nodeId); A.displacementX = 0, A.displacementY = 0; }), this.constraints.alignmentConstraint) {
            if (this.constraints.alignmentConstraint.vertical)
                for (var m = this.constraints.alignmentConstraint.vertical, v = 0; v < m.length; v++) {
                    for (var T = 0, d = 0; d < m[v].length; d++) {
                        if (this.fixedNodeSet.has(m[v][d])) {
                            T = 0;
                            break;
                        }
                        T += this.idToNodeMap.get(m[v][d]).displacementX;
                    }
                    for (var x = T / m[v].length, d = 0; d < m[v].length; d++)
                        this.idToNodeMap.get(m[v][d]).displacementX = x;
                }
            if (this.constraints.alignmentConstraint.horizontal)
                for (var D = this.constraints.alignmentConstraint.horizontal, v = 0; v < D.length; v++) {
                    for (var P = 0, d = 0; d < D[v].length; d++) {
                        if (this.fixedNodeSet.has(D[v][d])) {
                            P = 0;
                            break;
                        }
                        P += this.idToNodeMap.get(D[v][d]).displacementY;
                    }
                    for (var F = P / D[v].length, d = 0; d < D[v].length; d++)
                        this.idToNodeMap.get(D[v][d]).displacementY = F;
                }
        } if (this.constraints.relativePlacementConstraint)
            if (l.RELAX_MOVEMENT_ON_CONSTRAINTS)
                this.totalIterations % 10 == 0 && (this.shuffle(this.nodesInRelativeHorizontal), this.shuffle(this.nodesInRelativeVertical)), this.nodesInRelativeHorizontal.forEach(function ($) { if (!o.fixedNodesOnHorizontal.has($)) {
                    var A = 0;
                    o.dummyToNodeForVerticalAlignment.has($) ? A = o.idToNodeMap.get(o.dummyToNodeForVerticalAlignment.get($)[0]).displacementX : A = o.idToNodeMap.get($).displacementX, o.nodeToRelativeConstraintMapHorizontal.get($).forEach(function (Y) { if (Y.right) {
                        var W = o.nodeToTempPositionMapHorizontal.get(Y.right) - o.nodeToTempPositionMapHorizontal.get($) - A;
                        W < Y.gap && (A -= Y.gap - W);
                    }
                    else {
                        var W = o.nodeToTempPositionMapHorizontal.get($) - o.nodeToTempPositionMapHorizontal.get(Y.left) + A;
                        W < Y.gap && (A += Y.gap - W);
                    } }), o.nodeToTempPositionMapHorizontal.set($, o.nodeToTempPositionMapHorizontal.get($) + A), o.dummyToNodeForVerticalAlignment.has($) ? o.dummyToNodeForVerticalAlignment.get($).forEach(function (Y) { o.idToNodeMap.get(Y).displacementX = A; }) : o.idToNodeMap.get($).displacementX = A;
                } }), this.nodesInRelativeVertical.forEach(function ($) { if (!o.fixedNodesOnHorizontal.has($)) {
                    var A = 0;
                    o.dummyToNodeForHorizontalAlignment.has($) ? A = o.idToNodeMap.get(o.dummyToNodeForHorizontalAlignment.get($)[0]).displacementY : A = o.idToNodeMap.get($).displacementY, o.nodeToRelativeConstraintMapVertical.get($).forEach(function (Y) { if (Y.bottom) {
                        var W = o.nodeToTempPositionMapVertical.get(Y.bottom) - o.nodeToTempPositionMapVertical.get($) - A;
                        W < Y.gap && (A -= Y.gap - W);
                    }
                    else {
                        var W = o.nodeToTempPositionMapVertical.get($) - o.nodeToTempPositionMapVertical.get(Y.top) + A;
                        W < Y.gap && (A += Y.gap - W);
                    } }), o.nodeToTempPositionMapVertical.set($, o.nodeToTempPositionMapVertical.get($) + A), o.dummyToNodeForHorizontalAlignment.has($) ? o.dummyToNodeForHorizontalAlignment.get($).forEach(function (Y) { o.idToNodeMap.get(Y).displacementY = A; }) : o.idToNodeMap.get($).displacementY = A;
                } });
            else {
                for (var v = 0; v < this.componentsOnHorizontal.length; v++) {
                    var R = this.componentsOnHorizontal[v];
                    if (this.fixedComponentsOnHorizontal[v])
                        for (var d = 0; d < R.length; d++)
                            this.dummyToNodeForVerticalAlignment.has(R[d]) ? this.dummyToNodeForVerticalAlignment.get(R[d]).forEach(function (Y) { o.idToNodeMap.get(Y).displacementX = 0; }) : this.idToNodeMap.get(R[d]).displacementX = 0;
                    else {
                        for (var k = 0, tt = 0, d = 0; d < R.length; d++)
                            if (this.dummyToNodeForVerticalAlignment.has(R[d])) {
                                var b = this.dummyToNodeForVerticalAlignment.get(R[d]);
                                k += b.length * this.idToNodeMap.get(b[0]).displacementX, tt += b.length;
                            }
                            else
                                k += this.idToNodeMap.get(R[d]).displacementX, tt++;
                        for (var _ = k / tt, d = 0; d < R.length; d++)
                            this.dummyToNodeForVerticalAlignment.has(R[d]) ? this.dummyToNodeForVerticalAlignment.get(R[d]).forEach(function (Y) { o.idToNodeMap.get(Y).displacementX = _; }) : this.idToNodeMap.get(R[d]).displacementX = _;
                    }
                }
                for (var v = 0; v < this.componentsOnVertical.length; v++) {
                    var R = this.componentsOnVertical[v];
                    if (this.fixedComponentsOnVertical[v])
                        for (var d = 0; d < R.length; d++)
                            this.dummyToNodeForHorizontalAlignment.has(R[d]) ? this.dummyToNodeForHorizontalAlignment.get(R[d]).forEach(function (W) { o.idToNodeMap.get(W).displacementY = 0; }) : this.idToNodeMap.get(R[d]).displacementY = 0;
                    else {
                        for (var k = 0, tt = 0, d = 0; d < R.length; d++)
                            if (this.dummyToNodeForHorizontalAlignment.has(R[d])) {
                                var b = this.dummyToNodeForHorizontalAlignment.get(R[d]);
                                k += b.length * this.idToNodeMap.get(b[0]).displacementY, tt += b.length;
                            }
                            else
                                k += this.idToNodeMap.get(R[d]).displacementY, tt++;
                        for (var _ = k / tt, d = 0; d < R.length; d++)
                            this.dummyToNodeForHorizontalAlignment.has(R[d]) ? this.dummyToNodeForHorizontalAlignment.get(R[d]).forEach(function (Lt) { o.idToNodeMap.get(Lt).displacementY = _; }) : this.idToNodeMap.get(R[d]).displacementY = _;
                    }
                }
            } }, O.prototype.calculateNodesToApplyGravitationTo = function () { var o = [], m, v = this.graphManager.getGraphs(), T = v.length, d; for (d = 0; d < T; d++)
            m = v[d], m.updateConnected(), m.isConnected || (o = o.concat(m.getNodes())); return o; }, O.prototype.createBendpoints = function () { var o = []; o = o.concat(this.graphManager.getAllEdges()); var m = new Set, v; for (v = 0; v < o.length; v++) {
            var T = o[v];
            if (!m.has(T)) {
                var d = T.getSource(), x = T.getTarget();
                if (d == x)
                    T.getBendpoints().push(new y), T.getBendpoints().push(new y), this.createDummyNodesForBendpoints(T), m.add(T);
                else {
                    var D = [];
                    if (D = D.concat(d.getEdgeListToNode(x)), D = D.concat(x.getEdgeListToNode(d)), !m.has(D[0])) {
                        if (D.length > 1) {
                            var P;
                            for (P = 0; P < D.length; P++) {
                                var F = D[P];
                                F.getBendpoints().push(new y), this.createDummyNodesForBendpoints(F);
                            }
                        }
                        D.forEach(function (R) { m.add(R); });
                    }
                }
            }
            if (m.size == o.length)
                break;
        } }, O.prototype.positionNodesRadially = function (o) { for (var m = new p(0, 0), v = Math.ceil(Math.sqrt(o.length)), T = 0, d = 0, x = 0, D = new y(0, 0), P = 0; P < o.length; P++) {
            P % v == 0 && (x = 0, d = T, P != 0 && (d += l.DEFAULT_COMPONENT_SEPERATION), T = 0);
            var F = o[P], R = I.findCenterOfTree(F);
            m.x = x, m.y = d, D = O.radialLayout(F, R, m), D.y > T && (T = Math.floor(D.y)), x = Math.floor(D.x + l.DEFAULT_COMPONENT_SEPERATION);
        } this.transform(new y(w.WORLD_CENTER_X - D.x / 2, w.WORLD_CENTER_Y - D.y / 2)); }, O.radialLayout = function (o, m, v) { var T = Math.max(this.maxDiagonalInTree(o), l.DEFAULT_RADIAL_SEPARATION); O.branchRadialLayout(m, null, 0, 359, 0, T); var d = X.calculateBounds(o), x = new G; x.setDeviceOrgX(d.getMinX()), x.setDeviceOrgY(d.getMinY()), x.setWorldOrgX(v.x), x.setWorldOrgY(v.y); for (var D = 0; D < o.length; D++) {
            var P = o[D];
            P.transform(x);
        } var F = new y(d.getMaxX(), d.getMaxY()); return x.inverseTransformPoint(F); }, O.branchRadialLayout = function (o, m, v, T, d, x) { var D = (T - v + 1) / 2; D < 0 && (D += 180); var P = (D + v) % 360, F = P * S.TWO_PI / 360, R = Math.cos(F), k = d * Math.cos(F), tt = d * Math.sin(F); o.setCenter(k, tt); var b = []; b = b.concat(o.getEdges()); var _ = b.length; m != null && _--; for (var $ = 0, A = b.length, Y, W = o.getEdgesBetween(m); W.length > 1;) {
            var K = W[0];
            W.splice(0, 1);
            var st = b.indexOf(K);
            st >= 0 && b.splice(st, 1), A--, _--;
        } m != null ? Y = (b.indexOf(W[0]) + 1) % A : Y = 0; for (var Lt = Math.abs(T - v) / _, St = Y; $ != _; St = ++St % A) {
            var J = b[St].getOtherEnd(o);
            if (J != m) {
                var Ut = (v + $ * Lt) % 360, At = (Ut + Lt) % 360;
                O.branchRadialLayout(J, o, Ut, At, d + x, x), $++;
            }
        } }, O.maxDiagonalInTree = function (o) { for (var m = M.MIN_VALUE, v = 0; v < o.length; v++) {
            var T = o[v], d = T.getDiagonal();
            d > m && (m = d);
        } return m; }, O.prototype.calcRepulsionRange = function () { return 2 * (this.level + 1) * this.idealEdgeLength; }, O.prototype.groupZeroDegreeMembers = function () { var o = this, m = {}; this.memberGroups = {}, this.idToDummyNode = {}; for (var v = [], T = this.graphManager.getAllNodes(), d = 0; d < T.length; d++) {
            var x = T[d], D = x.getParent();
            this.getNodeDegreeWithChildren(x) === 0 && (D.id == null || !this.getToBeTiled(D)) && v.push(x);
        } for (var d = 0; d < v.length; d++) {
            var x = v[d], P = x.getParent().id;
            typeof m[P] > "u" && (m[P] = []), m[P] = m[P].concat(x);
        } Object.keys(m).forEach(function (F) { if (m[F].length > 1) {
            var R = "DummyCompound_" + F;
            o.memberGroups[R] = m[F];
            var k = m[F][0].getParent(), tt = new r(o.graphManager);
            tt.id = R, tt.paddingLeft = k.paddingLeft || 0, tt.paddingRight = k.paddingRight || 0, tt.paddingBottom = k.paddingBottom || 0, tt.paddingTop = k.paddingTop || 0, o.idToDummyNode[R] = tt;
            var b = o.getGraphManager().add(o.newGraph(), tt), _ = k.getChild();
            _.add(tt);
            for (var $ = 0; $ < m[F].length; $++) {
                var A = m[F][$];
                _.remove(A), b.add(A);
            }
        } }); }, O.prototype.clearCompounds = function () { var o = {}, m = {}; this.performDFSOnCompounds(); for (var v = 0; v < this.compoundOrder.length; v++)
            m[this.compoundOrder[v].id] = this.compoundOrder[v], o[this.compoundOrder[v].id] = [].concat(this.compoundOrder[v].getChild().getNodes()), this.graphManager.remove(this.compoundOrder[v].getChild()), this.compoundOrder[v].child = null; this.graphManager.resetAllNodes(), this.tileCompoundMembers(o, m); }, O.prototype.clearZeroDegreeMembers = function () { var o = this, m = this.tiledZeroDegreePack = []; Object.keys(this.memberGroups).forEach(function (v) { var T = o.idToDummyNode[v]; if (m[v] = o.tileNodes(o.memberGroups[v], T.paddingLeft + T.paddingRight), T.rect.width = m[v].width, T.rect.height = m[v].height, T.setCenter(m[v].centerX, m[v].centerY), T.labelMarginLeft = 0, T.labelMarginTop = 0, l.NODE_DIMENSIONS_INCLUDE_LABELS) {
            var d = T.rect.width, x = T.rect.height;
            T.labelWidth && (T.labelPosHorizontal == "left" ? (T.rect.x -= T.labelWidth, T.setWidth(d + T.labelWidth), T.labelMarginLeft = T.labelWidth) : T.labelPosHorizontal == "center" && T.labelWidth > d ? (T.rect.x -= (T.labelWidth - d) / 2, T.setWidth(T.labelWidth), T.labelMarginLeft = (T.labelWidth - d) / 2) : T.labelPosHorizontal == "right" && T.setWidth(d + T.labelWidth)), T.labelHeight && (T.labelPosVertical == "top" ? (T.rect.y -= T.labelHeight, T.setHeight(x + T.labelHeight), T.labelMarginTop = T.labelHeight) : T.labelPosVertical == "center" && T.labelHeight > x ? (T.rect.y -= (T.labelHeight - x) / 2, T.setHeight(T.labelHeight), T.labelMarginTop = (T.labelHeight - x) / 2) : T.labelPosVertical == "bottom" && T.setHeight(x + T.labelHeight));
        } }); }, O.prototype.repopulateCompounds = function () { for (var o = this.compoundOrder.length - 1; o >= 0; o--) {
            var m = this.compoundOrder[o], v = m.id, T = m.paddingLeft, d = m.paddingTop, x = m.labelMarginLeft, D = m.labelMarginTop;
            this.adjustLocations(this.tiledMemberPack[v], m.rect.x, m.rect.y, T, d, x, D);
        } }, O.prototype.repopulateZeroDegreeMembers = function () { var o = this, m = this.tiledZeroDegreePack; Object.keys(m).forEach(function (v) { var T = o.idToDummyNode[v], d = T.paddingLeft, x = T.paddingTop, D = T.labelMarginLeft, P = T.labelMarginTop; o.adjustLocations(m[v], T.rect.x, T.rect.y, d, x, D, P); }); }, O.prototype.getToBeTiled = function (o) { var m = o.id; if (this.toBeTiled[m] != null)
            return this.toBeTiled[m]; var v = o.getChild(); if (v == null)
            return this.toBeTiled[m] = !1, !1; for (var T = v.getNodes(), d = 0; d < T.length; d++) {
            var x = T[d];
            if (this.getNodeDegree(x) > 0)
                return this.toBeTiled[m] = !1, !1;
            if (x.getChild() == null) {
                this.toBeTiled[x.id] = !1;
                continue;
            }
            if (!this.getToBeTiled(x))
                return this.toBeTiled[m] = !1, !1;
        } return this.toBeTiled[m] = !0, !0; }, O.prototype.getNodeDegree = function (o) { for (var m = o.id, v = o.getEdges(), T = 0, d = 0; d < v.length; d++) {
            var x = v[d];
            x.getSource().id !== x.getTarget().id && (T = T + 1);
        } return T; }, O.prototype.getNodeDegreeWithChildren = function (o) { var m = this.getNodeDegree(o); if (o.getChild() == null)
            return m; for (var v = o.getChild().getNodes(), T = 0; T < v.length; T++) {
            var d = v[T];
            m += this.getNodeDegreeWithChildren(d);
        } return m; }, O.prototype.performDFSOnCompounds = function () { this.compoundOrder = [], this.fillCompexOrderByDFS(this.graphManager.getRoot().getNodes()); }, O.prototype.fillCompexOrderByDFS = function (o) { for (var m = 0; m < o.length; m++) {
            var v = o[m];
            v.getChild() != null && this.fillCompexOrderByDFS(v.getChild().getNodes()), this.getToBeTiled(v) && this.compoundOrder.push(v);
        } }, O.prototype.adjustLocations = function (o, m, v, T, d, x, D) { m += T + x, v += d + D; for (var P = m, F = 0; F < o.rows.length; F++) {
            var R = o.rows[F];
            m = P;
            for (var k = 0, tt = 0; tt < R.length; tt++) {
                var b = R[tt];
                b.rect.x = m, b.rect.y = v, m += b.rect.width + o.horizontalPadding, b.rect.height > k && (k = b.rect.height);
            }
            v += k + o.verticalPadding;
        } }, O.prototype.tileCompoundMembers = function (o, m) { var v = this; this.tiledMemberPack = [], Object.keys(o).forEach(function (T) { var d = m[T]; if (v.tiledMemberPack[T] = v.tileNodes(o[T], d.paddingLeft + d.paddingRight), d.rect.width = v.tiledMemberPack[T].width, d.rect.height = v.tiledMemberPack[T].height, d.setCenter(v.tiledMemberPack[T].centerX, v.tiledMemberPack[T].centerY), d.labelMarginLeft = 0, d.labelMarginTop = 0, l.NODE_DIMENSIONS_INCLUDE_LABELS) {
            var x = d.rect.width, D = d.rect.height;
            d.labelWidth && (d.labelPosHorizontal == "left" ? (d.rect.x -= d.labelWidth, d.setWidth(x + d.labelWidth), d.labelMarginLeft = d.labelWidth) : d.labelPosHorizontal == "center" && d.labelWidth > x ? (d.rect.x -= (d.labelWidth - x) / 2, d.setWidth(d.labelWidth), d.labelMarginLeft = (d.labelWidth - x) / 2) : d.labelPosHorizontal == "right" && d.setWidth(x + d.labelWidth)), d.labelHeight && (d.labelPosVertical == "top" ? (d.rect.y -= d.labelHeight, d.setHeight(D + d.labelHeight), d.labelMarginTop = d.labelHeight) : d.labelPosVertical == "center" && d.labelHeight > D ? (d.rect.y -= (d.labelHeight - D) / 2, d.setHeight(d.labelHeight), d.labelMarginTop = (d.labelHeight - D) / 2) : d.labelPosVertical == "bottom" && d.setHeight(D + d.labelHeight));
        } }); }, O.prototype.tileNodes = function (o, m) { var v = this.tileNodesByFavoringDim(o, m, !0), T = this.tileNodesByFavoringDim(o, m, !1), d = this.getOrgRatio(v), x = this.getOrgRatio(T), D; return x < d ? D = T : D = v, D; }, O.prototype.getOrgRatio = function (o) { var m = o.width, v = o.height, T = m / v; return T < 1 && (T = 1 / T), T; }, O.prototype.calcIdealRowWidth = function (o, m) { var v = l.TILING_PADDING_VERTICAL, T = l.TILING_PADDING_HORIZONTAL, d = o.length, x = 0, D = 0, P = 0; o.forEach(function ($) { x += $.getWidth(), D += $.getHeight(), $.getWidth() > P && (P = $.getWidth()); }); var F = x / d, R = D / d, k = Math.pow(v - T, 2) + 4 * (F + T) * (R + v) * d, tt = (T - v + Math.sqrt(k)) / (2 * (F + T)), b; m ? (b = Math.ceil(tt), b == tt && b++) : b = Math.floor(tt); var _ = b * (F + T) - T; return P > _ && (_ = P), _ += T * 2, _; }, O.prototype.tileNodesByFavoringDim = function (o, m, v) { var T = l.TILING_PADDING_VERTICAL, d = l.TILING_PADDING_HORIZONTAL, x = l.TILING_COMPARE_BY, D = { rows: [], rowWidth: [], rowHeight: [], width: 0, height: m, verticalPadding: T, horizontalPadding: d, centerX: 0, centerY: 0 }; x && (D.idealRowWidth = this.calcIdealRowWidth(o, v)); var P = function (A) { return A.rect.width * A.rect.height; }, F = function (A, Y) { return P(Y) - P(A); }; o.sort(function ($, A) { var Y = F; return D.idealRowWidth ? (Y = x, Y($.id, A.id)) : Y($, A); }); for (var R = 0, k = 0, tt = 0; tt < o.length; tt++) {
            var b = o[tt];
            R += b.getCenterX(), k += b.getCenterY();
        } D.centerX = R / o.length, D.centerY = k / o.length; for (var tt = 0; tt < o.length; tt++) {
            var b = o[tt];
            if (D.rows.length == 0)
                this.insertNodeToRow(D, b, 0, m);
            else if (this.canAddHorizontal(D, b.rect.width, b.rect.height)) {
                var _ = D.rows.length - 1;
                D.idealRowWidth || (_ = this.getShortestRowIndex(D)), this.insertNodeToRow(D, b, _, m);
            }
            else
                this.insertNodeToRow(D, b, D.rows.length, m);
            this.shiftToLastRow(D);
        } return D; }, O.prototype.insertNodeToRow = function (o, m, v, T) { var d = T; if (v == o.rows.length) {
            var x = [];
            o.rows.push(x), o.rowWidth.push(d), o.rowHeight.push(0);
        } var D = o.rowWidth[v] + m.rect.width; o.rows[v].length > 0 && (D += o.horizontalPadding), o.rowWidth[v] = D, o.width < D && (o.width = D); var P = m.rect.height; v > 0 && (P += o.verticalPadding); var F = 0; P > o.rowHeight[v] && (F = o.rowHeight[v], o.rowHeight[v] = P, F = o.rowHeight[v] - F), o.height += F, o.rows[v].push(m); }, O.prototype.getShortestRowIndex = function (o) { for (var m = -1, v = Number.MAX_VALUE, T = 0; T < o.rows.length; T++)
            o.rowWidth[T] < v && (m = T, v = o.rowWidth[T]); return m; }, O.prototype.getLongestRowIndex = function (o) { for (var m = -1, v = Number.MIN_VALUE, T = 0; T < o.rows.length; T++)
            o.rowWidth[T] > v && (m = T, v = o.rowWidth[T]); return m; }, O.prototype.canAddHorizontal = function (o, m, v) { if (o.idealRowWidth) {
            var T = o.rows.length - 1, d = o.rowWidth[T];
            return d + m + o.horizontalPadding <= o.idealRowWidth;
        } var x = this.getShortestRowIndex(o); if (x < 0)
            return !0; var D = o.rowWidth[x]; if (D + o.horizontalPadding + m <= o.width)
            return !0; var P = 0; o.rowHeight[x] < v && x > 0 && (P = v + o.verticalPadding - o.rowHeight[x]); var F; o.width - D >= m + o.horizontalPadding ? F = (o.height + P) / (D + m + o.horizontalPadding) : F = (o.height + P) / o.width, P = v + o.verticalPadding; var R; return o.width < m ? R = (o.height + P) / m : R = (o.height + P) / o.width, R < 1 && (R = 1 / R), F < 1 && (F = 1 / F), F < R; }, O.prototype.shiftToLastRow = function (o) { var m = this.getLongestRowIndex(o), v = o.rowWidth.length - 1, T = o.rows[m], d = T[T.length - 1], x = d.width + o.horizontalPadding; if (o.width - o.rowWidth[v] > x && m != v) {
            T.splice(-1, 1), o.rows[v].push(d), o.rowWidth[m] = o.rowWidth[m] - x, o.rowWidth[v] = o.rowWidth[v] + x, o.width = o.rowWidth[instance.getLongestRowIndex(o)];
            for (var D = Number.MIN_VALUE, P = 0; P < T.length; P++)
                T[P].height > D && (D = T[P].height);
            m > 0 && (D += o.verticalPadding);
            var F = o.rowHeight[m] + o.rowHeight[v];
            o.rowHeight[m] = D, o.rowHeight[v] < d.height + o.verticalPadding && (o.rowHeight[v] = d.height + o.verticalPadding);
            var R = o.rowHeight[m] + o.rowHeight[v];
            o.height += R - F, this.shiftToLastRow(o);
        } }, O.prototype.tilingPreLayout = function () { l.TILE && (this.groupZeroDegreeMembers(), this.clearCompounds(), this.clearZeroDegreeMembers()); }, O.prototype.tilingPostLayout = function () { l.TILE && (this.repopulateZeroDegreeMembers(), this.repopulateCompounds()); }, O.prototype.reduceTrees = function () { for (var o = [], m = !0, v; m;) {
            var T = this.graphManager.getAllNodes(), d = [];
            m = !1;
            for (var x = 0; x < T.length; x++)
                if (v = T[x], v.getEdges().length == 1 && !v.getEdges()[0].isInterGraph && v.getChild() == null) {
                    if (l.PURE_INCREMENTAL) {
                        var D = v.getEdges()[0].getOtherEnd(v), P = new L(v.getCenterX() - D.getCenterX(), v.getCenterY() - D.getCenterY());
                        d.push([v, v.getEdges()[0], v.getOwner(), P]);
                    }
                    else
                        d.push([v, v.getEdges()[0], v.getOwner()]);
                    m = !0;
                }
            if (m == !0) {
                for (var F = [], R = 0; R < d.length; R++)
                    d[R][0].getEdges().length == 1 && (F.push(d[R]), d[R][0].getOwner().remove(d[R][0]));
                o.push(F), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges();
            }
        } this.prunedNodesAll = o; }, O.prototype.growTree = function (o) { for (var m = o.length, v = o[m - 1], T, d = 0; d < v.length; d++)
            T = v[d], this.findPlaceforPrunedNode(T), T[2].add(T[0]), T[2].add(T[1], T[1].source, T[1].target); o.splice(o.length - 1, 1), this.graphManager.resetAllNodes(), this.graphManager.resetAllEdges(); }, O.prototype.findPlaceforPrunedNode = function (o) { var m, v, T = o[0]; if (T == o[1].source ? v = o[1].target : v = o[1].source, l.PURE_INCREMENTAL)
            T.setCenter(v.getCenterX() + o[3].getWidth(), v.getCenterY() + o[3].getHeight());
        else {
            var d = v.startX, x = v.finishX, D = v.startY, P = v.finishY, F = 0, R = 0, k = 0, tt = 0, b = [F, k, R, tt];
            if (D > 0)
                for (var _ = d; _ <= x; _++)
                    b[0] += this.grid[_][D - 1].length + this.grid[_][D].length - 1;
            if (x < this.grid.length - 1)
                for (var _ = D; _ <= P; _++)
                    b[1] += this.grid[x + 1][_].length + this.grid[x][_].length - 1;
            if (P < this.grid[0].length - 1)
                for (var _ = d; _ <= x; _++)
                    b[2] += this.grid[_][P + 1].length + this.grid[_][P].length - 1;
            if (d > 0)
                for (var _ = D; _ <= P; _++)
                    b[3] += this.grid[d - 1][_].length + this.grid[d][_].length - 1;
            for (var $ = M.MAX_VALUE, A, Y, W = 0; W < b.length; W++)
                b[W] < $ ? ($ = b[W], A = 1, Y = W) : b[W] == $ && A++;
            if (A == 3 && $ == 0)
                b[0] == 0 && b[1] == 0 && b[2] == 0 ? m = 1 : b[0] == 0 && b[1] == 0 && b[3] == 0 ? m = 0 : b[0] == 0 && b[2] == 0 && b[3] == 0 ? m = 3 : b[1] == 0 && b[2] == 0 && b[3] == 0 && (m = 2);
            else if (A == 2 && $ == 0) {
                var K = Math.floor(Math.random() * 2);
                b[0] == 0 && b[1] == 0 ? K == 0 ? m = 0 : m = 1 : b[0] == 0 && b[2] == 0 ? K == 0 ? m = 0 : m = 2 : b[0] == 0 && b[3] == 0 ? K == 0 ? m = 0 : m = 3 : b[1] == 0 && b[2] == 0 ? K == 0 ? m = 1 : m = 2 : b[1] == 0 && b[3] == 0 ? K == 0 ? m = 1 : m = 3 : K == 0 ? m = 2 : m = 3;
            }
            else if (A == 4 && $ == 0) {
                var K = Math.floor(Math.random() * 4);
                m = K;
            }
            else
                m = Y;
            m == 0 ? T.setCenter(v.getCenterX(), v.getCenterY() - v.getHeight() / 2 - h.DEFAULT_EDGE_LENGTH - T.getHeight() / 2) : m == 1 ? T.setCenter(v.getCenterX() + v.getWidth() / 2 + h.DEFAULT_EDGE_LENGTH + T.getWidth() / 2, v.getCenterY()) : m == 2 ? T.setCenter(v.getCenterX(), v.getCenterY() + v.getHeight() / 2 + h.DEFAULT_EDGE_LENGTH + T.getHeight() / 2) : T.setCenter(v.getCenterX() - v.getWidth() / 2 - h.DEFAULT_EDGE_LENGTH - T.getWidth() / 2, v.getCenterY());
        } }, a.exports = O; }), 991: ((a, i, n) => { var f = n(551).FDLayoutNode, e = n(551).IMath; function u(t, l, c, h) { f.call(this, t, l, c, h); } u.prototype = Object.create(f.prototype); for (var r in f)
            u[r] = f[r]; u.prototype.calculateDisplacement = function () { var t = this.graphManager.getLayout(); this.getChild() != null && this.fixedNodeWeight ? (this.displacementX += t.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.fixedNodeWeight, this.displacementY += t.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.fixedNodeWeight) : (this.displacementX += t.coolingFactor * (this.springForceX + this.repulsionForceX + this.gravitationForceX) / this.noOfChildren, this.displacementY += t.coolingFactor * (this.springForceY + this.repulsionForceY + this.gravitationForceY) / this.noOfChildren), Math.abs(this.displacementX) > t.coolingFactor * t.maxNodeDisplacement && (this.displacementX = t.coolingFactor * t.maxNodeDisplacement * e.sign(this.displacementX)), Math.abs(this.displacementY) > t.coolingFactor * t.maxNodeDisplacement && (this.displacementY = t.coolingFactor * t.maxNodeDisplacement * e.sign(this.displacementY)), this.child && this.child.getNodes().length > 0 && this.propogateDisplacementToChildren(this.displacementX, this.displacementY); }, u.prototype.propogateDisplacementToChildren = function (t, l) { for (var c = this.getChild().getNodes(), h, w = 0; w < c.length; w++)
            h = c[w], h.getChild() == null ? (h.displacementX += t, h.displacementY += l) : h.propogateDisplacementToChildren(t, l); }, u.prototype.move = function () { var t = this.graphManager.getLayout(); (this.child == null || this.child.getNodes().length == 0) && (this.moveBy(this.displacementX, this.displacementY), t.totalDisplacement += Math.abs(this.displacementX) + Math.abs(this.displacementY)), this.springForceX = 0, this.springForceY = 0, this.repulsionForceX = 0, this.repulsionForceY = 0, this.gravitationForceX = 0, this.gravitationForceY = 0, this.displacementX = 0, this.displacementY = 0; }, u.prototype.setPred1 = function (t) { this.pred1 = t; }, u.prototype.getPred1 = function () { return pred1; }, u.prototype.getPred2 = function () { return pred2; }, u.prototype.setNext = function (t) { this.next = t; }, u.prototype.getNext = function () { return next; }, u.prototype.setProcessed = function (t) { this.processed = t; }, u.prototype.isProcessed = function () { return processed; }, a.exports = u; }), 902: ((a, i, n) => { function f(c) { if (Array.isArray(c)) {
            for (var h = 0, w = Array(c.length); h < c.length; h++)
                w[h] = c[h];
            return w;
        }
        else
            return Array.from(c); } var e = n(806), u = n(551).LinkedList, r = n(551).Matrix, t = n(551).SVD; function l() { } l.handleConstraints = function (c) { var h = {}; h.fixedNodeConstraint = c.constraints.fixedNodeConstraint, h.alignmentConstraint = c.constraints.alignmentConstraint, h.relativePlacementConstraint = c.constraints.relativePlacementConstraint; for (var w = new Map, p = new Map, y = [], L = [], I = c.getAllNodes(), M = 0, S = 0; S < I.length; S++) {
            var X = I[S];
            X.getChild() == null && (p.set(X.id, M++), y.push(X.getCenterX()), L.push(X.getCenterY()), w.set(X.id, X));
        } h.relativePlacementConstraint && h.relativePlacementConstraint.forEach(function (U) { !U.gap && U.gap != 0 && (U.left ? U.gap = e.DEFAULT_EDGE_LENGTH + w.get(U.left).getWidth() / 2 + w.get(U.right).getWidth() / 2 : U.gap = e.DEFAULT_EDGE_LENGTH + w.get(U.top).getHeight() / 2 + w.get(U.bottom).getHeight() / 2); }); var G = function (V, z) { return { x: V.x - z.x, y: V.y - z.y }; }, Q = function (V) { var z = 0, B = 0; return V.forEach(function (Z) { z += y[p.get(Z)], B += L[p.get(Z)]; }), { x: z / V.size, y: B / V.size }; }, O = function (V, z, B, Z, j) { function ut(ot, it) { var dt = new Set(ot), nt = !0, lt = !1, Ft = void 0; try {
            for (var xt = it[Symbol.iterator](), Vt; !(nt = (Vt = xt.next()).done); nt = !0) {
                var Ot = Vt.value;
                dt.add(Ot);
            }
        }
        catch (Nt) {
            lt = !0, Ft = Nt;
        }
        finally {
            try {
                !nt && xt.return && xt.return();
            }
            finally {
                if (lt)
                    throw Ft;
            }
        } return dt; } var ct = new Map; V.forEach(function (ot, it) { ct.set(it, 0); }), V.forEach(function (ot, it) { ot.forEach(function (dt) { ct.set(dt.id, ct.get(dt.id) + 1); }); }); var q = new Map, ht = new Map, gt = new u; ct.forEach(function (ot, it) { ot == 0 ? (gt.push(it), B || (z == "horizontal" ? q.set(it, p.has(it) ? y[p.get(it)] : Z.get(it)) : q.set(it, p.has(it) ? L[p.get(it)] : Z.get(it)))) : q.set(it, Number.NEGATIVE_INFINITY), B && ht.set(it, new Set([it])); }), B && j.forEach(function (ot) { var it = []; if (ot.forEach(function (lt) { B.has(lt) && it.push(lt); }), it.length > 0) {
            var dt = 0;
            it.forEach(function (lt) { z == "horizontal" ? (q.set(lt, p.has(lt) ? y[p.get(lt)] : Z.get(lt)), dt += q.get(lt)) : (q.set(lt, p.has(lt) ? L[p.get(lt)] : Z.get(lt)), dt += q.get(lt)); }), dt = dt / it.length, ot.forEach(function (lt) { B.has(lt) || q.set(lt, dt); });
        }
        else {
            var nt = 0;
            ot.forEach(function (lt) { z == "horizontal" ? nt += p.has(lt) ? y[p.get(lt)] : Z.get(lt) : nt += p.has(lt) ? L[p.get(lt)] : Z.get(lt); }), nt = nt / ot.length, ot.forEach(function (lt) { q.set(lt, nt); });
        } }); for (var rt = function () { var it = gt.shift(), dt = V.get(it); dt.forEach(function (nt) { if (q.get(nt.id) < q.get(it) + nt.gap)
            if (B && B.has(nt.id)) {
                var lt = void 0;
                if (z == "horizontal" ? lt = p.has(nt.id) ? y[p.get(nt.id)] : Z.get(nt.id) : lt = p.has(nt.id) ? L[p.get(nt.id)] : Z.get(nt.id), q.set(nt.id, lt), lt < q.get(it) + nt.gap) {
                    var Ft = q.get(it) + nt.gap - lt;
                    ht.get(it).forEach(function (xt) { q.set(xt, q.get(xt) - Ft); });
                }
            }
            else
                q.set(nt.id, q.get(it) + nt.gap); ct.set(nt.id, ct.get(nt.id) - 1), ct.get(nt.id) == 0 && gt.push(nt.id), B && ht.set(nt.id, ut(ht.get(it), ht.get(nt.id))); }); }; gt.length != 0;)
            rt(); if (B) {
            var vt = new Set;
            V.forEach(function (ot, it) { ot.length == 0 && vt.add(it); });
            var Mt = [];
            ht.forEach(function (ot, it) { if (vt.has(it)) {
                var dt = !1, nt = !0, lt = !1, Ft = void 0;
                try {
                    for (var xt = ot[Symbol.iterator](), Vt; !(nt = (Vt = xt.next()).done); nt = !0) {
                        var Ot = Vt.value;
                        B.has(Ot) && (dt = !0);
                    }
                }
                catch (Rt) {
                    lt = !0, Ft = Rt;
                }
                finally {
                    try {
                        !nt && xt.return && xt.return();
                    }
                    finally {
                        if (lt)
                            throw Ft;
                    }
                }
                if (!dt) {
                    var Nt = !1, Bt = void 0;
                    Mt.forEach(function (Rt, Xt) { Rt.has([].concat(f(ot))[0]) && (Nt = !0, Bt = Xt); }), Nt ? ot.forEach(function (Rt) { Mt[Bt].add(Rt); }) : Mt.push(new Set(ot));
                }
            } }), Mt.forEach(function (ot, it) { var dt = Number.POSITIVE_INFINITY, nt = Number.POSITIVE_INFINITY, lt = Number.NEGATIVE_INFINITY, Ft = Number.NEGATIVE_INFINITY, xt = !0, Vt = !1, Ot = void 0; try {
                for (var Nt = ot[Symbol.iterator](), Bt; !(xt = (Bt = Nt.next()).done); xt = !0) {
                    var Rt = Bt.value, Xt = void 0;
                    z == "horizontal" ? Xt = p.has(Rt) ? y[p.get(Rt)] : Z.get(Rt) : Xt = p.has(Rt) ? L[p.get(Rt)] : Z.get(Rt);
                    var zt = q.get(Rt);
                    Xt < dt && (dt = Xt), Xt > lt && (lt = Xt), zt < nt && (nt = zt), zt > Ft && (Ft = zt);
                }
            }
            catch (te) {
                Vt = !0, Ot = te;
            }
            finally {
                try {
                    !xt && Nt.return && Nt.return();
                }
                finally {
                    if (Vt)
                        throw Ot;
                }
            } var ue = (dt + lt) / 2 - (nt + Ft) / 2, Qt = !0, Kt = !1, jt = void 0; try {
                for (var Jt = ot[Symbol.iterator](), he; !(Qt = (he = Jt.next()).done); Qt = !0) {
                    var _t = he.value;
                    q.set(_t, q.get(_t) + ue);
                }
            }
            catch (te) {
                Kt = !0, jt = te;
            }
            finally {
                try {
                    !Qt && Jt.return && Jt.return();
                }
                finally {
                    if (Kt)
                        throw jt;
                }
            } });
        } return q; }, H = function (V) { var z = 0, B = 0, Z = 0, j = 0; if (V.forEach(function (ht) { ht.left ? y[p.get(ht.left)] - y[p.get(ht.right)] >= 0 ? z++ : B++ : L[p.get(ht.top)] - L[p.get(ht.bottom)] >= 0 ? Z++ : j++; }), z > B && Z > j)
            for (var ut = 0; ut < p.size; ut++)
                y[ut] = -1 * y[ut], L[ut] = -1 * L[ut];
        else if (z > B)
            for (var ct = 0; ct < p.size; ct++)
                y[ct] = -1 * y[ct];
        else if (Z > j)
            for (var q = 0; q < p.size; q++)
                L[q] = -1 * L[q]; }, o = function (V) { var z = [], B = new u, Z = new Set, j = 0; return V.forEach(function (ut, ct) { if (!Z.has(ct)) {
            z[j] = [];
            var q = ct;
            for (B.push(q), Z.add(q), z[j].push(q); B.length != 0;) {
                q = B.shift();
                var ht = V.get(q);
                ht.forEach(function (gt) { Z.has(gt.id) || (B.push(gt.id), Z.add(gt.id), z[j].push(gt.id)); });
            }
            j++;
        } }), z; }, m = function (V) { var z = new Map; return V.forEach(function (B, Z) { z.set(Z, []); }), V.forEach(function (B, Z) { B.forEach(function (j) { z.get(Z).push(j), z.get(j.id).push({ id: Z, gap: j.gap, direction: j.direction }); }); }), z; }, v = function (V) { var z = new Map; return V.forEach(function (B, Z) { z.set(Z, []); }), V.forEach(function (B, Z) { B.forEach(function (j) { z.get(j.id).push({ id: Z, gap: j.gap, direction: j.direction }); }); }), z; }, T = [], d = [], x = !1, D = !1, P = new Set, F = new Map, R = new Map, k = []; if (h.fixedNodeConstraint && h.fixedNodeConstraint.forEach(function (U) { P.add(U.nodeId); }), h.relativePlacementConstraint && (h.relativePlacementConstraint.forEach(function (U) { U.left ? (F.has(U.left) ? F.get(U.left).push({ id: U.right, gap: U.gap, direction: "horizontal" }) : F.set(U.left, [{ id: U.right, gap: U.gap, direction: "horizontal" }]), F.has(U.right) || F.set(U.right, [])) : (F.has(U.top) ? F.get(U.top).push({ id: U.bottom, gap: U.gap, direction: "vertical" }) : F.set(U.top, [{ id: U.bottom, gap: U.gap, direction: "vertical" }]), F.has(U.bottom) || F.set(U.bottom, [])); }), R = m(F), k = o(R)), e.TRANSFORM_ON_CONSTRAINT_HANDLING) {
            if (h.fixedNodeConstraint && h.fixedNodeConstraint.length > 1)
                h.fixedNodeConstraint.forEach(function (U, V) { T[V] = [U.position.x, U.position.y], d[V] = [y[p.get(U.nodeId)], L[p.get(U.nodeId)]]; }), x = !0;
            else if (h.alignmentConstraint)
                (function () { var U = 0; if (h.alignmentConstraint.vertical) {
                    for (var V = h.alignmentConstraint.vertical, z = function (q) { var ht = new Set; V[q].forEach(function (vt) { ht.add(vt); }); var gt = new Set([].concat(f(ht)).filter(function (vt) { return P.has(vt); })), rt = void 0; gt.size > 0 ? rt = y[p.get(gt.values().next().value)] : rt = Q(ht).x, V[q].forEach(function (vt) { T[U] = [rt, L[p.get(vt)]], d[U] = [y[p.get(vt)], L[p.get(vt)]], U++; }); }, B = 0; B < V.length; B++)
                        z(B);
                    x = !0;
                } if (h.alignmentConstraint.horizontal) {
                    for (var Z = h.alignmentConstraint.horizontal, j = function (q) { var ht = new Set; Z[q].forEach(function (vt) { ht.add(vt); }); var gt = new Set([].concat(f(ht)).filter(function (vt) { return P.has(vt); })), rt = void 0; gt.size > 0 ? rt = y[p.get(gt.values().next().value)] : rt = Q(ht).y, Z[q].forEach(function (vt) { T[U] = [y[p.get(vt)], rt], d[U] = [y[p.get(vt)], L[p.get(vt)]], U++; }); }, ut = 0; ut < Z.length; ut++)
                        j(ut);
                    x = !0;
                } h.relativePlacementConstraint && (D = !0); })();
            else if (h.relativePlacementConstraint) {
                for (var tt = 0, b = 0, _ = 0; _ < k.length; _++)
                    k[_].length > tt && (tt = k[_].length, b = _);
                if (tt < R.size / 2)
                    H(h.relativePlacementConstraint), x = !1, D = !1;
                else {
                    var $ = new Map, A = new Map, Y = [];
                    k[b].forEach(function (U) { F.get(U).forEach(function (V) { V.direction == "horizontal" ? ($.has(U) ? $.get(U).push(V) : $.set(U, [V]), $.has(V.id) || $.set(V.id, []), Y.push({ left: U, right: V.id })) : (A.has(U) ? A.get(U).push(V) : A.set(U, [V]), A.has(V.id) || A.set(V.id, []), Y.push({ top: U, bottom: V.id })); }); }), H(Y), D = !1;
                    var W = O($, "horizontal"), K = O(A, "vertical");
                    k[b].forEach(function (U, V) { d[V] = [y[p.get(U)], L[p.get(U)]], T[V] = [], W.has(U) ? T[V][0] = W.get(U) : T[V][0] = y[p.get(U)], K.has(U) ? T[V][1] = K.get(U) : T[V][1] = L[p.get(U)]; }), x = !0;
                }
            }
            if (x) {
                for (var st = void 0, Lt = r.transpose(T), St = r.transpose(d), J = 0; J < Lt.length; J++)
                    Lt[J] = r.multGamma(Lt[J]), St[J] = r.multGamma(St[J]);
                var Ut = r.multMat(Lt, r.transpose(St)), At = t.svd(Ut);
                st = r.multMat(At.V, r.transpose(At.U));
                for (var at = 0; at < p.size; at++) {
                    var et = [y[at], L[at]], pt = [st[0][0], st[1][0]], mt = [st[0][1], st[1][1]];
                    y[at] = r.dotProduct(et, pt), L[at] = r.dotProduct(et, mt);
                }
                D && H(h.relativePlacementConstraint);
            }
        } if (e.ENFORCE_CONSTRAINTS) {
            if (h.fixedNodeConstraint && h.fixedNodeConstraint.length > 0) {
                var wt = { x: 0, y: 0 };
                h.fixedNodeConstraint.forEach(function (U, V) { var z = { x: y[p.get(U.nodeId)], y: L[p.get(U.nodeId)] }, B = U.position, Z = G(B, z); wt.x += Z.x, wt.y += Z.y; }), wt.x /= h.fixedNodeConstraint.length, wt.y /= h.fixedNodeConstraint.length, y.forEach(function (U, V) { y[V] += wt.x; }), L.forEach(function (U, V) { L[V] += wt.y; }), h.fixedNodeConstraint.forEach(function (U) { y[p.get(U.nodeId)] = U.position.x, L[p.get(U.nodeId)] = U.position.y; });
            }
            if (h.alignmentConstraint) {
                if (h.alignmentConstraint.vertical)
                    for (var Et = h.alignmentConstraint.vertical, Tt = function (V) { var z = new Set; Et[V].forEach(function (j) { z.add(j); }); var B = new Set([].concat(f(z)).filter(function (j) { return P.has(j); })), Z = void 0; B.size > 0 ? Z = y[p.get(B.values().next().value)] : Z = Q(z).x, z.forEach(function (j) { P.has(j) || (y[p.get(j)] = Z); }); }, Dt = 0; Dt < Et.length; Dt++)
                        Tt(Dt);
                if (h.alignmentConstraint.horizontal)
                    for (var It = h.alignmentConstraint.horizontal, Wt = function (V) { var z = new Set; It[V].forEach(function (j) { z.add(j); }); var B = new Set([].concat(f(z)).filter(function (j) { return P.has(j); })), Z = void 0; B.size > 0 ? Z = L[p.get(B.values().next().value)] : Z = Q(z).y, z.forEach(function (j) { P.has(j) || (L[p.get(j)] = Z); }); }, Pt = 0; Pt < It.length; Pt++)
                        Wt(Pt);
            }
            h.relativePlacementConstraint && (function () { var U = new Map, V = new Map, z = new Map, B = new Map, Z = new Map, j = new Map, ut = new Set, ct = new Set; if (P.forEach(function (Gt) { ut.add(Gt), ct.add(Gt); }), h.alignmentConstraint) {
                if (h.alignmentConstraint.vertical)
                    for (var q = h.alignmentConstraint.vertical, ht = function (yt) { z.set("dummy" + yt, []), q[yt].forEach(function (Ct) { U.set(Ct, "dummy" + yt), z.get("dummy" + yt).push(Ct), P.has(Ct) && ut.add("dummy" + yt); }), Z.set("dummy" + yt, y[p.get(q[yt][0])]); }, gt = 0; gt < q.length; gt++)
                        ht(gt);
                if (h.alignmentConstraint.horizontal)
                    for (var rt = h.alignmentConstraint.horizontal, vt = function (yt) { B.set("dummy" + yt, []), rt[yt].forEach(function (Ct) { V.set(Ct, "dummy" + yt), B.get("dummy" + yt).push(Ct), P.has(Ct) && ct.add("dummy" + yt); }), j.set("dummy" + yt, L[p.get(rt[yt][0])]); }, Mt = 0; Mt < rt.length; Mt++)
                        vt(Mt);
            } var ot = new Map, it = new Map, dt = function (yt) { F.get(yt).forEach(function (Ct) { var Zt = void 0, $t = void 0; Ct.direction == "horizontal" ? (Zt = U.get(yt) ? U.get(yt) : yt, U.get(Ct.id) ? $t = { id: U.get(Ct.id), gap: Ct.gap, direction: Ct.direction } : $t = Ct, ot.has(Zt) ? ot.get(Zt).push($t) : ot.set(Zt, [$t]), ot.has($t.id) || ot.set($t.id, [])) : (Zt = V.get(yt) ? V.get(yt) : yt, V.get(Ct.id) ? $t = { id: V.get(Ct.id), gap: Ct.gap, direction: Ct.direction } : $t = Ct, it.has(Zt) ? it.get(Zt).push($t) : it.set(Zt, [$t]), it.has($t.id) || it.set($t.id, [])); }); }, nt = !0, lt = !1, Ft = void 0; try {
                for (var xt = F.keys()[Symbol.iterator](), Vt; !(nt = (Vt = xt.next()).done); nt = !0) {
                    var Ot = Vt.value;
                    dt(Ot);
                }
            }
            catch (Gt) {
                lt = !0, Ft = Gt;
            }
            finally {
                try {
                    !nt && xt.return && xt.return();
                }
                finally {
                    if (lt)
                        throw Ft;
                }
            } var Nt = m(ot), Bt = m(it), Rt = o(Nt), Xt = o(Bt), zt = v(ot), ue = v(it), Qt = [], Kt = []; Rt.forEach(function (Gt, yt) { Qt[yt] = [], Gt.forEach(function (Ct) { zt.get(Ct).length == 0 && Qt[yt].push(Ct); }); }), Xt.forEach(function (Gt, yt) { Kt[yt] = [], Gt.forEach(function (Ct) { ue.get(Ct).length == 0 && Kt[yt].push(Ct); }); }); var jt = O(ot, "horizontal", ut, Z, Qt), Jt = O(it, "vertical", ct, j, Kt), he = function (yt) { z.get(yt) ? z.get(yt).forEach(function (Ct) { y[p.get(Ct)] = jt.get(yt); }) : y[p.get(yt)] = jt.get(yt); }, _t = !0, te = !1, Ie = void 0; try {
                for (var de = jt.keys()[Symbol.iterator](), Re; !(_t = (Re = de.next()).done); _t = !0) {
                    var ve = Re.value;
                    he(ve);
                }
            }
            catch (Gt) {
                te = !0, Ie = Gt;
            }
            finally {
                try {
                    !_t && de.return && de.return();
                }
                finally {
                    if (te)
                        throw Ie;
                }
            } var yr = function (yt) { B.get(yt) ? B.get(yt).forEach(function (Ct) { L[p.get(Ct)] = Jt.get(yt); }) : L[p.get(yt)] = Jt.get(yt); }, pe = !0, Se = !1, Fe = void 0; try {
                for (var ye = Jt.keys()[Symbol.iterator](), be; !(pe = (be = ye.next()).done); pe = !0) {
                    var ve = be.value;
                    yr(ve);
                }
            }
            catch (Gt) {
                Se = !0, Fe = Gt;
            }
            finally {
                try {
                    !pe && ye.return && ye.return();
                }
                finally {
                    if (Se)
                        throw Fe;
                }
            } })();
        } for (var Yt = 0; Yt < I.length; Yt++) {
            var bt = I[Yt];
            bt.getChild() == null && bt.setCenter(y[p.get(bt.id)], L[p.get(bt.id)]);
        } }, a.exports = l; }), 551: (a => { a.exports = E; }) }, N = {};
    function g(a) { var i = N[a]; if (i !== void 0)
        return i.exports; var n = N[a] = { exports: {} }; return C[a](n, n.exports, g), n.exports; }
    var s = g(45);
    return s;
})(); }); });
var tr = Ee((oe, Ae) => { (function (C, N) { typeof oe == "object" && typeof Ae == "object" ? Ae.exports = N(Ce()) : typeof define == "function" && define.amd ? define(["cose-base"], N) : typeof oe == "object" ? oe.cytoscapeFcose = N(Ce()) : C.cytoscapeFcose = N(C.coseBase); })(oe, function (E) { return (() => {
    "use strict";
    var C = { 658: (a => { a.exports = Object.assign != null ? Object.assign.bind(Object) : function (i) { for (var n = arguments.length, f = Array(n > 1 ? n - 1 : 0), e = 1; e < n; e++)
            f[e - 1] = arguments[e]; return f.forEach(function (u) { Object.keys(u).forEach(function (r) { return i[r] = u[r]; }); }), i; }; }), 548: ((a, i, n) => { var f = (function () { function r(t, l) { var c = [], h = !0, w = !1, p = void 0; try {
            for (var y = t[Symbol.iterator](), L; !(h = (L = y.next()).done) && (c.push(L.value), !(l && c.length === l)); h = !0)
                ;
        }
        catch (I) {
            w = !0, p = I;
        }
        finally {
            try {
                !h && y.return && y.return();
            }
            finally {
                if (w)
                    throw p;
            }
        } return c; } return function (t, l) { if (Array.isArray(t))
            return t; if (Symbol.iterator in Object(t))
            return r(t, l); throw new TypeError("Invalid attempt to destructure non-iterable instance"); }; })(), e = n(140).layoutBase.LinkedList, u = {}; u.getTopMostNodes = function (r) { for (var t = {}, l = 0; l < r.length; l++)
            t[r[l].id()] = !0; var c = r.filter(function (h, w) { typeof h == "number" && (h = w); for (var p = h.parent()[0]; p != null;) {
            if (t[p.id()])
                return !1;
            p = p.parent()[0];
        } return !0; }); return c; }, u.connectComponents = function (r, t, l, c) { var h = new e, w = new Set, p = [], y = void 0, L = void 0, I = void 0, M = !1, S = 1, X = [], G = [], Q = function () { var H = r.collection(); G.push(H); var o = l[0], m = r.collection(); m.merge(o).merge(o.descendants().intersection(t)), p.push(o), m.forEach(function (d) { h.push(d), w.add(d), H.merge(d); }); for (var v = function () { o = h.shift(); var x = r.collection(); o.neighborhood().nodes().forEach(function (R) { t.intersection(o.edgesWith(R)).length > 0 && x.merge(R); }); for (var D = 0; D < x.length; D++) {
            var P = x[D];
            if (y = l.intersection(P.union(P.ancestors())), y != null && !w.has(y[0])) {
                var F = y.union(y.descendants());
                F.forEach(function (R) { h.push(R), w.add(R), H.merge(R), l.has(R) && p.push(R); });
            }
        } }; h.length != 0;)
            v(); if (H.forEach(function (d) { t.intersection(d.connectedEdges()).forEach(function (x) { H.has(x.source()) && H.has(x.target()) && H.merge(x); }); }), p.length == l.length && (M = !0), !M || M && S > 1) {
            L = p[0], I = L.connectedEdges().length, p.forEach(function (d) { d.connectedEdges().length < I && (I = d.connectedEdges().length, L = d); }), X.push(L.id());
            var T = r.collection();
            T.merge(p[0]), p.forEach(function (d) { T.merge(d); }), p = [], l = l.difference(T), S++;
        } }; do
            Q();
        while (!M); return c && X.length > 0 && c.set("dummy" + (c.size + 1), X), G; }, u.relocateComponent = function (r, t, l) { if (!l.fixedNodeConstraint) {
            var c = Number.POSITIVE_INFINITY, h = Number.NEGATIVE_INFINITY, w = Number.POSITIVE_INFINITY, p = Number.NEGATIVE_INFINITY;
            if (l.quality == "draft") {
                var y = !0, L = !1, I = void 0;
                try {
                    for (var M = t.nodeIndexes[Symbol.iterator](), S; !(y = (S = M.next()).done); y = !0) {
                        var X = S.value, G = f(X, 2), Q = G[0], O = G[1], H = l.cy.getElementById(Q);
                        if (H) {
                            var o = H.boundingBox(), m = t.xCoords[O] - o.w / 2, v = t.xCoords[O] + o.w / 2, T = t.yCoords[O] - o.h / 2, d = t.yCoords[O] + o.h / 2;
                            m < c && (c = m), v > h && (h = v), T < w && (w = T), d > p && (p = d);
                        }
                    }
                }
                catch (R) {
                    L = !0, I = R;
                }
                finally {
                    try {
                        !y && M.return && M.return();
                    }
                    finally {
                        if (L)
                            throw I;
                    }
                }
                var x = r.x - (h + c) / 2, D = r.y - (p + w) / 2;
                t.xCoords = t.xCoords.map(function (R) { return R + x; }), t.yCoords = t.yCoords.map(function (R) { return R + D; });
            }
            else {
                Object.keys(t).forEach(function (R) { var k = t[R], tt = k.getRect().x, b = k.getRect().x + k.getRect().width, _ = k.getRect().y, $ = k.getRect().y + k.getRect().height; tt < c && (c = tt), b > h && (h = b), _ < w && (w = _), $ > p && (p = $); });
                var P = r.x - (h + c) / 2, F = r.y - (p + w) / 2;
                Object.keys(t).forEach(function (R) { var k = t[R]; k.setCenter(k.getCenterX() + P, k.getCenterY() + F); });
            }
        } }, u.calcBoundingBox = function (r, t, l, c) { for (var h = Number.MAX_SAFE_INTEGER, w = Number.MIN_SAFE_INTEGER, p = Number.MAX_SAFE_INTEGER, y = Number.MIN_SAFE_INTEGER, L = void 0, I = void 0, M = void 0, S = void 0, X = r.descendants().not(":parent"), G = X.length, Q = 0; Q < G; Q++) {
            var O = X[Q];
            L = t[c.get(O.id())] - O.width() / 2, I = t[c.get(O.id())] + O.width() / 2, M = l[c.get(O.id())] - O.height() / 2, S = l[c.get(O.id())] + O.height() / 2, h > L && (h = L), w < I && (w = I), p > M && (p = M), y < S && (y = S);
        } var H = {}; return H.topLeftX = h, H.topLeftY = p, H.width = w - h, H.height = y - p, H; }, u.calcParentsWithoutChildren = function (r, t) { var l = r.collection(); return t.nodes(":parent").forEach(function (c) { var h = !1; c.children().forEach(function (w) { w.css("display") != "none" && (h = !0); }), h || l.merge(c); }), l; }, a.exports = u; }), 816: ((a, i, n) => { var f = n(548), e = n(140).CoSELayout, u = n(140).CoSENode, r = n(140).layoutBase.PointD, t = n(140).layoutBase.DimensionD, l = n(140).layoutBase.LayoutConstants, c = n(140).layoutBase.FDLayoutConstants, h = n(140).CoSEConstants, w = function (y, L) { var I = y.cy, M = y.eles, S = M.nodes(), X = M.edges(), G = void 0, Q = void 0, O = void 0, H = {}; y.randomize && (G = L.nodeIndexes, Q = L.xCoords, O = L.yCoords); var o = function (R) { return typeof R == "function"; }, m = function (R, k) { return o(R) ? R(k) : R; }, v = f.calcParentsWithoutChildren(I, M), T = function F(R, k, tt, b) { for (var _ = k.length, $ = 0; $ < _; $++) {
            var A = k[$], Y = null;
            A.intersection(v).length == 0 && (Y = A.children());
            var W = void 0, K = A.layoutDimensions({ nodeDimensionsIncludeLabels: b.nodeDimensionsIncludeLabels });
            if (A.outerWidth() != null && A.outerHeight() != null)
                if (b.randomize)
                    if (!A.isParent())
                        W = R.add(new u(tt.graphManager, new r(Q[G.get(A.id())] - K.w / 2, O[G.get(A.id())] - K.h / 2), new t(parseFloat(K.w), parseFloat(K.h))));
                    else {
                        var st = f.calcBoundingBox(A, Q, O, G);
                        A.intersection(v).length == 0 ? W = R.add(new u(tt.graphManager, new r(st.topLeftX, st.topLeftY), new t(st.width, st.height))) : W = R.add(new u(tt.graphManager, new r(st.topLeftX, st.topLeftY), new t(parseFloat(K.w), parseFloat(K.h))));
                    }
                else
                    W = R.add(new u(tt.graphManager, new r(A.position("x") - K.w / 2, A.position("y") - K.h / 2), new t(parseFloat(K.w), parseFloat(K.h))));
            else
                W = R.add(new u(this.graphManager));
            if (W.id = A.data("id"), W.nodeRepulsion = m(b.nodeRepulsion, A), W.paddingLeft = parseInt(A.css("padding")), W.paddingTop = parseInt(A.css("padding")), W.paddingRight = parseInt(A.css("padding")), W.paddingBottom = parseInt(A.css("padding")), b.nodeDimensionsIncludeLabels && (W.labelWidth = A.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).w, W.labelHeight = A.boundingBox({ includeLabels: !0, includeNodes: !1, includeOverlays: !1 }).h, W.labelPosVertical = A.css("text-valign"), W.labelPosHorizontal = A.css("text-halign")), H[A.data("id")] = W, isNaN(W.rect.x) && (W.rect.x = 0), isNaN(W.rect.y) && (W.rect.y = 0), Y != null && Y.length > 0) {
                var Lt = void 0;
                Lt = tt.getGraphManager().add(tt.newGraph(), W), F(Lt, Y, tt, b);
            }
        } }, d = function (R, k, tt) { for (var b = 0, _ = 0, $ = 0; $ < tt.length; $++) {
            var A = tt[$], Y = H[A.data("source")], W = H[A.data("target")];
            if (Y && W && Y !== W && Y.getEdgesBetween(W).length == 0) {
                var K = k.add(R.newEdge(), Y, W);
                K.id = A.id(), K.idealLength = m(y.idealEdgeLength, A), K.edgeElasticity = m(y.edgeElasticity, A), b += K.idealLength, _++;
            }
        } y.idealEdgeLength != null && (_ > 0 ? h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = b / _ : o(y.idealEdgeLength) ? h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = 50 : h.DEFAULT_EDGE_LENGTH = c.DEFAULT_EDGE_LENGTH = y.idealEdgeLength, h.MIN_REPULSION_DIST = c.MIN_REPULSION_DIST = c.DEFAULT_EDGE_LENGTH / 10, h.DEFAULT_RADIAL_SEPARATION = c.DEFAULT_EDGE_LENGTH); }, x = function (R, k) { k.fixedNodeConstraint && (R.constraints.fixedNodeConstraint = k.fixedNodeConstraint), k.alignmentConstraint && (R.constraints.alignmentConstraint = k.alignmentConstraint), k.relativePlacementConstraint && (R.constraints.relativePlacementConstraint = k.relativePlacementConstraint); }; y.nestingFactor != null && (h.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = c.PER_LEVEL_IDEAL_EDGE_LENGTH_FACTOR = y.nestingFactor), y.gravity != null && (h.DEFAULT_GRAVITY_STRENGTH = c.DEFAULT_GRAVITY_STRENGTH = y.gravity), y.numIter != null && (h.MAX_ITERATIONS = c.MAX_ITERATIONS = y.numIter), y.gravityRange != null && (h.DEFAULT_GRAVITY_RANGE_FACTOR = c.DEFAULT_GRAVITY_RANGE_FACTOR = y.gravityRange), y.gravityCompound != null && (h.DEFAULT_COMPOUND_GRAVITY_STRENGTH = c.DEFAULT_COMPOUND_GRAVITY_STRENGTH = y.gravityCompound), y.gravityRangeCompound != null && (h.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = c.DEFAULT_COMPOUND_GRAVITY_RANGE_FACTOR = y.gravityRangeCompound), y.initialEnergyOnIncremental != null && (h.DEFAULT_COOLING_FACTOR_INCREMENTAL = c.DEFAULT_COOLING_FACTOR_INCREMENTAL = y.initialEnergyOnIncremental), y.tilingCompareBy != null && (h.TILING_COMPARE_BY = y.tilingCompareBy), y.quality == "proof" ? l.QUALITY = 2 : l.QUALITY = 0, h.NODE_DIMENSIONS_INCLUDE_LABELS = c.NODE_DIMENSIONS_INCLUDE_LABELS = l.NODE_DIMENSIONS_INCLUDE_LABELS = y.nodeDimensionsIncludeLabels, h.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = l.DEFAULT_INCREMENTAL = !y.randomize, h.ANIMATE = c.ANIMATE = l.ANIMATE = y.animate, h.TILE = y.tile, h.TILING_PADDING_VERTICAL = typeof y.tilingPaddingVertical == "function" ? y.tilingPaddingVertical.call() : y.tilingPaddingVertical, h.TILING_PADDING_HORIZONTAL = typeof y.tilingPaddingHorizontal == "function" ? y.tilingPaddingHorizontal.call() : y.tilingPaddingHorizontal, h.DEFAULT_INCREMENTAL = c.DEFAULT_INCREMENTAL = l.DEFAULT_INCREMENTAL = !0, h.PURE_INCREMENTAL = !y.randomize, l.DEFAULT_UNIFORM_LEAF_NODE_SIZES = y.uniformNodeDimensions, y.step == "transformed" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !0, h.ENFORCE_CONSTRAINTS = !1, h.APPLY_LAYOUT = !1), y.step == "enforced" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !0, h.APPLY_LAYOUT = !1), y.step == "cose" && (h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !1, h.APPLY_LAYOUT = !0), y.step == "all" && (y.randomize ? h.TRANSFORM_ON_CONSTRAINT_HANDLING = !0 : h.TRANSFORM_ON_CONSTRAINT_HANDLING = !1, h.ENFORCE_CONSTRAINTS = !0, h.APPLY_LAYOUT = !0), y.fixedNodeConstraint || y.alignmentConstraint || y.relativePlacementConstraint ? h.TREE_REDUCTION_ON_INCREMENTAL = !1 : h.TREE_REDUCTION_ON_INCREMENTAL = !0; var D = new e, P = D.newGraphManager(); return T(P.addRoot(), f.getTopMostNodes(S), D, y), d(D, P, X), x(D, y), D.runLayout(), H; }; a.exports = { coseLayout: w }; }), 212: ((a, i, n) => { var f = (function () { function y(L, I) { for (var M = 0; M < I.length; M++) {
            var S = I[M];
            S.enumerable = S.enumerable || !1, S.configurable = !0, "value" in S && (S.writable = !0), Object.defineProperty(L, S.key, S);
        } } return function (L, I, M) { return I && y(L.prototype, I), M && y(L, M), L; }; })(); function e(y, L) { if (!(y instanceof L))
            throw new TypeError("Cannot call a class as a function"); } var u = n(658), r = n(548), t = n(657), l = t.spectralLayout, c = n(816), h = c.coseLayout, w = Object.freeze({ quality: "default", randomize: !0, animate: !0, animationDuration: 1e3, animationEasing: void 0, fit: !0, padding: 30, nodeDimensionsIncludeLabels: !1, uniformNodeDimensions: !1, packComponents: !0, step: "all", samplingType: !0, sampleSize: 25, nodeSeparation: 75, piTol: 1e-7, nodeRepulsion: function (L) { return 4500; }, idealEdgeLength: function (L) { return 50; }, edgeElasticity: function (L) { return .45; }, nestingFactor: .1, gravity: .25, numIter: 2500, tile: !0, tilingCompareBy: void 0, tilingPaddingVertical: 10, tilingPaddingHorizontal: 10, gravityRangeCompound: 1.5, gravityCompound: 1, gravityRange: 3.8, initialEnergyOnIncremental: .3, fixedNodeConstraint: void 0, alignmentConstraint: void 0, relativePlacementConstraint: void 0, ready: function () { }, stop: function () { } }), p = (function () { function y(L) { e(this, y), this.options = u({}, w, L); } return f(y, [{ key: "run", value: function () { var I = this, M = this.options, S = M.cy, X = M.eles, G = [], Q = void 0, O = void 0, H = [], o = void 0, m = []; M.fixedNodeConstraint && (!Array.isArray(M.fixedNodeConstraint) || M.fixedNodeConstraint.length == 0) && (M.fixedNodeConstraint = void 0), M.alignmentConstraint && (M.alignmentConstraint.vertical && (!Array.isArray(M.alignmentConstraint.vertical) || M.alignmentConstraint.vertical.length == 0) && (M.alignmentConstraint.vertical = void 0), M.alignmentConstraint.horizontal && (!Array.isArray(M.alignmentConstraint.horizontal) || M.alignmentConstraint.horizontal.length == 0) && (M.alignmentConstraint.horizontal = void 0)), M.relativePlacementConstraint && (!Array.isArray(M.relativePlacementConstraint) || M.relativePlacementConstraint.length == 0) && (M.relativePlacementConstraint = void 0); var v = M.fixedNodeConstraint || M.alignmentConstraint || M.relativePlacementConstraint; v && (M.tile = !1, M.packComponents = !1); var T = void 0, d = !1; if (S.layoutUtilities && M.packComponents && (T = S.layoutUtilities("get"), T || (T = S.layoutUtilities()), d = !0), X.nodes().length > 0)
                    if (d) {
                        var P = r.getTopMostNodes(M.eles.nodes());
                        if (o = r.connectComponents(S, M.eles, P), o.forEach(function (at) { var et = at.boundingBox(); m.push({ x: et.x1 + et.w / 2, y: et.y1 + et.h / 2 }); }), M.randomize && o.forEach(function (at) { M.eles = at, G.push(l(M)); }), M.quality == "default" || M.quality == "proof") {
                            var F = S.collection();
                            if (M.tile) {
                                var R = new Map, k = [], tt = [], b = 0, _ = { nodeIndexes: R, xCoords: k, yCoords: tt }, $ = [];
                                if (o.forEach(function (at, et) { at.edges().length == 0 && (at.nodes().forEach(function (pt, mt) { F.merge(at.nodes()[mt]), pt.isParent() || (_.nodeIndexes.set(at.nodes()[mt].id(), b++), _.xCoords.push(at.nodes()[0].position().x), _.yCoords.push(at.nodes()[0].position().y)); }), $.push(et)); }), F.length > 1) {
                                    var A = F.boundingBox();
                                    m.push({ x: A.x1 + A.w / 2, y: A.y1 + A.h / 2 }), o.push(F), G.push(_);
                                    for (var Y = $.length - 1; Y >= 0; Y--)
                                        o.splice($[Y], 1), G.splice($[Y], 1), m.splice($[Y], 1);
                                }
                            }
                            o.forEach(function (at, et) { M.eles = at, H.push(h(M, G[et])), r.relocateComponent(m[et], H[et], M); });
                        }
                        else
                            o.forEach(function (at, et) { r.relocateComponent(m[et], G[et], M); });
                        var W = new Set;
                        if (o.length > 1) {
                            var K = [], st = X.filter(function (at) { return at.css("display") == "none"; });
                            o.forEach(function (at, et) { var pt = void 0; if (M.quality == "draft" && (pt = G[et].nodeIndexes), at.nodes().not(st).length > 0) {
                                var mt = {};
                                mt.edges = [], mt.nodes = [];
                                var wt = void 0;
                                at.nodes().not(st).forEach(function (Et) { if (M.quality == "draft")
                                    if (!Et.isParent())
                                        wt = pt.get(Et.id()), mt.nodes.push({ x: G[et].xCoords[wt] - Et.boundingbox().w / 2, y: G[et].yCoords[wt] - Et.boundingbox().h / 2, width: Et.boundingbox().w, height: Et.boundingbox().h });
                                    else {
                                        var Tt = r.calcBoundingBox(Et, G[et].xCoords, G[et].yCoords, pt);
                                        mt.nodes.push({ x: Tt.topLeftX, y: Tt.topLeftY, width: Tt.width, height: Tt.height });
                                    }
                                else
                                    H[et][Et.id()] && mt.nodes.push({ x: H[et][Et.id()].getLeft(), y: H[et][Et.id()].getTop(), width: H[et][Et.id()].getWidth(), height: H[et][Et.id()].getHeight() }); }), at.edges().forEach(function (Et) { var Tt = Et.source(), Dt = Et.target(); if (Tt.css("display") != "none" && Dt.css("display") != "none")
                                    if (M.quality == "draft") {
                                        var It = pt.get(Tt.id()), Wt = pt.get(Dt.id()), Pt = [], Yt = [];
                                        if (Tt.isParent()) {
                                            var bt = r.calcBoundingBox(Tt, G[et].xCoords, G[et].yCoords, pt);
                                            Pt.push(bt.topLeftX + bt.width / 2), Pt.push(bt.topLeftY + bt.height / 2);
                                        }
                                        else
                                            Pt.push(G[et].xCoords[It]), Pt.push(G[et].yCoords[It]);
                                        if (Dt.isParent()) {
                                            var U = r.calcBoundingBox(Dt, G[et].xCoords, G[et].yCoords, pt);
                                            Yt.push(U.topLeftX + U.width / 2), Yt.push(U.topLeftY + U.height / 2);
                                        }
                                        else
                                            Yt.push(G[et].xCoords[Wt]), Yt.push(G[et].yCoords[Wt]);
                                        mt.edges.push({ startX: Pt[0], startY: Pt[1], endX: Yt[0], endY: Yt[1] });
                                    }
                                    else
                                        H[et][Tt.id()] && H[et][Dt.id()] && mt.edges.push({ startX: H[et][Tt.id()].getCenterX(), startY: H[et][Tt.id()].getCenterY(), endX: H[et][Dt.id()].getCenterX(), endY: H[et][Dt.id()].getCenterY() }); }), mt.nodes.length > 0 && (K.push(mt), W.add(et));
                            } });
                            var Lt = T.packComponents(K, M.randomize).shifts;
                            if (M.quality == "draft")
                                G.forEach(function (at, et) { var pt = at.xCoords.map(function (wt) { return wt + Lt[et].dx; }), mt = at.yCoords.map(function (wt) { return wt + Lt[et].dy; }); at.xCoords = pt, at.yCoords = mt; });
                            else {
                                var St = 0;
                                W.forEach(function (at) { Object.keys(H[at]).forEach(function (et) { var pt = H[at][et]; pt.setCenter(pt.getCenterX() + Lt[St].dx, pt.getCenterY() + Lt[St].dy); }), St++; });
                            }
                        }
                    }
                    else {
                        var x = M.eles.boundingBox();
                        if (m.push({ x: x.x1 + x.w / 2, y: x.y1 + x.h / 2 }), M.randomize) {
                            var D = l(M);
                            G.push(D);
                        }
                        M.quality == "default" || M.quality == "proof" ? (H.push(h(M, G[0])), r.relocateComponent(m[0], H[0], M)) : r.relocateComponent(m[0], G[0], M);
                    } var J = function (et, pt) { if (M.quality == "default" || M.quality == "proof") {
                    typeof et == "number" && (et = pt);
                    var mt = void 0, wt = void 0, Et = et.data("id");
                    return H.forEach(function (Dt) { Et in Dt && (mt = { x: Dt[Et].getRect().getCenterX(), y: Dt[Et].getRect().getCenterY() }, wt = Dt[Et]); }), M.nodeDimensionsIncludeLabels && (wt.labelWidth && (wt.labelPosHorizontal == "left" ? mt.x += wt.labelWidth / 2 : wt.labelPosHorizontal == "right" && (mt.x -= wt.labelWidth / 2)), wt.labelHeight && (wt.labelPosVertical == "top" ? mt.y += wt.labelHeight / 2 : wt.labelPosVertical == "bottom" && (mt.y -= wt.labelHeight / 2))), mt == null && (mt = { x: et.position("x"), y: et.position("y") }), { x: mt.x, y: mt.y };
                }
                else {
                    var Tt = void 0;
                    return G.forEach(function (Dt) { var It = Dt.nodeIndexes.get(et.id()); It != null && (Tt = { x: Dt.xCoords[It], y: Dt.yCoords[It] }); }), Tt == null && (Tt = { x: et.position("x"), y: et.position("y") }), { x: Tt.x, y: Tt.y };
                } }; if (M.quality == "default" || M.quality == "proof" || M.randomize) {
                    var Ut = r.calcParentsWithoutChildren(S, X), At = X.filter(function (at) { return at.css("display") == "none"; });
                    M.eles = X.not(At), X.nodes().not(":parent").not(At).layoutPositions(I, M, J), Ut.length > 0 && Ut.forEach(function (at) { at.position(J(at)); });
                }
                else
                    console.log("If randomize option is set to false, then quality option must be 'default' or 'proof'."); } }]), y; })(); a.exports = p; }), 657: ((a, i, n) => { var f = n(548), e = n(140).layoutBase.Matrix, u = n(140).layoutBase.SVD, r = function (l) { var c = l.cy, h = l.eles, w = h.nodes(), p = h.nodes(":parent"), y = new Map, L = new Map, I = new Map, M = [], S = [], X = [], G = [], Q = [], O = [], H = [], o = [], m = void 0, v = void 0, T = 1e8, d = 1e-9, x = l.piTol, D = l.samplingType, P = l.nodeSeparation, F = void 0, R = function () { for (var z = 0, B = 0, Z = !1; B < F;) {
            z = Math.floor(Math.random() * v), Z = !1;
            for (var j = 0; j < B; j++)
                if (G[j] == z) {
                    Z = !0;
                    break;
                }
            if (!Z)
                G[B] = z, B++;
            else
                continue;
        } }, k = function (z, B, Z) { for (var j = [], ut = 0, ct = 0, q = 0, ht = void 0, gt = [], rt = 0, vt = 1, Mt = 0; Mt < v; Mt++)
            gt[Mt] = T; for (j[ct] = z, gt[z] = 0; ct >= ut;) {
            q = j[ut++];
            for (var ot = M[q], it = 0; it < ot.length; it++)
                ht = L.get(ot[it]), gt[ht] == T && (gt[ht] = gt[q] + 1, j[++ct] = ht);
            O[q][B] = gt[q] * P;
        } if (Z) {
            for (var dt = 0; dt < v; dt++)
                O[dt][B] < Q[dt] && (Q[dt] = O[dt][B]);
            for (var nt = 0; nt < v; nt++)
                Q[nt] > rt && (rt = Q[nt], vt = nt);
        } return vt; }, tt = function (z) { var B = void 0; if (z) {
            B = Math.floor(Math.random() * v), m = B;
            for (var j = 0; j < v; j++)
                Q[j] = T;
            for (var ut = 0; ut < F; ut++)
                G[ut] = B, B = k(B, ut, z);
        }
        else {
            R();
            for (var Z = 0; Z < F; Z++)
                k(G[Z], Z, z, !1);
        } for (var ct = 0; ct < v; ct++)
            for (var q = 0; q < F; q++)
                O[ct][q] *= O[ct][q]; for (var ht = 0; ht < F; ht++)
            H[ht] = []; for (var gt = 0; gt < F; gt++)
            for (var rt = 0; rt < F; rt++)
                H[gt][rt] = O[G[rt]][gt]; }, b = function () { for (var z = u.svd(H), B = z.S, Z = z.U, j = z.V, ut = B[0] * B[0] * B[0], ct = [], q = 0; q < F; q++) {
            ct[q] = [];
            for (var ht = 0; ht < F; ht++)
                ct[q][ht] = 0, q == ht && (ct[q][ht] = B[q] / (B[q] * B[q] + ut / (B[q] * B[q])));
        } o = e.multMat(e.multMat(j, ct), e.transpose(Z)); }, _ = function () { for (var z = void 0, B = void 0, Z = [], j = [], ut = [], ct = [], q = 0; q < v; q++)
            Z[q] = Math.random(), j[q] = Math.random(); Z = e.normalize(Z), j = e.normalize(j); for (var ht = 0, gt = d, rt = d, vt = void 0;;) {
            ht++;
            for (var Mt = 0; Mt < v; Mt++)
                ut[Mt] = Z[Mt];
            if (Z = e.multGamma(e.multL(e.multGamma(ut), O, o)), z = e.dotProduct(ut, Z), Z = e.normalize(Z), gt = e.dotProduct(ut, Z), vt = Math.abs(gt / rt), vt <= 1 + x && vt >= 1)
                break;
            rt = gt;
        } for (var ot = 0; ot < v; ot++)
            ut[ot] = Z[ot]; for (ht = 0, rt = d;;) {
            ht++;
            for (var it = 0; it < v; it++)
                ct[it] = j[it];
            if (ct = e.minusOp(ct, e.multCons(ut, e.dotProduct(ut, ct))), j = e.multGamma(e.multL(e.multGamma(ct), O, o)), B = e.dotProduct(ct, j), j = e.normalize(j), gt = e.dotProduct(ct, j), vt = Math.abs(gt / rt), vt <= 1 + x && vt >= 1)
                break;
            rt = gt;
        } for (var dt = 0; dt < v; dt++)
            ct[dt] = j[dt]; S = e.multCons(ut, Math.sqrt(Math.abs(z))), X = e.multCons(ct, Math.sqrt(Math.abs(B))); }; f.connectComponents(c, h, f.getTopMostNodes(w), y), p.forEach(function (V) { f.connectComponents(c, h, f.getTopMostNodes(V.descendants().intersection(h)), y); }); for (var $ = 0, A = 0; A < w.length; A++)
            w[A].isParent() || L.set(w[A].id(), $++); var Y = !0, W = !1, K = void 0; try {
            for (var st = y.keys()[Symbol.iterator](), Lt; !(Y = (Lt = st.next()).done); Y = !0) {
                var St = Lt.value;
                L.set(St, $++);
            }
        }
        catch (V) {
            W = !0, K = V;
        }
        finally {
            try {
                !Y && st.return && st.return();
            }
            finally {
                if (W)
                    throw K;
            }
        } for (var J = 0; J < L.size; J++)
            M[J] = []; p.forEach(function (V) { for (var z = V.children().intersection(h); z.nodes(":childless").length == 0;)
            z = z.nodes()[0].children().intersection(h); var B = 0, Z = z.nodes(":childless")[0].connectedEdges().length; z.nodes(":childless").forEach(function (j, ut) { j.connectedEdges().length < Z && (Z = j.connectedEdges().length, B = ut); }), I.set(V.id(), z.nodes(":childless")[B].id()); }), w.forEach(function (V) { var z = void 0; V.isParent() ? z = L.get(I.get(V.id())) : z = L.get(V.id()), V.neighborhood().nodes().forEach(function (B) { h.intersection(V.edgesWith(B)).length > 0 && (B.isParent() ? M[z].push(I.get(B.id())) : M[z].push(B.id())); }); }); var Ut = function (z) { var B = L.get(z), Z = void 0; y.get(z).forEach(function (j) { c.getElementById(j).isParent() ? Z = I.get(j) : Z = j, M[B].push(Z), M[L.get(Z)].push(z); }); }, At = !0, at = !1, et = void 0; try {
            for (var pt = y.keys()[Symbol.iterator](), mt; !(At = (mt = pt.next()).done); At = !0) {
                var wt = mt.value;
                Ut(wt);
            }
        }
        catch (V) {
            at = !0, et = V;
        }
        finally {
            try {
                !At && pt.return && pt.return();
            }
            finally {
                if (at)
                    throw et;
            }
        } v = L.size; var Et = void 0; if (v > 2) {
            F = v < l.sampleSize ? v : l.sampleSize;
            for (var Tt = 0; Tt < v; Tt++)
                O[Tt] = [];
            for (var Dt = 0; Dt < F; Dt++)
                o[Dt] = [];
            return l.quality == "draft" || l.step == "all" ? (tt(D), b(), _(), Et = { nodeIndexes: L, xCoords: S, yCoords: X }) : (L.forEach(function (V, z) { S.push(c.getElementById(z).position("x")), X.push(c.getElementById(z).position("y")); }), Et = { nodeIndexes: L, xCoords: S, yCoords: X }), Et;
        }
        else {
            var It = L.keys(), Wt = c.getElementById(It.next().value), Pt = Wt.position(), Yt = Wt.outerWidth();
            if (S.push(Pt.x), X.push(Pt.y), v == 2) {
                var bt = c.getElementById(It.next().value), U = bt.outerWidth();
                S.push(Pt.x + Yt / 2 + U / 2 + l.idealEdgeLength), X.push(Pt.y);
            }
            return Et = { nodeIndexes: L, xCoords: S, yCoords: X }, Et;
        } }; a.exports = { spectralLayout: r }; }), 579: ((a, i, n) => { var f = n(212), e = function (r) { r && r("layout", "fcose", f); }; typeof cytoscape < "u" && e(cytoscape), a.exports = e; }), 140: (a => { a.exports = E; }) }, N = {};
    function g(a) { var i = N[a]; if (i !== void 0)
        return i.exports; var n = N[a] = { exports: {} }; return C[a](n, n.exports, g), n.exports; }
    var s = g(579);
    return s;
})(); }); });
var hr = mr(tr(), 1);
var er = { L: "left", R: "right", T: "top", B: "bottom" }, rr = { L: ft(E => `${E},${E / 2} 0,${E} 0,0`, "L"), R: ft(E => `0,${E / 2} ${E},0 ${E},${E}`, "R"), T: ft(E => `0,0 ${E},0 ${E / 2},${E}`, "T"), B: ft(E => `${E / 2},0 ${E},${E} 0,${E}`, "B") }, ge = { L: ft((E, C) => E - C + 2, "L"), R: ft((E, C) => E - 2, "R"), T: ft((E, C) => E - C + 2, "T"), B: ft((E, C) => E - 2, "B") }, Er = ft(function (E) { return Ht(E) ? E === "L" ? "R" : "L" : E === "T" ? "B" : "T"; }, "getOppositeArchitectureDirection"), ir = ft(function (E) { let C = E; return C === "L" || C === "R" || C === "T" || C === "B"; }, "isArchitectureDirection"), Ht = ft(function (E) { let C = E; return C === "L" || C === "R"; }, "isArchitectureDirectionX"), qt = ft(function (E) { let C = E; return C === "T" || C === "B"; }, "isArchitectureDirectionY"), xe = ft(function (E, C) { let N = Ht(E) && qt(C), g = qt(E) && Ht(C); return N || g; }, "isArchitectureDirectionXY"), Tr = ft(function (E) { let C = E[0], N = E[1], g = Ht(C) && qt(N), s = qt(C) && Ht(N); return g || s; }, "isArchitecturePairXY"), Nr = ft(function (E) { return E !== "LL" && E !== "RR" && E !== "TT" && E !== "BB"; }, "isValidArchitectureDirectionPair"), De = ft(function (E, C) { let N = `${E}${C}`; return Nr(N) ? N : void 0; }, "getArchitectureDirectionPair"), Lr = ft(function ([E, C], N) { let g = N[0], s = N[1]; return Ht(g) ? qt(s) ? [E + (g === "L" ? -1 : 1), C + (s === "T" ? 1 : -1)] : [E + (g === "L" ? -1 : 1), C] : Ht(s) ? [E + (s === "L" ? 1 : -1), C + (g === "T" ? 1 : -1)] : [E, C + (g === "T" ? 1 : -1)]; }, "shiftPositionByArchitectureDirectionPair"), wr = ft(function (E) { return E === "LT" || E === "TL" ? [1, 1] : E === "BL" || E === "LB" ? [1, -1] : E === "BR" || E === "RB" ? [-1, -1] : [-1, 1]; }, "getArchitectureDirectionXYFactors"), Mr = ft(function (E, C) { return xe(E, C) ? "bend" : Ht(E) ? "horizontal" : "vertical"; }, "getArchitectureDirectionAlignment"), Cr = ft(function (E) { return E.type === "service"; }, "isArchitectureService"), Ar = ft(function (E) { return E.type === "junction"; }, "isArchitectureJunction"), nr = ft((E, C) => { let [N, g] = [E, C].sort(); return `${JSON.stringify(N)}-${JSON.stringify(g)}`; }, "architectureGroupAlignmentKey"), ar = ft(E => E.data(), "edgeData"), re = ft(E => E.data(), "nodeData"), Dr = Pe.architecture, or = class {
    constructor() { this.nodes = new Map, this.groups = new Map, this.edges = [], this.layoutHints = [], this.registeredIds = new Map, this.elements = new Map, this.diagramId = "", this.setAccTitle = He, this.getAccTitle = We, this.setDiagramTitle = $e, this.getDiagramTitle = Be, this.getAccDescription = ze, this.setAccDescription = Ve, this.clear(); }
    static { ft(this, "ArchitectureDB"); }
    setDiagramId(E) { this.diagramId = E; }
    getDiagramId() { return this.diagramId; }
    clear() { this.nodes = new Map, this.groups = new Map, this.edges = [], this.layoutHints = [], this.registeredIds = new Map, this.dataStructures = void 0, this.elements = new Map, this.diagramId = "", Xe(); }
    addService({ id: E, icon: C, in: N, title: g, iconText: s }) { if (this.registeredIds.has(E))
        throw new Error(`The service id [${E}] is already in use by another ${this.registeredIds.get(E)}`); if (N !== void 0) {
        if (E === N)
            throw new Error(`The service [${E}] cannot be placed within itself`);
        if (!this.registeredIds.has(N))
            throw new Error(`The service [${E}]'s parent does not exist. Please make sure the parent is created before this service`);
        if (this.registeredIds.get(N) === "node")
            throw new Error(`The service [${E}]'s parent is not a group`);
    } this.registeredIds.set(E, "node"), this.nodes.set(E, { id: E, type: "service", icon: C, iconText: s, title: g, edges: [], in: N }); }
    getServices() { return [...this.nodes.values()].filter(Cr); }
    addJunction({ id: E, in: C }) { if (this.registeredIds.has(E))
        throw new Error(`The junction id [${E}] is already in use by another ${this.registeredIds.get(E)}`); if (C !== void 0) {
        if (E === C)
            throw new Error(`The junction [${E}] cannot be placed within itself`);
        if (!this.registeredIds.has(C))
            throw new Error(`The junction [${E}]'s parent does not exist. Please make sure the parent is created before this junction`);
        if (this.registeredIds.get(C) === "node")
            throw new Error(`The junction [${E}]'s parent is not a group`);
    } this.registeredIds.set(E, "node"), this.nodes.set(E, { id: E, type: "junction", edges: [], in: C }); }
    getJunctions() { return [...this.nodes.values()].filter(Ar); }
    getNodes() { return [...this.nodes.values()]; }
    getNode(E) { return this.nodes.get(E) ?? null; }
    addGroup({ id: E, icon: C, in: N, title: g }) { if (this.registeredIds.has(E))
        throw new Error(`The group id [${E}] is already in use by another ${this.registeredIds.get(E)}`); if (N !== void 0) {
        if (E === N)
            throw new Error(`The group [${E}] cannot be placed within itself`);
        if (!this.registeredIds.has(N))
            throw new Error(`The group [${E}]'s parent does not exist. Please make sure the parent is created before this group`);
        if (this.registeredIds.get(N) === "node")
            throw new Error(`The group [${E}]'s parent is not a group`);
    } this.registeredIds.set(E, "group"), this.groups.set(E, { id: E, icon: C, title: g, in: N }); }
    getGroups() { return [...this.groups.values()]; }
    addEdge({ lhsId: E, rhsId: C, lhsDir: N, rhsDir: g, lhsInto: s, rhsInto: a, lhsGroup: i, rhsGroup: n, title: f }) { if (!ir(N))
        throw new Error(`Invalid direction given for left hand side of edge ${E}--${C}. Expected (L,R,T,B) got ${String(N)}`); if (!ir(g))
        throw new Error(`Invalid direction given for right hand side of edge ${E}--${C}. Expected (L,R,T,B) got ${String(g)}`); if (!this.nodes.has(E) && !this.groups.has(E))
        throw new Error(`The left-hand id [${E}] does not yet exist. Please create the service/group before declaring an edge to it.`); if (!this.nodes.has(C) && !this.groups.has(C))
        throw new Error(`The right-hand id [${C}] does not yet exist. Please create the service/group before declaring an edge to it.`); let e = this.nodes.get(E).in, u = this.nodes.get(C).in; if (i && e && u && e == u)
        throw new Error(`The left-hand id [${E}] is modified to traverse the group boundary, but the edge does not pass through two groups.`); if (n && e && u && e == u)
        throw new Error(`The right-hand id [${C}] is modified to traverse the group boundary, but the edge does not pass through two groups.`); let r = { lhsId: E, lhsDir: N, lhsInto: s, lhsGroup: i, rhsId: C, rhsDir: g, rhsInto: a, rhsGroup: n, title: f }; this.edges.push(r); let t = this.nodes.get(E), l = this.nodes.get(C); t && l && (t.edges.push(this.edges[this.edges.length - 1]), l.edges.push(this.edges[this.edges.length - 1])); }
    getEdges() { return this.edges; }
    addLayoutHint(E) { if (E.members.length < 2)
        throw new Error(`An align directive requires at least two members; got ${E.members.length}`); let C = new Set; E.members.forEach(N => { if (this.registeredIds.get(N) !== "node")
        throw new Error(`align ${E.direction} references [${N}], which is not a service or junction`); if (C.has(N))
        throw new Error(`align ${E.direction} lists [${N}] more than once`); C.add(N); }), this.layoutHints.push(E); }
    getLayoutHints() { return this.layoutHints; }
    getDataStructures() { if (this.dataStructures === void 0) {
        let E = new Map, C = new Map;
        for (let [i, n] of this.nodes.entries()) {
            let f = new Map;
            for (let e of n.edges) {
                let u = this.getNode(e.lhsId)?.in, r = this.getNode(e.rhsId)?.in;
                if (u && r && u !== r) {
                    let t = Mr(e.lhsDir, e.rhsDir);
                    t !== "bend" && E.set(nr(u, r), t);
                }
                if (e.lhsId === i) {
                    let t = De(e.lhsDir, e.rhsDir);
                    t && f.set(t, e.rhsId);
                }
                else {
                    let t = De(e.rhsDir, e.lhsDir);
                    t && f.set(t, e.lhsId);
                }
            }
            C.set(i, f);
        }
        let N = new Set, g = new Set(C.keys()), s = ft(i => { let n = new Map([[i, [0, 0]]]), f = [i]; for (; f.length > 0;) {
            let e = f.shift();
            if (e) {
                N.add(e), g.delete(e);
                let u = C.get(e);
                if (!u)
                    throw new Error(`BFS error: adjacency list for id ${e} not found. Please report this as a bug.`);
                let r = n.get(e);
                if (!r)
                    throw new Error(`BFS error: position for id ${e} not found in spatial map. Please report this as a bug.`);
                let [t, l] = r;
                u.forEach((c, h) => { N.has(c) || (n.set(c, Lr([t, l], h)), f.push(c)); });
            }
        } return n; }, "BFS"), a = [];
        for (; g.size > 0;) {
            let i = g.values().next().value;
            a.push(s(i));
        }
        this.dataStructures = { adjList: C, spatialMaps: a, groupAlignments: E };
    } return this.dataStructures; }
    setElementForId(E, C) { this.elements.set(E, C); }
    getElementById(E) { return this.elements.get(E); }
    getConfig() { return Je(ie(ie({}, Dr), Ge().architecture)); }
    getConfigField(E) { return this.getConfig()[E]; }
}, Or = ft((E, C) => { je(E, C), E.groups.map(N => C.addGroup(N)), E.services.map(N => C.addService(me(ie({}, N), { type: "service" }))), E.junctions.map(N => C.addJunction(me(ie({}, N), { type: "junction" }))), E.edges.map(N => C.addEdge(N)), E.alignments?.map(N => C.addLayoutHint({ direction: N.direction, members: [...N.members] })); }, "populateDb"), sr = { parser: { yy: void 0 }, parse: ft(E => kt(null, null, function* () { let C = yield _e("architecture", E); Te.debug(C); let N = sr.parser?.yy; if (!(N instanceof or))
        throw new Error("parser.parser?.yy was not a ArchitectureDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues."); Or(C, N); }), "parse") }, xr = ft(E => `
  .edge {
    stroke-width: ${E.archEdgeWidth};
    stroke: ${E.archEdgeColor};
    fill: none;
  }

  .arrow {
    fill: ${E.archEdgeArrowColor};
  }

  .node-bkg {
    fill: none;
    stroke: ${E.archGroupBorderColor};
    stroke-width: ${E.archGroupBorderWidth};
    stroke-dasharray: 8;
  }
  .node-icon-text {
    display: flex; 
    align-items: center;
  }
  
  .node-icon-text > div {
    color: #fff;
    margin: 1px;
    height: fit-content;
    text-align: center;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
  }
`, "getStyles"), Ir = xr;
function Oe(E, C) { if (E === 0)
    return C(); let N = Math.random, g = E >>> 0; Math.random = function () { g = g + 1831565813 >>> 0; let s = g; return s = Math.imul(s ^ s >>> 15, s | 1), s ^= s + Math.imul(s ^ s >>> 7, s | 61), ((s ^ s >>> 14) >>> 0) / 4294967296; }; try {
    return C();
}
finally {
    Math.random = N;
} }
ft(Oe, "withSeededRandom");
var ee = ft(E => `<g><rect width="80" height="80" style="fill: #087ebf; stroke-width: 0px;"/>${E}</g>`, "wrapIcon"), se = { prefix: "mermaid-architecture", height: 80, width: 80, icons: { database: { body: ee('<path id="b" data-name="4" d="m20,57.86c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="c" data-name="3" d="m20,45.95c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path id="d" data-name="2" d="m20,34.05c0,3.94,8.95,7.14,20,7.14s20-3.2,20-7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse id="e" data-name="1" cx="40" cy="22.14" rx="20" ry="7.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="20" y1="57.86" x2="20" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="60" y1="57.86" x2="60" y2="22.14" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>') }, server: { body: ee('<rect x="17.5" y="17.5" width="45" height="45" rx="2" ry="2" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="32.5" x2="62.5" y2="32.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="47.5" x2="62.5" y2="47.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><g><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,25c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,40c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: #fff; stroke-width: 0px;"/><path d="m56.25,55c0,.27-.45.5-1,.5h-10.5c-.55,0-1-.23-1-.5s.45-.5,1-.5h10.5c.55,0,1,.23,1,.5Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="25" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="40" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g><g><circle cx="32.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="27.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/><circle cx="22.5" cy="55" r=".75" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10;"/></g>') }, disk: { body: ee('<rect x="20" y="15" width="40" height="50" rx="1" ry="1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="19.17" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="24" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="56" cy="60.83" rx=".8" ry=".83" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="14" ry="14.58" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><ellipse cx="40" cy="33.75" rx="4" ry="4.17" style="fill: #fff; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m37.51,42.52l-4.83,13.22c-.26.71-1.1,1.02-1.76.64l-4.18-2.42c-.66-.38-.81-1.26-.33-1.84l9.01-10.8c.88-1.05,2.56-.08,2.09,1.2Z" style="fill: #fff; stroke-width: 0px;"/>') }, internet: { body: ee('<circle cx="40" cy="40" r="22.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="40" y1="17.5" x2="40" y2="62.5" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="17.5" y1="40" x2="62.5" y2="40" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m39.99,17.51c-15.28,11.1-15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><path d="m40.01,17.51c15.28,11.1,15.28,33.88,0,44.98" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="30.1" x2="60.25" y2="30.1" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/><line x1="19.75" y1="49.9" x2="60.25" y2="49.9" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>') }, cloud: { body: ee('<path d="m65,47.5c0,2.76-2.24,5-5,5H20c-2.76,0-5-2.24-5-5,0-1.87,1.03-3.51,2.56-4.36-.04-.21-.06-.42-.06-.64,0-2.6,2.48-4.74,5.65-4.97,1.65-4.51,6.34-7.76,11.85-7.76.86,0,1.69.08,2.5.23,2.09-1.57,4.69-2.5,7.5-2.5,6.1,0,11.19,4.38,12.28,10.17,2.14.56,3.72,2.51,3.72,4.83,0,.03,0,.07-.01.1,2.29.46,4.01,2.48,4.01,4.9Z" style="fill: none; stroke: #fff; stroke-miterlimit: 10; stroke-width: 2px;"/>') }, unknown: qe, blank: { body: ee("") } } }, Rr = ft(function (E, C, N, g) {
    return kt(this, null, function* () {
        let s = N.getConfigField("padding"), a = N.getConfigField("iconSize"), i = a / 2, n = a / 6, f = n / 2;
        yield Promise.all(C.edges().map(e => kt(null, null, function* () {
            let { source: u, sourceDir: r, sourceArrow: t, sourceGroup: l, target: c, targetDir: h, targetArrow: w, targetGroup: p, label: y } = ar(e), { x: L, y: I } = e[0].sourceEndpoint(), { x: M, y: S } = e[0].midpoint(), { x: X, y: G } = e[0].targetEndpoint(), Q = s + 4;
            if (l && (Ht(r) ? L += r === "L" ? -Q : Q : I += r === "T" ? -Q : Q + 18), p && (Ht(h) ? X += h === "L" ? -Q : Q : G += h === "T" ? -Q : Q + 18), !l && N.getNode(u)?.type === "junction" && (Ht(r) ? L += r === "L" ? i : -i : I += r === "T" ? i : -i), !p && N.getNode(c)?.type === "junction" && (Ht(h) ? X += h === "L" ? i : -i : G += h === "T" ? i : -i), e[0]._private.rscratch) {
                let O = E.insert("g");
                if (O.insert("path").attr("d", `M ${L},${I} L ${M},${S} L${X},${G} `).attr("class", "edge").attr("id", `${g}-${Ke(u, c, { prefix: "L" })}`), t) {
                    let H = Ht(r) ? ge[r](L, n) : L - f, o = qt(r) ? ge[r](I, n) : I - f;
                    O.insert("polygon").attr("points", rr[r](n)).attr("transform", `translate(${H},${o})`).attr("class", "arrow");
                }
                if (w) {
                    let H = Ht(h) ? ge[h](X, n) : X - f, o = qt(h) ? ge[h](G, n) : G - f;
                    O.insert("polygon").attr("points", rr[h](n)).attr("transform", `translate(${H},${o})`).attr("class", "arrow");
                }
                if (y) {
                    let H = xe(r, h) ? "XY" : Ht(r) ? "X" : "Y", o = 0;
                    H === "X" ? o = Math.abs(L - X) : H === "Y" ? o = Math.abs(I - G) / 1.5 : o = Math.abs(L - X) / 2;
                    let m = O.append("g");
                    if (yield ce(m, y, { useHtmlLabels: !1, width: o, classes: "architecture-service-label" }, le()), m.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), H === "X")
                        m.attr("transform", "translate(" + M + ", " + S + ")");
                    else if (H === "Y")
                        m.attr("transform", "translate(" + M + ", " + S + ") rotate(-90)");
                    else if (H === "XY") {
                        let v = De(r, h);
                        if (v && Tr(v)) {
                            let T = m.node().getBoundingClientRect(), [d, x] = wr(v);
                            m.attr("dominant-baseline", "auto").attr("transform", `rotate(${-1 * d * x * 45})`);
                            let D = m.node().getBoundingClientRect();
                            m.attr("transform", `
                translate(${M}, ${S - T.height / 2})
                translate(${d * D.width / 2}, ${x * D.height / 2})
                rotate(${-1 * d * x * 45}, 0, ${T.height / 2})
              `);
                        }
                    }
                }
            }
        })));
    });
}, "drawEdges"), Sr = ft(function (E, C, N, g) { return kt(this, null, function* () { let a = N.getConfigField("padding") * .75, i = N.getConfigField("fontSize"), f = N.getConfigField("iconSize") / 2; yield Promise.all(C.nodes().map(e => kt(null, null, function* () { let u = re(e); if (u.type === "group") {
    let { h: r, w: t, x1: l, y1: c } = e.boundingBox(), h = E.append("rect");
    h.attr("id", `${g}-group-${u.id}`).attr("x", l + f).attr("y", c + f).attr("width", t).attr("height", r).attr("class", "node-bkg");
    let w = E.append("g"), p = l, y = c;
    if (u.icon) {
        let L = w.append("g");
        L.html(`<g>${yield fe(u.icon, { height: a, width: a, fallbackPrefix: se.prefix })}</g>`), L.attr("transform", "translate(" + (p + f + 1) + ", " + (y + f + 1) + ")"), p += a, y += i / 2 - 1 - 2;
    }
    if (u.label) {
        let L = w.append("g");
        yield ce(L, u.label, { useHtmlLabels: !1, width: t, classes: "architecture-service-label" }, le()), L.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "start").attr("text-anchor", "start"), L.attr("transform", "translate(" + (p + f + 4) + ", " + (y + f + 2) + ")");
    }
    N.setElementForId(u.id, h);
} }))); }); }, "drawGroups"), Fr = ft(function (E, C, N, g) { return kt(this, null, function* () { let s = le(); for (let a of N) {
    let i = C.append("g"), n = E.getConfigField("iconSize");
    if (a.title) {
        let r = i.append("g");
        yield ce(r, a.title, { useHtmlLabels: !1, width: n * 1.5, classes: "architecture-service-label" }, s), r.attr("dy", "1em").attr("alignment-baseline", "middle").attr("dominant-baseline", "middle").attr("text-anchor", "middle"), r.attr("transform", "translate(" + n / 2 + ", " + n + ")");
    }
    let f = i.append("g");
    if (a.icon)
        f.html(`<g>${yield fe(a.icon, { height: n, width: n, fallbackPrefix: se.prefix })}</g>`);
    else if (a.iconText) {
        f.html(`<g>${yield fe("blank", { height: n, width: n, fallbackPrefix: se.prefix })}</g>`);
        let l = f.append("g").append("foreignObject").attr("width", n).attr("height", n).append("div").attr("class", "node-icon-text").attr("style", `height: ${n}px;`).append("div").html(Ue(a.iconText, s)), c = parseInt(window.getComputedStyle(l.node(), null).getPropertyValue("font-size").replace(/\D/g, "")) ?? 16;
        l.attr("style", `-webkit-line-clamp: ${Math.floor((n - 2) / c)};`);
    }
    else
        f.append("path").attr("class", "node-bkg").attr("id", `${g}-node-${a.id}`).attr("d", `M0,${n} V5 Q0,0 5,0 H${n - 5} Q${n},0 ${n},5 V${n} Z`);
    i.attr("id", `${g}-service-${a.id}`).attr("class", "architecture-service");
    let { width: e, height: u } = i.node().getBBox();
    a.width = e, a.height = u, E.setElementForId(a.id, i);
} return 0; }); }, "drawServices"), br = ft(function (E, C, N, g) { N.forEach(s => { let a = C.append("g"), i = E.getConfigField("iconSize"); a.append("g").append("rect").attr("id", `${g}-node-${s.id}`).attr("fill-opacity", "0").attr("width", i).attr("height", i), a.attr("class", "architecture-junction"); let { width: f, height: e } = a._groups[0][0].getBBox(); a.width = f, a.height = e, E.setElementForId(s.id, a); }); }, "drawJunctions");
Qe([{ name: se.prefix, icons: se }]);
Ne.use(hr.default);
function lr(E, C, N) { E.forEach(g => { C.add({ group: "nodes", data: { type: "service", id: g.id, icon: g.icon, label: g.title, parent: g.in, width: N.getConfigField("iconSize"), height: N.getConfigField("iconSize") }, classes: "node-service" }); }); }
ft(lr, "addServices");
function fr(E, C, N) { E.forEach(g => { C.add({ group: "nodes", data: { type: "junction", id: g.id, parent: g.in, width: N.getConfigField("iconSize"), height: N.getConfigField("iconSize") }, classes: "node-junction" }); }); }
ft(fr, "addJunctions");
function cr(E, C) { C.nodes().map(N => { let g = re(N); if (g.type === "group")
    return; g.x = N.position().x, g.y = N.position().y, E.getElementById(g.id).attr("transform", "translate(" + (g.x || 0) + "," + (g.y || 0) + ")"); }); }
ft(cr, "positionNodes");
function gr(E, C) { E.forEach(N => { C.add({ group: "nodes", data: { type: "group", id: N.id, icon: N.icon, label: N.title, parent: N.in }, classes: "node-group" }); }); }
ft(gr, "addGroups");
function ur(E, C) { E.forEach(N => { let { lhsId: g, rhsId: s, lhsInto: a, lhsGroup: i, rhsInto: n, lhsDir: f, rhsDir: e, rhsGroup: u, title: r } = N, t = xe(N.lhsDir, N.rhsDir) ? "segments" : "straight", l = { id: `${g}-${s}`, label: r, source: g, sourceDir: f, sourceArrow: a, sourceGroup: i, sourceEndpoint: f === "L" ? "0 50%" : f === "R" ? "100% 50%" : f === "T" ? "50% 0" : "50% 100%", target: s, targetDir: e, targetArrow: n, targetGroup: u, targetEndpoint: e === "L" ? "0 50%" : e === "R" ? "100% 50%" : e === "T" ? "50% 0" : "50% 100%" }; C.add({ group: "edges", data: l, classes: t }); }); }
ft(ur, "addEdges");
function dr(E, C, N, g = []) { let s = ft((t, l) => { let c = new Map; for (let [h, w] of t.entries()) {
    let p = `${h}`, y = 0, L = [...w.entries()];
    if (L.length === 1) {
        c.set(p, L[0][1]);
        continue;
    }
    for (let I = 0; I < L.length - 1; I++)
        for (let M = I + 1; M < L.length; M++) {
            let [S, X] = L[I], [G, Q] = L[M];
            if (N.get(nr(S, G)) === l)
                c.set(p, [...c.get(p) ?? [], ...X, ...Q]);
            else if (S === "default" || G === "default")
                c.set(p, [...c.get(p) ?? [], ...X, ...Q]);
            else {
                let H = `${p}-${y++}`;
                c.set(H, X);
                let o = `${p}-${y++}`;
                c.set(o, Q);
            }
        }
} return c; }, "flattenAlignments"), a = C.map(t => { let l = new Map, c = new Map; return t.forEach(([h, w], p) => { let y = E.getNode(p)?.in ?? "default", L = l.get(w) ?? new Map; l.has(w) || l.set(w, L); let I = c.get(h) ?? new Map; c.has(h) || c.set(h, I); for (let M of [L, I]) {
    let S = M.get(y) ?? [];
    M.has(y) || M.set(y, S), S.push(p);
} }), { horiz: [...s(l, "horizontal").values()].filter(h => h.length > 1), vert: [...s(c, "vertical").values()].filter(h => h.length > 1) }; }), [i, n] = a.reduce(([t, l], { horiz: c, vert: h }) => [[...t, ...c], [...l, ...h]], [[], []]), f = new Set; g.forEach(t => t.members.forEach(l => f.add(l))); let e = ft(t => t.filter(l => !l.some(c => f.has(c))), "dropOverlapping"), u = e(i), r = e(n); return g.forEach(t => { t.members.length < 2 || (t.direction === "row" ? u.push([...t.members]) : r.push([...t.members])); }), { horizontal: u, vertical: r }; }
ft(dr, "getAlignments");
function vr(E, C, N = []) { let g = [], s = C.getConfigField("iconSize"), a = C.getConfigField("idealEdgeLengthMultiplier"), i = a * s, n = new Set; N.forEach(u => { for (let r = 0; r < u.members.length - 1; r++) {
    let t = u.members[r], l = u.members[r + 1];
    n.add(`${t}|${l}`), n.add(`${l}|${t}`), u.direction === "row" ? g.push({ left: t, right: l, gap: i }) : g.push({ top: t, bottom: l, gap: i });
} }); let f = ft(u => `${u[0]},${u[1]}`, "posToStr"), e = ft(u => u.split(",").map(r => parseInt(r)), "strToPos"); return E.forEach(u => { let r = new Map([...u.entries()].map(([h, w]) => [f(w), h])), t = [f([0, 0])], l = {}, c = { L: [-1, 0], R: [1, 0], T: [0, 1], B: [0, -1] }; for (; t.length > 0;) {
    let h = t.shift();
    if (h) {
        l[h] = 1;
        let w = r.get(h);
        if (w) {
            let p = e(h);
            Object.entries(c).forEach(([y, L]) => { let I = f([p[0] + L[0], p[1] + L[1]]), M = r.get(I); if (M && !l[I]) {
                if (t.push(I), n.has(`${w}|${M}`))
                    return;
                g.push({ [er[y]]: M, [er[Er(y)]]: w, gap: a * s });
            } });
        }
    }
} }), g; }
ft(vr, "getRelativeConstraints");
function pr(E, C, N, g, s, { spatialMaps: a, groupAlignments: i }) { return new Promise(n => { let f = Ze("body").append("div").attr("id", "cy").attr("style", "display:none"), e = Ne({ container: document.getElementById("cy"), style: [{ selector: "edge", style: { "curve-style": "straight", "source-endpoint": "data(sourceEndpoint)", "target-endpoint": "data(targetEndpoint)" } }, { selector: "edge[label]", style: { label: "data(label)" } }, { selector: "edge.segments", style: { "curve-style": "segments", "segment-weights": "0", "segment-distances": [.5], "edge-distances": "endpoints", "source-endpoint": "data(sourceEndpoint)", "target-endpoint": "data(targetEndpoint)" } }, { selector: "node", style: { "compound-sizing-wrt-labels": "include" } }, { selector: "node[label]", style: { "text-valign": "bottom", "text-halign": "center", "font-size": `${s.getConfigField("fontSize")}px` } }, { selector: ".node-service", style: { label: "data(label)", width: "data(width)", height: "data(height)" } }, { selector: ".node-junction", style: { width: "data(width)", height: "data(height)" } }, { selector: ".node-group", style: { padding: `${s.getConfigField("padding")}px` } }], layout: { name: "grid", boundingBox: { x1: 0, x2: 100, y1: 0, y2: 100 } } }); f.remove(), gr(N, e), lr(E, e, s), fr(C, e, s), ur(g, e); let u = s.getLayoutHints(), r = dr(s, a, i, u), t = vr(a, s, u), l = s.getConfigField("iconSize"), c = s.getConfigField("idealEdgeLengthMultiplier") * l, h = .5 * l, w = s.getConfigField("edgeElasticity"), p = s.getConfigField("seed"), y = e.layout({ name: "fcose", quality: "proof", randomize: s.getConfigField("randomize"), nodeSeparation: s.getConfigField("nodeSeparation"), numIter: s.getConfigField("numIter"), styleEnabled: !1, animate: !1, nodeDimensionsIncludeLabels: !1, idealEdgeLength(L) { let [I, M] = L.connectedNodes(), { parent: S } = re(I), { parent: X } = re(M); return S === X ? c : h; }, edgeElasticity(L) { let [I, M] = L.connectedNodes(), { parent: S } = re(I), { parent: X } = re(M); return S === X ? w : .001; }, alignmentConstraint: r, relativePlacementConstraint: t }); y.one("layoutstop", () => { function L(I, M, S, X) { let G, Q, { x: O, y: H } = I, { x: o, y: m } = M; Q = (X - H + (O - S) * (H - m) / (O - o)) / Math.sqrt(1 + Math.pow((H - m) / (O - o), 2)), G = Math.sqrt(Math.pow(X - H, 2) + Math.pow(S - O, 2) - Math.pow(Q, 2)); let v = Math.sqrt(Math.pow(o - O, 2) + Math.pow(m - H, 2)); G = G / v; let T = (o - O) * (X - H) - (m - H) * (S - O); switch (!0) {
    case T >= 0:
        T = 1;
        break;
    case T < 0:
        T = -1;
        break;
} let d = (o - O) * (S - O) + (m - H) * (X - H); switch (!0) {
    case d >= 0:
        d = 1;
        break;
    case d < 0:
        d = -1;
        break;
} return Q = Math.abs(Q) * T, G = G * d, { distances: Q, weights: G }; } ft(L, "getSegmentWeights"), e.startBatch(); for (let I of Object.values(e.edges()))
    if (I.data?.()) {
        let { x: M, y: S } = I.source().position(), { x: X, y: G } = I.target().position();
        if (M !== X && S !== G) {
            let Q = I.sourceEndpoint(), O = I.targetEndpoint(), { sourceDir: H } = ar(I), [o, m] = qt(H) ? [Q.x, O.y] : [O.x, Q.y], { weights: v, distances: T } = L(Q, O, o, m);
            I.style("segment-distances", T), I.style("segment-weights", v);
        }
    } e.endBatch(), Oe(p, () => y.run()); }); try {
    Oe(p, () => y.run());
}
catch (L) {
    throw L instanceof RangeError && L.message.includes("Invalid array length") ? new Error("Architecture layout failed: a declared `align row|column` directive likely contradicts the edge directions, or two declared alignments overlap on a shared node. Check that the order of members in each `align` chain is consistent with the edges between them, and that no node appears in two `align` directives along the same axis.") : L;
} e.ready(L => { Te.info("Ready", L), n(e); }); }); }
ft(pr, "layoutArchitecture");
var Pr = ft((E, C, N, g) => kt(null, null, function* () { let s = g.db; s.setDiagramId(C); let a = s.getServices(), i = s.getJunctions(), n = s.getGroups(), f = s.getEdges(), e = s.getDataStructures(), u = ke(C), r = u.append("g"); r.attr("class", "architecture-edges"); let t = u.append("g"); t.attr("class", "architecture-services"); let l = u.append("g"); l.attr("class", "architecture-groups"), yield Fr(s, t, a, C), br(s, t, i, C); let c = yield pr(a, i, n, f, s, e); yield Rr(r, c, s, C), yield Sr(l, c, s, C), cr(s, c), Ye(void 0, u, s.getConfigField("padding"), s.getConfigField("useMaxWidth")); }), "draw"), Gr = { draw: Pr }, qr = { parser: sr, get db() { return new or; }, renderer: Gr, styles: Ir };
export { qr as diagram };
