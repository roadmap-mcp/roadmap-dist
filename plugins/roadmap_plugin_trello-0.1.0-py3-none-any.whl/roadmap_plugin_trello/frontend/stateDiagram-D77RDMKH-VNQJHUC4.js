import { a as _, c as N, d as F } from "@nf-internal/chunk-GV5ZBDHE";
import "@nf-internal/chunk-X5ONEG5D";
import "@nf-internal/chunk-3UW5LP2A";
import "@nf-internal/chunk-WVCFK4LD";
import "@nf-internal/chunk-4PKWXC3U";
import { a as U } from "@nf-internal/chunk-JG3WN63S";
import { C } from "@nf-internal/chunk-LUZVEH3G";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { p as P } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { I as A, N as T, O as G, _ as t } from "@nf-internal/chunk-LEJRRF65";
import { H as R, L as W, b as v, h as z } from "@nf-internal/chunk-RZWXGGKD";
import { a as u } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var D = u(e => e.append("circle").attr("class", "start-state").attr("r", t().state.sizeUnit).attr("cx", t().state.padding + t().state.sizeUnit).attr("cy", t().state.padding + t().state.sizeUnit), "drawStartState"), Y = u(e => e.append("line").style("stroke", "grey").style("stroke-dasharray", "3").attr("x1", t().state.textHeight).attr("class", "divider").attr("x2", t().state.textHeight * 2).attr("y1", 0).attr("y2", 0), "drawDivider"), I = u((e, i) => { let s = e.append("text").attr("x", 2 * t().state.padding).attr("y", t().state.textHeight + 2 * t().state.padding).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.id), g = s.node().getBBox(); return e.insert("rect", ":first-child").attr("x", t().state.padding).attr("y", t().state.padding).attr("width", g.width + 2 * t().state.padding).attr("height", g.height + 2 * t().state.padding).attr("rx", t().state.radius), s; }, "drawSimpleState"), $ = u((e, i) => { let s = u(function (o, w, y) { let S = o.append("tspan").attr("x", 2 * t().state.padding).text(w); y || S.attr("dy", t().state.textHeight); }, "addTspan"), n = e.append("text").attr("x", 2 * t().state.padding).attr("y", t().state.textHeight + 1.3 * t().state.padding).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.descriptions[0]).node().getBBox(), p = n.height, h = e.append("text").attr("x", t().state.padding).attr("y", p + t().state.padding * .4 + t().state.dividerMargin + t().state.textHeight).attr("class", "state-description"), a = !0, d = !0; i.descriptions.forEach(function (o) { a || (s(h, o, d), d = !1), a = !1; }); let m = e.append("line").attr("x1", t().state.padding).attr("y1", t().state.padding + p + t().state.dividerMargin / 2).attr("y2", t().state.padding + p + t().state.dividerMargin / 2).attr("class", "descr-divider"), x = h.node().getBBox(), c = Math.max(x.width, n.width); return m.attr("x2", c + 3 * t().state.padding), e.insert("rect", ":first-child").attr("x", t().state.padding).attr("y", t().state.padding).attr("width", c + 2 * t().state.padding).attr("height", x.height + p + 2 * t().state.padding).attr("rx", t().state.radius), e; }, "drawDescrState"), q = u((e, i, s) => { let g = t().state.padding, n = 2 * t().state.padding, p = e.node().getBBox(), h = p.width, a = p.x, d = e.append("text").attr("x", 0).attr("y", t().state.titleShift).attr("font-size", t().state.fontSize).attr("class", "state-title").text(i.id), x = d.node().getBBox().width + n, c = Math.max(x, h); c === h && (c = c + n); let o, w = e.node().getBBox(); i.doc, o = a - g, x > h && (o = (h - c) / 2 + g), Math.abs(a - w.x) < g && x > h && (o = a - (x - h) / 2); let y = 1 - t().state.textHeight; return e.insert("rect", ":first-child").attr("x", o).attr("y", y).attr("class", s ? "alt-composit" : "composit").attr("width", c).attr("height", w.height + t().state.textHeight + t().state.titleShift + 1).attr("rx", "0"), d.attr("x", o + g), x <= h && d.attr("x", a + (c - n) / 2 - x / 2 + g), e.insert("rect", ":first-child").attr("x", o).attr("y", t().state.titleShift - t().state.textHeight - t().state.padding).attr("width", c).attr("height", t().state.textHeight * 3).attr("rx", t().state.radius), e.insert("rect", ":first-child").attr("x", o).attr("y", t().state.titleShift - t().state.textHeight - t().state.padding).attr("width", c).attr("height", w.height + 3 + 2 * t().state.textHeight).attr("rx", t().state.radius), e; }, "addTitleAndBox"), Z = u(e => (e.append("circle").attr("class", "end-state-outer").attr("r", t().state.sizeUnit + t().state.miniPadding).attr("cx", t().state.padding + t().state.sizeUnit + t().state.miniPadding).attr("cy", t().state.padding + t().state.sizeUnit + t().state.miniPadding), e.append("circle").attr("class", "end-state-inner").attr("r", t().state.sizeUnit).attr("cx", t().state.padding + t().state.sizeUnit + 2).attr("cy", t().state.padding + t().state.sizeUnit + 2)), "drawEndState"), j = u((e, i) => { let s = t().state.forkWidth, g = t().state.forkHeight; if (i.parentId) {
    let n = s;
    s = g, g = n;
} return e.append("rect").style("stroke", "black").style("fill", "black").attr("width", s).attr("height", g).attr("x", t().state.padding).attr("y", t().state.padding); }, "drawForkJoinState"), K = u((e, i, s, g) => { let n = 0, p = g.append("text"); p.style("text-anchor", "start"), p.attr("class", "noteText"); let h = e.replace(/\r\n/g, "<br/>"); h = h.replace(/\n/g, "<br/>"); let a = h.split(T.lineBreakRegex), d = 1.25 * t().state.noteMargin; for (let m of a) {
    let x = m.trim();
    if (x.length > 0) {
        let c = p.append("tspan");
        if (c.text(x), d === 0) {
            let o = c.node().getBBox();
            d += o.height;
        }
        n += d, c.attr("x", i + t().state.noteMargin), c.attr("y", s + n + 1.25 * t().state.noteMargin);
    }
} return { textWidth: p.node().getBBox().width, textHeight: n }; }, "_drawLongText"), Q = u((e, i) => { i.attr("class", "state-note"); let s = i.append("rect").attr("x", 0).attr("y", t().state.padding), g = i.append("g"), { textWidth: n, textHeight: p } = K(e, 0, 0, g); return s.attr("height", p + 2 * t().state.noteMargin), s.attr("width", n + t().state.noteMargin * 2), s; }, "drawNote"), O = u(function (e, i) { let s = i.id, g = { id: s, label: i.id, width: 0, height: 0 }, n = e.append("g").attr("id", s).attr("class", "stateGroup"); i.type === "start" && D(n), i.type === "end" && Z(n), (i.type === "fork" || i.type === "join") && j(n, i), i.type === "note" && Q(i.note.text, n), i.type === "divider" && Y(n), i.type === "default" && i.descriptions.length === 0 && I(n, i), i.type === "default" && i.descriptions.length > 0 && $(n, i); let p = n.node().getBBox(); return g.width = p.width + 2 * t().state.padding, g.height = p.height + 2 * t().state.padding, g; }, "drawState"), J = 0, V = u(function (e, i, s) { let g = u(function (d) { switch (d) {
    case N.relationType.AGGREGATION: return "aggregation";
    case N.relationType.EXTENSION: return "extension";
    case N.relationType.COMPOSITION: return "composition";
    case N.relationType.DEPENDENCY: return "dependency";
} }, "getRelationType"); i.points = i.points.filter(d => !Number.isNaN(d.y)); let n = i.points, p = R().x(function (d) { return d.x; }).y(function (d) { return d.y; }).curve(W), h = e.append("path").attr("d", p(n)).attr("id", "edge" + J).attr("class", "transition"), a = ""; if (t().state.arrowMarkerAbsolute && (a = A(!0)), h.attr("marker-end", "url(" + a + "#" + g(N.relationType.DEPENDENCY) + "End)"), s.title !== void 0) {
    let d = e.append("g").attr("class", "stateLabel"), { x: m, y: x } = P.calcLabelPosition(i.points), c = T.getRows(s.title), o = 0, w = [], y = 0, S = 0;
    for (let r = 0; r <= c.length; r++) {
        let f = d.append("text").attr("text-anchor", "middle").text(c[r]).attr("x", m).attr("y", x + o), l = f.node().getBBox();
        y = Math.max(y, l.width), S = Math.min(S, l.x), v.info(l.x, m, x + o), o === 0 && (o = f.node().getBBox().height, v.info("Title height", o, x)), w.push(f);
    }
    let k = o * c.length;
    if (c.length > 1) {
        let r = (c.length - 1) * o * .5;
        w.forEach((f, l) => f.attr("y", x + l * o - r)), k = o * c.length;
    }
    let M = d.node().getBBox();
    d.insert("rect", ":first-child").attr("class", "box").attr("x", m - y / 2 - t().state.padding / 2).attr("y", x - k / 2 - t().state.padding / 2 - 3.5).attr("width", y + t().state.padding).attr("height", k + t().state.padding), v.info(M);
} J++; }, "drawEdge"), b, L = {}, tt = u(function () { }, "setConf"), et = u(function (e) { e.append("defs").append("marker").attr("id", "dependencyEnd").attr("refX", 19).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 19,7 L9,13 L14,7 L9,1 Z"); }, "insertMarkers"), at = u(function (e, i, s, g) { b = t().state; let n = t().securityLevel, p; n === "sandbox" && (p = z("#i" + i)); let h = n === "sandbox" ? z(p.nodes()[0].contentDocument.body) : z("body"), a = n === "sandbox" ? p.nodes()[0].contentDocument : document; v.debug("Rendering diagram " + e); let d = h.select(`[id='${i}']`); et(d); let m = g.db.getRootDoc(), x = d.append("g").attr("id", i + "-root"); X(m, x, void 0, !1, h, a, g); let c = b.padding, o = d.node().getBBox(), w = o.width + c * 2, y = o.height + c * 2, S = w * 1.75; G(d, y, S, b.useMaxWidth), d.attr("viewBox", `${o.x - b.padding}  ${o.y - b.padding} ` + w + " " + y); }, "draw"), it = u(e => e ? e.length * b.fontSizeFactor : 1, "getLabelWidth"), X = u((e, i, s, g, n, p, h) => { let a = new C({ compound: !0, multigraph: !0 }), d, m = !0; for (d = 0; d < e.length; d++)
    if (e[d].stmt === "relation") {
        m = !1;
        break;
    } s ? a.setGraph({ rankdir: "LR", multigraph: !0, compound: !0, ranker: "tight-tree", ranksep: m ? 1 : b.edgeLengthFactor, nodeSep: m ? 1 : 50, isMultiGraph: !0 }) : a.setGraph({ rankdir: "TB", multigraph: !0, compound: !0, ranksep: m ? 1 : b.edgeLengthFactor, nodeSep: m ? 1 : 50, ranker: "tight-tree", isMultiGraph: !0 }), a.setDefaultEdgeLabel(function () { return {}; }); let x = h.db.getStates(), c = h.db.getRelations(), o = Object.keys(x), w = !0; for (let r of o) {
    let f = x[r];
    s && (f.parentId = s);
    let l;
    if (f.doc) {
        let B = i.append("g").attr("id", f.id).attr("class", "stateGroup");
        if (l = X(f.doc, B, f.id, !g, n, p, h), w) {
            B = q(B, f, g);
            let E = B.node().getBBox();
            l.width = E.width, l.height = E.height + b.padding / 2, L[f.id] = { y: b.compositTitleSize };
        }
        else {
            let E = B.node().getBBox();
            l.width = E.width, l.height = E.height;
        }
    }
    else
        l = O(i, f, a);
    if (f.note) {
        let B = { descriptions: [], id: f.id + "-note", note: f.note, type: "note" }, E = O(i, B, a);
        f.note.position === "left of" ? (a.setNode(l.id + "-note", E), a.setNode(l.id, l)) : (a.setNode(l.id, l), a.setNode(l.id + "-note", E)), a.setParent(l.id, l.id + "-group"), a.setParent(l.id + "-note", l.id + "-group");
    }
    else
        a.setNode(l.id, l);
} v.debug("Count=", a.nodeCount(), a); let y = 0; c.forEach(function (r) { y++, v.debug("Setting edge", r), a.setEdge(r.id1, r.id2, { relation: r, width: it(r.title), height: b.labelHeight * T.getRows(r.title).length, labelpos: "c" }, "id" + y); }), U(a), v.debug("Graph after layout", a.nodes()); let S = i.node(); a.nodes().forEach(function (r) { r !== void 0 && a.node(r) !== void 0 ? (v.warn("Node " + r + ": " + JSON.stringify(a.node(r))), n.select("#" + S.id + " #" + r).attr("transform", "translate(" + (a.node(r).x - a.node(r).width / 2) + "," + (a.node(r).y + (L[r] ? L[r].y : 0) - a.node(r).height / 2) + " )"), n.select("#" + S.id + " #" + r).attr("data-x-shift", a.node(r).x - a.node(r).width / 2), p.querySelectorAll("#" + S.id + " #" + r + " .divider").forEach(l => { let B = l.parentElement, E = 0, H = 0; B && (B.parentElement && (E = B.parentElement.getBBox().width), H = parseInt(B.getAttribute("data-x-shift"), 10), Number.isNaN(H) && (H = 0)), l.setAttribute("x1", 0 - H + 8), l.setAttribute("x2", E - H - 8); })) : v.debug("No Node " + r + ": " + JSON.stringify(a.node(r))); }); let k = S.getBBox(); a.edges().forEach(function (r) { r !== void 0 && a.edge(r) !== void 0 && (v.debug("Edge " + r.v + " -> " + r.w + ": " + JSON.stringify(a.edge(r))), V(i, a.edge(r), a.edge(r).relation)); }), k = S.getBBox(); let M = { id: s || "root", label: s || "root", width: 0, height: 0 }; return M.width = k.width + 2 * b.padding, M.height = k.height + 2 * b.padding, v.debug("Doc rendered", M, a), M; }, "renderDoc"), rt = { setConf: tt, draw: at }, kt = { parser: _, get db() { return new N(1); }, renderer: rt, styles: F, init: u(e => { e.state || (e.state = {}), e.state.arrowMarkerAbsolute = e.arrowMarkerAbsolute; }, "init") };
export { kt as diagram };
