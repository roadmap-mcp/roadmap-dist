import { B as L, G as ie, g as ee, j as H, t as N, v as K, w as te } from "@nf-internal/chunk-DTCUIADE";
import "@nf-internal/chunk-RECHUXGF";
import { c as $ } from "@nf-internal/chunk-EAER6ZQJ";
import "@nf-internal/chunk-UYYL2GTR";
import "@nf-internal/chunk-FVDLKYOC";
import "@nf-internal/chunk-SMAQMSIK";
import "@nf-internal/chunk-AWGKBVI5";
import { a as J } from "@nf-internal/chunk-TTLGK2TK";
import { c as B, f as q } from "@nf-internal/chunk-44S5HDKK";
import "@nf-internal/chunk-PACPXHXL";
import "@nf-internal/chunk-TT7XXVKE";
import "@nf-internal/chunk-ZVGPI6ZI";
import { d as x } from "@nf-internal/chunk-ZGWTKG5Z";
import "@nf-internal/chunk-RNULGOC3";
import "@nf-internal/chunk-Z4DWJRNS";
import { a as c } from "@nf-internal/chunk-SVIUGILY";
import { c as Y, e as v, k as Q, l as I, q as p, r as X, s as _, t as P } from "@nf-internal/chunk-LAIZNMCN";
import "@nf-internal/chunk-7RHXFCZM";
import { a as O } from "@nf-internal/chunk-F5B6FRRL";
import { a as T } from "@nf-internal/chunk-RMOXI6XO";
import "@nf-internal/chunk-5HDY5C2T";
import { c as k } from "@nf-internal/chunk-6QY5OUOO";
import "@nf-internal/chunk-JE6VEUSL";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-XID2BBVI";
import { a as g, b as G } from "@nf-internal/chunk-OSQMNGTH";
import * as s from "@angular/core";
import { InjectionToken as y, inject as r, Injector as M, ViewContainerRef as ce, EventEmitter as S, NgZone as D, RendererFactory2 as le, ElementRef as U, ChangeDetectorRef as se, Renderer2 as V, booleanAttribute as W, QueryList as de, signal as he, computed as me } from "@angular/core";
import { Subject as m, merge as z, partition as ge } from "rxjs";
import { startWith as C, debounceTime as fe, distinctUntilChanged as pe, takeUntil as l, mergeMap as _e, mapTo as ke, mergeAll as Me, switchMap as ye, skipWhile as be, skip as ve } from "rxjs/operators";
import "@angular/common";
var Z = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuGroup", ""]], hostAttrs: ["role", "group", 1, "cdk-menu-group"], exportAs: ["cdkMenuGroup"], features: [s.\u0275\u0275ProvidersFeature([{ provide: O, useClass: O }])] });
} return i; })(), E = new y("cdk-menu"), d = (function (i) { return i[i.nextItem = 0] = "nextItem", i[i.previousItem = 1] = "previousItem", i[i.currentItem = 2] = "currentItem", i; })(d || {}), h = new y("cdk-menu-stack"), Ie = { provide: h, useFactory: () => r(h, { optional: !0, skipSelf: !0 }) || new R }, Te = i => ({ provide: h, useFactory: () => r(h, { optional: !0, skipSelf: !0 }) || R.inline(i) }), R = (() => { class i {
    id = r(T).getId("cdk-menu-stack-");
    _elements = [];
    _close = new m;
    _empty = new m;
    _hasFocus = new m;
    closed = this._close;
    hasFocus = this._hasFocus.pipe(C(!1), fe(0), pe());
    emptied = this._empty;
    _inlineMenuOrientation = null;
    static inline(e) { let t = new i; return t._inlineMenuOrientation = e, t; }
    push(e) { this._elements.push(e); }
    close(e, t) { let { focusNextOnEmpty: n, focusParentTrigger: o } = g({}, t); if (this._elements.indexOf(e) >= 0) {
        let a;
        do
            a = this._elements.pop(), this._close.next({ item: a, focusParentTrigger: o });
        while (a !== e);
        this.isEmpty() && this._empty.next(n);
    } }
    closeSubMenuOf(e) { let t = !1; if (this._elements.indexOf(e) >= 0)
        for (t = this.peek() !== e; this.peek() !== e;)
            this._close.next({ item: this._elements.pop() }); return t; }
    closeAll(e) { let { focusNextOnEmpty: t, focusParentTrigger: n } = g({}, e); if (!this.isEmpty()) {
        for (; !this.isEmpty();) {
            let o = this._elements.pop();
            o && this._close.next({ item: o, focusParentTrigger: n });
        }
        this._empty.next(t);
    } }
    isEmpty() { return !this._elements.length; }
    length() { return this._elements.length; }
    peek() { return this._elements[this._elements.length - 1]; }
    hasInlineMenu() { return this._inlineMenuOrientation != null; }
    inlineMenuOrientation() { return this._inlineMenuOrientation; }
    setHasFocus(e) { this._hasFocus.next(e); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: i, factory: i.\u0275fac });
} return i; })(), A = new y("cdk-menu-trigger"), Oe = new y("cdk-menu-scroll-strategy", { providedIn: "root", factory: () => { let i = r(M); return () => ee(i); } }), re = (() => { class i {
    static _openMenuTrigger;
    update(e) { i._openMenuTrigger !== e && (i._openMenuTrigger?.close(), i._openMenuTrigger = e); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: i, factory: i.\u0275fac, providedIn: "root" });
} return i; })(), oe = (() => { class i {
    injector = r(M);
    viewContainerRef = r(ce);
    menuStack = r(h);
    menuScrollStrategy = r(Oe);
    menuPosition;
    opened = new S;
    closed = new S;
    menuTemplateRef = null;
    menuData;
    transformOriginSelector = null;
    overlayRef = null;
    destroyed = new m;
    stopOutsideClicksListener = z(this.closed, this.destroyed);
    childMenu;
    _menuPortal;
    _childMenuInjector;
    ngOnDestroy() { this._destroyOverlay(), this.destroyed.next(), this.destroyed.complete(); }
    isOpen() { return !!this.overlayRef?.hasAttached(); }
    registerChildMenu(e) { this.childMenu = e; }
    getMenuContentPortal() { let e = this.menuTemplateRef !== this._menuPortal?.templateRef; return this.menuTemplateRef && (!this._menuPortal || e) && (this._menuPortal = new $(this.menuTemplateRef, this.viewContainerRef, this.menuData, this._getChildMenuInjector())), this._menuPortal; }
    isElementInsideMenuStack(e) { for (let t = e; t; t = t?.parentElement ?? null)
        if (t.getAttribute("data-cdk-menu-stack-id") === this.menuStack.id)
            return !0; return !1; }
    _destroyOverlay() { this.overlayRef && (this.overlayRef.dispose(), this.overlayRef = null); }
    _getChildMenuInjector() { return this._childMenuInjector = this._childMenuInjector || M.create({ providers: [{ provide: A, useValue: this }, { provide: h, useValue: this.menuStack }], parent: this.injector }), this._childMenuInjector; }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, hostVars: 2, hostBindings: function (t, n) { t & 2 && s.\u0275\u0275attribute("aria-controls", n.childMenu == null ? null : n.childMenu.id)("data-cdk-menu-stack-id", n.menuStack.id); } });
} return i; })();
var F = new y("cdk-menu-aim"), Se = 3, ne = 5, Ce = 300;
function De(i, u) { return (u.y - i.y) / (u.x - i.x); }
function Ee(i, u) { return i.y - u * i.x; }
function Re(i, u, e) { let { left: t, right: n, top: o, bottom: a } = i; return u * t + e >= o && u * t + e <= a || u * n + e >= o && u * n + e <= a || (o - e) / u >= t && (o - e) / u <= n || (a - e) / u >= t && (a - e) / u <= n; }
var Ae = (() => { class i {
    _ngZone = r(D);
    _renderer = r(le).createRenderer(null, null);
    _cleanupMousemove;
    _points = [];
    _menu;
    _pointerTracker;
    _timeoutId = null;
    _destroyed = new m;
    ngOnDestroy() { this._cleanupMousemove?.(), this._destroyed.next(), this._destroyed.complete(); }
    initialize(e, t) { this._menu = e, this._pointerTracker = t, this._subscribeToMouseMoves(); }
    toggle(e) { this._menu.orientation === "horizontal" && e(), this._checkConfigured(); let t = !!this._timeoutId; this._points.length > 1 && !t ? this._isMovingToSubmenu() ? this._startTimeout(e) : e() : t || e(); }
    _startTimeout(e) { let t = setTimeout(() => { this._pointerTracker.activeElement && t === this._timeoutId && e(), this._timeoutId = null; }, Ce); this._timeoutId = t; }
    _isMovingToSubmenu() { let e = this._getSubmenuBounds(); if (!e)
        return !1; let t = 0, n = this._points[this._points.length - 1]; for (let o = this._points.length - 2; o >= 0; o--) {
        let a = this._points[o], b = De(n, a);
        Re(e, b, Ee(n, b)) && t++;
    } return t >= Math.floor(ne / 2); }
    _getSubmenuBounds() { return this._pointerTracker?.previousElement?.getMenu()?.nativeElement.getBoundingClientRect(); }
    _checkConfigured() { }
    _subscribeToMouseMoves() { this._cleanupMousemove?.(), this._cleanupMousemove = this._ngZone.runOutsideAngular(() => { let e = 0; return this._renderer.listen(this._menu.nativeElement, "mousemove", t => { e % Se === 0 && (this._points.push({ x: t.clientX, y: t.clientY }), this._points.length > ne && this._points.shift()), e++; }); }); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275prov = s.\u0275\u0275defineInjectable({ token: i, factory: i.\u0275fac });
} return i; })(), $e = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkTargetMenuAim", ""]], exportAs: ["cdkTargetMenuAim"], features: [s.\u0275\u0275ProvidersFeature([{ provide: F, useClass: Ae }])] });
} return i; })();
function ae(i, u) { if (!u.isTrusted)
    return !1; let e = i.nativeElement, t = u.keyCode; return e.nodeName === "BUTTON" && !e.disabled ? t === 13 || t === 32 : e.nodeName === "A" ? t === 13 : !1; }
var Fe = (() => { class i extends oe {
    _elementRef = r(U);
    _ngZone = r(D);
    _changeDetectorRef = r(se);
    _inputModalityDetector = r(B);
    _directionality = r(k, { optional: !0 });
    _renderer = r(V);
    _injector = r(M);
    _cleanupMouseenter;
    _menuTracker = r(re);
    _parentMenu = r(E, { optional: !0 });
    _menuAim = r(F, { optional: !0 });
    constructor() { super(), this._setRole(), this._registerCloseHandler(), this._subscribeToMenuStackClosed(), this._subscribeToMouseEnter(), this._subscribeToMenuStackHasFocus(), this._setType(); }
    toggle() { this.isOpen() ? this.close() : this.open(); }
    open() { this._parentMenu || this._menuTracker.update(this), !this.isOpen() && this.menuTemplateRef != null && (this.opened.next(), this.overlayRef = this.overlayRef || L(this._injector, this._getOverlayConfig()), this.overlayRef.attach(this.getMenuContentPortal()), this._changeDetectorRef.markForCheck(), this._subscribeToOutsideClicks()); }
    close() { this.isOpen() && (this.closed.next(), this.overlayRef.detach(), this._changeDetectorRef.markForCheck()), this._closeSiblingTriggers(); }
    getMenu() { return this.childMenu; }
    ngOnChanges(e) { e.menuPosition && this.overlayRef && this.overlayRef.updatePositionStrategy(this._getOverlayPositionStrategy()); }
    ngOnDestroy() { this._cleanupMouseenter(), super.ngOnDestroy(); }
    _toggleOnKeydown(e) { let t = this._parentMenu?.orientation === "vertical"; switch (e.keyCode) {
        case 32:
        case 13:
            !c(e) && !ae(this._elementRef, e) && (this.toggle(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 39:
            c(e) || this._parentMenu && t && this._directionality?.value !== "rtl" && (e.preventDefault(), this.open(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 37:
            c(e) || this._parentMenu && t && this._directionality?.value === "rtl" && (e.preventDefault(), this.open(), this.childMenu?.focusFirstItem("keyboard"));
            break;
        case 40:
        case 38:
            c(e) || t || (e.preventDefault(), this.open(), e.keyCode === 40 ? this.childMenu?.focusFirstItem("keyboard") : this.childMenu?.focusLastItem("keyboard"));
            break;
    } }
    _handleClick() { this.toggle(), this.childMenu?.focusFirstItem("mouse"); }
    _setHasFocus(e) { this._parentMenu || this.menuStack.setHasFocus(e); }
    _subscribeToMouseEnter() { this._cleanupMouseenter = this._ngZone.runOutsideAngular(() => this._renderer.listen(this._elementRef.nativeElement, "mouseenter", () => { if (this._inputModalityDetector.mostRecentModality !== "touch" && !this.menuStack.isEmpty() && !this.isOpen()) {
        let e = () => this._ngZone.run(() => { this._closeSiblingTriggers(), this.open(); });
        this._menuAim ? this._menuAim.toggle(e) : e();
    } })); }
    _closeSiblingTriggers() { this._parentMenu ? !this.menuStack.closeSubMenuOf(this._parentMenu) && this.menuStack.peek() !== this._parentMenu && this.menuStack.closeAll() : this.menuStack.closeAll(); }
    _getOverlayConfig() { return new H({ positionStrategy: this._getOverlayPositionStrategy(), scrollStrategy: this.menuScrollStrategy(), direction: this._directionality || void 0 }); }
    _getOverlayPositionStrategy() { let e = N(this._injector, this._elementRef).withLockedPosition().withFlexibleDimensions(!1).withPositions(this._getOverlayPositions()); return this.transformOriginSelector && e.withTransformOriginOn(this.transformOriginSelector), e; }
    _getOverlayPositions() { return this.menuPosition ?? (!this._parentMenu || this._parentMenu.orientation === "horizontal" ? K : te); }
    _registerCloseHandler() { this._parentMenu || this.menuStack.closed.pipe(l(this.destroyed)).subscribe(({ item: e }) => { e === this.childMenu && this.close(); }); }
    _subscribeToOutsideClicks() { this.overlayRef && this.overlayRef.outsidePointerEvents().pipe(l(this.stopOutsideClicksListener)).subscribe(e => { let t = x(e), n = this._elementRef.nativeElement; t !== n && !n.contains(t) && (this.isElementInsideMenuStack(t) ? this._closeSiblingTriggers() : this.menuStack.closeAll()); }); }
    _subscribeToMenuStackHasFocus() { this._parentMenu || this.menuStack.hasFocus.pipe(l(this.destroyed)).subscribe(e => { e || this.menuStack.closeAll(); }); }
    _subscribeToMenuStackClosed() { this._parentMenu || this.menuStack.closed.subscribe(({ focusParentTrigger: e }) => { e && !this.menuStack.length() && this._elementRef.nativeElement.focus(); }); }
    _setRole() { this._parentMenu || this._elementRef.nativeElement.setAttribute("role", "button"); }
    _setType() { let e = this._elementRef.nativeElement; e.nodeName === "BUTTON" && !e.getAttribute("type") && e.setAttribute("type", "button"); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuTriggerFor", ""]], hostAttrs: [1, "cdk-menu-trigger"], hostVars: 2, hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("focusin", function () { return n._setHasFocus(!0); })("focusout", function () { return n._setHasFocus(!1); })("keydown", function (a) { return n._toggleOnKeydown(a); })("click", function () { return n._handleClick(); }), t & 2 && s.\u0275\u0275attribute("aria-haspopup", n.menuTemplateRef ? "menu" : null)("aria-expanded", n.menuTemplateRef == null ? null : n.isOpen()); }, inputs: { menuTemplateRef: [0, "cdkMenuTriggerFor", "menuTemplateRef"], menuPosition: [0, "cdkMenuPosition", "menuPosition"], menuData: [0, "cdkMenuTriggerData", "menuData"], transformOriginSelector: [0, "cdkMenuTriggerTransformOriginOn", "transformOriginSelector"] }, outputs: { opened: "cdkMenuOpened", closed: "cdkMenuClosed" }, exportAs: ["cdkMenuTriggerFor"], features: [s.\u0275\u0275ProvidersFeature([{ provide: A, useExisting: i }, Ie]), s.\u0275\u0275InheritDefinitionFeature, s.\u0275\u0275NgOnChangesFeature] });
} return i; })(), w = (() => { class i {
    _dir = r(k, { optional: !0 });
    _elementRef = r(U);
    _ngZone = r(D);
    _inputModalityDetector = r(B);
    _renderer = r(V);
    _cleanupMouseEnter;
    _menuAim = r(F, { optional: !0 });
    _menuStack = r(h);
    _parentMenu = r(E, { optional: !0 });
    _menuTrigger = r(Fe, { optional: !0, self: !0 });
    disabled = !1;
    typeaheadLabel = null;
    triggered = new S;
    get hasMenu() { return this._menuTrigger?.menuTemplateRef != null; }
    _tabindex = -1;
    closeOnSpacebarTrigger = !0;
    destroyed = new m;
    constructor() { this._setupMouseEnter(), this._setType(), this._isStandaloneItem() && (this._tabindex = 0); }
    ngOnDestroy() { this._cleanupMouseEnter?.(), this.destroyed.next(), this.destroyed.complete(); }
    focus() { this._elementRef.nativeElement.focus(); }
    trigger(e) { let { keepOpen: t } = g({}, e); !this.disabled && !this.hasMenu && (this.triggered.next(), t || this._menuStack.closeAll({ focusParentTrigger: !0 })); }
    isMenuOpen() { return !!this._menuTrigger?.isOpen(); }
    getMenu() { return this._menuTrigger?.getMenu(); }
    getMenuTrigger() { return this._menuTrigger; }
    getLabel() { return this.typeaheadLabel || this._elementRef.nativeElement.textContent?.trim() || ""; }
    _resetTabIndex() { this._isStandaloneItem() || (this._tabindex = -1); }
    _setTabIndex(e) { this.disabled || (!e || !this._menuStack.isEmpty()) && (this._tabindex = 0); }
    _handleClick(e) { this.disabled ? (e.preventDefault(), e.stopPropagation()) : this.trigger(); }
    _onKeydown(e) { switch (e.keyCode) {
        case 32:
        case 13:
            if (!c(e) && !ae(this._elementRef, e)) {
                let t = this._elementRef.nativeElement.nodeName;
                t !== "A" && t !== "BUTTON" && e.preventDefault(), this.trigger({ keepOpen: e.keyCode === 32 && !this.closeOnSpacebarTrigger });
            }
            break;
        case 39:
            c(e) || this._parentMenu && this._isParentVertical() && (this._dir?.value !== "rtl" ? this._forwardArrowPressed(e) : this._backArrowPressed(e));
            break;
        case 37:
            c(e) || this._parentMenu && this._isParentVertical() && (this._dir?.value !== "rtl" ? this._backArrowPressed(e) : this._forwardArrowPressed(e));
            break;
    } }
    _isStandaloneItem() { return !this._parentMenu; }
    _backArrowPressed(e) { let t = this._parentMenu; (this._menuStack.hasInlineMenu() || this._menuStack.length() > 1) && (e.preventDefault(), this._menuStack.close(t, { focusNextOnEmpty: this._menuStack.inlineMenuOrientation() === "horizontal" ? d.previousItem : d.currentItem, focusParentTrigger: !0 })); }
    _forwardArrowPressed(e) { !this.hasMenu && this._menuStack.inlineMenuOrientation() === "horizontal" && (e.preventDefault(), this._menuStack.closeAll({ focusNextOnEmpty: d.nextItem, focusParentTrigger: !0 })); }
    _setupMouseEnter() { if (!this._isStandaloneItem()) {
        let e = () => this._ngZone.run(() => this._menuStack.closeSubMenuOf(this._parentMenu));
        this._cleanupMouseEnter = this._ngZone.runOutsideAngular(() => this._renderer.listen(this._elementRef.nativeElement, "mouseenter", () => { this._inputModalityDetector.mostRecentModality !== "touch" && !this._menuStack.isEmpty() && !this.hasMenu && (this._menuAim ? this._menuAim.toggle(e) : e()); }));
    } }
    _isParentVertical() { return this._parentMenu?.orientation === "vertical"; }
    _setType() { let e = this._elementRef.nativeElement; e.nodeName === "BUTTON" && !e.getAttribute("type") && e.setAttribute("type", "button"); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuItem", ""]], hostAttrs: ["role", "menuitem", 1, "cdk-menu-item"], hostVars: 4, hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("blur", function () { return n._resetTabIndex(); })("focus", function () { return n._setTabIndex(); })("click", function (a) { return n._handleClick(a); })("keydown", function (a) { return n._onKeydown(a); }), t & 2 && (s.\u0275\u0275domProperty("tabIndex", n._tabindex), s.\u0275\u0275attribute("aria-disabled", n.disabled || null), s.\u0275\u0275classProp("cdk-menu-item-disabled", n.disabled)); }, inputs: { disabled: [2, "cdkMenuItemDisabled", "disabled", W], typeaheadLabel: [0, "cdkMenuitemTypeaheadLabel", "typeaheadLabel"] }, outputs: { triggered: "cdkMenuItemTriggered" }, exportAs: ["cdkMenuItem"] });
} return i; })(), j = class {
    _renderer;
    _items;
    _eventCleanups;
    _itemsSubscription;
    entered = new m;
    exited = new m;
    activeElement;
    previousElement;
    constructor(u, e) { this._renderer = u, this._items = e, this._bindEvents(), this.entered.subscribe(t => this.activeElement = t), this.exited.subscribe(() => { this.previousElement = this.activeElement, this.activeElement = void 0; }); }
    destroy() { this._cleanupEvents(), this._itemsSubscription?.unsubscribe(); }
    _bindEvents() { this._itemsSubscription = this._items.changes.pipe(C(this._items)).subscribe(() => { this._cleanupEvents(), this._eventCleanups = [], this._items.forEach(u => { let e = u._elementRef.nativeElement; this._eventCleanups.push(this._renderer.listen(e, "mouseenter", () => { this.entered.next(u); }), this._renderer.listen(e, "mouseout", () => { this.exited.next(u); })); }); }); }
    _cleanupEvents() { this._eventCleanups?.forEach(u => u()), this._eventCleanups = void 0; }
}, ue = (() => { class i extends Z {
    _focusMonitor = r(q);
    ngZone = r(D);
    _renderer = r(V);
    nativeElement = r(U).nativeElement;
    menuStack = r(h);
    menuAim = r(F, { optional: !0, self: !0 });
    dir = r(k, { optional: !0 });
    _allItems;
    id = r(T).getId("cdk-menu-");
    items = new de;
    orientation = "vertical";
    isInline = !1;
    keyManager;
    destroyed = new m;
    triggerItem;
    pointerTracker;
    _menuStackHasFocus = he(!1);
    _tabIndexSignal = me(() => { let e = this._menuStackHasFocus() ? -1 : 0; return this.isInline ? e : null; });
    ngAfterContentInit() { this.isInline || this.menuStack.push(this), this._setItems(), this._setKeyManager(), this._handleFocus(), this._subscribeToMenuStackHasFocus(), this._subscribeToMenuOpen(), this._subscribeToMenuStackClosed(), this._setUpPointerTracker(); }
    ngOnDestroy() { this._focusMonitor.stopMonitoring(this.nativeElement), this.keyManager?.destroy(), this.destroyed.next(), this.destroyed.complete(), this.pointerTracker?.destroy(); }
    focusFirstItem(e = "program") { this.keyManager.setFocusOrigin(e), this.keyManager.setFirstItemActive(); }
    focusLastItem(e = "program") { this.keyManager.setFocusOrigin(e), this.keyManager.setLastItemActive(); }
    setActiveMenuItem(e) { this.keyManager?.setActiveItem(e); }
    _getTabIndex() { return this._tabIndexSignal(); }
    closeOpenMenu(e, t) { let { focusParentTrigger: n } = g({}, t), o = this.keyManager, a = this.triggerItem; e === a?.getMenuTrigger()?.getMenu() && (a?.getMenuTrigger()?.close(), n && (a ? o.setActiveItem(a) : o.setFirstItemActive())); }
    _setItems() { this._allItems.changes.pipe(C(this._allItems), l(this.destroyed)).subscribe(e => { this.items.reset(e.filter(t => t._parentMenu === this)), this.items.notifyOnChanges(); }); }
    _setKeyManager() { this.keyManager = new J(this.items).withWrap().withTypeAhead().withHomeAndEnd().skipPredicate(() => !1), this.orientation === "horizontal" ? this.keyManager.withHorizontalOrientation(this.dir?.value || "ltr") : this.keyManager.withVerticalOrientation(); }
    _subscribeToMenuOpen() { let e = z(this.items.changes, this.destroyed); this.items.changes.pipe(C(this.items), _e(t => t.filter(n => n.hasMenu).map(n => n.getMenuTrigger().opened.pipe(ke(n), l(e)))), Me(), ye(t => (this.triggerItem = t, t.getMenuTrigger().closed)), l(this.destroyed)).subscribe(() => this.triggerItem = void 0); }
    _subscribeToMenuStackClosed() { this.menuStack.closed.pipe(l(this.destroyed)).subscribe(({ item: e, focusParentTrigger: t }) => this.closeOpenMenu(e, { focusParentTrigger: t })); }
    _subscribeToMenuStackHasFocus() { this.isInline && this.menuStack.hasFocus.pipe(l(this.destroyed)).subscribe(e => { this._menuStackHasFocus.set(e); }); }
    _setUpPointerTracker() { this.menuAim && (this.ngZone.runOutsideAngular(() => { this.pointerTracker = new j(this._renderer, this.items); }), this.menuAim.initialize(this, this.pointerTracker)); }
    _handleFocus() { this._focusMonitor.monitor(this.nativeElement, !1).pipe(l(this.destroyed)).subscribe(e => { e !== null && e !== "mouse" && this.focusFirstItem(e); }); }
    static \u0275fac = (() => { let e; return function (n) { return (e || (e = s.\u0275\u0275getInheritedFactory(i)))(n || i); }; })();
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, contentQueries: function (t, n, o) { if (t & 1 && s.\u0275\u0275contentQuery(o, w, 5), t & 2) {
            let a;
            s.\u0275\u0275queryRefresh(a = s.\u0275\u0275loadQuery()) && (n._allItems = a);
        } }, hostAttrs: ["role", "menu"], hostVars: 4, hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("focusin", function () { return n.menuStack.setHasFocus(!0); })("focusout", function () { return n.menuStack.setHasFocus(!1); }), t & 2 && (s.\u0275\u0275domProperty("tabIndex", n._getTabIndex())("id", n.id), s.\u0275\u0275attribute("aria-orientation", n.orientation)("data-cdk-menu-stack-id", n.menuStack.id)); }, inputs: { id: "id" }, features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), et = (() => { class i extends ue {
    _parentTrigger = r(A, { optional: !0 });
    closed = new S;
    orientation = "vertical";
    isInline = !this._parentTrigger;
    constructor() { super(), this.destroyed.subscribe(this.closed), this._parentTrigger?.registerChildMenu(this); }
    ngAfterContentInit() { super.ngAfterContentInit(), this._subscribeToMenuStackEmptied(); }
    ngOnDestroy() { super.ngOnDestroy(), this.closed.complete(); }
    _handleKeyEvent(e) { let t = this.keyManager; switch (e.keyCode) {
        case 37:
        case 39:
            c(e) || (e.preventDefault(), t.setFocusOrigin("keyboard"), t.onKeydown(e));
            break;
        case 27:
            c(e) || (e.preventDefault(), this.menuStack.close(this, { focusNextOnEmpty: d.currentItem, focusParentTrigger: !0 }));
            break;
        case 9:
            c(e, "altKey", "metaKey", "ctrlKey") || this.menuStack.closeAll({ focusParentTrigger: !0 });
            break;
        default: t.onKeydown(e);
    } }
    _toggleMenuFocus(e) { let t = this.keyManager; switch (e) {
        case d.nextItem:
            t.setFocusOrigin("keyboard"), t.setNextItemActive();
            break;
        case d.previousItem:
            t.setFocusOrigin("keyboard"), t.setPreviousItemActive();
            break;
        case d.currentItem:
            t.activeItem && (t.setFocusOrigin("keyboard"), t.setActiveItem(t.activeItem));
            break;
    } }
    _subscribeToMenuStackEmptied() { this.menuStack.emptied.pipe(l(this.destroyed)).subscribe(e => this._toggleMenuFocus(e)); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenu", ""]], hostAttrs: ["role", "menu", 1, "cdk-menu"], hostVars: 2, hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("keydown", function (a) { return n._handleKeyEvent(a); }), t & 2 && s.\u0275\u0275classProp("cdk-menu-inline", n.isInline); }, outputs: { closed: "closed" }, exportAs: ["cdkMenu"], features: [s.\u0275\u0275ProvidersFeature([{ provide: Z, useExisting: i }, { provide: E, useExisting: i }, Te("vertical")]), s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), tt = (() => { class i extends ue {
    orientation = "horizontal";
    isInline = !0;
    ngAfterContentInit() { super.ngAfterContentInit(), this._subscribeToMenuStackEmptied(); }
    _handleKeyEvent(e) { let t = this.keyManager; switch (e.keyCode) {
        case 38:
        case 40:
        case 37:
        case 39:
            if (!c(e) && (e.keyCode === 37 || e.keyCode === 39)) {
                e.preventDefault();
                let o = t.activeItem?.isMenuOpen();
                t.activeItem?.getMenuTrigger()?.close(), t.setFocusOrigin("keyboard"), t.onKeydown(e), o && t.activeItem?.getMenuTrigger()?.open();
            }
            break;
        case 27:
            c(e) || (e.preventDefault(), t.activeItem?.getMenuTrigger()?.close());
            break;
        case 9:
            c(e, "altKey", "metaKey", "ctrlKey") || t.activeItem?.getMenuTrigger()?.close();
            break;
        default: t.onKeydown(e);
    } }
    _toggleOpenMenu(e) { let t = this.keyManager; switch (e) {
        case d.nextItem:
            t.setFocusOrigin("keyboard"), t.setNextItemActive(), t.activeItem?.getMenuTrigger()?.open();
            break;
        case d.previousItem:
            t.setFocusOrigin("keyboard"), t.setPreviousItemActive(), t.activeItem?.getMenuTrigger()?.open();
            break;
        case d.currentItem:
            t.activeItem && (t.setFocusOrigin("keyboard"), t.setActiveItem(t.activeItem));
            break;
    } }
    _subscribeToMenuStackEmptied() { this.menuStack?.emptied.pipe(l(this.destroyed)).subscribe(e => this._toggleOpenMenu(e)); }
    static \u0275fac = (() => { let e; return function (n) { return (e || (e = s.\u0275\u0275getInheritedFactory(i)))(n || i); }; })();
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuBar", ""]], hostAttrs: ["role", "menubar", 1, "cdk-menu-bar"], hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("keydown", function (a) { return n._handleKeyEvent(a); }); }, exportAs: ["cdkMenuBar"], features: [s.\u0275\u0275ProvidersFeature([{ provide: Z, useExisting: i }, { provide: E, useExisting: i }, { provide: h, useFactory: () => R.inline("horizontal") }]), s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), f = (() => { class i extends w {
    checked = !1;
    closeOnSpacebarTrigger = !1;
    static \u0275fac = (() => { let e; return function (n) { return (e || (e = s.\u0275\u0275getInheritedFactory(i)))(n || i); }; })();
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, hostVars: 2, hostBindings: function (t, n) { t & 2 && s.\u0275\u0275attribute("aria-checked", !!n.checked)("aria-disabled", n.disabled || null); }, inputs: { checked: [2, "cdkMenuItemChecked", "checked", W] }, features: [s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), it = (() => { class i extends f {
    _selectionDispatcher = r(O);
    _id = r(T).getId("cdk-menu-item-radio-");
    _removeDispatcherListener;
    constructor() { super(), this._removeDispatcherListener = this._selectionDispatcher.listen(e => { this.checked = this._id === e; }); }
    ngOnDestroy() { super.ngOnDestroy(), this._removeDispatcherListener(); }
    trigger(e) { super.trigger(e), this.disabled || this._selectionDispatcher.notify(this._id, ""); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuItemRadio", ""]], hostAttrs: ["role", "menuitemradio"], hostVars: 2, hostBindings: function (t, n) { t & 2 && s.\u0275\u0275classProp("cdk-menu-item-radio", !0); }, exportAs: ["cdkMenuItemRadio"], features: [s.\u0275\u0275ProvidersFeature([{ provide: f, useExisting: i }, { provide: w, useExisting: f }]), s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), nt = (() => { class i extends f {
    trigger(e) { super.trigger(e), this.disabled || (this.checked = !this.checked); }
    static \u0275fac = (() => { let e; return function (n) { return (e || (e = s.\u0275\u0275getInheritedFactory(i)))(n || i); }; })();
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkMenuItemCheckbox", ""]], hostAttrs: ["role", "menuitemcheckbox"], hostVars: 2, hostBindings: function (t, n) { t & 2 && s.\u0275\u0275classProp("cdk-menu-item-checkbox", !0); }, exportAs: ["cdkMenuItemCheckbox"], features: [s.\u0275\u0275ProvidersFeature([{ provide: f, useExisting: i }, { provide: w, useExisting: f }]), s.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), we = K.map(i => { let u = i.overlayX === "start" ? 2 : -2, e = i.overlayY === "top" ? 2 : -2; return G(g({}, i), { offsetX: u, offsetY: e }); }), st = (() => { class i extends oe {
    _injector = r(M);
    _directionality = r(k, { optional: !0 });
    _menuTracker = r(re);
    _changeDetectorRef = r(se);
    disabled = !1;
    constructor() { super(), this._setMenuStackCloseListener(); }
    open(e) { this._open(null, e), this._changeDetectorRef.markForCheck(); }
    close() { this.menuStack.closeAll(); }
    _openOnContextMenu(e) { this.disabled || (e.preventDefault(), e.stopPropagation(), this._menuTracker.update(this), this._open(e, { x: e.clientX, y: e.clientY }), e.button === 2 ? this.childMenu?.focusFirstItem("mouse") : e.button === 0 ? this.childMenu?.focusFirstItem("keyboard") : this.childMenu?.focusFirstItem("program")); }
    _getOverlayConfig(e) { return new H({ positionStrategy: this._getOverlayPositionStrategy(e), scrollStrategy: this.menuScrollStrategy(), direction: this._directionality || void 0 }); }
    _getOverlayPositionStrategy(e) { let t = N(this._injector, e).withLockedPosition().withGrowAfterOpen().withPositions(this.menuPosition ?? we); return this.transformOriginSelector && t.withTransformOriginOn(this.transformOriginSelector), t; }
    _setMenuStackCloseListener() { this.menuStack.closed.pipe(l(this.destroyed)).subscribe(({ item: e }) => { e === this.childMenu && this.isOpen() && (this.closed.next(), this.overlayRef.detach(), this.childMenu = void 0, this._changeDetectorRef.markForCheck()); }); }
    _subscribeToOutsideClicks(e) { if (this.overlayRef) {
        let t = this.overlayRef.outsidePointerEvents();
        if (e) {
            let [n, o] = ge(t, ({ type: a }) => a === "auxclick");
            t = z(o.pipe(be((a, b) => e.ctrlKey && b === 0 && a.ctrlKey)), n.pipe(ve(1)));
        }
        t.pipe(l(this.stopOutsideClicksListener)).subscribe(n => { this.isElementInsideMenuStack(x(n)) || this.menuStack.closeAll(); });
    } }
    _open(e, t) { this.disabled || (this.isOpen() ? (this.menuStack.closeSubMenuOf(this.childMenu), this.overlayRef.getConfig().positionStrategy.setOrigin(t), this.overlayRef.updatePosition()) : (this.opened.next(), this.overlayRef ? (this.overlayRef.getConfig().positionStrategy.setOrigin(t), this.overlayRef.updatePosition()) : this.overlayRef = L(this._injector, this._getOverlayConfig(t)), this.overlayRef.attach(this.getMenuContentPortal()), this._subscribeToOutsideClicks(e))); }
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275dir = s.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkContextMenuTriggerFor", ""]], hostVars: 1, hostBindings: function (t, n) { t & 1 && s.\u0275\u0275listener("contextmenu", function (a) { return n._openOnContextMenu(a); }), t & 2 && s.\u0275\u0275attribute("data-cdk-menu-stack-id", null); }, inputs: { menuTemplateRef: [0, "cdkContextMenuTriggerFor", "menuTemplateRef"], menuPosition: [0, "cdkContextMenuPosition", "menuPosition"], menuData: [0, "cdkContextMenuTriggerData", "menuData"], transformOriginSelector: [0, "cdkContextMenuTriggerTransformOriginOn", "transformOriginSelector"], disabled: [2, "cdkContextMenuDisabled", "disabled", W] }, outputs: { opened: "cdkContextMenuOpened", closed: "cdkContextMenuClosed" }, exportAs: ["cdkContextMenuTriggerFor"], features: [s.\u0275\u0275ProvidersFeature([{ provide: A, useExisting: i }, { provide: h, useClass: R }]), s.\u0275\u0275InheritDefinitionFeature] });
} return i; })();
var rt = (() => { class i {
    static \u0275fac = function (t) { return new (t || i); };
    static \u0275mod = s.\u0275\u0275defineNgModule({ type: i });
    static \u0275inj = s.\u0275\u0275defineInjector({ imports: [ie] });
} return i; })();
export { E as CDK_MENU, st as CdkContextMenuTrigger, et as CdkMenu, tt as CdkMenuBar, ue as CdkMenuBase, Z as CdkMenuGroup, w as CdkMenuItem, nt as CdkMenuItemCheckbox, it as CdkMenuItemRadio, f as CdkMenuItemSelectable, rt as CdkMenuModule, Fe as CdkMenuTrigger, oe as CdkMenuTriggerBase, $e as CdkTargetMenuAim, re as ContextMenuTracker, d as FocusNext, F as MENU_AIM, Oe as MENU_SCROLL_STRATEGY, h as MENU_STACK, A as MENU_TRIGGER, R as MenuStack, re as MenuTracker, Te as PARENT_OR_NEW_INLINE_MENU_STACK_PROVIDER, Ie as PARENT_OR_NEW_MENU_STACK_PROVIDER, j as PointerFocusTracker, Ae as TargetMenuAim };
