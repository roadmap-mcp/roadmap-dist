import { a as o, b as e } from "@nf-internal/chunk-RKUVKBC6";
import "@nf-internal/chunk-QP3MATMC";
import "@nf-internal/chunk-X5ONEG5D";
import "@nf-internal/chunk-3UW5LP2A";
import "@nf-internal/chunk-WVCFK4LD";
import "@nf-internal/chunk-GDGZBOQC";
import "@nf-internal/chunk-4PKWXC3U";
import "@nf-internal/chunk-PFHS2QSV";
import "@nf-internal/chunk-ST43FWUC";
import "@nf-internal/chunk-JKFADCWD";
import "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import "@nf-internal/chunk-LEJRRF65";
import "@nf-internal/chunk-RZWXGGKD";
import { a as r } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
var m = r(t => `${o(t)}
  .swimlane.cluster rect {
    stroke: ${t.clusterBorder} !important;
  }
  [data-look="neo"].cluster rect {
    filter: none;
  }
`, "getStyles"), i = m, B = e({ defaultLayout: "swimlane", styles: i });
export { B as diagram };
