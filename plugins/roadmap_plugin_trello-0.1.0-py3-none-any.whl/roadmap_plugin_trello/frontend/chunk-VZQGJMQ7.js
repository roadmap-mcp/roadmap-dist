import { a as o, b as d, c, d as i, e as l, g as u, s as v, w as g, y as m } from "@nf-internal/chunk-EPGORQP5";
var p = class extends m {
    static { o(this, "RailroadPegTokenBuilder"); }
    constructor() { super(["railroad-peg-beta"]); }
}, h = o(a => {
    let e = a.slice(1, -1), r = "";
    for (let t = 0; t < e.length; t++) {
        let n = e[t];
        if (n === "\\" && t + 1 < e.length) {
            t++;
            let s = e[t];
            switch (s) {
                case "n":
                    r += `
`;
                    break;
                case "r":
                    r += "\r";
                    break;
                case "t":
                    r += "	";
                    break;
                default: r += s;
            }
            continue;
        }
        r += n;
    }
    return r;
}, "decodeEscapedString"), f = class extends g {
    static { o(this, "RailroadPegValueConverter"); }
    runConverter(a, e, r) { let t = super.runConverter(a, e, r); if (a.name === "TITLE" && typeof t == "string") {
        let n = t.trim();
        if (n.startsWith('"') && n.endsWith('"') || n.startsWith("'") && n.endsWith("'"))
            return h(n);
    } return t; }
    runCustomConverter(a, e, r) { if (a.name === "PEG_STRING")
        return h(e); }
}, C = { parser: { TokenBuilder: o(() => new p, "TokenBuilder"), ValueConverter: o(() => new f, "ValueConverter") } };
function R(a = l) { let e = i(c(a), u), r = i(d({ shared: e }), v, C); return e.ServiceRegistry.register(r), { shared: e, RailroadPeg: r }; }
o(R, "createRailroadPegServices");
export { C as a, R as b };
