import { d as m } from "@nf-internal/chunk-OSQMNGTH";
var R = m(e => {
    "use strict";
    Object.defineProperty(e, "__esModule", { value: !0 });
    e.BLANK_URL = e.relativeFirstCharacters = e.whitespaceEscapeCharsRegex = e.urlSchemeRegex = e.ctrlCharactersRegex = e.htmlCtrlEntityRegex = e.htmlEntitiesRegex = e.invalidProtocolRegex = void 0;
    e.invalidProtocolRegex = /^([^\w]*)(javascript|data|vbscript)/im;
    e.htmlEntitiesRegex = /&#(\w+)(^\w|;)?/g;
    e.htmlCtrlEntityRegex = /&(newline|tab);/gi;
    e.ctrlCharactersRegex = /[\u0000-\u001F\u007F-\u009F\u2000-\u200D\uFEFF]/gim;
    e.urlSchemeRegex = /^.+(:|&colon;)/gim;
    e.whitespaceEscapeCharsRegex = /(\\|%5[cC])((%(6[eE]|72|74))|[nrt])/g;
    e.relativeFirstCharacters = [".", "/"];
    e.BLANK_URL = "about:blank";
});
var v = m(s => {
    "use strict";
    Object.defineProperty(s, "__esModule", { value: !0 });
    s.sanitizeUrl = p;
    var t = R();
    function d(r) { return t.relativeFirstCharacters.indexOf(r[0]) > -1; }
    function x(r) { var c = r.replace(t.ctrlCharactersRegex, ""); return c.replace(t.htmlEntitiesRegex, function (a, i) { return String.fromCharCode(i); }); }
    function C(r) { return URL.canParse(r); }
    function g(r) { try {
        return decodeURIComponent(r);
    }
    catch {
        return r;
    } }
    function p(r) { if (!r)
        return t.BLANK_URL; var c, a = g(r.trim()); do
        a = x(a).replace(t.htmlCtrlEntityRegex, "").replace(t.ctrlCharactersRegex, "").replace(t.whitespaceEscapeCharsRegex, "").trim(), a = g(a), c = a.match(t.ctrlCharactersRegex) || a.match(t.htmlEntitiesRegex) || a.match(t.htmlCtrlEntityRegex) || a.match(t.whitespaceEscapeCharsRegex);
    while (c && c.length > 0); var i = a; if (!i)
        return t.BLANK_URL; if (d(i))
        return i; var h = i.trimStart(), u = h.match(t.urlSchemeRegex); if (!u)
        return i; var n = u[0].toLowerCase().trim(); if (t.invalidProtocolRegex.test(n))
        return t.BLANK_URL; var o = h.replace(/\\/g, "/"); if (n === "mailto:" || n.includes("://"))
        return o; if (n === "http:" || n === "https:") {
        if (!C(o))
            return t.BLANK_URL;
        var l = new URL(o);
        return l.protocol = l.protocol.toLowerCase(), l.hostname = l.hostname.toLowerCase(), l.toString();
    } return o; }
});
export { v as a };
