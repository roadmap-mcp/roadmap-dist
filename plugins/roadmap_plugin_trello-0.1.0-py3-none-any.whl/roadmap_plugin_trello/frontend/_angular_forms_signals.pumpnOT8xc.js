import { A as Ne, B as J, C as be, E as ee, b as g, c as h, d as u, e as fe, f as me, g as v, h as Z, i as K, j as X, k as $, l as W, m as Q, n as Y, p as E, q as x, w as ge, x as he, y as ve, z as pe } from "@nf-internal/chunk-ABK7YORT";
import { a as z, b as H, f as q } from "@nf-internal/chunk-OSQMNGTH";
import * as m from "@angular/core";
import { InjectionToken as B, resource as Ee, \u0275isPromise as te, linkedSignal as ie, inject as f, \u0275RuntimeError as T, untracked as y, input as oe, Renderer2 as ye, DestroyRef as Ae, computed as D, Injector as De, ElementRef as Me, signal as Re, afterRenderEffect as Te, effect as Fe } from "@angular/core";
import { Validators as Ce, NG_VALUE_ACCESSOR as we, NgControl as Se } from "@angular/forms";
import { httpResource as _e } from "@angular/common/http";
import "@angular/core/primitives/signals";
var ae = new B("");
function ft(e) { return [{ provide: ae, useValue: e }]; }
function mt(e, t) { h(e), g.unwrapFieldPath(e).builder.addDisabledReasonRule(s => { let n = !0; return typeof t == "string" ? n = t : t && (n = t(s)), typeof n == "string" ? { fieldTree: s.fieldTree, message: n } : n ? { fieldTree: s.fieldTree } : void 0; }); }
function gt(e, t) { h(e), g.unwrapFieldPath(e).builder.addHiddenRule(t); }
function ht(e, t = () => !0) { h(e), g.unwrapFieldPath(e).builder.addReadonlyRule(t); }
function ue(e) { let t = e; return typeof t.length == "number" ? t.length : t.size; }
function d(e, t) { return e instanceof Function ? e(t) : e; }
function N(e) { return typeof e == "number" ? isNaN(e) : e === "" || e === !1 || e == null; }
function re(e) { return e === void 0 ? [] : Array.isArray(e) ? e : [e]; }
function b(e, t) { h(e), g.unwrapFieldPath(e).builder.addSyncErrorRule(s => E(t(s), s.fieldTree)); }
function Ie(e) { return new F(e); }
function Oe(e, t) { return new C(e, t); }
function Le(e, t) { return new w(e, t); }
function Ve(e, t) { return new S(e, t); }
function ke(e, t) { return new _(e, t); }
function Pe(e, t) { return new I(e, t); }
function Be(e) { return new O(e); }
var l = class {
    __brand = void 0;
    kind = "";
    fieldTree;
    message;
    constructor(t) { t && Object.assign(this, t); }
}, F = class extends l {
    kind = "required";
}, C = class extends l {
    min;
    kind = "min";
    constructor(t, r) { super(r), this.min = t; }
}, w = class extends l {
    max;
    kind = "max";
    constructor(t, r) { super(r), this.max = t; }
}, S = class extends l {
    minLength;
    kind = "minLength";
    constructor(t, r) { super(r), this.minLength = t; }
}, _ = class extends l {
    maxLength;
    kind = "maxLength";
    constructor(t, r) { super(r), this.maxLength = t; }
}, I = class extends l {
    pattern;
    kind = "pattern";
    constructor(t, r) { super(r), this.pattern = t; }
}, O = class extends l {
    kind = "email";
}, L = class extends l {
    kind = "parse";
}, vt = l, je = /^(?=.{1,254}$)(?=.{1,64}@)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
function pt(e, t) { b(e, r => { if (!N(r.value()) && !je.test(r.value()))
    return t?.error ? d(t.error, r) : Be({ message: d(t?.message, r) }); }); }
function Nt(e, t, r) { let s = u(e, v(), n => typeof t == "number" ? t : t(n)); u(e, $, ({ state: n }) => n.metadata(s)()), b(e, n => { if (N(n.value()))
    return; let i = n.state.metadata(s)(); if (i === void 0 || Number.isNaN(i))
    return; let o = n.value(); if ((!o && o !== 0 ? NaN : Number(o)) > i)
    return r?.error ? d(r.error, n) : Le(i, { message: d(r?.message, n) }); }); }
function bt(e, t, r) { let s = u(e, v(), n => typeof t == "number" ? t : t(n)); u(e, Q, ({ state: n }) => n.metadata(s)()), b(e, n => { if (N(n.value()))
    return; let i = n.state.metadata(s)(); if (i !== void 0 && ue(n.value()) > i)
    return r?.error ? d(r.error, n) : ke(i, { message: d(r?.message, n) }); }); }
function Et(e, t, r) { let s = u(e, v(), n => typeof t == "number" ? t : t(n)); u(e, X, ({ state: n }) => n.metadata(s)()), b(e, n => { if (N(n.value()))
    return; let i = n.state.metadata(s)(); if (i === void 0 || Number.isNaN(i))
    return; let o = n.value(); if ((!o && o !== 0 ? NaN : Number(o)) < i)
    return r?.error ? d(r.error, n) : Oe(i, { message: d(r?.message, n) }); }); }
function yt(e, t, r) { let s = u(e, v(), n => typeof t == "number" ? t : t(n)); u(e, W, ({ state: n }) => n.metadata(s)()), b(e, n => { if (N(n.value()))
    return; let i = n.state.metadata(s)(); if (i !== void 0 && ue(n.value()) < i)
    return r?.error ? d(r.error, n) : Ve(i, { message: d(r?.message, n) }); }); }
function At(e, t, r) { let s = u(e, v(), n => t instanceof RegExp ? t : t(n)); u(e, Y, ({ state: n }) => n.metadata(s)()), b(e, n => { if (N(n.value()))
    return; let i = n.state.metadata(s)(); if (i !== void 0 && !i.test(n.value()))
    return r?.error ? d(r.error, n) : Pe(i, { message: d(r?.message, n) }); }); }
function Dt(e, t) { let r = u(e, v(), s => t?.when ? t.when(s) : !0); u(e, K, ({ state: s }) => s.metadata(r)()), b(e, s => { if (s.state.metadata(r)() && N(s.value()))
    return t?.error ? d(t.error, s) : Ie({ message: d(t?.message, s) }); }); }
function de(e, t) { h(e); let r = g.unwrapFieldPath(e), s = Z(t.factory); u(e, s, n => { let o = n.stateOf(e).validationState; if (!(o.shouldSkipValidation() || !o.syncValid()))
    return t.params(n); }), r.builder.addAsyncErrorRule(n => { let i = n.state.metadata(s), o; switch (i.status()) {
    case "idle": return;
    case "loading":
    case "reloading": return "pending";
    case "resolved":
    case "local": return i.hasValue() ? (o = t.onSuccess(i.value(), n), E(o, n.fieldTree)) : void 0;
    case "error": return o = t.onError(i.error(), n), E(o, n.fieldTree);
} }); }
function Ue(e, t) { h(e), g.unwrapFieldPath(e).builder.addSyncTreeErrorRule(s => E(t(s), s.fieldTree)); }
function Mt(e, t) { let r = u(e, v(), s => { let n = typeof t == "function" ? t(s) : t; return n ? n["~standard"].validate(s.value()) : void 0; }); Ue(e, ({ state: s, fieldTreeOf: n }) => { let i = s.metadata(r)(); return !i || te(i) ? [] : i?.issues?.map(o => ne(n(e), o)) ?? []; }), de(e, { params: ({ state: s }) => { let n = s.metadata(r)(); return n && te(n) ? n : void 0; }, factory: s => Ee({ params: s, loader: i => q(null, [i], function* ({ params: n }) { return (yield n)?.issues ?? []; }) }), onSuccess: (s, { fieldTreeOf: n }) => s.map(i => ne(n(e), i)), onError: () => { } }); }
function Ge(e, t) { return new V(e, t); }
function ne(e, t) { let r = e; for (let s of t.path ?? []) {
    let n = typeof s == "object" ? s.key : s;
    r = r[n];
} return E(Ge(t, { message: t.message }), r); }
var V = class extends l {
    issue;
    kind = "standardSchema";
    constructor(t, r) { super(r), this.issue = t; }
};
function Rt(e, t) { de(e, { params: t.request, factory: r => _e(r, t.options), onSuccess: t.onSuccess, onError: t.onError }); }
function Tt(e, t) { h(e); let r = g.unwrapFieldPath(e), s = ze(t); r.builder.addMetadataRule(x, () => s); }
function ze(e) { return typeof e == "function" ? e : e === "blur" ? qe() : e > 0 ? He(e) : Ze; }
function He(e) { return (t, r) => new Promise(s => { let n, i = () => { clearTimeout(n), s(); }; n = setTimeout(() => { r.removeEventListener("abort", i), s(); }, e), r.addEventListener("abort", i, { once: !0 }); }); }
function qe() { return (e, t) => new Promise(r => { t.addEventListener("abort", () => r(), { once: !0 }); }); }
function Ze() { }
var le = new B("");
function ce(e, t, r) { let s = ie({ source: e, computation: () => [] }), n = i => { let o = r(i); s.set(re(o.error)), o.value !== void 0 && t(o.value), s.set(re(o.error)); }; return { errors: s.asReadonly(), setRawValue: n }; }
function Ft(e, t) { let { parse: r, format: s } = t, n = ce(e, e.set, r), i = f(le, { self: !0, optional: !0 }); i && i.set(n.errors); let o = ie(() => s(e())), a = o; a.parseErrors = n.errors; let A = a.set.bind(a); return a.set = c => { n.setRawValue(c), A(c); }, a.update = c => { a.set(c(o())); }, a; }
var k = class {
    field;
    constructor(t) { this.field = t; }
    control = this;
    get value() { return this.field().value(); }
    get valid() { return this.field().valid(); }
    get invalid() { return this.field().invalid(); }
    get pending() { return this.field().pending(); }
    get disabled() { return this.field().disabled(); }
    get enabled() { return !this.field().disabled(); }
    get errors() { return ee(this.field().errors()); }
    get pristine() { return !this.field().dirty(); }
    get dirty() { return this.field().dirty(); }
    get touched() { return this.field().touched(); }
    get untouched() { return !this.field().touched(); }
    get status() { if (this.field().disabled())
        return "DISABLED"; if (this.field().valid())
        return "VALID"; if (this.field().invalid())
        return "INVALID"; if (this.field().pending())
        return "PENDING"; throw new T(1910, !1); }
    valueAccessor = null;
    hasValidator(t) { return t === Ce.required ? this.field().required() : !1; }
    updateValueAndValidity() { }
}, P = { disabled: "disabled", disabledReasons: "disabledReasons", dirty: "dirty", errors: "errors", hidden: "hidden", invalid: "invalid", max: "max", maxLength: "maxLength", min: "min", minLength: "minLength", name: "name", pattern: "pattern", pending: "pending", readonly: "readonly", required: "required", touched: "touched" }, Ke = (() => { let e = {}; for (let t of Object.keys(P))
    e[P[t]] = t; return e; })();
function j(e, t) { let r = Ke[t]; return e[r]?.(); }
var U = Object.values(P);
function M() { return {}; }
function p(e, t, r) { return e[t] !== r ? (e[t] = r, !0) : !1; }
function Xe(e) { return e.tagName === "INPUT" || e.tagName === "SELECT" || e.tagName === "TEXTAREA"; }
function $e(e) { if (e.tagName !== "INPUT")
    return !1; let t = e.type; return t === "date" || t === "datetime-local" || t === "month" || t === "number" || t === "range" || t === "time" || t === "week"; }
function We(e) { return e.tagName === "INPUT" || e.tagName === "TEXTAREA"; }
function Qe(e, t) { let r; if (e.validity.badInput)
    return { error: new L }; switch (e.type) {
    case "checkbox": return { value: e.checked };
    case "number":
    case "range":
    case "datetime-local":
        if (r = y(t), typeof r == "number" || r === null)
            return { value: e.value === "" ? null : e.valueAsNumber };
        break;
    case "date":
    case "month":
    case "time":
    case "week":
        if (r = y(t), r === null || r instanceof Date)
            return { value: e.valueAsDate };
        if (typeof r == "number")
            return { value: e.valueAsNumber };
        break;
} return { value: e.value }; }
function Ye(e, t) { switch (e.type) {
    case "checkbox":
        e.checked = t;
        return;
    case "radio":
        e.checked = t === e.value;
        return;
    case "number":
    case "range":
    case "datetime-local":
        if (typeof t == "number") {
            se(e, t);
            return;
        }
        else if (t === null) {
            e.value = "";
            return;
        }
        break;
    case "date":
    case "month":
    case "time":
    case "week": if (t === null || t instanceof Date) {
        e.valueAsDate = t;
        return;
    }
    else if (typeof t == "number") {
        se(e, t);
        return;
    }
} e.value = t; }
function se(e, t) { isNaN(t) ? e.value = "" : e.valueAsNumber = t; }
function G(e, t, r, s) { switch (r) {
    case "name":
        e.setAttribute(t, r, s);
        break;
    case "disabled":
    case "readonly":
    case "required":
        s ? e.setAttribute(t, r, "") : e.removeAttribute(t, r);
        break;
    case "max":
    case "min":
    case "minLength":
    case "maxLength":
        s !== void 0 ? e.setAttribute(t, r, s.toString()) : e.removeAttribute(t, r);
        break;
} }
function xe(e, t) { e.listenToCustomControlModel(s => t.state().controlValue.set(s)), e.listenToCustomControlOutput("touchedChange", () => t.state().markAsTouched()), t.registerAsBinding(e.customControl); let r = M(); return () => { let s = t.state(), n = s.controlValue(); p(r, "controlValue", n) && e.setCustomControlModelInput(n); for (let i of U) {
    let o;
    i === "errors" ? o = t.errors() : o = j(s, i), p(r, i, o) && (e.setInputOnDirectives(i, o), t.elementAcceptsNativeProperty(i) && !e.customControlHasInput(i) && G(t.renderer, t.nativeFormElement, i, o));
} }; }
function Je(e, t) { t.controlValueAccessor.registerOnChange(s => t.state().controlValue.set(s)), t.controlValueAccessor.registerOnTouched(() => t.state().markAsTouched()), t.registerAsBinding(); let r = M(); return () => { let s = t.state(), n = s.value(); p(r, "controlValue", n) && y(() => t.controlValueAccessor.writeValue(n)); for (let i of U) {
    let o = j(s, i);
    if (p(r, i, o)) {
        let a = e.setInputOnDirectives(i, o);
        i === "disabled" && t.controlValueAccessor.setDisabledState ? y(() => t.controlValueAccessor.setDisabledState(o)) : !a && t.elementAcceptsNativeProperty(i) && G(t.renderer, t.nativeFormElement, i, o);
    }
} }; }
function et(e, t, r) { if (typeof MutationObserver != "function")
    return; let s = new MutationObserver(n => { n.some(i => tt(i)) && t(); }); s.observe(e, { attributes: !0, attributeFilter: ["value"], characterData: !0, childList: !0, subtree: !0 }), r.onDestroy(() => s.disconnect()); }
function tt(e) { if (e.type === "childList" || e.type === "characterData") {
    if (e.target instanceof Comment)
        return !1;
    for (let t of e.addedNodes)
        if (!(t instanceof Comment))
            return !0;
    for (let t of e.removedNodes)
        if (!(t instanceof Comment))
            return !0;
    return !1;
} return e.type === "attributes" && e.target instanceof HTMLOptionElement; }
function rt(e, t, r) { let s = !1, n = t.nativeFormElement, i = ce(() => t.state().value(), a => t.state().controlValue.set(a), () => Qe(n, t.state().value)); r.set(i.errors), e.listenToDom("input", () => i.setRawValue(void 0)), e.listenToDom("blur", () => t.state().markAsTouched()), t.registerAsBinding(), n.tagName === "SELECT" && et(n, () => { s && (n.value = t.state().controlValue()); }, t.destroyRef); let o = M(); return () => { let a = t.state(), A = a.controlValue(); p(o, "controlValue", A) && Ye(n, A); for (let c of U) {
    let R = j(a, c);
    p(o, c, R) && (e.setInputOnDirectives(c, R), t.elementAcceptsNativeProperty(c) && G(t.renderer, n, c, R));
} s = !0; }; }
var nt = Symbol(), st = new B(""), Ct = (() => { class e {
    field = oe.required({ alias: "formField" });
    renderer = f(ye);
    destroyRef = f(Ae);
    state = D(() => this.field()());
    injector = f(De);
    element = f(Me).nativeElement;
    elementIsNativeFormElement = Xe(this.element);
    elementAcceptsNumericValues = $e(this.element);
    elementAcceptsTextualValues = We(this.element);
    nativeFormElement = this.elementIsNativeFormElement ? this.element : void 0;
    focuser = r => this.element.focus(r);
    controlValueAccessors = f(we, { optional: !0, self: !0 });
    config = f(ae, { optional: !0 });
    parseErrorsSource = Re(void 0);
    _interopNgControl;
    get interopNgControl() { return this._interopNgControl ??= new k(this.state); }
    parseErrors = D(() => this.parseErrorsSource()?.().map(r => H(z({}, r), { fieldTree: y(this.state).fieldTree, formField: this })) ?? []);
    errors = D(() => this.state().errors().filter(r => !r.formField || r.formField === this));
    isFieldBinding = !1;
    get controlValueAccessor() { return this.controlValueAccessors?.[0] ?? this.interopNgControl?.valueAccessor ?? void 0; }
    installClassBindingEffect() { let r = Object.entries(this.config?.classes ?? {}).map(([n, i]) => [n, D(() => i(this))]); if (r.length === 0)
        return; let s = M(); Te({ write: () => { for (let [n, i] of r) {
            let o = i();
            p(s, n, o) && (o ? this.renderer.addClass(this.element, n) : this.renderer.removeClass(this.element, n));
        } } }, { injector: this.injector }); }
    focus(r) { this.focuser(r); }
    registerAsBinding(r) { if (this.isFieldBinding)
        throw new T(1913, !1); this.isFieldBinding = !0, this.installClassBindingEffect(), r?.focus && (this.focuser = s => r.focus(s)), Fe(s => { let n = this.state(); n.nodeState.formFieldBindings.update(i => [...i, this]), s(() => { n.nodeState.formFieldBindings.update(i => i.filter(o => o !== this)); }); }, { injector: this.injector }); }
    [nt];
    \u0275ngControlCreate(r) { if (!r.hasPassThrough)
        if (this.controlValueAccessor)
            this.\u0275ngControlUpdate = Je(r, this);
        else if (r.customControl)
            this.\u0275ngControlUpdate = xe(r, this);
        else if (this.elementIsNativeFormElement)
            this.\u0275ngControlUpdate = rt(r, this, this.parseErrorsSource);
        else
            throw new T(1914, !1); }
    \u0275ngControlUpdate;
    elementAcceptsNativeProperty(r) { if (!this.elementIsNativeFormElement)
        return !1; switch (r) {
        case "min":
        case "max": return this.elementAcceptsNumericValues;
        case "minLength":
        case "maxLength": return this.elementAcceptsTextualValues;
        case "disabled":
        case "required":
        case "readonly":
        case "name": return !0;
        default: return !1;
    } }
    static \u0275fac = function (s) { return new (s || e); };
    static \u0275dir = m.\u0275\u0275defineDirective({ type: e, selectors: [["", "formField", ""]], inputs: { field: [1, "formField", "field"] }, exportAs: ["formField"], features: [m.\u0275\u0275ProvidersFeature([{ provide: st, useExisting: e }, { provide: Se, useFactory: () => f(e).interopNgControl }, { provide: le, useFactory: () => f(e).parseErrorsSource }]), m.\u0275\u0275ControlFeature("formField")] });
} return e; })(), wt = (() => { class e {
    fieldTree = oe.required({ alias: "formRoot" });
    onSubmit(r) { r.preventDefault(), J(this.fieldTree()); }
    static \u0275fac = function (s) { return new (s || e); };
    static \u0275dir = m.\u0275\u0275defineDirective({ type: e, selectors: [["form", "formRoot", ""]], hostAttrs: ["novalidate", ""], hostBindings: function (s, n) { s & 1 && m.\u0275\u0275listener("submit", function (o) { return n.onSubmit(o); }); }, inputs: { fieldTree: [1, "formRoot", "fieldTree"] } });
} return e; })();
export { l as BaseNgValidationError, O as EmailValidationError, st as FORM_FIELD, Ct as FormField, wt as FormRoot, $ as MAX, Q as MAX_LENGTH, X as MIN, W as MIN_LENGTH, _ as MaxLengthValidationError, w as MaxValidationError, me as MetadataKey, fe as MetadataReducer, S as MinLengthValidationError, C as MinValidationError, L as NativeInputParseError, vt as NgValidationError, Y as PATTERN, I as PatternValidationError, K as REQUIRED, F as RequiredValidationError, V as StandardSchemaValidationError, ve as apply, he as applyEach, pe as applyWhen, Ne as applyWhenValue, Z as createManagedMetadataKey, v as createMetadataKey, Tt as debounce, mt as disabled, pt as email, Be as emailError, ge as form, gt as hidden, Nt as max, Le as maxError, bt as maxLength, ke as maxLengthError, u as metadata, Et as min, Oe as minError, yt as minLength, Ve as minLengthError, At as pattern, Pe as patternError, ft as provideSignalFormsConfig, ht as readonly, Dt as required, Ie as requiredError, be as schema, Ge as standardSchemaError, J as submit, Ft as transformedValue, b as validate, de as validateAsync, Rt as validateHttp, Mt as validateStandardSchema, Ue as validateTree, nt as \u0275NgFieldDirective };
/*! Bundled license information:

@angular/forms/fesm2022/signals.mjs:
  (**
   * @license Angular v21.2.16
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
