import { a as e, b as o, c as n, d as i, e as s, g as u, n as d, w as l, y as c } from "@nf-internal/chunk-EPGORQP5";
var m = class extends c {
    static { e(this, "PieTokenBuilder"); }
    constructor() { super(["pie", "showData"]); }
}, v = class extends l {
    static { e(this, "PieValueConverter"); }
    runCustomConverter(t, r, a) { if (t.name === "PIE_SECTION_LABEL")
        return r.replace(/"/g, "").trim(); }
}, C = { parser: { TokenBuilder: e(() => new m, "TokenBuilder"), ValueConverter: e(() => new v, "ValueConverter") } };
function P(t = s) { let r = i(n(t), u), a = i(o({ shared: r }), d, C); return r.ServiceRegistry.register(a), { shared: r, Pie: a }; }
e(P, "createPieServices");
export { C as a, P as b };
