import { a as e, b as r } from "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { e as TreeViewModule, r as createTreeViewServices };
