import { a as F } from "@nf-internal/chunk-JG3WN63S";
import { a as H, b as J, c as S, d as P, e as T, f as X, g as z } from "@nf-internal/chunk-BA5WCRNE";
import { C as _ } from "@nf-internal/chunk-LUZVEH3G";
import { a as O } from "@nf-internal/chunk-PFHS2QSV";
import { f as R, g as A, h as Y } from "@nf-internal/chunk-ST43FWUC";
import { a as G, c as k, e as C } from "@nf-internal/chunk-JKFADCWD";
import { b as M } from "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { _ as I } from "@nf-internal/chunk-LEJRRF65";
import { b as p } from "@nf-internal/chunk-RZWXGGKD";
import { a as L } from "@nf-internal/chunk-YUSHYV7C";
import { a as E, b as D, f as x } from "@nf-internal/chunk-OSQMNGTH";
var W = L((t, e, r) => Math.max(e, Math.min(r, t)), "clamp"), j = L((t = "TB") => { switch (t) {
    case "BT": return "bottom";
    case "LR": return "right";
    case "RL": return "left";
    default: return "top";
} }, "getDefaultSelfLoopSide"), Z = L(t => t === "flowchart" || t === "flowchart-v2" || t === "stateDiagram" || t === "er" || t === "classDiagram", "shouldMergeSelfLoopSegments"), $ = ["x", "y", "width", "height", "labelBBox", "intersect", "calcIntersect", "diff", "clusterNode"], ee = L((t, e, r, l, o) => { let c = [], h = new Set; if (r.forEach(({ start: n, end: d }) => { n !== l && h.add(n), d !== l && h.add(d); }), h.forEach(n => { let d = t.node(n); typeof d?.x == "number" && typeof d?.y == "number" && c.push(d); }), c.length === 0 && r.forEach(({ edge: n }) => { (n.points ?? []).forEach(d => { typeof d?.x == "number" && typeof d?.y == "number" && c.push(d); }); }), c.length === 0)
    return j(o); let s = c.reduce((n, d) => ({ x: n.x + d.x / c.length, y: n.y + d.y / c.length }), { x: 0, y: 0 }), f = s.x - e.x, i = s.y - e.y; return Math.abs(f) > Math.abs(i) ? f > 0 ? "right" : "left" : Math.abs(i) > 0 ? i > 0 ? "bottom" : "top" : j(o); }, "getSelfLoopSide"), te = L((t, e = "top", r = 0, l = 0) => { let o = t.x, c = t.y - r, h = t.width / 2, s = t.height / 2, f = Math.max(36, Math.min(100, t.width * .8)), i = W(Math.max(l, t.width * .35), 36, f), n = W(Math.min(t.width, t.height) * .45, 24, 48); switch (e) {
    case "bottom": {
        let d = c + s;
        return [{ x: o - i / 2, y: d }, { x: o - i / 2, y: d + n }, { x: o + i / 2, y: d + n }, { x: o + i / 2, y: d }];
    }
    case "right": {
        let d = o + h;
        return [{ x: d, y: c - i / 2 }, { x: d + n, y: c - i / 2 }, { x: d + n, y: c + i / 2 }, { x: d, y: c + i / 2 }];
    }
    case "left": {
        let d = o - h;
        return [{ x: d, y: c - i / 2 }, { x: d - n, y: c - i / 2 }, { x: d - n, y: c + i / 2 }, { x: d, y: c + i / 2 }];
    }
    default: {
        let d = c - s;
        return [{ x: o - i / 2, y: d }, { x: o - i / 2, y: d - n }, { x: o + i / 2, y: d - n }, { x: o + i / 2, y: d }];
    }
} }, "getSelfLoopPoints"), re = L((t, e, r = "top", l = 0, o = {}) => { let h = t.x, s = t.y - l, f = o.width ?? 0, i = o.height ?? 0; switch (r) {
    case "bottom": return { x: h, y: Math.max(...e.map(n => n.y)) + i / 2 + 4 };
    case "right": return { x: Math.max(...e.map(n => n.x)) + f / 2 + 4, y: s };
    case "left": return { x: Math.min(...e.map(n => n.x)) - f / 2 - 4, y: s };
    default: return { x: h, y: Math.min(...e.map(n => n.y)) - i / 2 - 4 };
} }, "getSelfLoopLabelPosition"), U = L((t, e = 0, { mergeSelfLoops: r = !0 } = {}) => { let l = new Map, o = [], c = t.graph()?.rankdir; return t.edges().forEach(h => { let s = t.edge(h); if (r && s.selfLoop) {
    let f = s.selfLoop.id;
    l.has(f) || l.set(f, []), l.get(f).push({ edge: s, start: h.v, end: h.w });
}
else
    o.push({ edge: s, start: h.v, end: h.w }); }), l.forEach(h => { if (h.length !== 3) {
    h.forEach(g => o.push(g));
    return;
} h.sort((g, y) => g.edge.selfLoop.order - y.edge.selfLoop.order); let [s, f, i] = h, n = s.edge.originalEdge ?? f.edge.originalEdge ?? i.edge.originalEdge ?? f.edge, d = t.node(n.start); if (!d) {
    h.forEach(g => o.push(g));
    return;
} let m = { width: f.edge.width, height: f.edge.height }, a = ee(t, d, h, n.start, c), b = te(d, a, e, m.width ?? 0), w = re(d, b, a, e, m), u = D(E(E({}, f.edge), n), { id: n.id, points: b, start: n.start, end: n.end, x: w.x, y: w.y, width: m.width, height: m.height, labelStyle: f.edge.labelStyle, fromCluster: s.edge.fromCluster ?? f.edge.fromCluster ?? i.edge.fromCluster, toCluster: s.edge.toCluster ?? f.edge.toCluster ?? i.edge.toCluster }); delete u.selfLoop, delete u.originalEdge, o.push({ edge: u, start: u.start, end: u.end }); }), o; }, "getEdgesToRender"), K = L(h => x(null, [h], function* ({ element: t, graph: e, diagramType: r, id: l, parentCluster: o, siteConfig: c }) {
    let s = e.graph().rankdir;
    p.trace("Dir in recursive render - dir:", s);
    let { clusters: f, edgePaths: i, edgeLabels: n, nodes: d, rootGroups: m } = H(t, { edgePathsClass: "edgePaths" });
    e.nodes() ? p.info("Recursive render XXX", e.nodes()) : p.info("No nodes found for", e), e.edges().length > 0 && p.info("Recursive edges", e.edge(e.edges()[0]));
    let a = Z(r);
    yield Promise.all(e.nodes().map(function (u) {
        return x(this, null, function* () {
            let g = e.node(u);
            if (o !== void 0) {
                let y = JSON.parse(JSON.stringify(o.clusterData));
                p.trace(`Setting data for parent cluster XXX
 Node.id = `, u, `
 data=`, y.height, `
Parent cluster`, o.height), e.setNode(o.id, y), e.parent(u) || (p.trace("Setting parent", u, o.id), e.setParent(u, o.id, y));
            }
            if (p.info("(Insert) Node XXX" + u + ": " + JSON.stringify(e.node(u))), g?.clusterNode) {
                p.info("Cluster identified XBX", u, g.width, e.node(u));
                let { ranksep: y, nodesep: N } = e.graph();
                g.graph.setGraph(D(E({}, g.graph.graph()), { ranksep: y + 25, nodesep: N }));
                let v = yield se({ element: d, graph: g.graph, diagramType: r, id: l, parentCluster: e.node(u), siteConfig: c }), B = v.elem;
                M(g, B), g.diff = v.diff || 0, p.info("New compound node after recursive render XAX", u, "width", g.width, "height", g.height), k(B, g);
            }
            else
                e.children(u).length > 0 ? (p.trace("Cluster - the non recursive path XBX", u, g.id, g, g.width, "Graph:", e), p.trace(P(g.id, e)), S.set(g.id, { id: P(g.id, e), node: g })) : (p.trace("Node - the non recursive path XAX", u, d, e.node(u), s), yield J(d, e.node(u), { config: c, dir: s }));
        });
    })), yield L(() => x(null, null, function* () { let u = e.edges().map(function (g) { return x(this, null, function* () { let y = e.edge(g.v, g.w, g.name); if (p.info("Edge " + g.v + " -> " + g.w + ": " + JSON.stringify(g)), p.info("Edge " + g.v + " -> " + g.w + ": ", g, " ", JSON.stringify(e.edge(g))), p.info("Fix", S, "ids:", g.v, g.w, "Translating: ", S.get(g.v), S.get(g.w)), a && y.selfLoop) {
        if (y.selfLoop.order !== 1)
            return;
        let N = D(E(E({}, y.originalEdge), y), { id: y.selfLoop.id, startLabelLeft: y.originalEdge?.startLabelLeft ?? y.startLabelLeft, startLabelRight: y.originalEdge?.startLabelRight ?? y.startLabelRight, endLabelLeft: y.originalEdge?.endLabelLeft ?? y.endLabelLeft, endLabelRight: y.originalEdge?.endLabelRight ?? y.endLabelRight });
        yield R(n, N), y.width = N.width, y.height = N.height, y.labelStyle = N.labelStyle;
        return;
    } yield R(n, y); }); }); yield Promise.all(u); }), "processEdges")();
    let { subGraphTitleTotalMargin: w } = G(c);
    return { elem: m, graph: e, groups: { clusters: f, edgePaths: i, edgeLabels: n, nodes: d, rootGroups: m }, diagramType: r, id: l, mergeSelfLoops: a, subGraphTitleTotalMargin: w };
}), "measureDagreGraph"), Q = L(t => { p.info("############################################# XXX"), p.info("###                Layout                 ### XXX"), p.info("############################################# XXX"), F(t); }, "runDagreGraphLayout"), oe = L((t, e, r) => { let l = t.node(e); if (!l)
    return; let o = E({}, l); return l?.clusterNode ? o.y = (l.y ?? 0) + r : t.children(e).length > 0 ? o.height = (l.height ?? 0) + r : o.y = (l.y ?? 0) + r / 2, o; }, "normalizeDagreNode"), q = L((t, e) => { $.forEach(r => { e[r] !== void 0 && (t[r] = e[r]); }); }, "applyDagreNodeLayout"), ne = L((t, e, r, l) => D(E({}, t), { start: t.start ?? e, end: t.end ?? r, points: (t.points ?? []).map(o => D(E({}, o), { y: typeof o.y == "number" ? o.y + l : o.y })) }), "normalizeDagreEdge"), ae = L((t, e) => { let { graph: r, mergeSelfLoops: l, subGraphTitleTotalMargin: o = 0 } = e, c = new Map(t.nodes.map(s => [s.id, s])); X(r).forEach(s => { let f = oe(r, s, o); if (!f)
    return; q(r.node(s), f); let i = c.get(s); i && q(i, f); }); let h = o / 2; return t.edges = U(r, h, { mergeSelfLoops: l }).map(({ edge: s, start: f, end: i }) => ne(s, f, i, h)), t; }, "applyDagreLayoutResult"), ie = L(f => x(null, [f], function* ({ elem: t, graph: e, groups: { clusters: r, edgePaths: l }, diagramType: o, id: c, mergeSelfLoops: h, subGraphTitleTotalMargin: s }) { let i = 0; yield Promise.all(X(e).map(function (m) { return x(this, null, function* () { let a = e.node(m); if (p.info("Position XBX => " + m + ": (" + a.x, "," + a.y, ") width: ", a.width, " height: ", a.height), a?.clusterNode)
    a.y += s, p.info("A tainted cluster node XBX1", m, a.id, a.width, a.height, a.x, a.y, e.parent(m)), S.get(a.id).node = a, C(a);
else if (e.children(m).length > 0) {
    p.info("A pure cluster node XBX1", m, a.id, a.x, a.y, a.width, a.height, e.parent(m)), a.height += s, e.node(a.parentId);
    let b = a?.padding / 2 || 0, w = a?.labelBBox?.height || 0, u = w - b || 0;
    p.debug("OffsetY", u, "labelHeight", w, "halfPadding", b), yield O(r, a), S.get(a.id).node = a;
}
else {
    let b = e.node(a.parentId);
    a.y += s / 2, p.info("A regular node XBX1 - using the padding", a.id, "parent", a.parentId, a.width, a.height, a.x, a.y, "offsetY", a.offsetY, "parent", b, b?.offsetY, a), C(a);
} }); })); let n = s / 2; return U(e, n, { mergeSelfLoops: h }).forEach(function ({ edge: m, start: a, end: b }) { p.info("Edge " + a + " -> " + b + ": " + JSON.stringify(m), m), m.points.forEach(y => y.y += n); let w = e.node(a), u = e.node(b), g = Y(l, m, S, o, w, u, c); A(m, g); }), e.nodes().forEach(function (m) { let a = e.node(m); p.info(m, a.type, a.diff), a.isGroup && (i = a.diff); }), p.warn("Returning from recursive render XAX", t, i), { elem: t, diff: i }; }), "paintDagreLayoutCore"), se = L(t => x(null, null, function* () { let e = yield K(t); return Q(e.graph), yield ie(e); }), "renderDagreSubgraph"), V = L(t => { let e = new _({ multigraph: !0, compound: !0 }).setGraph({ rankdir: t.direction, nodesep: t.config?.nodeSpacing || t.nodeSpacing || t.config?.flowchart?.nodeSpacing, ranksep: t.config?.rankSpacing || t.rankSpacing || t.config?.flowchart?.rankSpacing, marginx: 8, marginy: 8 }).setDefaultEdgeLabel(function () { return {}; }); return t.nodes.forEach(r => { e.setNode(r.id, E({}, r)), r.parentId && e.setParent(r.id, r.parentId); }), p.debug("Edges:", t.edges), t.edges.forEach(r => { if (r.start === r.end) {
    let l = r.start, o = l + "---" + l + "---1", c = l + "---" + l + "---2", h = e.node(l);
    e.setNode(o, { domId: o, id: o, parentId: h.parentId, labelStyle: "", label: "", padding: 0, shape: "labelRect", style: "", width: 10, height: 10 }), e.setParent(o, h.parentId), e.setNode(c, { domId: c, id: c, parentId: h.parentId, labelStyle: "", padding: 0, shape: "labelRect", label: "", style: "", width: 10, height: 10 }), e.setParent(c, h.parentId);
    let s = structuredClone(r), f = structuredClone(r), i = structuredClone(r), n = structuredClone(r);
    f.originalEdge = s, f.selfLoop = { id: s.id, order: 0 }, i.originalEdge = s, i.selfLoop = { id: s.id, order: 1 }, n.originalEdge = s, n.selfLoop = { id: s.id, order: 2 }, f.label = "", f.arrowTypeEnd = "none", f.endLabelLeft = "", f.endLabelRight = "", f.startLabelLeft = "", f.id = l + "-cyclic-special-1", i.startLabelRight = "", i.startLabelLeft = "", i.endLabelLeft = "", i.endLabelRight = "", i.arrowTypeStart = "none", i.arrowTypeEnd = "none", i.id = l + "-cyclic-special-mid", n.label = "", n.startLabelRight = "", n.startLabelLeft = "", n.arrowTypeStart = "none", h.isGroup && (f.fromCluster = l, n.toCluster = l), n.id = l + "-cyclic-special-2", n.arrowTypeStart = "none", e.setEdge(l, o, f, l + "-cyclic-special-0"), e.setEdge(o, c, i, l + "-cyclic-special-1"), e.setEdge(c, l, n, l + "-cyclic-special-2");
}
else
    e.setEdge(r.start, r.end, E({}, r), r.id); }), T(e), { graph: e }; }, "prepareLayoutForDagre"), de = L((l, o) => x(null, [l, o], function* (t, { element: e, preparedLayout: r }) { let c = r ?? V(t), h = I(), s = yield K({ element: e, graph: c.graph, diagramType: t.type, id: t.diagramId, parentCluster: void 0, siteConfig: h }); return c.measuredLayout = s, s; }), "measureDagreLayout"), le = L((t, e) => { let r = e.preparedLayout?.measuredLayout; if (!r)
    throw new Error("runDagreLayoutCore requires measureDagreLayout to run first"); return Q(r.graph), ae(t, r), r; }, "runDagreLayoutCore"), ge = L((t, { measure: e }) => X(e.graph).map(r => e.graph.node(r)).filter(Boolean), "getDagrePaintNodes"), ce = L((t, e, { measure: r }) => t ? r.graph.node(t) : void 0, "getDagreEdgeNode"), Xe = z({ prepareLayout: V, measureLayout: de, runLayoutCore: le, paintOptions: { clusterDb: S, getNodes: ge, getEdgeNode: ce, skipNode: L((t, { measure: e }) => !e.graph.hasNode(t.id), "skipNode"), isCluster: L((t, { measure: e }) => e.graph.hasNode(t.id) && (e.graph.children(t.id) ?? []).length > 0, "isCluster") } });
export { ae as applyDagreLayoutResult, U as getEdgesToRender, de as measureDagreLayout, V as prepareLayoutForDagre, Xe as render, le as runDagreLayoutCore };
