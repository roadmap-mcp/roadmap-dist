import { a as e, b as o } from "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { e as EventModelingModule, o as createEventModelingServices };
