import { a as ht } from "@nf-internal/chunk-QP3MATMC";
import { h as ot } from "@nf-internal/chunk-X5ONEG5D";
import { a as dt } from "@nf-internal/chunk-3UW5LP2A";
import { a as pt } from "@nf-internal/chunk-WVCFK4LD";
import { b as lt, c as ct } from "@nf-internal/chunk-4PKWXC3U";
import { p as Ae, s as ut } from "@nf-internal/chunk-FDRUJGNH";
import { H as $e, J as P, N as v, T as et, U as tt, V as st, W as it, X as at, Y as rt, Z as nt, _ as F, g as Ze } from "@nf-internal/chunk-LEJRRF65";
import { b as pe, h as Z } from "@nf-internal/chunk-RZWXGGKD";
import { a as b } from "@nf-internal/chunk-YUSHYV7C";
import { a as qe, b as He, f as Je } from "@nf-internal/chunk-OSQMNGTH";
var Ve = (function () {
    var t = b(function (O, o, h, p) { for (h = h || {}, p = O.length; p--; h[O[p]] = o)
        ; return h; }, "o"), i = [1, 18], a = [1, 19], r = [1, 20], n = [1, 41], c = [1, 26], u = [1, 42], d = [1, 24], k = [1, 25], f = [1, 32], N = [1, 33], fe = [1, 34], g = [1, 45], ke = [1, 35], me = [1, 36], ge = [1, 37], Ce = [1, 38], Ee = [1, 27], Te = [1, 28], ye = [1, 29], De = [1, 30], Fe = [1, 31], C = [1, 44], E = [1, 46], T = [1, 43], y = [1, 47], Be = [1, 9], A = [1, 8, 9], $ = [1, 58], ee = [1, 59], te = [1, 60], se = [1, 61], ie = [1, 62], _e = [1, 63], Se = [1, 64], _ = [1, 8, 9, 41], Me = [1, 77], R = [1, 8, 9, 12, 13, 22, 39, 41, 44, 46, 68, 69, 70, 71, 72, 73, 74, 79, 81], ae = [1, 8, 9, 12, 13, 18, 20, 22, 39, 41, 44, 46, 47, 60, 68, 69, 70, 71, 72, 73, 74, 79, 81, 86, 100, 102, 103], re = [13, 60, 86, 100, 102, 103], U = [13, 60, 73, 74, 86, 100, 102, 103], Re = [13, 60, 68, 69, 70, 71, 72, 86, 100, 102, 103], ne = [1, 103], z = [1, 121], Y = [1, 117], K = [1, 113], W = [1, 119], Q = [1, 114], j = [1, 115], X = [1, 116], q = [1, 118], H = [1, 120], Ge = [22, 50, 60, 61, 82, 86, 87, 88, 89, 90], Ue = [1, 128], ue = [12, 39], Ne = [1, 8, 9, 39, 41, 44, 46], le = [1, 8, 9, 22], ze = [1, 153], Ye = [1, 8, 9, 61], x = [1, 8, 9, 22, 50, 60, 61, 82, 86, 87, 88, 89, 90], Le = { trace: b(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, mermaidDoc: 4, statements: 5, graphConfig: 6, CLASS_DIAGRAM: 7, NEWLINE: 8, EOF: 9, statement: 10, classLabel: 11, SQS: 12, STR: 13, SQE: 14, namespaceName: 15, alphaNumToken: 16, classLiteralName: 17, DOT: 18, className: 19, GENERICTYPE: 20, relationStatement: 21, LABEL: 22, namespaceStatement: 23, classStatement: 24, memberStatement: 25, annotationStatement: 26, clickStatement: 27, styleStatement: 28, cssClassStatement: 29, noteStatement: 30, classDefStatement: 31, direction: 32, acc_title: 33, acc_title_value: 34, acc_descr: 35, acc_descr_value: 36, acc_descr_multiline_value: 37, namespaceIdentifier: 38, STRUCT_START: 39, classStatements: 40, STRUCT_STOP: 41, NAMESPACE: 42, classIdentifier: 43, STYLE_SEPARATOR: 44, members: 45, ANNOTATION_START: 46, ANNOTATION_END: 47, CLASS: 48, emptyBody: 49, SPACE: 50, MEMBER: 51, SEPARATOR: 52, relation: 53, NOTE_FOR: 54, noteText: 55, NOTE: 56, CLASSDEF: 57, classList: 58, stylesOpt: 59, ALPHA: 60, COMMA: 61, direction_tb: 62, direction_bt: 63, direction_rl: 64, direction_lr: 65, relationType: 66, lineType: 67, AGGREGATION: 68, EXTENSION: 69, COMPOSITION: 70, DEPENDENCY: 71, LOLLIPOP: 72, LINE: 73, DOTTED_LINE: 74, CALLBACK: 75, LINK: 76, LINK_TARGET: 77, CLICK: 78, CALLBACK_NAME: 79, CALLBACK_ARGS: 80, HREF: 81, STYLE: 82, CSSCLASS: 83, style: 84, styleComponent: 85, NUM: 86, COLON: 87, UNIT: 88, BRKT: 89, PCT: 90, commentToken: 91, textToken: 92, graphCodeTokens: 93, textNoTagsToken: 94, TAGSTART: 95, TAGEND: 96, "==": 97, "--": 98, DEFAULT: 99, MINUS: 100, keywords: 101, UNICODE_TEXT: 102, BQUOTE_STR: 103, $accept: 0, $end: 1 }, terminals_: { 2: "error", 7: "CLASS_DIAGRAM", 8: "NEWLINE", 9: "EOF", 12: "SQS", 13: "STR", 14: "SQE", 18: "DOT", 20: "GENERICTYPE", 22: "LABEL", 33: "acc_title", 34: "acc_title_value", 35: "acc_descr", 36: "acc_descr_value", 37: "acc_descr_multiline_value", 39: "STRUCT_START", 41: "STRUCT_STOP", 42: "NAMESPACE", 44: "STYLE_SEPARATOR", 46: "ANNOTATION_START", 47: "ANNOTATION_END", 48: "CLASS", 50: "SPACE", 51: "MEMBER", 52: "SEPARATOR", 54: "NOTE_FOR", 56: "NOTE", 57: "CLASSDEF", 60: "ALPHA", 61: "COMMA", 62: "direction_tb", 63: "direction_bt", 64: "direction_rl", 65: "direction_lr", 68: "AGGREGATION", 69: "EXTENSION", 70: "COMPOSITION", 71: "DEPENDENCY", 72: "LOLLIPOP", 73: "LINE", 74: "DOTTED_LINE", 75: "CALLBACK", 76: "LINK", 77: "LINK_TARGET", 78: "CLICK", 79: "CALLBACK_NAME", 80: "CALLBACK_ARGS", 81: "HREF", 82: "STYLE", 83: "CSSCLASS", 86: "NUM", 87: "COLON", 88: "UNIT", 89: "BRKT", 90: "PCT", 93: "graphCodeTokens", 95: "TAGSTART", 96: "TAGEND", 97: "==", 98: "--", 99: "DEFAULT", 100: "MINUS", 101: "keywords", 102: "UNICODE_TEXT", 103: "BQUOTE_STR" }, productions_: [0, [3, 1], [3, 1], [4, 1], [6, 4], [5, 1], [5, 2], [5, 3], [11, 3], [15, 1], [15, 1], [15, 3], [15, 2], [19, 1], [19, 3], [19, 1], [19, 2], [19, 2], [19, 2], [10, 1], [10, 2], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 1], [10, 2], [10, 2], [10, 1], [23, 4], [23, 5], [38, 2], [38, 3], [40, 1], [40, 2], [40, 3], [40, 1], [40, 2], [40, 3], [40, 1], [40, 2], [40, 3], [24, 1], [24, 3], [24, 4], [24, 3], [24, 6], [24, 4], [24, 7], [24, 6], [43, 2], [43, 3], [49, 0], [49, 2], [49, 2], [26, 4], [45, 1], [45, 2], [25, 1], [25, 2], [25, 1], [25, 1], [21, 3], [21, 4], [21, 4], [21, 5], [30, 3], [30, 2], [31, 3], [58, 1], [58, 3], [32, 1], [32, 1], [32, 1], [32, 1], [53, 3], [53, 2], [53, 2], [53, 1], [66, 1], [66, 1], [66, 1], [66, 1], [66, 1], [67, 1], [67, 1], [27, 3], [27, 4], [27, 3], [27, 4], [27, 4], [27, 5], [27, 3], [27, 4], [27, 4], [27, 5], [27, 4], [27, 5], [27, 5], [27, 6], [28, 3], [29, 3], [59, 1], [59, 3], [84, 1], [84, 2], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [85, 1], [91, 1], [91, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [92, 1], [94, 1], [94, 1], [94, 1], [94, 1], [16, 1], [16, 1], [16, 1], [16, 1], [17, 1], [55, 1]], performAction: b(function (o, h, p, l, m, e, J) { var s = e.length - 1; switch (m) {
            case 8:
                this.$ = e[s - 1];
                break;
            case 9:
            case 10:
            case 13:
            case 15:
                this.$ = e[s];
                break;
            case 11:
            case 14:
                this.$ = e[s - 2] + "." + e[s];
                break;
            case 12:
            case 16:
                this.$ = e[s - 1] + e[s];
                break;
            case 17:
            case 18:
                this.$ = e[s - 1] + "~" + e[s] + "~";
                break;
            case 19:
                l.addRelation(e[s]);
                break;
            case 20:
                e[s - 1].title = l.cleanupLabel(e[s]), l.addRelation(e[s - 1]);
                break;
            case 31:
                this.$ = e[s].trim(), l.setAccTitle(this.$);
                break;
            case 32:
            case 33:
                this.$ = e[s].trim(), l.setAccDescription(this.$);
                break;
            case 34:
                l.addClassesToNamespace(e[s - 3], e[s - 1][0], e[s - 1][1]), l.popNamespace();
                break;
            case 35:
                l.addClassesToNamespace(e[s - 4], e[s - 1][0], e[s - 1][1]), l.popNamespace();
                break;
            case 36:
                this.$ = l.addNamespace(e[s]);
                break;
            case 37:
                this.$ = l.addNamespace(e[s - 1], e[s]);
                break;
            case 38:
                this.$ = [[e[s]], []];
                break;
            case 39:
                this.$ = [[e[s - 1]], []];
                break;
            case 40:
                e[s][0].unshift(e[s - 2]), this.$ = e[s];
                break;
            case 41:
                this.$ = [[], [e[s]]];
                break;
            case 42:
                this.$ = [[], [e[s - 1]]];
                break;
            case 43:
                e[s][1].unshift(e[s - 2]), this.$ = e[s];
                break;
            case 44:
            case 45:
                this.$ = [[], []];
                break;
            case 46:
                this.$ = e[s];
                break;
            case 48:
                l.setCssClass(e[s - 2], e[s]);
                break;
            case 49:
                l.addMembers(e[s - 3], e[s - 1]);
                break;
            case 51:
                l.setCssClass(e[s - 5], e[s - 3]), l.addMembers(e[s - 5], e[s - 1]);
                break;
            case 52:
                l.addAnnotation(e[s - 3], e[s - 1]);
                break;
            case 53:
                l.addAnnotation(e[s - 6], e[s - 4]), l.addMembers(e[s - 6], e[s - 1]);
                break;
            case 54:
                l.addAnnotation(e[s - 5], e[s - 3]);
                break;
            case 55:
                this.$ = e[s], l.addClass(e[s]);
                break;
            case 56:
                this.$ = e[s - 1], l.addClass(e[s - 1]), l.setClassLabel(e[s - 1], e[s]);
                break;
            case 60:
                l.addAnnotation(e[s], e[s - 2]);
                break;
            case 61:
            case 74:
                this.$ = [e[s]];
                break;
            case 62:
                e[s].push(e[s - 1]), this.$ = e[s];
                break;
            case 63: break;
            case 64:
                l.addMember(e[s - 1], l.cleanupLabel(e[s]));
                break;
            case 65: break;
            case 66: break;
            case 67:
                this.$ = { id1: e[s - 2], id2: e[s], relation: e[s - 1], relationTitle1: "none", relationTitle2: "none" };
                break;
            case 68:
                this.$ = { id1: e[s - 3], id2: e[s], relation: e[s - 1], relationTitle1: e[s - 2], relationTitle2: "none" };
                break;
            case 69:
                this.$ = { id1: e[s - 3], id2: e[s], relation: e[s - 2], relationTitle1: "none", relationTitle2: e[s - 1] };
                break;
            case 70:
                this.$ = { id1: e[s - 4], id2: e[s], relation: e[s - 2], relationTitle1: e[s - 3], relationTitle2: e[s - 1] };
                break;
            case 71:
                this.$ = l.addNote(e[s], e[s - 1]);
                break;
            case 72:
                this.$ = l.addNote(e[s]);
                break;
            case 73:
                this.$ = e[s - 2], l.defineClass(e[s - 1], e[s]);
                break;
            case 75:
                this.$ = e[s - 2].concat([e[s]]);
                break;
            case 76:
                l.setDirection("TB");
                break;
            case 77:
                l.setDirection("BT");
                break;
            case 78:
                l.setDirection("RL");
                break;
            case 79:
                l.setDirection("LR");
                break;
            case 80:
                this.$ = { type1: e[s - 2], type2: e[s], lineType: e[s - 1] };
                break;
            case 81:
                this.$ = { type1: "none", type2: e[s], lineType: e[s - 1] };
                break;
            case 82:
                this.$ = { type1: e[s - 1], type2: "none", lineType: e[s] };
                break;
            case 83:
                this.$ = { type1: "none", type2: "none", lineType: e[s] };
                break;
            case 84:
                this.$ = l.relationType.AGGREGATION;
                break;
            case 85:
                this.$ = l.relationType.EXTENSION;
                break;
            case 86:
                this.$ = l.relationType.COMPOSITION;
                break;
            case 87:
                this.$ = l.relationType.DEPENDENCY;
                break;
            case 88:
                this.$ = l.relationType.LOLLIPOP;
                break;
            case 89:
                this.$ = l.lineType.LINE;
                break;
            case 90:
                this.$ = l.lineType.DOTTED_LINE;
                break;
            case 91:
            case 97:
                this.$ = e[s - 2], l.setClickEvent(e[s - 1], e[s]);
                break;
            case 92:
            case 98:
                this.$ = e[s - 3], l.setClickEvent(e[s - 2], e[s - 1]), l.setTooltip(e[s - 2], e[s]);
                break;
            case 93:
                this.$ = e[s - 2], l.setLink(e[s - 1], e[s]);
                break;
            case 94:
                this.$ = e[s - 3], l.setLink(e[s - 2], e[s - 1], e[s]);
                break;
            case 95:
                this.$ = e[s - 3], l.setLink(e[s - 2], e[s - 1]), l.setTooltip(e[s - 2], e[s]);
                break;
            case 96:
                this.$ = e[s - 4], l.setLink(e[s - 3], e[s - 2], e[s]), l.setTooltip(e[s - 3], e[s - 1]);
                break;
            case 99:
                this.$ = e[s - 3], l.setClickEvent(e[s - 2], e[s - 1], e[s]);
                break;
            case 100:
                this.$ = e[s - 4], l.setClickEvent(e[s - 3], e[s - 2], e[s - 1]), l.setTooltip(e[s - 3], e[s]);
                break;
            case 101:
                this.$ = e[s - 3], l.setLink(e[s - 2], e[s]);
                break;
            case 102:
                this.$ = e[s - 4], l.setLink(e[s - 3], e[s - 1], e[s]);
                break;
            case 103:
                this.$ = e[s - 4], l.setLink(e[s - 3], e[s - 1]), l.setTooltip(e[s - 3], e[s]);
                break;
            case 104:
                this.$ = e[s - 5], l.setLink(e[s - 4], e[s - 2], e[s]), l.setTooltip(e[s - 4], e[s - 1]);
                break;
            case 105:
                this.$ = e[s - 2], l.setCssStyle(e[s - 1], e[s]);
                break;
            case 106:
                l.setCssClass(e[s - 1], e[s]);
                break;
            case 107:
                this.$ = [e[s]];
                break;
            case 108:
                e[s - 2].push(e[s]), this.$ = e[s - 2];
                break;
            case 110:
                this.$ = e[s - 1] + e[s];
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 5: 3, 6: 4, 7: [1, 6], 10: 5, 16: 39, 17: 40, 19: 21, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 33: i, 35: a, 37: r, 38: 22, 42: n, 43: 23, 46: c, 48: u, 51: d, 52: k, 54: f, 56: N, 57: fe, 60: g, 62: ke, 63: me, 64: ge, 65: Ce, 75: Ee, 76: Te, 78: ye, 82: De, 83: Fe, 86: C, 100: E, 102: T, 103: y }, { 1: [3] }, { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 3] }, t(Be, [2, 5], { 8: [1, 48] }), { 8: [1, 49] }, t(A, [2, 19], { 22: [1, 50] }), t(A, [2, 21]), t(A, [2, 22]), t(A, [2, 23]), t(A, [2, 24]), t(A, [2, 25]), t(A, [2, 26]), t(A, [2, 27]), t(A, [2, 28]), t(A, [2, 29]), t(A, [2, 30]), { 34: [1, 51] }, { 36: [1, 52] }, t(A, [2, 33]), t(A, [2, 63], { 53: 53, 66: 56, 67: 57, 13: [1, 54], 22: [1, 55], 68: $, 69: ee, 70: te, 71: se, 72: ie, 73: _e, 74: Se }), { 39: [1, 65] }, t(_, [2, 47], { 39: [1, 67], 44: [1, 66], 46: [1, 68] }), t(A, [2, 65]), t(A, [2, 66]), { 16: 69, 60: g, 86: C, 100: E, 102: T }, { 16: 39, 17: 40, 19: 70, 60: g, 86: C, 100: E, 102: T, 103: y }, { 16: 39, 17: 40, 19: 71, 60: g, 86: C, 100: E, 102: T, 103: y }, { 16: 39, 17: 40, 19: 72, 60: g, 86: C, 100: E, 102: T, 103: y }, { 60: [1, 73] }, { 13: [1, 74] }, { 16: 39, 17: 40, 19: 75, 60: g, 86: C, 100: E, 102: T, 103: y }, { 13: Me, 55: 76 }, { 58: 78, 60: [1, 79] }, t(A, [2, 76]), t(A, [2, 77]), t(A, [2, 78]), t(A, [2, 79]), t(R, [2, 13], { 16: 39, 17: 40, 19: 81, 18: [1, 80], 20: [1, 82], 60: g, 86: C, 100: E, 102: T, 103: y }), t(R, [2, 15], { 20: [1, 83] }), { 15: 84, 16: 85, 17: 86, 60: g, 86: C, 100: E, 102: T, 103: y }, { 16: 39, 17: 40, 19: 87, 60: g, 86: C, 100: E, 102: T, 103: y }, t(ae, [2, 133]), t(ae, [2, 134]), t(ae, [2, 135]), t(ae, [2, 136]), t([1, 8, 9, 12, 13, 20, 22, 39, 41, 44, 46, 68, 69, 70, 71, 72, 73, 74, 79, 81], [2, 137]), t(Be, [2, 6], { 10: 5, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 19: 21, 38: 22, 43: 23, 16: 39, 17: 40, 5: 88, 33: i, 35: a, 37: r, 42: n, 46: c, 48: u, 51: d, 52: k, 54: f, 56: N, 57: fe, 60: g, 62: ke, 63: me, 64: ge, 65: Ce, 75: Ee, 76: Te, 78: ye, 82: De, 83: Fe, 86: C, 100: E, 102: T, 103: y }), { 5: 89, 10: 5, 16: 39, 17: 40, 19: 21, 21: 7, 23: 8, 24: 9, 25: 10, 26: 11, 27: 12, 28: 13, 29: 14, 30: 15, 31: 16, 32: 17, 33: i, 35: a, 37: r, 38: 22, 42: n, 43: 23, 46: c, 48: u, 51: d, 52: k, 54: f, 56: N, 57: fe, 60: g, 62: ke, 63: me, 64: ge, 65: Ce, 75: Ee, 76: Te, 78: ye, 82: De, 83: Fe, 86: C, 100: E, 102: T, 103: y }, t(A, [2, 20]), t(A, [2, 31]), t(A, [2, 32]), { 13: [1, 91], 16: 39, 17: 40, 19: 90, 60: g, 86: C, 100: E, 102: T, 103: y }, { 53: 92, 66: 56, 67: 57, 68: $, 69: ee, 70: te, 71: se, 72: ie, 73: _e, 74: Se }, t(A, [2, 64]), { 67: 93, 73: _e, 74: Se }, t(re, [2, 83], { 66: 94, 68: $, 69: ee, 70: te, 71: se, 72: ie }), t(U, [2, 84]), t(U, [2, 85]), t(U, [2, 86]), t(U, [2, 87]), t(U, [2, 88]), t(Re, [2, 89]), t(Re, [2, 90]), { 8: [1, 96], 23: 99, 24: 97, 30: 98, 38: 22, 40: 95, 42: n, 43: 23, 48: u, 54: f, 56: N }, { 16: 100, 60: g, 86: C, 100: E, 102: T }, { 41: [1, 102], 45: 101, 51: ne }, { 16: 104, 60: g, 86: C, 100: E, 102: T }, { 47: [1, 105] }, { 13: [1, 106] }, { 13: [1, 107] }, { 79: [1, 108], 81: [1, 109] }, { 22: z, 50: Y, 59: 110, 60: K, 82: W, 84: 111, 85: 112, 86: Q, 87: j, 88: X, 89: q, 90: H }, { 60: [1, 122] }, { 13: Me, 55: 123 }, t(_, [2, 72]), t(_, [2, 138]), { 22: z, 50: Y, 59: 124, 60: K, 61: [1, 125], 82: W, 84: 111, 85: 112, 86: Q, 87: j, 88: X, 89: q, 90: H }, t(Ge, [2, 74]), { 16: 39, 17: 40, 19: 126, 60: g, 86: C, 100: E, 102: T, 103: y }, t(R, [2, 16]), t(R, [2, 17]), t(R, [2, 18]), { 11: 127, 12: Ue, 39: [2, 36] }, t(ue, [2, 9], { 16: 85, 17: 86, 15: 130, 18: [1, 129], 60: g, 86: C, 100: E, 102: T, 103: y }), t(ue, [2, 10]), t(Ne, [2, 55], { 11: 131, 12: Ue }), t(Be, [2, 7]), { 9: [1, 132] }, t(le, [2, 67]), { 16: 39, 17: 40, 19: 133, 60: g, 86: C, 100: E, 102: T, 103: y }, { 13: [1, 135], 16: 39, 17: 40, 19: 134, 60: g, 86: C, 100: E, 102: T, 103: y }, t(re, [2, 82], { 66: 136, 68: $, 69: ee, 70: te, 71: se, 72: ie }), t(re, [2, 81]), { 41: [1, 137] }, { 23: 99, 24: 97, 30: 98, 38: 22, 40: 138, 42: n, 43: 23, 48: u, 54: f, 56: N }, { 8: [1, 139], 41: [2, 38] }, { 8: [1, 140], 41: [2, 41] }, { 8: [1, 141], 41: [2, 44] }, t(_, [2, 48], { 39: [1, 142] }), { 41: [1, 143] }, t(_, [2, 50]), { 41: [2, 61], 45: 144, 51: ne }, { 47: [1, 145] }, { 16: 39, 17: 40, 19: 146, 60: g, 86: C, 100: E, 102: T, 103: y }, t(A, [2, 91], { 13: [1, 147] }), t(A, [2, 93], { 13: [1, 149], 77: [1, 148] }), t(A, [2, 97], { 13: [1, 150], 80: [1, 151] }), { 13: [1, 152] }, t(A, [2, 105], { 61: ze }), t(Ye, [2, 107], { 85: 154, 22: z, 50: Y, 60: K, 82: W, 86: Q, 87: j, 88: X, 89: q, 90: H }), t(x, [2, 109]), t(x, [2, 111]), t(x, [2, 112]), t(x, [2, 113]), t(x, [2, 114]), t(x, [2, 115]), t(x, [2, 116]), t(x, [2, 117]), t(x, [2, 118]), t(x, [2, 119]), t(A, [2, 106]), t(_, [2, 71]), t(A, [2, 73], { 61: ze }), { 60: [1, 155] }, t(R, [2, 14]), { 39: [2, 37] }, { 13: [1, 156] }, { 15: 157, 16: 85, 17: 86, 60: g, 86: C, 100: E, 102: T, 103: y }, t(ue, [2, 12]), t(Ne, [2, 56]), { 1: [2, 4] }, t(le, [2, 69]), t(le, [2, 68]), { 16: 39, 17: 40, 19: 158, 60: g, 86: C, 100: E, 102: T, 103: y }, t(re, [2, 80]), t(_, [2, 34]), { 41: [1, 159] }, { 23: 99, 24: 97, 30: 98, 38: 22, 40: 160, 41: [2, 39], 42: n, 43: 23, 48: u, 54: f, 56: N }, { 23: 99, 24: 97, 30: 98, 38: 22, 40: 161, 41: [2, 42], 42: n, 43: 23, 48: u, 54: f, 56: N }, { 23: 99, 24: 97, 30: 98, 38: 22, 40: 162, 41: [2, 45], 42: n, 43: 23, 48: u, 54: f, 56: N }, { 45: 163, 51: ne }, t(_, [2, 49]), { 41: [2, 62] }, t(_, [2, 52], { 39: [1, 164] }), t(A, [2, 60]), t(A, [2, 92]), t(A, [2, 94]), t(A, [2, 95], { 77: [1, 165] }), t(A, [2, 98]), t(A, [2, 99], { 13: [1, 166] }), t(A, [2, 101], { 13: [1, 168], 77: [1, 167] }), { 22: z, 50: Y, 60: K, 82: W, 84: 169, 85: 112, 86: Q, 87: j, 88: X, 89: q, 90: H }, t(x, [2, 110]), t(Ge, [2, 75]), { 14: [1, 170] }, t(ue, [2, 11]), t(le, [2, 70]), t(_, [2, 35]), { 41: [2, 40] }, { 41: [2, 43] }, { 41: [2, 46] }, { 41: [1, 171] }, { 41: [1, 173], 45: 172, 51: ne }, t(A, [2, 96]), t(A, [2, 100]), t(A, [2, 102]), t(A, [2, 103], { 77: [1, 174] }), t(Ye, [2, 108], { 85: 154, 22: z, 50: Y, 60: K, 82: W, 86: Q, 87: j, 88: X, 89: q, 90: H }), t(Ne, [2, 8]), t(_, [2, 51]), { 41: [1, 175] }, t(_, [2, 54]), t(A, [2, 104]), t(_, [2, 53])], defaultActions: { 2: [2, 1], 3: [2, 2], 4: [2, 3], 127: [2, 37], 132: [2, 4], 144: [2, 62], 160: [2, 40], 161: [2, 43], 162: [2, 46] }, parseError: b(function (o, h) { if (h.recoverable)
            this.trace(o);
        else {
            var p = new Error(o);
            throw p.hash = h, p;
        } }, "parseError"), parse: b(function (o) {
            var h = this, p = [0], l = [], m = [null], e = [], J = this.table, s = "", oe = 0, Ke = 0, We = 0, mt = 2, Qe = 1, gt = e.slice.call(arguments, 1), D = Object.create(this.lexer), w = { yy: {} };
            for (var xe in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, xe) && (w.yy[xe] = this.yy[xe]);
            D.setInput(o, w.yy), w.yy.lexer = D, w.yy.parser = this, typeof D.yylloc > "u" && (D.yylloc = {});
            var ve = D.yylloc;
            e.push(ve);
            var Ct = D.options && D.options.ranges;
            typeof w.yy.parseError == "function" ? this.parseError = w.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function Et(S) { p.length = p.length - 2 * S, m.length = m.length - S, e.length = e.length - S; }
            b(Et, "popStack");
            function je() { var S; return S = l.pop() || D.lex() || Qe, typeof S != "number" && (S instanceof Array && (l = S, S = l.pop()), S = h.symbols_[S] || S), S; }
            b(je, "lex");
            for (var B, Ie, V, L, Bt, Oe, G = {}, he, I, Xe, de;;) {
                if (V = p[p.length - 1], this.defaultActions[V] ? L = this.defaultActions[V] : ((B === null || typeof B > "u") && (B = je()), L = J[V] && J[V][B]), typeof L > "u" || !L.length || !L[0]) {
                    var we = "";
                    de = [];
                    for (he in J[V])
                        this.terminals_[he] && he > mt && de.push("'" + this.terminals_[he] + "'");
                    D.showPosition ? we = "Parse error on line " + (oe + 1) + `:
` + D.showPosition() + `
Expecting ` + de.join(", ") + ", got '" + (this.terminals_[B] || B) + "'" : we = "Parse error on line " + (oe + 1) + ": Unexpected " + (B == Qe ? "end of input" : "'" + (this.terminals_[B] || B) + "'"), this.parseError(we, { text: D.match, token: this.terminals_[B] || B, line: D.yylineno, loc: ve, expected: de });
                }
                if (L[0] instanceof Array && L.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + V + ", token: " + B);
                switch (L[0]) {
                    case 1:
                        p.push(B), m.push(D.yytext), e.push(D.yylloc), p.push(L[1]), B = null, Ie ? (B = Ie, Ie = null) : (Ke = D.yyleng, s = D.yytext, oe = D.yylineno, ve = D.yylloc, We > 0 && We--);
                        break;
                    case 2:
                        if (I = this.productions_[L[1]][1], G.$ = m[m.length - I], G._$ = { first_line: e[e.length - (I || 1)].first_line, last_line: e[e.length - 1].last_line, first_column: e[e.length - (I || 1)].first_column, last_column: e[e.length - 1].last_column }, Ct && (G._$.range = [e[e.length - (I || 1)].range[0], e[e.length - 1].range[1]]), Oe = this.performAction.apply(G, [s, Ke, oe, w.yy, L[1], m, e].concat(gt)), typeof Oe < "u")
                            return Oe;
                        I && (p = p.slice(0, -1 * I * 2), m = m.slice(0, -1 * I), e = e.slice(0, -1 * I)), p.push(this.productions_[L[1]][0]), m.push(G.$), e.push(G._$), Xe = J[p[p.length - 2]][p[p.length - 1]], p.push(Xe);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, kt = (function () {
        var O = { EOF: 1, parseError: b(function (h, p) { if (this.yy.parser)
                this.yy.parser.parseError(h, p);
            else
                throw new Error(h); }, "parseError"), setInput: b(function (o, h) { return this.yy = h || this.yy || {}, this._input = o, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: b(function () { var o = this._input[0]; this.yytext += o, this.yyleng++, this.offset++, this.match += o, this.matched += o; var h = o.match(/(?:\r\n?|\n).*/g); return h ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), o; }, "input"), unput: b(function (o) { var h = o.length, p = o.split(/(?:\r\n?|\n)/g); this._input = o + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - h), this.offset -= h; var l = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), p.length - 1 && (this.yylineno -= p.length - 1); var m = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: p ? (p.length === l.length ? this.yylloc.first_column : 0) + l[l.length - p.length].length - p[0].length : this.yylloc.first_column - h }, this.options.ranges && (this.yylloc.range = [m[0], m[0] + this.yyleng - h]), this.yyleng = this.yytext.length, this; }, "unput"), more: b(function () { return this._more = !0, this; }, "more"), reject: b(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: b(function (o) { this.unput(this.match.slice(o)); }, "less"), pastInput: b(function () { var o = this.matched.substr(0, this.matched.length - this.match.length); return (o.length > 20 ? "..." : "") + o.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: b(function () { var o = this.match; return o.length < 20 && (o += this._input.substr(0, 20 - o.length)), (o.substr(0, 20) + (o.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: b(function () {
                var o = this.pastInput(), h = new Array(o.length + 1).join("-");
                return o + this.upcomingInput() + `
` + h + "^";
            }, "showPosition"), test_match: b(function (o, h) { var p, l, m; if (this.options.backtrack_lexer && (m = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (m.yylloc.range = this.yylloc.range.slice(0))), l = o[0].match(/(?:\r\n?|\n).*/g), l && (this.yylineno += l.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: l ? l[l.length - 1].length - l[l.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + o[0].length }, this.yytext += o[0], this.match += o[0], this.matches = o, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(o[0].length), this.matched += o[0], p = this.performAction.call(this, this.yy, this, h, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), p)
                return p; if (this._backtrack) {
                for (var e in m)
                    this[e] = m[e];
                return !1;
            } return !1; }, "test_match"), next: b(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var o, h, p, l;
                this._more || (this.yytext = "", this.match = "");
                for (var m = this._currentRules(), e = 0; e < m.length; e++)
                    if (p = this._input.match(this.rules[m[e]]), p && (!h || p[0].length > h[0].length)) {
                        if (h = p, l = e, this.options.backtrack_lexer) {
                            if (o = this.test_match(p, m[e]), o !== !1)
                                return o;
                            if (this._backtrack) {
                                h = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return h ? (o = this.test_match(h, m[l]), o !== !1 ? o : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: b(function () { var h = this.next(); return h || this.lex(); }, "lex"), begin: b(function (h) { this.conditionStack.push(h); }, "begin"), popState: b(function () { var h = this.conditionStack.length - 1; return h > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: b(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: b(function (h) { return h = this.conditionStack.length - 1 - Math.abs(h || 0), h >= 0 ? this.conditionStack[h] : "INITIAL"; }, "topState"), pushState: b(function (h) { this.begin(h); }, "pushState"), stateStackSize: b(function () { return this.conditionStack.length; }, "stateStackSize"), options: {}, performAction: b(function (h, p, l, m) { var e = m; switch (l) {
                case 0: return 62;
                case 1: return 63;
                case 2: return 64;
                case 3: return 65;
                case 4: break;
                case 5: break;
                case 6:
                    return this.begin("acc_title"), 33;
                    break;
                case 7:
                    return this.popState(), "acc_title_value";
                    break;
                case 8:
                    return this.begin("acc_descr"), 35;
                    break;
                case 9:
                    return this.popState(), "acc_descr_value";
                    break;
                case 10:
                    this.begin("acc_descr_multiline");
                    break;
                case 11:
                    this.popState();
                    break;
                case 12: return "acc_descr_multiline_value";
                case 13: return 8;
                case 14: break;
                case 15: return 7;
                case 16: return 7;
                case 17: return "EDGE_STATE";
                case 18:
                    this.begin("callback_name");
                    break;
                case 19:
                    this.popState();
                    break;
                case 20:
                    this.popState(), this.begin("callback_args");
                    break;
                case 21: return 79;
                case 22:
                    this.popState();
                    break;
                case 23: return 80;
                case 24:
                    this.popState();
                    break;
                case 25: return "STR";
                case 26:
                    this.begin("string");
                    break;
                case 27: return 82;
                case 28: return 57;
                case 29:
                    return this.begin("namespace"), 42;
                    break;
                case 30:
                    return this.popState(), 8;
                    break;
                case 31: break;
                case 32:
                    return this.begin("namespace-body"), 39;
                    break;
                case 33:
                    this.popState(), this.less(0);
                    break;
                case 34:
                    return this.popState(), 41;
                    break;
                case 35: return "EOF_IN_STRUCT";
                case 36: return 8;
                case 37: break;
                case 38: return "EDGE_STATE";
                case 39:
                    return this.begin("class"), 48;
                    break;
                case 40:
                    return this.popState(), 8;
                    break;
                case 41: break;
                case 42:
                    return this.popState(), this.popState(), 41;
                    break;
                case 43:
                    return this.begin("class-body"), 39;
                    break;
                case 44:
                    return this.popState(), 41;
                    break;
                case 45: return "EOF_IN_STRUCT";
                case 46: return "EDGE_STATE";
                case 47: return "OPEN_IN_STRUCT";
                case 48: break;
                case 49: return "MEMBER";
                case 50: return 83;
                case 51: return 75;
                case 52: return 76;
                case 53: return 78;
                case 54: return 54;
                case 55: return 56;
                case 56: return 46;
                case 57: return 47;
                case 58: return 81;
                case 59:
                    this.popState();
                    break;
                case 60: return "GENERICTYPE";
                case 61:
                    this.begin("generic");
                    break;
                case 62:
                    this.popState();
                    break;
                case 63: return "BQUOTE_STR";
                case 64:
                    this.begin("bqstring");
                    break;
                case 65: return 77;
                case 66: return 77;
                case 67: return 77;
                case 68: return 77;
                case 69: return 69;
                case 70: return 69;
                case 71: return 71;
                case 72: return 71;
                case 73: return 70;
                case 74: return 68;
                case 75: return 72;
                case 76: return 73;
                case 77: return 74;
                case 78: return 22;
                case 79: return 44;
                case 80: return 100;
                case 81: return 18;
                case 82: return "PLUS";
                case 83: return 87;
                case 84: return 61;
                case 85: return 89;
                case 86: return 89;
                case 87: return 90;
                case 88: return "EQUALS";
                case 89: return "EQUALS";
                case 90: return 60;
                case 91: return 12;
                case 92: return 14;
                case 93: return "PUNCTUATION";
                case 94: return 86;
                case 95: return 102;
                case 96: return 50;
                case 97: return 50;
                case 98: return 9;
            } }, "anonymous"), rules: [/^(?:.*direction\s+TB[^\n]*)/, /^(?:.*direction\s+BT[^\n]*)/, /^(?:.*direction\s+RL[^\n]*)/, /^(?:.*direction\s+LR[^\n]*)/, /^(?:%%(?!\{)*[^\n]*(\r?\n?)+)/, /^(?:%%[^\n]*(\r?\n)*)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:classDiagram-v2\b)/, /^(?:classDiagram\b)/, /^(?:\[\*\])/, /^(?:call[\s]+)/, /^(?:\([\s]*\))/, /^(?:\()/, /^(?:[^(]*)/, /^(?:\))/, /^(?:[^)]*)/, /^(?:["])/, /^(?:[^"]*)/, /^(?:["])/, /^(?:style\b)/, /^(?:classDef\b)/, /^(?:namespace\b)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:[{])/, /^(?:[}])/, /^(?:[}])/, /^(?:$)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:\[\*\])/, /^(?:class\b)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:[}])/, /^(?:[{])/, /^(?:[}])/, /^(?:$)/, /^(?:\[\*\])/, /^(?:[{])/, /^(?:[\n])/, /^(?:[^{}\n]*)/, /^(?:cssClass\b)/, /^(?:callback\b)/, /^(?:link\b)/, /^(?:click\b)/, /^(?:note for\b)/, /^(?:note\b)/, /^(?:<<)/, /^(?:>>)/, /^(?:href\b)/, /^(?:[~])/, /^(?:[^~]*)/, /^(?:~)/, /^(?:[`])/, /^(?:[^`]+)/, /^(?:[`])/, /^(?:_self\b)/, /^(?:_blank\b)/, /^(?:_parent\b)/, /^(?:_top\b)/, /^(?:\s*<\|)/, /^(?:\s*\|>)/, /^(?:\s*>)/, /^(?:\s*<)/, /^(?:\s*\*)/, /^(?:\s*o\b)/, /^(?:\s*\(\))/, /^(?:--)/, /^(?:\.\.)/, /^(?::{1}[^:\n;]+)/, /^(?::{3})/, /^(?:-)/, /^(?:\.)/, /^(?:\+)/, /^(?::)/, /^(?:,)/, /^(?:#)/, /^(?:#)/, /^(?:%)/, /^(?:=)/, /^(?:=)/, /^(?:\w+)/, /^(?:\[)/, /^(?:\])/, /^(?:[!"#$%&'*+,-.`?\\/])/, /^(?:[0-9]+)/, /^(?:[\u00AA\u00B5\u00BA\u00C0-\u00D6\u00D8-\u00F6]|[\u00F8-\u02C1\u02C6-\u02D1\u02E0-\u02E4\u02EC\u02EE\u0370-\u0374\u0376\u0377]|[\u037A-\u037D\u0386\u0388-\u038A\u038C\u038E-\u03A1\u03A3-\u03F5]|[\u03F7-\u0481\u048A-\u0527\u0531-\u0556\u0559\u0561-\u0587\u05D0-\u05EA]|[\u05F0-\u05F2\u0620-\u064A\u066E\u066F\u0671-\u06D3\u06D5\u06E5\u06E6\u06EE]|[\u06EF\u06FA-\u06FC\u06FF\u0710\u0712-\u072F\u074D-\u07A5\u07B1\u07CA-\u07EA]|[\u07F4\u07F5\u07FA\u0800-\u0815\u081A\u0824\u0828\u0840-\u0858\u08A0]|[\u08A2-\u08AC\u0904-\u0939\u093D\u0950\u0958-\u0961\u0971-\u0977]|[\u0979-\u097F\u0985-\u098C\u098F\u0990\u0993-\u09A8\u09AA-\u09B0\u09B2]|[\u09B6-\u09B9\u09BD\u09CE\u09DC\u09DD\u09DF-\u09E1\u09F0\u09F1\u0A05-\u0A0A]|[\u0A0F\u0A10\u0A13-\u0A28\u0A2A-\u0A30\u0A32\u0A33\u0A35\u0A36\u0A38\u0A39]|[\u0A59-\u0A5C\u0A5E\u0A72-\u0A74\u0A85-\u0A8D\u0A8F-\u0A91\u0A93-\u0AA8]|[\u0AAA-\u0AB0\u0AB2\u0AB3\u0AB5-\u0AB9\u0ABD\u0AD0\u0AE0\u0AE1\u0B05-\u0B0C]|[\u0B0F\u0B10\u0B13-\u0B28\u0B2A-\u0B30\u0B32\u0B33\u0B35-\u0B39\u0B3D\u0B5C]|[\u0B5D\u0B5F-\u0B61\u0B71\u0B83\u0B85-\u0B8A\u0B8E-\u0B90\u0B92-\u0B95\u0B99]|[\u0B9A\u0B9C\u0B9E\u0B9F\u0BA3\u0BA4\u0BA8-\u0BAA\u0BAE-\u0BB9\u0BD0]|[\u0C05-\u0C0C\u0C0E-\u0C10\u0C12-\u0C28\u0C2A-\u0C33\u0C35-\u0C39\u0C3D]|[\u0C58\u0C59\u0C60\u0C61\u0C85-\u0C8C\u0C8E-\u0C90\u0C92-\u0CA8\u0CAA-\u0CB3]|[\u0CB5-\u0CB9\u0CBD\u0CDE\u0CE0\u0CE1\u0CF1\u0CF2\u0D05-\u0D0C\u0D0E-\u0D10]|[\u0D12-\u0D3A\u0D3D\u0D4E\u0D60\u0D61\u0D7A-\u0D7F\u0D85-\u0D96\u0D9A-\u0DB1]|[\u0DB3-\u0DBB\u0DBD\u0DC0-\u0DC6\u0E01-\u0E30\u0E32\u0E33\u0E40-\u0E46\u0E81]|[\u0E82\u0E84\u0E87\u0E88\u0E8A\u0E8D\u0E94-\u0E97\u0E99-\u0E9F\u0EA1-\u0EA3]|[\u0EA5\u0EA7\u0EAA\u0EAB\u0EAD-\u0EB0\u0EB2\u0EB3\u0EBD\u0EC0-\u0EC4\u0EC6]|[\u0EDC-\u0EDF\u0F00\u0F40-\u0F47\u0F49-\u0F6C\u0F88-\u0F8C\u1000-\u102A]|[\u103F\u1050-\u1055\u105A-\u105D\u1061\u1065\u1066\u106E-\u1070\u1075-\u1081]|[\u108E\u10A0-\u10C5\u10C7\u10CD\u10D0-\u10FA\u10FC-\u1248\u124A-\u124D]|[\u1250-\u1256\u1258\u125A-\u125D\u1260-\u1288\u128A-\u128D\u1290-\u12B0]|[\u12B2-\u12B5\u12B8-\u12BE\u12C0\u12C2-\u12C5\u12C8-\u12D6\u12D8-\u1310]|[\u1312-\u1315\u1318-\u135A\u1380-\u138F\u13A0-\u13F4\u1401-\u166C]|[\u166F-\u167F\u1681-\u169A\u16A0-\u16EA\u1700-\u170C\u170E-\u1711]|[\u1720-\u1731\u1740-\u1751\u1760-\u176C\u176E-\u1770\u1780-\u17B3\u17D7]|[\u17DC\u1820-\u1877\u1880-\u18A8\u18AA\u18B0-\u18F5\u1900-\u191C]|[\u1950-\u196D\u1970-\u1974\u1980-\u19AB\u19C1-\u19C7\u1A00-\u1A16]|[\u1A20-\u1A54\u1AA7\u1B05-\u1B33\u1B45-\u1B4B\u1B83-\u1BA0\u1BAE\u1BAF]|[\u1BBA-\u1BE5\u1C00-\u1C23\u1C4D-\u1C4F\u1C5A-\u1C7D\u1CE9-\u1CEC]|[\u1CEE-\u1CF1\u1CF5\u1CF6\u1D00-\u1DBF\u1E00-\u1F15\u1F18-\u1F1D]|[\u1F20-\u1F45\u1F48-\u1F4D\u1F50-\u1F57\u1F59\u1F5B\u1F5D\u1F5F-\u1F7D]|[\u1F80-\u1FB4\u1FB6-\u1FBC\u1FBE\u1FC2-\u1FC4\u1FC6-\u1FCC\u1FD0-\u1FD3]|[\u1FD6-\u1FDB\u1FE0-\u1FEC\u1FF2-\u1FF4\u1FF6-\u1FFC\u2071\u207F]|[\u2090-\u209C\u2102\u2107\u210A-\u2113\u2115\u2119-\u211D\u2124\u2126\u2128]|[\u212A-\u212D\u212F-\u2139\u213C-\u213F\u2145-\u2149\u214E\u2183\u2184]|[\u2C00-\u2C2E\u2C30-\u2C5E\u2C60-\u2CE4\u2CEB-\u2CEE\u2CF2\u2CF3]|[\u2D00-\u2D25\u2D27\u2D2D\u2D30-\u2D67\u2D6F\u2D80-\u2D96\u2DA0-\u2DA6]|[\u2DA8-\u2DAE\u2DB0-\u2DB6\u2DB8-\u2DBE\u2DC0-\u2DC6\u2DC8-\u2DCE]|[\u2DD0-\u2DD6\u2DD8-\u2DDE\u2E2F\u3005\u3006\u3031-\u3035\u303B\u303C]|[\u3041-\u3096\u309D-\u309F\u30A1-\u30FA\u30FC-\u30FF\u3105-\u312D]|[\u3131-\u318E\u31A0-\u31BA\u31F0-\u31FF\u3400-\u4DB5\u4E00-\u9FCC]|[\uA000-\uA48C\uA4D0-\uA4FD\uA500-\uA60C\uA610-\uA61F\uA62A\uA62B]|[\uA640-\uA66E\uA67F-\uA697\uA6A0-\uA6E5\uA717-\uA71F\uA722-\uA788]|[\uA78B-\uA78E\uA790-\uA793\uA7A0-\uA7AA\uA7F8-\uA801\uA803-\uA805]|[\uA807-\uA80A\uA80C-\uA822\uA840-\uA873\uA882-\uA8B3\uA8F2-\uA8F7\uA8FB]|[\uA90A-\uA925\uA930-\uA946\uA960-\uA97C\uA984-\uA9B2\uA9CF\uAA00-\uAA28]|[\uAA40-\uAA42\uAA44-\uAA4B\uAA60-\uAA76\uAA7A\uAA80-\uAAAF\uAAB1\uAAB5]|[\uAAB6\uAAB9-\uAABD\uAAC0\uAAC2\uAADB-\uAADD\uAAE0-\uAAEA\uAAF2-\uAAF4]|[\uAB01-\uAB06\uAB09-\uAB0E\uAB11-\uAB16\uAB20-\uAB26\uAB28-\uAB2E]|[\uABC0-\uABE2\uAC00-\uD7A3\uD7B0-\uD7C6\uD7CB-\uD7FB\uF900-\uFA6D]|[\uFA70-\uFAD9\uFB00-\uFB06\uFB13-\uFB17\uFB1D\uFB1F-\uFB28\uFB2A-\uFB36]|[\uFB38-\uFB3C\uFB3E\uFB40\uFB41\uFB43\uFB44\uFB46-\uFBB1\uFBD3-\uFD3D]|[\uFD50-\uFD8F\uFD92-\uFDC7\uFDF0-\uFDFB\uFE70-\uFE74\uFE76-\uFEFC]|[\uFF21-\uFF3A\uFF41-\uFF5A\uFF66-\uFFBE\uFFC2-\uFFC7\uFFCA-\uFFCF]|[\uFFD2-\uFFD7\uFFDA-\uFFDC])/, /^(?:\s)/, /^(?:\s)/, /^(?:$)/], conditions: { "namespace-body": { rules: [26, 29, 34, 35, 36, 37, 38, 39, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, namespace: { rules: [26, 29, 30, 31, 32, 33, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, "class-body": { rules: [26, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, class: { rules: [26, 40, 41, 42, 43, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, acc_descr_multiline: { rules: [11, 12, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, acc_descr: { rules: [9, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, acc_title: { rules: [7, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, callback_args: { rules: [22, 23, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, callback_name: { rules: [19, 20, 21, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, href: { rules: [26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, struct: { rules: [26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, generic: { rules: [26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, bqstring: { rules: [26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, string: { rules: [24, 25, 26, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 98], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 8, 10, 13, 14, 15, 16, 17, 18, 26, 27, 28, 29, 39, 50, 51, 52, 53, 54, 55, 56, 57, 58, 61, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98], inclusive: !0 } } };
        return O;
    })();
    Le.lexer = kt;
    function ce() { this.yy = {}; }
    return b(ce, "Parser"), ce.prototype = Le, Le.Parser = ce, new ce;
})();
Ve.parser = Ve;
var Vt = Ve, At = ["#", "+", "~", "-", ""], bt = class {
    static { b(this, "ClassMember"); }
    constructor(t, i) { this.memberType = i, this.visibility = "", this.classifier = "", this.text = ""; let a = $e(t, F()); this.parseMember(a); }
    getDisplayDetails() { let t = this.visibility + P(this.id); this.memberType === "method" && (t += `(${P(this.parameters.trim())})`, this.returnType && (t += " : " + P(this.returnType))), t = t.trim(); let i = this.parseClassifier(); return { displayText: t, cssStyle: i }; }
    parseMember(t) { let i = ""; if (this.memberType === "method") {
        let n = /([#+~-])?(.+)\((.*)\)([\s$*])?(.*)([$*])?/.exec(t);
        if (n) {
            let c = n[1] ? n[1].trim() : "";
            if (At.includes(c) && (this.visibility = c), this.id = n[2], this.parameters = n[3] ? n[3].trim() : "", i = n[4] ? n[4].trim() : "", this.returnType = n[5] ? n[5].trim() : "", i === "") {
                let u = this.returnType.substring(this.returnType.length - 1);
                /[$*]/.exec(u) && (i = u, this.returnType = this.returnType.substring(0, this.returnType.length - 1));
            }
        }
    }
    else {
        let r = t.length, n = t.substring(0, 1), c = t.substring(r - 1);
        At.includes(n) && (this.visibility = n), /[$*]/.exec(c) && (i = c), this.id = t.substring(this.visibility === "" ? 0 : 1, i === "" ? r : r - 1);
    } this.classifier = i, this.id = this.id.startsWith(" ") ? " " + this.id.trim() : this.id.trim(); let a = `${this.visibility ? "\\" + this.visibility : ""}${P(this.id)}${this.memberType === "method" ? `(${P(this.parameters)})${this.returnType ? " : " + P(this.returnType) : ""}` : ""}`; this.text = a.replaceAll("<", "&lt;").replaceAll(">", "&gt;"), this.text.startsWith("\\&lt;") && (this.text = this.text.replace("\\&lt;", "~")); }
    parseClassifier() { switch (this.classifier) {
        case "*": return "font-style:italic;";
        case "$": return "text-decoration:underline;";
        default: return "";
    } }
}, be = "classId-", ft = 0, M = b(t => v.sanitizeText(t, F()), "sanitizeText"), Rt = class Pe {
    constructor() { this.relations = [], this.classes = new Map, this.styleClasses = new Map, this.notes = new Map, this.interfaces = [], this.namespaces = new Map, this.namespaceCounter = 0, this.namespaceStack = [], this.diagramId = "", this.functions = [], this.lineType = { LINE: 0, DOTTED_LINE: 1 }, this.relationType = { AGGREGATION: 0, EXTENSION: 1, COMPOSITION: 2, DEPENDENCY: 3, LOLLIPOP: 4 }, this.setupToolTips = b(i => { let a = ot(); Z(i).select("svg").selectAll("g").filter(function () { return Z(this).attr("title") !== null; }).on("mouseover", c => { let u = Z(c.currentTarget), d = u.attr("title"); if (!d)
        return; let k = c.currentTarget.getBoundingClientRect(); a.transition().duration(200).style("opacity", ".9"), a.html(Ze.sanitize(d)).style("left", `${window.scrollX + k.left + k.width / 2}px`).style("top", `${window.scrollY + k.bottom + 4}px`), u.classed("hover", !0); }).on("mouseout", c => { a.transition().duration(500).style("opacity", 0), Z(c.currentTarget).classed("hover", !1); }); }, "setupToolTips"), this.direction = "TB", this.setAccTitle = tt, this.getAccTitle = st, this.setAccDescription = it, this.getAccDescription = at, this.setDiagramTitle = rt, this.getDiagramTitle = nt, this.getConfig = b(() => F().class, "getConfig"), this.functions.push(this.setupToolTips.bind(this)), this.clear(), this.addRelation = this.addRelation.bind(this), this.addClassesToNamespace = this.addClassesToNamespace.bind(this), this.addNamespace = this.addNamespace.bind(this), this.popNamespace = this.popNamespace.bind(this), this.setCssClass = this.setCssClass.bind(this), this.addMembers = this.addMembers.bind(this), this.addClass = this.addClass.bind(this), this.setClassLabel = this.setClassLabel.bind(this), this.addAnnotation = this.addAnnotation.bind(this), this.addMember = this.addMember.bind(this), this.cleanupLabel = this.cleanupLabel.bind(this), this.addNote = this.addNote.bind(this), this.defineClass = this.defineClass.bind(this), this.setDirection = this.setDirection.bind(this), this.setLink = this.setLink.bind(this), this.bindFunctions = this.bindFunctions.bind(this), this.clear = this.clear.bind(this), this.setTooltip = this.setTooltip.bind(this), this.setClickEvent = this.setClickEvent.bind(this), this.setCssStyle = this.setCssStyle.bind(this); }
    static { b(this, "ClassDB"); }
    splitClassNameAndType(i) { let a = v.sanitizeText(i, F()), r = "", n = a; if (a.indexOf("~") > 0) {
        let c = a.split("~");
        n = M(c[0]), r = M(c[1]);
    } return { className: n, type: r }; }
    setClassLabel(i, a) { let r = v.sanitizeText(i, F()); a && (a = M(a)); let { className: n } = this.splitClassNameAndType(r); this.classes.get(n).label = a, this.classes.get(n).text = `${a}${this.classes.get(n).type ? `<${this.classes.get(n).type}>` : ""}`; }
    addClass(i) { let a = v.sanitizeText(i, F()), { className: r, type: n } = this.splitClassNameAndType(a); if (this.classes.has(r))
        return; let c = v.sanitizeText(r, F()); this.classes.set(c, { id: c, type: n, label: c, text: `${c}${n ? `&lt;${n}&gt;` : ""}`, shape: "classBox", cssClasses: "default", methods: [], members: [], annotations: [], styles: [], domId: be + c + "-" + ft }), ft++; }
    addInterface(i, a) { let r = { id: `interface${this.interfaces.length}`, label: i, classId: a }; this.interfaces.push(r); }
    setDiagramId(i) { this.diagramId = i; }
    lookUpDomId(i) { let a = v.sanitizeText(i, F()); if (this.classes.has(a)) {
        let r = this.classes.get(a).domId;
        return this.diagramId ? `${this.diagramId}-${r}` : r;
    } throw new Error("Class not found: " + a); }
    clear() { this.relations = [], this.classes = new Map, this.notes = new Map, this.interfaces = [], this.functions = [], this.functions.push(this.setupToolTips.bind(this)), this.namespaces = new Map, this.namespaceCounter = 0, this.namespaceStack = [], this.diagramId = "", this.direction = "TB", et(); }
    getClass(i) { return this.classes.get(i); }
    getClasses() { return this.classes; }
    getRelations() { return this.relations; }
    getNote(i) { let a = typeof i == "number" ? `note${i}` : i; return this.notes.get(a); }
    getNotes() { return this.notes; }
    addRelation(i) { pe.debug("Adding relation: " + JSON.stringify(i)); let a = [this.relationType.LOLLIPOP, this.relationType.AGGREGATION, this.relationType.COMPOSITION, this.relationType.DEPENDENCY, this.relationType.EXTENSION]; i.relation.type1 === this.relationType.LOLLIPOP && !a.includes(i.relation.type2) ? (this.addClass(i.id2), this.addInterface(i.id1, i.id2), i.id1 = `interface${this.interfaces.length - 1}`) : i.relation.type2 === this.relationType.LOLLIPOP && !a.includes(i.relation.type1) ? (this.addClass(i.id1), this.addInterface(i.id2, i.id1), i.id2 = `interface${this.interfaces.length - 1}`) : (this.addClass(i.id1), this.addClass(i.id2)), i.id1 = this.splitClassNameAndType(i.id1).className, i.id2 = this.splitClassNameAndType(i.id2).className, i.relationTitle1 = v.sanitizeText(i.relationTitle1.trim(), F()), i.relationTitle2 = v.sanitizeText(i.relationTitle2.trim(), F()), this.relations.push(i); }
    addAnnotation(i, a) { let r = this.splitClassNameAndType(i).className; this.classes.get(r).annotations.push(a); }
    addMember(i, a) { this.addClass(i); let r = this.splitClassNameAndType(i).className, n = this.classes.get(r); if (typeof a == "string") {
        let c = a.trim();
        c.startsWith("<<") && c.endsWith(">>") ? n.annotations.push(M(c.substring(2, c.length - 2))) : c.indexOf(")") > 0 ? n.methods.push(new bt(c, "method")) : c && n.members.push(new bt(c, "attribute"));
    } }
    addMembers(i, a) { Array.isArray(a) && (a.reverse(), a.forEach(r => this.addMember(i, r))); }
    addNote(i, a) { let r = this.notes.size, n = { id: `note${r}`, class: a, text: i, index: r }; return this.notes.set(n.id, n), n.id; }
    cleanupLabel(i) { return i.startsWith(":") && (i = i.substring(1)), M(i.trim()); }
    setCssClass(i, a) { i.split(",").forEach(r => { let n = r; /\d/.exec(r[0]) && (n = be + n), n = this.splitClassNameAndType(n).className; let c = this.classes.get(n); c && (c.cssClasses += " " + a); }); }
    defineClass(i, a) { for (let r of i) {
        let n = this.styleClasses.get(r);
        n === void 0 && (n = { id: r, styles: [], textStyles: [] }, this.styleClasses.set(r, n)), a && a.forEach(c => { if (/color/.exec(c)) {
            let u = c.replace("fill", "bgFill");
            n.textStyles.push(u);
        } n.styles.push(c); }), this.classes.forEach(c => { c.cssClasses.includes(r) && c.styles.push(...a.flatMap(u => u.split(","))); });
    } }
    setTooltip(i, a) { i.split(",").forEach(r => { if (a !== void 0) {
        let n = this.splitClassNameAndType(r).className, c = this.classes.get(n);
        c && (c.tooltip = M(a));
    } }); }
    getTooltip(i, a) { return a && this.namespaces.has(a) ? this.namespaces.get(a).classes.get(i).tooltip : this.classes.get(i).tooltip; }
    setLink(i, a, r) { let n = F(); i.split(",").forEach(c => { let u = c; /\d/.exec(c[0]) && (u = be + u), u = this.splitClassNameAndType(u).className; let d = this.classes.get(u); d && (d.link = Ae.formatUrl(a, n), n.securityLevel === "sandbox" ? d.linkTarget = "_top" : typeof r == "string" ? d.linkTarget = M(r) : d.linkTarget = "_blank"); }), this.setCssClass(i, "clickable"); }
    setClickEvent(i, a, r) { i.split(",").forEach(n => { this.setClickFunc(n, a, r); let c = this.splitClassNameAndType(n).className, u = this.classes.get(c); u && (u.haveCallback = !0); }), this.setCssClass(i, "clickable"); }
    setClickFunc(i, a, r) { let n = v.sanitizeText(i, F()); if (F().securityLevel !== "loose" || a === void 0)
        return; let u = this.splitClassNameAndType(n).className; if (this.classes.has(u)) {
        let d = [];
        if (typeof r == "string") {
            d = r.split(/,(?=(?:(?:[^"]*"){2})*[^"]*$)/);
            for (let k = 0; k < d.length; k++) {
                let f = d[k].trim();
                f.startsWith('"') && f.endsWith('"') && (f = f.substr(1, f.length - 2)), d[k] = f;
            }
        }
        d.length === 0 && d.push(u), this.functions.push(() => { let k = this.lookUpDomId(u), f = document.querySelector(`[id="${k}"]`); f !== null && f.addEventListener("click", () => { Ae.runFunc(a, ...d); }, !1); });
    } }
    bindFunctions(i) { this.functions.forEach(a => { a(i); }); }
    escapeHtml(i) { return i.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#39;"); }
    getDirection() { return this.direction; }
    setDirection(i) { this.direction = i; }
    static resolveQualifiedId(i, a) { let r = a.at(-1); return r ? `${r}.${i}` : i; }
    static getAncestorIds(i) { let a = i.split("."), r = new Array(a.length); r[0] = a[0]; for (let n = 1; n < a.length; n++)
        r[n] = `${r[n - 1]}.${a[n]}`; return r; }
    createNamespaceNode(i, a, r, n = !1) { return { id: i, label: a, classes: new Map, notes: new Map, children: new Map, domId: be + i + "-" + this.namespaceCounter++, parent: r, explicit: n }; }
    linkParentChild(i, a) { let r = this.namespaces.get(i), n = this.namespaces.get(a); !r || !n || (r.children.has(a) || r.children.set(a, n), n.parent ??= i); }
    addNamespace(i, a) { let r = Pe.resolveQualifiedId(i, this.namespaceStack); if (this.namespaceStack.push(r), this.namespaces.has(r)) {
        let u = this.namespaces.get(r);
        return u.explicit = !0, a && (u.label = a), r;
    } let n = r.split("."), c = Pe.getAncestorIds(r); for (let u = 0; u < c.length; u++) {
        let d = c[u], k = u > 0 ? c[u - 1] : void 0, f = u === c.length - 1, N = f && a ? a : n[u];
        this.namespaces.has(d) ? f && (this.namespaces.get(d).explicit = !0) : this.namespaces.set(d, this.createNamespaceNode(d, N, k, f)), k && this.linkParentChild(k, d);
    } return r; }
    popNamespace() { this.namespaceStack.pop(); }
    getNamespace(i) { return this.namespaces.get(i); }
    getNamespaces() { return this.namespaces; }
    addClassesToNamespace(i, a, r) { if (this.namespaces.has(i)) {
        for (let n of a) {
            let { className: c } = this.splitClassNameAndType(n), u = this.getClass(c);
            u.parent = i, this.namespaces.get(i).classes.set(c, u);
        }
        for (let n of r) {
            let c = this.getNote(n);
            c.parent = i, this.namespaces.get(i).notes.set(n, c);
        }
    } }
    setCssStyle(i, a) { let r = this.classes.get(i); if (!(!a || !r))
        for (let n of a)
            n.includes(",") ? r.styles.push(...n.split(",")) : r.styles.push(n); }
    getArrowMarker(i) { let a; switch (i) {
        case 0:
            a = "aggregation";
            break;
        case 1:
            a = "extension";
            break;
        case 2:
            a = "composition";
            break;
        case 3:
            a = "dependency";
            break;
        case 4:
            a = "lollipop";
            break;
        default: a = "none";
    } return a; }
    resolveExplicitAncestor(i) { let a = i; for (; a;) {
        let r = this.namespaces.get(a);
        if (!r)
            return;
        if (r.explicit)
            return a;
        a = r.parent;
    } }
    getData() { let i = [], a = [], r = F(), n = r.class?.hierarchicalNamespaces ?? !0; for (let u of this.namespaces.values()) {
        if (!n && !u.explicit)
            continue;
        let d = { id: u.id, label: n ? u.label : u.id, isGroup: !0, padding: r.class.padding ?? 16, shape: "rect", cssStyles: [], look: r.look, parentId: n ? u.parent : void 0 };
        i.push(d);
    } for (let u of this.classes.values()) {
        let d = n ? u.parent : this.resolveExplicitAncestor(u.parent), k = He(qe({}, u), { type: void 0, isGroup: !1, parentId: d, look: r.look });
        i.push(k);
    } for (let u of this.notes.values()) {
        let d = n ? u.parent : this.resolveExplicitAncestor(u.parent), k = { id: u.id, label: u.text, isGroup: !1, shape: "note", padding: r.class.padding ?? 6, cssStyles: ["text-align: left", "white-space: nowrap", `fill: ${r.themeVariables.noteBkgColor}`, `stroke: ${r.themeVariables.noteBorderColor}`], look: r.look, parentId: d, labelType: "markdown" };
        i.push(k);
        let f = this.classes.get(u.class)?.id;
        if (f) {
            let N = { id: `edgeNote${u.index}`, start: u.id, end: f, type: "normal", thickness: "normal", classes: "relation", arrowTypeStart: "none", arrowTypeEnd: "none", arrowheadStyle: "", labelStyle: [""], style: ["fill: none"], pattern: "dotted", look: r.look };
            a.push(N);
        }
    } for (let u of this.interfaces) {
        let d = { id: u.id, label: u.label, isGroup: !1, shape: "rect", cssStyles: ["opacity: 0;"], look: r.look };
        i.push(d);
    } let c = 0; for (let u of this.relations) {
        c++;
        let d = { id: ut(u.id1, u.id2, { prefix: "id", counter: c }), start: u.id1, end: u.id2, type: "normal", label: u.title, labelpos: "c", thickness: "normal", classes: "relation", arrowTypeStart: this.getArrowMarker(u.relation.type1), arrowTypeEnd: this.getArrowMarker(u.relation.type2), startLabelRight: u.relationTitle1 === "none" ? "" : u.relationTitle1, endLabelLeft: u.relationTitle2 === "none" ? "" : u.relationTitle2, arrowheadStyle: "", labelStyle: ["display: inline-block"], style: u.style || "", pattern: u.relation.lineType == 1 ? "dashed" : "solid", look: r.look, labelType: "markdown" };
        a.push(d);
    } return { nodes: i, edges: a, other: {}, config: r, direction: this.getDirection() }; }
}, Tt = b(t => `g.classGroup text {
  fill: ${t.nodeBorder || t.classText};
  stroke: none;
  font-family: ${t.fontFamily};
  font-size: 10px;

  .title {
    font-weight: bolder;
  }

}

  .cluster-label text {
    fill: ${t.titleColor};
  }
  .cluster-label span {
    color: ${t.titleColor};
  }
  .cluster-label span p {
    background-color: transparent;
  }

  .cluster rect {
    fill: ${t.clusterBkg};
    stroke: ${t.clusterBorder};
    stroke-width: 1px;
  }

  .cluster text {
    fill: ${t.titleColor};
  }

  .cluster span {
    color: ${t.titleColor};
  }

.nodeLabel, .edgeLabel {
  color: ${t.classText};
}

.noteLabel .nodeLabel, .noteLabel .edgeLabel {
  color: ${t.noteTextColor};
}
.edgeLabel .label rect {
  fill: ${t.mainBkg};
}
.label text {
  fill: ${t.classText};
}

.labelBkg {
  background: ${t.mainBkg};
}
.edgeLabel .label span {
  background: ${t.mainBkg};
}

.classTitle {
  font-weight: bolder;
}
.node rect,
  .node circle,
  .node ellipse,
  .node polygon,
  .node path {
    fill: ${t.mainBkg};
    stroke: ${t.nodeBorder};
    stroke-width: ${t.strokeWidth};
  }


.divider {
  stroke: ${t.nodeBorder};
  stroke-width: 1;
}

g.clickable {
  cursor: pointer;
}

g.classGroup rect {
  fill: ${t.mainBkg};
  stroke: ${t.nodeBorder};
}

g.classGroup line {
  stroke: ${t.nodeBorder};
  stroke-width: 1;
}

.classLabel .box {
  stroke: none;
  stroke-width: 0;
  fill: ${t.mainBkg};
  opacity: 0.5;
}

.classLabel .label {
  fill: ${t.nodeBorder};
  font-size: 10px;
}

.relation {
  stroke: ${t.lineColor};
  stroke-width: ${t.strokeWidth};
  fill: none;
}

.dashed-line{
  stroke-dasharray: 3;
}

.dotted-line{
  stroke-dasharray: 1 2;
}

[id$="-compositionStart"], .composition {
  fill: ${t.lineColor} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-compositionEnd"], .composition {
  fill: ${t.lineColor} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-dependencyStart"], .dependency {
  fill: ${t.lineColor} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-dependencyEnd"], .dependency {
  fill: ${t.lineColor} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-extensionStart"], .extension {
  fill: transparent !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-extensionEnd"], .extension {
  fill: transparent !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-aggregationStart"], .aggregation {
  fill: transparent !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-aggregationEnd"], .aggregation {
  fill: transparent !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-lollipopStart"], .lollipop {
  fill: ${t.mainBkg} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

[id$="-lollipopEnd"], .lollipop {
  fill: ${t.mainBkg} !important;
  stroke: ${t.lineColor} !important;
  stroke-width: 1;
}

.edgeTerminals {
  font-size: 11px;
  line-height: initial;
}

.classTitleText {
  text-anchor: middle;
  font-size: 18px;
  fill: ${t.textColor};
}

.edgeLabel[data-look="neo"] {
  background-color: ${t.edgeLabelBackground};
  p {
    background-color: ${t.edgeLabelBackground};
  }
  rect {
    opacity: 0.5;
    background-color: ${t.edgeLabelBackground};
    fill: ${t.edgeLabelBackground};
  }
  text-align: center;
}
  ${ht()}
`, "getStyles"), Gt = Tt, yt = b((t, i = "TB") => { if (!t.doc)
    return i; let a = i; for (let r of t.doc)
    r.stmt === "dir" && (a = r.value); return a; }, "getDir"), Dt = b(function (t, i) { return i.db.getClasses(); }, "getClasses"), Ft = b(function (t, i, a, r) { return Je(this, null, function* () { pe.info("REF0:"), pe.info("Drawing class diagram (v3)", i); let { securityLevel: n, state: c, layout: u } = F(); r.db.setDiagramId(i); let d = r.db.getData(), k = dt(i, n); d.type = r.type, d.layoutAlgorithm = ct(u), d.nodeSpacing = c?.nodeSpacing || 50, d.rankSpacing = c?.rankSpacing || 50, d.markers = ["aggregation", "extension", "composition", "dependency", "lollipop"], d.diagramId = i, yield lt(d, k); let f = 8; Ae.insertTitle(k, "classDiagramTitleText", c?.titleTopMargin ?? 25, r.db.getDiagramTitle()), pt(k, f, "classDiagram", c?.useMaxWidth ?? !0); }); }, "draw"), Ut = { getClasses: Dt, draw: Ft, getDir: yt };
export { Vt as a, Rt as b, Gt as c, Ut as d };
