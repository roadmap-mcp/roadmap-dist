import { a as r, b as e } from "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { r as RadarModule, e as createRadarServices };
