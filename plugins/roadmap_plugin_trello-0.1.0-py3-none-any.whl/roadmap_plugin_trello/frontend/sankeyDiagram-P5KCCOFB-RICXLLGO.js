import { N as xt, P as kt, T as _t, U as vt, V as bt, W as St, X as Lt, Y as wt, Z as Et, _ as Q, aa as At } from "@nf-internal/chunk-LEJRRF65";
import { E as Tt, h as G, m as Ct } from "@nf-internal/chunk-RZWXGGKD";
import { a as d } from "@nf-internal/chunk-YUSHYV7C";
import "@nf-internal/chunk-OSQMNGTH";
function X(t, o) { let s; if (o === void 0)
    for (let u of t)
        u != null && (s < u || s === void 0 && u >= u) && (s = u);
else {
    let u = -1;
    for (let f of t)
        (f = o(f, ++u, t)) != null && (s < f || s === void 0 && f >= f) && (s = f);
} return s; }
function U(t, o) { let s; if (o === void 0)
    for (let u of t)
        u != null && (s > u || s === void 0 && u >= u) && (s = u);
else {
    let u = -1;
    for (let f of t)
        (f = o(f, ++u, t)) != null && (s > f || s === void 0 && f >= f) && (s = f);
} return s; }
function H(t, o) { let s = 0; if (o === void 0)
    for (let u of t)
        (u = +u) && (s += u);
else {
    let u = -1;
    for (let f of t)
        (f = +o(f, ++u, t)) && (s += f);
} return s; }
function Bt(t) { return t.target.depth; }
function st(t) { return t.depth; }
function it(t, o) { return o - 1 - t.height; }
function J(t, o) { return t.sourceLinks.length ? t.depth : o - 1; }
function at(t) { return t.targetLinks.length ? t.depth : t.sourceLinks.length ? U(t.sourceLinks, Bt) - 1 : 0; }
function Y(t) { return function () { return t; }; }
function Mt(t, o) { return K(t.source, o.source) || t.index - o.index; }
function Ot(t, o) { return K(t.target, o.target) || t.index - o.index; }
function K(t, o) { return t.y0 - o.y0; }
function lt(t) { return t.value; }
function $t(t) { return t.index; }
function Vt(t) { return t.nodes; }
function Ft(t) { return t.links; }
function Nt(t, o) { let s = t.get(o); if (!s)
    throw new Error("missing: " + o); return s; }
function It({ nodes: t }) { for (let o of t) {
    let s = o.y0, u = s;
    for (let f of o.sourceLinks)
        f.y0 = s + f.width / 2, s += f.width;
    for (let f of o.targetLinks)
        f.y1 = u + f.width / 2, u += f.width;
} }
function Z() { let t = 0, o = 0, s = 1, u = 1, f = 24, _ = 8, y, g = $t, i = J, a, c, x = Vt, k = Ft, p = 6; function v() { let e = { nodes: x.apply(null, arguments), links: k.apply(null, arguments) }; return A(e), E(e), T(e), M(e), R(e), It(e), e; } v.update = function (e) { return It(e), e; }, v.nodeId = function (e) { return arguments.length ? (g = typeof e == "function" ? e : Y(e), v) : g; }, v.nodeAlign = function (e) { return arguments.length ? (i = typeof e == "function" ? e : Y(e), v) : i; }, v.nodeSort = function (e) { return arguments.length ? (a = e, v) : a; }, v.nodeWidth = function (e) { return arguments.length ? (f = +e, v) : f; }, v.nodePadding = function (e) { return arguments.length ? (_ = y = +e, v) : _; }, v.nodes = function (e) { return arguments.length ? (x = typeof e == "function" ? e : Y(e), v) : x; }, v.links = function (e) { return arguments.length ? (k = typeof e == "function" ? e : Y(e), v) : k; }, v.linkSort = function (e) { return arguments.length ? (c = e, v) : c; }, v.size = function (e) { return arguments.length ? (t = o = 0, s = +e[0], u = +e[1], v) : [s - t, u - o]; }, v.extent = function (e) { return arguments.length ? (t = +e[0][0], s = +e[1][0], o = +e[0][1], u = +e[1][1], v) : [[t, o], [s, u]]; }, v.iterations = function (e) { return arguments.length ? (p = +e, v) : p; }; function A({ nodes: e, links: l }) { for (let [n, r] of e.entries())
    r.index = n, r.sourceLinks = [], r.targetLinks = []; let h = new Map(e.map((n, r) => [g(n, r, e), n])); for (let [n, r] of l.entries()) {
    r.index = n;
    let { source: m, target: b } = r;
    typeof m != "object" && (m = r.source = Nt(h, m)), typeof b != "object" && (b = r.target = Nt(h, b)), m.sourceLinks.push(r), b.targetLinks.push(r);
} if (c != null)
    for (let { sourceLinks: n, targetLinks: r } of e)
        n.sort(c), r.sort(c); } function E({ nodes: e }) { for (let l of e)
    l.value = l.fixedValue === void 0 ? Math.max(H(l.sourceLinks, lt), H(l.targetLinks, lt)) : l.fixedValue; } function T({ nodes: e }) { let l = e.length, h = new Set(e), n = new Set, r = 0; for (; h.size;) {
    for (let m of h) {
        m.depth = r;
        for (let { target: b } of m.sourceLinks)
            n.add(b);
    }
    if (++r > l)
        throw new Error("circular link");
    h = n, n = new Set;
} } function M({ nodes: e }) { let l = e.length, h = new Set(e), n = new Set, r = 0; for (; h.size;) {
    for (let m of h) {
        m.height = r;
        for (let { source: b } of m.targetLinks)
            n.add(b);
    }
    if (++r > l)
        throw new Error("circular link");
    h = n, n = new Set;
} } function O({ nodes: e }) { let l = X(e, r => r.depth) + 1, h = (s - t - f) / (l - 1), n = new Array(l); for (let r of e) {
    let m = Math.max(0, Math.min(l - 1, Math.floor(i.call(null, r, l))));
    r.layer = m, r.x0 = t + m * h, r.x1 = r.x0 + f, n[m] ? n[m].push(r) : n[m] = [r];
} if (a)
    for (let r of n)
        r.sort(a); return n; } function P(e) { let l = U(e, h => (u - o - (h.length - 1) * y) / H(h, lt)); for (let h of e) {
    let n = o;
    for (let r of h) {
        r.y0 = n, r.y1 = n + r.value * l, n = r.y1 + y;
        for (let m of r.sourceLinks)
            m.width = m.value * l;
    }
    n = (u - n + y) / (h.length + 1);
    for (let r = 0; r < h.length; ++r) {
        let m = h[r];
        m.y0 += n * (r + 1), m.y1 += n * (r + 1);
    }
    V(h);
} } function R(e) { let l = O(e); y = Math.min(_, (u - o) / (X(l, h => h.length) - 1)), P(l); for (let h = 0; h < p; ++h) {
    let n = Math.pow(.99, h), r = Math.max(1 - n, (h + 1) / p);
    N(l, n, r), S(l, n, r);
} } function S(e, l, h) { for (let n = 1, r = e.length; n < r; ++n) {
    let m = e[n];
    for (let b of m) {
        let $ = 0, C = 0;
        for (let { source: w, value: ot } of b.targetLinks) {
            let q = ot * (b.layer - w.layer);
            $ += L(w, b) * q, C += q;
        }
        if (!(C > 0))
            continue;
        let D = ($ / C - b.y0) * l;
        b.y0 += D, b.y1 += D, W(b);
    }
    a === void 0 && m.sort(K), j(m, h);
} } function N(e, l, h) { for (let n = e.length, r = n - 2; r >= 0; --r) {
    let m = e[r];
    for (let b of m) {
        let $ = 0, C = 0;
        for (let { target: w, value: ot } of b.sourceLinks) {
            let q = ot * (w.layer - b.layer);
            $ += z(b, w) * q, C += q;
        }
        if (!(C > 0))
            continue;
        let D = ($ / C - b.y0) * l;
        b.y0 += D, b.y1 += D, W(b);
    }
    a === void 0 && m.sort(K), j(m, h);
} } function j(e, l) { let h = e.length >> 1, n = e[h]; I(e, n.y0 - y, h - 1, l), B(e, n.y1 + y, h + 1, l), I(e, u, e.length - 1, l), B(e, o, 0, l); } function B(e, l, h, n) { for (; h < e.length; ++h) {
    let r = e[h], m = (l - r.y0) * n;
    m > 1e-6 && (r.y0 += m, r.y1 += m), l = r.y1 + y;
} } function I(e, l, h, n) { for (; h >= 0; --h) {
    let r = e[h], m = (r.y1 - l) * n;
    m > 1e-6 && (r.y0 -= m, r.y1 -= m), l = r.y0 - y;
} } function W({ sourceLinks: e, targetLinks: l }) { if (c === void 0) {
    for (let { source: { sourceLinks: h } } of l)
        h.sort(Ot);
    for (let { target: { targetLinks: h } } of e)
        h.sort(Mt);
} } function V(e) { if (c === void 0)
    for (let { sourceLinks: l, targetLinks: h } of e)
        l.sort(Ot), h.sort(Mt); } function L(e, l) { let h = e.y0 - (e.sourceLinks.length - 1) * y / 2; for (let { target: n, width: r } of e.sourceLinks) {
    if (n === l)
        break;
    h += r + y;
} for (let { source: n, width: r } of l.targetLinks) {
    if (n === e)
        break;
    h -= r;
} return h; } function z(e, l) { let h = l.y0 - (l.targetLinks.length - 1) * y / 2; for (let { source: n, width: r } of l.targetLinks) {
    if (n === e)
        break;
    h += r + y;
} for (let { target: n, width: r } of e.sourceLinks) {
    if (n === l)
        break;
    h -= r;
} return h; } return v; }
var ut = Math.PI, ft = 2 * ut, F = 1e-6, Wt = ft - F;
function ct() { this._x0 = this._y0 = this._x1 = this._y1 = null, this._ = ""; }
function Pt() { return new ct; }
ct.prototype = Pt.prototype = { constructor: ct, moveTo: function (t, o) { this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +o); }, closePath: function () { this._x1 !== null && (this._x1 = this._x0, this._y1 = this._y0, this._ += "Z"); }, lineTo: function (t, o) { this._ += "L" + (this._x1 = +t) + "," + (this._y1 = +o); }, quadraticCurveTo: function (t, o, s, u) { this._ += "Q" + +t + "," + +o + "," + (this._x1 = +s) + "," + (this._y1 = +u); }, bezierCurveTo: function (t, o, s, u, f, _) { this._ += "C" + +t + "," + +o + "," + +s + "," + +u + "," + (this._x1 = +f) + "," + (this._y1 = +_); }, arcTo: function (t, o, s, u, f) { t = +t, o = +o, s = +s, u = +u, f = +f; var _ = this._x1, y = this._y1, g = s - t, i = u - o, a = _ - t, c = y - o, x = a * a + c * c; if (f < 0)
        throw new Error("negative radius: " + f); if (this._x1 === null)
        this._ += "M" + (this._x1 = t) + "," + (this._y1 = o);
    else if (x > F)
        if (!(Math.abs(c * g - i * a) > F) || !f)
            this._ += "L" + (this._x1 = t) + "," + (this._y1 = o);
        else {
            var k = s - _, p = u - y, v = g * g + i * i, A = k * k + p * p, E = Math.sqrt(v), T = Math.sqrt(x), M = f * Math.tan((ut - Math.acos((v + x - A) / (2 * E * T))) / 2), O = M / T, P = M / E;
            Math.abs(O - 1) > F && (this._ += "L" + (t + O * a) + "," + (o + O * c)), this._ += "A" + f + "," + f + ",0,0," + +(c * k > a * p) + "," + (this._x1 = t + P * g) + "," + (this._y1 = o + P * i);
        } }, arc: function (t, o, s, u, f, _) { t = +t, o = +o, s = +s, _ = !!_; var y = s * Math.cos(u), g = s * Math.sin(u), i = t + y, a = o + g, c = 1 ^ _, x = _ ? u - f : f - u; if (s < 0)
        throw new Error("negative radius: " + s); this._x1 === null ? this._ += "M" + i + "," + a : (Math.abs(this._x1 - i) > F || Math.abs(this._y1 - a) > F) && (this._ += "L" + i + "," + a), s && (x < 0 && (x = x % ft + ft), x > Wt ? this._ += "A" + s + "," + s + ",0,1," + c + "," + (t - y) + "," + (o - g) + "A" + s + "," + s + ",0,1," + c + "," + (this._x1 = i) + "," + (this._y1 = a) : x > F && (this._ += "A" + s + "," + s + ",0," + +(x >= ut) + "," + c + "," + (this._x1 = t + s * Math.cos(f)) + "," + (this._y1 = o + s * Math.sin(f)))); }, rect: function (t, o, s, u) { this._ += "M" + (this._x0 = this._x1 = +t) + "," + (this._y0 = this._y1 = +o) + "h" + +s + "v" + +u + "h" + -s + "Z"; }, toString: function () { return this._; } };
var ht = Pt;
function dt(t) { return function () { return t; }; }
function Rt(t) { return t[0]; }
function zt(t) { return t[1]; }
var Dt = Array.prototype.slice;
function Ut(t) { return t.source; }
function Ht(t) { return t.target; }
function Yt(t) { var o = Ut, s = Ht, u = Rt, f = zt, _ = null; function y() { var g, i = Dt.call(arguments), a = o.apply(this, i), c = s.apply(this, i); if (_ || (_ = g = ht()), t(_, +u.apply(this, (i[0] = a, i)), +f.apply(this, i), +u.apply(this, (i[0] = c, i)), +f.apply(this, i)), g)
    return _ = null, g + "" || null; } return y.source = function (g) { return arguments.length ? (o = g, y) : o; }, y.target = function (g) { return arguments.length ? (s = g, y) : s; }, y.x = function (g) { return arguments.length ? (u = typeof g == "function" ? g : dt(+g), y) : u; }, y.y = function (g) { return arguments.length ? (f = typeof g == "function" ? g : dt(+g), y) : f; }, y.context = function (g) { return arguments.length ? (_ = g ?? null, y) : _; }, y; }
function qt(t, o, s, u, f) { t.moveTo(o, s), t.bezierCurveTo(o = (o + u) / 2, s, o, f, u, f); }
function pt() { return Yt(qt); }
function Gt(t) { return [t.source.x1, t.y0]; }
function Xt(t) { return [t.target.x0, t.y1]; }
function yt() { return pt().source(Gt).target(Xt); }
var mt = (function () {
    var t = d(function (g, i, a, c) { for (a = a || {}, c = g.length; c--; a[g[c]] = i)
        ; return a; }, "o"), o = [1, 9], s = [1, 10], u = [1, 5, 10, 12], f = { trace: d(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, SANKEY: 4, NEWLINE: 5, csv: 6, opt_eof: 7, record: 8, csv_tail: 9, EOF: 10, "field[source]": 11, COMMA: 12, "field[target]": 13, "field[value]": 14, field: 15, escaped: 16, non_escaped: 17, DQUOTE: 18, ESCAPED_TEXT: 19, NON_ESCAPED_TEXT: 20, $accept: 0, $end: 1 }, terminals_: { 2: "error", 4: "SANKEY", 5: "NEWLINE", 10: "EOF", 11: "field[source]", 12: "COMMA", 13: "field[target]", 14: "field[value]", 18: "DQUOTE", 19: "ESCAPED_TEXT", 20: "NON_ESCAPED_TEXT" }, productions_: [0, [3, 4], [6, 2], [9, 2], [9, 0], [7, 1], [7, 0], [8, 5], [15, 1], [15, 1], [16, 3], [17, 1]], performAction: d(function (i, a, c, x, k, p, v) { var A = p.length - 1; switch (k) {
            case 7:
                let E = x.findOrCreateNode(p[A - 4].trim().replaceAll('""', '"')), T = x.findOrCreateNode(p[A - 2].trim().replaceAll('""', '"')), M = parseFloat(p[A].trim());
                x.addLink(E, T, M);
                break;
            case 8:
            case 9:
            case 11:
                this.$ = p[A];
                break;
            case 10:
                this.$ = p[A - 1];
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: [1, 2] }, { 1: [3] }, { 5: [1, 3] }, { 6: 4, 8: 5, 15: 6, 16: 7, 17: 8, 18: o, 20: s }, { 1: [2, 6], 7: 11, 10: [1, 12] }, t(s, [2, 4], { 9: 13, 5: [1, 14] }), { 12: [1, 15] }, t(u, [2, 8]), t(u, [2, 9]), { 19: [1, 16] }, t(u, [2, 11]), { 1: [2, 1] }, { 1: [2, 5] }, t(s, [2, 2]), { 6: 17, 8: 5, 15: 6, 16: 7, 17: 8, 18: o, 20: s }, { 15: 18, 16: 7, 17: 8, 18: o, 20: s }, { 18: [1, 19] }, t(s, [2, 3]), { 12: [1, 20] }, t(u, [2, 10]), { 15: 21, 16: 7, 17: 8, 18: o, 20: s }, t([1, 5, 10], [2, 7])], defaultActions: { 11: [2, 1], 12: [2, 5] }, parseError: d(function (i, a) { if (a.recoverable)
            this.trace(i);
        else {
            var c = new Error(i);
            throw c.hash = a, c;
        } }, "parseError"), parse: d(function (i) {
            var a = this, c = [0], x = [], k = [null], p = [], v = this.table, A = "", E = 0, T = 0, M = 0, O = 2, P = 1, R = p.slice.call(arguments, 1), S = Object.create(this.lexer), N = { yy: {} };
            for (var j in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, j) && (N.yy[j] = this.yy[j]);
            S.setInput(i, N.yy), N.yy.lexer = S, N.yy.parser = this, typeof S.yylloc > "u" && (S.yylloc = {});
            var B = S.yylloc;
            p.push(B);
            var I = S.options && S.options.ranges;
            typeof N.yy.parseError == "function" ? this.parseError = N.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function W(w) { c.length = c.length - 2 * w, k.length = k.length - w, p.length = p.length - w; }
            d(W, "popStack");
            function V() { var w; return w = x.pop() || S.lex() || P, typeof w != "number" && (w instanceof Array && (x = w, w = x.pop()), w = a.symbols_[w] || w), w; }
            d(V, "lex");
            for (var L, z, e, l, h, n, r = {}, m, b, $, C;;) {
                if (e = c[c.length - 1], this.defaultActions[e] ? l = this.defaultActions[e] : ((L === null || typeof L > "u") && (L = V()), l = v[e] && v[e][L]), typeof l > "u" || !l.length || !l[0]) {
                    var D = "";
                    C = [];
                    for (m in v[e])
                        this.terminals_[m] && m > O && C.push("'" + this.terminals_[m] + "'");
                    S.showPosition ? D = "Parse error on line " + (E + 1) + `:
` + S.showPosition() + `
Expecting ` + C.join(", ") + ", got '" + (this.terminals_[L] || L) + "'" : D = "Parse error on line " + (E + 1) + ": Unexpected " + (L == P ? "end of input" : "'" + (this.terminals_[L] || L) + "'"), this.parseError(D, { text: S.match, token: this.terminals_[L] || L, line: S.yylineno, loc: B, expected: C });
                }
                if (l[0] instanceof Array && l.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + e + ", token: " + L);
                switch (l[0]) {
                    case 1:
                        c.push(L), k.push(S.yytext), p.push(S.yylloc), c.push(l[1]), L = null, z ? (L = z, z = null) : (T = S.yyleng, A = S.yytext, E = S.yylineno, B = S.yylloc, M > 0 && M--);
                        break;
                    case 2:
                        if (b = this.productions_[l[1]][1], r.$ = k[k.length - b], r._$ = { first_line: p[p.length - (b || 1)].first_line, last_line: p[p.length - 1].last_line, first_column: p[p.length - (b || 1)].first_column, last_column: p[p.length - 1].last_column }, I && (r._$.range = [p[p.length - (b || 1)].range[0], p[p.length - 1].range[1]]), n = this.performAction.apply(r, [A, T, E, N.yy, l[1], k, p].concat(R)), typeof n < "u")
                            return n;
                        b && (c = c.slice(0, -1 * b * 2), k = k.slice(0, -1 * b), p = p.slice(0, -1 * b)), c.push(this.productions_[l[1]][0]), k.push(r.$), p.push(r._$), $ = v[c[c.length - 2]][c[c.length - 1]], c.push($);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, _ = (function () {
        var g = { EOF: 1, parseError: d(function (a, c) { if (this.yy.parser)
                this.yy.parser.parseError(a, c);
            else
                throw new Error(a); }, "parseError"), setInput: d(function (i, a) { return this.yy = a || this.yy || {}, this._input = i, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: d(function () { var i = this._input[0]; this.yytext += i, this.yyleng++, this.offset++, this.match += i, this.matched += i; var a = i.match(/(?:\r\n?|\n).*/g); return a ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), i; }, "input"), unput: d(function (i) { var a = i.length, c = i.split(/(?:\r\n?|\n)/g); this._input = i + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - a), this.offset -= a; var x = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), c.length - 1 && (this.yylineno -= c.length - 1); var k = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: c ? (c.length === x.length ? this.yylloc.first_column : 0) + x[x.length - c.length].length - c[0].length : this.yylloc.first_column - a }, this.options.ranges && (this.yylloc.range = [k[0], k[0] + this.yyleng - a]), this.yyleng = this.yytext.length, this; }, "unput"), more: d(function () { return this._more = !0, this; }, "more"), reject: d(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: d(function (i) { this.unput(this.match.slice(i)); }, "less"), pastInput: d(function () { var i = this.matched.substr(0, this.matched.length - this.match.length); return (i.length > 20 ? "..." : "") + i.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: d(function () { var i = this.match; return i.length < 20 && (i += this._input.substr(0, 20 - i.length)), (i.substr(0, 20) + (i.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: d(function () {
                var i = this.pastInput(), a = new Array(i.length + 1).join("-");
                return i + this.upcomingInput() + `
` + a + "^";
            }, "showPosition"), test_match: d(function (i, a) { var c, x, k; if (this.options.backtrack_lexer && (k = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (k.yylloc.range = this.yylloc.range.slice(0))), x = i[0].match(/(?:\r\n?|\n).*/g), x && (this.yylineno += x.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: x ? x[x.length - 1].length - x[x.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + i[0].length }, this.yytext += i[0], this.match += i[0], this.matches = i, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(i[0].length), this.matched += i[0], c = this.performAction.call(this, this.yy, this, a, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), c)
                return c; if (this._backtrack) {
                for (var p in k)
                    this[p] = k[p];
                return !1;
            } return !1; }, "test_match"), next: d(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var i, a, c, x;
                this._more || (this.yytext = "", this.match = "");
                for (var k = this._currentRules(), p = 0; p < k.length; p++)
                    if (c = this._input.match(this.rules[k[p]]), c && (!a || c[0].length > a[0].length)) {
                        if (a = c, x = p, this.options.backtrack_lexer) {
                            if (i = this.test_match(c, k[p]), i !== !1)
                                return i;
                            if (this._backtrack) {
                                a = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return a ? (i = this.test_match(a, k[x]), i !== !1 ? i : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: d(function () { var a = this.next(); return a || this.lex(); }, "lex"), begin: d(function (a) { this.conditionStack.push(a); }, "begin"), popState: d(function () { var a = this.conditionStack.length - 1; return a > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: d(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: d(function (a) { return a = this.conditionStack.length - 1 - Math.abs(a || 0), a >= 0 ? this.conditionStack[a] : "INITIAL"; }, "topState"), pushState: d(function (a) { this.begin(a); }, "pushState"), stateStackSize: d(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: d(function (a, c, x, k) { var p = k; switch (x) {
                case 0:
                    return this.pushState("csv"), 4;
                    break;
                case 1:
                    return this.pushState("csv"), 4;
                    break;
                case 2: return 10;
                case 3: return 5;
                case 4: return 12;
                case 5:
                    return this.pushState("escaped_text"), 18;
                    break;
                case 6: return 20;
                case 7:
                    return this.popState("escaped_text"), 18;
                    break;
                case 8: return 19;
            } }, "anonymous"), rules: [/^(?:sankey-beta\b)/i, /^(?:sankey\b)/i, /^(?:$)/i, /^(?:((\u000D\u000A)|(\u000A)))/i, /^(?:(\u002C))/i, /^(?:(\u0022))/i, /^(?:([\u0020-\u0021\u0023-\u002B\u002D-\u007E])*)/i, /^(?:(\u0022)(?!(\u0022)))/i, /^(?:(([\u0020-\u0021\u0023-\u002B\u002D-\u007E])|(\u002C)|(\u000D)|(\u000A)|(\u0022)(\u0022))*)/i], conditions: { csv: { rules: [2, 3, 4, 5, 6, 7, 8], inclusive: !1 }, escaped_text: { rules: [7, 8], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8], inclusive: !0 } } };
        return g;
    })();
    f.lexer = _;
    function y() { this.yy = {}; }
    return d(y, "Parser"), y.prototype = f, f.Parser = y, new y;
})();
mt.parser = mt;
var tt = mt, nt = [], rt = [], et = new Map, Jt = d(() => { nt = [], rt = [], et = new Map, _t(); }, "clear"), Qt = class {
    constructor(t, o, s = 0) { this.source = t, this.target = o, this.value = s; }
    static { d(this, "SankeyLink"); }
}, Kt = d((t, o, s) => { nt.push(new Qt(t, o, s)); }, "addLink"), Zt = class {
    constructor(t) { this.ID = t; }
    static { d(this, "SankeyNode"); }
}, te = d(t => { t = xt.sanitizeText(t, Q()); let o = et.get(t); return o === void 0 && (o = new Zt(t), et.set(t, o), rt.push(o)), o; }, "findOrCreateNode"), ee = d(() => rt, "getNodes"), ne = d(() => nt, "getLinks"), re = d(() => ({ nodes: rt.map(t => ({ id: t.ID })), links: nt.map(t => ({ source: t.source.ID, target: t.target.ID, value: t.value })) }), "getGraph"), oe = { nodesMap: et, getConfig: d(() => Q().sankey, "getConfig"), getNodes: ee, getLinks: ne, getGraph: re, addLink: Kt, findOrCreateNode: te, getAccTitle: bt, setAccTitle: vt, getAccDescription: Lt, setAccDescription: St, getDiagramTitle: Et, setDiagramTitle: wt, clear: Jt }, jt = class gt {
    static { d(this, "Uid"); }
    static { this.count = 0; }
    static next(s) { return new gt(s + ++gt.count); }
    constructor(s) { this.id = s, this.href = `#${s}`; }
    toString() { return "url(" + this.href + ")"; }
}, se = { left: st, right: it, center: at, justify: J }, ie = d(t => { let o = 0, s = 0; for (let u of t) {
    let f = u.value ?? 0;
    f > o && (o = f, s = u.layer ?? 0);
} return s; }, "findCentralNodeLayer"), ae = d(function (t, o, s, u) {
    let { securityLevel: f, sankey: _ } = Q(), y = At.sankey, g;
    f === "sandbox" && (g = G("#i" + o));
    let i = f === "sandbox" ? G(g.nodes()[0].contentDocument.body) : G("body"), a = f === "sandbox" ? i.select(`[id="${o}"]`) : G(`[id="${o}"]`), c = _?.width ?? y.width, x = _?.height ?? y.width, k = _?.useMaxWidth ?? y.useMaxWidth, p = _?.nodeAlignment ?? y.nodeAlignment, v = _?.prefix ?? y.prefix, A = _?.suffix ?? y.suffix, E = _?.showValues ?? y.showValues, T = _?.nodeWidth ?? y.nodeWidth ?? 10, M = _?.nodePadding ?? y.nodePadding ?? 12, O = _?.labelStyle ?? y.labelStyle ?? "legacy", P = _?.nodeColors ?? {}, R = u.db.getGraph(), S = se[p];
    Z().nodeId(n => n.id).nodeWidth(T).nodePadding(M + (E ? 15 : 0)).nodeAlign(S).extent([[0, 0], [c, x]])(R);
    let j = ie(R.nodes), B = Ct(Tt), I = d(n => P[n] ?? B(n), "getNodeColor");
    a.append("g").attr("class", "nodes").selectAll(".node").data(R.nodes).join("g").attr("class", "node").attr("id", n => (n.uid = jt.next("node-")).id).attr("transform", function (n) { return "translate(" + n.x0 + "," + n.y0 + ")"; }).attr("x", n => n.x0).attr("y", n => n.y0).append("rect").attr("height", n => n.y1 - n.y0).attr("width", n => n.x1 - n.x0).attr("fill", n => I(n.id));
    let W = d(({ id: n, value: r }) => E ? `${n}
${v}${Math.round(r * 100) / 100}${A}` : n, "getText"), V = d(n => O === "outlined" ? (n.layer ?? 0) < j ? { x: n.x0 - 6, anchor: "end" } : { x: n.x1 + 6, anchor: "start" } : n.x0 < c / 2 ? { x: n.x1 + 6, anchor: "start" } : { x: n.x0 - 6, anchor: "end" }, "getLabelPosition"), L = a.append("g").attr("class", "node-labels").attr("font-size", 14), z = d(n => L.selectAll(n ? `.${n}` : "text").data(R.nodes).join("text").attr("class", n ?? null).attr("x", r => V(r).x).attr("y", r => (r.y1 + r.y0) / 2).attr("dy", `${E ? "0" : "0.35"}em`).attr("text-anchor", r => V(r).anchor).text(W), "appendLabel");
    O === "outlined" ? (z("sankey-label-bg"), z("sankey-label-fg")) : z();
    let e = a.append("g").attr("class", "links").attr("fill", "none").attr("stroke-opacity", .5).selectAll(".link").data(R.links).join("g").attr("class", "link").style("mix-blend-mode", "multiply"), l = _?.linkColor ?? "gradient";
    if (l === "gradient") {
        let n = e.append("linearGradient").attr("id", r => (r.uid = jt.next("linearGradient-")).id).attr("gradientUnits", "userSpaceOnUse").attr("x1", r => r.source.x1).attr("x2", r => r.target.x0);
        n.append("stop").attr("offset", "0%").attr("stop-color", r => I(r.source.id)), n.append("stop").attr("offset", "100%").attr("stop-color", r => I(r.target.id));
    }
    let h;
    switch (l) {
        case "gradient":
            h = d(n => n.uid, "coloring");
            break;
        case "source":
            h = d(n => I(n.source.id), "coloring");
            break;
        case "target":
            h = d(n => I(n.target.id), "coloring");
            break;
        default: h = l;
    }
    e.append("path").attr("d", yt()).attr("stroke", h).attr("stroke-width", n => Math.max(1, n.width)), kt(void 0, a, 0, k);
}, "draw"), le = { draw: ae }, ue = d(t => t.replaceAll(/^[^\S\n\r]+|[^\S\n\r]+$/g, "").replaceAll(/([\n\r])+/g, `
`).trim(), "prepareTextForParsing"), fe = d(t => `.label {
    font-family: ${t.fontFamily};
  }

  .node-labels {
    font-family: ${t.fontFamily};
  }

  /* Outlined label style - background stroke for better readability */
  .sankey-label-bg {
    stroke: ${t.mainBkg || t.background || "#fff"};
    stroke-width: 4px;
    stroke-linejoin: round;
    paint-order: stroke;
  }

  /* Foreground label text */
  .sankey-label-fg {
    fill: ${t.textColor};
  }

  /* Node styling */
  .node rect {
    shape-rendering: crispEdges;
  }

  /* Link styling */
  .link {
    fill: none;
    stroke-opacity: 0.5;
    mix-blend-mode: multiply;
  }
`, "getStyles"), ce = fe, he = tt.parse.bind(tt);
tt.parse = t => he(ue(t));
var Ze = { styles: ce, parser: tt, db: oe, renderer: le };
export { Ze as diagram };
