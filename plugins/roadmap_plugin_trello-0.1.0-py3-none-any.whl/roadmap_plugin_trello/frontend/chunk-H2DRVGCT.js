import { d as et } from "@nf-internal/chunk-OSQMNGTH";
var zt = et((Ft, Le) => {
    function ye(e) { return e instanceof Map ? e.clear = e.delete = e.set = function () { throw new Error("map is read-only"); } : e instanceof Set && (e.add = e.clear = e.delete = function () { throw new Error("set is read-only"); }), Object.freeze(e), Object.getOwnPropertyNames(e).forEach(t => { let i = e[t], u = typeof i; (u === "object" || u === "function") && !Object.isFrozen(i) && ye(i); }), e; }
    var X = class {
        constructor(t) { t.data === void 0 && (t.data = {}), this.data = t.data, this.isMatchIgnored = !1; }
        ignoreMatch() { this.isMatchIgnored = !0; }
    };
    function Re(e) { return e.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&#x27;"); }
    function B(e, ...t) { let i = Object.create(null); for (let u in e)
        i[u] = e[u]; return t.forEach(function (u) { for (let b in u)
        i[b] = u[b]; }), i; }
    var tt = "</span>", be = e => !!e.scope, nt = (e, { prefix: t }) => { if (e.startsWith("language:"))
        return e.replace("language:", "language-"); if (e.includes(".")) {
        let i = e.split(".");
        return [`${t}${i.shift()}`, ...i.map((u, b) => `${u}${"_".repeat(b + 1)}`)].join(" ");
    } return `${t}${e}`; }, ne = class {
        constructor(t, i) { this.buffer = "", this.classPrefix = i.classPrefix, t.walk(this); }
        addText(t) { this.buffer += Re(t); }
        openNode(t) { if (!be(t))
            return; let i = nt(t.scope, { prefix: this.classPrefix }); this.span(i); }
        closeNode(t) { be(t) && (this.buffer += tt); }
        value() { return this.buffer; }
        span(t) { this.buffer += `<span class="${t}">`; }
    }, _e = (e = {}) => { let t = { children: [] }; return Object.assign(t, e), t; }, ie = class e {
        constructor() { this.rootNode = _e(), this.stack = [this.rootNode]; }
        get top() { return this.stack[this.stack.length - 1]; }
        get root() { return this.rootNode; }
        add(t) { this.top.children.push(t); }
        openNode(t) { let i = _e({ scope: t }); this.add(i), this.stack.push(i); }
        closeNode() { if (this.stack.length > 1)
            return this.stack.pop(); }
        closeAllNodes() { for (; this.closeNode();)
            ; }
        toJSON() { return JSON.stringify(this.rootNode, null, 4); }
        walk(t) { return this.constructor._walk(t, this.rootNode); }
        static _walk(t, i) { return typeof i == "string" ? t.addText(i) : i.children && (t.openNode(i), i.children.forEach(u => this._walk(t, u)), t.closeNode(i)), t; }
        static _collapse(t) { typeof t != "string" && t.children && (t.children.every(i => typeof i == "string") ? t.children = [t.children.join("")] : t.children.forEach(i => { e._collapse(i); })); }
    }, se = class extends ie {
        constructor(t) { super(), this.options = t; }
        addText(t) { t !== "" && this.add(t); }
        startScope(t) { this.openNode(t); }
        endScope() { this.closeNode(); }
        __addSublanguage(t, i) { let u = t.root; i && (u.scope = `language:${i}`), this.add(u); }
        toHTML() { return new ne(this, this.options).value(); }
        finalize() { return this.closeAllNodes(), !0; }
    };
    function H(e) { return e ? typeof e == "string" ? e : e.source : null; }
    function Se(e) { return C("(?=", e, ")"); }
    function it(e) { return C("(?:", e, ")*"); }
    function st(e) { return C("(?:", e, ")?"); }
    function C(...e) { return e.map(i => H(i)).join(""); }
    function rt(e) { let t = e[e.length - 1]; return typeof t == "object" && t.constructor === Object ? (e.splice(e.length - 1, 1), t) : {}; }
    function ce(...e) { return "(" + (rt(e).capture ? "" : "?:") + e.map(u => H(u)).join("|") + ")"; }
    function Ne(e) { return new RegExp(e.toString() + "|").exec("").length - 1; }
    function ct(e, t) { let i = e && e.exec(t); return i && i.index === 0; }
    var ot = /\[(?:[^\\\]]|\\.)*\]|\(\??|\\([1-9][0-9]*)|\\./;
    function oe(e, { joinWith: t }) { let i = 0; return e.map(u => { i += 1; let b = i, _ = H(u), c = ""; for (; _.length > 0;) {
        let r = ot.exec(_);
        if (!r) {
            c += _;
            break;
        }
        c += _.substring(0, r.index), _ = _.substring(r.index + r[0].length), r[0][0] === "\\" && r[1] ? c += "\\" + String(Number(r[1]) + b) : (c += r[0], r[0] === "(" && i++);
    } return c; }).map(u => `(${u})`).join(t); }
    var at = /\b\B/, Ae = "[a-zA-Z]\\w*", ae = "[a-zA-Z_]\\w*", ke = "\\b\\d+(\\.\\d+)?", Ie = "(-?)(\\b0[xX][a-fA-F0-9]+|(\\b\\d+(\\.\\d*)?|\\.\\d+)([eE][-+]?\\d+)?)", Te = "\\b(0b[01]+)", lt = "!|!=|!==|%|%=|&|&&|&=|\\*|\\*=|\\+|\\+=|,|-|-=|/=|/|:|;|<<|<<=|<=|<|===|==|=|>>>=|>>=|>=|>>>|>>|>|\\?|\\[|\\{|\\(|\\^|\\^=|\\||\\|=|\\|\\||~", ut = (e = {}) => { let t = /^#![ ]*\//; return e.binary && (e.begin = C(t, /.*\b/, e.binary, /\b.*/)), B({ scope: "meta", begin: t, end: /$/, relevance: 0, "on:begin": (i, u) => { i.index !== 0 && u.ignoreMatch(); } }, e); }, U = { begin: "\\\\[\\s\\S]", relevance: 0 }, ft = { scope: "string", begin: "'", end: "'", illegal: "\\n", contains: [U] }, gt = { scope: "string", begin: '"', end: '"', illegal: "\\n", contains: [U] }, ht = { begin: /\b(a|an|the|are|I'm|isn't|don't|doesn't|won't|but|just|should|pretty|simply|enough|gonna|going|wtf|so|such|will|you|your|they|like|more)\b/ }, Z = function (e, t, i = {}) { let u = B({ scope: "comment", begin: e, end: t, contains: [] }, i); u.contains.push({ scope: "doctag", begin: "[ ]*(?=(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):)", end: /(TODO|FIXME|NOTE|BUG|OPTIMIZE|HACK|XXX):/, excludeBegin: !0, relevance: 0 }); let b = ce("I", "a", "is", "so", "us", "to", "at", "if", "in", "it", "on", /[A-Za-z]+['](d|ve|re|ll|t|s|n)/, /[A-Za-z]+[-][a-z]+/, /[A-Za-z][a-z]{2,}/); return u.contains.push({ begin: C(/[ ]+/, "(", b, /[.]?[:]?([.][ ]|[ ])/, "){3}") }), u; }, pt = Z("//", "$"), dt = Z("/\\*", "\\*/"), Et = Z("#", "$"), bt = { scope: "number", begin: ke, relevance: 0 }, _t = { scope: "number", begin: Ie, relevance: 0 }, Mt = { scope: "number", begin: Te, relevance: 0 }, wt = { scope: "regexp", begin: /\/(?=[^/\n]*\/)/, end: /\/[gimuy]*/, contains: [U, { begin: /\[/, end: /\]/, relevance: 0, contains: [U] }] }, xt = { scope: "title", begin: Ae, relevance: 0 }, Ot = { scope: "title", begin: ae, relevance: 0 }, yt = { begin: "\\.\\s*" + ae, relevance: 0 }, Rt = function (e) { return Object.assign(e, { "on:begin": (t, i) => { i.data._beginMatch = t[1]; }, "on:end": (t, i) => { i.data._beginMatch !== t[1] && i.ignoreMatch(); } }); }, F = Object.freeze({ __proto__: null, APOS_STRING_MODE: ft, BACKSLASH_ESCAPE: U, BINARY_NUMBER_MODE: Mt, BINARY_NUMBER_RE: Te, COMMENT: Z, C_BLOCK_COMMENT_MODE: dt, C_LINE_COMMENT_MODE: pt, C_NUMBER_MODE: _t, C_NUMBER_RE: Ie, END_SAME_AS_BEGIN: Rt, HASH_COMMENT_MODE: Et, IDENT_RE: Ae, MATCH_NOTHING_RE: at, METHOD_GUARD: yt, NUMBER_MODE: bt, NUMBER_RE: ke, PHRASAL_WORDS_MODE: ht, QUOTE_STRING_MODE: gt, REGEXP_MODE: wt, RE_STARTERS_RE: lt, SHEBANG: ut, TITLE_MODE: xt, UNDERSCORE_IDENT_RE: ae, UNDERSCORE_TITLE_MODE: Ot });
    function St(e, t) { e.input[e.index - 1] === "." && t.ignoreMatch(); }
    function Nt(e, t) { e.className !== void 0 && (e.scope = e.className, delete e.className); }
    function At(e, t) { t && e.beginKeywords && (e.begin = "\\b(" + e.beginKeywords.split(" ").join("|") + ")(?!\\.)(?=\\b|\\s)", e.__beforeBegin = St, e.keywords = e.keywords || e.beginKeywords, delete e.beginKeywords, e.relevance === void 0 && (e.relevance = 0)); }
    function kt(e, t) { Array.isArray(e.illegal) && (e.illegal = ce(...e.illegal)); }
    function It(e, t) { if (e.match) {
        if (e.begin || e.end)
            throw new Error("begin & end are not supported with match");
        e.begin = e.match, delete e.match;
    } }
    function Tt(e, t) { e.relevance === void 0 && (e.relevance = 1); }
    var Bt = (e, t) => { if (!e.beforeMatch)
        return; if (e.starts)
        throw new Error("beforeMatch cannot be used with starts"); let i = Object.assign({}, e); Object.keys(e).forEach(u => { delete e[u]; }), e.keywords = i.keywords, e.begin = C(i.beforeMatch, Se(i.begin)), e.starts = { relevance: 0, contains: [Object.assign(i, { endsParent: !0 })] }, e.relevance = 0, delete i.beforeMatch; }, Dt = ["of", "and", "for", "in", "not", "or", "if", "then", "parent", "list", "value"], vt = "keyword";
    function Be(e, t, i = vt) { let u = Object.create(null); return typeof e == "string" ? b(i, e.split(" ")) : Array.isArray(e) ? b(i, e) : Object.keys(e).forEach(function (_) { Object.assign(u, Be(e[_], t, _)); }), u; function b(_, c) { t && (c = c.map(r => r.toLowerCase())), c.forEach(function (r) { let l = r.split("|"); u[l[0]] = [_, Ct(l[0], l[1])]; }); } }
    function Ct(e, t) { return t ? Number(t) : Lt(e) ? 0 : 1; }
    function Lt(e) { return Dt.includes(e.toLowerCase()); }
    var Me = {}, v = e => { console.error(e); }, we = (e, ...t) => { console.log(`WARN: ${e}`, ...t); }, L = (e, t) => { Me[`${e}/${t}`] || (console.log(`Deprecated as of ${e}. ${t}`), Me[`${e}/${t}`] = !0); }, Y = new Error;
    function De(e, t, { key: i }) { let u = 0, b = e[i], _ = {}, c = {}; for (let r = 1; r <= t.length; r++)
        c[r + u] = b[r], _[r + u] = !0, u += Ne(t[r - 1]); e[i] = c, e[i]._emit = _, e[i]._multi = !0; }
    function Pt(e) { if (Array.isArray(e.begin)) {
        if (e.skip || e.excludeBegin || e.returnBegin)
            throw v("skip, excludeBegin, returnBegin not compatible with beginScope: {}"), Y;
        if (typeof e.beginScope != "object" || e.beginScope === null)
            throw v("beginScope must be object"), Y;
        De(e, e.begin, { key: "beginScope" }), e.begin = oe(e.begin, { joinWith: "" });
    } }
    function jt(e) { if (Array.isArray(e.end)) {
        if (e.skip || e.excludeEnd || e.returnEnd)
            throw v("skip, excludeEnd, returnEnd not compatible with endScope: {}"), Y;
        if (typeof e.endScope != "object" || e.endScope === null)
            throw v("endScope must be object"), Y;
        De(e, e.end, { key: "endScope" }), e.end = oe(e.end, { joinWith: "" });
    } }
    function Ht(e) { e.scope && typeof e.scope == "object" && e.scope !== null && (e.beginScope = e.scope, delete e.scope); }
    function Ut(e) { Ht(e), typeof e.beginScope == "string" && (e.beginScope = { _wrap: e.beginScope }), typeof e.endScope == "string" && (e.endScope = { _wrap: e.endScope }), Pt(e), jt(e); }
    function $t(e) { function t(c, r) { return new RegExp(H(c), "m" + (e.case_insensitive ? "i" : "") + (e.unicodeRegex ? "u" : "") + (r ? "g" : "")); } class i {
        constructor() { this.matchIndexes = {}, this.regexes = [], this.matchAt = 1, this.position = 0; }
        addRule(r, l) { l.position = this.position++, this.matchIndexes[this.matchAt] = l, this.regexes.push([l, r]), this.matchAt += Ne(r) + 1; }
        compile() { this.regexes.length === 0 && (this.exec = () => null); let r = this.regexes.map(l => l[1]); this.matcherRe = t(oe(r, { joinWith: "|" }), !0), this.lastIndex = 0; }
        exec(r) { this.matcherRe.lastIndex = this.lastIndex; let l = this.matcherRe.exec(r); if (!l)
            return null; let x = l.findIndex((j, J) => J > 0 && j !== void 0), M = this.matchIndexes[x]; return l.splice(0, x), Object.assign(l, M); }
    } class u {
        constructor() { this.rules = [], this.multiRegexes = [], this.count = 0, this.lastIndex = 0, this.regexIndex = 0; }
        getMatcher(r) { if (this.multiRegexes[r])
            return this.multiRegexes[r]; let l = new i; return this.rules.slice(r).forEach(([x, M]) => l.addRule(x, M)), l.compile(), this.multiRegexes[r] = l, l; }
        resumingScanAtSamePosition() { return this.regexIndex !== 0; }
        considerAll() { this.regexIndex = 0; }
        addRule(r, l) { this.rules.push([r, l]), l.type === "begin" && this.count++; }
        exec(r) { let l = this.getMatcher(this.regexIndex); l.lastIndex = this.lastIndex; let x = l.exec(r); if (this.resumingScanAtSamePosition() && !(x && x.index === this.lastIndex)) {
            let M = this.getMatcher(0);
            M.lastIndex = this.lastIndex + 1, x = M.exec(r);
        } return x && (this.regexIndex += x.position + 1, this.regexIndex === this.count && this.considerAll()), x; }
    } function b(c) { let r = new u; return c.contains.forEach(l => r.addRule(l.begin, { rule: l, type: "begin" })), c.terminatorEnd && r.addRule(c.terminatorEnd, { type: "end" }), c.illegal && r.addRule(c.illegal, { type: "illegal" }), r; } function _(c, r) { let l = c; if (c.isCompiled)
        return l; [Nt, It, Ut, Bt].forEach(M => M(c, r)), e.compilerExtensions.forEach(M => M(c, r)), c.__beforeBegin = null, [At, kt, Tt].forEach(M => M(c, r)), c.isCompiled = !0; let x = null; return typeof c.keywords == "object" && c.keywords.$pattern && (c.keywords = Object.assign({}, c.keywords), x = c.keywords.$pattern, delete c.keywords.$pattern), x = x || /\w+/, c.keywords && (c.keywords = Be(c.keywords, e.case_insensitive)), l.keywordPatternRe = t(x, !0), r && (c.begin || (c.begin = /\B|\b/), l.beginRe = t(l.begin), !c.end && !c.endsWithParent && (c.end = /\B|\b/), c.end && (l.endRe = t(l.end)), l.terminatorEnd = H(l.end) || "", c.endsWithParent && r.terminatorEnd && (l.terminatorEnd += (c.end ? "|" : "") + r.terminatorEnd)), c.illegal && (l.illegalRe = t(c.illegal)), c.contains || (c.contains = []), c.contains = [].concat(...c.contains.map(function (M) { return Gt(M === "self" ? c : M); })), c.contains.forEach(function (M) { _(M, l); }), c.starts && _(c.starts, r), l.matcher = b(l), l; } if (e.compilerExtensions || (e.compilerExtensions = []), e.contains && e.contains.includes("self"))
        throw new Error("ERR: contains `self` is not supported at the top-level of a language.  See documentation."); return e.classNameAliases = B(e.classNameAliases || {}), _(e); }
    function ve(e) { return e ? e.endsWithParent || ve(e.starts) : !1; }
    function Gt(e) { return e.variants && !e.cachedVariants && (e.cachedVariants = e.variants.map(function (t) { return B(e, { variants: null }, t); })), e.cachedVariants ? e.cachedVariants : ve(e) ? B(e, { starts: e.starts ? B(e.starts) : null }) : Object.isFrozen(e) ? B(e) : e; }
    var Wt = "11.11.1", re = class extends Error {
        constructor(t, i) { super(t), this.name = "HTMLInjectionError", this.html = i; }
    }, te = Re, xe = B, Oe = Symbol("nomatch"), Kt = 7, Ce = function (e) {
        let t = Object.create(null), i = Object.create(null), u = [], b = !0, _ = "Could not find the language '{}', did you forget to load/include a language module?", c = { disableAutodetect: !0, name: "Plain text", contains: [] }, r = { ignoreUnescapedHTML: !1, throwUnescapedHTML: !1, noHighlightRe: /^(no-?highlight)$/i, languageDetectRe: /\blang(?:uage)?-([\w-]+)\b/i, classPrefix: "hljs-", cssSelector: "pre code", languages: null, __emitter: se };
        function l(n) { return r.noHighlightRe.test(n); }
        function x(n) { let a = n.className + " "; a += n.parentNode ? n.parentNode.className : ""; let h = r.languageDetectRe.exec(a); if (h) {
            let d = I(h[1]);
            return d || (we(_.replace("{}", h[1])), we("Falling back to no-highlight mode for this block.", n)), d ? h[1] : "no-highlight";
        } return a.split(/\s+/).find(d => l(d) || I(d)); }
        function M(n, a, h) {
            let d = "", w = "";
            typeof a == "object" ? (d = n, h = a.ignoreIllegals, w = a.language) : (L("10.7.0", "highlight(lang, code, ...args) has been deprecated."), L("10.7.0", `Please use highlight(code, options) instead.
https://github.com/highlightjs/highlight.js/issues/2277`), w = n, d = a), h === void 0 && (h = !0);
            let S = { code: d, language: w };
            G("before:highlight", S);
            let T = S.result ? S.result : j(S.language, S.code, h);
            return T.code = S.code, G("after:highlight", T), T;
        }
        function j(n, a, h, d) {
            let w = Object.create(null);
            function S(s, o) { return s.keywords[o]; }
            function T() { if (!f.keywords) {
                O.addText(E);
                return;
            } let s = 0; f.keywordPatternRe.lastIndex = 0; let o = f.keywordPatternRe.exec(E), g = ""; for (; o;) {
                g += E.substring(s, o.index);
                let p = A.case_insensitive ? o[0].toLowerCase() : o[0], y = S(f, p);
                if (y) {
                    let [k, Qe] = y;
                    if (O.addText(g), g = "", w[p] = (w[p] || 0) + 1, w[p] <= Kt && (z += Qe), k.startsWith("_"))
                        g += o[0];
                    else {
                        let me = A.classNameAliases[k] || k;
                        N(o[0], me);
                    }
                }
                else
                    g += o[0];
                s = f.keywordPatternRe.lastIndex, o = f.keywordPatternRe.exec(E);
            } g += E.substring(s), O.addText(g); }
            function W() { if (E === "")
                return; let s = null; if (typeof f.subLanguage == "string") {
                if (!t[f.subLanguage]) {
                    O.addText(E);
                    return;
                }
                s = j(f.subLanguage, E, !0, Ee[f.subLanguage]), Ee[f.subLanguage] = s._top;
            }
            else
                s = V(E, f.subLanguage.length ? f.subLanguage : null); f.relevance > 0 && (z += s.relevance), O.__addSublanguage(s._emitter, s.language); }
            function R() { f.subLanguage != null ? W() : T(), E = ""; }
            function N(s, o) { s !== "" && (O.startScope(o), O.addText(s), O.endScope()); }
            function ge(s, o) { let g = 1, p = o.length - 1; for (; g <= p;) {
                if (!s._emit[g]) {
                    g++;
                    continue;
                }
                let y = A.classNameAliases[s[g]] || s[g], k = o[g];
                y ? N(k, y) : (E = k, T(), E = ""), g++;
            } }
            function he(s, o) { return s.scope && typeof s.scope == "string" && O.openNode(A.classNameAliases[s.scope] || s.scope), s.beginScope && (s.beginScope._wrap ? (N(E, A.classNameAliases[s.beginScope._wrap] || s.beginScope._wrap), E = "") : s.beginScope._multi && (ge(s.beginScope, o), E = "")), f = Object.create(s, { parent: { value: f } }), f; }
            function pe(s, o, g) { let p = ct(s.endRe, g); if (p) {
                if (s["on:end"]) {
                    let y = new X(s);
                    s["on:end"](o, y), y.isMatchIgnored && (p = !1);
                }
                if (p) {
                    for (; s.endsParent && s.parent;)
                        s = s.parent;
                    return s;
                }
            } if (s.endsWithParent)
                return pe(s.parent, o, g); }
            function Ye(s) { return f.matcher.regexIndex === 0 ? (E += s[0], 1) : (ee = !0, 0); }
            function Ze(s) { let o = s[0], g = s.rule, p = new X(g), y = [g.__beforeBegin, g["on:begin"]]; for (let k of y)
                if (k && (k(s, p), p.isMatchIgnored))
                    return Ye(o); return g.skip ? E += o : (g.excludeBegin && (E += o), R(), !g.returnBegin && !g.excludeBegin && (E = o)), he(g, s), g.returnBegin ? 0 : o.length; }
            function Je(s) { let o = s[0], g = a.substring(s.index), p = pe(f, s, g); if (!p)
                return Oe; let y = f; f.endScope && f.endScope._wrap ? (R(), N(o, f.endScope._wrap)) : f.endScope && f.endScope._multi ? (R(), ge(f.endScope, s)) : y.skip ? E += o : (y.returnEnd || y.excludeEnd || (E += o), R(), y.excludeEnd && (E = o)); do
                f.scope && O.closeNode(), !f.skip && !f.subLanguage && (z += f.relevance), f = f.parent;
            while (f !== p.parent); return p.starts && he(p.starts, s), y.returnEnd ? 0 : o.length; }
            function Ve() { let s = []; for (let o = f; o !== A; o = o.parent)
                o.scope && s.unshift(o.scope); s.forEach(o => O.openNode(o)); }
            let K = {};
            function de(s, o) {
                let g = o && o[0];
                if (E += s, g == null)
                    return R(), 0;
                if (K.type === "begin" && o.type === "end" && K.index === o.index && g === "") {
                    if (E += a.slice(o.index, o.index + 1), !b) {
                        let p = new Error(`0 width match regex (${n})`);
                        throw p.languageName = n, p.badRule = K.rule, p;
                    }
                    return 1;
                }
                if (K = o, o.type === "begin")
                    return Ze(o);
                if (o.type === "illegal" && !h) {
                    let p = new Error('Illegal lexeme "' + g + '" for mode "' + (f.scope || "<unnamed>") + '"');
                    throw p.mode = f, p;
                }
                else if (o.type === "end") {
                    let p = Je(o);
                    if (p !== Oe)
                        return p;
                }
                if (o.type === "illegal" && g === "")
                    return E += `
`, 1;
                if (m > 1e5 && m > o.index * 3)
                    throw new Error("potential infinite loop, way more iterations than matches");
                return E += g, g.length;
            }
            let A = I(n);
            if (!A)
                throw v(_.replace("{}", n)), new Error('Unknown language: "' + n + '"');
            let qe = $t(A), Q = "", f = d || qe, Ee = {}, O = new r.__emitter(r);
            Ve();
            let E = "", z = 0, D = 0, m = 0, ee = !1;
            try {
                if (A.__emitTokens)
                    A.__emitTokens(a, O);
                else {
                    for (f.matcher.considerAll();;) {
                        m++, ee ? ee = !1 : f.matcher.considerAll(), f.matcher.lastIndex = D;
                        let s = f.matcher.exec(a);
                        if (!s)
                            break;
                        let o = a.substring(D, s.index), g = de(o, s);
                        D = s.index + g;
                    }
                    de(a.substring(D));
                }
                return O.finalize(), Q = O.toHTML(), { language: n, value: Q, relevance: z, illegal: !1, _emitter: O, _top: f };
            }
            catch (s) {
                if (s.message && s.message.includes("Illegal"))
                    return { language: n, value: te(a), illegal: !0, relevance: 0, _illegalBy: { message: s.message, index: D, context: a.slice(D - 100, D + 100), mode: s.mode, resultSoFar: Q }, _emitter: O };
                if (b)
                    return { language: n, value: te(a), illegal: !1, relevance: 0, errorRaised: s, _emitter: O, _top: f };
                throw s;
            }
        }
        function J(n) { let a = { value: te(n), illegal: !1, relevance: 0, _top: c, _emitter: new r.__emitter(r) }; return a._emitter.addText(n), a; }
        function V(n, a) { a = a || r.languages || Object.keys(t); let h = J(n), d = a.filter(I).filter(fe).map(R => j(R, n, !1)); d.unshift(h); let w = d.sort((R, N) => { if (R.relevance !== N.relevance)
            return N.relevance - R.relevance; if (R.language && N.language) {
            if (I(R.language).supersetOf === N.language)
                return 1;
            if (I(N.language).supersetOf === R.language)
                return -1;
        } return 0; }), [S, T] = w, W = S; return W.secondBest = T, W; }
        function Pe(n, a, h) { let d = a && i[a] || h; n.classList.add("hljs"), n.classList.add(`language-${d}`); }
        function q(n) { let a = null, h = x(n); if (l(h))
            return; if (G("before:highlightElement", { el: n, language: h }), n.dataset.highlighted) {
            console.log("Element previously highlighted. To highlight again, first unset `dataset.highlighted`.", n);
            return;
        } if (n.children.length > 0 && (r.ignoreUnescapedHTML || (console.warn("One of your code blocks includes unescaped HTML. This is a potentially serious security risk."), console.warn("https://github.com/highlightjs/highlight.js/wiki/security"), console.warn("The element with unescaped HTML:"), console.warn(n)), r.throwUnescapedHTML))
            throw new re("One of your code blocks includes unescaped HTML.", n.innerHTML); a = n; let d = a.textContent, w = h ? M(d, { language: h, ignoreIllegals: !0 }) : V(d); n.innerHTML = w.value, n.dataset.highlighted = "yes", Pe(n, h, w.language), n.result = { language: w.language, re: w.relevance, relevance: w.relevance }, w.secondBest && (n.secondBest = { language: w.secondBest.language, relevance: w.secondBest.relevance }), G("after:highlightElement", { el: n, result: w, text: d }); }
        function je(n) { r = xe(r, n); }
        let He = () => { $(), L("10.6.0", "initHighlighting() deprecated.  Use highlightAll() now."); };
        function Ue() { $(), L("10.6.0", "initHighlightingOnLoad() deprecated.  Use highlightAll() now."); }
        let le = !1;
        function $() { function n() { $(); } if (document.readyState === "loading") {
            le || window.addEventListener("DOMContentLoaded", n, !1), le = !0;
            return;
        } document.querySelectorAll(r.cssSelector).forEach(q); }
        function $e(n, a) { let h = null; try {
            h = a(e);
        }
        catch (d) {
            if (v("Language definition for '{}' could not be registered.".replace("{}", n)), b)
                v(d);
            else
                throw d;
            h = c;
        } h.name || (h.name = n), t[n] = h, h.rawDefinition = a.bind(null, e), h.aliases && ue(h.aliases, { languageName: n }); }
        function Ge(n) { delete t[n]; for (let a of Object.keys(i))
            i[a] === n && delete i[a]; }
        function We() { return Object.keys(t); }
        function I(n) { return n = (n || "").toLowerCase(), t[n] || t[i[n]]; }
        function ue(n, { languageName: a }) { typeof n == "string" && (n = [n]), n.forEach(h => { i[h.toLowerCase()] = a; }); }
        function fe(n) { let a = I(n); return a && !a.disableAutodetect; }
        function Ke(n) { n["before:highlightBlock"] && !n["before:highlightElement"] && (n["before:highlightElement"] = a => { n["before:highlightBlock"](Object.assign({ block: a.el }, a)); }), n["after:highlightBlock"] && !n["after:highlightElement"] && (n["after:highlightElement"] = a => { n["after:highlightBlock"](Object.assign({ block: a.el }, a)); }); }
        function ze(n) { Ke(n), u.push(n); }
        function Fe(n) { let a = u.indexOf(n); a !== -1 && u.splice(a, 1); }
        function G(n, a) { let h = n; u.forEach(function (d) { d[h] && d[h](a); }); }
        function Xe(n) { return L("10.7.0", "highlightBlock will be removed entirely in v12.0"), L("10.7.0", "Please use highlightElement now."), q(n); }
        Object.assign(e, { highlight: M, highlightAuto: V, highlightAll: $, highlightElement: q, highlightBlock: Xe, configure: je, initHighlighting: He, initHighlightingOnLoad: Ue, registerLanguage: $e, unregisterLanguage: Ge, listLanguages: We, getLanguage: I, registerAliases: ue, autoDetection: fe, inherit: xe, addPlugin: ze, removePlugin: Fe }), e.debugMode = function () { b = !1; }, e.safeMode = function () { b = !0; }, e.versionString = Wt, e.regex = { concat: C, lookahead: Se, either: ce, optional: st, anyNumberOfTimes: it };
        for (let n in F)
            typeof F[n] == "object" && ye(F[n]);
        return Object.assign(e, F), e;
    }, P = Ce({});
    P.newInstance = () => Ce({});
    Le.exports = P;
    P.HighlightJS = P;
    P.default = P;
});
export { zt as a };
