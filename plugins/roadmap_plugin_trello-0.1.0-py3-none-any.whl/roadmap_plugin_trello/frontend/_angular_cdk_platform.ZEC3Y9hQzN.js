import { a as c } from "@nf-internal/chunk-RECHUXGF";
import { a as f, b as g, c as y } from "@nf-internal/chunk-FVDLKYOC";
import { a as d, b as l } from "@nf-internal/chunk-PACPXHXL";
import { a as s, b as p, c as u, d as a } from "@nf-internal/chunk-ZGWTKG5Z";
import { a as m } from "@nf-internal/chunk-7RHXFCZM";
import "@nf-internal/chunk-OSQMNGTH";
import * as o from "@angular/core";
import "@angular/core";
import "@angular/common";
var w = (() => { class e {
    static \u0275fac = function (i) { return new (i || e); };
    static \u0275mod = o.\u0275\u0275defineNgModule({ type: e });
    static \u0275inj = o.\u0275\u0275defineInjector({});
} return e; })(), t, n = ["color", "button", "checkbox", "date", "datetime-local", "email", "file", "hidden", "image", "month", "number", "password", "radio", "range", "reset", "search", "submit", "tel", "text", "time", "url", "week"];
function T() { if (t)
    return t; if (typeof document != "object" || !document)
    return t = new Set(n), t; let e = document.createElement("input"); return t = new Set(n.filter(r => (e.setAttribute("type", r), e.type === r))), t; }
export { m as Platform, w as PlatformModule, f as RtlScrollAxisType, a as _getEventTarget, u as _getFocusedElementPierceShadowDom, p as _getShadowRoot, c as _isTestEnvironment, s as _supportsShadowDom, y as getRtlScrollAxisType, T as getSupportedInputTypes, l as normalizePassiveListenerOptions, d as supportsPassiveEventListeners, g as supportsScrollBehavior };
