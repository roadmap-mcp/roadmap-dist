import { a as e, b as i, c as o, d as t, e as n, g as u, k as d, x as l, y as s } from "@nf-internal/chunk-EPGORQP5";
var c = class extends s {
    static { e(this, "GitGraphTokenBuilder"); }
    constructor() { super(["gitGraph"]); }
}, p = { parser: { TokenBuilder: e(() => new c, "TokenBuilder"), ValueConverter: e(() => new l, "ValueConverter") } };
function h(G = n) { let r = t(o(G), u), a = t(i({ shared: r }), d, p); return r.ServiceRegistry.register(a), { shared: r, GitGraph: a }; }
e(h, "createGitGraphServices");
export { p as a, h as b };
