import { a as Vt } from "@nf-internal/chunk-YQ6X4GJP";
import { a as qt } from "@nf-internal/chunk-PRKFGJVH";
import { o as Bt } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { O as Rt, T as Ct, U as Nt, V as Ot, W as Lt, X as Ft, Y as jt, Z as Pt, c as Tt, d as zt, e as At, f as lt, k as Dt, u as ct } from "@nf-internal/chunk-LEJRRF65";
import { h as it } from "@nf-internal/chunk-RZWXGGKD";
import { a as w } from "@nf-internal/chunk-YUSHYV7C";
import { a as Et } from "@nf-internal/chunk-OSQMNGTH";
function rt(t, n) { let s = he(t), e = s.filter(l => fe(l, t)), i = 0, r = 0, o = []; if (e.length > 1) {
    let l = Kt(e);
    for (let u = 0; u < e.length; ++u) {
        let a = e[u];
        a.angle = Math.atan2(a.x - l.x, a.y - l.y);
    }
    e.sort((u, a) => a.angle - u.angle);
    let f = e[e.length - 1];
    for (let u = 0; u < e.length; ++u) {
        let a = e[u];
        r += (f.x + a.x) * (a.y - f.y);
        let y = { x: (a.x + f.x) / 2, y: (a.y + f.y) / 2 }, d = null;
        for (let b = 0; b < a.parentIndex.length; ++b)
            if (f.parentIndex.includes(a.parentIndex[b])) {
                let p = t[a.parentIndex[b]], M = Math.atan2(a.x - p.x, a.y - p.y), T = Math.atan2(f.x - p.x, f.y - p.y), _ = T - M;
                _ < 0 && (_ += 2 * Math.PI);
                let S = T - _ / 2, g = U(y, { x: p.x + p.radius * Math.sin(S), y: p.y + p.radius * Math.cos(S) });
                g > p.radius * 2 && (g = p.radius * 2), (d == null || d.width > g) && (d = { circle: p, width: g, p1: a, p2: f, large: g > p.radius, sweep: !0 });
            }
        d != null && (o.push(d), i += ht(d.circle.radius, d.width), f = a);
    }
}
else {
    let l = t[0];
    for (let u = 1; u < t.length; ++u)
        t[u].radius < l.radius && (l = t[u]);
    let f = !1;
    for (let u = 0; u < t.length; ++u)
        if (U(t[u], l) > Math.abs(l.radius - t[u].radius)) {
            f = !0;
            break;
        }
    f ? i = r = 0 : (i = l.radius * l.radius * Math.PI, o.push({ circle: l, p1: { x: l.x, y: l.y + l.radius }, p2: { x: l.x - 1e-10, y: l.y + l.radius }, width: l.radius * 2, large: !0, sweep: !0 }));
} return r /= 2, n && (n.area = i + r, n.arcArea = i, n.polygonArea = r, n.arcs = o, n.innerPoints = e, n.intersectionPoints = s), i + r; }
function fe(t, n) { return n.every(s => U(t, s) < s.radius + 1e-10); }
function he(t) { let n = []; for (let s = 0; s < t.length; ++s)
    for (let e = s + 1; e < t.length; ++e) {
        let i = Wt(t[s], t[e]);
        for (let r of i)
            r.parentIndex = [s, e], n.push(r);
    } return n; }
function ht(t, n) { return t * t * Math.acos(1 - n / t) - (t - n) * Math.sqrt(n * (2 * t - n)); }
function U(t, n) { return Math.sqrt((t.x - n.x) * (t.x - n.x) + (t.y - n.y) * (t.y - n.y)); }
function mt(t, n, s) { if (s >= t + n)
    return 0; if (s <= Math.abs(t - n))
    return Math.PI * Math.min(t, n) * Math.min(t, n); let e = t - (s * s - n * n + t * t) / (2 * s), i = n - (s * s - t * t + n * n) / (2 * s); return ht(t, e) + ht(n, i); }
function Wt(t, n) { let s = U(t, n), e = t.radius, i = n.radius; if (s >= e + i || s <= Math.abs(e - i))
    return []; let r = (e * e - i * i + s * s) / (2 * s), o = Math.sqrt(e * e - r * r), l = t.x + r * (n.x - t.x) / s, f = t.y + r * (n.y - t.y) / s, u = -(n.y - t.y) * (o / s), a = -(n.x - t.x) * (o / s); return [{ x: l + u, y: f - a }, { x: l - u, y: f + a }]; }
function Kt(t) { let n = { x: 0, y: 0 }; for (let s of t)
    n.x += s.x, n.y += s.y; return n.x /= t.length, n.y /= t.length, n; }
function de(t, n, s, e) { e = e || {}; let i = e.maxIterations || 100, r = e.tolerance || 1e-10, o = t(n), l = t(s), f = s - n; if (o * l > 0)
    throw "Initial bisect points must have opposite signs"; if (o === 0)
    return n; if (l === 0)
    return s; for (let u = 0; u < i; ++u) {
    f /= 2;
    let a = n + f, y = t(a);
    if (y * o >= 0 && (n = a), Math.abs(f) < r || y === 0)
        return a;
} return n + f; }
function dt(t) { let n = new Array(t); for (let s = 0; s < t; ++s)
    n[s] = 0; return n; }
function Ut(t, n) { return dt(t).map(() => dt(n)); }
function $(t, n) { let s = 0; for (let e = 0; e < t.length; ++e)
    s += t[e] * n[e]; return s; }
function gt(t) { return Math.sqrt($(t, t)); }
function xt(t, n, s) { for (let e = 0; e < n.length; ++e)
    t[e] = n[e] * s; }
function J(t, n, s, e, i) { for (let r = 0; r < t.length; ++r)
    t[r] = n * s[r] + e * i[r]; }
function Ht(t, n, s) { s = s || {}; let e = s.maxIterations || n.length * 200, i = s.nonZeroDelta || 1.05, r = s.zeroDelta || .001, o = s.minErrorDelta || 1e-6, l = s.minErrorDelta || 1e-5, f = s.rho !== void 0 ? s.rho : 1, u = s.chi !== void 0 ? s.chi : 2, a = s.psi !== void 0 ? s.psi : -.5, y = s.sigma !== void 0 ? s.sigma : .5, d, b = n.length, p = new Array(b + 1); p[0] = n, p[0].fx = t(n), p[0].id = 0; for (let v = 0; v < b; ++v) {
    let c = n.slice();
    c[v] = c[v] ? c[v] * i : r, p[v + 1] = c, p[v + 1].fx = t(c), p[v + 1].id = v + 1;
} function M(v) { for (let c = 0; c < v.length; c++)
    p[b][c] = v[c]; p[b].fx = v.fx; } let T = (v, c) => v.fx - c.fx, _ = n.slice(), S = n.slice(), g = n.slice(), m = n.slice(); for (let v = 0; v < e; ++v) {
    if (p.sort(T), s.history) {
        let x = p.map(h => { let D = h.slice(); return D.fx = h.fx, D.id = h.id, D; });
        x.sort((h, D) => h.id - D.id), s.history.push({ x: p[0].slice(), fx: p[0].fx, simplex: x });
    }
    d = 0;
    for (let x = 0; x < b; ++x)
        d = Math.max(d, Math.abs(p[0][x] - p[1][x]));
    if (Math.abs(p[0].fx - p[b].fx) < o && d < l)
        break;
    for (let x = 0; x < b; ++x) {
        _[x] = 0;
        for (let h = 0; h < b; ++h)
            _[x] += p[h][x];
        _[x] /= b;
    }
    let c = p[b];
    if (J(S, 1 + f, _, -f, c), S.fx = t(S), S.fx < p[0].fx)
        J(m, 1 + u, _, -u, c), m.fx = t(m), m.fx < S.fx ? M(m) : M(S);
    else if (S.fx >= p[b - 1].fx) {
        let x = !1;
        if (S.fx > c.fx ? (J(g, 1 + a, _, -a, c), g.fx = t(g), g.fx < c.fx ? M(g) : x = !0) : (J(g, 1 - a * f, _, a * f, c), g.fx = t(g), g.fx < S.fx ? M(g) : x = !0), x) {
            if (y >= 1)
                break;
            for (let h = 1; h < p.length; ++h)
                J(p[h], 1 - y, p[0], y, p[h]), p[h].fx = t(p[h]);
        }
    }
    else
        M(S);
} return p.sort(T), { fx: p[0].fx, x: p[0] }; }
function ge(t, n, s, e, i, r, o) { let l = s.fx, f = $(s.fxprime, n), u = l, a = l, y = f, d = 0; i = i || 1, r = r || 1e-6, o = o || .1; function b(p, M, T) { for (let _ = 0; _ < 16; ++_)
    if (i = (p + M) / 2, J(e.x, 1, s.x, i, n), u = e.fx = t(e.x, e.fxprime), y = $(e.fxprime, n), u > l + r * i * f || u >= T)
        M = i;
    else {
        if (Math.abs(y) <= -o * f)
            return i;
        y * (M - p) >= 0 && (M = p), p = i, T = u;
    } return 0; } for (let p = 0; p < 10; ++p) {
    if (J(e.x, 1, s.x, i, n), u = e.fx = t(e.x, e.fxprime), y = $(e.fxprime, n), u > l + r * i * f || p && u >= a)
        return b(d, i, a);
    if (Math.abs(y) <= -o * f)
        return i;
    if (y >= 0)
        return b(i, d, u);
    a = u, d = i, i *= 2;
} return i; }
function xe(t, n, s) { let e = { x: n.slice(), fx: 0, fxprime: n.slice() }, i = { x: n.slice(), fx: 0, fxprime: n.slice() }, r = n.slice(), o, l, f = 1, u; s = s || {}, u = s.maxIterations || n.length * 20, e.fx = t(e.x, e.fxprime), o = e.fxprime.slice(), xt(o, e.fxprime, -1); for (let a = 0; a < u; ++a) {
    if (f = ge(t, o, e, i, f), s.history && s.history.push({ x: e.x.slice(), fx: e.fx, fxprime: e.fxprime.slice(), alpha: f }), !f)
        xt(o, e.fxprime, -1);
    else {
        J(r, 1, i.fxprime, -1, e.fxprime);
        let y = $(e.fxprime, e.fxprime), d = Math.max(0, $(r, i.fxprime) / y);
        J(o, d, o, -1, i.fxprime), l = e, e = i, i = l;
    }
    if (gt(e.fxprime) <= 1e-5)
        break;
} return s.history && s.history.push({ x: e.x.slice(), fx: e.fx, fxprime: e.fxprime.slice(), alpha: f }), e; }
function Yt(t, n = {}) { n.maxIterations = n.maxIterations || 500; let s = n.initialLayout || be, e = n.lossFunction || tt, i = ye(t, n), r = s(i, n), o = Object.keys(r), l = []; for (let a of o)
    l.push(r[a].x), l.push(r[a].y); let u = Ht(a => { let y = {}; for (let d = 0; d < o.length; ++d) {
    let b = o[d];
    y[b] = { x: a[2 * d], y: a[2 * d + 1], radius: r[b].radius };
} return e(y, i); }, l, n).x; for (let a = 0; a < o.length; ++a) {
    let y = o[a];
    r[y].x = u[2 * a], r[y].y = u[2 * a + 1];
} return r; }
var Xt = 1e-10;
function yt(t, n, s) { return Math.min(t, n) * Math.min(t, n) * Math.PI <= s + Xt ? Math.abs(t - n) : de(e => mt(t, n, e) - s, 0, t + n); }
function ye(t, n = {}) { let s = n.distinct, e = t.map(l => Object.assign({}, l)); function i(l) { return l.join(";"); } if (s) {
    let l = new Map;
    for (let f of e)
        for (let u = 0; u < f.sets.length; u++) {
            let a = String(f.sets[u]);
            l.set(a, f.size + (l.get(a) || 0));
            for (let y = u + 1; y < f.sets.length; y++) {
                let d = String(f.sets[y]), b = `${a};${d}`, p = `${d};${a}`;
                l.set(b, f.size + (l.get(b) || 0)), l.set(p, f.size + (l.get(p) || 0));
            }
        }
    for (let f of e)
        f.sets.length < 3 && (f.size = l.get(i(f.sets)));
} let r = [], o = new Set; for (let l of e)
    if (l.sets.length === 1)
        r.push(l.sets[0]);
    else if (l.sets.length === 2) {
        let f = l.sets[0], u = l.sets[1];
        o.add(i(l.sets)), o.add(i([u, f]));
    } r.sort((l, f) => l === f ? 0 : l < f ? -1 : 1); for (let l = 0; l < r.length; ++l) {
    let f = r[l];
    for (let u = l + 1; u < r.length; ++u) {
        let a = r[u];
        o.has(i([f, a])) || e.push({ sets: [f, a], size: 0 });
    }
} return e; }
function pe(t, n, s) { let e = Ut(n.length, n.length), i = Ut(n.length, n.length); return t.filter(r => r.sets.length === 2).forEach(r => { let o = s[r.sets[0]], l = s[r.sets[1]], f = Math.sqrt(n[o].size / Math.PI), u = Math.sqrt(n[l].size / Math.PI), a = yt(f, u, r.size); e[o][l] = e[l][o] = a; let y = 0; r.size + 1e-10 >= Math.min(n[o].size, n[l].size) ? y = 1 : r.size <= 1e-10 && (y = -1), i[o][l] = i[l][o] = y; }), { distances: e, constraints: i }; }
function me(t, n, s, e) { for (let r = 0; r < n.length; ++r)
    n[r] = 0; let i = 0; for (let r = 0; r < s.length; ++r) {
    let o = t[2 * r], l = t[2 * r + 1];
    for (let f = r + 1; f < s.length; ++f) {
        let u = t[2 * f], a = t[2 * f + 1], y = s[r][f], d = e[r][f], b = (u - o) * (u - o) + (a - l) * (a - l), p = Math.sqrt(b), M = b - y * y;
        d > 0 && p <= y || d < 0 && p >= y || (i += 2 * M * M, n[2 * r] += 4 * M * (o - u), n[2 * r + 1] += 4 * M * (l - a), n[2 * f] += 4 * M * (u - o), n[2 * f + 1] += 4 * M * (a - l));
    }
} return i; }
function be(t, n = {}) { let s = ke(t, n), e = n.lossFunction || tt; if (t.length >= 8) {
    let i = ve(t, n), r = e(i, t), o = e(s, t);
    r + 1e-8 < o && (s = i);
} return s; }
function ve(t, n = {}) { let s = n.restarts || 10, e = [], i = {}; for (let d of t)
    d.sets.length === 1 && (i[d.sets[0]] = e.length, e.push(d)); let { distances: r, constraints: o } = pe(t, e, i), l = gt(r.map(gt)) / r.length; r = r.map(d => d.map(b => b / l)); let f = (d, b) => me(d, b, r, o), u = null; for (let d = 0; d < s; ++d) {
    let b = dt(r.length * 2).map(Math.random), p = xe(f, b, n);
    (!u || p.fx < u.fx) && (u = p);
} let a = u.x, y = {}; for (let d = 0; d < e.length; ++d) {
    let b = e[d];
    y[b.sets[0]] = { x: a[2 * d] * l, y: a[2 * d + 1] * l, radius: Math.sqrt(b.size / Math.PI) };
} if (n.history)
    for (let d of n.history)
        xt(d.x, l); return y; }
function ke(t, n) { let s = n && n.lossFunction ? n.lossFunction : tt, e = {}, i = {}; for (let y of t)
    if (y.sets.length === 1) {
        let d = y.sets[0];
        e[d] = { x: 1e10, y: 1e10, rowid: e.length, size: y.size, radius: Math.sqrt(y.size / Math.PI) }, i[d] = [];
    } t = t.filter(y => y.sets.length === 2); for (let y of t) {
    let d = y.weight != null ? y.weight : 1, b = y.sets[0], p = y.sets[1];
    y.size + Xt >= Math.min(e[b].size, e[p].size) && (d = 0), i[b].push({ set: p, size: y.size, weight: d }), i[p].push({ set: b, size: y.size, weight: d });
} let r = []; Object.keys(i).forEach(y => { let d = 0; for (let b = 0; b < i[y].length; ++b)
    d += i[y][b].size * i[y][b].weight; r.push({ set: y, size: d }); }); function o(y, d) { return d.size - y.size; } r.sort(o); let l = {}; function f(y) { return y.set in l; } function u(y, d) { e[d].x = y.x, e[d].y = y.y, l[d] = !0; } u({ x: 0, y: 0 }, r[0].set); for (let y = 1; y < r.length; ++y) {
    let d = r[y].set, b = i[d].filter(f), p = e[d];
    if (b.sort(o), b.length === 0)
        throw "ERROR: missing pairwise overlap information";
    let M = [];
    for (var a = 0; a < b.length; ++a) {
        let S = e[b[a].set], g = yt(p.radius, S.radius, b[a].size);
        M.push({ x: S.x + g, y: S.y }), M.push({ x: S.x - g, y: S.y }), M.push({ y: S.y + g, x: S.x }), M.push({ y: S.y - g, x: S.x });
        for (let m = a + 1; m < b.length; ++m) {
            let v = e[b[m].set], c = yt(p.radius, v.radius, b[m].size), x = Wt({ x: S.x, y: S.y, radius: g }, { x: v.x, y: v.y, radius: c });
            M.push(...x);
        }
    }
    let T = 1e50, _ = M[0];
    for (let S of M) {
        e[d].x = S.x, e[d].y = S.y;
        let g = s(e, t);
        g < T && (T = g, _ = S);
    }
    u(_, d);
} return e; }
function tt(t, n) { let s = 0; for (let e of n) {
    if (e.sets.length === 1)
        continue;
    let i;
    if (e.sets.length === 2) {
        let o = t[e.sets[0]], l = t[e.sets[1]];
        i = mt(o.radius, l.radius, U(o, l));
    }
    else
        i = rt(e.sets.map(o => t[o]));
    let r = e.weight != null ? e.weight : 1;
    s += r * (i - e.size) * (i - e.size);
} return s; }
function Zt(t, n) { let s = 0; for (let e of n) {
    if (e.sets.length === 1)
        continue;
    let i;
    if (e.sets.length === 2) {
        let l = t[e.sets[0]], f = t[e.sets[1]];
        i = mt(l.radius, f.radius, U(l, f));
    }
    else
        i = rt(e.sets.map(l => t[l]));
    let r = e.weight != null ? e.weight : 1, o = Math.log((i + 1) / (e.size + 1));
    s += r * o * o;
} return s; }
function Ie(t, n, s) { if (s == null ? t.sort((i, r) => r.radius - i.radius) : t.sort(s), t.length > 0) {
    let i = t[0].x, r = t[0].y;
    for (let o of t)
        o.x -= i, o.y -= r;
} if (t.length === 2 && U(t[0], t[1]) < Math.abs(t[1].radius - t[0].radius) && (t[1].x = t[0].x + t[0].radius - t[1].radius - 1e-10, t[1].y = t[0].y), t.length > 1) {
    let i = Math.atan2(t[1].x, t[1].y) - n, r = Math.cos(i), o = Math.sin(i);
    for (let l of t) {
        let f = l.x, u = l.y;
        l.x = r * f - o * u, l.y = o * f + r * u;
    }
} if (t.length > 2) {
    let i = Math.atan2(t[2].x, t[2].y) - n;
    for (; i < 0;)
        i += 2 * Math.PI;
    for (; i > 2 * Math.PI;)
        i -= 2 * Math.PI;
    if (i > Math.PI) {
        let r = t[1].y / (1e-10 + t[1].x);
        for (let o of t) {
            var e = (o.x + r * o.y) / (1 + r * r);
            o.x = 2 * e - o.x, o.y = 2 * e * r - o.y;
        }
    }
} }
function Me(t) { t.forEach(i => { i.parent = i; }); function n(i) { return i.parent !== i && (i.parent = n(i.parent)), i.parent; } function s(i, r) { let o = n(i), l = n(r); o.parent = l; } for (let i = 0; i < t.length; ++i)
    for (let r = i + 1; r < t.length; ++r) {
        let o = t[i].radius + t[r].radius;
        U(t[i], t[r]) + 1e-10 < o && s(t[r], t[i]);
    } let e = new Map; for (let i = 0; i < t.length; ++i) {
    let r = n(t[i]).parent.setid;
    e.has(r) || e.set(r, []), e.get(r).push(t[i]);
} return t.forEach(i => { delete i.parent; }), Array.from(e.values()); }
function pt(t) { let n = s => { let e = t.reduce((r, o) => Math.max(r, o[s] + o.radius), Number.NEGATIVE_INFINITY), i = t.reduce((r, o) => Math.min(r, o[s] - o.radius), Number.POSITIVE_INFINITY); return { max: e, min: i }; }; return { xRange: n("x"), yRange: n("y") }; }
function Jt(t, n, s) { n == null && (n = Math.PI / 2); let e = te(t).map(u => Object.assign({}, u)), i = Me(e); for (let u of i) {
    Ie(u, n, s);
    let a = pt(u);
    u.size = (a.xRange.max - a.xRange.min) * (a.yRange.max - a.yRange.min), u.bounds = a;
} i.sort((u, a) => a.size - u.size), e = i[0]; let r = e.bounds, o = (r.xRange.max - r.xRange.min) / 50; function l(u, a, y) { if (!u)
    return; let d = u.bounds, b, p; if (a)
    b = r.xRange.max - d.xRange.min + o;
else {
    b = r.xRange.max - d.xRange.max;
    let M = (d.xRange.max - d.xRange.min) / 2 - (r.xRange.max - r.xRange.min) / 2;
    M < 0 && (b += M);
} if (y)
    p = r.yRange.max - d.yRange.min + o;
else {
    p = r.yRange.max - d.yRange.max;
    let M = (d.yRange.max - d.yRange.min) / 2 - (r.yRange.max - r.yRange.min) / 2;
    M < 0 && (p += M);
} for (let M of u)
    M.x += b, M.y += p, e.push(M); } let f = 1; for (; f < i.length;)
    l(i[f], !0, !1), l(i[f + 1], !1, !0), l(i[f + 2], !0, !0), f += 3, r = pt(e); return $t(e); }
function Qt(t, n, s, e, i) { let r = te(t); n -= 2 * e, s -= 2 * e; let { xRange: o, yRange: l } = pt(r); if (o.max === o.min || l.max === l.min)
    return console.log("not scaling solution: zero size detected"), t; let f, u; if (i) {
    let b = Math.sqrt(i / Math.PI) * 2;
    f = n / b, u = s / b;
}
else
    f = n / (o.max - o.min), u = s / (l.max - l.min); let a = Math.min(u, f), y = (n - (o.max - o.min) * a) / 2, d = (s - (l.max - l.min) * a) / 2; return $t(r.map(b => ({ radius: a * b.radius, x: e + y + (b.x - o.min) * a, y: e + d + (b.y - l.min) * a, setid: b.setid }))); }
function $t(t) { let n = {}; for (let s of t)
    n[s.setid] = s; return n; }
function te(t) { return Object.keys(t).map(s => Object.assign(t[s], { setid: s })); }
function ee(t = {}) { let n = !1, s = 600, e = 350, i = 15, r = 1e3, o = Math.PI / 2, l = !0, f = null, u = !0, a = !0, y = null, d = null, b = !1, p = null, M = t && t.symmetricalTextCentre ? t.symmetricalTextCentre : !1, T = {}, _ = t && t.colourScheme ? t.colourScheme : t && t.colorScheme ? t.colorScheme : ["#1f77b4", "#ff7f0e", "#2ca02c", "#d62728", "#9467bd", "#8c564b", "#e377c2", "#7f7f7f", "#bcbd22", "#17becf"], S = 0, g = function (x) { if (x in T)
    return T[x]; var h = T[x] = _[S]; return S += 1, S >= _.length && (S = 0), h; }, m = Yt, v = tt; function c(x) { let h = x.datum(), D = new Set; h.forEach(k => { k.size == 0 && k.sets.length == 1 && D.add(k.sets[0]); }), h = h.filter(k => !k.sets.some(P => D.has(P))); let I = {}, R = {}; if (h.length > 0) {
    let k = m(h, { lossFunction: v, distinct: b });
    l && (k = Jt(k, o, d)), I = Qt(k, s, e, i, f), R = se(I, h, M);
} let G = {}; h.forEach(k => { k.label && (G[k.sets] = k.label); }); function V(k) { if (k.sets in G)
    return G[k.sets]; if (k.sets.length == 1)
    return "" + k.sets[0]; } x.selectAll("svg").data([I]).enter().append("svg"); let N = x.select("svg"); n ? N.attr("viewBox", `0 0 ${s} ${e}`) : N.attr("width", s).attr("height", e); let A = {}, C = !1; N.selectAll(".venn-area path").each(function (k) { let P = this.getAttribute("d"); k.sets.length == 1 && P && !b && (C = !0, A[k.sets[0]] = _e(P)); }); function E(k) { return P => { let et = k.sets.map(Z => { let Y = A[Z], q = I[Z]; return Y || (Y = { x: s / 2, y: e / 2, radius: 1 }), q || (q = { x: s / 2, y: e / 2, radius: 1 }), { x: Y.x * (1 - P) + q.x * P, y: Y.y * (1 - P) + q.y * P, radius: Y.radius * (1 - P) + q.radius * P }; }); return Gt(et, p); }; } let O = N.selectAll(".venn-area").data(h, k => k.sets), B = O.enter().append("g").attr("class", k => `venn-area venn-${k.sets.length == 1 ? "circle" : "intersection"}${k.colour || k.color ? " venn-coloured" : ""}`).attr("data-venn-sets", k => k.sets.join("_")), L = B.append("path"), F = B.append("text").attr("class", "label").text(k => V(k)).attr("text-anchor", "middle").attr("dy", ".35em").attr("x", s / 2).attr("y", e / 2); a && (L.style("fill-opacity", "0").filter(k => k.sets.length == 1).style("fill", k => k.colour ? k.colour : k.color ? k.color : g(k.sets)).style("fill-opacity", ".25"), F.style("fill", k => k.colour || k.color ? "#FFF" : t.textFill ? t.textFill : k.sets.length == 1 ? g(k.sets) : "#444")); function H(k) { return typeof k.transition == "function" ? k.transition("venn").duration(r) : k; } let j = x; C && typeof j.transition == "function" ? (j = H(x), j.selectAll("path").attrTween("d", E)) : j.selectAll("path").attr("d", k => Gt(k.sets.map(P => I[P])), p); let z = j.selectAll("text").filter(k => k.sets in R).text(k => V(k)).attr("x", k => Math.floor(R[k.sets].x)).attr("y", k => Math.floor(R[k.sets].y)); u && (C ? "on" in z ? z.on("end", ut(I, V)) : z.each("end", ut(I, V)) : z.each(ut(I, V))); let X = H(O.exit()).remove(); typeof O.transition == "function" && X.selectAll("path").attrTween("d", E); let W = X.selectAll("text").attr("x", s / 2).attr("y", e / 2); return y !== null && (F.style("font-size", "0px"), z.style("font-size", y), W.style("font-size", "0px")), { circles: I, textCentres: R, nodes: O, enter: B, update: j, exit: X }; } return c.wrap = function (x) { return arguments.length ? (u = x, c) : u; }, c.useViewBox = function () { return n = !0, c; }, c.width = function (x) { return arguments.length ? (s = x, c) : s; }, c.height = function (x) { return arguments.length ? (e = x, c) : e; }, c.padding = function (x) { return arguments.length ? (i = x, c) : i; }, c.distinct = function (x) { return arguments.length ? (b = x, c) : b; }, c.colours = function (x) { return arguments.length ? (g = x, c) : g; }, c.colors = function (x) { return arguments.length ? (g = x, c) : g; }, c.fontSize = function (x) { return arguments.length ? (y = x, c) : y; }, c.round = function (x) { return arguments.length ? (p = x, c) : p; }, c.duration = function (x) { return arguments.length ? (r = x, c) : r; }, c.layoutFunction = function (x) { return arguments.length ? (m = x, c) : m; }, c.normalize = function (x) { return arguments.length ? (l = x, c) : l; }, c.scaleToFit = function (x) { return arguments.length ? (f = x, c) : f; }, c.styled = function (x) { return arguments.length ? (a = x, c) : a; }, c.orientation = function (x) { return arguments.length ? (o = x, c) : o; }, c.orientationOrder = function (x) { return arguments.length ? (d = x, c) : d; }, c.lossFunction = function (x) { return arguments.length ? (v = x === "default" ? tt : x === "logRatio" ? Zt : x, c) : v; }, c; }
function ut(t, n) { return function (s) { let e = this, i = t[s.sets[0]].radius || 50, r = n(s) || "", o = r.split(/\s+/).reverse(), f = (r.length + o.length) / 3, u = o.pop(), a = [u], y = 0, d = 1.1; e.textContent = null; let b = []; function p(g) { let m = e.ownerDocument.createElementNS(e.namespaceURI, "tspan"); return m.textContent = g, b.push(m), e.append(m), m; } let M = p(u); for (; u = o.pop(), !!u;) {
    a.push(u);
    let g = a.join(" ");
    M.textContent = g, g.length > f && M.getComputedTextLength() > i && (a.pop(), M.textContent = a.join(" "), a = [u], M = p(u), y++);
} let T = .35 - y * d / 2, _ = e.getAttribute("x"), S = e.getAttribute("y"); b.forEach((g, m) => { g.setAttribute("x", _), g.setAttribute("y", S), g.setAttribute("dy", `${T + m * d}em`); }); }; }
function ft(t, n, s) { let e = n[0].radius - U(n[0], t); for (let i = 1; i < n.length; ++i) {
    let r = n[i].radius - U(n[i], t);
    r <= e && (e = r);
} for (let i = 0; i < s.length; ++i) {
    let r = U(s[i], t) - s[i].radius;
    r <= e && (e = r);
} return e; }
function ne(t, n, s) { let e = []; for (let a of t)
    e.push({ x: a.x, y: a.y }), e.push({ x: a.x + a.radius / 2, y: a.y }), e.push({ x: a.x - a.radius / 2, y: a.y }), e.push({ x: a.x, y: a.y + a.radius / 2 }), e.push({ x: a.x, y: a.y - a.radius / 2 }); let i = e[0], r = ft(e[0], t, n); for (let a = 1; a < e.length; ++a) {
    let y = ft(e[a], t, n);
    y >= r && (i = e[a], r = y);
} let o = Ht(a => -1 * ft({ x: a[0], y: a[1] }, t, n), [i.x, i.y], { maxIterations: 500, minErrorDelta: 1e-10 }).x, l = { x: s ? 0 : o[0], y: o[1] }, f = !0; for (let a of t)
    if (U(l, a) > a.radius) {
        f = !1;
        break;
    } for (let a of n)
    if (U(l, a) < a.radius) {
        f = !1;
        break;
    } if (f)
    return l; if (t.length == 1)
    return { x: t[0].x, y: t[0].y }; let u = {}; return rt(t, u), u.arcs.length === 0 ? { x: 0, y: -1e3, disjoint: !0 } : u.arcs.length == 1 ? { x: u.arcs[0].circle.x, y: u.arcs[0].circle.y } : n.length ? ne(t, []) : Kt(u.arcs.map(a => a.p1)); }
function Se(t) { let n = {}, s = Object.keys(t); for (let e of s)
    n[e] = []; for (let e = 0; e < s.length; e++) {
    let i = s[e], r = t[i];
    for (let o = e + 1; o < s.length; ++o) {
        let l = s[o], f = t[l], u = U(r, f);
        u + f.radius <= r.radius + 1e-10 ? n[l].push(i) : u + r.radius <= f.radius + 1e-10 && n[i].push(l);
    }
} return n; }
function se(t, n, s) { let e = {}, i = Se(t); for (let r = 0; r < n.length; ++r) {
    let o = n[r].sets, l = {}, f = {};
    for (let d = 0; d < o.length; ++d) {
        l[o[d]] = !0;
        let b = i[o[d]];
        for (let p = 0; p < b.length; ++p)
            f[b[p]] = !0;
    }
    let u = [], a = [];
    for (let d in t)
        d in l ? u.push(t[d]) : d in f || a.push(t[d]);
    let y = ne(u, a, s);
    e[o] = y, y.disjoint && n[r].size > 0 && console.log("WARNING: area " + o + " not represented on screen");
} return e; }
function we(t, n, s) {
    let e = [];
    return e.push(`
M`, t, n), e.push(`
m`, -s, 0), e.push(`
a`, s, s, 0, 1, 0, s * 2, 0), e.push(`
a`, s, s, 0, 1, 0, -s * 2, 0), e.join(" ");
}
function _e(t) { let n = t.split(" "); return { x: Number.parseFloat(n[1]), y: Number.parseFloat(n[2]), radius: -Number.parseFloat(n[4]) }; }
function ie(t) { if (t.length === 0)
    return []; let n = {}; return rt(t, n), n.arcs; }
function re(t, n) {
    if (t.length === 0)
        return "M 0 0";
    let s = Math.pow(10, n || 0), e = n != null ? r => Math.round(r * s) / s : r => r;
    if (t.length == 1) {
        let r = t[0].circle;
        return we(e(r.x), e(r.y), e(r.radius));
    }
    let i = [`
M`, e(t[0].p2.x), e(t[0].p2.y)];
    for (let r of t) {
        let o = e(r.circle.radius);
        i.push(`
A`, o, o, 0, r.large ? 1 : 0, r.sweep ? 1 : 0, e(r.p1.x), e(r.p1.y));
    }
    return i.join(" ");
}
function Gt(t, n) { return re(ie(t), n); }
function oe(t, n = {}) { let { lossFunction: s, layoutFunction: e = Yt, normalize: i = !0, orientation: r = Math.PI / 2, orientationOrder: o, width: l = 600, height: f = 350, padding: u = 15, scaleToFit: a = !1, symmetricalTextCentre: y = !1, distinct: d, round: b = 2 } = n, p = e(t, { lossFunction: s === "default" || !s ? tt : s === "logRatio" ? Zt : s, distinct: d }); i && (p = Jt(p, r, o)); let M = Qt(p, l, f, u, a), T = se(M, t, y), _ = new Map(Object.keys(M).map(m => [m, { set: m, x: M[m].x, y: M[m].y, radius: M[m].radius }])), S = t.map(m => { let v = m.sets.map(h => _.get(h)), c = ie(v), x = re(c, b); return { circles: v, arcs: c, path: x, area: m, has: new Set(m.sets) }; }); function g(m) { let v = ""; for (let c of S)
    c.has.size > m.length && m.every(x => c.has.has(x)) && (v += " " + c.path); return v; } return S.map(({ circles: m, arcs: v, path: c, area: x }) => ({ data: x, text: T[x.sets], circles: m, arcs: v, path: c, distinctPath: c + g(x.sets) })); }
var bt = (function () {
    var t = w(function (S, g, m, v) { for (m = m || {}, v = S.length; v--; m[S[v]] = g)
        ; return m; }, "o"), n = [5, 8], s = [7, 8, 11, 12, 17, 19, 22, 24], e = [1, 17], i = [1, 18], r = [7, 8, 11, 12, 14, 15, 16, 17, 19, 20, 21, 22, 24, 27], o = [1, 31], l = [1, 39], f = [7, 8, 11, 12, 17, 19, 22, 24, 27], u = [1, 57], a = [1, 56], y = [1, 58], d = [1, 59], b = [1, 60], p = [7, 8, 11, 12, 16, 17, 19, 20, 22, 24, 27, 31, 32, 33], M = { trace: w(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, optNewlines: 4, VENN: 5, document: 6, EOF: 7, NEWLINE: 8, line: 9, statement: 10, TITLE: 11, SET: 12, identifier: 13, BRACKET_LABEL: 14, COLON: 15, NUMERIC: 16, UNION: 17, identifierList: 18, TEXT: 19, IDENTIFIER: 20, STRING: 21, INDENT_TEXT: 22, indentedTextTail: 23, STYLE: 24, stylesOpt: 25, styleField: 26, COMMA: 27, styleValue: 28, valueTokens: 29, valueToken: 30, HEXCOLOR: 31, RGBCOLOR: 32, RGBACOLOR: 33, $accept: 0, $end: 1 }, terminals_: { 2: "error", 5: "VENN", 7: "EOF", 8: "NEWLINE", 11: "TITLE", 12: "SET", 14: "BRACKET_LABEL", 15: "COLON", 16: "NUMERIC", 17: "UNION", 19: "TEXT", 20: "IDENTIFIER", 21: "STRING", 22: "INDENT_TEXT", 24: "STYLE", 27: "COMMA", 31: "HEXCOLOR", 32: "RGBCOLOR", 33: "RGBACOLOR" }, productions_: [0, [3, 4], [4, 0], [4, 2], [6, 0], [6, 2], [9, 1], [9, 1], [10, 1], [10, 2], [10, 3], [10, 4], [10, 5], [10, 2], [10, 3], [10, 4], [10, 5], [10, 3], [10, 3], [10, 3], [10, 4], [10, 4], [10, 2], [10, 3], [23, 1], [23, 1], [23, 1], [23, 2], [23, 2], [25, 1], [25, 3], [26, 3], [28, 1], [28, 1], [29, 1], [29, 2], [30, 1], [30, 1], [30, 1], [30, 1], [30, 1], [18, 1], [18, 3], [13, 1], [13, 1]], performAction: w(function (g, m, v, c, x, h, D) { var I = h.length - 1; switch (x) {
            case 1: return h[I - 1];
            case 2:
            case 3:
            case 4:
                this.$ = [];
                break;
            case 5:
                h[I - 1].push(h[I]), this.$ = h[I - 1];
                break;
            case 6:
                this.$ = [];
                break;
            case 7:
            case 22:
            case 32:
            case 36:
            case 37:
            case 38:
            case 39:
            case 40:
                this.$ = h[I];
                break;
            case 8:
                c.setDiagramTitle(h[I].substr(6)), this.$ = h[I].substr(6);
                break;
            case 9:
                c.addSubsetData([h[I]], void 0, void 0), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 10:
                c.addSubsetData([h[I - 1]], h[I], void 0), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 11:
                c.addSubsetData([h[I - 2]], void 0, parseFloat(h[I])), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 12:
                c.addSubsetData([h[I - 3]], h[I - 2], parseFloat(h[I])), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 13:
                if (h[I].length < 2)
                    throw new Error("union requires multiple identifiers");
                c.validateUnionIdentifiers && c.validateUnionIdentifiers(h[I]), c.addSubsetData(h[I], void 0, void 0), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 14:
                if (h[I - 1].length < 2)
                    throw new Error("union requires multiple identifiers");
                c.validateUnionIdentifiers && c.validateUnionIdentifiers(h[I - 1]), c.addSubsetData(h[I - 1], h[I], void 0), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 15:
                if (h[I - 2].length < 2)
                    throw new Error("union requires multiple identifiers");
                c.validateUnionIdentifiers && c.validateUnionIdentifiers(h[I - 2]), c.addSubsetData(h[I - 2], void 0, parseFloat(h[I])), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 16:
                if (h[I - 3].length < 2)
                    throw new Error("union requires multiple identifiers");
                c.validateUnionIdentifiers && c.validateUnionIdentifiers(h[I - 3]), c.addSubsetData(h[I - 3], h[I - 2], parseFloat(h[I])), c.setIndentMode && c.setIndentMode(!0);
                break;
            case 17:
            case 18:
            case 19:
                c.addTextData(h[I - 1], h[I], void 0);
                break;
            case 20:
            case 21:
                c.addTextData(h[I - 2], h[I - 1], h[I]);
                break;
            case 23:
                c.addStyleData(h[I - 1], h[I]);
                break;
            case 24:
            case 25:
            case 26:
                var R = c.getCurrentSets();
                if (!R)
                    throw new Error("text requires set");
                c.addTextData(R, h[I], void 0);
                break;
            case 27:
            case 28:
                var R = c.getCurrentSets();
                if (!R)
                    throw new Error("text requires set");
                c.addTextData(R, h[I - 1], h[I]);
                break;
            case 29:
            case 41:
                this.$ = [h[I]];
                break;
            case 30:
            case 42:
                this.$ = [...h[I - 2], h[I]];
                break;
            case 31:
                this.$ = [h[I - 2], h[I]];
                break;
            case 33:
                this.$ = h[I].join(" ");
                break;
            case 34:
                this.$ = [h[I]];
                break;
            case 35:
                h[I - 1].push(h[I]), this.$ = h[I - 1];
                break;
            case 43:
            case 44:
                this.$ = h[I];
                break;
        } }, "anonymous"), table: [t(n, [2, 2], { 3: 1, 4: 2 }), { 1: [3] }, { 5: [1, 3], 8: [1, 4] }, t(s, [2, 4], { 6: 5 }), t(n, [2, 3]), { 7: [1, 6], 8: [1, 8], 9: 7, 10: 9, 11: [1, 10], 12: [1, 11], 17: [1, 12], 19: [1, 13], 22: [1, 14], 24: [1, 15] }, { 1: [2, 1] }, t(s, [2, 5]), t(s, [2, 6]), t(s, [2, 7]), t(s, [2, 8]), { 13: 16, 20: e, 21: i }, { 13: 20, 18: 19, 20: e, 21: i }, { 13: 20, 18: 21, 20: e, 21: i }, { 16: [1, 25], 20: [1, 23], 21: [1, 24], 23: 22 }, { 13: 20, 18: 26, 20: e, 21: i }, t(s, [2, 9], { 14: [1, 27], 15: [1, 28] }), t(r, [2, 43]), t(r, [2, 44]), t(s, [2, 13], { 14: [1, 29], 15: [1, 30], 27: o }), t(r, [2, 41]), { 16: [1, 34], 20: [1, 32], 21: [1, 33], 27: o }, t(s, [2, 22]), t(s, [2, 24], { 14: [1, 35] }), t(s, [2, 25], { 14: [1, 36] }), t(s, [2, 26]), { 20: l, 25: 37, 26: 38, 27: o }, t(s, [2, 10], { 15: [1, 40] }), { 16: [1, 41] }, t(s, [2, 14], { 15: [1, 42] }), { 16: [1, 43] }, { 13: 44, 20: e, 21: i }, t(s, [2, 17], { 14: [1, 45] }), t(s, [2, 18], { 14: [1, 46] }), t(s, [2, 19]), t(s, [2, 27]), t(s, [2, 28]), t(s, [2, 23], { 27: [1, 47] }), t(f, [2, 29]), { 15: [1, 48] }, { 16: [1, 49] }, t(s, [2, 11]), { 16: [1, 50] }, t(s, [2, 15]), t(r, [2, 42]), t(s, [2, 20]), t(s, [2, 21]), { 20: l, 26: 51 }, { 16: u, 20: a, 21: [1, 53], 28: 52, 29: 54, 30: 55, 31: y, 32: d, 33: b }, t(s, [2, 12]), t(s, [2, 16]), t(f, [2, 30]), t(f, [2, 31]), t(f, [2, 32]), t(f, [2, 33], { 30: 61, 16: u, 20: a, 31: y, 32: d, 33: b }), t(p, [2, 34]), t(p, [2, 36]), t(p, [2, 37]), t(p, [2, 38]), t(p, [2, 39]), t(p, [2, 40]), t(p, [2, 35])], defaultActions: { 6: [2, 1] }, parseError: w(function (g, m) { if (m.recoverable)
            this.trace(g);
        else {
            var v = new Error(g);
            throw v.hash = m, v;
        } }, "parseError"), parse: w(function (g) {
            var m = this, v = [0], c = [], x = [null], h = [], D = this.table, I = "", R = 0, G = 0, V = 0, N = 2, A = 1, C = h.slice.call(arguments, 1), E = Object.create(this.lexer), O = { yy: {} };
            for (var B in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, B) && (O.yy[B] = this.yy[B]);
            E.setInput(g, O.yy), O.yy.lexer = E, O.yy.parser = this, typeof E.yylloc > "u" && (E.yylloc = {});
            var L = E.yylloc;
            h.push(L);
            var F = E.options && E.options.ranges;
            typeof O.yy.parseError == "function" ? this.parseError = O.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function H(K) { v.length = v.length - 2 * K, x.length = x.length - K, h.length = h.length - K; }
            w(H, "popStack");
            function j() { var K; return K = c.pop() || E.lex() || A, typeof K != "number" && (K instanceof Array && (c = K, K = c.pop()), K = m.symbols_[K] || K), K; }
            w(j, "lex");
            for (var z, X, W, k, P, et, Z = {}, Y, q, _t, st;;) {
                if (W = v[v.length - 1], this.defaultActions[W] ? k = this.defaultActions[W] : ((z === null || typeof z > "u") && (z = j()), k = D[W] && D[W][z]), typeof k > "u" || !k.length || !k[0]) {
                    var at = "";
                    st = [];
                    for (Y in D[W])
                        this.terminals_[Y] && Y > N && st.push("'" + this.terminals_[Y] + "'");
                    E.showPosition ? at = "Parse error on line " + (R + 1) + `:
` + E.showPosition() + `
Expecting ` + st.join(", ") + ", got '" + (this.terminals_[z] || z) + "'" : at = "Parse error on line " + (R + 1) + ": Unexpected " + (z == A ? "end of input" : "'" + (this.terminals_[z] || z) + "'"), this.parseError(at, { text: E.match, token: this.terminals_[z] || z, line: E.yylineno, loc: L, expected: st });
                }
                if (k[0] instanceof Array && k.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + W + ", token: " + z);
                switch (k[0]) {
                    case 1:
                        v.push(z), x.push(E.yytext), h.push(E.yylloc), v.push(k[1]), z = null, X ? (z = X, X = null) : (G = E.yyleng, I = E.yytext, R = E.yylineno, L = E.yylloc, V > 0 && V--);
                        break;
                    case 2:
                        if (q = this.productions_[k[1]][1], Z.$ = x[x.length - q], Z._$ = { first_line: h[h.length - (q || 1)].first_line, last_line: h[h.length - 1].last_line, first_column: h[h.length - (q || 1)].first_column, last_column: h[h.length - 1].last_column }, F && (Z._$.range = [h[h.length - (q || 1)].range[0], h[h.length - 1].range[1]]), et = this.performAction.apply(Z, [I, G, R, O.yy, k[1], x, h].concat(C)), typeof et < "u")
                            return et;
                        q && (v = v.slice(0, -1 * q * 2), x = x.slice(0, -1 * q), h = h.slice(0, -1 * q)), v.push(this.productions_[k[1]][0]), x.push(Z.$), h.push(Z._$), _t = D[v[v.length - 2]][v[v.length - 1]], v.push(_t);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, T = (function () {
        var S = { EOF: 1, parseError: w(function (m, v) { if (this.yy.parser)
                this.yy.parser.parseError(m, v);
            else
                throw new Error(m); }, "parseError"), setInput: w(function (g, m) { return this.yy = m || this.yy || {}, this._input = g, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: w(function () { var g = this._input[0]; this.yytext += g, this.yyleng++, this.offset++, this.match += g, this.matched += g; var m = g.match(/(?:\r\n?|\n).*/g); return m ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), g; }, "input"), unput: w(function (g) { var m = g.length, v = g.split(/(?:\r\n?|\n)/g); this._input = g + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - m), this.offset -= m; var c = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), v.length - 1 && (this.yylineno -= v.length - 1); var x = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: v ? (v.length === c.length ? this.yylloc.first_column : 0) + c[c.length - v.length].length - v[0].length : this.yylloc.first_column - m }, this.options.ranges && (this.yylloc.range = [x[0], x[0] + this.yyleng - m]), this.yyleng = this.yytext.length, this; }, "unput"), more: w(function () { return this._more = !0, this; }, "more"), reject: w(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: w(function (g) { this.unput(this.match.slice(g)); }, "less"), pastInput: w(function () { var g = this.matched.substr(0, this.matched.length - this.match.length); return (g.length > 20 ? "..." : "") + g.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: w(function () { var g = this.match; return g.length < 20 && (g += this._input.substr(0, 20 - g.length)), (g.substr(0, 20) + (g.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: w(function () {
                var g = this.pastInput(), m = new Array(g.length + 1).join("-");
                return g + this.upcomingInput() + `
` + m + "^";
            }, "showPosition"), test_match: w(function (g, m) { var v, c, x; if (this.options.backtrack_lexer && (x = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (x.yylloc.range = this.yylloc.range.slice(0))), c = g[0].match(/(?:\r\n?|\n).*/g), c && (this.yylineno += c.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: c ? c[c.length - 1].length - c[c.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + g[0].length }, this.yytext += g[0], this.match += g[0], this.matches = g, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(g[0].length), this.matched += g[0], v = this.performAction.call(this, this.yy, this, m, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), v)
                return v; if (this._backtrack) {
                for (var h in x)
                    this[h] = x[h];
                return !1;
            } return !1; }, "test_match"), next: w(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var g, m, v, c;
                this._more || (this.yytext = "", this.match = "");
                for (var x = this._currentRules(), h = 0; h < x.length; h++)
                    if (v = this._input.match(this.rules[x[h]]), v && (!m || v[0].length > m[0].length)) {
                        if (m = v, c = h, this.options.backtrack_lexer) {
                            if (g = this.test_match(v, x[h]), g !== !1)
                                return g;
                            if (this._backtrack) {
                                m = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return m ? (g = this.test_match(m, x[c]), g !== !1 ? g : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: w(function () { var m = this.next(); return m || this.lex(); }, "lex"), begin: w(function (m) { this.conditionStack.push(m); }, "begin"), popState: w(function () { var m = this.conditionStack.length - 1; return m > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: w(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: w(function (m) { return m = this.conditionStack.length - 1 - Math.abs(m || 0), m >= 0 ? this.conditionStack[m] : "INITIAL"; }, "topState"), pushState: w(function (m) { this.begin(m); }, "pushState"), stateStackSize: w(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: w(function (m, v, c, x) { var h = x; switch (c) {
                case 0: break;
                case 1: break;
                case 2: break;
                case 3:
                    if (m.getIndentMode && m.getIndentMode())
                        return m.consumeIndentText = !0, this.begin("INITIAL"), 22;
                    break;
                case 4: break;
                case 5:
                    m.setIndentMode && m.setIndentMode(!1), this.begin("INITIAL"), this.unput(v.yytext);
                    break;
                case 6:
                    return this.begin("bol"), 8;
                    break;
                case 7: break;
                case 8: break;
                case 9: return 7;
                case 10: return 11;
                case 11: return 5;
                case 12: return 12;
                case 13: return 17;
                case 14:
                    if (m.consumeIndentText)
                        m.consumeIndentText = !1;
                    else
                        return 19;
                    break;
                case 15: return 24;
                case 16:
                    return v.yytext = v.yytext.slice(2, -2), 14;
                    break;
                case 17:
                    return v.yytext = v.yytext.slice(1, -1).trim(), 14;
                    break;
                case 18: return 16;
                case 19: return 31;
                case 20: return 33;
                case 21: return 32;
                case 22: return 20;
                case 23: return 21;
                case 24: return 27;
                case 25: return 15;
            } }, "anonymous"), rules: [/^(?:%%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:[ \t]+(?=[\n\r]))/i, /^(?:[ \t]+(?=text\b))/i, /^(?:[ \t]+)/i, /^(?:[^ \t\n\r])/i, /^(?:[\n\r]+)/i, /^(?:%%[^\n]*)/i, /^(?:[ \t]+)/i, /^(?:$)/i, /^(?:title\s[^#\n;]+)/i, /^(?:venn-beta\b)/i, /^(?:set\b)/i, /^(?:union\b)/i, /^(?:text\b)/i, /^(?:style\b)/i, /^(?:\["[^\"]*"\])/i, /^(?:\[[^\]\"]+\])/i, /^(?:[+-]?(\d+(\.\d+)?|\.\d+))/i, /^(?:#[0-9a-fA-F]{3,8})/i, /^(?:rgba\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i, /^(?:rgb\(\s*[0-9.]+\s*[,]\s*[0-9.]+\s*[,]\s*[0-9.]+\s*\))/i, /^(?:[A-Za-z_][A-Za-z0-9\-_]*)/i, /^(?:"[^\"]*")/i, /^(?:,)/i, /^(?::)/i], conditions: { bol: { rules: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25], inclusive: !0 }, INITIAL: { rules: [0, 1, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25], inclusive: !0 } } };
        return S;
    })();
    M.lexer = T;
    function _() { this.yy = {}; }
    return w(_, "Parser"), _.prototype = M, M.Parser = _, new _;
})();
bt.parser = bt;
var Te = bt, vt = [], kt = [], It = [], Mt = new Set, St, wt = !1, ze = w((t, n, s) => { let e = ot(t).sort(), i = s ?? 10 / Math.pow(t.length, 2); St = e, e.length === 1 && Mt.add(e[0]), vt.push({ sets: e, size: i, label: n ? nt(n) : void 0 }); }, "addSubsetData"), Ae = w(() => vt, "getSubsetData"), nt = w(t => { let n = t.trim(); return n.length >= 2 && n.startsWith('"') && n.endsWith('"') ? n.slice(1, -1) : n; }, "normalizeText"), De = w(t => t && nt(t), "normalizeStyleValue"), Re = w((t, n, s) => { let e = nt(n); kt.push({ sets: ot(t).sort(), id: e, label: s ? nt(s) : void 0 }); }, "addTextData"), Ce = w((t, n) => { let s = ot(t).sort(), e = {}; for (let [i, r] of n)
    e[i] = De(r) ?? r; It.push({ targets: s, styles: e }); }, "addStyleData"), Ne = w(() => It, "getStyleData"), ot = w(t => t.map(n => nt(n)), "normalizeIdentifierList"), Oe = w(t => { let s = ot(t).filter(e => !Mt.has(e)); if (s.length > 0)
    throw new Error(`unknown set identifier: ${s.join(", ")}`); }, "validateUnionIdentifiers"), Le = w(() => kt, "getTextData"), Fe = w(() => St, "getCurrentSets"), je = w(() => wt, "getIndentMode"), Pe = w(t => { wt = t; }, "setIndentMode"), Ve = Dt.venn;
function ae() { return Bt(Ve, ct().venn); }
w(ae, "getConfig");
var Be = w(() => { Ct(), vt.length = 0, kt.length = 0, It.length = 0, Mt.clear(), St = void 0, wt = !1; }, "customClear"), qe = { getConfig: ae, clear: Be, setAccTitle: Nt, getAccTitle: Ot, setDiagramTitle: jt, getDiagramTitle: Pt, getAccDescription: Ft, setAccDescription: Lt, addSubsetData: ze, getSubsetData: Ae, addTextData: Re, addStyleData: Ce, validateUnionIdentifiers: Oe, getTextData: Le, getStyleData: Ne, getCurrentSets: Fe, getIndentMode: je, setIndentMode: Pe }, Ue = w(t => `
  .venn-title {
    font-size: 32px;
    fill: ${t.vennTitleTextColor};
    font-family: ${t.fontFamily};
  }

  .venn-circle text {
    font-size: 48px;
    font-family: ${t.fontFamily};
  }

  .venn-intersection text {
    font-size: 48px;
    fill: ${t.vennSetTextColor};
    font-family: ${t.fontFamily};
  }

  .venn-text-node {
    font-family: ${t.fontFamily};
    color: ${t.vennSetTextColor};
  }
`, "getStyles"), Ge = Ue;
function le(t) { let n = new Map; for (let s of t) {
    let e = s.targets.join("|"), i = n.get(e);
    i ? Object.assign(i, s.styles) : n.set(e, Et({}, s.styles));
} return n; }
w(le, "buildStyleByKey");
var We = w((t, n, s, e) => { let i = e.db, r = i.getConfig?.(), { themeVariables: o, look: l, handDrawnSeed: f } = ct(), u = l === "handDrawn", a = [o.venn1, o.venn2, o.venn3, o.venn4, o.venn5, o.venn6, o.venn7, o.venn8].filter(Boolean), y = i.getDiagramTitle?.(), d = i.getSubsetData(), b = i.getTextData(), p = le(i.getStyleData()), M = ue(d), T = r?.width ?? 800, _ = r?.height ?? 450, g = T / 1600, m = y ? 48 * g : 0, v = o.primaryTextColor ?? o.textColor, c = Vt(n); c.attr("viewBox", `0 0 ${T} ${_}`), y && c.append("text").text(y).attr("class", "venn-title").attr("font-size", `${32 * g}px`).attr("text-anchor", "middle").attr("dominant-baseline", "middle").attr("x", "50%").attr("y", 32 * g).style("fill", o.vennTitleTextColor || o.titleColor); let x = it(document.createElement("div")), h = ee().width(T).height(_ - m); x.datum(M).call(h); let D = u ? qt.svg(x.select("svg").node()) : void 0, I = oe(M, { width: T, height: _ - m, padding: r?.padding ?? 15 }), R = new Map; for (let A of I) {
    let C = Q([...A.data.sets].sort());
    R.set(C, A);
} b.length > 0 && ce(r, R, x, b, g, p); let G = Tt(o.background || "#f4f4f4"); x.selectAll(".venn-circle").each(function (A, C) { let E = it(this), B = Q([...A.sets].sort()), L = p.get(B), F = L?.fill || a[C % a.length] || o.primaryColor; E.classed(`venn-set-${C % 8}`, !0); let H = L?.["fill-opacity"] ?? .1, j = L?.stroke || F, z = L?.["stroke-width"] || `${5 * g}`; if (u && D) {
    let W = R.get(B);
    if (W && W.circles.length > 0) {
        let k = W.circles[0], P = D.circle(k.x, k.y, k.radius * 2, { roughness: .7, seed: f, fill: lt(F, .7), fillStyle: "hachure", fillWeight: 2, hachureGap: 8, hachureAngle: -41 + C * 60, stroke: j, strokeWidth: parseFloat(String(z)) });
        E.select("path").remove(), E.node()?.insertBefore(P, E.select("text").node());
    }
}
else
    E.select("path").style("fill", F).style("fill-opacity", H).style("stroke", j).style("stroke-width", z).style("stroke-opacity", .95); let X = L?.color || (G ? zt(F, 30) : At(F, 30)); E.select("text").style("font-size", `${48 * g}px`).style("fill", X); }), u && D ? x.selectAll(".venn-intersection").each(function (A) { let C = it(this), O = Q([...A.sets].sort()), B = p.get(O), L = B?.fill; if (L) {
    let F = C.select("path"), H = F.attr("d");
    if (H) {
        let j = D.path(H, { roughness: .7, seed: f, fill: lt(L, .3), fillStyle: "cross-hatch", fillWeight: 2, hachureGap: 6, hachureAngle: 60, stroke: "none" }), z = F.node();
        z?.parentNode?.insertBefore(j, z), F.remove();
    }
}
else
    C.select("path").style("fill-opacity", 0); C.select("text").style("font-size", `${48 * g}px`).style("fill", B?.color ?? o.vennSetTextColor ?? v); }) : (x.selectAll(".venn-intersection text").style("font-size", `${48 * g}px`).style("fill", A => { let E = Q([...A.sets].sort()); return p.get(E)?.color ?? o.vennSetTextColor ?? v; }), x.selectAll(".venn-intersection path").style("fill-opacity", A => { let E = Q([...A.sets].sort()); return p.get(E)?.fill ? 1 : 0; }).style("fill", A => { let E = Q([...A.sets].sort()); return p.get(E)?.fill ?? "transparent"; })); let V = c.append("g").attr("transform", `translate(0, ${m})`), N = x.select("svg").node(); if (N && "childNodes" in N)
    for (let A of [...N.childNodes])
        V.node()?.appendChild(A); Rt(c, _, T, r?.useMaxWidth ?? !0); }, "draw");
function Q(t) { return t.join("|"); }
w(Q, "stableSetsKey");
function ce(t, n, s, e, i, r) { let o = t?.useDebugLayout ?? !1, f = s.select("svg").append("g").attr("class", "venn-text-nodes"), u = new Map; for (let a of e) {
    let y = Q(a.sets), d = u.get(y);
    d ? d.push(a) : u.set(y, [a]);
} for (let [a, y] of u.entries()) {
    let d = n.get(a);
    if (!d?.text)
        continue;
    let b = d.text.x, p = d.text.y, M = Math.min(...d.circles.map(N => N.radius)), T = Math.min(...d.circles.map(N => N.radius - Math.hypot(b - N.x, p - N.y))), _ = Number.isFinite(T) ? Math.max(0, T) : 0;
    _ === 0 && Number.isFinite(M) && (_ = M * .6);
    let S = f.append("g").attr("class", "venn-text-area").attr("font-size", `${40 * i}px`);
    o && S.append("circle").attr("class", "venn-text-debug-circle").attr("cx", b).attr("cy", p).attr("r", _).attr("fill", "none").attr("stroke", "purple").attr("stroke-width", 1.5 * i).attr("stroke-dasharray", `${6 * i} ${4 * i}`);
    let g = Math.max(80 * i, _ * 2 * .95), m = Math.max(60 * i, _ * 2 * .95), x = (d.data.label && d.data.label.length > 0 ? Math.min(32 * i, _ * .25) : 0) + (y.length <= 2 ? 30 * i : 0), h = b - g / 2, D = p - m / 2 + x, I = Math.max(1, Math.ceil(Math.sqrt(y.length))), R = Math.max(1, Math.ceil(y.length / I)), G = g / I, V = m / R;
    for (let [N, A] of y.entries()) {
        let C = N % I, E = Math.floor(N / I), O = h + G * (C + .5), B = D + V * (E + .5);
        o && S.append("rect").attr("class", "venn-text-debug-cell").attr("x", h + G * C).attr("y", D + V * E).attr("width", G).attr("height", V).attr("fill", "none").attr("stroke", "teal").attr("stroke-width", 1 * i).attr("stroke-dasharray", `${4 * i} ${3 * i}`);
        let L = G * .9, F = V * .9, H = S.append("foreignObject").attr("class", "venn-text-node-fo").attr("width", L).attr("height", F).attr("x", O - L / 2).attr("y", B - F / 2).attr("overflow", "visible"), j = r.get(A.id)?.color, z = H.append("xhtml:span").attr("class", "venn-text-node").style("display", "flex").style("width", "100%").style("height", "100%").style("white-space", "normal").style("align-items", "center").style("justify-content", "center").style("text-align", "center").style("overflow-wrap", "normal").style("word-break", "normal").text(A.label ?? A.id);
        j && z.style("color", j);
    }
} }
w(ce, "renderTextNodes");
function ue(t) { let n = new Set(t.map(i => [...i.sets].sort().join("|"))), s = new Map(t.filter(i => i.sets.length === 1 && i.size !== void 0).map(i => [i.sets[0], i.size])), e = []; for (let i of t) {
    if (i.sets.length < 3)
        continue;
    let r = [...i.sets].sort();
    for (let o = 0; o < r.length - 1; o++)
        for (let l = o + 1; l < r.length; l++) {
            let f = [r[o], r[l]], u = f.join("|");
            if (!n.has(u)) {
                n.add(u);
                let a = s.get(f[0]), y = s.get(f[1]), d = a !== void 0 && y !== void 0 ? Math.min(a, y) / 4 : 2.5;
                e.push({ sets: f, size: d, label: "" });
            }
        }
} return e.length > 0 ? [...t, ...e] : t; }
w(ue, "ensurePairwiseSubsets");
var Ke = { draw: We }, en = { parser: Te, db: qe, renderer: Ke, styles: Ge };
export { en as diagram };
