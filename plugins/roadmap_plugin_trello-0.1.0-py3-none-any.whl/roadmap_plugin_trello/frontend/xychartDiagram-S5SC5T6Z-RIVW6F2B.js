import { a as qt } from "@nf-internal/chunk-YQ6X4GJP";
import { c as jt } from "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { o as yt } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { H as Wt, O as Xt, T as Nt, U as Yt, V as Ht, W as $t, X as Ut, Y as Gt, Z as ft, i as Vt, k as Ft, u as nt } from "@nf-internal/chunk-LEJRRF65";
import { H as bt, b as dt, n as pt, o as mt } from "@nf-internal/chunk-RZWXGGKD";
import { a } from "@nf-internal/chunk-YUSHYV7C";
import { a as Ot } from "@nf-internal/chunk-OSQMNGTH";
var At = (function () {
    var t = a(function (z, r, h, g) { for (h = h || {}, g = z.length; g--; h[z[g]] = r)
        ; return h; }, "o"), e = [1, 10, 12, 14, 16, 18, 19, 21, 23], i = [2, 6], s = [1, 3], n = [1, 5], u = [1, 6], l = [1, 7], d = [1, 5, 10, 12, 14, 16, 18, 19, 21, 23, 36, 37, 38], p = [1, 25], S = [1, 26], R = [1, 28], T = [1, 29], B = [1, 30], W = [1, 31], X = [1, 32], v = [1, 33], V = [1, 34], N = [1, 35], Y = [1, 36], b = [1, 37], E = [1, 43], c = [1, 42], L = [1, 47], I = [1, 50], A = [1, 10, 12, 14, 16, 18, 19, 21, 23, 36, 37, 38], $ = [1, 10, 12, 14, 16, 18, 19, 21, 23, 24, 26, 28, 29, 36, 37, 38], D = [1, 10, 12, 14, 16, 18, 19, 21, 23, 24, 26, 28, 29, 36, 37, 38, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51], Q = [1, 65], C = [26, 28], y = { trace: a(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, eol: 4, XYCHART: 5, chartConfig: 6, document: 7, CHART_ORIENTATION: 8, statement: 9, title: 10, text: 11, X_AXIS: 12, parseXAxis: 13, Y_AXIS: 14, parseYAxis: 15, LINE: 16, plotData: 17, BAR: 18, acc_title: 19, acc_title_value: 20, acc_descr: 21, acc_descr_value: 22, acc_descr_multiline_value: 23, SQUARE_BRACES_START: 24, dataPoints: 25, SQUARE_BRACES_END: 26, dataPoint: 27, COMMA: 28, NUMBER_WITH_DECIMAL: 29, STR: 30, xAxisData: 31, bandData: 32, ARROW_DELIMITER: 33, commaSeparatedTexts: 34, yAxisData: 35, NEWLINE: 36, SEMI: 37, EOF: 38, alphaNum: 39, MD_STR: 40, alphaNumToken: 41, AMP: 42, NUM: 43, ALPHA: 44, PLUS: 45, EQUALS: 46, MULT: 47, DOT: 48, BRKT: 49, MINUS: 50, UNDERSCORE: 51, $accept: 0, $end: 1 }, terminals_: { 2: "error", 5: "XYCHART", 8: "CHART_ORIENTATION", 10: "title", 12: "X_AXIS", 14: "Y_AXIS", 16: "LINE", 18: "BAR", 19: "acc_title", 20: "acc_title_value", 21: "acc_descr", 22: "acc_descr_value", 23: "acc_descr_multiline_value", 24: "SQUARE_BRACES_START", 26: "SQUARE_BRACES_END", 28: "COMMA", 29: "NUMBER_WITH_DECIMAL", 30: "STR", 33: "ARROW_DELIMITER", 36: "NEWLINE", 37: "SEMI", 38: "EOF", 40: "MD_STR", 42: "AMP", 43: "NUM", 44: "ALPHA", 45: "PLUS", 46: "EQUALS", 47: "MULT", 48: "DOT", 49: "BRKT", 50: "MINUS", 51: "UNDERSCORE" }, productions_: [0, [3, 2], [3, 3], [3, 2], [3, 1], [6, 1], [7, 0], [7, 2], [9, 2], [9, 2], [9, 2], [9, 2], [9, 2], [9, 3], [9, 2], [9, 3], [9, 2], [9, 2], [9, 1], [17, 3], [25, 3], [25, 1], [27, 2], [27, 1], [13, 1], [13, 2], [13, 1], [31, 1], [31, 3], [32, 3], [34, 3], [34, 1], [15, 1], [15, 2], [15, 1], [35, 3], [4, 1], [4, 1], [4, 1], [11, 1], [11, 1], [11, 1], [39, 1], [39, 2], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1], [41, 1]], performAction: a(function (r, h, g, x, k, o, U) { var f = o.length - 1; switch (k) {
            case 5:
                x.setOrientation(o[f]);
                break;
            case 9:
                x.setDiagramTitle(o[f].text.trim());
                break;
            case 12:
                x.setLineData({ text: "", type: "text" }, o[f]);
                break;
            case 13:
                x.setLineData(o[f - 1], o[f]);
                break;
            case 14:
                x.setBarData({ text: "", type: "text" }, o[f]);
                break;
            case 15:
                x.setBarData(o[f - 1], o[f]);
                break;
            case 16:
                this.$ = o[f].trim(), x.setAccTitle(this.$);
                break;
            case 17:
            case 18:
                this.$ = o[f].trim(), x.setAccDescription(this.$);
                break;
            case 19:
                this.$ = o[f - 1];
                break;
            case 20:
            case 30:
                this.$ = [o[f - 2], ...o[f]];
                break;
            case 21:
            case 31:
                this.$ = [o[f]];
                break;
            case 22:
                this.$ = { value: Number(o[f - 1]), label: o[f] };
                break;
            case 23:
                this.$ = { value: Number(o[f]), label: "" };
                break;
            case 24:
                x.setXAxisTitle(o[f]);
                break;
            case 25:
                x.setXAxisTitle(o[f - 1]);
                break;
            case 26:
                x.setXAxisTitle({ type: "text", text: "" });
                break;
            case 27:
                x.setXAxisBand(o[f]);
                break;
            case 28:
                x.setXAxisRangeData(Number(o[f - 2]), Number(o[f]));
                break;
            case 29:
                this.$ = o[f - 1];
                break;
            case 32:
                x.setYAxisTitle(o[f]);
                break;
            case 33:
                x.setYAxisTitle(o[f - 1]);
                break;
            case 34:
                x.setYAxisTitle({ type: "text", text: "" });
                break;
            case 35:
                x.setYAxisRangeData(Number(o[f - 2]), Number(o[f]));
                break;
            case 39:
                this.$ = { text: o[f], type: "text" };
                break;
            case 40:
                this.$ = { text: o[f], type: "text" };
                break;
            case 41:
                this.$ = { text: o[f], type: "markdown" };
                break;
            case 42:
                this.$ = o[f];
                break;
            case 43:
                this.$ = o[f - 1] + "" + o[f];
                break;
        } }, "anonymous"), table: [t(e, i, { 3: 1, 4: 2, 7: 4, 5: s, 36: n, 37: u, 38: l }), { 1: [3] }, t(e, i, { 4: 2, 7: 4, 3: 8, 5: s, 36: n, 37: u, 38: l }), t(e, i, { 4: 2, 7: 4, 6: 9, 3: 10, 5: s, 8: [1, 11], 36: n, 37: u, 38: l }), { 1: [2, 4], 9: 12, 10: [1, 13], 12: [1, 14], 14: [1, 15], 16: [1, 16], 18: [1, 17], 19: [1, 18], 21: [1, 19], 23: [1, 20] }, t(d, [2, 36]), t(d, [2, 37]), t(d, [2, 38]), { 1: [2, 1] }, t(e, i, { 4: 2, 7: 4, 3: 21, 5: s, 36: n, 37: u, 38: l }), { 1: [2, 3] }, t(d, [2, 5]), t(e, [2, 7], { 4: 22, 36: n, 37: u, 38: l }), { 11: 23, 30: p, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, { 11: 39, 13: 38, 24: E, 29: c, 30: p, 31: 40, 32: 41, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, { 11: 45, 15: 44, 29: L, 30: p, 35: 46, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, { 11: 49, 17: 48, 24: I, 30: p, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, { 11: 52, 17: 51, 24: I, 30: p, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, { 20: [1, 53] }, { 22: [1, 54] }, t(A, [2, 18]), { 1: [2, 2] }, t(A, [2, 8]), t(A, [2, 9]), t($, [2, 39], { 41: 55, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }), t($, [2, 40]), t($, [2, 41]), t(D, [2, 42]), t(D, [2, 44]), t(D, [2, 45]), t(D, [2, 46]), t(D, [2, 47]), t(D, [2, 48]), t(D, [2, 49]), t(D, [2, 50]), t(D, [2, 51]), t(D, [2, 52]), t(D, [2, 53]), t(A, [2, 10]), t(A, [2, 24], { 32: 41, 31: 56, 24: E, 29: c }), t(A, [2, 26]), t(A, [2, 27]), { 33: [1, 57] }, { 11: 59, 30: p, 34: 58, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, t(A, [2, 11]), t(A, [2, 32], { 35: 60, 29: L }), t(A, [2, 34]), { 33: [1, 61] }, t(A, [2, 12]), { 17: 62, 24: I }, { 25: 63, 27: 64, 29: Q }, t(A, [2, 14]), { 17: 66, 24: I }, t(A, [2, 16]), t(A, [2, 17]), t(D, [2, 43]), t(A, [2, 25]), { 29: [1, 67] }, { 26: [1, 68] }, { 26: [2, 31], 28: [1, 69] }, t(A, [2, 33]), { 29: [1, 70] }, t(A, [2, 13]), { 26: [1, 71] }, { 26: [2, 21], 28: [1, 72] }, t(C, [2, 23], { 30: [1, 73] }), t(A, [2, 15]), t(A, [2, 28]), t(A, [2, 29]), { 11: 59, 30: p, 34: 74, 39: 24, 40: S, 41: 27, 42: R, 43: T, 44: B, 45: W, 46: X, 47: v, 48: V, 49: N, 50: Y, 51: b }, t(A, [2, 35]), t(A, [2, 19]), { 25: 75, 27: 64, 29: Q }, t(C, [2, 22]), { 26: [2, 30] }, { 26: [2, 20] }], defaultActions: { 8: [2, 1], 10: [2, 3], 21: [2, 2], 74: [2, 30], 75: [2, 20] }, parseError: a(function (r, h) { if (h.recoverable)
            this.trace(r);
        else {
            var g = new Error(r);
            throw g.hash = h, g;
        } }, "parseError"), parse: a(function (r) {
            var h = this, g = [0], x = [], k = [null], o = [], U = this.table, f = "", it = 0, Et = 0, It = 0, pe = 2, Mt = 1, me = o.slice.call(arguments, 1), _ = Object.create(this.lexer), G = { yy: {} };
            for (var lt in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, lt) && (G.yy[lt] = this.yy[lt]);
            _.setInput(r, G.yy), G.yy.lexer = _, G.yy.parser = this, typeof _.yylloc > "u" && (_.yylloc = {});
            var ct = _.yylloc;
            o.push(ct);
            var be = _.options && _.options.ranges;
            typeof G.yy.parseError == "function" ? this.parseError = G.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function ye(M) { g.length = g.length - 2 * M, k.length = k.length - M, o.length = o.length - M; }
            a(ye, "popStack");
            function Bt() { var M; return M = x.pop() || _.lex() || Mt, typeof M != "number" && (M instanceof Array && (x = M, M = x.pop()), M = h.symbols_[M] || M), M; }
            a(Bt, "lex");
            for (var P, gt, q, O, Oe, ut, K = {}, st, H, zt, at;;) {
                if (q = g[g.length - 1], this.defaultActions[q] ? O = this.defaultActions[q] : ((P === null || typeof P > "u") && (P = Bt()), O = U[q] && U[q][P]), typeof O > "u" || !O.length || !O[0]) {
                    var xt = "";
                    at = [];
                    for (st in U[q])
                        this.terminals_[st] && st > pe && at.push("'" + this.terminals_[st] + "'");
                    _.showPosition ? xt = "Parse error on line " + (it + 1) + `:
` + _.showPosition() + `
Expecting ` + at.join(", ") + ", got '" + (this.terminals_[P] || P) + "'" : xt = "Parse error on line " + (it + 1) + ": Unexpected " + (P == Mt ? "end of input" : "'" + (this.terminals_[P] || P) + "'"), this.parseError(xt, { text: _.match, token: this.terminals_[P] || P, line: _.yylineno, loc: ct, expected: at });
                }
                if (O[0] instanceof Array && O.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + q + ", token: " + P);
                switch (O[0]) {
                    case 1:
                        g.push(P), k.push(_.yytext), o.push(_.yylloc), g.push(O[1]), P = null, gt ? (P = gt, gt = null) : (Et = _.yyleng, f = _.yytext, it = _.yylineno, ct = _.yylloc, It > 0 && It--);
                        break;
                    case 2:
                        if (H = this.productions_[O[1]][1], K.$ = k[k.length - H], K._$ = { first_line: o[o.length - (H || 1)].first_line, last_line: o[o.length - 1].last_line, first_column: o[o.length - (H || 1)].first_column, last_column: o[o.length - 1].last_column }, be && (K._$.range = [o[o.length - (H || 1)].range[0], o[o.length - 1].range[1]]), ut = this.performAction.apply(K, [f, Et, it, G.yy, O[1], k, o].concat(me)), typeof ut < "u")
                            return ut;
                        H && (g = g.slice(0, -1 * H * 2), k = k.slice(0, -1 * H), o = o.slice(0, -1 * H)), g.push(this.productions_[O[1]][0]), k.push(K.$), o.push(K._$), zt = U[g[g.length - 2]][g[g.length - 1]], g.push(zt);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, F = (function () {
        var z = { EOF: 1, parseError: a(function (h, g) { if (this.yy.parser)
                this.yy.parser.parseError(h, g);
            else
                throw new Error(h); }, "parseError"), setInput: a(function (r, h) { return this.yy = h || this.yy || {}, this._input = r, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: a(function () { var r = this._input[0]; this.yytext += r, this.yyleng++, this.offset++, this.match += r, this.matched += r; var h = r.match(/(?:\r\n?|\n).*/g); return h ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), r; }, "input"), unput: a(function (r) { var h = r.length, g = r.split(/(?:\r\n?|\n)/g); this._input = r + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - h), this.offset -= h; var x = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), g.length - 1 && (this.yylineno -= g.length - 1); var k = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: g ? (g.length === x.length ? this.yylloc.first_column : 0) + x[x.length - g.length].length - g[0].length : this.yylloc.first_column - h }, this.options.ranges && (this.yylloc.range = [k[0], k[0] + this.yyleng - h]), this.yyleng = this.yytext.length, this; }, "unput"), more: a(function () { return this._more = !0, this; }, "more"), reject: a(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: a(function (r) { this.unput(this.match.slice(r)); }, "less"), pastInput: a(function () { var r = this.matched.substr(0, this.matched.length - this.match.length); return (r.length > 20 ? "..." : "") + r.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: a(function () { var r = this.match; return r.length < 20 && (r += this._input.substr(0, 20 - r.length)), (r.substr(0, 20) + (r.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: a(function () {
                var r = this.pastInput(), h = new Array(r.length + 1).join("-");
                return r + this.upcomingInput() + `
` + h + "^";
            }, "showPosition"), test_match: a(function (r, h) { var g, x, k; if (this.options.backtrack_lexer && (k = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (k.yylloc.range = this.yylloc.range.slice(0))), x = r[0].match(/(?:\r\n?|\n).*/g), x && (this.yylineno += x.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: x ? x[x.length - 1].length - x[x.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + r[0].length }, this.yytext += r[0], this.match += r[0], this.matches = r, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(r[0].length), this.matched += r[0], g = this.performAction.call(this, this.yy, this, h, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), g)
                return g; if (this._backtrack) {
                for (var o in k)
                    this[o] = k[o];
                return !1;
            } return !1; }, "test_match"), next: a(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var r, h, g, x;
                this._more || (this.yytext = "", this.match = "");
                for (var k = this._currentRules(), o = 0; o < k.length; o++)
                    if (g = this._input.match(this.rules[k[o]]), g && (!h || g[0].length > h[0].length)) {
                        if (h = g, x = o, this.options.backtrack_lexer) {
                            if (r = this.test_match(g, k[o]), r !== !1)
                                return r;
                            if (this._backtrack) {
                                h = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return h ? (r = this.test_match(h, k[x]), r !== !1 ? r : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: a(function () { var h = this.next(); return h || this.lex(); }, "lex"), begin: a(function (h) { this.conditionStack.push(h); }, "begin"), popState: a(function () { var h = this.conditionStack.length - 1; return h > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: a(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: a(function (h) { return h = this.conditionStack.length - 1 - Math.abs(h || 0), h >= 0 ? this.conditionStack[h] : "INITIAL"; }, "topState"), pushState: a(function (h) { this.begin(h); }, "pushState"), stateStackSize: a(function () { return this.conditionStack.length; }, "stateStackSize"), options: { "case-insensitive": !0 }, performAction: a(function (h, g, x, k) { var o = k; switch (x) {
                case 0: break;
                case 1: break;
                case 2:
                    return this.popState(), 36;
                    break;
                case 3:
                    return this.popState(), 36;
                    break;
                case 4: return 36;
                case 5: break;
                case 6: return 10;
                case 7:
                    return this.pushState("acc_title"), 19;
                    break;
                case 8:
                    return this.popState(), "acc_title_value";
                    break;
                case 9:
                    return this.pushState("acc_descr"), 21;
                    break;
                case 10:
                    return this.popState(), "acc_descr_value";
                    break;
                case 11:
                    this.pushState("acc_descr_multiline");
                    break;
                case 12:
                    this.popState();
                    break;
                case 13: return "acc_descr_multiline_value";
                case 14: return 5;
                case 15: return 5;
                case 16: return 8;
                case 17:
                    return this.pushState("axis_data"), "X_AXIS";
                    break;
                case 18:
                    return this.pushState("axis_data"), "Y_AXIS";
                    break;
                case 19:
                    return this.pushState("axis_band_data"), 24;
                    break;
                case 20: return 33;
                case 21:
                    return this.pushState("data"), 16;
                    break;
                case 22:
                    return this.pushState("data"), 18;
                    break;
                case 23:
                    return this.pushState("data_inner"), 24;
                    break;
                case 24: return 29;
                case 25:
                    return this.popState(), 26;
                    break;
                case 26:
                    this.popState();
                    break;
                case 27:
                    this.pushState("string");
                    break;
                case 28:
                    this.popState();
                    break;
                case 29: return "STR";
                case 30: return 24;
                case 31: return 26;
                case 32: return 44;
                case 33: return "COLON";
                case 34: return 45;
                case 35: return 28;
                case 36: return 46;
                case 37: return 47;
                case 38: return 49;
                case 39: return 51;
                case 40: return 48;
                case 41: return 42;
                case 42: return 50;
                case 43: return 43;
                case 44: break;
                case 45: return 37;
                case 46: return 38;
            } }, "anonymous"), rules: [/^(?:%%(?!\{)[^\n]*)/i, /^(?:[^\}]%%[^\n]*)/i, /^(?:(\r?\n))/i, /^(?:(\r?\n))/i, /^(?:[\n\r]+)/i, /^(?:%%[^\n]*)/i, /^(?:title\b)/i, /^(?:accTitle\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*:\s*)/i, /^(?:(?!\n||)*[^\n]*)/i, /^(?:accDescr\s*\{\s*)/i, /^(?:\})/i, /^(?:[^\}]*)/i, /^(?:xychart-beta\b)/i, /^(?:xychart\b)/i, /^(?:(?:vertical|horizontal))/i, /^(?:x-axis\b)/i, /^(?:y-axis\b)/i, /^(?:\[)/i, /^(?:-->)/i, /^(?:line\b)/i, /^(?:bar\b)/i, /^(?:\[)/i, /^(?:[+-]?(?:\d+(?:\.\d+)?|\.\d+))/i, /^(?:\])/i, /^(?:(?:`\)                                    \{ this\.pushState\(md_string\); \}\n<md_string>\(\?:\(\?!`"\)\.\)\+                  \{ return MD_STR; \}\n<md_string>\(\?:`))/i, /^(?:["])/i, /^(?:["])/i, /^(?:[^"]*)/i, /^(?:\[)/i, /^(?:\])/i, /^(?:[A-Za-z]+)/i, /^(?::)/i, /^(?:\+)/i, /^(?:,)/i, /^(?:=)/i, /^(?:\*)/i, /^(?:#)/i, /^(?:[\_])/i, /^(?:\.)/i, /^(?:&)/i, /^(?:-)/i, /^(?:[0-9]+)/i, /^(?:\s+)/i, /^(?:;)/i, /^(?:$)/i], conditions: { data_inner: { rules: [0, 1, 4, 5, 6, 7, 9, 11, 14, 15, 16, 17, 18, 21, 22, 24, 25, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], inclusive: !0 }, data: { rules: [0, 1, 3, 4, 5, 6, 7, 9, 11, 14, 15, 16, 17, 18, 21, 22, 23, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], inclusive: !0 }, axis_band_data: { rules: [0, 1, 4, 5, 6, 7, 9, 11, 14, 15, 16, 17, 18, 21, 22, 25, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], inclusive: !0 }, axis_data: { rules: [0, 1, 2, 4, 5, 6, 7, 9, 11, 14, 15, 16, 17, 18, 19, 20, 21, 22, 24, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], inclusive: !0 }, acc_descr_multiline: { rules: [12, 13], inclusive: !1 }, acc_descr: { rules: [10], inclusive: !1 }, acc_title: { rules: [8], inclusive: !1 }, title: { rules: [], inclusive: !1 }, md_string: { rules: [], inclusive: !1 }, string: { rules: [28, 29], inclusive: !1 }, INITIAL: { rules: [0, 1, 4, 5, 6, 7, 9, 11, 14, 15, 16, 17, 18, 21, 22, 26, 27, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46], inclusive: !0 } } };
        return z;
    })();
    y.lexer = F;
    function w() { this.yy = {}; }
    return a(w, "Parser"), w.prototype = y, y.Parser = w, new w;
})();
At.parser = At;
var Ae = At;
function ot(t) { return t.type === "bar"; }
a(ot, "isBarPlot");
function rt(t) { return t.type === "band"; }
a(rt, "isBandAxisData");
function Z(t) { return t.type === "linear"; }
a(Z, "isLinearAxisData");
var St = class {
    constructor(t) { this.parentGroup = t; }
    static { a(this, "TextDimensionCalculatorWithFont"); }
    getMaxDimension(t, e) { if (!this.parentGroup)
        return { width: t.reduce((n, u) => Math.max(u.length, n), 0) * e, height: e }; let i = { width: 0, height: 0 }, s = this.parentGroup.append("g").attr("visibility", "hidden").attr("font-size", e); for (let n of t) {
        let u = jt(s, 1, n), l = u ? u.width : n.length * e, d = u ? u.height : e;
        i.width = Math.max(i.width, l), i.height = Math.max(i.height, d);
    } return s.remove(), i; }
}, Qt = .7, Kt = .2, Zt = class {
    constructor(t, e, i, s) { this.axisConfig = t, this.title = e, this.textDimensionCalculator = i, this.axisThemeConfig = s, this.boundingRect = { x: 0, y: 0, width: 0, height: 0 }, this.axisPosition = "left", this.showTitle = !1, this.showLabel = !1, this.showTick = !1, this.showAxisLine = !1, this.outerPadding = 0, this.titleTextHeight = 0, this.labelTextHeight = 0, this.normalizedLabelRotationInRad = 0, this.range = [0, 10], this.boundingRect = { x: 0, y: 0, width: 0, height: 0 }, this.axisPosition = "left", this.normalizedLabelRotationInRad = this.axisConfig.labelRotation >= -90 && this.axisConfig.labelRotation <= 90 ? this.axisConfig.labelRotation * Math.PI / 180 : 0; }
    static { a(this, "BaseAxis"); }
    setRange(t) { this.range = t, this.axisPosition === "left" || this.axisPosition === "right" ? this.boundingRect.height = t[1] - t[0] : this.boundingRect.width = t[1] - t[0], this.recalculateScale(); }
    getRange() { return [this.range[0] + this.outerPadding, this.range[1] - this.outerPadding]; }
    setAxisPosition(t) { this.axisPosition = t, this.setRange(this.range); }
    getTickDistance() { let t = this.getRange(); return Math.abs(t[0] - t[1]) / this.getTickValues().length; }
    getAxisOuterPadding() { return this.outerPadding; }
    getLabelDimension() { return this.textDimensionCalculator.getMaxDimension(this.getTickValues().map(t => t.toString()), this.axisConfig.labelFontSize); }
    recalculateOuterPaddingToDrawBar() { Qt * this.getTickDistance() > this.outerPadding * 2 && (this.outerPadding = Math.floor(Qt * this.getTickDistance() / 2)), this.recalculateScale(); }
    calculateSpaceIfDrawnHorizontally(t) { let e = t.height; if (this.axisConfig.showAxisLine && e > this.axisConfig.axisLineWidth && (e -= this.axisConfig.axisLineWidth, this.showAxisLine = !0), this.axisConfig.showLabel) {
        let i = this.getLabelDimension(), s = Kt * t.width;
        this.outerPadding = Math.min(i.width / 2, s);
        let n = i.height;
        this.axisPosition === "bottom" && this.normalizedLabelRotationInRad !== 0 && (n = Math.max(n, Math.abs(Math.sin(this.normalizedLabelRotationInRad) * i.width) + Math.abs(Math.cos(this.normalizedLabelRotationInRad) * i.height))), n += this.axisConfig.labelPadding * 2, this.labelTextHeight = i.height, n <= e && (e -= n, this.showLabel = !0);
    } if (this.axisConfig.showTick && e >= this.axisConfig.tickLength && (this.showTick = !0, e -= this.axisConfig.tickLength), this.axisConfig.showTitle && this.title) {
        let i = this.textDimensionCalculator.getMaxDimension([this.title], this.axisConfig.titleFontSize), s = i.height + this.axisConfig.titlePadding * 2;
        this.titleTextHeight = i.height, s <= e && (e -= s, this.showTitle = !0);
    } this.boundingRect.width = t.width, this.boundingRect.height = t.height - e; }
    calculateSpaceIfDrawnVertical(t) { let e = t.width; if (this.axisConfig.showAxisLine && e > this.axisConfig.axisLineWidth && (e -= this.axisConfig.axisLineWidth, this.showAxisLine = !0), this.axisConfig.showLabel) {
        let i = this.getLabelDimension(), s = Kt * t.height;
        this.outerPadding = Math.min(i.height / 2, s);
        let n = i.width + this.axisConfig.labelPadding * 2;
        n <= e && (e -= n, this.showLabel = !0);
    } if (this.axisConfig.showTick && e >= this.axisConfig.tickLength && (this.showTick = !0, e -= this.axisConfig.tickLength), this.axisConfig.showTitle && this.title) {
        let i = this.textDimensionCalculator.getMaxDimension([this.title], this.axisConfig.titleFontSize), s = i.height + this.axisConfig.titlePadding * 2;
        this.titleTextHeight = i.height, s <= e && (e -= s, this.showTitle = !0);
    } this.boundingRect.width = t.width - e, this.boundingRect.height = t.height; }
    calculateSpace(t) { return this.axisPosition === "left" || this.axisPosition === "right" ? this.calculateSpaceIfDrawnVertical(t) : this.calculateSpaceIfDrawnHorizontally(t), this.recalculateScale(), { width: this.boundingRect.width, height: this.boundingRect.height }; }
    setBoundingBoxXY(t) { this.boundingRect.x = t.x, this.boundingRect.y = t.y; }
    calculateOffsetByRotation(t) { let e = this.normalizedLabelRotationInRad; return e === 0 ? 0 : Math.sin(e) * this.getLabelDimension()[t] / 2; }
    getDrawableElementsForLeftAxis() { let t = []; if (this.showAxisLine) {
        let e = this.boundingRect.x + this.boundingRect.width - this.axisConfig.axisLineWidth / 2;
        t.push({ type: "path", groupTexts: ["left-axis", "axisl-line"], data: [{ path: `M ${e},${this.boundingRect.y} L ${e},${this.boundingRect.y + this.boundingRect.height} `, strokeFill: this.axisThemeConfig.axisLineColor, strokeWidth: this.axisConfig.axisLineWidth }] });
    } if (this.showLabel && t.push({ type: "text", groupTexts: ["left-axis", "label"], data: this.getTickValues().map(e => ({ text: e.toString(), x: this.boundingRect.x + this.boundingRect.width - (this.showLabel ? this.axisConfig.labelPadding : 0) - (this.showTick ? this.axisConfig.tickLength : 0) - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0), y: this.getScaleValue(e), fill: this.axisThemeConfig.labelColor, fontSize: this.axisConfig.labelFontSize, rotation: 0, verticalPos: "middle", horizontalPos: "right" })) }), this.showTick) {
        let e = this.boundingRect.x + this.boundingRect.width - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0);
        t.push({ type: "path", groupTexts: ["left-axis", "ticks"], data: this.getTickValues().map(i => ({ path: `M ${e},${this.getScaleValue(i)} L ${e - this.axisConfig.tickLength},${this.getScaleValue(i)}`, strokeFill: this.axisThemeConfig.tickColor, strokeWidth: this.axisConfig.tickWidth })) });
    } return this.showTitle && t.push({ type: "text", groupTexts: ["left-axis", "title"], data: [{ text: this.title, x: this.boundingRect.x + this.axisConfig.titlePadding, y: this.boundingRect.y + this.boundingRect.height / 2, fill: this.axisThemeConfig.titleColor, fontSize: this.axisConfig.titleFontSize, rotation: 270, verticalPos: "top", horizontalPos: "center" }] }), t; }
    getDrawableElementsForBottomAxis() { let t = []; if (this.showAxisLine) {
        let e = this.boundingRect.y + this.axisConfig.axisLineWidth / 2;
        t.push({ type: "path", groupTexts: ["bottom-axis", "axis-line"], data: [{ path: `M ${this.boundingRect.x},${e} L ${this.boundingRect.x + this.boundingRect.width},${e}`, strokeFill: this.axisThemeConfig.axisLineColor, strokeWidth: this.axisConfig.axisLineWidth }] });
    } if (this.showLabel && t.push({ type: "text", groupTexts: ["bottom-axis", "label"], data: this.getTickValues().map(e => ({ text: e.toString(), x: this.getScaleValue(e) + this.calculateOffsetByRotation("height"), y: this.boundingRect.y + this.axisConfig.labelPadding + (this.showTick ? this.axisConfig.tickLength : 0) + (this.showAxisLine ? this.axisConfig.axisLineWidth : 0) + Math.abs(this.calculateOffsetByRotation("width")), fill: this.axisThemeConfig.labelColor, fontSize: this.axisConfig.labelFontSize, rotation: this.normalizedLabelRotationInRad * 180 / Math.PI, verticalPos: "top", horizontalPos: "center" })) }), this.showTick) {
        let e = this.boundingRect.y + (this.showAxisLine ? this.axisConfig.axisLineWidth : 0);
        t.push({ type: "path", groupTexts: ["bottom-axis", "ticks"], data: this.getTickValues().map(i => ({ path: `M ${this.getScaleValue(i)},${e} L ${this.getScaleValue(i)},${e + this.axisConfig.tickLength}`, strokeFill: this.axisThemeConfig.tickColor, strokeWidth: this.axisConfig.tickWidth })) });
    } return this.showTitle && t.push({ type: "text", groupTexts: ["bottom-axis", "title"], data: [{ text: this.title, x: this.range[0] + (this.range[1] - this.range[0]) / 2, y: this.boundingRect.y + this.boundingRect.height - this.axisConfig.titlePadding - this.titleTextHeight, fill: this.axisThemeConfig.titleColor, fontSize: this.axisConfig.titleFontSize, rotation: 0, verticalPos: "top", horizontalPos: "center" }] }), t; }
    getDrawableElementsForTopAxis() { let t = []; if (this.showAxisLine) {
        let e = this.boundingRect.y + this.boundingRect.height - this.axisConfig.axisLineWidth / 2;
        t.push({ type: "path", groupTexts: ["top-axis", "axis-line"], data: [{ path: `M ${this.boundingRect.x},${e} L ${this.boundingRect.x + this.boundingRect.width},${e}`, strokeFill: this.axisThemeConfig.axisLineColor, strokeWidth: this.axisConfig.axisLineWidth }] });
    } if (this.showLabel && t.push({ type: "text", groupTexts: ["top-axis", "label"], data: this.getTickValues().map(e => ({ text: e.toString(), x: this.getScaleValue(e), y: this.boundingRect.y + (this.showTitle ? this.titleTextHeight + this.axisConfig.titlePadding * 2 : 0) + this.axisConfig.labelPadding, fill: this.axisThemeConfig.labelColor, fontSize: this.axisConfig.labelFontSize, rotation: 0, verticalPos: "top", horizontalPos: "center" })) }), this.showTick) {
        let e = this.boundingRect.y;
        t.push({ type: "path", groupTexts: ["top-axis", "ticks"], data: this.getTickValues().map(i => ({ path: `M ${this.getScaleValue(i)},${e + this.boundingRect.height - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0)} L ${this.getScaleValue(i)},${e + this.boundingRect.height - this.axisConfig.tickLength - (this.showAxisLine ? this.axisConfig.axisLineWidth : 0)}`, strokeFill: this.axisThemeConfig.tickColor, strokeWidth: this.axisConfig.tickWidth })) });
    } return this.showTitle && t.push({ type: "text", groupTexts: ["top-axis", "title"], data: [{ text: this.title, x: this.boundingRect.x + this.boundingRect.width / 2, y: this.boundingRect.y + this.axisConfig.titlePadding, fill: this.axisThemeConfig.titleColor, fontSize: this.axisConfig.titleFontSize, rotation: 0, verticalPos: "top", horizontalPos: "center" }] }), t; }
    getDrawableElements() { if (this.axisPosition === "left")
        return this.getDrawableElementsForLeftAxis(); if (this.axisPosition === "right")
        throw Error("Drawing of right axis is not implemented"); return this.axisPosition === "bottom" ? this.getDrawableElementsForBottomAxis() : this.axisPosition === "top" ? this.getDrawableElementsForTopAxis() : []; }
}, ke = class extends Zt {
    static { a(this, "BandAxis"); }
    constructor(t, e, i, s, n) { super(t, s, n, e), this.categories = i, this.scale = pt().domain(this.categories).range(this.getRange()); }
    setRange(t) { super.setRange(t); }
    recalculateScale() { this.scale = pt().domain(this.categories).range(this.getRange()).paddingInner(1).paddingOuter(0).align(.5), dt.trace("BandAxis axis final categories, range: ", this.categories, this.getRange()); }
    getTickValues() { return this.categories; }
    getScaleValue(t) { return this.scale(t) ?? this.getRange()[0]; }
}, we = class extends Zt {
    static { a(this, "LinearAxis"); }
    constructor(t, e, i, s, n) { super(t, s, n, e), this.domain = i, this.scale = mt().domain(this.domain).range(this.getRange()); }
    getTickValues() { return this.scale.ticks(); }
    recalculateScale() { let t = [...this.domain]; this.axisPosition === "left" && t.reverse(), this.scale = mt().domain(t).range(this.getRange()); }
    getScaleValue(t) { return this.scale(t); }
};
function kt(t, e, i, s) { let n = new St(s); return rt(t) ? new ke(e, i, t.categories, t.title, n) : new we(e, i, [t.min, t.max], t.title, n); }
a(kt, "getAxis");
var Ce = class {
    constructor(t, e, i, s) { this.textDimensionCalculator = t, this.chartConfig = e, this.chartData = i, this.chartThemeConfig = s, this.boundingRect = { x: 0, y: 0, width: 0, height: 0 }, this.showChartTitle = !1; }
    static { a(this, "ChartTitle"); }
    setBoundingBoxXY(t) { this.boundingRect.x = t.x, this.boundingRect.y = t.y; }
    calculateSpace(t) { let e = this.textDimensionCalculator.getMaxDimension([this.chartData.title], this.chartConfig.titleFontSize), i = Math.max(e.width, t.width), s = e.height + 2 * this.chartConfig.titlePadding; return e.width <= i && e.height <= s && this.chartConfig.showTitle && this.chartData.title && (this.boundingRect.width = i, this.boundingRect.height = s, this.showChartTitle = !0), { width: this.boundingRect.width, height: this.boundingRect.height }; }
    getDrawableElements() { let t = []; return this.showChartTitle && t.push({ groupTexts: ["chart-title"], type: "text", data: [{ fontSize: this.chartConfig.titleFontSize, text: this.chartData.title, verticalPos: "middle", horizontalPos: "center", x: this.boundingRect.x + this.boundingRect.width / 2, y: this.boundingRect.y + this.boundingRect.height / 2, fill: this.chartThemeConfig.titleColor, rotation: 0 }] }), t; }
};
function Jt(t, e, i, s) { let n = new St(s); return new Ce(n, t, e, i); }
a(Jt, "getChartTitleComponent");
var Se = .75, Re = .5, _e = .35;
function wt(t) { return { fontSize: t, markerSize: t * Se, markerSpacing: t * _e, itemSpacing: t * Re }; }
a(wt, "getLegendLayout");
var Te = class {
    constructor(t, e, i, s) { this.textDimensionCalculator = t, this.chartConfig = e, this.chartData = i, this.chartThemeConfig = s, this.boundingRect = { x: 0, y: 0, width: 0, height: 0 }, this.visiblePlots = []; }
    static { a(this, "ChartLegend"); }
    setBoundingBoxXY(t) { this.boundingRect.x = t.x, this.boundingRect.y = t.y; }
    calculateSpace(t) { if (this.visiblePlots = this.chartConfig.showLegend ? this.chartData.plots.filter(p => p.title) : [], this.visiblePlots.length === 0)
        return this.boundingRect.width = 0, this.boundingRect.height = 0, { width: 0, height: 0 }; let { fontSize: e, markerSize: i, markerSpacing: s, itemSpacing: n } = wt(this.chartConfig.legendFontSize), u = this.textDimensionCalculator.getMaxDimension(this.visiblePlots.map(p => p.title), e), l = this.chartConfig.legendPadding * 2 + i + s + u.width, d = this.chartConfig.legendPadding * 2 + this.visiblePlots.length * e + (this.visiblePlots.length - 1) * n; return l <= t.width && d <= t.height ? (this.boundingRect.width = l, this.boundingRect.height = d) : (this.visiblePlots = [], this.boundingRect.width = 0, this.boundingRect.height = 0), { width: this.boundingRect.width, height: this.boundingRect.height }; }
    getDrawableElements() { if (this.visiblePlots.length === 0)
        return []; let { fontSize: t, markerSize: e, markerSpacing: i, itemSpacing: s } = wt(this.chartConfig.legendFontSize), n = t + s, u = this.boundingRect.x + this.chartConfig.legendPadding, l = this.boundingRect.y + this.chartConfig.legendPadding, d = [], p = []; for (let [S, R] of this.visiblePlots.entries())
        if (ot(R))
            d.push({ x: u, y: l + S * n, width: e, height: e, fill: R.fill, strokeFill: R.fill, strokeWidth: 0 });
        else {
            let T = l + S * n + e / 2;
            p.push({ path: `M ${u},${T} L ${u + e},${T}`, strokeFill: R.strokeFill, strokeWidth: R.strokeWidth });
        } return [{ groupTexts: ["legend", "markers"], type: "rect", data: d }, { groupTexts: ["legend", "markers"], type: "path", data: p }, { groupTexts: ["legend", "label"], type: "text", data: this.visiblePlots.map((S, R) => ({ text: S.title, x: u + e + i, y: l + R * n + e / 2, fill: this.chartThemeConfig.legendTextColor, fontSize: t, rotation: 0, verticalPos: "middle", horizontalPos: "left" })) }]; }
};
function te(t, e, i, s) { let n = new St(s); return new Te(n, t, e, i); }
a(te, "getChartLegendComponent");
var De = class {
    constructor(t, e, i, s, n) { this.plotData = t, this.xAxis = e, this.yAxis = i, this.orientation = s, this.plotIndex = n; }
    static { a(this, "LinePlot"); }
    getDrawableElement() { let t = this.plotData.data.map(s => [this.xAxis.getScaleValue(s[0]), this.yAxis.getScaleValue(s[1])]), e; if (this.orientation === "horizontal" ? e = bt().y(s => s[0]).x(s => s[1])(t) : e = bt().x(s => s[0]).y(s => s[1])(t), !e)
        return []; let i = [{ groupTexts: ["plot", `line-plot-${this.plotIndex}`], type: "path", data: [{ path: e, strokeFill: this.plotData.strokeFill, strokeWidth: this.plotData.strokeWidth }] }]; if (this.plotData.pointLabels && this.plotData.pointLabels.length > 0) {
        let u = [];
        for (let [l, [d, p]] of t.entries()) {
            let S = this.plotData.pointLabels[l];
            S && (this.orientation === "horizontal" ? u.push({ x: p + 10, y: d, text: S, fill: this.plotData.strokeFill, verticalPos: "middle", horizontalPos: "left", fontSize: 12, rotation: 0 }) : u.push({ x: d, y: p - 10, text: S, fill: this.plotData.strokeFill, verticalPos: "middle", horizontalPos: "center", fontSize: 12, rotation: 0 }));
        }
        u.length > 0 && i.push({ groupTexts: ["plot", `line-plot-${this.plotIndex}`, "labels"], type: "text", data: u });
    } return i; }
}, Pe = class {
    constructor(t, e, i, s, n, u) { this.barData = t, this.boundingRect = e, this.xAxis = i, this.yAxis = s, this.orientation = n, this.plotIndex = u; }
    static { a(this, "BarPlot"); }
    getDrawableElement() { let t = this.barData.data.map(n => [this.xAxis.getScaleValue(n[0]), this.yAxis.getScaleValue(n[1])]), i = Math.min(this.xAxis.getAxisOuterPadding() * 2, this.xAxis.getTickDistance()) * (1 - .05), s = i / 2; return this.orientation === "horizontal" ? [{ groupTexts: ["plot", `bar-plot-${this.plotIndex}`], type: "rect", data: t.map(n => ({ x: this.boundingRect.x, y: n[0] - s, height: i, width: n[1] - this.boundingRect.x, fill: this.barData.fill, strokeWidth: 0, strokeFill: this.barData.fill })) }] : [{ groupTexts: ["plot", `bar-plot-${this.plotIndex}`], type: "rect", data: t.map(n => ({ x: n[0] - s, y: n[1], width: i, height: this.boundingRect.y + this.boundingRect.height - n[1], fill: this.barData.fill, strokeWidth: 0, strokeFill: this.barData.fill })) }]; }
}, Le = class {
    constructor(t, e, i) { this.chartConfig = t, this.chartData = e, this.chartThemeConfig = i, this.boundingRect = { x: 0, y: 0, width: 0, height: 0 }; }
    static { a(this, "BasePlot"); }
    setAxes(t, e) { this.xAxis = t, this.yAxis = e; }
    setBoundingBoxXY(t) { this.boundingRect.x = t.x, this.boundingRect.y = t.y; }
    calculateSpace(t) { return this.boundingRect.width = t.width, this.boundingRect.height = t.height, { width: this.boundingRect.width, height: this.boundingRect.height }; }
    getDrawableElements() { if (!(this.xAxis && this.yAxis))
        throw Error("Axes must be passed to render Plots"); let t = []; for (let [e, i] of this.chartData.plots.entries())
        switch (i.type) {
            case "line":
                {
                    let s = new De(i, this.xAxis, this.yAxis, this.chartConfig.chartOrientation, e);
                    t.push(...s.getDrawableElement());
                }
                break;
            case "bar":
                {
                    let s = new Pe(i, this.boundingRect, this.xAxis, this.yAxis, this.chartConfig.chartOrientation, e);
                    t.push(...s.getDrawableElement());
                }
                break;
        } return t; }
};
function ee(t, e, i) { return new Le(t, e, i); }
a(ee, "getPlotComponent");
var ve = class {
    constructor(t, e, i, s) { this.chartConfig = t, this.chartData = e, this.componentStore = { title: Jt(t, e, i, s), plot: ee(t, e, i), legend: te(t, e, i, s), xAxis: kt(e.xAxis, t.xAxis, { titleColor: i.xAxisTitleColor, labelColor: i.xAxisLabelColor, tickColor: i.xAxisTickColor, axisLineColor: i.xAxisLineColor }, s), yAxis: kt(e.yAxis, t.yAxis, { titleColor: i.yAxisTitleColor, labelColor: i.yAxisLabelColor, tickColor: i.yAxisTickColor, axisLineColor: i.yAxisLineColor }, s) }; }
    static { a(this, "Orchestrator"); }
    calculateVerticalSpace() { let t = this.chartConfig.width, e = this.chartConfig.height, i = 0, s = 0, n = { width: 0, height: 0 }, u = Math.floor(t * this.chartConfig.plotReservedSpacePercent / 100), l = Math.floor(e * this.chartConfig.plotReservedSpacePercent / 100), d = this.componentStore.plot.calculateSpace({ width: u, height: l }); t -= d.width, e -= d.height, d = this.componentStore.title.calculateSpace({ width: this.chartConfig.width, height: e }), s = d.height, e -= d.height, this.componentStore.xAxis.setAxisPosition("bottom"), d = this.componentStore.xAxis.calculateSpace({ width: t, height: e }), e -= d.height, this.componentStore.yAxis.setAxisPosition("left"), d = this.componentStore.yAxis.calculateSpace({ width: t, height: e }), i = d.width, t -= d.width, n = this.componentStore.legend.calculateSpace({ width: t, height: l }), t -= n.width, t > 0 && (u += t, t = 0), e > 0 && (l += e, e = 0), this.componentStore.plot.calculateSpace({ width: u, height: l }), this.componentStore.plot.setBoundingBoxXY({ x: i, y: s }), this.componentStore.legend.setBoundingBoxXY({ x: i + u, y: s + Math.max((l - n.height) / 2, 0) }), this.componentStore.xAxis.setRange([i, i + u]), this.componentStore.xAxis.setBoundingBoxXY({ x: i, y: s + l }), this.componentStore.yAxis.setRange([s, s + l]), this.componentStore.yAxis.setBoundingBoxXY({ x: 0, y: s }), this.chartData.plots.some(p => ot(p)) && this.componentStore.xAxis.recalculateOuterPaddingToDrawBar(); }
    calculateHorizontalSpace() { let t = this.chartConfig.width, e = this.chartConfig.height, i = 0, s = 0, n = 0, u = { width: 0, height: 0 }, l = Math.floor(t * this.chartConfig.plotReservedSpacePercent / 100), d = Math.floor(e * this.chartConfig.plotReservedSpacePercent / 100), p = this.componentStore.plot.calculateSpace({ width: l, height: d }); t -= p.width, e -= p.height, p = this.componentStore.title.calculateSpace({ width: this.chartConfig.width, height: e }), i = p.height, e -= p.height, this.componentStore.xAxis.setAxisPosition("left"), p = this.componentStore.xAxis.calculateSpace({ width: t, height: e }), t -= p.width, s = p.width, this.componentStore.yAxis.setAxisPosition("top"), p = this.componentStore.yAxis.calculateSpace({ width: t, height: e }), e -= p.height, n = i + p.height, u = this.componentStore.legend.calculateSpace({ width: t, height: d }), t -= u.width, t > 0 && (l += t, t = 0), e > 0 && (d += e, e = 0), this.componentStore.plot.calculateSpace({ width: l, height: d }), this.componentStore.plot.setBoundingBoxXY({ x: s, y: n }), this.componentStore.legend.setBoundingBoxXY({ x: s + l, y: n + Math.max((d - u.height) / 2, 0) }), this.componentStore.yAxis.setRange([s, s + l]), this.componentStore.yAxis.setBoundingBoxXY({ x: s, y: i }), this.componentStore.xAxis.setRange([n, n + d]), this.componentStore.xAxis.setBoundingBoxXY({ x: 0, y: n }), this.chartData.plots.some(S => ot(S)) && this.componentStore.xAxis.recalculateOuterPaddingToDrawBar(); }
    calculateSpace() { this.chartConfig.chartOrientation === "horizontal" ? this.calculateHorizontalSpace() : this.calculateVerticalSpace(); }
    getDrawableElement() { this.calculateSpace(); let t = []; this.componentStore.plot.setAxes(this.componentStore.xAxis, this.componentStore.yAxis); for (let e of Object.values(this.componentStore))
        t.push(...e.getDrawableElements()); return t; }
}, Ee = class {
    static { a(this, "XYChartBuilder"); }
    static build(t, e, i, s) { return new ve(t, e, i, s).getDrawableElement(); }
}, J = 0, ie, tt = Tt(), et = _t(), m = Dt(), Ct = et.plotColorPalette.split(",").map(t => t.trim()), ht = !1, Rt = !1;
function _t() { let t = Vt(), e = nt(); return yt(t.xyChart, e.themeVariables.xyChart); }
a(_t, "getChartDefaultThemeConfig");
function Tt() { let t = nt(); return yt(Ft.xyChart, t.xyChart); }
a(Tt, "getChartDefaultConfig");
function Dt() { return { yAxis: { type: "linear", title: "", min: 1 / 0, max: -1 / 0 }, xAxis: { type: "band", title: "", categories: [] }, title: "", plots: [] }; }
a(Dt, "getChartDefaultData");
function j(t) { let e = nt(); return Wt(t.trim(), e); }
a(j, "textSanitizer");
function se(t) { ie = t; }
a(se, "setTmpSVGG");
function ae(t) { t === "horizontal" ? tt.chartOrientation = "horizontal" : tt.chartOrientation = "vertical"; }
a(ae, "setOrientation");
function ne(t) { m.xAxis.title = j(t.text); }
a(ne, "setXAxisTitle");
function Pt(t, e) { m.xAxis = { type: "linear", title: m.xAxis.title, min: t, max: e }, ht = !0; }
a(Pt, "setXAxisRangeData");
function oe(t) { m.xAxis = { type: "band", title: m.xAxis.title, categories: t.map(e => j(e.text)) }, ht = !0; }
a(oe, "setXAxisBand");
function re(t) { m.yAxis.title = j(t.text); }
a(re, "setYAxisTitle");
function he(t, e) { m.yAxis = { type: "linear", title: m.yAxis.title, min: t, max: e }, Rt = !0; }
a(he, "setYAxisRangeData");
function le(t) { let e = Math.min(...t), i = Math.max(...t), s = Z(m.yAxis) ? m.yAxis.min : 1 / 0, n = Z(m.yAxis) ? m.yAxis.max : -1 / 0; m.yAxis = { type: "linear", title: m.yAxis.title, min: Math.min(s, e), max: Math.max(n, i) }; }
a(le, "setYAxisRangeFromPlotData");
function Lt(t) { let e = []; if (t.length === 0)
    return e; if (!ht) {
    let i = Z(m.xAxis) ? m.xAxis.min : 1 / 0, s = Z(m.xAxis) ? m.xAxis.max : -1 / 0;
    Pt(Math.min(i, 1), Math.max(s, t.length));
} if (rt(m.xAxis) && t.length > m.xAxis.categories.length && (t = t.slice(0, m.xAxis.categories.length)), Rt || le(t), rt(m.xAxis) && (e = m.xAxis.categories.map((i, s) => [i, t[s]])), Z(m.xAxis)) {
    let i = m.xAxis.min, s = m.xAxis.max;
    if (t.length === 1)
        e = [[`${i}`, t[0]]];
    else {
        let n = (s - i) / (t.length - 1);
        e = t.map((u, l) => [`${i + l * n}`, u]);
    }
} return e; }
a(Lt, "transformDataWithoutCategory");
function vt(t) { return Ct[t === 0 ? 0 : t % Ct.length]; }
a(vt, "getPlotColorFromPalette");
function ce(t, e) { let i = e.map(l => l.value), s = e.map(l => l.label ? j(l.label) : ""), n = Lt(i), u = s.some(l => l !== ""); m.plots.push(Ot({ type: "line", title: j(t.text), strokeFill: vt(J), strokeWidth: 2, data: n }, u ? { pointLabels: s } : {})), J++; }
a(ce, "setLineData");
function ge(t, e) { let i = e.map(n => n.value), s = Lt(i); m.plots.push({ type: "bar", title: j(t.text), fill: vt(J), data: s }), J++; }
a(ge, "setBarData");
function ue() { if (m.plots.length === 0)
    throw Error("No Plot to render, please provide a plot with some data"); return m.title = ft(), Ee.build(tt, m, et, ie); }
a(ue, "getDrawableElem");
function xe() { return et; }
a(xe, "getChartThemeConfig");
function de() { return tt; }
a(de, "getChartConfig");
function fe() { return m; }
a(fe, "getXYChartData");
var Ie = a(function () { Nt(), J = 0, tt = Tt(), m = Dt(), et = _t(), Ct = et.plotColorPalette.split(",").map(t => t.trim()), ht = !1, Rt = !1; }, "clear"), Me = { getDrawableElem: ue, clear: Ie, setAccTitle: Yt, getAccTitle: Ht, setDiagramTitle: Gt, getDiagramTitle: ft, getAccDescription: Ut, setAccDescription: $t, setOrientation: ae, setXAxisTitle: ne, setXAxisRangeData: Pt, setXAxisBand: oe, setYAxisTitle: re, setYAxisRangeData: he, setLineData: ce, setBarData: ge, setTmpSVGG: se, getChartThemeConfig: xe, getChartConfig: de, getXYChartData: fe }, Be = a((t, e, i, s) => {
    let n = s.db, u = n.getChartThemeConfig(), l = n.getChartConfig(), d = n.getXYChartData().plots[0].data.map(b => b[1]);
    function p(b) { return b === "top" ? "text-before-edge" : "middle"; }
    a(p, "getDominantBaseLine");
    function S(b) { return b === "left" ? "start" : b === "right" ? "end" : "middle"; }
    a(S, "getTextAnchor");
    function R(b) { return `translate(${b.x}, ${b.y}) rotate(${b.rotation || 0})`; }
    a(R, "getTextTransformation"), dt.debug(`Rendering xychart chart
` + t);
    let T = qt(e), B = T.append("g").attr("class", "main"), W = B.append("rect").attr("width", l.width).attr("height", l.height).attr("class", "background");
    Xt(T, l.height, l.width, !0), T.attr("viewBox", `0 0 ${l.width} ${l.height}`), W.attr("fill", u.backgroundColor), n.setTmpSVGG(T.append("g").attr("class", "mermaid-tmp-group"));
    let X = n.getDrawableElem(), v = {};
    function V(b) { let E = B, c = ""; for (let [L] of b.entries()) {
        let I = B;
        L > 0 && v[c] && (I = v[c]), c += b[L], E = v[c], E || (E = v[c] = I.append("g").attr("class", b[L]));
    } return E; }
    a(V, "getGroup");
    for (let b of X) {
        if (b.data.length === 0)
            continue;
        let E = V(b.groupTexts);
        switch (b.type) {
            case "rect":
                if (E.selectAll("rect").data(b.data).enter().append("rect").attr("x", c => c.x).attr("y", c => c.y).attr("width", c => c.width).attr("height", c => c.height).attr("fill", c => c.fill).attr("stroke", c => c.strokeFill).attr("stroke-width", c => c.strokeWidth), l.showDataLabel) {
                    let c = l.showDataLabelOutsideBar;
                    if (l.chartOrientation === "horizontal") {
                        let L = function (y, F) { let { data: w, label: z } = y; return F * z.length * I <= w.width - A; };
                        var N = L;
                        a(L, "fitsHorizontally");
                        let I = .7, A = 10, $ = b.data.map((y, F) => ({ data: y, label: d[F].toString() })).filter(y => y.data.width > 0 && y.data.height > 0), D = $.map(y => { let { data: F } = y, w = F.height * .7; for (; !L(y, w) && w > 0;)
                            w -= 1; return w; }), Q = Math.floor(Math.min(...D)), C = a(y => c ? y.data.x + y.data.width + A : y.data.x + y.data.width - A, "determineLabelXPosition");
                        E.selectAll("text").data($).enter().append("text").attr("x", C).attr("y", y => y.data.y + y.data.height / 2).attr("text-anchor", c ? "start" : "end").attr("dominant-baseline", "middle").attr("fill", u.dataLabelColor).attr("font-size", `${Q}px`).text(y => y.label);
                    }
                    else {
                        let L = function (C, y, F) { let { data: w, label: z } = C, h = y * z.length * .7, g = w.x + w.width / 2, x = g - h / 2, k = g + h / 2, o = x >= w.x && k <= w.x + w.width, U = w.y + F + y <= w.y + w.height; return o && U; };
                        var Y = L;
                        a(L, "fitsInBar");
                        let I = 10, A = b.data.map((C, y) => ({ data: C, label: d[y].toString() })).filter(C => C.data.width > 0 && C.data.height > 0), $ = A.map(C => { let { data: y, label: F } = C, w = y.width / (F.length * .7); for (; !L(C, w, I) && w > 0;)
                            w -= 1; return w; }), D = Math.floor(Math.min(...$)), Q = a(C => c ? C.data.y - I : C.data.y + I, "determineLabelYPosition");
                        E.selectAll("text").data(A).enter().append("text").attr("x", C => C.data.x + C.data.width / 2).attr("y", Q).attr("text-anchor", "middle").attr("dominant-baseline", c ? "auto" : "hanging").attr("fill", u.dataLabelColor).attr("font-size", `${D}px`).text(C => C.label);
                    }
                }
                break;
            case "text":
                E.selectAll("text").data(b.data).enter().append("text").attr("x", 0).attr("y", 0).attr("fill", c => c.fill).attr("font-size", c => c.fontSize).attr("dominant-baseline", c => p(c.verticalPos)).attr("text-anchor", c => S(c.horizontalPos)).attr("transform", c => R(c)).text(c => c.text);
                break;
            case "path":
                E.selectAll("path").data(b.data).enter().append("path").attr("d", c => c.path).attr("fill", c => c.fill ? c.fill : "none").attr("stroke", c => c.strokeFill).attr("stroke-width", c => c.strokeWidth);
                break;
        }
    }
}, "draw"), ze = { draw: Be }, qe = { parser: Ae, db: Me, renderer: ze };
export { qe as diagram };
