import { a as e, b as r } from "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { e as ArchitectureModule, r as createArchitectureServices };
