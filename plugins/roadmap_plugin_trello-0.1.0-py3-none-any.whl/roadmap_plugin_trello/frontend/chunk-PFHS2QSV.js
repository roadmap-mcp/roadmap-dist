import { a as U } from "@nf-internal/chunk-JKFADCWD";
import { c as j, d as z, e as Q } from "@nf-internal/chunk-VEDGZ2C2";
import { a as O } from "@nf-internal/chunk-PRKFGJVH";
import { d as J, e as Y } from "@nf-internal/chunk-GP7LUXUQ";
import { d as q } from "@nf-internal/chunk-3SXY7Q5B";
import { _ as I, o as Z, y as X } from "@nf-internal/chunk-LEJRRF65";
import { b as L, h as E } from "@nf-internal/chunk-RZWXGGKD";
import { a as $ } from "@nf-internal/chunk-YUSHYV7C";
import { f as G } from "@nf-internal/chunk-OSQMNGTH";
var et = $((k, t) => G(null, null, function* () { let l = I(), { themeVariables: b, handDrawnSeed: d } = l, { clusterBkg: x, clusterBorder: m } = b, n = m, { labelStyles: C, nodeStyles: c, borderStyles: R, backgroundStyles: o } = J(t), h = k.insert("g").attr("class", "cluster swimlane " + (t.cssClasses || "")).attr("id", t.id).attr("data-id", t.id).attr("data-et", "cluster").attr("data-look", t.look), g = Z(l.flowchart.htmlLabels), a = t.direction === "LR", s = h.insert("g").attr("class", "cluster-label swimlane-label"), w = yield q(s, t.label, { style: t.labelStyle, useHtmlLabels: g, isNode: !0, width: t.width }), r = w.getBBox(); if (g) {
    let B = w.children[0], D = E(w);
    r = B.getBoundingClientRect(), D.attr("width", r.width), D.attr("height", r.height);
} let p = t.padding ?? 0, u = t.width <= r.width + p ? r.width + p : t.width; t.width <= r.width + p ? t.diff = (u - t.width) / 2 - p : t.diff = -p; let i = t.height, f = t.y - i / 2, T = t.y + i / 2, e = t.x - u / 2, v = t.swimlaneContentTop !== void 0 ? t.swimlaneContentTop : f + i / 3, y = a ? 4 : 0, N = r.height + 2 * y, S, M; if (a) {
    let B = Math.max(N, r.height + 2 * y), D = e + B, H = Math.max(0, u - B);
    if (t.look === "handDrawn") {
        let _ = O.svg(h), A = Y(t, { roughness: .7, fill: x, stroke: n, fillWeight: 3, seed: d }), P = Y(t, { roughness: .7, fill: "none", stroke: n, seed: d }), F = _.rectangle(e, f, B, i, A);
        S = h.insert(() => F, ":first-child");
        let K = _.rectangle(D, f, H, i, P);
        M = h.insert(() => K, ":first-child"), S.select("path:nth-child(2)").attr("style", R.join(";")), S.select("path").attr("style", o.join(";").replace("fill", "stroke"));
    }
    else
        S = h.insert("rect", ":first-child"), M = h.insert("rect", ":first-child"), S.attr("class", "swimlane-title").attr("style", c).attr("x", e).attr("y", f).attr("width", B).attr("height", i).attr("fill", x).attr("stroke", n), M.attr("class", "swimlane-body").attr("style", c).attr("x", D).attr("y", f).attr("width", H).attr("height", i).attr("fill", "none").attr("stroke", n);
    let V = e + B / 2, W = t.y;
    s.attr("transform", `translate(${V}, ${W}) rotate(-90) translate(${-r.width / 2}, ${-r.height / 2})`);
}
else {
    let B = Math.max(0, v - f), D = Math.min(N, B), H = f + D, V = Math.max(0, T - H), W = t.x - u / 2;
    if (t.look === "handDrawn") {
        let P = O.svg(h), F = Y(t, { roughness: .7, fill: x, stroke: n, fillWeight: 3, seed: d }), K = Y(t, { roughness: .7, fill: "none", stroke: n, seed: d }), rt = P.rectangle(W, f, u, D, F);
        S = h.insert(() => rt, ":first-child");
        let it = P.rectangle(W, H, u, V, K);
        M = h.insert(() => it, ":first-child"), S.select("path:nth-child(2)").attr("style", R.join(";")), S.select("path").attr("style", o.join(";").replace("fill", "stroke"));
    }
    else
        S = h.insert("rect", ":first-child"), M = h.insert("rect", ":first-child"), S.attr("class", "swimlane-title").attr("style", c).attr("x", W).attr("y", f).attr("width", u).attr("height", D).attr("fill", x).attr("stroke", n), M.attr("class", "swimlane-body").attr("style", c).attr("x", W).attr("y", H).attr("width", u).attr("height", V).attr("fill", "none").attr("stroke", n);
    let _ = t.x - r.width / 2, A = f + (D - r.height) / 2;
    s.attr("transform", `translate(${_}, ${A})`);
} if (L.trace("Swimlane data ", t, JSON.stringify(t)), C) {
    let B = s.select("span");
    B && B.attr("style", C);
} return t.offsetX = 0, t.width = u, t.height = i, t.offsetY = r.height - p / 2, t.intersect = function (B) { return j(t, B); }, { cluster: h, labelBBox: r }; }), "swimlane"), tt = $((k, t) => G(null, null, function* () { L.info("Creating subgraph rect for ", t.id, t); let l = I(), { themeVariables: b, handDrawnSeed: d } = l, { clusterBkg: x, clusterBorder: m } = b, { labelStyles: n, nodeStyles: C, borderStyles: c, backgroundStyles: R } = J(t), o = k.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.domId).attr("data-look", t.look), h = X(l), g = o.insert("g").attr("class", "cluster-label "), a; t.labelType === "markdown" ? a = yield q(g, t.label, { style: t.labelStyle, useHtmlLabels: h, isNode: !0, width: t.width }) : a = yield Q(g, t.label, t.labelStyle || "", !1, !0); let s = a.getBBox(); if (X(l)) {
    let e = a.children[0], v = E(a);
    s = e.getBoundingClientRect(), v.attr("width", s.width), v.attr("height", s.height);
} let w = t.width <= s.width + t.padding ? s.width + t.padding : t.width; t.width <= s.width + t.padding ? t.diff = (w - t.width) / 2 - t.padding : t.diff = -t.padding; let r = t.height, p = t.x - w / 2, u = t.y - r / 2; L.trace("Data ", t, JSON.stringify(t)); let i; if (t.look === "handDrawn") {
    let e = O.svg(o), v = Y(t, { roughness: .7, fill: x, stroke: m, fillWeight: 3, seed: d }), y = e.path(z(p, u, w, r, 0), v);
    i = o.insert(() => (L.debug("Rough node insert CXC", y), y), ":first-child"), i.select("path:nth-child(2)").attr("style", c.join(";")), i.select("path").attr("style", R.join(";").replace("fill", "stroke"));
}
else
    i = o.insert("rect", ":first-child"), i.attr("style", C).attr("rx", t.rx).attr("ry", t.ry).attr("x", p).attr("y", u).attr("width", w).attr("height", r); let { subGraphTitleTopMargin: f } = U(l); if (g.attr("transform", `translate(${t.x - s.width / 2}, ${t.y - t.height / 2 + f})`), n) {
    let e = g.select("span");
    e && e.attr("style", n);
} let T = i.node().getBBox(); return t.offsetX = 0, t.width = T.width, t.height = T.height, t.offsetY = s.height - t.padding / 2, t.intersect = function (e) { return j(t, e); }, { cluster: o, labelBBox: s }; }), "rect"), at = $((k, t) => { let l = k.insert("g").attr("class", "note-cluster").attr("id", t.domId), b = l.insert("rect", ":first-child"), d = 0 * t.padding, x = d / 2; b.attr("rx", t.rx).attr("ry", t.ry).attr("x", t.x - t.width / 2 - x).attr("y", t.y - t.height / 2 - x).attr("width", t.width + d).attr("height", t.height + d).attr("fill", "none"); let m = b.node().getBBox(); return t.width = m.width, t.height = m.height, t.intersect = function (n) { return j(t, n); }, { cluster: l, labelBBox: { width: 0, height: 0 } }; }, "noteGroup"), lt = $((k, t) => G(null, null, function* () { let l = I(), { themeVariables: b, handDrawnSeed: d } = l, { altBackground: x, compositeBackground: m, compositeTitleBackground: n, nodeBorder: C } = b, c = k.insert("g").attr("class", t.cssClasses).attr("id", t.domId).attr("data-id", t.id).attr("data-look", t.look), R = c.insert("g", ":first-child"), o = c.insert("g").attr("class", "cluster-label"), h = c.append("rect"), g = yield Q(o, t.label, t.labelStyle, void 0, !0), a = g.getBBox(); if (X(l)) {
    let y = g.children[0], N = E(g);
    a = y.getBoundingClientRect(), N.attr("width", a.width), N.attr("height", a.height);
} let s = 0 * t.padding, w = s / 2, r = (t.width <= a.width + t.padding ? a.width + t.padding : t.width) + s; t.width <= a.width + t.padding ? t.diff = (r - t.width) / 2 - t.padding : t.diff = -t.padding; let p = t.height + s, u = t.height + s - a.height - 6, i = t.x - r / 2, f = t.y - p / 2; t.width = r; let T = t.y - t.height / 2 - w + a.height + 2, e; if (t.look === "handDrawn") {
    let y = t.cssClasses.includes("statediagram-cluster-alt"), N = O.svg(c), S = t.rx || t.ry ? N.path(z(i, f, r, p, 10), { roughness: .7, fill: n, fillStyle: "solid", stroke: C, seed: d }) : N.rectangle(i, f, r, p, { seed: d });
    e = c.insert(() => S, ":first-child");
    let M = N.rectangle(i, T, r, u, { fill: y ? x : m, fillStyle: y ? "hachure" : "solid", stroke: C, seed: d });
    e = c.insert(() => S, ":first-child"), h = c.insert(() => M);
}
else
    e = R.insert("rect", ":first-child"), e.attr("class", "outer").attr("x", i).attr("y", f).attr("width", r).attr("height", p).attr("data-look", t.look), h.attr("class", "inner").attr("x", i).attr("y", T).attr("width", r).attr("height", u); o.attr("transform", `translate(${t.x - a.width / 2}, ${f + 1 - (X(l) ? 0 : 3)})`); let v = e.node().getBBox(); return t.height = v.height, t.offsetX = 0, t.offsetY = a.height - t.padding / 2, t.labelBBox = a, t.intersect = function (y) { return j(t, y); }, { cluster: c, labelBBox: a }; }), "roundedWithTitle"), ct = $((k, t) => G(null, null, function* () { L.info("Creating subgraph rect for ", t.id, t); let l = I(), { themeVariables: b, handDrawnSeed: d } = l, { clusterBkg: x, clusterBorder: m } = b, { labelStyles: n, nodeStyles: C, borderStyles: c, backgroundStyles: R } = J(t), o = k.insert("g").attr("class", "cluster " + t.cssClasses).attr("id", t.domId).attr("data-look", t.look), h = X(l), g = o.insert("g").attr("class", "cluster-label "), a = yield q(g, t.label, { style: t.labelStyle, useHtmlLabels: h, isNode: !0, width: t.width }), s = a.getBBox(); if (X(l)) {
    let e = a.children[0], v = E(a);
    s = e.getBoundingClientRect(), v.attr("width", s.width), v.attr("height", s.height);
} let w = t.width <= s.width + t.padding ? s.width + t.padding : t.width; t.width <= s.width + t.padding ? t.diff = (w - t.width) / 2 - t.padding : t.diff = -t.padding; let r = t.height, p = t.x - w / 2, u = t.y - r / 2; L.trace("Data ", t, JSON.stringify(t)); let i; if (t.look === "handDrawn") {
    let e = O.svg(o), v = Y(t, { roughness: .7, fill: x, stroke: m, fillWeight: 4, seed: d }), y = e.path(z(p, u, w, r, t.rx), v);
    i = o.insert(() => (L.debug("Rough node insert CXC", y), y), ":first-child"), i.select("path:nth-child(2)").attr("style", c.join(";")), i.select("path").attr("style", R.join(";").replace("fill", "stroke"));
}
else
    i = o.insert("rect", ":first-child"), i.attr("style", C).attr("rx", t.rx).attr("ry", t.ry).attr("x", p).attr("y", u).attr("width", w).attr("height", r); let { subGraphTitleTopMargin: f } = U(l); if (g.attr("transform", `translate(${t.x - s.width / 2}, ${t.y - t.height / 2 + f})`), n) {
    let e = g.select("span");
    e && e.attr("style", n);
} let T = i.node().getBBox(); return t.offsetX = 0, t.width = T.width, t.height = T.height, t.offsetY = s.height - t.padding / 2, t.intersect = function (e) { return j(t, e); }, { cluster: o, labelBBox: s }; }), "kanbanSection"), ht = $((k, t) => { let l = I(), { themeVariables: b, handDrawnSeed: d } = l, { nodeBorder: x } = b, m = k.insert("g").attr("class", t.cssClasses).attr("id", t.domId).attr("data-look", t.look), n = m.insert("g", ":first-child"), C = 0 * t.padding, c = t.width + C; t.diff = -t.padding; let R = t.height + C, o = t.x - c / 2, h = t.y - R / 2; t.width = c; let g; if (t.look === "handDrawn") {
    let w = O.svg(m).rectangle(o, h, c, R, { fill: "lightgrey", roughness: .5, strokeLineDash: [5], stroke: x, seed: d });
    g = m.insert(() => w, ":first-child");
}
else {
    g = n.insert("rect", ":first-child");
    let s = "outer";
    t.look, s = "divider", g.attr("class", s).attr("x", o).attr("y", h).attr("width", c).attr("height", R).attr("data-look", t.look);
} let a = g.node().getBBox(); return t.height = a.height, t.offsetX = 0, t.offsetY = 0, t.intersect = function (s) { return j(t, s); }, { cluster: m, labelBBox: {} }; }, "divider"), nt = tt, ot = { rect: tt, squareRect: nt, roundedWithTitle: lt, noteGroup: at, divider: ht, kanbanSection: ct, swimlane: et }, st = new Map, kt = $((k, t) => G(null, null, function* () { let l = t.shape || "rect", b = yield ot[l](k, t); return st.set(t.id, b), b; }), "insertCluster"), vt = $(() => { st = new Map; }, "clear");
export { kt as a, vt as b };
