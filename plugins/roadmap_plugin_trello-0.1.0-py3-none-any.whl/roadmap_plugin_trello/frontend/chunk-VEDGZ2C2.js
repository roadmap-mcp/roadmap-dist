import { a as v } from "@nf-internal/chunk-PRKFGJVH";
import { a as aa, b as Bt, d as W, e as I } from "@nf-internal/chunk-GP7LUXUQ";
import { b as Rt, d as mt } from "@nf-internal/chunk-3SXY7Q5B";
import { d as Ct } from "@nf-internal/chunk-ZBOYDPPL";
import { k as At, n as sa, r as kt, t as et } from "@nf-internal/chunk-FDRUJGNH";
import { H as It, J as Et, K as ta, _ as Q, ba as Tt, k as Qt, o as bt, u as vt, y as St } from "@nf-internal/chunk-LEJRRF65";
import { b as U, h as J } from "@nf-internal/chunk-RZWXGGKD";
import { a as $ } from "@nf-internal/chunk-YUSHYV7C";
import { a as it, b as nt, f as B } from "@nf-internal/chunk-OSQMNGTH";
var Fs = 1, js = 3;
function zt(h) { return B(this, null, function* () { let t = h.getElementsByTagName("img"); if (!t || t.length === 0)
    return; let i = !Vt(h); yield Promise.all([...t].map(g => new Promise(y => { function c() { if (g.style.display = "flex", g.style.flexDirection = "column", i) {
    let m = Q().fontSize ? Q().fontSize : window.getComputedStyle(document.body).fontSize, o = 5, [n = Qt.fontSize] = sa(m), r = n * o + "px";
    g.style.minWidth = r, g.style.maxWidth = r;
}
else
    g.style.width = "100%"; y(g); } $(c, "setupImage"), setTimeout(() => { g.complete && c(); }), g.addEventListener("error", c), g.addEventListener("load", c); }))); }); }
$(zt, "configureLabelImages");
function Vt(h) { return h.nodeType === js ? h.textContent?.trim() !== "" : h.nodeType !== Fs || h.tagName.toLowerCase() === "img" ? !1 : [...h.childNodes].some(Vt); }
$(Vt, "hasTextBesidesImages");
var ea = 3, Gs = 32, qs = $((h, t, i) => B(null, null, function* () { let g = Q(), y = h.insert("g").attr("class", i ?? "node default").attr("id", t.domId || t.id), c = y.insert("g").attr("class", "label").attr("style", et(t.labelStyle)), o = [{ text: typeof t.label == "string" ? t.label : t.label?.[0] ?? "", cssClass: "c4-name" }, { text: t.stereotype, cssClass: "c4-type" }, ...(t.description ?? []).map(p => ({ text: p, cssClass: "c4-descr" }))].filter(p => p.text), n = t.width ? Math.max(t.width - 2 * (t.padding ?? 0), Gs) : Q().flowchart?.wrappingWidth ?? 200, s = g.c4?.wrap ?? !0 ? n : Number.POSITIVE_INFINITY, a = yield Promise.all(o.map(p => B(null, null, function* () { let x = c.append("g").attr("class", p.cssClass), w = yield mt(x, It(kt(p.text ?? ""), g), { useHtmlLabels: !1, markdown: !1, isNode: !0, width: s, style: t.labelStyle }, g); return J(w).selectAll("tspan.text-outer-tspan").attr("text-anchor", "middle"), J(w).selectAll("tspan.text-inner-tspan").attr("font-weight", null).attr("font-style", null), { el: x, box: x.node().getBBox() }; }))), l = Math.max(...a.map(({ box: p }) => p.width), 0), e = 0; for (let { el: p, box: x } of a)
    p.attr("transform", `translate(${l / 2 - x.x - x.width / 2}, ${e - x.y})`), e += x.height + ea; let u = a.length > 0 ? e - ea : 0; c.insert("rect", ":first-child"), c.attr("transform", `translate(${-l / 2}, ${-u / 2})`); let f = c.node().getBBox(), d = (t.padding ?? 0) / 2; return { shapeSvg: y, bbox: f, halfPadding: d, label: c }; }), "c4LabelHelper"), X = $((h, t, i) => B(null, null, function* () { if (t.stereotype !== void 0)
    return qs(h, t, i); let g, y = t.useHtmlLabels || bt(Q()?.htmlLabels); i ? g = i : g = "node default"; let c = h.insert("g").attr("class", g).attr("id", t.domId || t.id), m = c.insert("g").attr("class", "label").attr("style", et(t.labelStyle)), o; t.label === void 0 ? o = "" : o = typeof t.label == "string" ? t.label : t.label[0]; let n = !!t.icon || !!t.img, r = t.labelType === "markdown", s = yield mt(m, It(kt(o), Q()), { useHtmlLabels: y, width: t.width || t.wrappingWidth || Q().flowchart?.wrappingWidth, classes: r ? "markdown-node-label" : "", style: t.labelStyle, addSvgBackground: n, markdown: r }, Q()), a = (t?.padding ?? 0) / 2, l; if (y) {
    let e = s.children[0], u = J(s);
    yield zt(e), l = yield Rt.measure(() => e.getBoundingClientRect()), u.attr("width", l.width), u.attr("height", l.height);
}
else
    l = yield Rt.measure(() => s.getBBox()); return y ? m.attr("transform", "translate(" + -l.width / 2 + ", " + -l.height / 2 + ")") : m.attr("transform", "translate(0, " + -l.height / 2 + ")"), t.centerLabel && m.attr("transform", "translate(" + -l.width / 2 + ", " + -l.height / 2 + ")"), m.insert("rect", ":first-child"), { shapeSvg: c, bbox: l, halfPadding: a, label: m }; }), "labelHelper"), _t = $((h, t, i) => B(null, null, function* () { let g = i.useHtmlLabels ?? St(Q()), y = h.insert("g").attr("class", "label").attr("style", i.labelStyle || ""), c = yield mt(y, It(kt(t), Q()), { useHtmlLabels: g, width: i.width || Q()?.flowchart?.wrappingWidth, style: i.labelStyle, addSvgBackground: !!i.icon || !!i.img }), m = i.padding / 2, o; if (St(Q())) {
    let n = c.children[0], r = J(c);
    o = yield Rt.measure(() => n.getBoundingClientRect()), r.attr("width", o.width), r.attr("height", o.height);
}
else
    o = yield Rt.measure(() => c.getBBox()); return g ? y.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")") : y.attr("transform", "translate(0, " + -o.height / 2 + ")"), i.centerLabel && y.attr("transform", "translate(" + -o.width / 2 + ", " + -o.height / 2 + ")"), y.insert("rect", ":first-child"), { shapeSvg: h, bbox: o, halfPadding: m, label: y }; }), "insertLabel"), R = $((h, t, i) => { if (i) {
    h.width = i.width, h.height = i.height;
    return;
} let g = t.node().getBBox(); h.width = g.width, h.height = g.height; }, "updateNodeBounds"), Y = $((h, t) => (h.look === "handDrawn" ? "rough-node" : "node") + " " + h.cssClasses + " " + (t || ""), "getNodeClasses");
function V(h) { let t = h.map((i, g) => `${g === 0 ? "M" : "L"}${i.x},${i.y}`); return t.push("Z"), t.join(" "); }
$(V, "createPathFromPoints");
function xt(h, t, i, g, y, c) { let m = [], n = i - h, r = g - t, s = n / c, a = 2 * Math.PI / s, l = t + r / 2; for (let e = 0; e <= 50; e++) {
    let u = e / 50, f = h + u * n, d = l + y * Math.sin(a * (f - h));
    m.push({ x: f, y: d });
} return m; }
$(xt, "generateFullSineWavePoints");
function ht(h, t, i, g, y, c) { let m = [], o = y * Math.PI / 180, s = (c * Math.PI / 180 - o) / (g - 1); for (let a = 0; a < g; a++) {
    let l = o + a * s, e = h + i * Math.cos(l), u = t + i * Math.sin(l);
    m.push({ x: -e, y: -u });
} return m; }
$(ht, "generateCirclePoints");
function jt(h) { let t = Array.from(h.childNodes).filter(n => n.tagName === "path"), i = document.createElementNS("http://www.w3.org/2000/svg", "path"), g = t.map(n => n.getAttribute("d")).filter(n => n !== null).join(" "); i.setAttribute("d", g); let y = t.find(n => n.getAttribute("fill") !== "none"), c = t.find(n => n.getAttribute("stroke") !== "none"), m = $((n, r) => n?.getAttribute(r) ?? void 0, "getAttr"); if (y) {
    let n = { fill: m(y, "fill"), "fill-opacity": m(y, "fill-opacity") ?? "1" };
    Object.entries(n).forEach(([r, s]) => { s && i.setAttribute(r, s); });
} if (c) {
    let n = { stroke: m(c, "stroke"), "stroke-width": m(c, "stroke-width") ?? "1", "stroke-opacity": m(c, "stroke-opacity") ?? "1" };
    Object.entries(n).forEach(([r, s]) => { s && i.setAttribute(r, s); });
} let o = document.createElementNS("http://www.w3.org/2000/svg", "g"); return o.appendChild(i), o; }
$(jt, "mergePaths");
var zs = $((h, t) => { var i = h.x, g = h.y, y = t.x - i, c = t.y - g, m = h.width / 2, o = h.height / 2, n, r; return Math.abs(c) * m > Math.abs(y) * o ? (c < 0 && (o = -o), n = c === 0 ? 0 : o * y / c, r = o) : (y < 0 && (m = -m), n = m, r = y === 0 ? 0 : m * c / y), { x: i + n, y: g + r }; }, "intersectRect"), Vs = zs, ut = $((h, t, i, g, y) => ["M", h + y, t, "H", h + i - y, "A", y, y, 0, 0, 1, h + i, t + y, "V", t + g - y, "A", y, y, 0, 0, 1, h + i - y, t + g, "H", h + y, "A", y, y, 0, 0, 1, h, t + g - y, "V", t + y, "A", y, y, 0, 0, 1, h + y, t, "Z"].join(" "), "createRoundedRectPathD"), Zs = $((h, t, i, g = !1, y = !1) => B(null, null, function* () { let c = t || ""; typeof c == "object" && (c = c[0]); let m = Q(), o = St(m); return yield mt(h, c, { style: i, isTitle: g, useHtmlLabels: o, markdown: !1, isNode: y, width: Number.POSITIVE_INFINITY }, m); }), "createLabel"), ra = Zs;
function ma(h, t) { return h.intersect(t); }
$(ma, "intersectNode");
var Js = ma;
function xa(h, t, i, g) { var y = h.x, c = h.y, m = y - g.x, o = c - g.y, n = Math.sqrt(t * t * o * o + i * i * m * m), r = Math.abs(t * i * m / n); g.x < y && (r = -r); var s = Math.abs(t * i * o / n); return g.y < c && (s = -s), { x: y + r, y: c + s }; }
$(xa, "intersectEllipse");
var wa = xa;
function ba(h, t, i) { return wa(h, t, t, i); }
$(ba, "intersectCircle");
var Ks = ba;
function Sa(h, t, i, g) { {
    let y = t.y - h.y, c = h.x - t.x, m = t.x * h.y - h.x * t.y, o = y * i.x + c * i.y + m, n = y * g.x + c * g.y + m, r = 1e-6;
    if (o !== 0 && n !== 0 && Gt(o, n))
        return;
    let s = g.y - i.y, a = i.x - g.x, l = g.x * i.y - i.x * g.y, e = s * h.x + a * h.y + l, u = s * t.x + a * t.y + l;
    if (Math.abs(e) < r && Math.abs(u) < r && Gt(e, u))
        return;
    let f = y * a - s * c;
    if (f === 0)
        return;
    let d = Math.abs(f / 2), p = c * l - a * m, x = p < 0 ? (p - d) / f : (p + d) / f;
    p = s * m - y * l;
    let w = p < 0 ? (p - d) / f : (p + d) / f;
    return { x, y: w };
} }
$(Sa, "intersectLine");
function Gt(h, t) { return h * t > 0; }
$(Gt, "sameSign");
var Us = Sa;
function $a(h, t, i) { let g = h.x, y = h.y, c = [], m = Number.POSITIVE_INFINITY, o = Number.POSITIVE_INFINITY; typeof t.forEach == "function" ? t.forEach(function (s) { m = Math.min(m, s.x), o = Math.min(o, s.y); }) : (m = Math.min(m, t.x), o = Math.min(o, t.y)); let n = g - h.width / 2 - m, r = y - h.height / 2 - o; for (let s = 0; s < t.length; s++) {
    let a = t[s], l = t[s < t.length - 1 ? s + 1 : 0], e = Us(h, i, { x: n + a.x, y: r + a.y }, { x: n + l.x, y: r + l.y });
    e && c.push(e);
} return c.length ? (c.length > 1 && c.sort(function (s, a) { let l = s.x - i.x, e = s.y - i.y, u = Math.sqrt(l * l + e * e), f = a.x - i.x, d = a.y - i.y, p = Math.sqrt(f * f + d * d); return u < p ? -1 : u === p ? 0 : 1; }), c[0]) : h; }
$($a, "intersectPolygon");
var Qs = $a, N = { node: Js, circle: Ks, ellipse: wa, polygon: Qs, rect: Vs };
function va(h, t) { let { labelStyles: i } = W(t); t.labelStyle = i; let g = Y(t), y = g; g || (y = "anchor"); let c = h.insert("g").attr("class", y).attr("id", t.domId || t.id), m = 1, { cssStyles: o } = t, n = v.svg(c), r = I(t, { fill: "black", stroke: "none", fillStyle: "solid" }); t.look !== "handDrawn" && (r.roughness = 0); let s = n.circle(0, 0, m * 2, r), a = c.insert(() => s, ":first-child"); return a.attr("class", "anchor").attr("style", et(o)), R(t, a), t.intersect = function (l) { return U.info("Circle intersect", t, m, l), N.circle(t, m, l); }, c; }
$(va, "anchor");
function qt(h, t, i, g, y, c, m) { let n = (h + i) / 2, r = (t + g) / 2, s = Math.atan2(g - t, i - h), a = (i - h) / 2, l = (g - t) / 2, e = a / y, u = l / c, f = Math.sqrt(e ** 2 + u ** 2); if (f > 1)
    throw new Error("The given radii are too small to create an arc between the points."); let d = Math.sqrt(1 - f ** 2), p = n + d * c * Math.sin(s) * (m ? -1 : 1), x = r - d * y * Math.cos(s) * (m ? -1 : 1), w = Math.atan2((t - x) / c, (h - p) / y), S = Math.atan2((g - x) / c, (i - p) / y) - w; m && S < 0 && (S += 2 * Math.PI), !m && S > 0 && (S -= 2 * Math.PI); let k = []; for (let M = 0; M < 20; M++) {
    let P = M / 19, A = w + P * S, D = p + y * Math.cos(A), H = x + c * Math.sin(A);
    k.push({ x: D, y: H });
} return k; }
$(qt, "generateArcPoints");
function ka(h, t, i) { let [g, y] = [t, i].sort((c, m) => m - c); return y * (1 - Math.sqrt(1 - (h / g / 2) ** 2)); }
$(ka, "calculateArcSagitta");
function Pa(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y, o = $(A => A + m, "calcTotalHeight"), n = $(A => { let D = A / 2; return [D / (2.5 + A / 50), D]; }, "calcEllipseRadius"), { shapeSvg: r, bbox: s } = yield X(h, t, Y(t)), a = o(t?.height ? t?.height : s.height), [l, e] = n(a), u = ka(a, l, e), d = (t?.width ? t?.width : s.width) + c * 2 + u - u, p = a, { cssStyles: x } = t, w = [{ x: d / 2, y: -p / 2 }, { x: -d / 2, y: -p / 2 }, ...qt(-d / 2, -p / 2, -d / 2, p / 2, l, e, !1), { x: d / 2, y: p / 2 }, ...qt(d / 2, p / 2, d / 2, -p / 2, l, e, !0)], b = v.svg(r), S = I(t, {}); t.look !== "handDrawn" && (S.roughness = 0, S.fillStyle = "solid"); let k = V(w), M = b.path(k, S), P = r.insert(() => M, ":first-child"); return P.attr("class", "basic label-container outer-path"), x && t.look !== "handDrawn" && P.selectAll("path").attr("style", x), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), P.attr("transform", `translate(${l / 2}, 0)`), R(t, P), t.intersect = function (A) { return N.polygon(t, w, A); }, r; }); }
$(Pa, "bowTieRect");
function Ma(g, y, c) { return B(this, arguments, function* (h, t, { config: { themeVariables: i } }) { let { labelStyles: m, nodeStyles: o } = W(t); t.labelStyle = m; let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = i?.nodeBorder ?? i?.lineColor ?? "currentColor", l = t.padding ?? 12, e = Math.max(r.width + l * 2, t.width ?? 0, 80), u = Math.max(Math.min(e * .08, 12), 5), f = Math.max(r.height + l * 2 + u, t.height ?? 0), d = -f / 2 + u, p = f / 2, x = e * .72, w = [`M${-e / 2},${d}`, `L${-x / 2},${p}`, `A${x / 2},${u} 0 0 0 ${x / 2},${p}`, `L${e / 2},${d}`, `A${e / 2},${u} 0 0 0 ${-e / 2},${d}`, "Z"].join(" "), { cssStyles: b } = t, S = n.insert("g", ":first-child").attr("class", "basic label-container"); if (t.look === "handDrawn") {
    let H = v.svg(n).path(w, I(t, {}));
    S.node()?.appendChild(H), b && S.attr("style", b);
}
else
    S.append("path").attr("d", w).attr("style", o); S.append("ellipse").attr("cx", 0).attr("cy", d).attr("rx", e / 2).attr("ry", u).attr("style", `fill:none;stroke:${a};stroke-width:1px`), R(t, S); let k = d + (p - d) / 2; s.attr("transform", `translate(${-(r.width / 2) - (r.x - (r.left ?? 0))}, ${k - r.height / 2 - (r.y - (r.top ?? 0))})`); let M = 12, P = $((D, H, z) => Array.from({ length: M + 1 }, (G, E) => { let L = Math.PI - E * Math.PI / M; return { x: D * Math.cos(L), y: H + z * u * Math.sin(L) }; }), "arc"), A = [...P(e / 2, d, -1), ...P(x / 2, p, 1).reverse()]; return t.intersect = function (D) { return N.polygon(t, A, D); }, n; }); }
$(Ma, "bucket");
var Yt = 20, Xt = 8, te = 80, Ot = 8;
function Da(h, t) { return B(this, null, function* () { let { themeVariables: i } = Q(), g = i.clusterBkg, y = i.clusterBorder, { nodeStyles: c } = W(t), { shapeSvg: m, bbox: o } = yield X(h, t, Y(t)), n = t.padding ?? 8, r = o.height, s = Math.max(o.width + n * 2, te, t?.width ?? 0), a = Math.max(r + Xt + Yt + n * 2, t?.height ?? 0), l = -s / 2, e = -a / 2, u = -(Xt + Yt) / 2, f = m.select(".label"); f && (t.useHtmlLabels ?? St(Q()) ? f.attr("transform", `translate(${-o.width / 2}, ${-o.height / 2 + u})`) : f.attr("transform", `translate(0, ${-o.height / 2 + u})`)); let d; if (t.look === "handDrawn") {
    let S = v.svg(m), k = I(t, { fill: g, stroke: y, fillStyle: "solid" }), M = S.path(ut(l, e, s, a, Ot), k);
    d = m.insert(() => M, ":first-child"), d.attr("class", "basic label-container collapsed-group").attr("style", et(t.cssStyles));
}
else
    d = m.insert("rect", ":first-child"), d.attr("class", "basic label-container collapsed-group").attr("style", c).attr("rx", Ot).attr("ry", Ot).attr("x", l).attr("y", e).attr("width", s).attr("height", a).attr("fill", g).attr("stroke", y); let p = e + n + r + Xt; m.append("line").attr("class", "collapsed-separator").attr("x1", l + 8).attr("y1", p).attr("x2", l + s - 8).attr("y2", p).attr("stroke", y).attr("stroke-dasharray", "3, 3"); let x = p + Yt / 2, w = 2.5, b = 10; for (let S = -1; S <= 1; S++)
    m.append("circle").attr("class", "collapsed-indicator").attr("cx", S * b).attr("cy", x).attr("r", w).attr("fill", y); return R(t, d), t.calcIntersect = function (S, k) { return N.rect(S, k); }, t.intersect = function (S) { return N.rect(t, S); }, m; }); }
$(Da, "collapsedGroup");
function gt(h, t, i, g) { return h.insert("polygon", ":first-child").attr("points", g.map(function (y) { return y.x + "," + y.y; }).join(" ")).attr("class", "label-container").attr("transform", "translate(" + -t / 2 + "," + i / 2 + ")"); }
$(gt, "insertPolygonShape");
var ae = ["right", "left", "up", "down"], Zt = "point", se = $(h => { let t = new Set; for (let i of h)
    switch (i) {
        case "x":
            t.add("right"), t.add("left");
            break;
        case "y":
            t.add("up"), t.add("down");
            break;
        default:
            t.add(i);
            break;
    } return t; }, "expandAndDeduplicateDirections"), ee = $(h => ae.filter(t => h.has(t)).join("|") || Zt, "getDirectionKey"), ia = { "right|left|up|down": $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: 0, y: 0 }, { x: t, y: 0 }, { x: g / 2, y: 2 * i }, { x: g - t, y: 0 }, { x: g, y: 0 }, { x: g, y: -h / 3 }, { x: g + 2 * i, y: -h / 2 }, { x: g, y: -2 * h / 3 }, { x: g, y: -h }, { x: g - t, y: -h }, { x: g / 2, y: -h - 2 * i }, { x: t, y: -h }, { x: 0, y: -h }, { x: 0, y: -2 * h / 3 }, { x: -2 * i, y: -h / 2 }, { x: 0, y: -h / 3 }], "right|left|up|down"), "right|left|up": $(({ height: h, midpoint: t, width: i }) => [{ x: t, y: 0 }, { x: i - t, y: 0 }, { x: i, y: -h / 2 }, { x: i - t, y: -h }, { x: t, y: -h }, { x: 0, y: -h / 2 }], "right|left|up"), "right|left|down": $(({ height: h, midpoint: t, width: i }) => [{ x: 0, y: 0 }, { x: t, y: -h }, { x: i - t, y: -h }, { x: i, y: 0 }], "right|left|down"), "right|up|down": $(({ height: h, midpoint: t, width: i }) => [{ x: 0, y: 0 }, { x: i, y: -t }, { x: i, y: -h + t }, { x: 0, y: -h }], "right|up|down"), "left|up|down": $(({ height: h, midpoint: t, width: i }) => [{ x: i, y: 0 }, { x: 0, y: -t }, { x: 0, y: -h + t }, { x: i, y: -h }], "left|up|down"), "right|left": $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: t, y: 0 }, { x: t, y: -i }, { x: g - t, y: -i }, { x: g - t, y: 0 }, { x: g, y: -h / 2 }, { x: g - t, y: -h }, { x: g - t, y: -h + i }, { x: t, y: -h + i }, { x: t, y: -h }, { x: 0, y: -h / 2 }], "right|left"), "up|down": $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: g / 2, y: 0 }, { x: 0, y: -i }, { x: t, y: -i }, { x: t, y: -h + i }, { x: 0, y: -h + i }, { x: g / 2, y: -h }, { x: g, y: -h + i }, { x: g - t, y: -h + i }, { x: g - t, y: -i }, { x: g, y: -i }], "up|down"), "right|up": $(({ height: h, midpoint: t, width: i }) => [{ x: 0, y: 0 }, { x: i, y: -t }, { x: 0, y: -h }], "right|up"), "right|down": $(({ height: h, width: t }) => [{ x: 0, y: 0 }, { x: t, y: 0 }, { x: 0, y: -h }], "right|down"), "left|up": $(({ height: h, midpoint: t, width: i }) => [{ x: i, y: 0 }, { x: 0, y: -t }, { x: i, y: -h }], "left|up"), "left|down": $(({ height: h, width: t }) => [{ x: t, y: 0 }, { x: 0, y: 0 }, { x: t, y: -h }], "left|down"), right: $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: t, y: -i }, { x: t, y: -i }, { x: g - t, y: -i }, { x: g - t, y: 0 }, { x: g, y: -h / 2 }, { x: g - t, y: -h }, { x: g - t, y: -h + i }, { x: t, y: -h + i }, { x: t, y: -h + i }], "right"), left: $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: t, y: 0 }, { x: t, y: -i }, { x: g - t, y: -i }, { x: g - t, y: -h + i }, { x: t, y: -h + i }, { x: t, y: -h }, { x: 0, y: -h / 2 }], "left"), up: $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: t, y: -i }, { x: t, y: -h + i }, { x: 0, y: -h + i }, { x: g / 2, y: -h }, { x: g, y: -h + i }, { x: g - t, y: -h + i }, { x: g - t, y: -i }], "up"), down: $(({ height: h, midpoint: t, padding: i, width: g }) => [{ x: g / 2, y: 0 }, { x: 0, y: -i }, { x: t, y: -i }, { x: t, y: -h + i }, { x: g - t, y: -h + i }, { x: g - t, y: -i }, { x: g, y: -i }], "down"), [Zt]: () => [{ x: 0, y: 0 }] }, re = $((h, t, i, g) => { let y = se(h), c = (i.padding ?? 0) / 2, m = t.height + 4 * c, o = m / 2, n = g ?? t.width + 2 * o + 2 * c, r = ee(y); return (ia[r] ?? ia[Zt])({ height: m, midpoint: o, padding: c, width: n }); }, "getArrowPoints");
function Na(h, t) { return B(this, null, function* () { let i = t, { shapeSvg: g, bbox: y } = yield X(h, i, Y(i)), c = i.padding ?? 0, m = y.height + 2 * c, o = m / 2, n = y.width + 2 * o + c, r = i.width ?? 0, a = i.positioned && (i.widthInColumns ?? 1) > 1 && r > n ? r : n, l = re(i.directions ?? [], y, i, a), e = gt(g, a, m, l); return e.attr("style", i.style ?? null), R(i, e), i.intersect = function (u) { return N.polygon(i, l, u); }, g; }); }
$(Na, "block_arrow");
function Ba(g, y, c) { return B(this, arguments, function* (h, t, { config: { themeVariables: i } }) { let { labelStyles: m, nodeStyles: o } = W(t); t.labelStyle = m; let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = i?.nodeBorder ?? i?.lineColor ?? "currentColor", l = t.padding ?? 12, e = 18, u = 12, f = Math.max(r.width + l * 2, t.width ?? 0, 90), d = Math.max(r.height + l * 2 + e, t.height ?? 0), p = -d / 2, { cssStyles: x } = t, w = n.insert("g", ":first-child").attr("class", "basic label-container"); if (t.look === "handDrawn") {
    let k = v.svg(n).path(ut(-f / 2, p, f, d, u), I(t, {}));
    w.node()?.appendChild(k), x && w.attr("style", x);
}
else
    w.append("rect").attr("x", -f / 2).attr("y", p).attr("width", f).attr("height", d).attr("rx", u).attr("ry", u).attr("style", o); w.append("line").attr("x1", -f / 2).attr("y1", p + e).attr("x2", f / 2).attr("y2", p + e).attr("style", `stroke:${a};stroke-width:1px`); for (let S = 0; S < 3; S++)
    w.append("circle").attr("cx", -f / 2 + 12 + S * 9).attr("cy", p + e / 2).attr("r", 2.5).attr("style", `fill:${a};stroke:none`); w.append("rect").attr("class", "browser-address-bar").attr("x", -f / 2 + 44).attr("y", p + 4).attr("width", Math.max(f - 56, 10)).attr("height", e - 8).attr("rx", 3).attr("ry", 3).attr("style", `fill:none;stroke:${a};stroke-width:1px;opacity:0.6`), R(t, w); let b = p + e + (d - e) / 2; return s.attr("transform", `translate(${-(r.width / 2) - (r.x - (r.left ?? 0))}, ${b - r.height / 2 - (r.y - (r.top ?? 0))})`), t.intersect = function (S) { return N.rect(t, S); }, n; }); }
$(Ba, "browser");
var Lt = 12;
function Ca(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 28 : y, m = t.look === "neo" ? 24 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = (t?.width ?? n.width) + (t.look === "neo" ? c * 2 : c + Lt), s = (t?.height ?? n.height) + (t.look === "neo" ? m * 2 : m), a = 0, l = r, e = -s, u = 0, f = [{ x: a + Lt, y: e }, { x: l, y: e }, { x: l, y: u }, { x: a, y: u }, { x: a, y: e + Lt }, { x: a + Lt, y: e }], d, { cssStyles: p } = t; if (t.look === "handDrawn") {
    let x = v.svg(o), w = I(t, {}), b = V(f), S = x.path(b, w);
    d = o.insert(() => S, ":first-child").attr("transform", `translate(${-r / 2}, ${s / 2})`), p && d.attr("style", p);
}
else
    d = gt(o, r, s, f); return g && d.attr("style", g), R(t, d), t.intersect = function (x) { return N.polygon(t, f, x); }, o; }); }
$(Ca, "card");
function Aa(h, t) { let { nodeStyles: i } = W(t); t.label = ""; let g = h.insert("g").attr("class", Y(t)).attr("id", t.domId ?? t.id), { cssStyles: y } = t, c = Math.max(28, t.width ?? 0), m = [{ x: 0, y: c / 2 }, { x: c / 2, y: 0 }, { x: 0, y: -c / 2 }, { x: -c / 2, y: 0 }], o = v.svg(g), n = I(t, {}); t.look !== "handDrawn" && (n.roughness = 0, n.fillStyle = "solid"); let r = V(m), s = o.path(r, n), a = g.insert(() => s, ":first-child"); return y && t.look !== "handDrawn" && a.selectAll("path").attr("style", y), i && t.look !== "handDrawn" && a.selectAll("path").attr("style", i), t.width = 28, t.height = 28, t.intersect = function (l) { return N.polygon(t, m, l); }, g; }
$(Aa, "choice");
function Jt(h, t, i) { return B(this, null, function* () { let { labelStyles: g, nodeStyles: y } = W(t); t.labelStyle = g; let { shapeSvg: c, bbox: m, halfPadding: o } = yield X(h, t, Y(t)), n = 16, r = i?.padding ?? o, s = t.look === "neo" ? m.width / 2 + n * 2 : m.width / 2 + r, a, { cssStyles: l } = t; if (t.look === "handDrawn") {
    let e = v.svg(c), u = I(t, {}), f = e.circle(0, 0, s * 2, u);
    a = c.insert(() => f, ":first-child"), a.attr("class", "basic label-container").attr("style", et(l));
}
else
    a = c.insert("circle", ":first-child").attr("class", "basic label-container").attr("style", y).attr("r", s).attr("cx", 0).attr("cy", 0); return R(t, a), t.calcIntersect = function (e, u) { let f = e.width / 2; return N.circle(e, f, u); }, t.intersect = function (e) { return U.info("Circle intersect", t, s, e), N.circle(t, s, e); }, c; }); }
$(Jt, "circle");
function Ra(h, t) { return B(this, null, function* () { let i = t, g = ["node", i.cssClasses, i.class].filter(Boolean).join(" "), { shapeSvg: y, bbox: c, halfPadding: m } = yield X(h, i, g), o = y.insert("rect", ":first-child"), n = i.padding ?? 0, r = i.positioned ? i.width ?? 0 : c.width + n, s = i.positioned ? i.height ?? 0 : c.height + n, a = i.positioned ? -r / 2 : -c.width / 2 - m, l = i.positioned ? -s / 2 : -c.height / 2 - m; return o.attr("class", "basic cluster composite label-container").attr("style", i.style ?? null).attr("rx", i.rx ?? null).attr("ry", i.ry ?? null).attr("x", a).attr("y", l).attr("width", r).attr("height", s), R(i, o), i.intersect = function (e) { return N.rect(i, e); }, y; }); }
$(Ra, "composite");
function Ha(g, y, c) { return B(this, arguments, function* (h, t, { config: { themeVariables: i } }) { let { labelStyles: m, nodeStyles: o } = W(t); t.labelStyle = m; let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = i?.nodeBorder ?? i?.lineColor ?? "currentColor", l = t.padding ?? 12, e = 20, u = 12, f = Math.max(r.width + l * 2, t.width ?? 0, 90), d = Math.max(r.height + l * 2 + e, t.height ?? 0), p = -d / 2, { cssStyles: x } = t, w = n.insert("g", ":first-child").attr("class", "basic label-container"); if (t.look === "handDrawn") {
    let k = v.svg(n).path(ut(-f / 2, p, f, d, u), I(t, {}));
    w.node()?.appendChild(k), x && w.attr("style", x);
}
else
    w.append("rect").attr("x", -f / 2).attr("y", p).attr("width", f).attr("height", d).attr("rx", u).attr("ry", u).attr("style", o); w.append("text").attr("x", -f / 2 + 12).attr("y", p + 16).attr("class", "console-glyph").attr("style", `font-family:monospace;font-weight:bold;font-size:14px;fill:${a}`).text(">_"), R(t, w); let b = p + e + (d - e) / 2; return s.attr("transform", `translate(${-(r.width / 2) - (r.x - (r.left ?? 0))}, ${b - r.height / 2 - (r.y - (r.top ?? 0))})`), t.intersect = function (S) { return N.rect(t, S); }, n; }); }
$(Ha, "consoleWindow");
function Ia(h) {
    let t = Math.cos(Math.PI / 4), i = Math.sin(Math.PI / 4), g = h * 2, y = { x: g / 2 * t, y: g / 2 * i }, c = { x: -(g / 2) * t, y: g / 2 * i }, m = { x: -(g / 2) * t, y: -(g / 2) * i }, o = { x: g / 2 * t, y: -(g / 2) * i };
    return `M ${c.x},${c.y} L ${o.x},${o.y}
                   M ${y.x},${y.y} L ${m.x},${m.y}`;
}
$(Ia, "createLine");
function La(h, t) { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i, t.label = ""; let y = h.insert("g").attr("class", Y(t)).attr("id", t.domId ?? t.id), c = Math.max(30, t?.width ?? 0), { cssStyles: m } = t, o = v.svg(y), n = I(t, {}); t.look !== "handDrawn" && (n.roughness = 0, n.fillStyle = "solid"); let r = o.circle(0, 0, c * 2, n), s = Ia(c), a = o.path(s, n), l = y.insert(() => r, ":first-child"); return l.insert(() => a), l.attr("class", "outer-path"), m && t.look !== "handDrawn" && l.selectAll("path").attr("style", m), g && t.look !== "handDrawn" && l.selectAll("path").attr("style", g), R(t, l), t.intersect = function (e) { return U.info("crossedCircle intersect", t, { radius: c, point: e }), N.circle(t, c, e); }, y; }
$(La, "crossedCircle");
function ft(h, t, i, g = 100, y = 0, c = 180) { let m = [], o = y * Math.PI / 180, s = (c * Math.PI / 180 - o) / (g - 1); for (let a = 0; a < g; a++) {
    let l = o + a * s, e = h + i * Math.cos(l), u = t + i * Math.sin(l);
    m.push({ x: -e, y: -u });
} return m; }
$(ft, "generateCirclePoints");
function Wa(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.look === "neo" ? 18 : t.padding ?? 0, n = t.look === "neo" ? 12 : t.padding ?? 0, r = c.width + o, s = c.height + n, a = Math.max(5, s * .1), { cssStyles: l } = t, e = [...ft(r / 2, -s / 2, a, 30, -90, 0), { x: -r / 2 - a, y: a }, ...ft(r / 2 + a * 2, -a, a, 20, -180, -270), ...ft(r / 2 + a * 2, a, a, 20, -90, -180), { x: -r / 2 - a, y: -s / 2 }, ...ft(r / 2, s / 2, a, 20, 0, 90)], u = [{ x: r / 2, y: -s / 2 - a }, { x: -r / 2, y: -s / 2 - a }, ...ft(r / 2, -s / 2, a, 20, -90, 0), { x: -r / 2 - a, y: -a }, ...ft(r / 2 + r * .1, -a, a, 20, -180, -270), ...ft(r / 2 + r * .1, a, a, 20, -90, -180), { x: -r / 2 - a, y: s / 2 }, ...ft(r / 2, s / 2, a, 20, 0, 90), { x: -r / 2, y: s / 2 + a }, { x: r / 2, y: s / 2 + a }], f = v.svg(y), d = I(t, { fill: "none" }); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let x = V(e).replace("Z", ""), w = f.path(x, d), b = V(u), S = f.path(b, it({}, d)), k = y.insert("g", ":first-child"); return k.insert(() => S, ":first-child").attr("stroke-opacity", 0), k.insert(() => w, ":first-child"), k.attr("class", "text"), l && t.look !== "handDrawn" && k.selectAll("path").attr("style", l), g && t.look !== "handDrawn" && k.selectAll("path").attr("style", g), k.attr("transform", `translate(${a}, 0)`), m.attr("transform", `translate(${-r / 2 + a - (c.x - (c.left ?? 0))},${-s / 2 + (t.padding ?? 0) / 2 - (c.y - (c.top ?? 0))})`), R(t, k), t.intersect = function (M) { return N.polygon(t, u, M); }, y; }); }
$(Wa, "curlyBraceLeft");
function pt(h, t, i, g = 100, y = 0, c = 180) { let m = [], o = y * Math.PI / 180, s = (c * Math.PI / 180 - o) / (g - 1); for (let a = 0; a < g; a++) {
    let l = o + a * s, e = h + i * Math.cos(l), u = t + i * Math.sin(l);
    m.push({ x: e, y: u });
} return m; }
$(pt, "generateCirclePoints");
function Ea(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.look === "neo" ? 18 : t.padding ?? 0, n = t.look === "neo" ? 12 : t.padding ?? 0, r = c.width + (t.look === "neo" ? o * 2 : o), s = c.height + (t.look === "neo" ? n * 2 : n), a = Math.max(5, s * .1), { cssStyles: l } = t, e = [...pt(r / 2, -s / 2, a, 20, -90, 0), { x: r / 2 + a, y: -a }, ...pt(r / 2 + a * 2, -a, a, 20, -180, -270), ...pt(r / 2 + a * 2, a, a, 20, -90, -180), { x: r / 2 + a, y: s / 2 }, ...pt(r / 2, s / 2, a, 20, 0, 90)], u = [{ x: -r / 2, y: -s / 2 - a }, { x: r / 2, y: -s / 2 - a }, ...pt(r / 2, -s / 2, a, 20, -90, 0), { x: r / 2 + a, y: -a }, ...pt(r / 2 + a * 2, -a, a, 20, -180, -270), ...pt(r / 2 + a * 2, a, a, 20, -90, -180), { x: r / 2 + a, y: s / 2 }, ...pt(r / 2, s / 2, a, 20, 0, 90), { x: r / 2, y: s / 2 + a }, { x: -r / 2, y: s / 2 + a }], f = v.svg(y), d = I(t, { fill: "none" }); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let x = V(e).replace("Z", ""), w = f.path(x, d), b = V(u), S = f.path(b, it({}, d)), k = y.insert("g", ":first-child"); return k.insert(() => S, ":first-child").attr("stroke-opacity", 0), k.insert(() => w, ":first-child"), k.attr("class", "text"), l && t.look !== "handDrawn" && k.selectAll("path").attr("style", l), g && t.look !== "handDrawn" && k.selectAll("path").attr("style", g), k.attr("transform", `translate(${-a}, 0)`), m.attr("transform", `translate(${-r / 2 + (t.padding ?? 0) / 2 - (c.x - (c.left ?? 0))},${-s / 2 + (t.padding ?? 0) / 2 - (c.y - (c.top ?? 0))})`), R(t, k), t.intersect = function (M) { return N.polygon(t, u, M); }, y; }); }
$(Ea, "curlyBraceRight");
function rt(h, t, i, g = 100, y = 0, c = 180) { let m = [], o = y * Math.PI / 180, s = (c * Math.PI / 180 - o) / (g - 1); for (let a = 0; a < g; a++) {
    let l = o + a * s, e = h + i * Math.cos(l), u = t + i * Math.sin(l);
    m.push({ x: -e, y: -u });
} return m; }
$(rt, "generateCirclePoints");
function Ta(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.look === "neo" ? 18 : t.padding ?? 0, n = t.look === "neo" ? 12 : t.padding ?? 0, r = c.width + (t.look === "neo" ? o * 2 : o), s = c.height + (t.look === "neo" ? n * 2 : n), a = Math.max(5, s * .1), { cssStyles: l } = t, e = [...rt(r / 2, -s / 2, a, 30, -90, 0), { x: -r / 2 - a, y: a }, ...rt(r / 2 + a * 2, -a, a, 20, -180, -270), ...rt(r / 2 + a * 2, a, a, 20, -90, -180), { x: -r / 2 - a, y: -s / 2 }, ...rt(r / 2, s / 2, a, 20, 0, 90)], u = [...rt(-r / 2 + a + a / 2, -s / 2, a, 20, -90, -180), { x: r / 2 - a / 2, y: a }, ...rt(-r / 2 - a / 2, -a, a, 20, 0, 90), ...rt(-r / 2 - a / 2, a, a, 20, -90, 0), { x: r / 2 - a / 2, y: -a }, ...rt(-r / 2 + a + a / 2, s / 2, a, 30, -180, -270)], f = [{ x: r / 2, y: -s / 2 - a }, { x: -r / 2, y: -s / 2 - a }, ...rt(r / 2, -s / 2, a, 20, -90, 0), { x: -r / 2 - a, y: -a }, ...rt(r / 2 + a * 2, -a, a, 20, -180, -270), ...rt(r / 2 + a * 2, a, a, 20, -90, -180), { x: -r / 2 - a, y: s / 2 }, ...rt(r / 2, s / 2, a, 20, 0, 90), { x: -r / 2, y: s / 2 + a }, { x: r / 2 - a - a / 2, y: s / 2 + a }, ...rt(-r / 2 + a + a / 2, -s / 2, a, 20, -90, -180), { x: r / 2 - a / 2, y: a }, ...rt(-r / 2 - a / 2, -a, a, 20, 0, 90), ...rt(-r / 2 - a / 2, a, a, 20, -90, 0), { x: r / 2 - a / 2, y: -a }, ...rt(-r / 2 + a + a / 2, s / 2, a, 30, -180, -270)], d = v.svg(y), p = I(t, { fill: "none" }); t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid"); let w = V(e).replace("Z", ""), b = d.path(w, p), k = V(u).replace("Z", ""), M = d.path(k, p), P = V(f), A = d.path(P, it({}, p)), D = y.insert("g", ":first-child"); return D.insert(() => A, ":first-child").attr("stroke-opacity", 0), D.insert(() => b, ":first-child"), D.insert(() => M, ":first-child"), D.attr("class", "text"), l && t.look !== "handDrawn" && D.selectAll("path").attr("style", l), g && t.look !== "handDrawn" && D.selectAll("path").attr("style", g), D.attr("transform", `translate(${a - a / 4}, 0)`), m.attr("transform", `translate(${-r / 2 + (t.padding ?? 0) / 2 - (c.x - (c.left ?? 0))},${-s / 2 + (t.padding ?? 0) / 2 - (c.y - (c.top ?? 0))})`), R(t, D), t.intersect = function (H) { return N.polygon(t, f, H); }, y; }); }
$(Ta, "curlyBraces");
function _a(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y, o = 20, n = 5, { shapeSvg: r, bbox: s } = yield X(h, t, Y(t)), a = Math.max(o, (s.width + c * 2) * 1.25, t?.width ?? 0), l = Math.max(n, s.height + m * 2, t?.height ?? 0), e = l / 2, { cssStyles: u } = t, f = v.svg(r), d = I(t, {}); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let p = a, x = l, w = p - e, b = x / 4, S = [{ x: w, y: 0 }, { x: b, y: 0 }, { x: 0, y: x / 2 }, { x: b, y: x }, { x: w, y: x }, ...ht(-w, -x / 2, e, 50, 270, 90)], k = V(S), M = f.path(k, d), P = r.insert(() => M, ":first-child"); return P.attr("class", "basic label-container outer-path"), u && t.look !== "handDrawn" && P.selectChildren("path").attr("style", u), g && t.look !== "handDrawn" && P.selectChildren("path").attr("style", g), P.attr("transform", `translate(${-a / 2}, ${-l / 2})`), R(t, P), t.intersect = function (A) { return N.polygon(t, S, A); }, r; }); }
$(_a, "curvedTrapezoid");
function Ya(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.padding ?? 20, n = Math.max(c.width + o * 2, t.width ?? 0, 100), r = Math.min(Math.max(n * .23, 16), 56), s = r * .27, a = Math.max(c.height + o * 2, t.height ? t.height - (2 * r - s) : 0), l = Math.min(n * .177, a * .45), e = a + 2 * r - s, u = -e / 2, f = u + 2 * r - s, d = y.insert("g", ":first-child").attr("class", "basic label-container"), { cssStyles: p } = t; if (t.look === "handDrawn") {
    let P = v.svg(y), A = I(t, {}), D = P.path(ut(-n / 2, f, n, a, l), A), H = P.circle(0, u + r, r * 2, A);
    d.insert(() => H, ":first-child"), d.insert(() => D, ":first-child"), p && d.attr("style", p);
}
else
    d.append("rect").attr("x", -n / 2).attr("y", f).attr("width", n).attr("height", a).attr("rx", l).attr("ry", l).attr("style", g), d.append("circle").attr("cx", 0).attr("cy", u + r).attr("r", r).attr("style", g); R(t, d); let x = f + a / 2; m.attr("transform", `translate(${-(c.width / 2) - (c.x - (c.left ?? 0))}, ${x - c.height / 2 - (c.y - (c.top ?? 0))})`); let w = u + r, b = Math.asin(Math.min(1, (f - w) / r)) * 180 / Math.PI, M = [...ht(0, -w, r, 24, 180 + b, -b), ...ht(-(-n / 2 + l), -(f + l), l, 12, 90, 0), ...ht(-(-n / 2 + l), -(e / 2 - l), l, 12, 360, 270), ...ht(-(n / 2 - l), -(e / 2 - l), l, 12, 270, 180), ...ht(-(n / 2 - l), -(f + l), l, 12, 180, 90)]; return t.intersect = function (P) { return N.polygon(t, M, P); }, y; }); }
$(Ya, "person");
var ie = $((h, t, i, g, y, c) => [`M${h},${t + c}`, `a${y},${c} 0,0,0 ${i},0`, `a${y},${c} 0,0,0 ${-i},0`, `l0,${g}`, `a${y},${c} 0,0,0 ${i},0`, `l0,${-g}`].join(" "), "createCylinderPathD"), le = $((h, t, i, g, y, c) => [`M${h},${t + c}`, `M${h + i},${t + c}`, `a${y},${c} 0,0,0 ${-i},0`, `l0,${g}`, `a${y},${c} 0,0,0 ${i},0`, `l0,${-g}`].join(" "), "createOuterCylinderPathD"), ne = $((h, t, i, g, y, c) => [`M${h - i / 2},${-g / 2}`, `a${y},${c} 0,0,0 ${i},0`].join(" "), "createInnerCylinderPathD"), la = 8, na = 8;
function Xa(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 24 : y, m = t.look === "neo" ? 24 : y, o = t.width ?? 0; if (t.width && (t.width = t.width - m, t.width < na && (t.width = na)), t.height) {
    let x = o / 2 / (2.5 + o / 50);
    t.height = t.height - c - x * 3, t.height < la && (t.height = la);
} let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = Math.max(t.width ?? 0, r.width) + m, l = a / 2, e = l / (2.5 + a / 50), u = Math.max(t.height ?? 0, r.height) + c + e, f, { cssStyles: d } = t; if (t.look === "handDrawn") {
    let p = v.svg(n), x = le(0, 0, a, u, l, e), w = ne(0, e, a, u, l, e), b = I(t, {}), S = p.path(x, b), k = p.path(w, I(t, { fill: "none" }));
    f = n.insert(() => k, ":first-child"), f = n.insert(() => S, ":first-child"), f.attr("class", "basic label-container"), d && f.attr("style", d);
}
else {
    let p = ie(0, 0, a, u, l, e);
    f = n.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container outer-path").attr("style", et(d)).attr("style", g);
} return f.attr("label-offset-y", e), f.attr("transform", `translate(${-a / 2}, ${-(u / 2 + e)})`), R(t, f), s.attr("transform", `translate(${-(r.width / 2) - (r.x - (r.left ?? 0))}, ${-(r.height / 2) + (t.padding ?? 0) / 1.5 - (r.y - (r.top ?? 0))})`), t.intersect = function (p) { let x = N.rect(t, p), w = x.x - (t.x ?? 0); if (l != 0 && (Math.abs(w) < (t.width ?? 0) / 2 || Math.abs(w) == (t.width ?? 0) / 2 && Math.abs(x.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - e)) {
    let b = e * e * (1 - w * w / (l * l));
    b > 0 && (b = Math.sqrt(b)), b = e - b, p.y - (t.y ?? 0) > 0 && (b = -b), x.y += b;
} return x; }, n; }); }
$(Xa, "cylinder");
function Nt(h, t, i) { return B(this, null, function* () { let { labelStyles: g, nodeStyles: y } = W(t); t.labelStyle = g; let { shapeSvg: c, bbox: m } = yield X(h, t, Y(t)), o = Math.max(m.width + i.labelPaddingX * 2, t?.width || 0), n = Math.max(m.height + i.labelPaddingY * 2, t?.height || 0), r = -o / 2, s = -n / 2, a, { rx: l, ry: e } = t, { cssStyles: u } = t; if (i?.rx && i.ry && (l = i.rx, e = i.ry), t.look === "handDrawn") {
    let f = v.svg(c), d = I(t, {}), p = l || e ? f.path(ut(r, s, o, n, l || 0), d) : f.rectangle(r, s, o, n, d);
    a = c.insert(() => p, ":first-child"), a.attr("class", "basic label-container").attr("style", et(u));
}
else
    a = c.insert("rect", ":first-child"), a.attr("class", "basic label-container").attr("style", y).attr("rx", et(l)).attr("ry", et(e)).attr("x", r).attr("y", s).attr("width", o).attr("height", n); return R(t, a, t.look === "handDrawn" ? void 0 : { width: o, height: n }), t.calcIntersect = function (f, d) { return N.rect(f, d); }, t.intersect = function (f) { return N.rect(t, f); }, c; }); }
$(Nt, "drawRect");
function Oa(h, t) { return B(this, null, function* () { let { cssClasses: i, labelPaddingX: g, labelPaddingY: y, padding: c, width: m, height: o } = t, n = { rx: 0, ry: 0, classes: i ?? "", labelPaddingX: g ?? (c ?? 0) * 2, labelPaddingY: y ?? c ?? 0 }, r = yield Nt(h, t, n); if (t.look === "handDrawn") {
    let e = v.svg(r), u = I(t, {}), f = r.select(".basic.label-container > path:nth-child(2)"), d = f.node();
    if (!d)
        return r;
    let p = null;
    if (d instanceof SVGGraphicsElement)
        p = d.getBBox();
    else
        return r;
    return r.insert(() => e.line(p.x, p.y, p.x + p.width, p.y, u), ".basic.label-container g.label"), r.insert(() => e.line(p.x, p.y + p.height, p.x + p.width, p.y + p.height, u), ".basic.label-container g.label"), f.remove(), r;
} let s = r.select(".basic.label-container"), a = (Number(s.attr("width")) || m) ?? 0, l = (Number(s.attr("height")) || o) ?? 0; return a > 0 && l > 0 && s.attr("stroke-dasharray", `${a} ${l}`), r; }); }
$(Oa, "datastore");
function Fa(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.look === "neo" ? 16 : t.padding ?? 0, c = t.look === "neo" ? 16 : t.padding ?? 0, { shapeSvg: m, bbox: o, label: n } = yield X(h, t, Y(t)), r = o.width + y, s = o.height + c, a = s * .2, l = -r / 2, e = -s / 2 - a / 2, { cssStyles: u } = t, f = v.svg(m), d = I(t, {}); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let p = [{ x: l, y: e + a }, { x: -l, y: e + a }, { x: -l, y: -e }, { x: l, y: -e }, { x: l, y: e }, { x: -l, y: e }, { x: -l, y: e + a }], x = f.polygon(p.map(b => [b.x, b.y]), d), w = m.insert(() => x, ":first-child"); return w.attr("class", "basic label-container outer-path"), u && t.look !== "handDrawn" && w.selectAll("path").attr("style", u), g && t.look !== "handDrawn" && w.selectAll("path").attr("style", g), n.attr("transform", `translate(${l + (t.padding ?? 0) / 2 - (o.x - (o.left ?? 0))}, ${e + a + (t.padding ?? 0) / 2 - (o.y - (o.top ?? 0))})`), R(t, w), t.intersect = function (b) { return N.rect(t, b); }, m; }); }
$(Fa, "dividedRectangle");
function ja(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t), y = t.look === "neo" ? 12 : 5; t.labelStyle = i; let c = t.padding ?? 0, m = t.look === "neo" ? 16 : c, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = (t?.width ? t?.width / 2 : n.width / 2) + (m ?? 0), s = r - y, a, { cssStyles: l } = t; if (t.look === "handDrawn") {
    let e = v.svg(o), u = I(t, { roughness: .2, strokeWidth: 2.5 }), f = I(t, { roughness: .2, strokeWidth: 1.5 }), d = e.circle(0, 0, r * 2, u), p = e.circle(0, 0, s * 2, f);
    a = o.insert("g", ":first-child"), a.attr("class", et(t.cssClasses)).attr("style", et(l)), a.node()?.appendChild(d), a.node()?.appendChild(p);
}
else {
    a = o.insert("g", ":first-child");
    let e = a.insert("circle", ":first-child"), u = a.insert("circle");
    a.attr("class", "basic label-container").attr("style", g), e.attr("class", "outer-circle").attr("style", g).attr("r", r).attr("cx", 0).attr("cy", 0), u.attr("class", "inner-circle").attr("style", g).attr("r", s).attr("cx", 0).attr("cy", 0);
} return R(t, a), t.intersect = function (e) { return U.info("DoubleCircle intersect", t, r, e), N.circle(t, r, e); }, o; }); }
$(ja, "doublecircle");
function Ga(h, t, { config: { themeVariables: i } }) { let { labelStyles: g, nodeStyles: y } = W(t); t.label = "", t.labelStyle = g; let c = h.insert("g").attr("class", Y(t)).attr("id", t.domId ?? t.id), m = 7, { cssStyles: o } = t, n = v.svg(c), { nodeBorder: r } = i, s = I(t, { fillStyle: "solid" }); t.look !== "handDrawn" && (s.roughness = 0); let a = n.circle(0, 0, m * 2, s), l = c.insert(() => a, ":first-child"); return l.selectAll("path").attr("style", `fill: ${r} !important;`), o && o.length > 0 && t.look !== "handDrawn" && l.selectAll("path").attr("style", o), y && t.look !== "handDrawn" && l.selectAll("path").attr("style", y), R(t, l), t.intersect = function (e) { return U.info("filledCircle intersect", t, { radius: m, point: e }), N.circle(t, m, e); }, c; }
$(Ga, "filledCircle");
var ca = 10, oa = 10;
function qa(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? y * 2 : y; (t.width || t.height) && (t.height = t?.height ?? 0, t.height < ca && (t.height = ca), t.width = (t?.width ?? 0) - c - c / 2, t.width < oa && (t.width = oa)); let { shapeSvg: m, bbox: o, label: n } = yield X(h, t, Y(t)), r = (t?.width ? t?.width : o.width) + (c ?? 0), s = t?.height ? t?.height : r + o.height, a = s, l = [{ x: 0, y: -s }, { x: a, y: -s }, { x: a / 2, y: 0 }], { cssStyles: e } = t, u = v.svg(m), f = I(t, {}); t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid"); let d = V(l), p = u.path(d, f), x = m.insert(() => p, ":first-child").attr("transform", `translate(${-s / 2}, ${s / 2})`).attr("class", "outer-path"); return e && t.look !== "handDrawn" && x.selectChildren("path").attr("style", e), g && t.look !== "handDrawn" && x.selectChildren("path").attr("style", g), t.width = r, t.height = s, R(t, x), n.attr("transform", `translate(${-o.width / 2 - (o.x - (o.left ?? 0))}, ${-s / 2 + (t.padding ?? 0) / 2 + (o.y - (o.top ?? 0))})`), t.intersect = function (w) { return U.info("Triangle intersect", t, l, w), N.polygon(t, l, w); }, m; }); }
$(qa, "flippedTriangle");
function za(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.padding ?? 12, n = Math.max(c.width + o * 2, t.width ?? 0, 90), r = c.height + o * 2, s = Math.max(Math.min(r * .16, 14), 8), a = Math.max(r + s, t.height ?? 0), l = a - s, e = Math.max(n * .38, 28), u = -a / 2, f = [{ x: -n / 2, y: u }, { x: -n / 2 + e, y: u }, { x: -n / 2 + e, y: u + s }, { x: n / 2, y: u + s }, { x: n / 2, y: a / 2 }, { x: -n / 2, y: a / 2 }], d = [`M${f[0].x},${f[0].y}`, ...f.slice(1).map(b => `L${b.x},${b.y}`), "Z"].join(" "), { cssStyles: p } = t, x; if (t.look === "handDrawn") {
    let S = v.svg(y).path(d, I(t, {}));
    x = y.insert(() => S, ":first-child").attr("class", "basic label-container"), p && x.attr("style", p);
}
else
    x = y.insert("path", ":first-child").attr("d", d).attr("class", "basic label-container").attr("style", g); t.look === "handDrawn" ? R(t, x) : R(t, x, { width: n, height: a }); let w = u + s + l / 2; return m.attr("transform", `translate(${-(c.width / 2) - (c.x - (c.left ?? 0))}, ${w - c.height / 2 - (c.y - (c.top ?? 0))})`), t.intersect = function (b) { return N.polygon(t, f, b); }, y; }); }
$(za, "folder");
function Va(h, t, { dir: i, config: { state: g, themeVariables: y } }) { let { nodeStyles: c } = W(t); t.label = ""; let m = h.insert("g").attr("class", Y(t)).attr("id", t.domId ?? t.id), { cssStyles: o } = t, n = Math.max(70, t?.width ?? 0), r = Math.max(10, t?.height ?? 0); i === "LR" && (n = Math.max(10, t?.width ?? 0), r = Math.max(70, t?.height ?? 0)); let s = -1 * n / 2, a = -1 * r / 2, l = v.svg(m), e = I(t, { stroke: y.lineColor, fill: y.lineColor }); t.look !== "handDrawn" && (e.roughness = 0, e.fillStyle = "solid"); let u = l.rectangle(s, a, n, r, e), f = m.insert(() => u, ":first-child"); o && t.look !== "handDrawn" && f.selectAll("path").attr("style", o), c && t.look !== "handDrawn" && f.selectAll("path").attr("style", c), R(t, f); let d = g?.padding ?? 0; return t.width && t.height && (t.width += d / 2 || 0, t.height += d / 2 || 0), t.intersect = function (p) { return N.rect(t, p); }, m; }
$(Va, "forkJoin");
function Za(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = 15, c = 10, m = t.look === "neo" ? 16 : t.padding ?? 0, o = t.look === "neo" ? 12 : t.padding ?? 0; (t.width || t.height) && (t.height = (t?.height ?? 0) - o * 2, t.height < c && (t.height = c), t.width = (t?.width ?? 0) - m * 2, t.width < y && (t.width = y)); let { shapeSvg: n, bbox: r } = yield X(h, t, Y(t)), s = (t?.width ? t?.width : Math.max(y, r.width)) + m * 2, a = (t?.height ? t?.height : Math.max(c, r.height)) + o * 2, l = a / 2, { cssStyles: e } = t, u = v.svg(n), f = I(t, {}); t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid"); let d = [{ x: -s / 2, y: -a / 2 }, { x: s / 2 - l, y: -a / 2 }, ...ht(-s / 2 + l, 0, l, 50, 90, 270), { x: s / 2 - l, y: a / 2 }, { x: -s / 2, y: a / 2 }], p = V(d), x = u.path(p, f), w = n.insert(() => x, ":first-child"); return w.attr("class", "basic label-container outer-path"), e && t.look !== "handDrawn" && w.selectChildren("path").attr("style", e), g && t.look !== "handDrawn" && w.selectChildren("path").attr("style", g), R(t, w), t.intersect = function (b) { return U.info("Pill intersect", t, { radius: l, point: b }), N.polygon(t, d, b); }, n; }); }
$(Za, "halfRoundedRectangle");
var ce = $((h, t, i, g, y) => [`M${h + y},${t}`, `L${h + i - y},${t}`, `L${h + i},${t - g / 2}`, `L${h + i - y},${t - g}`, `L${h + y},${t - g}`, `L${h},${t - g / 2}`, "Z"].join(" "), "createHexagonPathD");
function Ja(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t), y = t.look === "neo" ? 3.5 : 4; t.labelStyle = i; let c = t.padding ?? 0, m = 70, o = 32, n = t.look === "neo" ? m : c, r = t.look === "neo" ? o : c; if (t.width || t.height) {
    let w = (t.height ?? 0) / y;
    t.width = (t?.width ?? 0) - 2 * w - r, t.height = (t.height ?? 0) - n;
} let { shapeSvg: s, bbox: a } = yield X(h, t, Y(t)), l = (t?.height ? t?.height : a.height) + n, e = l / y, u = (t?.width ? t?.width : a.width) + 2 * e + r, f = [{ x: e, y: 0 }, { x: u - e, y: 0 }, { x: u, y: -l / 2 }, { x: u - e, y: -l }, { x: e, y: -l }, { x: 0, y: -l / 2 }], d, { cssStyles: p } = t; if (t.look === "handDrawn") {
    let x = v.svg(s), w = I(t, {}), b = ce(0, 0, u, l, e), S = x.path(b, w);
    d = s.insert(() => S, ":first-child").attr("transform", `translate(${-u / 2}, ${l / 2})`), p && d.attr("style", p);
}
else
    d = gt(s, u, l, f); return g && d.attr("style", g), t.width = u, t.height = l, R(t, d), t.intersect = function (x) { return N.polygon(t, f, x); }, s; }); }
$(Ja, "hexagon");
function Ka(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.label = "", t.labelStyle = i; let { shapeSvg: y } = yield X(h, t, Y(t)), c = Math.max(30, t?.width ?? 0), m = Math.max(30, t?.height ?? 0), { cssStyles: o } = t, n = v.svg(y), r = I(t, {}); t.look !== "handDrawn" && (r.roughness = 0, r.fillStyle = "solid"); let s = [{ x: 0, y: 0 }, { x: c, y: 0 }, { x: 0, y: m }, { x: c, y: m }], a = V(s), l = n.path(a, r), e = y.insert(() => l, ":first-child"); return e.attr("class", "basic label-container outer-path"), o && t.look !== "handDrawn" && e.selectChildren("path").attr("style", o), g && t.look !== "handDrawn" && e.selectChildren("path").attr("style", g), e.attr("transform", `translate(${-c / 2}, ${-m / 2})`), R(t, e), t.intersect = function (u) { return U.info("Pill intersect", t, { points: s }), N.polygon(t, s, u); }, y; }); }
$(Ka, "hourglass");
function Ua(y, c, m) { return B(this, arguments, function* (h, t, { config: { themeVariables: i, flowchart: g } }) { let { labelStyles: o } = W(t); t.labelStyle = o; let n = t.assetHeight ?? 48, r = t.assetWidth ?? 48, s = Math.max(n, r), a = g?.wrappingWidth; t.width = Math.max(s, a ?? 0); let { shapeSvg: l, bbox: e, label: u } = yield X(h, t, "icon-shape default"), f = t.pos === "t", d = s, p = s, { nodeBorder: x } = i, { stylesMap: w } = Bt(t), b = -p / 2, S = -d / 2, k = t.label ? 8 : 0, M = v.svg(l), P = I(t, { stroke: "none", fill: "none" }); t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid"); let A = M.rectangle(b, S, p, d, P), D = Math.max(p, e.width), H = d + e.height + k, z = M.rectangle(-D / 2, -H / 2, D, H, nt(it({}, P), { fill: "transparent", stroke: "none" })), G = l.insert(() => A, ":first-child"), E = l.insert(() => z); if (t.icon) {
    let L = l.append("g");
    L.html(`<g>${yield Ct(t.icon, { height: s, width: s, fallbackPrefix: "" })}</g>`);
    let T = L.node().getBBox(), O = T.width, F = T.height, C = T.x, _ = T.y;
    L.attr("transform", `translate(${-O / 2 - C},${f ? e.height / 2 + k / 2 - F / 2 - _ : -e.height / 2 - k / 2 - F / 2 - _})`), L.attr("style", `color: ${w.get("stroke") ?? x};`);
} return u.attr("transform", `translate(${-e.width / 2 - (e.x - (e.left ?? 0))},${f ? -H / 2 : H / 2 - e.height})`), G.attr("transform", `translate(0,${f ? e.height / 2 + k / 2 : -e.height / 2 - k / 2})`), R(t, E), t.intersect = function (L) { if (U.info("iconSquare intersect", t, L), !t.label)
    return N.rect(t, L); let T = t.x ?? 0, O = t.y ?? 0, F = t.height ?? 0, C = []; return f ? C = [{ x: T - e.width / 2, y: O - F / 2 }, { x: T + e.width / 2, y: O - F / 2 }, { x: T + e.width / 2, y: O - F / 2 + e.height + k }, { x: T + p / 2, y: O - F / 2 + e.height + k }, { x: T + p / 2, y: O + F / 2 }, { x: T - p / 2, y: O + F / 2 }, { x: T - p / 2, y: O - F / 2 + e.height + k }, { x: T - e.width / 2, y: O - F / 2 + e.height + k }] : C = [{ x: T - p / 2, y: O - F / 2 }, { x: T + p / 2, y: O - F / 2 }, { x: T + p / 2, y: O - F / 2 + d }, { x: T + e.width / 2, y: O - F / 2 + d }, { x: T + e.width / 2 / 2, y: O + F / 2 }, { x: T - e.width / 2, y: O + F / 2 }, { x: T - e.width / 2, y: O - F / 2 + d }, { x: T - p / 2, y: O - F / 2 + d }], N.polygon(t, C, L); }, l; }); }
$(Ua, "icon");
function Qa(y, c, m) { return B(this, arguments, function* (h, t, { config: { themeVariables: i, flowchart: g } }) { let { labelStyles: o } = W(t); t.labelStyle = o; let n = t.assetHeight ?? 48, r = t.assetWidth ?? 48, s = Math.max(n, r), a = g?.wrappingWidth; t.width = Math.max(s, a ?? 0); let { shapeSvg: l, bbox: e, label: u } = yield X(h, t, "icon-shape default"), f = 20, d = t.label ? 8 : 0, p = t.pos === "t", { nodeBorder: x, mainBkg: w } = i, { stylesMap: b } = Bt(t), S = v.svg(l), k = I(t, {}); t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid"); let M = b.get("fill"); k.stroke = M ?? w; let P = l.append("g"); t.icon && P.html(`<g>${yield Ct(t.icon, { height: s, width: s, fallbackPrefix: "" })}</g>`); let A = P.node().getBBox(), D = A.width, H = A.height, z = A.x, G = A.y, E = Math.max(D, H) * Math.SQRT2 + f * 2, L = S.circle(0, 0, E, k), T = Math.max(E, e.width), O = E + e.height + d, F = S.rectangle(-T / 2, -O / 2, T, O, nt(it({}, k), { fill: "transparent", stroke: "none" })), C = l.insert(() => L, ":first-child"), _ = l.insert(() => F); return P.attr("transform", `translate(${-D / 2 - z},${p ? e.height / 2 + d / 2 - H / 2 - G : -e.height / 2 - d / 2 - H / 2 - G})`), P.attr("style", `color: ${b.get("stroke") ?? x};`), u.attr("transform", `translate(${-e.width / 2 - (e.x - (e.left ?? 0))},${p ? -O / 2 : O / 2 - e.height})`), C.attr("transform", `translate(0,${p ? e.height / 2 + d / 2 : -e.height / 2 - d / 2})`), R(t, _), t.intersect = function (j) { return U.info("iconSquare intersect", t, j), N.rect(t, j); }, l; }); }
$(Qa, "iconCircle");
function ts(y, c, m) { return B(this, arguments, function* (h, t, { config: { themeVariables: i, flowchart: g } }) { let { labelStyles: o } = W(t); t.labelStyle = o; let n = t.assetHeight ?? 48, r = t.assetWidth ?? 48, s = Math.max(n, r), a = g?.wrappingWidth; t.width = Math.max(s, a ?? 0); let { shapeSvg: l, bbox: e, halfPadding: u, label: f } = yield X(h, t, "icon-shape default"), d = t.pos === "t", p = s + u * 2, x = s + u * 2, { nodeBorder: w, mainBkg: b } = i, { stylesMap: S } = Bt(t), k = -x / 2, M = -p / 2, P = t.label ? 8 : 0, A = v.svg(l), D = I(t, {}); t.look !== "handDrawn" && (D.roughness = 0, D.fillStyle = "solid"); let H = S.get("fill"); D.stroke = H ?? b; let z = A.path(ut(k, M, x, p, 5), D), G = Math.max(x, e.width), E = p + e.height + P, L = A.rectangle(-G / 2, -E / 2, G, E, nt(it({}, D), { fill: "transparent", stroke: "none" })), T = l.insert(() => z, ":first-child").attr("class", "icon-shape2"), O = l.insert(() => L); if (t.icon) {
    let F = l.append("g");
    F.html(`<g>${yield Ct(t.icon, { height: s, width: s, fallbackPrefix: "" })}</g>`);
    let C = F.node().getBBox(), _ = C.width, j = C.height, tt = C.x, st = C.y;
    F.attr("transform", `translate(${-_ / 2 - tt},${d ? e.height / 2 + P / 2 - j / 2 - st : -e.height / 2 - P / 2 - j / 2 - st})`), F.attr("style", `color: ${S.get("stroke") ?? w};`);
} return f.attr("transform", `translate(${-e.width / 2 - (e.x - (e.left ?? 0))},${d ? -E / 2 : E / 2 - e.height})`), T.attr("transform", `translate(0,${d ? e.height / 2 + P / 2 : -e.height / 2 - P / 2})`), R(t, O), t.intersect = function (F) { if (U.info("iconSquare intersect", t, F), !t.label)
    return N.rect(t, F); let C = t.x ?? 0, _ = t.y ?? 0, j = t.height ?? 0, tt = []; return d ? tt = [{ x: C - e.width / 2, y: _ - j / 2 }, { x: C + e.width / 2, y: _ - j / 2 }, { x: C + e.width / 2, y: _ - j / 2 + e.height + P }, { x: C + x / 2, y: _ - j / 2 + e.height + P }, { x: C + x / 2, y: _ + j / 2 }, { x: C - x / 2, y: _ + j / 2 }, { x: C - x / 2, y: _ - j / 2 + e.height + P }, { x: C - e.width / 2, y: _ - j / 2 + e.height + P }] : tt = [{ x: C - x / 2, y: _ - j / 2 }, { x: C + x / 2, y: _ - j / 2 }, { x: C + x / 2, y: _ - j / 2 + p }, { x: C + e.width / 2, y: _ - j / 2 + p }, { x: C + e.width / 2 / 2, y: _ + j / 2 }, { x: C - e.width / 2, y: _ + j / 2 }, { x: C - e.width / 2, y: _ - j / 2 + p }, { x: C - x / 2, y: _ - j / 2 + p }], N.polygon(t, tt, F); }, l; }); }
$(ts, "iconRounded");
function as(y, c, m) { return B(this, arguments, function* (h, t, { config: { themeVariables: i, flowchart: g } }) { let { labelStyles: o } = W(t); t.labelStyle = o; let n = t.assetHeight ?? 48, r = t.assetWidth ?? 48, s = Math.max(n, r), a = g?.wrappingWidth; t.width = Math.max(s, a ?? 0); let { shapeSvg: l, bbox: e, halfPadding: u, label: f } = yield X(h, t, "icon-shape default"), d = t.pos === "t", p = s + u * 2, x = s + u * 2, { nodeBorder: w, mainBkg: b } = i, { stylesMap: S } = Bt(t), k = -x / 2, M = -p / 2, P = t.label ? 8 : 0, A = v.svg(l), D = I(t, {}); t.look !== "handDrawn" && (D.roughness = 0, D.fillStyle = "solid"); let H = S.get("fill"); D.stroke = H ?? b; let z = A.path(ut(k, M, x, p, .1), D), G = Math.max(x, e.width), E = p + e.height + P, L = A.rectangle(-G / 2, -E / 2, G, E, nt(it({}, D), { fill: "transparent", stroke: "none" })), T = l.insert(() => z, ":first-child"), O = l.insert(() => L); if (t.icon) {
    let F = l.append("g");
    F.html(`<g>${yield Ct(t.icon, { height: s, width: s, fallbackPrefix: "" })}</g>`);
    let C = F.node().getBBox(), _ = C.width, j = C.height, tt = C.x, st = C.y;
    F.attr("transform", `translate(${-_ / 2 - tt},${d ? e.height / 2 + P / 2 - j / 2 - st : -e.height / 2 - P / 2 - j / 2 - st})`), F.attr("style", `color: ${S.get("stroke") ?? w};`);
} return f.attr("transform", `translate(${-e.width / 2 - (e.x - (e.left ?? 0))},${d ? -E / 2 : E / 2 - e.height})`), T.attr("transform", `translate(0,${d ? e.height / 2 + P / 2 : -e.height / 2 - P / 2})`), R(t, O), t.intersect = function (F) { if (U.info("iconSquare intersect", t, F), !t.label)
    return N.rect(t, F); let C = t.x ?? 0, _ = t.y ?? 0, j = t.height ?? 0, tt = []; return d ? tt = [{ x: C - e.width / 2, y: _ - j / 2 }, { x: C + e.width / 2, y: _ - j / 2 }, { x: C + e.width / 2, y: _ - j / 2 + e.height + P }, { x: C + x / 2, y: _ - j / 2 + e.height + P }, { x: C + x / 2, y: _ + j / 2 }, { x: C - x / 2, y: _ + j / 2 }, { x: C - x / 2, y: _ - j / 2 + e.height + P }, { x: C - e.width / 2, y: _ - j / 2 + e.height + P }] : tt = [{ x: C - x / 2, y: _ - j / 2 }, { x: C + x / 2, y: _ - j / 2 }, { x: C + x / 2, y: _ - j / 2 + p }, { x: C + e.width / 2, y: _ - j / 2 + p }, { x: C + e.width / 2 / 2, y: _ + j / 2 }, { x: C - e.width / 2, y: _ + j / 2 }, { x: C - e.width / 2, y: _ - j / 2 + p }, { x: C - x / 2, y: _ - j / 2 + p }], N.polygon(t, tt, F); }, l; }); }
$(as, "iconSquare");
function ss(g, y, c) { return B(this, arguments, function* (h, t, { config: { flowchart: i } }) { let m = new Image; m.src = t?.img ?? "", yield m.decode(); let o = Number(m.naturalWidth.toString().replace("px", "")), n = Number(m.naturalHeight.toString().replace("px", "")); t.imageAspectRatio = o / n; let { labelStyles: r } = W(t); t.labelStyle = r; let s = i?.wrappingWidth; t.defaultWidth = i?.wrappingWidth; let a = Math.max(t.label ? s ?? 0 : 0, t?.assetWidth ?? o), l = t.constraint === "on" && t?.assetHeight ? t.assetHeight * t.imageAspectRatio : a, e = t.constraint === "on" ? l / t.imageAspectRatio : t?.assetHeight ?? n; t.width = Math.max(l, s ?? 0); let { shapeSvg: u, bbox: f, label: d } = yield X(h, t, "image-shape default"), p = t.pos === "t", x = -l / 2, w = -e / 2, b = t.label ? 8 : 0, S = v.svg(u), k = I(t, {}); t.look !== "handDrawn" && (k.roughness = 0, k.fillStyle = "solid"); let M = S.rectangle(x, w, l, e, k), P = Math.max(l, f.width), A = e + f.height + b, D = S.rectangle(-P / 2, -A / 2, P, A, nt(it({}, k), { fill: "none", stroke: "none" })), H = u.insert(() => M, ":first-child"), z = u.insert(() => D); if (t.img) {
    let G = u.append("image");
    G.attr("href", t.img), G.attr("width", l), G.attr("height", e), G.attr("preserveAspectRatio", "none"), G.attr("transform", `translate(${-l / 2},${p ? A / 2 - e : -A / 2})`);
} return d.attr("transform", `translate(${-f.width / 2 - (f.x - (f.left ?? 0))},${p ? -e / 2 - f.height / 2 - b / 2 : e / 2 - f.height / 2 + b / 2})`), H.attr("transform", `translate(0,${p ? f.height / 2 + b / 2 : -f.height / 2 - b / 2})`), R(t, z), t.intersect = function (G) { if (U.info("iconSquare intersect", t, G), !t.label)
    return N.rect(t, G); let E = t.x ?? 0, L = t.y ?? 0, T = t.height ?? 0, O = []; return p ? O = [{ x: E - f.width / 2, y: L - T / 2 }, { x: E + f.width / 2, y: L - T / 2 }, { x: E + f.width / 2, y: L - T / 2 + f.height + b }, { x: E + l / 2, y: L - T / 2 + f.height + b }, { x: E + l / 2, y: L + T / 2 }, { x: E - l / 2, y: L + T / 2 }, { x: E - l / 2, y: L - T / 2 + f.height + b }, { x: E - f.width / 2, y: L - T / 2 + f.height + b }] : O = [{ x: E - l / 2, y: L - T / 2 }, { x: E + l / 2, y: L - T / 2 }, { x: E + l / 2, y: L - T / 2 + e }, { x: E + f.width / 2, y: L - T / 2 + e }, { x: E + f.width / 2 / 2, y: L + T / 2 }, { x: E - f.width / 2, y: L + T / 2 }, { x: E - f.width / 2, y: L - T / 2 + e }, { x: E - l / 2, y: L - T / 2 + e }], N.polygon(t, O, G); }, u; }); }
$(ss, "imageSquare");
function es(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = y, m = t.look === "neo" ? y * 2 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = Math.max(n.height + c * 2, t.height ?? 0), s = Math.max(n.width + m * 2, (t.width ?? 0) - r), a = [{ x: 0, y: 0 }, { x: s, y: 0 }, { x: s + 3 * r / 6, y: -r }, { x: -3 * r / 6, y: -r }], l, { cssStyles: e } = t; if (t.look === "handDrawn") {
    let u = v.svg(o), f = I(t, {}), d = V(a), p = u.path(d, f);
    l = o.insert(() => p, ":first-child").attr("transform", `translate(${-s / 2}, ${r / 2})`), e && l.attr("style", e);
}
else
    l = gt(o, s, r, a); return g && l.attr("style", g), t.width = s, t.height = r, R(t, l), t.intersect = function (u) { return N.polygon(t, a, u); }, o; }); }
$(es, "inv_trapezoid");
function rs(h, t) { return B(this, null, function* () { let { shapeSvg: i, bbox: g, label: y } = yield X(h, t, "label"), c = i.insert("rect", ":first-child"); return c.attr("width", .1).attr("height", .1), i.attr("class", "label edgeLabel"), y.attr("transform", `translate(${-(g.width / 2) - (g.x - (g.left ?? 0))}, ${-(g.height / 2) - (g.y - (g.top ?? 0))})`), R(t, c), t.intersect = function (n) { return N.rect(t, n); }, i; }); }
$(rs, "labelRect");
function is(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = y, m = t.look === "neo" ? y * 2 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = Math.max(n.height + c, t.height ?? 0), s = Math.max(n.width + m, (t.width ?? 0) - r), a = [{ x: 0, y: 0 }, { x: s + 3 * r / 6, y: 0 }, { x: s, y: -r }, { x: -(3 * r) / 6, y: -r }], l, { cssStyles: e } = t; if (t.look === "handDrawn") {
    let u = v.svg(o), f = I(t, {}), d = V(a), p = u.path(d, f);
    l = o.insert(() => p, ":first-child").attr("transform", `translate(${-s / 2}, ${r / 2})`), e && l.attr("style", e);
}
else
    l = gt(o, s, r, a); return g && l.attr("style", g), t.width = s, t.height = r, R(t, l), t.intersect = function (u) { return N.polygon(t, a, u); }, o; }); }
$(is, "lean_left");
function ls(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = y, m = t.look === "neo" ? y * 2 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = Math.max(n.height + c, t.height ?? 0), s = Math.max(n.width + m, (t.width ?? 0) - r), a = [{ x: -3 * r / 6, y: 0 }, { x: s, y: 0 }, { x: s + 3 * r / 6, y: -r }, { x: 0, y: -r }], l, { cssStyles: e } = t; if (t.look === "handDrawn") {
    let u = v.svg(o), f = I(t, {}), d = V(a), p = u.path(d, f);
    l = o.insert(() => p, ":first-child").attr("transform", `translate(${-s / 2}, ${r / 2})`), e && l.attr("style", e);
}
else
    l = gt(o, s, r, a); return g && l.attr("style", g), t.width = s, t.height = r, R(t, l), t.intersect = function (u) { return N.polygon(t, a, u); }, o; }); }
$(ls, "lean_right");
function ns(h, t) { let { labelStyles: i, nodeStyles: g } = W(t); t.label = "", t.labelStyle = i; let y = h.insert("g").attr("class", Y(t)).attr("id", t.domId ?? t.id), { cssStyles: c } = t, m = Math.max(35, t?.width ?? 0), o = Math.max(35, t?.height ?? 0), n = 7, r = [{ x: m, y: 0 }, { x: 0, y: o + n / 2 }, { x: m - 2 * n, y: o + n / 2 }, { x: 0, y: 2 * o }, { x: m, y: o - n / 2 }, { x: 2 * n, y: o - n / 2 }], s = v.svg(y), a = I(t, {}); t.look !== "handDrawn" && (a.roughness = 0, a.fillStyle = "solid"); let l = V(r), e = s.path(l, a), u = y.insert(() => e, ":first-child"); return u.attr("class", "outer-path"), c && t.look !== "handDrawn" && u.selectAll("path").attr("style", c), g && t.look !== "handDrawn" && u.selectAll("path").attr("style", g), u.attr("transform", `translate(-${m / 2},${-o})`), R(t, u), t.intersect = function (f) { return U.info("lightningBolt intersect", t, f), N.polygon(t, r, f); }, y; }
$(ns, "lightningBolt");
var oe = $((h, t, i, g, y, c, m) => [`M${h},${t + c}`, `a${y},${c} 0,0,0 ${i},0`, `a${y},${c} 0,0,0 ${-i},0`, `l0,${g}`, `a${y},${c} 0,0,0 ${i},0`, `l0,${-g}`, `M${h},${t + c + m}`, `a${y},${c} 0,0,0 ${i},0`].join(" "), "createCylinderPathD"), he = $((h, t, i, g, y, c, m) => [`M${h},${t + c}`, `M${h + i},${t + c}`, `a${y},${c} 0,0,0 ${-i},0`, `l0,${g}`, `a${y},${c} 0,0,0 ${i},0`, `l0,${-g}`, `M${h},${t + c + m}`, `a${y},${c} 0,0,0 ${i},0`].join(" "), "createOuterCylinderPathD"), ge = $((h, t, i, g, y, c) => [`M${h - i / 2},${-g / 2}`, `a${y},${c} 0,0,0 ${i},0`].join(" "), "createInnerCylinderPathD"), ha = 10, ga = 10;
function cs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 24 : y; if (t.width || t.height) {
    let p = t.width ?? 0;
    t.width = (t.width ?? 0) - c, t.width < ga && (t.width = ga);
    let w = p / 2 / (2.5 + p / 50);
    t.height = (t.height ?? 0) - m - w * 3, t.height < ha && (t.height = ha);
} let { shapeSvg: o, bbox: n, label: r } = yield X(h, t, Y(t)), s = (t?.width ? t?.width : n.width) + c * 2, a = s / 2, l = a / (2.5 + s / 50), e = (t?.height ? t?.height : n.height) + l + m * 2, u = e * .1, f, { cssStyles: d } = t; if (t.look === "handDrawn") {
    let p = v.svg(o), x = he(0, 0, s, e, a, l, u), w = ge(0, l, s, e, a, l), b = I(t, {}), S = p.path(x, b), k = p.path(w, b);
    o.insert(() => k, ":first-child").attr("class", "line"), f = o.insert(() => S, ":first-child"), f.attr("class", "basic label-container"), d && f.attr("style", d);
}
else {
    let p = oe(0, 0, s, e, a, l, u);
    f = o.insert("path", ":first-child").attr("d", p).attr("class", "basic label-container outer-path").attr("style", et(d)).attr("style", g);
} return f.attr("label-offset-y", l), f.attr("transform", `translate(${-s / 2}, ${-(e / 2 + l)})`), R(t, f), r.attr("transform", `translate(${-(n.width / 2) - (n.x - (n.left ?? 0))}, ${-(n.height / 2) + l - (n.y - (n.top ?? 0))})`), t.intersect = function (p) { let x = N.rect(t, p), w = x.x - (t.x ?? 0); if (a != 0 && (Math.abs(w) < (t.width ?? 0) / 2 || Math.abs(w) == (t.width ?? 0) / 2 && Math.abs(x.y - (t.y ?? 0)) > (t.height ?? 0) / 2 - l)) {
    let b = l * l * (1 - w * w / (a * a));
    b > 0 && (b = Math.sqrt(b)), b = l - b, p.y - (t.y ?? 0) > 0 && (b = -b), x.y += b;
} return x; }, o; }); }
$(cs, "linedCylinder");
function os(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y; if (t.width || t.height) {
    let b = t.width;
    t.width = (b ?? 0) * 10 / 11 - c * 2, t.width < 10 && (t.width = 10), t.height = (t?.height ?? 0) - m * 2, t.height < 10 && (t.height = 10);
} let { shapeSvg: o, bbox: n, label: r } = yield X(h, t, Y(t)), s = (t?.width ? t?.width : n.width) + (c ?? 0) * 2, a = (t?.height ? t?.height : n.height) + (m ?? 0) * 2, l = t.look === "neo" ? a / 4 : a / 8, e = a + l, { cssStyles: u } = t, f = v.svg(o), d = I(t, {}); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let p = [{ x: -s / 2 - s / 2 * .1, y: -e / 2 }, { x: -s / 2 - s / 2 * .1, y: e / 2 }, ...xt(-s / 2 - s / 2 * .1, e / 2, s / 2 + s / 2 * .1, e / 2, l, .8), { x: s / 2 + s / 2 * .1, y: -e / 2 }, { x: -s / 2 - s / 2 * .1, y: -e / 2 }, { x: -s / 2, y: -e / 2 }, { x: -s / 2, y: e / 2 * 1.1 }, { x: -s / 2, y: -e / 2 }], x = f.polygon(p.map(b => [b.x, b.y]), d), w = o.insert(() => x, ":first-child"); return w.attr("class", "basic label-container outer-path"), u && t.look !== "handDrawn" && w.selectAll("path").attr("style", u), g && t.look !== "handDrawn" && w.selectAll("path").attr("style", g), w.attr("transform", `translate(0,${-l / 2})`), r.attr("transform", `translate(${-s / 2 + (t.padding ?? 0) + s / 2 * .1 / 2 - (n.x - (n.left ?? 0))},${-a / 2 + (t.padding ?? 0) - l / 2 - (n.y - (n.top ?? 0))})`), R(t, w), t.intersect = function (b) { return N.polygon(t, p, b); }, o; }); }
$(os, "linedWaveEdgedRect");
function hs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y, o = t.look === "neo" ? 10 : 5; (t.width || t.height) && (t.width = Math.max((t?.width ?? 0) - c * 2 - 2 * o, 10), t.height = Math.max((t?.height ?? 0) - m * 2 - 2 * o, 10)); let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = (t?.width ? t?.width : r.width) + c * 2 + 2 * o, l = (t?.height ? t?.height : r.height) + m * 2 + 2 * o, e = a - 2 * o, u = l - 2 * o, f = -e / 2, d = -u / 2, { cssStyles: p } = t, x = v.svg(n), w = I(t, {}), b = [{ x: f - o, y: d + o }, { x: f - o, y: d + u + o }, { x: f + e - o, y: d + u + o }, { x: f + e - o, y: d + u }, { x: f + e, y: d + u }, { x: f + e, y: d + u - o }, { x: f + e + o, y: d + u - o }, { x: f + e + o, y: d - o }, { x: f + o, y: d - o }, { x: f + o, y: d }, { x: f, y: d }, { x: f, y: d + o }], S = [{ x: f, y: d + o }, { x: f + e - o, y: d + o }, { x: f + e - o, y: d + u }, { x: f + e, y: d + u }, { x: f + e, y: d }, { x: f, y: d }]; t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid"); let k = V(b), M = x.path(k, w), P = V(S), A = x.path(P, w); t.look !== "handDrawn" && (M = jt(M), A = jt(A)); let D = n.insert("g", ":first-child"); return D.insert(() => M), D.insert(() => A), D.attr("class", "basic label-container outer-path"), p && t.look !== "handDrawn" && D.selectAll("path").attr("style", p), g && t.look !== "handDrawn" && D.selectAll("path").attr("style", g), s.attr("transform", `translate(${-(r.width / 2) - o - (r.x - (r.left ?? 0))}, ${-(r.height / 2) + o - (r.y - (r.top ?? 0))})`), R(t, D), t.intersect = function (H) { return N.polygon(t, b, H); }, n; }); }
$(hs, "multiRect");
function gs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = t.padding ?? 0, n = t.look === "neo" ? 16 : o, r = t.look === "neo" ? 12 : o, s = !0; (t.width || t.height) && (s = !1, t.width = (t?.width ?? 0) - n * 2, t.height = (t?.height ?? 0) - r * 3); let a = Math.max(c.width, t?.width ?? 0) + n * 2, l = Math.max(c.height, t?.height ?? 0) + r * 3, e = t.look === "neo" ? l / 4 : l / 8, u = l + (s ? e / 2 : -e / 2), f = -a / 2, d = -u / 2, p = 10, { cssStyles: x } = t, w = xt(f - p, d + u + p, f + a - p, d + u + p, e, .8), b = w?.[w.length - 1], S = [{ x: f - p, y: d + p }, { x: f - p, y: d + u + p }, ...w, { x: f + a - p, y: b.y - p }, { x: f + a, y: b.y - p }, { x: f + a, y: b.y - 2 * p }, { x: f + a + p, y: b.y - 2 * p }, { x: f + a + p, y: d - p }, { x: f + p, y: d - p }, { x: f + p, y: d }, { x: f, y: d }, { x: f, y: d + p }], k = [{ x: f, y: d + p }, { x: f + a - p, y: d + p }, { x: f + a - p, y: b.y - p }, { x: f + a, y: b.y - p }, { x: f + a, y: d }, { x: f, y: d }], M = v.svg(y), P = I(t, {}); t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid"); let A = V(S), D = M.path(A, P), H = V(k), z = M.path(H, P), G = y.insert(() => D, ":first-child"); return G.insert(() => z), G.attr("class", "basic label-container outer-path"), x && t.look !== "handDrawn" && G.selectAll("path").attr("style", x), g && t.look !== "handDrawn" && G.selectAll("path").attr("style", g), G.attr("transform", `translate(0,${-e / 2})`), m.attr("transform", `translate(${-(c.width / 2) - p - (c.x - (c.left ?? 0))}, ${-(c.height / 2) + p - e / 2 - (c.y - (c.top ?? 0))})`), R(t, G), t.intersect = function (E) { return N.polygon(t, S, E); }, y; }); }
$(gs, "multiWaveEdgedRectangle");
function ys(g, y, c) { return B(this, arguments, function* (h, t, { config: { themeVariables: i } }) { let { labelStyles: m, nodeStyles: o } = W(t); t.labelStyle = m, t.useHtmlLabels || St(vt()) || (t.centerLabel = !0); let { shapeSvg: r, bbox: s, label: a } = yield X(h, t, Y(t)), l = Math.max(s.width + (t.padding ?? 0) * 2, t?.width ?? 0), e = Math.max(s.height + (t.padding ?? 0) * 2, t?.height ?? 0), u = -l / 2, f = -e / 2, { cssStyles: d } = t, p = v.svg(r), x = I(t, { fill: i.noteBkgColor, stroke: i.noteBorderColor }); t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid"); let w = p.rectangle(u, f, l, e, x), b = r.insert(() => w, ":first-child"); return b.attr("class", "basic label-container outer-path"), a.attr("class", "label noteLabel"), d && t.look !== "handDrawn" && b.selectAll("path").attr("style", d), o && t.look !== "handDrawn" && b.selectAll("path").attr("style", o), a.attr("transform", `translate(${-s.width / 2 - (s.x - (s.left ?? 0))}, ${-(s.height / 2) - (s.y - (s.top ?? 0))})`), R(t, b), t.intersect = function (S) { return N.rect(t, S); }, r; }); }
$(ys, "note");
var ye = $((h, t, i) => [`M${h + i / 2},${t}`, `L${h + i},${t - i / 2}`, `L${h + i / 2},${t - i}`, `L${h},${t - i / 2}`, "Z"].join(" "), "createDecisionBoxPathD");
function fs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c } = yield X(h, t, Y(t)), m = c.width + (t.padding ?? 0), o = c.height + (t.padding ?? 0), n = m + o, r = .5, s = [{ x: n / 2, y: 0 }, { x: n, y: -n / 2 }, { x: n / 2, y: -n }, { x: 0, y: -n / 2 }], a, { cssStyles: l } = t; if (t.look === "handDrawn") {
    let e = v.svg(y), u = I(t, {}), f = ye(0, 0, n), d = e.path(f, u);
    a = y.insert(() => d, ":first-child").attr("transform", `translate(${-n / 2 + r}, ${n / 2})`), l && a.attr("style", l);
}
else
    a = gt(y, n, n, s), a.attr("transform", `translate(${-n / 2 + r}, ${n / 2})`); return g && a.attr("style", g), R(t, a), t.calcIntersect = function (e, u) { let f = e.width, d = [{ x: f / 2, y: 0 }, { x: f, y: -f / 2 }, { x: f / 2, y: -f }, { x: 0, y: -f / 2 }], p = N.polygon(e, d, u); return { x: p.x - .5, y: p.y - .5 }; }, t.intersect = function (e) { return this.calcIntersect(t, e); }, y; }); }
$(fs, "question");
function ps(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 21 : y ?? 0, m = t.look === "neo" ? 12 : y ?? 0, { shapeSvg: o, bbox: n, label: r } = yield X(h, t, Y(t)), s = n.width + (t.look === "neo" ? c * 2 : c), a = Math.max(n.height + (t.look === "neo" ? m * 2 : m), t.height ?? 0), l = a / 4, u = -Math.max(s, (t.width ?? 0) - l) / 2, f = -a / 2, d = f / 2, p = [{ x: u + d, y: f }, { x: u, y: 0 }, { x: u + d, y: -f }, { x: -u, y: -f }, { x: -u, y: f }], { cssStyles: x } = t, w = v.svg(o), b = I(t, {}); t.look !== "handDrawn" && (b.roughness = 0, b.fillStyle = "solid"); let S = V(p), k = w.path(S, b), M = o.insert(() => k, ":first-child"); return M.attr("class", "basic label-container outer-path"), x && t.look !== "handDrawn" && M.selectAll("path").attr("style", x), g && t.look !== "handDrawn" && M.selectAll("path").attr("style", g), M.attr("transform", `translate(${-d / 2},0)`), r.attr("transform", `translate(${-d / 2 - n.width / 2 - (n.x - (n.left ?? 0))}, ${-(n.height / 2) - (n.y - (n.top ?? 0))})`), R(t, M), t.intersect = function (P) { return N.polygon(t, p, P); }, o; }); }
$(ps, "rect_left_inv_arrow");
function us(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y; t.cssClasses ? y = "node " + t.cssClasses : y = "node default"; let c = h.insert("g").attr("class", y).attr("id", t.domId || t.id), m = c.insert("g"), o = c.insert("g").attr("class", "label").attr("style", g), n = t.description, r = t.label, s = yield ra(o, r, t.labelStyle, !0, !0), a = { width: 0, height: 0 }; if (St(Q())) {
    let P = s.children[0], A = J(s);
    a = P.getBoundingClientRect(), A.attr("width", a.width), A.attr("height", a.height);
} U.info("Text 2", n); let l = n || [], e = s.getBBox(), u = yield ra(o, Array.isArray(l) ? l.join("<br/>") : l, t.labelStyle, !0, !0), f = u.children[0], d = J(u); a = f.getBoundingClientRect(), d.attr("width", a.width), d.attr("height", a.height); let p = (t.padding || 0) / 2; J(u).attr("transform", "translate( " + (a.width > e.width ? 0 : (e.width - a.width) / 2) + ", " + (e.height + p + 5) + ")"), J(s).attr("transform", "translate( " + (a.width < e.width ? 0 : -(e.width - a.width) / 2) + ", 0)"), a = o.node().getBBox(), o.attr("transform", "translate(" + -a.width / 2 + ", " + (-a.height / 2 - p + 3) + ")"); let x = a.width + (t.padding || 0), w = a.height + (t.padding || 0), b = -a.width / 2 - p, S = -a.height / 2 - p, k, M; if (t.look === "handDrawn") {
    let P = v.svg(c), A = I(t, {}), D = P.path(ut(b, S, x, w, t.rx || 0), A), H = P.line(-a.width / 2 - p, -a.height / 2 - p + e.height + p, a.width / 2 + p, -a.height / 2 - p + e.height + p, A);
    M = c.insert(() => (U.debug("Rough node insert CXC", D), H), ":first-child"), k = c.insert(() => (U.debug("Rough node insert CXC", D), D), ":first-child");
}
else
    k = m.insert("rect", ":first-child"), M = m.insert("line"), k.attr("class", "outer title-state").attr("style", g).attr("x", -a.width / 2 - p).attr("y", -a.height / 2 - p).attr("width", a.width + (t.padding || 0)).attr("height", a.height + (t.padding || 0)), M.attr("class", "divider").attr("x1", -a.width / 2 - p).attr("x2", a.width / 2 + p).attr("y1", -a.height / 2 - p + e.height + p).attr("y2", -a.height / 2 - p + e.height + p); return R(t, k), t.intersect = function (P) { return N.rect(t, P); }, c; }); }
$(us, "rectWithTitle");
function ds(g, y, c) { return B(this, arguments, function* (h, t, { config: { themeVariables: i } }) { let m = i?.radius ?? 5, o = { rx: m, ry: m, classes: "", labelPaddingX: (t?.padding ?? 0) * 1, labelPaddingY: (t?.padding ?? 0) * 1 }; return Nt(h, t, o); }); }
$(ds, "roundedRect");
var $t = 8;
function ms(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.look === "neo" ? 16 : t.padding ?? 0, c = t.look === "neo" ? 12 : t.padding ?? 0, { shapeSvg: m, bbox: o, label: n } = yield X(h, t, Y(t)), r = (t?.width ?? o.width) + y * 2 + (t.look === "neo" ? $t : $t * 2), s = (t?.height ?? o.height) + c * 2, a = r - $t, l = s, e = $t - r / 2, u = -s / 2, { cssStyles: f } = t, d = v.svg(m), p = I(t, {}); t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid"); let x = [{ x: e, y: u }, { x: e + a, y: u }, { x: e + a, y: u + l }, { x: e - $t, y: u + l }, { x: e - $t, y: u }, { x: e, y: u }, { x: e, y: u + l }], w = d.polygon(x.map(S => [S.x, S.y]), p), b = m.insert(() => w, ":first-child"); return b.attr("class", "basic label-container outer-path").attr("style", et(f)), g && t.look !== "handDrawn" && b.selectAll("path").attr("style", g), f && t.look !== "handDrawn" && b.selectAll("path").attr("style", g), n.attr("transform", `translate(${$t / 2 - o.width / 2 - (o.x - (o.left ?? 0))}, ${-(o.height / 2) - (o.y - (o.top ?? 0))})`), R(t, b), t.intersect = function (S) { return N.rect(t, S); }, m; }); }
$(ms, "shadedProcess");
function xs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y; (t.width || t.height) && (t.width = Math.max((t?.width ?? 0) - c * 2, 10), t.height = Math.max((t?.height ?? 0) / 1.5 - m * 2, 10)); let { shapeSvg: o, bbox: n, label: r } = yield X(h, t, Y(t)), s = (t?.width ? t?.width : n.width) + c * 2, a = ((t?.height ? t?.height : n.height) + m * 2) * 1.5, l = s, e = a / 1.5, u = -l / 2, f = -e / 2, { cssStyles: d } = t, p = v.svg(o), x = I(t, {}); t.look !== "handDrawn" && (x.roughness = 0, x.fillStyle = "solid"); let w = [{ x: u, y: f }, { x: u, y: f + e }, { x: u + l, y: f + e }, { x: u + l, y: f - e / 2 }], b = V(w), S = p.path(b, x), k = o.insert(() => S, ":first-child"); return k.attr("class", "basic label-container  outer-path"), d && t.look !== "handDrawn" && k.selectChildren("path").attr("style", d), g && t.look !== "handDrawn" && k.selectChildren("path").attr("style", g), k.attr("transform", `translate(0, ${e / 4})`), r.attr("transform", `translate(${-l / 2 + (t.padding ?? 0) - (n.x - (n.left ?? 0))}, ${-e / 4 + (t.padding ?? 0) - (n.y - (n.top ?? 0))})`), R(t, k), t.intersect = function (M) { return N.polygon(t, w, M); }, o; }); }
$(xs, "slopedRect");
function ws(h, t) { return B(this, null, function* () { let i = t.padding ?? 0, g = t.look === "neo" ? 16 : i * 2, y = t.look === "neo" ? 12 : i, c = { rx: 0, ry: 0, classes: "", labelPaddingX: t.labelPaddingX ?? g, labelPaddingY: y }; return Nt(h, t, c); }); }
$(ws, "squareRect");
function bs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 20 : y, m = t.look === "neo" ? 12 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = n.height + (t.look === "neo" ? m * 2 : m), s = n.width + r / 4 + (t.look === "neo" ? c * 2 : c), a = r / 2, { cssStyles: l } = t, e = v.svg(o), u = I(t, {}); t.look !== "handDrawn" && (u.roughness = 0, u.fillStyle = "solid"); let f = [{ x: -s / 2 + a, y: -r / 2 }, { x: s / 2 - a, y: -r / 2 }, ...ht(-s / 2 + a, 0, a, 50, 90, 270), { x: s / 2 - a, y: r / 2 }, ...ht(s / 2 - a, 0, a, 50, 270, 450)], d = V(f), p = e.path(d, u), x = o.insert(() => p, ":first-child"); return x.attr("class", "basic label-container outer-path"), l && t.look !== "handDrawn" && x.selectChildren("path").attr("style", l), g && t.look !== "handDrawn" && x.selectChildren("path").attr("style", g), R(t, x), t.intersect = function (w) { return N.polygon(t, f, w); }, o; }); }
$(bs, "stadium");
function Ss(h, t) { return B(this, null, function* () { let i = { rx: t.look === "neo" ? 3 : 5, ry: t.look === "neo" ? 3 : 5, classes: "flowchart-node" }; return Nt(h, t, i); }); }
$(Ss, "state");
function $s(h, t, { config: { themeVariables: i } }) { let { labelStyles: g, nodeStyles: y } = W(t); t.labelStyle = g; let { cssStyles: c } = t, { lineColor: m, stateBorder: o, nodeBorder: n, nodeShadow: r } = i; (t.width || t.height) && ((t.width ?? 0) < 14 && (t.width = 14), (t.height ?? 0) < 14 && (t.height = 14)), t.width || (t.width = 14), t.height || (t.height = 14); let s = h.insert("g").attr("class", "node default").attr("id", t.domId ?? t.id), a = v.svg(s), l = I(t, {}); t.look !== "handDrawn" && (l.roughness = 0, l.fillStyle = "solid"); let e = a.circle(0, 0, t.width, nt(it({}, l), { stroke: m, strokeWidth: 2 })), u = o ?? n, f = (t.width ?? 0) * 5 / 14, d = a.circle(0, 0, f, nt(it({}, l), { fill: u, stroke: u, strokeWidth: 2, fillStyle: "solid" })), p = s.insert(() => e, ":first-child"); if (p.insert(() => d), t.look !== "handDrawn" && p.attr("class", "outer-path"), c && p.selectAll("path").attr("style", c), y && p.selectAll("path").attr("style", y), t.width < 25 && r && t.look !== "handDrawn") {
    let x = h.node()?.ownerSVGElement?.id ?? "", w = x ? `${x}-drop-shadow-small` : "drop-shadow-small";
    p.attr("style", `filter:url(#${w})`);
} return R(t, p), t.intersect = function (x) { return N.circle(t, (t.width ?? 0) / 2, x); }, s; }
$($s, "stateEnd");
function vs(h, t, { config: { themeVariables: i } }) { let { lineColor: g, nodeShadow: y } = i; (t.width || t.height) && ((t.width ?? 0) < 14 && (t.width = 14), (t.height ?? 0) < 14 && (t.height = 14)), t.width || (t.width = 14), t.height || (t.height = 14); let c = h.insert("g").attr("class", "node default").attr("id", t.domId || t.id), m; if (t.look === "handDrawn") {
    let n = v.svg(c).circle(0, 0, t.width, aa(g));
    m = c.insert(() => n), m.attr("class", "state-start").attr("r", (t.width ?? 7) / 2).attr("width", t.width ?? 14).attr("height", t.height ?? 14);
}
else
    m = c.insert("circle", ":first-child"), m.attr("class", "state-start").attr("r", (t.width ?? 7) / 2).attr("width", t.width ?? 14).attr("height", t.height ?? 14); if (t.width < 25 && y && t.look !== "handDrawn") {
    let o = h.node()?.ownerSVGElement?.id ?? "", n = o ? `${o}-drop-shadow-small` : "drop-shadow-small";
    m.attr("style", `filter:url(#${n})`);
} return R(t, m), t.intersect = function (o) { return N.circle(t, (t.width ?? 7) / 2, o); }, c; }
$(vs, "stateStart");
var Pt = 8;
function ks(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t?.padding ?? 8, c = t.look === "neo" ? 28 : y, m = t.look === "neo" ? 12 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = Math.max(n.width + 2 * Pt + c, t.width ?? 0), s = Math.max(n.height + m, t.height ?? 0), a = r - 2 * Pt, l = s, e = -r / 2, u = -s / 2, f = [{ x: 0, y: 0 }, { x: a, y: 0 }, { x: a, y: -l }, { x: 0, y: -l }, { x: 0, y: 0 }, { x: -8, y: 0 }, { x: a + 8, y: 0 }, { x: a + 8, y: -l }, { x: -8, y: -l }, { x: -8, y: 0 }]; if (t.look === "handDrawn") {
    let d = v.svg(o), p = I(t, {}), x = d.rectangle(e, u, a + 16, l, p), w = d.line(e + Pt, u, e + Pt, u + l, p), b = d.line(e + Pt + a, u, e + Pt + a, u + l, p);
    o.insert(() => w, ":first-child"), o.insert(() => b, ":first-child");
    let S = o.insert(() => x, ":first-child"), { cssStyles: k } = t;
    S.attr("class", "basic label-container").attr("style", et(k)), R(t, S);
}
else {
    let d = gt(o, a, l, f);
    g && d.attr("style", g), R(t, d);
} return t.intersect = function (d) { return N.polygon(t, f, d); }, o; }); }
$(ks, "subroutine");
var Ft = .2;
function Ps(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y; (t.width || t.height) && (t.height = Math.max((t?.height ?? 0) - m * 2, 10), t.width = Math.max((t?.width ?? 0) - c * 2 - Ft * (t.height + m * 2), 10)); let { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = (t?.height ? t?.height : n.height) + m * 2, s = Ft * r, a = Ft * r, e = (t?.width ? t?.width : n.width) + c * 2 + s - s, u = r, f = -e / 2, d = -u / 2, { cssStyles: p } = t, x = v.svg(o), w = I(t, {}), b = [{ x: f - s / 2, y: d }, { x: f + e + s / 2, y: d }, { x: f + e + s / 2, y: d + u }, { x: f - s / 2, y: d + u }], S = [{ x: f + e - s / 2, y: d + u }, { x: f + e + s / 2, y: d + u }, { x: f + e + s / 2, y: d + u - a }]; t.look !== "handDrawn" && (w.roughness = 0, w.fillStyle = "solid"); let k = V(b), M = x.path(k, w), P = V(S), A = x.path(P, nt(it({}, w), { fillStyle: "solid" })), D = o.insert(() => A, ":first-child"); return D.insert(() => M, ":first-child"), D.attr("class", "basic label-container outer-path"), p && t.look !== "handDrawn" && D.selectAll("path").attr("style", p), g && t.look !== "handDrawn" && D.selectAll("path").attr("style", g), R(t, D), t.intersect = function (H) { return N.polygon(t, b, H); }, o; }); }
$(Ps, "taggedRect");
function Ms(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c, label: m } = yield X(h, t, Y(t)), o = Math.max(c.width + (t.padding ?? 0) * 2, t?.width ?? 0), n = Math.max(c.height + (t.padding ?? 0) * 2, t?.height ?? 0), r = n / 8, s = .2 * o, a = .2 * n, l = n + r, { cssStyles: e } = t, u = v.svg(y), f = I(t, {}); t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid"); let d = [{ x: -o / 2 - o / 2 * .1, y: l / 2 }, ...xt(-o / 2 - o / 2 * .1, l / 2, o / 2 + o / 2 * .1, l / 2, r, .8), { x: o / 2 + o / 2 * .1, y: -l / 2 }, { x: -o / 2 - o / 2 * .1, y: -l / 2 }], p = -o / 2 + o / 2 * .1, x = -l / 2 - a * .4, w = [{ x: p + o - s, y: (x + n) * 1.3 }, { x: p + o, y: x + n - a }, { x: p + o, y: (x + n) * .9 }, ...xt(p + o, (x + n) * 1.25, p + o - s, (x + n) * 1.3, -n * .02, .5)], b = V(d), S = u.path(b, f), k = V(w), M = u.path(k, nt(it({}, f), { fillStyle: "solid" })), P = y.insert(() => M, ":first-child"); return P.insert(() => S, ":first-child"), P.attr("class", "basic label-container outer-path"), e && t.look !== "handDrawn" && P.selectAll("path").attr("style", e), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), P.attr("transform", `translate(0,${-r / 2})`), m.attr("transform", `translate(${-o / 2 + (t.padding ?? 0) - (c.x - (c.left ?? 0))},${-n / 2 + (t.padding ?? 0) - r / 2 - (c.y - (c.top ?? 0))})`), R(t, P), t.intersect = function (A) { return N.polygon(t, d, A); }, y; }); }
$(Ms, "taggedWaveEdgedRectangle");
function Ds(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let { shapeSvg: y, bbox: c } = yield X(h, t, Y(t)), m = Math.max(c.width + (t.padding ?? 0), t?.width || 0), o = Math.max(c.height + (t.padding ?? 0), t?.height || 0), n = -m / 2, r = -o / 2, s = y.insert("rect", ":first-child"); return s.attr("class", "text").attr("style", g).attr("rx", 0).attr("ry", 0).attr("x", n).attr("y", r).attr("width", m).attr("height", o), R(t, s), t.intersect = function (a) { return N.rect(t, a); }, y; }); }
$(Ds, "text");
var fe = $((h, t, i, g, y, c) => `M${h},${t}
    a${y},${c} 0,0,1 0,${-g}
    l${i},0
    a${y},${c} 0,0,1 0,${g}
    M${i},${-g}
    a${y},${c} 0,0,0 0,${g}
    l${-i},0`, "createCylinderPathD"), pe = $((h, t, i, g, y, c) => [`M${h},${t}`, `M${h + i},${t}`, `a${y},${c} 0,0,0 0,${-g}`, `l${-i},0`, `a${y},${c} 0,0,0 0,${g}`, `l${i},0`].join(" "), "createOuterCylinderPathD"), ue = $((h, t, i, g, y, c) => [`M${h + i / 2},${-g / 2}`, `a${y},${c} 0,0,0 0,${g}`].join(" "), "createInnerCylinderPathD"), ya = 5, fa = 10;
function Ns(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 12 : y / 2, m = t.height ?? 0; if (t.height && (t.height = t.height - c, t.height < ya && (t.height = ya)), t.width) {
    let p = m / 2 / (2.5 + m / 50);
    t.width = t.width - c - p * 3, t.width < fa && (t.width = fa);
} let { shapeSvg: o, bbox: n, label: r } = yield X(h, t, Y(t)), s = Math.max(t.height ?? 0, n.height) + c, a = s / 2, l = a / (2.5 + s / 50), e = Math.max(t.width ?? 0, n.width) + l + c, { cssStyles: u } = t, f; if (t.look === "handDrawn") {
    let d = v.svg(o), p = pe(0, 0, e, s, l, a), x = ue(0, 0, e, s, l, a), w = d.path(p, I(t, {})), b = d.path(x, I(t, { fill: "none" }));
    f = o.insert(() => b, ":first-child"), f = o.insert(() => w, ":first-child"), f.attr("class", "basic label-container"), u && f.attr("style", u);
}
else {
    let d = fe(0, 0, e, s, l, a);
    f = o.insert("path", ":first-child").attr("d", d).attr("class", "basic label-container").attr("style", et(u)).attr("style", g), f.attr("class", "basic label-container outer-path"), u && f.selectAll("path").attr("style", u), g && f.selectAll("path").attr("style", g);
} return f.attr("label-offset-x", l), f.attr("transform", `translate(${-e / 2}, ${s / 2} )`), r.attr("transform", `translate(${-(n.width / 2) - l - (n.x - (n.left ?? 0))}, ${-(n.height / 2) - (n.y - (n.top ?? 0))})`), R(t, f), t.intersect = function (d) { let p = N.rect(t, d), x = p.y - (t.y ?? 0); if (a != 0 && (Math.abs(x) < (t.height ?? 0) / 2 || Math.abs(x) == (t.height ?? 0) / 2 && Math.abs(p.x - (t.x ?? 0)) > (t.width ?? 0) / 2 - l)) {
    let w = l * l * (1 - x * x / (a * a));
    w != 0 && (w = Math.sqrt(Math.abs(w))), w = l - w, d.x - (t.x ?? 0) > 0 && (w = -w), p.x += w;
} return p; }, o; }); }
$(Ns, "tiltedCylinder");
function Bs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = (t.look === "neo", y), m = t.look === "neo" ? y * 2 : y, { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = Math.max(n.height + c, t.height ?? 0), s = Math.max(n.width + m, (t.width ?? 0) - r), a = [{ x: -3 * r / 6, y: 0 }, { x: s + 3 * r / 6, y: 0 }, { x: s, y: -r }, { x: 0, y: -r }], l, { cssStyles: e } = t; if (t.look === "handDrawn") {
    let u = v.svg(o), f = I(t, {}), d = V(a), p = u.path(d, f);
    l = o.insert(() => p, ":first-child").attr("transform", `translate(${-s / 2}, ${r / 2})`), e && l.attr("style", e);
}
else
    l = gt(o, s, r, a); return g && l.attr("style", g), t.width = s, t.height = r, R(t, l), t.intersect = function (u) { return N.polygon(t, a, u); }, o; }); }
$(Bs, "trapezoid");
function Cs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y, o = 15, n = 5; (t.width || t.height) && (t.height = (t.height ?? 0) - m * 2, t.height < n && (t.height = n), t.width = (t.width ?? 0) - c * 2, t.width < o && (t.width = o)); let { shapeSvg: r, bbox: s } = yield X(h, t, Y(t)), a = (t?.width ? t?.width : s.width) + c * 2, l = (t?.height ? t?.height : s.height) + m * 2, { cssStyles: e } = t, u = v.svg(r), f = I(t, {}); t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid"); let d = [{ x: -a / 2 * .8, y: -l / 2 }, { x: a / 2 * .8, y: -l / 2 }, { x: a / 2, y: -l / 2 * .6 }, { x: a / 2, y: l / 2 }, { x: -a / 2, y: l / 2 }, { x: -a / 2, y: -l / 2 * .6 }], p = V(d), x = u.path(p, f), w = r.insert(() => x, ":first-child"); return w.attr("class", "basic label-container outer-path"), e && t.look !== "handDrawn" && w.selectChildren("path").attr("style", e), g && t.look !== "handDrawn" && w.selectChildren("path").attr("style", g), R(t, w), t.intersect = function (b) { return N.polygon(t, d, b); }, r; }); }
$(Cs, "trapezoidalPentagon");
var pa = 10, ua = 10;
function As(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? y * 2 : y; (t.width || t.height) && (t.width = ((t?.width ?? 0) - c) / 2, t.width < ua && (t.width = ua), t.height = t?.height ?? 0, t.height < pa && (t.height = pa)); let { shapeSvg: m, bbox: o, label: n } = yield X(h, t, Y(t)), r = bt(Q().flowchart?.htmlLabels), s = (t?.width ? t?.width : o.width) + c, a = t?.height ? t?.height : s + o.height, l = a, e = [{ x: 0, y: 0 }, { x: l, y: 0 }, { x: l / 2, y: -a }], { cssStyles: u } = t, f = v.svg(m), d = I(t, {}); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let p = V(e), x = f.path(p, d), w = m.insert(() => x, ":first-child").attr("transform", `translate(${-a / 2}, ${a / 2})`).attr("class", "outer-path"); return u && t.look !== "handDrawn" && w.selectChildren("path").attr("style", u), g && t.look !== "handDrawn" && w.selectChildren("path").attr("style", g), t.width = s, t.height = a, R(t, w), n.attr("transform", `translate(${-o.width / 2 - (o.x - (o.left ?? 0))}, ${a / 2 - (o.height + (t.padding ?? 0) / (r ? 2 : 1) - (o.y - (o.top ?? 0)))})`), t.intersect = function (b) { return U.info("Triangle intersect", t, e, b), N.polygon(t, e, b); }, m; }); }
$(As, "triangle");
function Rs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 12 : y, o = !0; (t.width || t.height) && (o = !1, t.width = (t?.width ?? 0) - c * 2, t.width < 10 && (t.width = 10), t.height = (t?.height ?? 0) - m * 2, t.height < 10 && (t.height = 10)); let { shapeSvg: n, bbox: r, label: s } = yield X(h, t, Y(t)), a = (t?.width ? t?.width : r.width) + (c ?? 0) * 2, l = (t?.height ? t?.height : r.height) + (m ?? 0) * 2, e = t.look === "neo" ? l / 4 : l / 8, u = l + (o ? e : -e), { cssStyles: f } = t, p = 14 - a, x = p > 0 ? p / 2 : 0, w = v.svg(n), b = I(t, {}); t.look !== "handDrawn" && (b.roughness = 0, b.fillStyle = "solid"); let S = [{ x: -a / 2 - x, y: u / 2 }, ...xt(-a / 2 - x, u / 2, a / 2 + x, u / 2, e, .8), { x: a / 2 + x, y: -u / 2 }, { x: -a / 2 - x, y: -u / 2 }], k = V(S), M = w.path(k, b), P = n.insert(() => M, ":first-child"); return P.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && P.selectAll("path").attr("style", f), g && t.look !== "handDrawn" && P.selectAll("path").attr("style", g), P.attr("transform", `translate(0,${-e / 2})`), s.attr("transform", `translate(${-a / 2 + (t.padding ?? 0) - (r.x - (r.left ?? 0))},${-l / 2 + (t.padding ?? 0) - e - (r.y - (r.top ?? 0))})`), R(t, P), t.intersect = function (A) { return N.polygon(t, S, A); }, n; }); }
$(Rs, "waveEdgedRectangle");
function Hs(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t.padding ?? 0, c = t.look === "neo" ? 16 : y, m = t.look === "neo" ? 20 : y; if (t.width || t.height) {
    t.width = t?.width ?? 0, t.width < 20 && (t.width = 20), t.height = t?.height ?? 0, t.height < 10 && (t.height = 10);
    let b = Math.min(t.height * .2, t.height / 4);
    t.height = Math.ceil(t.height - m - b * (20 / 9)), t.width = t.width - c * 2;
} let { shapeSvg: o, bbox: n } = yield X(h, t, Y(t)), r = (t?.width ? t?.width : n.width) + c * 2, s = (t?.height ? t?.height : n.height) + m, a = s / 8, l = s + a * 2, { cssStyles: e } = t, u = v.svg(o), f = I(t, {}); t.look !== "handDrawn" && (f.roughness = 0, f.fillStyle = "solid"); let d = [{ x: -r / 2, y: l / 2 }, ...xt(-r / 2, l / 2, r / 2, l / 2, a, 1), { x: r / 2, y: -l / 2 }, ...xt(r / 2, -l / 2, -r / 2, -l / 2, a, -1)], p = V(d), x = u.path(p, f), w = o.insert(() => x, ":first-child"); return w.attr("class", "basic label-container"), e && t.look !== "handDrawn" && w.selectAll("path").attr("style", e), g && t.look !== "handDrawn" && w.selectAll("path").attr("style", g), R(t, w), t.intersect = function (b) { return N.polygon(t, d, b); }, o; }); }
$(Hs, "waveRectangle");
var K = 10;
function Is(h, t) {
    return B(this, null, function* () {
        let { labelStyles: i, nodeStyles: g } = W(t);
        t.labelStyle = i;
        let y = t.look === "neo" ? 16 : t.padding ?? 0, c = t.look === "neo" ? 12 : t.padding ?? 0;
        (t.width || t.height) && (t.width = Math.max((t?.width ?? 0) - y * 2 - K, 10), t.height = Math.max((t?.height ?? 0) - c * 2 - K, 10));
        let { shapeSvg: m, bbox: o, label: n } = yield X(h, t, Y(t)), r = (t?.width ? t?.width : o.width) + y * 2 + K, s = (t?.height ? t?.height : o.height) + c * 2 + K, a = r - K, l = s - K, e = -a / 2, u = -l / 2, { cssStyles: f } = t, d = v.svg(m), p = I(t, {}), x = [{ x: e - K, y: u - K }, { x: e - K, y: u + l }, { x: e + a, y: u + l }, { x: e + a, y: u - K }], w = `M${e - K},${u - K} L${e + a},${u - K} L${e + a},${u + l} L${e - K},${u + l} L${e - K},${u - K}
                M${e - K},${u} L${e + a},${u}
                M${e},${u - K} L${e},${u + l}`;
        t.look !== "handDrawn" && (p.roughness = 0, p.fillStyle = "solid");
        let b = d.path(w, p), S = m.insert(() => b, ":first-child");
        return S.attr("transform", `translate(${K / 2}, ${K / 2})`), S.attr("class", "basic label-container outer-path"), f && t.look !== "handDrawn" && S.selectAll("path").attr("style", f), g && t.look !== "handDrawn" && S.selectAll("path").attr("style", g), n.attr("transform", `translate(${-(o.width / 2) + K / 2 - (o.x - (o.left ?? 0))}, ${-(o.height / 2) + K / 2 - (o.y - (o.top ?? 0))})`), R(t, S), t.intersect = function (k) { return N.polygon(t, x, k); }, m;
    });
}
$(Is, "windowPane");
var da = new Set(["redux-color", "redux-dark-color"]), de = new Set(["redux", "redux-dark", "redux-color", "redux-dark-color"]);
function Kt(h, t) { return B(this, null, function* () { let i = t; i.alias && (t.label = i.alias); let { theme: g, themeVariables: y } = vt(), { rowEven: c, rowOdd: m, nodeBorder: o, borderColorArray: n } = y; if (t.look === "handDrawn") {
    let { themeVariables: q } = vt(), { background: Z } = q, at = nt(it({}, t), { id: t.id + "-background", domId: (t.domId || t.id) + "-background", look: "default", cssStyles: ["stroke: none", `fill: ${Z}`] });
    yield Kt(h, at);
} let r = vt(); t.useHtmlLabels = r.htmlLabels; let s = r.er?.diagramPadding ?? 10, a = r.er?.entityPadding ?? 6, { cssStyles: l } = t, { labelStyles: e, nodeStyles: u } = W(t); if (i.attributes.length === 0 && t.label) {
    let q = { rx: 0, ry: 0, labelPaddingX: s, labelPaddingY: s * 1.5, classes: "" };
    At(t.label, r) + q.labelPaddingX * 2 < r.er.minEntityWidth && (t.width = r.er.minEntityWidth);
    let Z = yield Nt(h, t, q);
    if (g != null && da.has(g)) {
        let at = i.colorIndex ?? 0;
        Z.attr("data-color-id", `color-${at % n.length}`);
    }
    if (!bt(r.htmlLabels)) {
        let at = Z.select("text"), lt = at.node()?.getBBox();
        at.attr("transform", `translate(${-lt.width / 2}, 0)`);
    }
    return Z;
} r.htmlLabels || (s *= 1.25, a *= 1.25); let f = Y(t); f || (f = "node default"); let d = h.insert("g").attr("class", f).attr("id", t.domId || t.id), p = yield Mt(d, t.label ?? "", r, 0, 0, ["name"], e); p.height += a; let x = 0, w = [], b = [], S = 0, k = 0, M = 0, P = 0, A = !0, D = !0; for (let q of i.attributes) {
    let Z = yield Mt(d, q.type, r, 0, x, ["attribute-type"], e);
    S = Math.max(S, Z.width + s);
    let at = yield Mt(d, q.name, r, 0, x, ["attribute-name"], e);
    k = Math.max(k, at.width + s);
    let lt = yield Mt(d, q.keys.join(), r, 0, x, ["attribute-keys"], e);
    M = Math.max(M, lt.width + s);
    let wt = yield Mt(d, q.comment, r, 0, x, ["attribute-comment"], e);
    P = Math.max(P, wt.width + s);
    let dt = Math.max(Z.height, at.height, lt.height, wt.height) + a;
    b.push({ yOffset: x, rowHeight: dt }), x += dt;
} let H = 4; M <= s && (A = !1, M = 0, H--), P <= s && (D = !1, P = 0, H--); let z = d.node().getBBox(); if (p.width + s * 2 - (S + k + M + P) > 0) {
    let q = p.width + s * 2 - (S + k + M + P);
    S += q / H, k += q / H, M > 0 && (M += q / H), P > 0 && (P += q / H);
} let G = S + k + M + P, E = v.svg(d), L = I(t, {}); t.look !== "handDrawn" && (L.roughness = 0, L.fillStyle = "solid"); let T = 0; b.length > 0 && (T = b.reduce((q, Z) => q + (Z?.rowHeight ?? 0), 0)); let O = Math.max(z.width + s * 2, t?.width || 0, G), F = Math.max((T ?? 0) + p.height, t?.height || 0), C = -O / 2, _ = -F / 2; if (d.selectAll("g:not(:first-child)").each((q, Z, at) => { let lt = J(at[Z]), wt = lt.attr("transform"), dt = 0, Ut = 0; if (wt) {
    let Wt = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(wt);
    Wt && (dt = parseFloat(Wt[1]), Ut = parseFloat(Wt[2]), lt.attr("class").includes("attribute-name") ? dt += S : lt.attr("class").includes("attribute-keys") ? dt += S + k : lt.attr("class").includes("attribute-comment") && (dt += S + k + M));
} lt.attr("transform", `translate(${C + s / 2 + dt}, ${Ut + _ + p.height + a / 2})`); }), d.select(".name").attr("transform", "translate(" + -p.width / 2 + ", " + (_ + a / 2) + ")"), g != null && da.has(g)) {
    let q = i.colorIndex ?? 0;
    d.attr("data-color-id", `color-${q % n.length}`);
} let j = E.rectangle(C, _, O, F, L), tt = d.insert(() => j, ":first-child").attr("class", "outer-path").attr("style", l.join("")); w.push(0); for (let [q, Z] of b.entries()) {
    let lt = (q + 1) % 2 === 0 && Z.yOffset !== 0, wt = E.rectangle(C, p.height + _ + Z?.yOffset, O, Z?.rowHeight, nt(it({}, L), { fill: lt ? c : m, stroke: o }));
    d.insert(() => wt, "g.label").attr("style", l.join("")).attr("class", `row-rect-${lt ? "even" : "odd"}`);
} let st = 1e-4, ct = Dt(C, p.height + _, O + C, p.height + _, st), yt = E.polygon(ct.map(q => [q.x, q.y]), L); if (d.insert(() => yt).attr("class", "divider"), ct = Dt(S + C, p.height + _, S + C, F + _, st), yt = E.polygon(ct.map(q => [q.x, q.y]), L), d.insert(() => yt).attr("class", "divider"), A) {
    let q = S + k + C;
    ct = Dt(q, p.height + _, q, F + _, st), yt = E.polygon(ct.map(Z => [Z.x, Z.y]), L), d.insert(() => yt).attr("class", "divider");
} if (D) {
    let q = S + k + M + C;
    ct = Dt(q, p.height + _, q, F + _, st), yt = E.polygon(ct.map(Z => [Z.x, Z.y]), L), d.insert(() => yt).attr("class", "divider");
} for (let q of w) {
    let Z = p.height + _ + q;
    ct = Dt(C, Z, O + C, Z, st), yt = E.polygon(ct.map(at => [at.x, at.y]), L), d.insert(() => yt).attr("class", "divider");
} if (R(t, tt), u && t.look !== "handDrawn")
    if (g != null && de.has(g))
        d.selectAll("path").attr("style", u);
    else {
        let Z = u.split(";")?.filter(at => at.includes("stroke"))?.map(at => `${at}`).join("; ");
        d.selectAll("path").attr("style", Z ?? ""), d.selectAll(".row-rect-even path").attr("style", u);
    } return t.intersect = function (q) { return N.rect(t, q); }, d; }); }
$(Kt, "erBox");
function Mt(o, n, r) { return B(this, arguments, function* (h, t, i, g = 0, y = 0, c = [], m = "") { let s = h.insert("g").attr("class", `label ${c.join(" ")}`).attr("transform", `translate(${g}, ${y})`).attr("style", m); t !== Et(t) && (t = Et(t), t = t.replaceAll("<", "&lt;").replaceAll(">", "&gt;")); let a = s.node().appendChild(yield mt(s, t, { width: At(t, i) + 100, style: m, useHtmlLabels: i.htmlLabels }, i)); if (t.includes("&lt;") || t.includes("&gt;")) {
    let e = a.children[0];
    for (e.textContent = e.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">"); e.childNodes[0];)
        e = e.childNodes[0], e.textContent = e.textContent.replaceAll("&lt;", "<").replaceAll("&gt;", ">");
} let l = a.getBBox(); if (bt(i.htmlLabels)) {
    let e = a.children[0];
    e.style.textAlign = "start";
    let u = J(a);
    l = e.getBoundingClientRect(), u.attr("width", l.width), u.attr("height", l.height);
} return l; }); }
$(Mt, "addText");
function Dt(h, t, i, g, y) { return h === i ? [{ x: h - y / 2, y: t }, { x: h + y / 2, y: t }, { x: i + y / 2, y: g }, { x: i - y / 2, y: g }] : [{ x: h, y: t - y / 2 }, { x: h, y: t + y / 2 }, { x: i, y: g + y / 2 }, { x: i, y: g - y / 2 }]; }
$(Dt, "lineToPolygon");
function Ls(c, m, o, n) { return B(this, arguments, function* (h, t, i, g, y = i.class.padding ?? 12) { let r = g ? 0 : 3, s = h.insert("g").attr("class", Y(t)).attr("id", t.domId || t.id), a = null, l = null, e = null, u = null, f = 0, d = 0, p = 0; if (a = s.insert("g").attr("class", "annotation-group text"), t.annotations.length > 0) {
    let k = t.annotations[0];
    yield Ht(a, { text: `\xAB${k}\xBB` }, 0), f = a.node().getBBox().height;
} l = s.insert("g").attr("class", "label-group text"), yield Ht(l, t, 0, ["font-weight: bolder"]); let x = l.node().getBBox(); d = x.height, e = s.insert("g").attr("class", "members-group text"); let w = 0; for (let k of t.members) {
    let M = yield Ht(e, k, w, [k.parseClassifier()]);
    w += M + r;
} p = e.node().getBBox().height, p <= 0 && (p = y / 2), u = s.insert("g").attr("class", "methods-group text"); let b = 0; for (let k of t.methods) {
    let M = yield Ht(u, k, b, [k.parseClassifier()]);
    b += M + r;
} let S = s.node().getBBox(); if (a !== null) {
    let k = a.node().getBBox();
    a.attr("transform", `translate(${-k.width / 2})`);
} return l.attr("transform", `translate(${-x.width / 2}, ${f})`), S = s.node().getBBox(), e.attr("transform", `translate(0, ${f + d + y * 2})`), S = s.node().getBBox(), u.attr("transform", `translate(0, ${f + d + (p ? p + y * 4 : y * 2)})`), S = s.node().getBBox(), { shapeSvg: s, bbox: S }; }); }
$(Ls, "textHelper");
function Ht(y, c, m) { return B(this, arguments, function* (h, t, i, g = []) { let o = h.insert("g").attr("class", "label").attr("style", g.join("; ")), n = vt(), r = "useHtmlLabels" in t ? t.useHtmlLabels : bt(n.htmlLabels) ?? !0, s = ""; "text" in t ? s = t.text : s = t.label, !r && s.startsWith("\\") && (s = s.substring(1)), ta(s) && (r = !0); let a = yield mt(o, Tt(kt(s)), { width: At(s, n) + 50, classes: "markdown-node-label", useHtmlLabels: r }, n), l, e = 1; if (r) {
    let u = a.children[0], f = J(a);
    e = u.innerHTML.split("<br>").length, u.innerHTML.includes("</math>") && (e += u.innerHTML.split("<mrow>").length - 1), yield zt(u), l = u.getBoundingClientRect(), f.attr("width", l.width), f.attr("height", l.height);
}
else {
    g.includes("font-weight: bolder") && J(a).selectAll("tspan").attr("font-weight", ""), e = a.children.length;
    let u = a.children[0];
    (a.textContent === "" || a.textContent.includes("&gt")) && (u.textContent = s[0] + s.substring(1).replaceAll("&gt;", ">").replaceAll("&lt;", "<").trim(), s[1] === " " && (u.textContent = u.textContent[0] + " " + u.textContent.substring(1))), u.textContent === "undefined" && (u.textContent = ""), l = a.getBBox();
} return o.attr("transform", "translate(0," + (-l.height / (2 * e) + i) + ")"), l.height; }); }
$(Ht, "addText");
function Ws(h, t) { return B(this, null, function* () { let i = Q(), { themeVariables: g } = i, { useGradient: y } = g, c = i.class.padding ?? 12, m = c, o = t.useHtmlLabels ?? bt(i.htmlLabels) ?? !0, n = t; n.annotations = n.annotations ?? [], n.members = n.members ?? [], n.methods = n.methods ?? []; let { shapeSvg: r, bbox: s } = yield Ls(h, t, i, o, m), { labelStyles: a, nodeStyles: l } = W(t); t.labelStyle = a, t.cssStyles = n.styles || ""; let e = n.styles?.join(";") || l || ""; t.cssStyles || (t.cssStyles = e.replaceAll("!important", "").split(";")); let u = n.members.length === 0 && n.methods.length === 0 && !i.class?.hideEmptyMembersBox, f = v.svg(r), d = I(t, {}); t.look !== "handDrawn" && (d.roughness = 0, d.fillStyle = "solid"); let p = Math.max(t.width ?? 0, s.width), x = Math.max(t.height ?? 0, s.height), w = (t.height ?? 0) > s.height; n.members.length === 0 && n.methods.length === 0 ? x += m : n.members.length > 0 && n.methods.length === 0 && (x += m * 2); let b = -p / 2, S = -x / 2, k = u ? c * 2 : n.members.length === 0 && n.methods.length === 0 ? -c : 0; w && (k = c * 2); let M = f.rectangle(b - c, S - c - (u ? c : n.members.length === 0 && n.methods.length === 0 ? -c / 2 : 0), p + 2 * c, x + 2 * c + k, d), P = r.insert(() => M, ":first-child"); P.attr("class", "basic label-container outer-path"); let A = P.node().getBBox(), D = r.select(".annotation-group").node().getBBox().height - (u ? c / 2 : 0) || 0, H = r.select(".label-group").node().getBBox().height - (u ? c / 2 : 0) || 0, z = r.select(".members-group").node().getBBox().height - (u ? c / 2 : 0) || 0, G = (D + H + S + c - (S - c - (u ? c : n.members.length === 0 && n.methods.length === 0 ? -c / 2 : 0))) / 2; if (r.selectAll(".text").each((E, L, T) => { let O = J(T[L]), F = O.attr("transform"), C = 0; if (F) {
    let st = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(F);
    st && (C = parseFloat(st[2]));
} let _ = C + S + c - (u ? c : n.members.length === 0 && n.methods.length === 0 ? -c / 2 : 0); if (O.attr("class").includes("methods-group")) {
    let tt = Math.max(z, m / 2);
    w ? _ = Math.max(G, D + H + tt + S + m * 2 + c) + m * 2 : _ = D + H + tt + S + m * 4 + c;
} n.members.length === 0 && n.methods.length === 0 && i.class?.hideEmptyMembersBox && (n.annotations.length > 0 ? _ = C - m : _ = C), o || (_ -= 4); let j = b; (O.attr("class").includes("label-group") || O.attr("class").includes("annotation-group")) && (j = -O.node()?.getBBox().width / 2 || 0, r.selectAll("text").each(function (tt, st, ct) { window.getComputedStyle(ct[st]).textAnchor === "middle" && (j = 0); })), O.attr("transform", `translate(${j}, ${_})`); }), n.members.length > 0 || n.methods.length > 0 || u) {
    let E = D + H + S + c, L = f.line(A.x, E, A.x + A.width, E + .001, d);
    r.insert(() => L).attr("class", `divider${t.look === "neo" && !y ? " neo-line" : ""}`).attr("style", e);
} if (u || n.members.length > 0 || n.methods.length > 0) {
    let E = D + H + z + S + m * 2 + c, L = f.line(A.x, w ? Math.max(G, E) : E, A.x + A.width, (w ? Math.max(G, E) : E) + .001, d);
    r.insert(() => L).attr("class", `divider${t.look === "neo" && !y ? " neo-line" : ""}`).attr("style", e);
} if (n.look !== "handDrawn" && r.selectAll("path").attr("style", e), P.select(":nth-child(2)").attr("style", e), r.selectAll(".divider").select("path").attr("style", e), t.labelStyle ? r.selectAll("span").attr("style", t.labelStyle) : r.selectAll("span").attr("style", e), !o) {
    let E = RegExp(/color\s*:\s*([^;]*)/), L = E.exec(e);
    if (L) {
        let T = L[0].replace("color", "fill");
        r.selectAll("tspan").attr("style", T);
    }
    else if (a) {
        let T = E.exec(a);
        if (T) {
            let O = T[0].replace("color", "fill");
            r.selectAll("tspan").attr("style", O);
        }
    }
} return R(t, P), t.intersect = function (E) { return N.rect(t, E); }, r; }); }
$(Ws, "classBox");
function Es(h, t) { return B(this, null, function* () { let { labelStyles: i, nodeStyles: g } = W(t); t.labelStyle = i; let y = t, c = t, m = 20, o = 20, n = "verifyMethod" in t, r = Y(t), s = Q(), { themeVariables: a } = s, { borderColorArray: l, requirementEdgeLabelBackground: e } = a, u = s.layout === "elk" ? "start" : "center", f = h.insert("g").attr("class", r).attr("id", t.domId ?? t.id), d; n ? d = yield ot(f, `&lt;&lt;${y.type}&gt;&gt;`, 0, t.labelStyle) : d = yield ot(f, "&lt;&lt;Element&gt;&gt;", 0, t.labelStyle); let p = d, x = yield ot(f, y.name, p, t.labelStyle + "; font-weight: bold;"); if (p += x + o, n) {
    let H = yield ot(f, `${y.requirementId ? `ID: ${y.requirementId}` : ""}`, p, t.labelStyle, u);
    p += H;
    let z = yield ot(f, `${y.text ? `Text: ${y.text}` : ""}`, p, t.labelStyle, u);
    p += z;
    let G = yield ot(f, `${y.risk ? `Risk: ${y.risk}` : ""}`, p, t.labelStyle, u);
    p += G, yield ot(f, `${y.verifyMethod ? `Verification: ${y.verifyMethod}` : ""}`, p, t.labelStyle, u);
}
else {
    let H = yield ot(f, `${c.type ? `Type: ${c.type}` : ""}`, p, t.labelStyle, u);
    p += H, yield ot(f, `${c.docRef ? `Doc Ref: ${c.docRef}` : ""}`, p, t.labelStyle, u);
} let w = (f.node()?.getBBox().width ?? 200) + m, b = (f.node()?.getBBox().height ?? 200) + m, S = -w / 2, k = -b / 2, M = v.svg(f), P = I(t, {}); t.look !== "handDrawn" && (P.roughness = 0, P.fillStyle = "solid"); let A = M.rectangle(S, k, w, b, P), D = f.insert(() => A, ":first-child"); if (D.attr("class", "basic label-container outer-path").attr("style", g), l?.length) {
    let H = t.colorIndex ?? 0;
    f.attr("data-color-id", `color-${H % l.length}`);
} if (f.selectAll(".label").each((H, z, G) => { let E = J(G[z]), L = E.attr("transform"), T = 0, O = 0; if (L) {
    let j = RegExp(/translate\(([^,]+),([^)]+)\)/).exec(L);
    j && (T = parseFloat(j[1]), O = parseFloat(j[2]));
} let F = O - b / 2, C = S + m / 2; (z === 0 || z === 1) && (C = T), E.attr("transform", `translate(${C}, ${F + m})`); }), p > d + x + o) {
    let H = k + d + x + o, z;
    if (t.look === "neo") {
        let L = [[S, H], [S + w, H], [S + w, H + .001], [S, H + .001]];
        z = M.polygon(L, P);
    }
    else
        z = M.line(S, H, S + w, H, P);
    f.insert(() => z).attr("class", "divider");
} return R(t, D), t.intersect = function (H) { return N.rect(t, H); }, g && t.look !== "handDrawn" && (e || l?.length) && f.selectAll("path").attr("style", g), f; }); }
$(Es, "requirementBox");
function ot(h, t, i, g = "", y = "center") { return B(this, null, function* () { if (t === "")
    return 0; let c = h.insert("g").attr("class", "label").attr("style", g), m = Q(), o = m.htmlLabels ?? !0, n = yield mt(c, Tt(kt(t)), { width: At(t, m) + 50, classes: "markdown-node-label", useHtmlLabels: o, style: g }, m), r; if (o) {
    let s = n.children[0], a = J(n);
    y === "start" && J(s).style("text-align", "left"), r = s.getBoundingClientRect(), a.attr("width", r.width), a.attr("height", r.height);
}
else {
    let s = n.children[0];
    for (let a of s.children)
        g && a.setAttribute("style", g);
    if (y === "start") {
        s.setAttribute("text-anchor", "start");
        for (let a of s.children)
            a.setAttribute("text-anchor", "start");
    }
    r = n.getBBox(), r.height += 6;
} return c.attr("transform", `translate(${-r.width / 2},${-r.height / 2 + i})`), r.height; }); }
$(ot, "addText");
var me = $(h => { switch (h) {
    case "Very High": return "red";
    case "High": return "orange";
    case "Medium": return null;
    case "Low": return "blue";
    case "Very Low": return "lightblue";
} }, "colorFromPriority");
function Ts(g, y, c) { return B(this, arguments, function* (h, t, { config: i }) { let { labelStyles: m, nodeStyles: o } = W(t); t.labelStyle = m || ""; let n = 10, r = t.width; t.width = (t.width ?? 200) - 10; let { shapeSvg: s, bbox: a, label: l } = yield X(h, t, Y(t)), e = t.padding || 10, u = "", f; "ticket" in t && t.ticket && i?.kanban?.ticketBaseUrl && (u = i?.kanban?.ticketBaseUrl.replace("#TICKET#", t.ticket), f = s.insert("svg:a", ":first-child").attr("class", "kanban-ticket-link").attr("xlink:href", u).attr("target", "_blank")); let d = { useHtmlLabels: t.useHtmlLabels, labelStyle: t.labelStyle || "", width: t.width, img: t.img, padding: t.padding || 8, centerLabel: !1 }, p, x; f ? { label: p, bbox: x } = yield _t(f, "ticket" in t && t.ticket || "", d) : { label: p, bbox: x } = yield _t(s, "ticket" in t && t.ticket || "", d); let { label: w, bbox: b } = yield _t(s, "assigned" in t && t.assigned || "", d); t.width = r; let S = 10, k = t?.width || 0, M = Math.max(x.height, b.height) / 2, P = Math.max(a.height + S * 2, t?.height || 0) + M, A = -k / 2, D = -P / 2; l.attr("transform", "translate(" + (e - k / 2) + ", " + (-M - a.height / 2) + ")"), p.attr("transform", "translate(" + (e - k / 2) + ", " + (-M + a.height / 2) + ")"), w.attr("transform", "translate(" + (e + k / 2 - b.width - 2 * n) + ", " + (-M + a.height / 2) + ")"); let H, { rx: z, ry: G } = t, { cssStyles: E } = t; if (t.look === "handDrawn") {
    let L = v.svg(s), T = I(t, {}), O = z || G ? L.path(ut(A, D, k, P, z || 0), T) : L.rectangle(A, D, k, P, T);
    H = s.insert(() => O, ":first-child"), H.attr("class", "basic label-container").attr("style", E || null);
}
else {
    H = s.insert("rect", ":first-child"), H.attr("class", "basic label-container __APA__").attr("style", o).attr("rx", z ?? 5).attr("ry", G ?? 5).attr("x", A).attr("y", D).attr("width", k).attr("height", P);
    let L = "priority" in t && t.priority;
    if (L) {
        let T = s.append("line"), O = A + 2, F = D + Math.floor((z ?? 0) / 2), C = D + P - Math.floor((z ?? 0) / 2);
        T.attr("x1", O).attr("y1", F).attr("x2", O).attr("y2", C).attr("stroke-width", "4").attr("stroke", me(L));
    }
} return R(t, H), t.height = P, t.intersect = function (L) { return N.rect(t, L); }, s; }); }
$(Ts, "kanbanItem");
function _s(h, t) {
    return B(this, null, function* () {
        let { labelStyles: i, nodeStyles: g } = W(t);
        t.labelStyle = i;
        let { shapeSvg: y, bbox: c, halfPadding: m, label: o } = yield X(h, t, Y(t)), n = c.width + 10 * m, r = c.height + 8 * m, s = .15 * n, { cssStyles: a } = t, l = c.width + 20, e = c.height + 20, u = Math.max(n, l), f = Math.max(r, e);
        o.attr("transform", `translate(${-c.width / 2}, ${-c.height / 2})`);
        let d, p = `M0 0 
    a${s},${s} 1 0,0 ${u * .25},${-1 * f * .1}
    a${s},${s} 1 0,0 ${u * .25},0
    a${s},${s} 1 0,0 ${u * .25},0
    a${s},${s} 1 0,0 ${u * .25},${f * .1}

    a${s},${s} 1 0,0 ${u * .15},${f * .33}
    a${s * .8},${s * .8} 1 0,0 0,${f * .34}
    a${s},${s} 1 0,0 ${-1 * u * .15},${f * .33}

    a${s},${s} 1 0,0 ${-1 * u * .25},${f * .15}
    a${s},${s} 1 0,0 ${-1 * u * .25},0
    a${s},${s} 1 0,0 ${-1 * u * .25},0
    a${s},${s} 1 0,0 ${-1 * u * .25},${-1 * f * .15}

    a${s},${s} 1 0,0 ${-1 * u * .1},${-1 * f * .33}
    a${s * .8},${s * .8} 1 0,0 0,${-1 * f * .34}
    a${s},${s} 1 0,0 ${u * .1},${-1 * f * .33}
  H0 V0 Z`;
        if (t.look === "handDrawn") {
            let x = v.svg(y), w = I(t, {}), b = x.path(p, w);
            d = y.insert(() => b, ":first-child"), d.attr("class", "basic label-container").attr("style", et(a));
        }
        else
            d = y.insert("path", ":first-child").attr("class", "basic label-container").attr("style", g).attr("d", p);
        return d.attr("transform", `translate(${-u / 2}, ${-f / 2})`), R(t, d), t.calcIntersect = function (x, w) { return N.rect(x, w); }, t.intersect = function (x) { return U.info("Bang intersect", t, x), N.rect(t, x); }, y;
    });
}
$(_s, "bang");
function Ys(h, t) {
    return B(this, null, function* () {
        let { labelStyles: i, nodeStyles: g } = W(t);
        t.labelStyle = i;
        let { shapeSvg: y, bbox: c, halfPadding: m, label: o } = yield X(h, t, Y(t)), n = c.width + 2 * m, r = c.height + 2 * m, s = .15 * n, a = .25 * n, l = .35 * n, e = .2 * n, { cssStyles: u } = t, f, d = `M0 0 
    a${s},${s} 0 0,1 ${n * .25},${-1 * n * .1}
    a${l},${l} 1 0,1 ${n * .4},${-1 * n * .1}
    a${a},${a} 1 0,1 ${n * .35},${n * .2}

    a${s},${s} 1 0,1 ${n * .15},${r * .35}
    a${e},${e} 1 0,1 ${-1 * n * .15},${r * .65}

    a${a},${s} 1 0,1 ${-1 * n * .25},${n * .15}
    a${l},${l} 1 0,1 ${-1 * n * .5},0
    a${s},${s} 1 0,1 ${-1 * n * .25},${-1 * n * .15}

    a${s},${s} 1 0,1 ${-1 * n * .1},${-1 * r * .35}
    a${e},${e} 1 0,1 ${n * .1},${-1 * r * .65}
  H0 V0 Z`;
        if (t.look === "handDrawn") {
            let p = v.svg(y), x = I(t, {}), w = p.path(d, x);
            f = y.insert(() => w, ":first-child"), f.attr("class", "basic label-container").attr("style", et(u));
        }
        else
            f = y.insert("path", ":first-child").attr("class", "basic label-container").attr("style", g).attr("d", d);
        return o.attr("transform", `translate(${-c.width / 2}, ${-c.height / 2})`), f.attr("transform", `translate(${-n / 2}, ${-r / 2})`), R(t, f), t.calcIntersect = function (p, x) { return N.rect(p, x); }, t.intersect = function (p) { return U.info("Cloud intersect", t, p), N.rect(t, p); }, y;
    });
}
$(Ys, "cloud");
function Xs(h, t) {
    return B(this, null, function* () {
        let { labelStyles: i, nodeStyles: g } = W(t);
        t.labelStyle = i;
        let { shapeSvg: y, bbox: c, halfPadding: m, label: o } = yield X(h, t, Y(t)), n = c.width + 8 * m, r = c.height + 2 * m, s = 5, a = t.look === "neo" ? `
    M${-n / 2} ${r / 2 - s}
    v${-r + 2 * s}
    q0,-${s} ${s},-${s}
    h${n - 2 * s}
    q${s},0 ${s},${s}
    v${r - s}
    H${-n / 2}
    Z
  ` : `
    M${-n / 2} ${r / 2 - s}
    v${-r + 2 * s}
    q0,-${s} ${s},-${s}
    h${n - 2 * s}
    q${s},0 ${s},${s}
    v${r - 2 * s}
    q0,${s} ${-s},${s}
    h${-(n - 2 * s)}
    q${-s},0 ${-s},${-s}
    Z
  `;
        if (!t.domId)
            throw new Error(`defaultMindmapNode: node "${t.id}" is missing a domId \u2014 was render.ts domId prefixing skipped?`);
        let l = y.append("path").attr("id", t.domId).attr("class", "node-bkg node-" + t.type).attr("style", g).attr("d", a);
        return y.append("line").attr("class", "node-line-").attr("x1", -n / 2).attr("y1", r / 2).attr("x2", n / 2).attr("y2", r / 2), o.attr("transform", `translate(${-c.width / 2}, ${-c.height / 2})`), y.append(() => o.node()), R(t, l), t.calcIntersect = function (e, u) { return N.rect(e, u); }, t.intersect = function (e) { return N.rect(t, e); }, y;
    });
}
$(Xs, "defaultMindmapNode");
function Os(h, t) { return B(this, null, function* () { let i = { padding: t.padding ?? 0 }; return Jt(h, t, i); }); }
$(Os, "mindmapCircle");
var xe = [{ semanticName: "Process", name: "Rectangle", shortName: "rect", description: "Standard process shape", aliases: ["proc", "process", "rectangle"], internalAliases: ["squareRect"], handler: ws }, { semanticName: "Event", name: "Rounded Rectangle", shortName: "rounded", description: "Represents an event", aliases: ["event"], internalAliases: ["roundedRect"], handler: ds }, { semanticName: "Terminal Point", name: "Stadium", shortName: "stadium", description: "Terminal point", aliases: ["terminal", "pill"], handler: bs }, { semanticName: "Subprocess", name: "Framed Rectangle", shortName: "fr-rect", description: "Subprocess", aliases: ["subprocess", "subproc", "framed-rectangle", "subroutine"], handler: ks }, { semanticName: "Database", name: "Cylinder", shortName: "cyl", description: "Database storage", aliases: ["db", "database", "cylinder"], handler: Xa }, { semanticName: "Data Store", name: "Data Store", shortName: "datastore", description: "Data flow diagram data store", aliases: ["data-store"], handler: Oa }, { semanticName: "Folder", name: "Folder", shortName: "folder", description: "Folder or directory", aliases: ["directory"], handler: za }, { semanticName: "Bucket", name: "Bucket", shortName: "bucket", description: "Object storage bucket", handler: Ma }, { semanticName: "Console", name: "Console (terminal window)", shortName: "console", description: "Terminal or console window", handler: Ha }, { semanticName: "Browser", name: "Browser", shortName: "browser", description: "Browser window", handler: Ba }, { semanticName: "Person", name: "Person", shortName: "person", description: "Person (circular head above a rounded body)", handler: Ya }, { semanticName: "Start", name: "Circle", shortName: "circle", description: "Starting point", aliases: ["circ"], handler: Jt }, { semanticName: "Bang", name: "Bang", shortName: "bang", description: "Bang", aliases: ["bang"], handler: _s }, { semanticName: "Cloud", name: "Cloud", shortName: "cloud", description: "cloud", aliases: ["cloud"], handler: Ys }, { semanticName: "Decision", name: "Diamond", shortName: "diam", description: "Decision-making step", aliases: ["decision", "diamond", "question"], handler: fs }, { semanticName: "Prepare Conditional", name: "Hexagon", shortName: "hex", description: "Preparation or condition step", aliases: ["hexagon", "prepare"], handler: Ja }, { semanticName: "Data Input/Output", name: "Lean Right", shortName: "lean-r", description: "Represents input or output", aliases: ["lean-right", "in-out"], internalAliases: ["lean_right"], handler: ls }, { semanticName: "Data Input/Output", name: "Lean Left", shortName: "lean-l", description: "Represents output or input", aliases: ["lean-left", "out-in"], internalAliases: ["lean_left"], handler: is }, { semanticName: "Priority Action", name: "Trapezoid Base Bottom", shortName: "trap-b", description: "Priority action", aliases: ["priority", "trapezoid-bottom", "trapezoid"], handler: Bs }, { semanticName: "Manual Operation", name: "Trapezoid Base Top", shortName: "trap-t", description: "Represents a manual task", aliases: ["manual", "trapezoid-top", "inv-trapezoid"], internalAliases: ["inv_trapezoid"], handler: es }, { semanticName: "Stop", name: "Double Circle", shortName: "dbl-circ", description: "Represents a stop point", aliases: ["double-circle"], internalAliases: ["doublecircle"], handler: ja }, { semanticName: "Text Block", name: "Text Block", shortName: "text", description: "Text block", handler: Ds }, { semanticName: "Card", name: "Notched Rectangle", shortName: "notch-rect", description: "Represents a card", aliases: ["card", "notched-rectangle"], handler: Ca }, { semanticName: "Lined/Shaded Process", name: "Lined Rectangle", shortName: "lin-rect", description: "Lined process shape", aliases: ["lined-rectangle", "lined-process", "lin-proc", "shaded-process"], handler: ms }, { semanticName: "Start", name: "Small Circle", shortName: "sm-circ", description: "Small starting point", aliases: ["start", "small-circle"], internalAliases: ["stateStart"], handler: vs }, { semanticName: "Stop", name: "Framed Circle", shortName: "fr-circ", description: "Stop point", aliases: ["stop", "framed-circle"], internalAliases: ["stateEnd"], handler: $s }, { semanticName: "Fork/Join", name: "Filled Rectangle", shortName: "fork", description: "Fork or join in process flow", aliases: ["join"], internalAliases: ["forkJoin"], handler: Va }, { semanticName: "Collate", name: "Hourglass", shortName: "hourglass", description: "Represents a collate operation", aliases: ["hourglass", "collate"], handler: Ka }, { semanticName: "Comment", name: "Curly Brace", shortName: "brace", description: "Adds a comment", aliases: ["comment", "brace-l"], handler: Wa }, { semanticName: "Comment Right", name: "Curly Brace", shortName: "brace-r", description: "Adds a comment", handler: Ea }, { semanticName: "Comment with braces on both sides", name: "Curly Braces", shortName: "braces", description: "Adds a comment", handler: Ta }, { semanticName: "Com Link", name: "Lightning Bolt", shortName: "bolt", description: "Communication link", aliases: ["com-link", "lightning-bolt"], handler: ns }, { semanticName: "Document", name: "Document", shortName: "doc", description: "Represents a document", aliases: ["doc", "document"], handler: Rs }, { semanticName: "Delay", name: "Half-Rounded Rectangle", shortName: "delay", description: "Represents a delay", aliases: ["half-rounded-rectangle"], handler: Za }, { semanticName: "Direct Access Storage", name: "Horizontal Cylinder", shortName: "h-cyl", description: "Direct access storage", aliases: ["das", "horizontal-cylinder"], handler: Ns }, { semanticName: "Disk Storage", name: "Lined Cylinder", shortName: "lin-cyl", description: "Disk storage", aliases: ["disk", "lined-cylinder"], handler: cs }, { semanticName: "Display", name: "Curved Trapezoid", shortName: "curv-trap", description: "Represents a display", aliases: ["curved-trapezoid", "display"], handler: _a }, { semanticName: "Divided Process", name: "Divided Rectangle", shortName: "div-rect", description: "Divided process shape", aliases: ["div-proc", "divided-rectangle", "divided-process"], handler: Fa }, { semanticName: "Extract", name: "Triangle", shortName: "tri", description: "Extraction process", aliases: ["extract", "triangle"], handler: As }, { semanticName: "Internal Storage", name: "Window Pane", shortName: "win-pane", description: "Internal storage", aliases: ["internal-storage", "window-pane"], handler: Is }, { semanticName: "Junction", name: "Filled Circle", shortName: "f-circ", description: "Junction point", aliases: ["junction", "filled-circle"], handler: Ga }, { semanticName: "Loop Limit", name: "Trapezoidal Pentagon", shortName: "notch-pent", description: "Loop limit step", aliases: ["loop-limit", "notched-pentagon"], handler: Cs }, { semanticName: "Manual File", name: "Flipped Triangle", shortName: "flip-tri", description: "Manual file operation", aliases: ["manual-file", "flipped-triangle"], handler: qa }, { semanticName: "Manual Input", name: "Sloped Rectangle", shortName: "sl-rect", description: "Manual input step", aliases: ["manual-input", "sloped-rectangle"], handler: xs }, { semanticName: "Multi-Document", name: "Stacked Document", shortName: "docs", description: "Multiple documents", aliases: ["documents", "st-doc", "stacked-document"], handler: gs }, { semanticName: "Multi-Process", name: "Stacked Rectangle", shortName: "st-rect", description: "Multiple processes", aliases: ["procs", "processes", "stacked-rectangle"], handler: hs }, { semanticName: "Stored Data", name: "Bow Tie Rectangle", shortName: "bow-rect", description: "Stored data", aliases: ["stored-data", "bow-tie-rectangle"], handler: Pa }, { semanticName: "Summary", name: "Crossed Circle", shortName: "cross-circ", description: "Summary", aliases: ["summary", "crossed-circle"], handler: La }, { semanticName: "Tagged Document", name: "Tagged Document", shortName: "tag-doc", description: "Tagged document", aliases: ["tag-doc", "tagged-document"], handler: Ms }, { semanticName: "Tagged Process", name: "Tagged Rectangle", shortName: "tag-rect", description: "Tagged process", aliases: ["tagged-rectangle", "tag-proc", "tagged-process"], handler: Ps }, { semanticName: "Paper Tape", name: "Flag", shortName: "flag", description: "Paper tape", aliases: ["paper-tape"], handler: Hs }, { semanticName: "Odd", name: "Odd", shortName: "odd", description: "Odd shape", internalAliases: ["rect_left_inv_arrow"], handler: ps }, { semanticName: "Lined Document", name: "Lined Document", shortName: "lin-doc", description: "Lined document", aliases: ["lined-document"], handler: os }], we = $(() => { let t = [...Object.entries({ state: Ss, choice: Aa, note: ys, composite: Ra, rectWithTitle: us, labelRect: rs, block_arrow: Na, collapsedGroup: Da, iconSquare: as, iconCircle: Qa, icon: Ua, iconRounded: ts, imageSquare: ss, anchor: va, kanbanItem: Ts, mindmapCircle: Os, defaultMindmapNode: Xs, classBox: Ws, erBox: Kt, requirementBox: Es }), ...xe.flatMap(i => [i.shortName, ..."aliases" in i ? i.aliases : [], ..."internalAliases" in i ? i.internalAliases : []].map(y => [y, i.handler]))]; return Object.fromEntries(t); }, "generateShapeMap"), be = we();
function Se(h) { return h in be; }
$(Se, "isValidShape");
export { X as a, R as b, Vs as c, ut as d, ra as e, be as f, Se as g };
