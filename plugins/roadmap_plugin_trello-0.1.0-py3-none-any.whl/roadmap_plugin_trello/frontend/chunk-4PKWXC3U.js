import { a as h } from "@nf-internal/chunk-PFHS2QSV";
import { f as u, g as y, h as w, i as F } from "@nf-internal/chunk-ST43FWUC";
import { b as c } from "@nf-internal/chunk-JKFADCWD";
import { a as f } from "@nf-internal/chunk-VEDGZ2C2";
import { e as g } from "@nf-internal/chunk-FDRUJGNH";
import { N as m, u as p } from "@nf-internal/chunk-LEJRRF65";
import { b as n } from "@nf-internal/chunk-RZWXGGKD";
import { a as o } from "@nf-internal/chunk-YUSHYV7C";
import { f as a } from "@nf-internal/chunk-OSQMNGTH";
var L = { common: m, getConfig: p, insertCluster: h, insertEdge: w, insertEdgeLabel: u, insertMarkers: F, insertNode: c, interpolateToCurve: g, labelHelper: f, log: n, positionEdgeLabel: y }, i = {}, E = o(t => { for (let r of t)
    i[r.name] = r; }, "registerLayoutLoaders"), b = o(() => { E([{ name: "dagre", loader: o(() => a(null, null, function* () { return yield import("@nf-internal/dagre-GXQ25YYZ-23AEMSPO"); }), "loader") }, { name: "swimlane", loader: o(() => a(null, null, function* () { return yield import("@nf-internal/swimlanes-42K2YHIH-EPADPJRM"); }), "loader") }, { name: "cose-bilkent", loader: o(() => a(null, null, function* () { return yield import("@nf-internal/cose-bilkent-JH36ORCC-LU4NNNQB"); }), "loader") }]); }, "registerDefaultLayoutLoaders");
b();
var H = o((t, r) => a(null, null, function* () { if (!(t.layoutAlgorithm in i))
    throw new Error(`Unknown layout algorithm: ${t.layoutAlgorithm}`); if (t.diagramId)
    for (let e of t.nodes) {
        let I = e.domId || e.id;
        e.domId = `${t.diagramId}-${I}`;
    } let d = i[t.layoutAlgorithm], $ = yield d.loader(), { theme: s, themeVariables: D } = t.config, { useGradient: v, gradientStart: x, gradientStop: A } = D, l = r.attr("id"); if (r.append("defs").append("filter").attr("id", `${l}-drop-shadow`).attr("height", "130%").attr("width", "130%").append("feDropShadow").attr("dx", "4").attr("dy", "4").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${s?.includes("dark") ? "#FFFFFF" : "#000000"}`), r.append("defs").append("filter").attr("id", `${l}-drop-shadow-small`).attr("height", "150%").attr("width", "150%").append("feDropShadow").attr("dx", "2").attr("dy", "2").attr("stdDeviation", 0).attr("flood-opacity", "0.06").attr("flood-color", `${s?.includes("dark") ? "#FFFFFF" : "#000000"}`), v) {
    let e = r.append("linearGradient").attr("id", r.attr("id") + "-gradient").attr("gradientUnits", "objectBoundingBox").attr("x1", "0%").attr("y1", "0%").attr("x2", "100%").attr("y2", "0%");
    e.append("svg:stop").attr("offset", "0%").attr("stop-color", x).attr("stop-opacity", 1), e.append("svg:stop").attr("offset", "100%").attr("stop-color", A).attr("stop-opacity", 1);
} return $.render(t, r, L, { algorithm: d.algorithm }); }), "render"), j = o((t = "", { fallback: r = "dagre" } = {}) => { if (t in i)
    return t; if (r in i)
    return n.warn(`Layout algorithm ${t} is not registered. Using ${r} as fallback.`), r; throw new Error(`Both layout algorithms ${t} and ${r} are not registered.`); }, "getRegisteredLayoutAlgorithm");
export { E as a, H as b, j as c };
