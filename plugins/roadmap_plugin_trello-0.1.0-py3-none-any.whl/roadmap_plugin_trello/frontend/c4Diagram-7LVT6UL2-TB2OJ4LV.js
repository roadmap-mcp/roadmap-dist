import { a as Ee } from "@nf-internal/chunk-X5ONEG5D";
import { f as ke } from "@nf-internal/chunk-VEDGZ2C2";
import "@nf-internal/chunk-PRKFGJVH";
import "@nf-internal/chunk-GP7LUXUQ";
import "@nf-internal/chunk-3SXY7Q5B";
import "@nf-internal/chunk-ZBOYDPPL";
import { i as ve, j as ee, k as wt } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { H as te, N as Yt, O as be, U as _e, V as me, W as ge, X as xe, _ as Et, h as ye } from "@nf-internal/chunk-LEJRRF65";
import { b as $t, h as Ft } from "@nf-internal/chunk-RZWXGGKD";
import { a as d } from "@nf-internal/chunk-YUSHYV7C";
import { f as Rt } from "@nf-internal/chunk-OSQMNGTH";
var jt = (function () {
    var t = d(function (yt, m, x, k) { for (x = x || {}, k = yt.length; k--; x[yt[k]] = m)
        ; return x; }, "o"), e = [1, 24], s = [1, 25], a = [1, 26], u = [1, 27], i = [1, 28], n = [1, 63], l = [1, 64], r = [1, 65], h = [1, 66], y = [1, 67], f = [1, 68], _ = [1, 69], v = [1, 29], w = [1, 30], N = [1, 31], O = [1, 32], P = [1, 33], M = [1, 34], W = [1, 35], X = [1, 36], q = [1, 37], H = [1, 38], Q = [1, 39], K = [1, 40], G = [1, 41], J = [1, 42], Z = [1, 43], $ = [1, 44], tt = [1, 45], et = [1, 46], nt = [1, 47], rt = [1, 48], st = [1, 50], at = [1, 51], it = [1, 52], ot = [1, 53], lt = [1, 54], ct = [1, 55], ut = [1, 56], ht = [1, 57], dt = [1, 58], pt = [1, 59], ft = [1, 60], Tt = [14, 42], Xt = [14, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74], Ot = [12, 14, 34, 36, 37, 38, 39, 40, 41, 42, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74], E = [1, 82], S = [1, 83], T = [1, 84], C = [1, 85], R = [12, 14, 42], ce = [12, 14, 33, 42], It = [12, 14, 33, 42, 76, 77, 79, 80], gt = [12, 33], qt = [34, 36, 37, 38, 39, 40, 41, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74], Ht = { trace: d(function () { }, "trace"), yy: {}, symbols_: { error: 2, start: 3, mermaidDoc: 4, direction: 5, direction_tb: 6, direction_bt: 7, direction_rl: 8, direction_lr: 9, graphConfig: 10, C4_CONTEXT: 11, NEWLINE: 12, statements: 13, EOF: 14, C4_CONTAINER: 15, C4_COMPONENT: 16, C4_DYNAMIC: 17, C4_DEPLOYMENT: 18, otherStatements: 19, diagramStatements: 20, otherStatement: 21, title: 22, accDescription: 23, acc_title: 24, acc_title_value: 25, acc_descr: 26, acc_descr_value: 27, acc_descr_multiline_value: 28, boundaryStatement: 29, boundaryStartStatement: 30, boundaryStopStatement: 31, boundaryStart: 32, LBRACE: 33, ENTERPRISE_BOUNDARY: 34, attributes: 35, SYSTEM_BOUNDARY: 36, BOUNDARY: 37, CONTAINER_BOUNDARY: 38, NODE: 39, NODE_L: 40, NODE_R: 41, RBRACE: 42, diagramStatement: 43, PERSON: 44, PERSON_EXT: 45, SYSTEM: 46, SYSTEM_DB: 47, SYSTEM_QUEUE: 48, SYSTEM_EXT: 49, SYSTEM_EXT_DB: 50, SYSTEM_EXT_QUEUE: 51, CONTAINER: 52, CONTAINER_DB: 53, CONTAINER_QUEUE: 54, CONTAINER_EXT: 55, CONTAINER_EXT_DB: 56, CONTAINER_EXT_QUEUE: 57, COMPONENT: 58, COMPONENT_DB: 59, COMPONENT_QUEUE: 60, COMPONENT_EXT: 61, COMPONENT_EXT_DB: 62, COMPONENT_EXT_QUEUE: 63, REL: 64, BIREL: 65, REL_U: 66, REL_D: 67, REL_L: 68, REL_R: 69, REL_B: 70, REL_INDEX: 71, UPDATE_EL_STYLE: 72, UPDATE_REL_STYLE: 73, UPDATE_LAYOUT_CONFIG: 74, attribute: 75, STR: 76, STR_KEY: 77, STR_VALUE: 78, ATTRIBUTE: 79, ATTRIBUTE_EMPTY: 80, $accept: 0, $end: 1 }, terminals_: { 2: "error", 6: "direction_tb", 7: "direction_bt", 8: "direction_rl", 9: "direction_lr", 11: "C4_CONTEXT", 12: "NEWLINE", 14: "EOF", 15: "C4_CONTAINER", 16: "C4_COMPONENT", 17: "C4_DYNAMIC", 18: "C4_DEPLOYMENT", 22: "title", 23: "accDescription", 24: "acc_title", 25: "acc_title_value", 26: "acc_descr", 27: "acc_descr_value", 28: "acc_descr_multiline_value", 33: "LBRACE", 34: "ENTERPRISE_BOUNDARY", 36: "SYSTEM_BOUNDARY", 37: "BOUNDARY", 38: "CONTAINER_BOUNDARY", 39: "NODE", 40: "NODE_L", 41: "NODE_R", 42: "RBRACE", 44: "PERSON", 45: "PERSON_EXT", 46: "SYSTEM", 47: "SYSTEM_DB", 48: "SYSTEM_QUEUE", 49: "SYSTEM_EXT", 50: "SYSTEM_EXT_DB", 51: "SYSTEM_EXT_QUEUE", 52: "CONTAINER", 53: "CONTAINER_DB", 54: "CONTAINER_QUEUE", 55: "CONTAINER_EXT", 56: "CONTAINER_EXT_DB", 57: "CONTAINER_EXT_QUEUE", 58: "COMPONENT", 59: "COMPONENT_DB", 60: "COMPONENT_QUEUE", 61: "COMPONENT_EXT", 62: "COMPONENT_EXT_DB", 63: "COMPONENT_EXT_QUEUE", 64: "REL", 65: "BIREL", 66: "REL_U", 67: "REL_D", 68: "REL_L", 69: "REL_R", 70: "REL_B", 71: "REL_INDEX", 72: "UPDATE_EL_STYLE", 73: "UPDATE_REL_STYLE", 74: "UPDATE_LAYOUT_CONFIG", 76: "STR", 77: "STR_KEY", 78: "STR_VALUE", 79: "ATTRIBUTE", 80: "ATTRIBUTE_EMPTY" }, productions_: [0, [3, 1], [3, 1], [5, 1], [5, 1], [5, 1], [5, 1], [4, 1], [10, 4], [10, 4], [10, 4], [10, 4], [10, 4], [13, 1], [13, 1], [13, 2], [19, 1], [19, 2], [19, 3], [21, 1], [21, 1], [21, 2], [21, 2], [21, 1], [29, 3], [30, 3], [30, 3], [30, 4], [32, 2], [32, 2], [32, 2], [32, 2], [32, 2], [32, 2], [32, 2], [31, 1], [20, 1], [20, 2], [20, 3], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 1], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [43, 2], [35, 1], [35, 2], [75, 1], [75, 2], [75, 1], [75, 1]], performAction: d(function (m, x, k, b, D, o, Pt) { var p = o.length - 1; switch (D) {
            case 3:
                b.setDirection("TB");
                break;
            case 4:
                b.setDirection("BT");
                break;
            case 5:
                b.setDirection("RL");
                break;
            case 6:
                b.setDirection("LR");
                break;
            case 8:
            case 9:
            case 10:
            case 11:
            case 12:
                b.setC4Type(o[p - 3]);
                break;
            case 19:
                b.setTitle(o[p].substring(6)), this.$ = o[p].substring(6);
                break;
            case 20:
                b.setAccDescription(o[p].substring(15)), this.$ = o[p].substring(15);
                break;
            case 21:
                this.$ = o[p].trim(), b.setTitle(this.$);
                break;
            case 22:
            case 23:
                this.$ = o[p].trim(), b.setAccDescription(this.$);
                break;
            case 28:
                o[p].splice(2, 0, "ENTERPRISE"), b.addPersonOrSystemBoundary(...o[p]), this.$ = o[p];
                break;
            case 29:
                o[p].splice(2, 0, "SYSTEM"), b.addPersonOrSystemBoundary(...o[p]), this.$ = o[p];
                break;
            case 30:
                b.addPersonOrSystemBoundary(...o[p]), this.$ = o[p];
                break;
            case 31:
                o[p].splice(2, 0, "CONTAINER"), b.addContainerBoundary(...o[p]), this.$ = o[p];
                break;
            case 32:
                b.addDeploymentNode("node", ...o[p]), this.$ = o[p];
                break;
            case 33:
                b.addDeploymentNode("nodeL", ...o[p]), this.$ = o[p];
                break;
            case 34:
                b.addDeploymentNode("nodeR", ...o[p]), this.$ = o[p];
                break;
            case 35:
                b.popBoundaryParseStack();
                break;
            case 39:
                b.addPersonOrSystem("person", ...o[p]), this.$ = o[p];
                break;
            case 40:
                b.addPersonOrSystem("external_person", ...o[p]), this.$ = o[p];
                break;
            case 41:
                b.addPersonOrSystem("system", ...o[p]), this.$ = o[p];
                break;
            case 42:
                b.addPersonOrSystem("system_db", ...o[p]), this.$ = o[p];
                break;
            case 43:
                b.addPersonOrSystem("system_queue", ...o[p]), this.$ = o[p];
                break;
            case 44:
                b.addPersonOrSystem("external_system", ...o[p]), this.$ = o[p];
                break;
            case 45:
                b.addPersonOrSystem("external_system_db", ...o[p]), this.$ = o[p];
                break;
            case 46:
                b.addPersonOrSystem("external_system_queue", ...o[p]), this.$ = o[p];
                break;
            case 47:
                b.addContainer("container", ...o[p]), this.$ = o[p];
                break;
            case 48:
                b.addContainer("container_db", ...o[p]), this.$ = o[p];
                break;
            case 49:
                b.addContainer("container_queue", ...o[p]), this.$ = o[p];
                break;
            case 50:
                b.addContainer("external_container", ...o[p]), this.$ = o[p];
                break;
            case 51:
                b.addContainer("external_container_db", ...o[p]), this.$ = o[p];
                break;
            case 52:
                b.addContainer("external_container_queue", ...o[p]), this.$ = o[p];
                break;
            case 53:
                b.addComponent("component", ...o[p]), this.$ = o[p];
                break;
            case 54:
                b.addComponent("component_db", ...o[p]), this.$ = o[p];
                break;
            case 55:
                b.addComponent("component_queue", ...o[p]), this.$ = o[p];
                break;
            case 56:
                b.addComponent("external_component", ...o[p]), this.$ = o[p];
                break;
            case 57:
                b.addComponent("external_component_db", ...o[p]), this.$ = o[p];
                break;
            case 58:
                b.addComponent("external_component_queue", ...o[p]), this.$ = o[p];
                break;
            case 60:
                b.addRel("rel", ...o[p]), this.$ = o[p];
                break;
            case 61:
                b.addRel("birel", ...o[p]), this.$ = o[p];
                break;
            case 62:
                b.addRel("rel_u", ...o[p]), this.$ = o[p];
                break;
            case 63:
                b.addRel("rel_d", ...o[p]), this.$ = o[p];
                break;
            case 64:
                b.addRel("rel_l", ...o[p]), this.$ = o[p];
                break;
            case 65:
                b.addRel("rel_r", ...o[p]), this.$ = o[p];
                break;
            case 66:
                b.addRel("rel_b", ...o[p]), this.$ = o[p];
                break;
            case 67:
                o[p].splice(0, 1), b.addRel("rel", ...o[p]), this.$ = o[p];
                break;
            case 68:
                b.updateElStyle("update_el_style", ...o[p]), this.$ = o[p];
                break;
            case 69:
                b.updateRelStyle("update_rel_style", ...o[p]), this.$ = o[p];
                break;
            case 70:
                b.updateLayoutConfig("update_layout_config", ...o[p]), this.$ = o[p];
                break;
            case 71:
                this.$ = [o[p]];
                break;
            case 72:
                o[p].unshift(o[p - 1]), this.$ = o[p];
                break;
            case 73:
            case 75:
                this.$ = o[p].trim();
                break;
            case 74:
                let xt = {};
                xt[o[p - 1].trim()] = o[p].trim(), this.$ = xt;
                break;
            case 76:
                this.$ = "";
                break;
        } }, "anonymous"), table: [{ 3: 1, 4: 2, 5: 3, 6: [1, 5], 7: [1, 6], 8: [1, 7], 9: [1, 8], 10: 4, 11: [1, 9], 15: [1, 10], 16: [1, 11], 17: [1, 12], 18: [1, 13] }, { 1: [3] }, { 1: [2, 1] }, { 1: [2, 2] }, { 1: [2, 7] }, { 1: [2, 3] }, { 1: [2, 4] }, { 1: [2, 5] }, { 1: [2, 6] }, { 12: [1, 14] }, { 12: [1, 15] }, { 12: [1, 16] }, { 12: [1, 17] }, { 12: [1, 18] }, { 13: 19, 19: 20, 20: 21, 21: 22, 22: e, 23: s, 24: a, 26: u, 28: i, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 13: 70, 19: 20, 20: 21, 21: 22, 22: e, 23: s, 24: a, 26: u, 28: i, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 13: 71, 19: 20, 20: 21, 21: 22, 22: e, 23: s, 24: a, 26: u, 28: i, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 13: 72, 19: 20, 20: 21, 21: 22, 22: e, 23: s, 24: a, 26: u, 28: i, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 13: 73, 19: 20, 20: 21, 21: 22, 22: e, 23: s, 24: a, 26: u, 28: i, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 14: [1, 74] }, t(Tt, [2, 13], { 43: 23, 29: 49, 30: 61, 32: 62, 20: 75, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }), t(Tt, [2, 14]), t(Xt, [2, 16], { 12: [1, 76] }), t(Tt, [2, 36], { 12: [1, 77] }), t(Ot, [2, 19]), t(Ot, [2, 20]), { 25: [1, 78] }, { 27: [1, 79] }, t(Ot, [2, 23]), { 35: 80, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 86, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 87, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 88, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 89, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 90, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 91, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 92, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 93, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 94, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 95, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 96, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 97, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 98, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 99, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 100, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 101, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 102, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 103, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 104, 75: 81, 76: E, 77: S, 79: T, 80: C }, t(R, [2, 59]), { 35: 105, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 106, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 107, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 108, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 109, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 110, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 111, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 112, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 113, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 114, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 115, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 20: 116, 29: 49, 30: 61, 32: 62, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 43: 23, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }, { 12: [1, 118], 33: [1, 117] }, { 35: 119, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 120, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 121, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 122, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 123, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 124, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 35: 125, 75: 81, 76: E, 77: S, 79: T, 80: C }, { 14: [1, 126] }, { 14: [1, 127] }, { 14: [1, 128] }, { 14: [1, 129] }, { 1: [2, 8] }, t(Tt, [2, 15]), t(Xt, [2, 17], { 21: 22, 19: 130, 22: e, 23: s, 24: a, 26: u, 28: i }), t(Tt, [2, 37], { 19: 20, 20: 21, 21: 22, 43: 23, 29: 49, 30: 61, 32: 62, 13: 131, 22: e, 23: s, 24: a, 26: u, 28: i, 34: n, 36: l, 37: r, 38: h, 39: y, 40: f, 41: _, 44: v, 45: w, 46: N, 47: O, 48: P, 49: M, 50: W, 51: X, 52: q, 53: H, 54: Q, 55: K, 56: G, 57: J, 58: Z, 59: $, 60: tt, 61: et, 62: nt, 63: rt, 64: st, 65: at, 66: it, 67: ot, 68: lt, 69: ct, 70: ut, 71: ht, 72: dt, 73: pt, 74: ft }), t(Ot, [2, 21]), t(Ot, [2, 22]), t(R, [2, 39]), t(ce, [2, 71], { 75: 81, 35: 132, 76: E, 77: S, 79: T, 80: C }), t(It, [2, 73]), { 78: [1, 133] }, t(It, [2, 75]), t(It, [2, 76]), t(R, [2, 40]), t(R, [2, 41]), t(R, [2, 42]), t(R, [2, 43]), t(R, [2, 44]), t(R, [2, 45]), t(R, [2, 46]), t(R, [2, 47]), t(R, [2, 48]), t(R, [2, 49]), t(R, [2, 50]), t(R, [2, 51]), t(R, [2, 52]), t(R, [2, 53]), t(R, [2, 54]), t(R, [2, 55]), t(R, [2, 56]), t(R, [2, 57]), t(R, [2, 58]), t(R, [2, 60]), t(R, [2, 61]), t(R, [2, 62]), t(R, [2, 63]), t(R, [2, 64]), t(R, [2, 65]), t(R, [2, 66]), t(R, [2, 67]), t(R, [2, 68]), t(R, [2, 69]), t(R, [2, 70]), { 31: 134, 42: [1, 135] }, { 12: [1, 136] }, { 33: [1, 137] }, t(gt, [2, 28]), t(gt, [2, 29]), t(gt, [2, 30]), t(gt, [2, 31]), t(gt, [2, 32]), t(gt, [2, 33]), t(gt, [2, 34]), { 1: [2, 9] }, { 1: [2, 10] }, { 1: [2, 11] }, { 1: [2, 12] }, t(Xt, [2, 18]), t(Tt, [2, 38]), t(ce, [2, 72]), t(It, [2, 74]), t(R, [2, 24]), t(R, [2, 35]), t(qt, [2, 25]), t(qt, [2, 26], { 12: [1, 138] }), t(qt, [2, 27])], defaultActions: { 2: [2, 1], 3: [2, 2], 4: [2, 7], 5: [2, 3], 6: [2, 4], 7: [2, 5], 8: [2, 6], 74: [2, 8], 126: [2, 9], 127: [2, 10], 128: [2, 11], 129: [2, 12] }, parseError: d(function (m, x) { if (x.recoverable)
            this.trace(m);
        else {
            var k = new Error(m);
            throw k.hash = x, k;
        } }, "parseError"), parse: d(function (m) {
            var x = this, k = [0], b = [], D = [null], o = [], Pt = this.table, p = "", xt = 0, ue = 0, he = 0, Fe = 2, de = 1, Ue = o.slice.call(arguments, 1), A = Object.create(this.lexer), vt = { yy: {} };
            for (var Qt in this.yy)
                Object.prototype.hasOwnProperty.call(this.yy, Qt) && (vt.yy[Qt] = this.yy[Qt]);
            A.setInput(m, vt.yy), vt.yy.lexer = A, vt.yy.parser = this, typeof A.yylloc > "u" && (A.yylloc = {});
            var Kt = A.yylloc;
            o.push(Kt);
            var je = A.options && A.options.ranges;
            typeof vt.yy.parseError == "function" ? this.parseError = vt.yy.parseError : this.parseError = Object.getPrototypeOf(this).parseError;
            function ze(B) { k.length = k.length - 2 * B, D.length = D.length - B, o.length = o.length - B; }
            d(ze, "popStack");
            function pe() { var B; return B = b.pop() || A.lex() || de, typeof B != "number" && (B instanceof Array && (b = B, B = b.pop()), B = x.symbols_[B] || B), B; }
            d(pe, "lex");
            for (var L, Gt, kt, V, H0, Jt, Ct = {}, Bt, j, fe, Vt;;) {
                if (kt = k[k.length - 1], this.defaultActions[kt] ? V = this.defaultActions[kt] : ((L === null || typeof L > "u") && (L = pe()), V = Pt[kt] && Pt[kt][L]), typeof V > "u" || !V.length || !V[0]) {
                    var Zt = "";
                    Vt = [];
                    for (Bt in Pt[kt])
                        this.terminals_[Bt] && Bt > Fe && Vt.push("'" + this.terminals_[Bt] + "'");
                    A.showPosition ? Zt = "Parse error on line " + (xt + 1) + `:
` + A.showPosition() + `
Expecting ` + Vt.join(", ") + ", got '" + (this.terminals_[L] || L) + "'" : Zt = "Parse error on line " + (xt + 1) + ": Unexpected " + (L == de ? "end of input" : "'" + (this.terminals_[L] || L) + "'"), this.parseError(Zt, { text: A.match, token: this.terminals_[L] || L, line: A.yylineno, loc: Kt, expected: Vt });
                }
                if (V[0] instanceof Array && V.length > 1)
                    throw new Error("Parse Error: multiple actions possible at state: " + kt + ", token: " + L);
                switch (V[0]) {
                    case 1:
                        k.push(L), D.push(A.yytext), o.push(A.yylloc), k.push(V[1]), L = null, Gt ? (L = Gt, Gt = null) : (ue = A.yyleng, p = A.yytext, xt = A.yylineno, Kt = A.yylloc, he > 0 && he--);
                        break;
                    case 2:
                        if (j = this.productions_[V[1]][1], Ct.$ = D[D.length - j], Ct._$ = { first_line: o[o.length - (j || 1)].first_line, last_line: o[o.length - 1].last_line, first_column: o[o.length - (j || 1)].first_column, last_column: o[o.length - 1].last_column }, je && (Ct._$.range = [o[o.length - (j || 1)].range[0], o[o.length - 1].range[1]]), Jt = this.performAction.apply(Ct, [p, ue, xt, vt.yy, V[1], D, o].concat(Ue)), typeof Jt < "u")
                            return Jt;
                        j && (k = k.slice(0, -1 * j * 2), D = D.slice(0, -1 * j), o = o.slice(0, -1 * j)), k.push(this.productions_[V[1]][0]), D.push(Ct.$), o.push(Ct._$), fe = Pt[k[k.length - 2]][k[k.length - 1]], k.push(fe);
                        break;
                    case 3: return !0;
                }
            }
            return !0;
        }, "parse") }, Ye = (function () {
        var yt = { EOF: 1, parseError: d(function (x, k) { if (this.yy.parser)
                this.yy.parser.parseError(x, k);
            else
                throw new Error(x); }, "parseError"), setInput: d(function (m, x) { return this.yy = x || this.yy || {}, this._input = m, this._more = this._backtrack = this.done = !1, this.yylineno = this.yyleng = 0, this.yytext = this.matched = this.match = "", this.conditionStack = ["INITIAL"], this.yylloc = { first_line: 1, first_column: 0, last_line: 1, last_column: 0 }, this.options.ranges && (this.yylloc.range = [0, 0]), this.offset = 0, this; }, "setInput"), input: d(function () { var m = this._input[0]; this.yytext += m, this.yyleng++, this.offset++, this.match += m, this.matched += m; var x = m.match(/(?:\r\n?|\n).*/g); return x ? (this.yylineno++, this.yylloc.last_line++) : this.yylloc.last_column++, this.options.ranges && this.yylloc.range[1]++, this._input = this._input.slice(1), m; }, "input"), unput: d(function (m) { var x = m.length, k = m.split(/(?:\r\n?|\n)/g); this._input = m + this._input, this.yytext = this.yytext.substr(0, this.yytext.length - x), this.offset -= x; var b = this.match.split(/(?:\r\n?|\n)/g); this.match = this.match.substr(0, this.match.length - 1), this.matched = this.matched.substr(0, this.matched.length - 1), k.length - 1 && (this.yylineno -= k.length - 1); var D = this.yylloc.range; return this.yylloc = { first_line: this.yylloc.first_line, last_line: this.yylineno + 1, first_column: this.yylloc.first_column, last_column: k ? (k.length === b.length ? this.yylloc.first_column : 0) + b[b.length - k.length].length - k[0].length : this.yylloc.first_column - x }, this.options.ranges && (this.yylloc.range = [D[0], D[0] + this.yyleng - x]), this.yyleng = this.yytext.length, this; }, "unput"), more: d(function () { return this._more = !0, this; }, "more"), reject: d(function () {
                if (this.options.backtrack_lexer)
                    this._backtrack = !0;
                else
                    return this.parseError("Lexical error on line " + (this.yylineno + 1) + `. You can only invoke reject() in the lexer when the lexer is of the backtracking persuasion (options.backtrack_lexer = true).
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
                return this;
            }, "reject"), less: d(function (m) { this.unput(this.match.slice(m)); }, "less"), pastInput: d(function () { var m = this.matched.substr(0, this.matched.length - this.match.length); return (m.length > 20 ? "..." : "") + m.substr(-20).replace(/\n/g, ""); }, "pastInput"), upcomingInput: d(function () { var m = this.match; return m.length < 20 && (m += this._input.substr(0, 20 - m.length)), (m.substr(0, 20) + (m.length > 20 ? "..." : "")).replace(/\n/g, ""); }, "upcomingInput"), showPosition: d(function () {
                var m = this.pastInput(), x = new Array(m.length + 1).join("-");
                return m + this.upcomingInput() + `
` + x + "^";
            }, "showPosition"), test_match: d(function (m, x) { var k, b, D; if (this.options.backtrack_lexer && (D = { yylineno: this.yylineno, yylloc: { first_line: this.yylloc.first_line, last_line: this.last_line, first_column: this.yylloc.first_column, last_column: this.yylloc.last_column }, yytext: this.yytext, match: this.match, matches: this.matches, matched: this.matched, yyleng: this.yyleng, offset: this.offset, _more: this._more, _input: this._input, yy: this.yy, conditionStack: this.conditionStack.slice(0), done: this.done }, this.options.ranges && (D.yylloc.range = this.yylloc.range.slice(0))), b = m[0].match(/(?:\r\n?|\n).*/g), b && (this.yylineno += b.length), this.yylloc = { first_line: this.yylloc.last_line, last_line: this.yylineno + 1, first_column: this.yylloc.last_column, last_column: b ? b[b.length - 1].length - b[b.length - 1].match(/\r?\n?/)[0].length : this.yylloc.last_column + m[0].length }, this.yytext += m[0], this.match += m[0], this.matches = m, this.yyleng = this.yytext.length, this.options.ranges && (this.yylloc.range = [this.offset, this.offset += this.yyleng]), this._more = !1, this._backtrack = !1, this._input = this._input.slice(m[0].length), this.matched += m[0], k = this.performAction.call(this, this.yy, this, x, this.conditionStack[this.conditionStack.length - 1]), this.done && this._input && (this.done = !1), k)
                return k; if (this._backtrack) {
                for (var o in D)
                    this[o] = D[o];
                return !1;
            } return !1; }, "test_match"), next: d(function () {
                if (this.done)
                    return this.EOF;
                this._input || (this.done = !0);
                var m, x, k, b;
                this._more || (this.yytext = "", this.match = "");
                for (var D = this._currentRules(), o = 0; o < D.length; o++)
                    if (k = this._input.match(this.rules[D[o]]), k && (!x || k[0].length > x[0].length)) {
                        if (x = k, b = o, this.options.backtrack_lexer) {
                            if (m = this.test_match(k, D[o]), m !== !1)
                                return m;
                            if (this._backtrack) {
                                x = !1;
                                continue;
                            }
                            else
                                return !1;
                        }
                        else if (!this.options.flex)
                            break;
                    }
                return x ? (m = this.test_match(x, D[b]), m !== !1 ? m : !1) : this._input === "" ? this.EOF : this.parseError("Lexical error on line " + (this.yylineno + 1) + `. Unrecognized text.
` + this.showPosition(), { text: "", token: null, line: this.yylineno });
            }, "next"), lex: d(function () { var x = this.next(); return x || this.lex(); }, "lex"), begin: d(function (x) { this.conditionStack.push(x); }, "begin"), popState: d(function () { var x = this.conditionStack.length - 1; return x > 0 ? this.conditionStack.pop() : this.conditionStack[0]; }, "popState"), _currentRules: d(function () { return this.conditionStack.length && this.conditionStack[this.conditionStack.length - 1] ? this.conditions[this.conditionStack[this.conditionStack.length - 1]].rules : this.conditions.INITIAL.rules; }, "_currentRules"), topState: d(function (x) { return x = this.conditionStack.length - 1 - Math.abs(x || 0), x >= 0 ? this.conditionStack[x] : "INITIAL"; }, "topState"), pushState: d(function (x) { this.begin(x); }, "pushState"), stateStackSize: d(function () { return this.conditionStack.length; }, "stateStackSize"), options: {}, performAction: d(function (x, k, b, D) { var o = D; switch (b) {
                case 0: return 6;
                case 1: return 7;
                case 2: return 8;
                case 3: return 9;
                case 4: return 22;
                case 5: return 23;
                case 6:
                    return this.begin("acc_title"), 24;
                    break;
                case 7:
                    return this.popState(), "acc_title_value";
                    break;
                case 8:
                    return this.begin("acc_descr"), 26;
                    break;
                case 9:
                    return this.popState(), "acc_descr_value";
                    break;
                case 10:
                    this.begin("acc_descr_multiline");
                    break;
                case 11:
                    this.popState();
                    break;
                case 12: return "acc_descr_multiline_value";
                case 13: break;
                case 14:
                    c;
                    break;
                case 15: return 12;
                case 16: break;
                case 17: return 11;
                case 18: return 15;
                case 19: return 16;
                case 20: return 17;
                case 21: return 18;
                case 22:
                    return this.begin("person_ext"), 45;
                    break;
                case 23:
                    return this.begin("person"), 44;
                    break;
                case 24:
                    return this.begin("system_ext_queue"), 51;
                    break;
                case 25:
                    return this.begin("system_ext_db"), 50;
                    break;
                case 26:
                    return this.begin("system_ext"), 49;
                    break;
                case 27:
                    return this.begin("system_queue"), 48;
                    break;
                case 28:
                    return this.begin("system_db"), 47;
                    break;
                case 29:
                    return this.begin("system"), 46;
                    break;
                case 30:
                    return this.begin("boundary"), 37;
                    break;
                case 31:
                    return this.begin("enterprise_boundary"), 34;
                    break;
                case 32:
                    return this.begin("system_boundary"), 36;
                    break;
                case 33:
                    return this.begin("container_ext_queue"), 57;
                    break;
                case 34:
                    return this.begin("container_ext_db"), 56;
                    break;
                case 35:
                    return this.begin("container_ext"), 55;
                    break;
                case 36:
                    return this.begin("container_queue"), 54;
                    break;
                case 37:
                    return this.begin("container_db"), 53;
                    break;
                case 38:
                    return this.begin("container"), 52;
                    break;
                case 39:
                    return this.begin("container_boundary"), 38;
                    break;
                case 40:
                    return this.begin("component_ext_queue"), 63;
                    break;
                case 41:
                    return this.begin("component_ext_db"), 62;
                    break;
                case 42:
                    return this.begin("component_ext"), 61;
                    break;
                case 43:
                    return this.begin("component_queue"), 60;
                    break;
                case 44:
                    return this.begin("component_db"), 59;
                    break;
                case 45:
                    return this.begin("component"), 58;
                    break;
                case 46:
                    return this.begin("node"), 39;
                    break;
                case 47:
                    return this.begin("node"), 39;
                    break;
                case 48:
                    return this.begin("node_l"), 40;
                    break;
                case 49:
                    return this.begin("node_r"), 41;
                    break;
                case 50:
                    return this.begin("rel"), 64;
                    break;
                case 51:
                    return this.begin("birel"), 65;
                    break;
                case 52:
                    return this.begin("rel_u"), 66;
                    break;
                case 53:
                    return this.begin("rel_u"), 66;
                    break;
                case 54:
                    return this.begin("rel_d"), 67;
                    break;
                case 55:
                    return this.begin("rel_d"), 67;
                    break;
                case 56:
                    return this.begin("rel_l"), 68;
                    break;
                case 57:
                    return this.begin("rel_l"), 68;
                    break;
                case 58:
                    return this.begin("rel_r"), 69;
                    break;
                case 59:
                    return this.begin("rel_r"), 69;
                    break;
                case 60:
                    return this.begin("rel_b"), 70;
                    break;
                case 61:
                    return this.begin("rel_index"), 71;
                    break;
                case 62:
                    return this.begin("update_el_style"), 72;
                    break;
                case 63:
                    return this.begin("update_rel_style"), 73;
                    break;
                case 64:
                    return this.begin("update_layout_config"), 74;
                    break;
                case 65: return "EOF_IN_STRUCT";
                case 66:
                    return this.begin("attribute"), "ATTRIBUTE_EMPTY";
                    break;
                case 67:
                    this.begin("attribute");
                    break;
                case 68:
                    this.popState(), this.popState();
                    break;
                case 69: return 80;
                case 70: break;
                case 71: return 80;
                case 72:
                    this.begin("string");
                    break;
                case 73:
                    this.popState();
                    break;
                case 74: return "STR";
                case 75:
                    this.begin("string_kv");
                    break;
                case 76:
                    return this.begin("string_kv_key"), "STR_KEY";
                    break;
                case 77:
                    this.popState(), this.begin("string_kv_value");
                    break;
                case 78: return "STR_VALUE";
                case 79:
                    this.popState(), this.popState();
                    break;
                case 80: return "STR";
                case 81: return "LBRACE";
                case 82: return "RBRACE";
                case 83: return "SPACE";
                case 84: return "EOL";
                case 85: return 14;
            } }, "anonymous"), rules: [/^(?:.*direction\s+TB[^\n]*)/, /^(?:.*direction\s+BT[^\n]*)/, /^(?:.*direction\s+RL[^\n]*)/, /^(?:.*direction\s+LR[^\n]*)/, /^(?:title\s[^#\n;]+)/, /^(?:accDescription\s[^#\n;]+)/, /^(?:accTitle\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*:\s*)/, /^(?:(?!\n||)*[^\n]*)/, /^(?:accDescr\s*\{\s*)/, /^(?:[\}])/, /^(?:[^\}]*)/, /^(?:%%(?!\{)*[^\n]*(\r?\n?)+)/, /^(?:%%[^\n]*(\r?\n)*)/, /^(?:\s*(\r?\n)+)/, /^(?:\s+)/, /^(?:C4Context\b)/, /^(?:C4Container\b)/, /^(?:C4Component\b)/, /^(?:C4Dynamic\b)/, /^(?:C4Deployment\b)/, /^(?:Person_Ext\b)/, /^(?:Person\b)/, /^(?:SystemQueue_Ext\b)/, /^(?:SystemDb_Ext\b)/, /^(?:System_Ext\b)/, /^(?:SystemQueue\b)/, /^(?:SystemDb\b)/, /^(?:System\b)/, /^(?:Boundary\b)/, /^(?:Enterprise_Boundary\b)/, /^(?:System_Boundary\b)/, /^(?:ContainerQueue_Ext\b)/, /^(?:ContainerDb_Ext\b)/, /^(?:Container_Ext\b)/, /^(?:ContainerQueue\b)/, /^(?:ContainerDb\b)/, /^(?:Container\b)/, /^(?:Container_Boundary\b)/, /^(?:ComponentQueue_Ext\b)/, /^(?:ComponentDb_Ext\b)/, /^(?:Component_Ext\b)/, /^(?:ComponentQueue\b)/, /^(?:ComponentDb\b)/, /^(?:Component\b)/, /^(?:Deployment_Node\b)/, /^(?:Node\b)/, /^(?:Node_L\b)/, /^(?:Node_R\b)/, /^(?:Rel\b)/, /^(?:BiRel\b)/, /^(?:Rel_Up\b)/, /^(?:Rel_U\b)/, /^(?:Rel_Down\b)/, /^(?:Rel_D\b)/, /^(?:Rel_Left\b)/, /^(?:Rel_L\b)/, /^(?:Rel_Right\b)/, /^(?:Rel_R\b)/, /^(?:Rel_Back\b)/, /^(?:RelIndex\b)/, /^(?:UpdateElementStyle\b)/, /^(?:UpdateRelStyle\b)/, /^(?:UpdateLayoutConfig\b)/, /^(?:$)/, /^(?:[(][ ]*[,])/, /^(?:[(])/, /^(?:[)])/, /^(?:,,)/, /^(?:,)/, /^(?:[ ]*["]["])/, /^(?:[ ]*["])/, /^(?:["])/, /^(?:[^"]*)/, /^(?:[ ]*[\$])/, /^(?:[^=]*)/, /^(?:[=][ ]*["])/, /^(?:[^"]+)/, /^(?:["])/, /^(?:[^,]+)/, /^(?:\{)/, /^(?:\})/, /^(?:[\s]+)/, /^(?:[\n\r]+)/, /^(?:$)/], conditions: { acc_descr_multiline: { rules: [11, 12], inclusive: !1 }, acc_descr: { rules: [9], inclusive: !1 }, acc_title: { rules: [7], inclusive: !1 }, string_kv_value: { rules: [78, 79], inclusive: !1 }, string_kv_key: { rules: [77], inclusive: !1 }, string_kv: { rules: [76], inclusive: !1 }, string: { rules: [73, 74], inclusive: !1 }, attribute: { rules: [68, 69, 70, 71, 72, 75, 80], inclusive: !1 }, update_layout_config: { rules: [65, 66, 67, 68], inclusive: !1 }, update_rel_style: { rules: [65, 66, 67, 68], inclusive: !1 }, update_el_style: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_b: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_r: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_l: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_d: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_u: { rules: [65, 66, 67, 68], inclusive: !1 }, rel_bi: { rules: [], inclusive: !1 }, rel: { rules: [65, 66, 67, 68], inclusive: !1 }, node_r: { rules: [65, 66, 67, 68], inclusive: !1 }, node_l: { rules: [65, 66, 67, 68], inclusive: !1 }, node: { rules: [65, 66, 67, 68], inclusive: !1 }, index: { rules: [], inclusive: !1 }, rel_index: { rules: [65, 66, 67, 68], inclusive: !1 }, component_ext_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, component_ext_db: { rules: [65, 66, 67, 68], inclusive: !1 }, component_ext: { rules: [65, 66, 67, 68], inclusive: !1 }, component_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, component_db: { rules: [65, 66, 67, 68], inclusive: !1 }, component: { rules: [65, 66, 67, 68], inclusive: !1 }, container_boundary: { rules: [65, 66, 67, 68], inclusive: !1 }, container_ext_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, container_ext_db: { rules: [65, 66, 67, 68], inclusive: !1 }, container_ext: { rules: [65, 66, 67, 68], inclusive: !1 }, container_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, container_db: { rules: [65, 66, 67, 68], inclusive: !1 }, container: { rules: [65, 66, 67, 68], inclusive: !1 }, birel: { rules: [65, 66, 67, 68], inclusive: !1 }, system_boundary: { rules: [65, 66, 67, 68], inclusive: !1 }, enterprise_boundary: { rules: [65, 66, 67, 68], inclusive: !1 }, boundary: { rules: [65, 66, 67, 68], inclusive: !1 }, system_ext_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, system_ext_db: { rules: [65, 66, 67, 68], inclusive: !1 }, system_ext: { rules: [65, 66, 67, 68], inclusive: !1 }, system_queue: { rules: [65, 66, 67, 68], inclusive: !1 }, system_db: { rules: [65, 66, 67, 68], inclusive: !1 }, system: { rules: [65, 66, 67, 68], inclusive: !1 }, person_ext: { rules: [65, 66, 67, 68], inclusive: !1 }, person: { rules: [65, 66, 67, 68], inclusive: !1 }, INITIAL: { rules: [0, 1, 2, 3, 4, 5, 6, 8, 10, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 81, 82, 83, 84, 85], inclusive: !0 } } };
        return yt;
    })();
    Ht.lexer = Ye;
    function Mt() { this.yy = {}; }
    return d(Mt, "Parser"), Mt.prototype = Ht, Ht.Parser = Mt, new Mt;
})();
jt.parser = jt;
var We = jt, we = d(t => Et()[t], "getRequiredConfig"), St = d((t, e) => { for (let [s, a] of Object.entries(e))
    if (a !== void 0)
        if (typeof a == "object") {
            let [u, i] = Object.entries(a)[0];
            t[u] = i;
        }
        else
            t[s] = a; }, "assignAttributes"), Oe = d(() => ({ alias: "global", label: { text: "global" }, type: { text: "global" }, tags: null, link: null, parentBoundary: "" }), "createGlobalBoundary"), F = [], bt = [""], I = "global", Y = "", U = [Oe()], Lt = [], ie = "", oe = !1, zt = 4, Wt = 2, Pe, Xe = d(function () { return Pe; }, "getC4Type"), qe = d(function (t) { Pe = te(t, Et()); }, "setC4Type"), He = d(function (t, e, s, a, u, i, n, l, r) { if (t == null || e === void 0 || e === null || s === void 0 || s === null || a === void 0 || a === null)
    return; let h = {}, y = Lt.find(f => f.from === e && f.to === s); if (y ? h = y : Lt.push(h), h.type = t, h.from = e, h.to = s, h.label = { text: a }, u == null)
    h.techn = { text: "" };
else if (typeof u == "object") {
    let [f, _] = Object.entries(u)[0];
    h[f] = { text: _ };
}
else
    h.techn = { text: u }; if (i == null)
    h.descr = { text: "" };
else if (typeof i == "object") {
    let [f, _] = Object.entries(i)[0];
    h[f] = { text: _ };
}
else
    h.descr = { text: i }; St(h, { sprite: n, tags: l, link: r }), h.wrap = mt(); }, "addRel"), Qe = d(function (t, e, s, a, u, i, n) { if (e === null || s === null)
    return; let l = {}, r = F.find(h => h.alias === e); if (r && e === r.alias ? l = r : (l.alias = e, F.push(l)), s == null ? l.label = { text: "" } : l.label = { text: s }, a == null)
    l.descr = { text: "" };
else if (typeof a == "object") {
    let [h, y] = Object.entries(a)[0];
    l[h] = { text: y };
}
else
    l.descr = { text: a }; St(l, { sprite: u, tags: i, link: n }), l.typeC4Shape = { text: t }, l.parentBoundary = I, l.wrap = mt(); }, "addPersonOrSystem"), Ke = d(function (t, e, s, a, u, i, n, l) { if (e === null || s === null)
    return; let r = {}, h = F.find(y => y.alias === e); if (h && e === h.alias ? r = h : (r.alias = e, F.push(r)), s == null ? r.label = { text: "" } : r.label = { text: s }, a == null)
    r.techn = { text: "" };
else if (typeof a == "object") {
    let [y, f] = Object.entries(a)[0];
    r[y] = { text: f };
}
else
    r.techn = { text: a }; if (u == null)
    r.descr = { text: "" };
else if (typeof u == "object") {
    let [y, f] = Object.entries(u)[0];
    r[y] = { text: f };
}
else
    r.descr = { text: u }; St(r, { sprite: i, tags: n, link: l }), r.wrap = mt(), r.typeC4Shape = { text: t }, r.parentBoundary = I; }, "addContainer"), Ge = d(function (t, e, s, a, u, i, n, l) { if (e === null || s === null)
    return; let r = {}, h = F.find(y => y.alias === e); if (h && e === h.alias ? r = h : (r.alias = e, F.push(r)), s == null ? r.label = { text: "" } : r.label = { text: s }, a == null)
    r.techn = { text: "" };
else if (typeof a == "object") {
    let [y, f] = Object.entries(a)[0];
    r[y] = { text: f };
}
else
    r.techn = { text: a }; if (u == null)
    r.descr = { text: "" };
else if (typeof u == "object") {
    let [y, f] = Object.entries(u)[0];
    r[y] = { text: f };
}
else
    r.descr = { text: u }; St(r, { sprite: i, tags: n, link: l }), r.wrap = mt(), r.typeC4Shape = { text: t }, r.parentBoundary = I; }, "addComponent"), Je = d(function (t, e, s, a, u) { if (t === null || e === null)
    return; let i = {}, n = U.find(l => l.alias === t); if (n && t === n.alias ? i = n : (i.alias = t, U.push(i)), e == null ? i.label = { text: "" } : i.label = { text: e }, s == null)
    i.type = { text: "system" };
else if (typeof s == "object") {
    let [l, r] = Object.entries(s)[0];
    i[l] = { text: r };
}
else
    i.type = { text: s }; St(i, { tags: a, link: u }), i.parentBoundary = I, i.wrap = mt(), Y = I, I = t, bt.push(Y); }, "addPersonOrSystemBoundary"), Ze = d(function (t, e, s, a, u) { if (t === null || e === null)
    return; let i = {}, n = U.find(l => l.alias === t); if (n && t === n.alias ? i = n : (i.alias = t, U.push(i)), e == null ? i.label = { text: "" } : i.label = { text: e }, s == null)
    i.type = { text: "container" };
else if (typeof s == "object") {
    let [l, r] = Object.entries(s)[0];
    i[l] = { text: r };
}
else
    i.type = { text: s }; St(i, { tags: a, link: u }), i.parentBoundary = I, i.wrap = mt(), Y = I, I = t, bt.push(Y); }, "addContainerBoundary"), $e = d(function (t, e, s, a, u, i, n, l) { if (e === null || s === null)
    return; let r = {}, h = U.find(y => y.alias === e); if (h && e === h.alias ? r = h : (r.alias = e, U.push(r)), s == null ? r.label = { text: "" } : r.label = { text: s }, a == null)
    r.type = { text: "node" };
else if (typeof a == "object") {
    let [y, f] = Object.entries(a)[0];
    r[y] = { text: f };
}
else
    r.type = { text: a }; if (u == null)
    r.descr = { text: "" };
else if (typeof u == "object") {
    let [y, f] = Object.entries(u)[0];
    r[y] = { text: f };
}
else
    r.descr = { text: u }; St(r, { tags: n, link: l }), r.nodeType = t, r.parentBoundary = I, r.wrap = mt(), Y = I, I = e, bt.push(Y); }, "addDeploymentNode"), t0 = d(function () { I = Y, bt.pop(), Y = bt.pop(), bt.push(Y); }, "popBoundaryParseStack"), e0 = d(function (t, e, s, a, u, i, n, l, r, h, y) { let f = F.find(_ => _.alias === e); if (!(f === void 0 && (f = U.find(_ => _.alias === e), f === void 0))) {
    if (s != null)
        if (typeof s == "object") {
            let [_, v] = Object.entries(s)[0];
            f[_] = v;
        }
        else
            f.bgColor = s;
    if (a != null)
        if (typeof a == "object") {
            let [_, v] = Object.entries(a)[0];
            f[_] = v;
        }
        else
            f.fontColor = a;
    if (u != null)
        if (typeof u == "object") {
            let [_, v] = Object.entries(u)[0];
            f[_] = v;
        }
        else
            f.borderColor = u;
    if (i != null)
        if (typeof i == "object") {
            let [_, v] = Object.entries(i)[0];
            f[_] = v;
        }
        else
            f.shadowing = i;
    if (n != null)
        if (typeof n == "object") {
            let [_, v] = Object.entries(n)[0];
            f[_] = v;
        }
        else
            f.shape = n;
    if (l != null)
        if (typeof l == "object") {
            let [_, v] = Object.entries(l)[0];
            f[_] = v;
        }
        else
            f.sprite = l;
    if (r != null)
        if (typeof r == "object") {
            let [_, v] = Object.entries(r)[0];
            f[_] = v;
        }
        else
            f.techn = r;
    if (h != null)
        if (typeof h == "object") {
            let [_, v] = Object.entries(h)[0];
            f[_] = v;
        }
        else
            f.legendText = h;
    if (y != null)
        if (typeof y == "object") {
            let [_, v] = Object.entries(y)[0];
            f[_] = v;
        }
        else
            f.legendSprite = y;
} }, "updateElStyle"), n0 = d(function (t, e, s, a, u, i, n) { let l = Lt.find(r => r.from === e && r.to === s); if (l !== void 0) {
    if (a != null)
        if (typeof a == "object") {
            let [r, h] = Object.entries(a)[0];
            l[r] = h;
        }
        else
            l.textColor = a;
    if (u != null)
        if (typeof u == "object") {
            let [r, h] = Object.entries(u)[0];
            l[r] = h;
        }
        else
            l.lineColor = u;
    if (i != null)
        if (typeof i == "object") {
            let [r, h] = Object.entries(i)[0];
            l[r] = parseInt(h);
        }
        else
            l.offsetX = parseInt(i);
    if (n != null)
        if (typeof n == "object") {
            let [r, h] = Object.entries(n)[0];
            l[r] = parseInt(h);
        }
        else
            l.offsetY = parseInt(n);
} }, "updateRelStyle"), r0 = d(function (t, e, s) { let a = zt, u = Wt; if (typeof e == "object") {
    let i = Object.values(e)[0];
    a = parseInt(i);
}
else
    a = parseInt(e); if (typeof s == "object") {
    let i = Object.values(s)[0];
    u = parseInt(i);
}
else
    u = parseInt(s); a >= 1 && (zt = a), u >= 1 && (Wt = u); }, "updateLayoutConfig"), s0 = d(function () { return zt; }, "getC4ShapeInRow"), a0 = d(function () { return Wt; }, "getC4BoundaryInRow"), i0 = d(function () { return I; }, "getCurrentBoundaryParse"), o0 = d(function () { return Y; }, "getParentBoundaryParse"), De = d(function (t) { return t == null ? F : F.filter(e => e.parentBoundary === t); }, "getC4ShapeArray"), l0 = d(function (t) { return F.find(e => e.alias === t); }, "getC4Shape"), c0 = d(function (t) { return Object.keys(De(t)); }, "getC4ShapeKeys"), Ne = d(function (t) { return t == null ? U : U.filter(e => e.parentBoundary === t); }, "getBoundaries"), u0 = Ne, h0 = d(function () { return Lt; }, "getRels"), d0 = d(function () { return ie; }, "getTitle"), p0 = d(function (t) { oe = t; }, "setWrap"), mt = d(function () { return oe; }, "autoWrap"), f0 = d(function () { F = [], U = [Oe()], Y = "", I = "global", bt = [""], Lt = [], bt = [""], ie = "", oe = !1, zt = 4, Wt = 2; }, "clear"), y0 = { SOLID: 0, DOTTED: 1, NOTE: 2, SOLID_CROSS: 3, DOTTED_CROSS: 4, SOLID_OPEN: 5, DOTTED_OPEN: 6, LOOP_START: 10, LOOP_END: 11, ALT_START: 12, ALT_ELSE: 13, ALT_END: 14, OPT_START: 15, OPT_END: 16, ACTIVE_START: 17, ACTIVE_END: 18, PAR_START: 19, PAR_AND: 20, PAR_END: 21, RECT_START: 22, RECT_END: 23, SOLID_POINT: 24, DOTTED_POINT: 25 }, b0 = { FILLED: 0, OPEN: 1 }, _0 = { LEFTOF: 0, RIGHTOF: 1, OVER: 2 }, m0 = d(function (t) { ie = te(t, Et()); }, "setTitle"), re = { addPersonOrSystem: Qe, addPersonOrSystemBoundary: Je, addContainer: Ke, addContainerBoundary: Ze, addComponent: Ge, addDeploymentNode: $e, popBoundaryParseStack: t0, addRel: He, updateElStyle: e0, updateRelStyle: n0, updateLayoutConfig: r0, autoWrap: mt, setWrap: p0, getC4ShapeArray: De, getC4Shape: l0, getC4ShapeKeys: c0, getBoundaries: Ne, getBoundarys: u0, getCurrentBoundaryParse: i0, getParentBoundaryParse: o0, getRels: h0, getTitle: d0, getC4Type: Xe, getC4ShapeInRow: s0, getC4BoundaryInRow: a0, setAccTitle: _e, getAccTitle: me, getAccDescription: xe, setAccDescription: ge, getConfig: d(() => we("c4"), "getConfig"), clear: f0, LINETYPE: y0, ARROWTYPE: b0, PLACEMENT: _0, setTitle: m0, setC4Type: qe }, Ae = d(function (t, e) { return Ee(t, e); }, "drawRect"), g0 = d((t, e, s, a) => { let u = t.append("g"), i = 0; for (let n of e) {
    let l = n.textColor ? n.textColor : "#444444", r = n.lineColor ? n.lineColor : "#444444", h = n.offsetX ? parseInt(String(n.offsetX)) : 0, y = n.offsetY ? parseInt(String(n.offsetY)) : 0, f = "";
    if (i === 0) {
        let w = u.append("line");
        w.attr("x1", n.startPoint.x), w.attr("y1", n.startPoint.y), w.attr("x2", n.endPoint.x), w.attr("y2", n.endPoint.y), w.attr("stroke-width", "1"), w.attr("stroke", r), w.style("fill", "none"), n.type !== "rel_b" && w.attr("marker-end", "url(" + f + "#" + a + "-arrowhead)"), (n.type === "birel" || n.type === "rel_b") && w.attr("marker-start", "url(" + f + "#" + a + "-arrowend)"), i = -1;
    }
    else {
        let w = u.append("path");
        w.attr("fill", "none").attr("stroke-width", "1").attr("stroke", r).attr("d", "Mstartx,starty Qcontrolx,controly stopx,stopy ".replaceAll("startx", n.startPoint.x).replaceAll("starty", n.startPoint.y).replaceAll("controlx", n.startPoint.x + (n.endPoint.x - n.startPoint.x) / 2 - (n.endPoint.x - n.startPoint.x) / 4).replaceAll("controly", n.startPoint.y + (n.endPoint.y - n.startPoint.y) / 2).replaceAll("stopx", n.endPoint.x).replaceAll("stopy", n.endPoint.y)), n.type !== "rel_b" && w.attr("marker-end", "url(" + f + "#" + a + "-arrowhead)"), (n.type === "birel" || n.type === "rel_b") && w.attr("marker-start", "url(" + f + "#" + a + "-arrowend)");
    }
    let _ = n.label.width, v = s.messageFont();
    Dt(s)(n.label.text, u, Math.min(n.startPoint.x, n.endPoint.x) + Math.abs(n.endPoint.x - n.startPoint.x) / 2 + h, Math.min(n.startPoint.y, n.endPoint.y) + Math.abs(n.endPoint.y - n.startPoint.y) / 2 + y, _, n.label.height, { fill: l }, v), n.techn && n.techn.text !== "" && (v = s.messageFont(), Dt(s)("[" + n.techn.text + "]", u, Math.min(n.startPoint.x, n.endPoint.x) + Math.abs(n.endPoint.x - n.startPoint.x) / 2 + h, Math.min(n.startPoint.y, n.endPoint.y) + Math.abs(n.endPoint.y - n.startPoint.y) / 2 + s.messageFontSize + 5 + y, Math.max(_, n.techn.width), n.techn.height, { fill: l, "font-style": "italic" }, v));
} }, "drawRels"), x0 = d(function (t, e, s) { let a = t.append("g"), u = e.bgColor ? e.bgColor : "none", i = e.borderColor ? e.borderColor : "#444444", n = e.fontColor ? e.fontColor : "black", l = { "stroke-width": 1, "stroke-dasharray": "7.0,7.0" }; e.nodeType && (l = { "stroke-width": 1 }); let r = { x: e.x, y: e.y, fill: u, stroke: i, width: e.width, height: e.height, rx: 2.5, ry: 2.5, attrs: l }; Ae(a, r); let h = s.boundaryFont(); h.fontWeight = "bold", h.fontSize = h.fontSize + 2, h.fontColor = n, Dt(s)(e.label.text, a, e.x, e.y + e.label.Y, e.width, e.height, { fill: "#444444" }, h), e.type && e.type.text !== "" && (h = s.boundaryFont(), h.fontColor = n, Dt(s)(e.type.text, a, e.x, e.y + e.type.Y, e.width, e.height, { fill: "#444444" }, h)), e.descr && e.descr.text !== "" && (h = s.boundaryFont(), h.fontSize = h.fontSize - 2, h.fontColor = n, Dt(s)(e.descr.text, a, e.x, e.y + e.descr.Y, e.width, e.height, { fill: "#444444" }, h)); }, "drawBoundary"), v0 = d(function (t, e) { t.append("defs").append("symbol").attr("id", e + "-database").attr("fill-rule", "evenodd").attr("clip-rule", "evenodd").append("path").attr("transform", "scale(.5)").attr("d", "M12.258.001l.256.004.255.005.253.008.251.01.249.012.247.015.246.016.242.019.241.02.239.023.236.024.233.027.231.028.229.031.225.032.223.034.22.036.217.038.214.04.211.041.208.043.205.045.201.046.198.048.194.05.191.051.187.053.183.054.18.056.175.057.172.059.168.06.163.061.16.063.155.064.15.066.074.033.073.033.071.034.07.034.069.035.068.035.067.035.066.035.064.036.064.036.062.036.06.036.06.037.058.037.058.037.055.038.055.038.053.038.052.038.051.039.05.039.048.039.047.039.045.04.044.04.043.04.041.04.04.041.039.041.037.041.036.041.034.041.033.042.032.042.03.042.029.042.027.042.026.043.024.043.023.043.021.043.02.043.018.044.017.043.015.044.013.044.012.044.011.045.009.044.007.045.006.045.004.045.002.045.001.045v17l-.001.045-.002.045-.004.045-.006.045-.007.045-.009.044-.011.045-.012.044-.013.044-.015.044-.017.043-.018.044-.02.043-.021.043-.023.043-.024.043-.026.043-.027.042-.029.042-.03.042-.032.042-.033.042-.034.041-.036.041-.037.041-.039.041-.04.041-.041.04-.043.04-.044.04-.045.04-.047.039-.048.039-.05.039-.051.039-.052.038-.053.038-.055.038-.055.038-.058.037-.058.037-.06.037-.06.036-.062.036-.064.036-.064.036-.066.035-.067.035-.068.035-.069.035-.07.034-.071.034-.073.033-.074.033-.15.066-.155.064-.16.063-.163.061-.168.06-.172.059-.175.057-.18.056-.183.054-.187.053-.191.051-.194.05-.198.048-.201.046-.205.045-.208.043-.211.041-.214.04-.217.038-.22.036-.223.034-.225.032-.229.031-.231.028-.233.027-.236.024-.239.023-.241.02-.242.019-.246.016-.247.015-.249.012-.251.01-.253.008-.255.005-.256.004-.258.001-.258-.001-.256-.004-.255-.005-.253-.008-.251-.01-.249-.012-.247-.015-.245-.016-.243-.019-.241-.02-.238-.023-.236-.024-.234-.027-.231-.028-.228-.031-.226-.032-.223-.034-.22-.036-.217-.038-.214-.04-.211-.041-.208-.043-.204-.045-.201-.046-.198-.048-.195-.05-.19-.051-.187-.053-.184-.054-.179-.056-.176-.057-.172-.059-.167-.06-.164-.061-.159-.063-.155-.064-.151-.066-.074-.033-.072-.033-.072-.034-.07-.034-.069-.035-.068-.035-.067-.035-.066-.035-.064-.036-.063-.036-.062-.036-.061-.036-.06-.037-.058-.037-.057-.037-.056-.038-.055-.038-.053-.038-.052-.038-.051-.039-.049-.039-.049-.039-.046-.039-.046-.04-.044-.04-.043-.04-.041-.04-.04-.041-.039-.041-.037-.041-.036-.041-.034-.041-.033-.042-.032-.042-.03-.042-.029-.042-.027-.042-.026-.043-.024-.043-.023-.043-.021-.043-.02-.043-.018-.044-.017-.043-.015-.044-.013-.044-.012-.044-.011-.045-.009-.044-.007-.045-.006-.045-.004-.045-.002-.045-.001-.045v-17l.001-.045.002-.045.004-.045.006-.045.007-.045.009-.044.011-.045.012-.044.013-.044.015-.044.017-.043.018-.044.02-.043.021-.043.023-.043.024-.043.026-.043.027-.042.029-.042.03-.042.032-.042.033-.042.034-.041.036-.041.037-.041.039-.041.04-.041.041-.04.043-.04.044-.04.046-.04.046-.039.049-.039.049-.039.051-.039.052-.038.053-.038.055-.038.056-.038.057-.037.058-.037.06-.037.061-.036.062-.036.063-.036.064-.036.066-.035.067-.035.068-.035.069-.035.07-.034.072-.034.072-.033.074-.033.151-.066.155-.064.159-.063.164-.061.167-.06.172-.059.176-.057.179-.056.184-.054.187-.053.19-.051.195-.05.198-.048.201-.046.204-.045.208-.043.211-.041.214-.04.217-.038.22-.036.223-.034.226-.032.228-.031.231-.028.234-.027.236-.024.238-.023.241-.02.243-.019.245-.016.247-.015.249-.012.251-.01.253-.008.255-.005.256-.004.258-.001.258.001zm-9.258 20.499v.01l.001.021.003.021.004.022.005.021.006.022.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.023.018.024.019.024.021.024.022.025.023.024.024.025.052.049.056.05.061.051.066.051.07.051.075.051.079.052.084.052.088.052.092.052.097.052.102.051.105.052.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.048.144.049.147.047.152.047.155.047.16.045.163.045.167.043.171.043.176.041.178.041.183.039.187.039.19.037.194.035.197.035.202.033.204.031.209.03.212.029.216.027.219.025.222.024.226.021.23.02.233.018.236.016.24.015.243.012.246.01.249.008.253.005.256.004.259.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.021.224-.024.22-.026.216-.027.212-.028.21-.031.205-.031.202-.034.198-.034.194-.036.191-.037.187-.039.183-.04.179-.04.175-.042.172-.043.168-.044.163-.045.16-.046.155-.046.152-.047.148-.048.143-.049.139-.049.136-.05.131-.05.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.053.083-.051.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.05.023-.024.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.023.01-.022.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.127l-.077.055-.08.053-.083.054-.085.053-.087.052-.09.052-.093.051-.095.05-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.045-.118.044-.12.043-.122.042-.124.042-.126.041-.128.04-.13.04-.132.038-.134.038-.135.037-.138.037-.139.035-.142.035-.143.034-.144.033-.147.032-.148.031-.15.03-.151.03-.153.029-.154.027-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.01-.179.008-.179.008-.181.006-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.006-.179-.008-.179-.008-.178-.01-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.027-.153-.029-.151-.03-.15-.03-.148-.031-.146-.032-.145-.033-.143-.034-.141-.035-.14-.035-.137-.037-.136-.037-.134-.038-.132-.038-.13-.04-.128-.04-.126-.041-.124-.042-.122-.042-.12-.044-.117-.043-.116-.045-.113-.045-.112-.046-.109-.047-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.05-.093-.052-.09-.051-.087-.052-.085-.053-.083-.054-.08-.054-.077-.054v4.127zm0-5.654v.011l.001.021.003.021.004.021.005.022.006.022.007.022.009.022.01.022.011.023.012.023.013.023.015.024.016.023.017.024.018.024.019.024.021.024.022.024.023.025.024.024.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.052.11.051.114.051.119.052.123.05.127.051.131.05.135.049.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.044.171.042.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.022.23.02.233.018.236.016.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.012.241-.015.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.048.139-.05.136-.049.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.051.051-.049.023-.025.023-.024.021-.025.02-.024.019-.024.018-.024.017-.024.015-.023.014-.023.013-.024.012-.022.01-.023.01-.023.008-.022.006-.022.006-.022.004-.021.004-.022.001-.021.001-.021v-4.139l-.077.054-.08.054-.083.054-.085.052-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.049-.105.048-.106.047-.109.047-.111.046-.114.045-.115.044-.118.044-.12.044-.122.042-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.035-.143.033-.144.033-.147.033-.148.031-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.025-.161.024-.162.023-.163.022-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.011-.178.009-.179.009-.179.007-.181.007-.182.005-.182.004-.184.003-.184.002h-.37l-.184-.002-.184-.003-.182-.004-.182-.005-.181-.007-.179-.007-.179-.009-.178-.009-.176-.011-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.022-.162-.023-.161-.024-.159-.025-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.031-.146-.033-.145-.033-.143-.033-.141-.035-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.04-.126-.041-.124-.042-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.047-.105-.048-.102-.049-.1-.049-.097-.05-.095-.051-.093-.051-.09-.051-.087-.053-.085-.052-.083-.054-.08-.054-.077-.054v4.139zm0-5.666v.011l.001.02.003.022.004.021.005.022.006.021.007.022.009.023.01.022.011.023.012.023.013.023.015.023.016.024.017.024.018.023.019.024.021.025.022.024.023.024.024.025.052.05.056.05.061.05.066.051.07.051.075.052.079.051.084.052.088.052.092.052.097.052.102.052.105.051.11.052.114.051.119.051.123.051.127.05.131.05.135.05.139.049.144.048.147.048.152.047.155.046.16.045.163.045.167.043.171.043.176.042.178.04.183.04.187.038.19.037.194.036.197.034.202.033.204.032.209.03.212.028.216.027.219.025.222.024.226.021.23.02.233.018.236.017.24.014.243.012.246.01.249.008.253.006.256.003.259.001.26-.001.257-.003.254-.006.25-.008.247-.01.244-.013.241-.014.237-.016.233-.018.231-.02.226-.022.224-.024.22-.025.216-.027.212-.029.21-.03.205-.032.202-.033.198-.035.194-.036.191-.037.187-.039.183-.039.179-.041.175-.042.172-.043.168-.044.163-.045.16-.045.155-.047.152-.047.148-.048.143-.049.139-.049.136-.049.131-.051.126-.05.123-.051.118-.052.114-.051.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.052.07-.051.065-.051.06-.051.056-.05.051-.049.023-.025.023-.025.021-.024.02-.024.019-.024.018-.024.017-.024.015-.023.014-.024.013-.023.012-.023.01-.022.01-.023.008-.022.006-.022.006-.022.004-.022.004-.021.001-.021.001-.021v-4.153l-.077.054-.08.054-.083.053-.085.053-.087.053-.09.051-.093.051-.095.051-.097.05-.1.049-.102.048-.105.048-.106.048-.109.046-.111.046-.114.046-.115.044-.118.044-.12.043-.122.043-.124.042-.126.041-.128.04-.13.039-.132.039-.134.038-.135.037-.138.036-.139.036-.142.034-.143.034-.144.033-.147.032-.148.032-.15.03-.151.03-.153.028-.154.028-.156.027-.158.026-.159.024-.161.024-.162.023-.163.023-.165.021-.166.02-.167.019-.169.018-.169.017-.171.016-.173.015-.173.014-.175.013-.175.012-.177.01-.178.01-.179.009-.179.007-.181.006-.182.006-.182.004-.184.003-.184.001-.185.001-.185-.001-.184-.001-.184-.003-.182-.004-.182-.006-.181-.006-.179-.007-.179-.009-.178-.01-.176-.01-.176-.012-.175-.013-.173-.014-.172-.015-.171-.016-.17-.017-.169-.018-.167-.019-.166-.02-.165-.021-.163-.023-.162-.023-.161-.024-.159-.024-.157-.026-.156-.027-.155-.028-.153-.028-.151-.03-.15-.03-.148-.032-.146-.032-.145-.033-.143-.034-.141-.034-.14-.036-.137-.036-.136-.037-.134-.038-.132-.039-.13-.039-.128-.041-.126-.041-.124-.041-.122-.043-.12-.043-.117-.044-.116-.044-.113-.046-.112-.046-.109-.046-.106-.048-.105-.048-.102-.048-.1-.05-.097-.049-.095-.051-.093-.051-.09-.052-.087-.052-.085-.053-.083-.053-.08-.054-.077-.054v4.153zm8.74-8.179l-.257.004-.254.005-.25.008-.247.011-.244.012-.241.014-.237.016-.233.018-.231.021-.226.022-.224.023-.22.026-.216.027-.212.028-.21.031-.205.032-.202.033-.198.034-.194.036-.191.038-.187.038-.183.04-.179.041-.175.042-.172.043-.168.043-.163.045-.16.046-.155.046-.152.048-.148.048-.143.048-.139.049-.136.05-.131.05-.126.051-.123.051-.118.051-.114.052-.11.052-.106.052-.101.052-.096.052-.092.052-.088.052-.083.052-.079.052-.074.051-.07.052-.065.051-.06.05-.056.05-.051.05-.023.025-.023.024-.021.024-.02.025-.019.024-.018.024-.017.023-.015.024-.014.023-.013.023-.012.023-.01.023-.01.022-.008.022-.006.023-.006.021-.004.022-.004.021-.001.021-.001.021.001.021.001.021.004.021.004.022.006.021.006.023.008.022.01.022.01.023.012.023.013.023.014.023.015.024.017.023.018.024.019.024.02.025.021.024.023.024.023.025.051.05.056.05.06.05.065.051.07.052.074.051.079.052.083.052.088.052.092.052.096.052.101.052.106.052.11.052.114.052.118.051.123.051.126.051.131.05.136.05.139.049.143.048.148.048.152.048.155.046.16.046.163.045.168.043.172.043.175.042.179.041.183.04.187.038.191.038.194.036.198.034.202.033.205.032.21.031.212.028.216.027.22.026.224.023.226.022.231.021.233.018.237.016.241.014.244.012.247.011.25.008.254.005.257.004.26.001.26-.001.257-.004.254-.005.25-.008.247-.011.244-.012.241-.014.237-.016.233-.018.231-.021.226-.022.224-.023.22-.026.216-.027.212-.028.21-.031.205-.032.202-.033.198-.034.194-.036.191-.038.187-.038.183-.04.179-.041.175-.042.172-.043.168-.043.163-.045.16-.046.155-.046.152-.048.148-.048.143-.048.139-.049.136-.05.131-.05.126-.051.123-.051.118-.051.114-.052.11-.052.106-.052.101-.052.096-.052.092-.052.088-.052.083-.052.079-.052.074-.051.07-.052.065-.051.06-.05.056-.05.051-.05.023-.025.023-.024.021-.024.02-.025.019-.024.018-.024.017-.023.015-.024.014-.023.013-.023.012-.023.01-.023.01-.022.008-.022.006-.023.006-.021.004-.022.004-.021.001-.021.001-.021-.001-.021-.001-.021-.004-.021-.004-.022-.006-.021-.006-.023-.008-.022-.01-.022-.01-.023-.012-.023-.013-.023-.014-.023-.015-.024-.017-.023-.018-.024-.019-.024-.02-.025-.021-.024-.023-.024-.023-.025-.051-.05-.056-.05-.06-.05-.065-.051-.07-.052-.074-.051-.079-.052-.083-.052-.088-.052-.092-.052-.096-.052-.101-.052-.106-.052-.11-.052-.114-.052-.118-.051-.123-.051-.126-.051-.131-.05-.136-.05-.139-.049-.143-.048-.148-.048-.152-.048-.155-.046-.16-.046-.163-.045-.168-.043-.172-.043-.175-.042-.179-.041-.183-.04-.187-.038-.191-.038-.194-.036-.198-.034-.202-.033-.205-.032-.21-.031-.212-.028-.216-.027-.22-.026-.224-.023-.226-.022-.231-.021-.233-.018-.237-.016-.241-.014-.244-.012-.247-.011-.25-.008-.254-.005-.257-.004-.26-.001-.26.001z"); }, "insertDatabaseIcon"), k0 = d(function (t, e) { t.append("defs").append("symbol").attr("id", e + "-computer").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M2 2v13h20v-13h-20zm18 11h-16v-9h16v9zm-10.228 6l.466-1h3.524l.467 1h-4.457zm14.228 3h-24l2-6h2.104l-1.33 4h18.45l-1.297-4h2.073l2 6zm-5-10h-14v-7h14v7z"); }, "insertComputerIcon"), E0 = d(function (t, e) { t.append("defs").append("symbol").attr("id", e + "-clock").attr("width", "24").attr("height", "24").append("path").attr("transform", "scale(.5)").attr("d", "M12 2c5.514 0 10 4.486 10 10s-4.486 10-10 10-10-4.486-10-10 4.486-10 10-10zm0-2c-6.627 0-12 5.373-12 12s5.373 12 12 12 12-5.373 12-12-5.373-12-12-12zm5.848 12.459c.202.038.202.333.001.372-1.907.361-6.045 1.111-6.547 1.111-.719 0-1.301-.582-1.301-1.301 0-.512.77-5.447 1.125-7.445.034-.192.312-.181.343.014l.985 6.238 5.394 1.011z"); }, "insertClockIcon"), S0 = d(function (t, e) { t.append("defs").append("marker").attr("id", e + "-arrowhead").attr("refX", 9).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 0 0 L 10 5 L 0 10 z"); }, "insertArrowHead"), T0 = d(function (t, e) { t.append("defs").append("marker").attr("id", e + "-arrowend").attr("refX", 1).attr("refY", 5).attr("markerUnits", "userSpaceOnUse").attr("markerWidth", 12).attr("markerHeight", 12).attr("orient", "auto").append("path").attr("d", "M 10 0 L 0 5 L 10 10 z"); }, "insertArrowEnd"), C0 = d(function (t, e) { t.append("defs").append("marker").attr("id", e + "-filled-head").attr("refX", 18).attr("refY", 7).attr("markerWidth", 20).attr("markerHeight", 28).attr("orient", "auto").append("path").attr("d", "M 18,7 L9,13 L14,7 L9,1 Z"); }, "insertArrowFilledHead"), R0 = d(function (t, e) { let a = t.append("defs").append("marker").attr("id", e + "-crosshead").attr("markerWidth", 15).attr("markerHeight", 8).attr("orient", "auto").attr("refX", 16).attr("refY", 4); a.append("path").attr("fill", "black").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1px").attr("d", "M 9,2 V 6 L16,4 Z"), a.append("path").attr("fill", "none").attr("stroke", "#000000").style("stroke-dasharray", "0, 0").attr("stroke-width", "1px").attr("d", "M 0,1 L 6,7 M 6,1 L 0,7"); }, "insertArrowCrossHead"), Dt = (function () { function t(u, i, n, l, r, h, y) { let f = i.append("text").attr("x", n + r / 2).attr("y", l + h / 2 + 5).style("text-anchor", "middle").text(u); a(f, y); } d(t, "byText"); function e(u, i, n, l, r, h, y, f) { let { fontSize: _, fontFamily: v, fontWeight: w } = f, N = u.split(Yt.lineBreakRegex); for (let O = 0; O < N.length; O++) {
    let P = O * _ - _ * (N.length - 1) / 2, M = i.append("text").attr("x", n + r / 2).attr("y", l).style("text-anchor", "middle").attr("dominant-baseline", "middle").style("font-size", _).style("font-weight", w).style("font-family", v);
    M.append("tspan").attr("dy", P).text(N[O]).attr("alignment-baseline", "mathematical"), a(M, y);
} } d(e, "byTspan"); function s(u, i, n, l, r, h, y, f) { let _ = i.append("switch"), w = _.append("foreignObject").attr("x", n).attr("y", l).attr("width", r).attr("height", h).append("xhtml:div").style("display", "table").style("height", "100%").style("width", "100%"); w.append("div").style("display", "table-cell").style("text-align", "center").style("vertical-align", "middle").text(u), e(u, _, n, l, r, h, y, f), a(w, y); } d(s, "byFo"); function a(u, i) { for (let n in i)
    i.hasOwnProperty(n) && u.attr(n, i[n]); } return d(a, "_setTextAttrs"), function (u) { return u.textPlacement === "fo" ? s : u.textPlacement === "old" ? t : e; }; })(), z = { drawRect: Ae, drawBoundary: x0, drawRels: g0, insertArrowHead: S0, insertArrowEnd: T0, insertArrowFilledHead: C0, insertArrowCrossHead: R0, insertDatabaseIcon: v0, insertComputerIcon: k0, insertClockIcon: E0 }, w0 = d((t, e) => { if (e === "sandbox") {
    let a = Ft("#i" + t).node()?.contentDocument;
    if (!a)
        throw new Error(`Sandbox iframe #i${t} is missing its content document`);
    return { root: Ft(a.body), doc: a };
} return { root: Ft("body"), doc: document }; }, "getDiagramRoot"), O0 = new Set(["system_queue", "external_system_queue", "container_queue", "external_container_queue", "component_queue", "external_component_queue"]), P0 = new Set(["system_db", "external_system_db", "container_db", "external_container_db", "component_db", "external_component_db"]), D0 = { person: "person", box: "rounded", rounded: "rounded", cylinder: "cylinder", database: "cylinder", db: "cylinder", queue: "h-cyl", pipe: "h-cyl", component: "fr-rect" }, ne = d(t => t ? D0[t.toLowerCase()] : void 0, "keywordShape"), N0 = d(t => { let e = ne(t.shape) ?? ne(t.sprite); if (e)
    return e; if (t.tags)
    for (let a of t.tags.split(",")) {
        let u = ne(a.trim());
        if (u)
            return u;
    } let s = t.typeC4Shape.text; return s === "person" || s === "external_person" ? "person" : P0.has(s) ? "cylinder" : O0.has(s) ? "h-cyl" : "rounded"; }, "resolveNodeShape"), A0 = { person: "Person", system: "Software System", container: "Container", component: "Component" }, L0 = d(t => { let e = t.replace(/^external_/, "").replace(/_(db|queue)$/, ""); return A0[e] ?? e.replace(/_/g, " "); }, "stereotypeLabel"), I0 = d(t => t.startsWith("external_"), "isExternal"), M0 = d(t => { let e = L0(t.typeC4Shape.text); return t.techn?.text ? `[${e}: ${t.techn.text}]` : `[${e}]`; }, "stereotypeText"), Le = ["person", "system", "system_db", "system_queue", "container", "container_db", "container_queue", "component", "component_db", "component_queue"].flatMap(t => [t, `external_${t}`]), B0 = new Set(Le), Se = d(t => B0.has(t), "isC4ElementType"), V0 = d((t, e) => { let s = t.typeC4Shape.text, a = t.bgColor ?? (Se(s) && e[`${s}_bg_color`]), u = t.borderColor ?? (Se(s) && e[`${s}_border_color`]), i = []; return a && i.push(`fill:${a}`), u && i.push(`stroke:${u}`), i.push(`color:${t.fontColor ?? "#FFFFFF"}`), i; }, "elementCssStyles"), Te = d((t, e, s, a, u) => { let i = t.typeC4Shape.text, n = ["c4-shape", `c4-${i}`]; I0(i) && n.push("c4-external"); let l = N0(t), r = V0(t, e); return (l === "rounded" || l === "fr-rect") && r.push("rx:12px", "ry:12px"), { id: t.alias, label: t.label.text, stereotype: M0(t), description: t.descr?.text ? [t.descr.text] : void 0, labelType: "string", isGroup: !1, shape: l, cssClasses: n.join(" "), cssStyles: r, padding: s, look: a, useHtmlLabels: !1, width: u }; }, "buildC4Node"), Nt = 0, At = 0, Ie = 4, se = 2;
jt.yy = re;
var g = {}, Me = class {
    static { d(this, "Bounds"); }
    constructor(t) { this.name = "", this.data = {}, this.data.startx = void 0, this.data.stopx = void 0, this.data.starty = void 0, this.data.stopy = void 0, this.data.widthLimit = void 0, this.nextData = {}, this.nextData.startx = void 0, this.nextData.stopx = void 0, this.nextData.starty = void 0, this.nextData.stopy = void 0, this.nextData.cnt = 0, ae(t.db.getConfig()); }
    setData(t, e, s, a) { this.nextData.startx = this.data.startx = t, this.nextData.stopx = this.data.stopx = e, this.nextData.starty = this.data.starty = s, this.nextData.stopy = this.data.stopy = a; }
    updateVal(t, e, s, a) { t[e] === void 0 ? t[e] = s : t[e] = a(s, t[e]); }
    insert(t) { this.nextData.cnt = this.nextData.cnt + 1; let e = this.nextData.stopx, s = this.data.widthLimit, a = this.nextData.startx === this.nextData.stopx ? e + t.margin : e + t.margin * 2, u = a + t.width, i = this.nextData.starty + t.margin * 2, n = i + t.height; (a >= s || u >= s || this.nextData.cnt > Ie) && (a = this.nextData.startx + t.margin + g.nextLinePaddingX, i = this.nextData.stopy + t.margin * 2, this.nextData.stopx = u = a + t.width, this.nextData.starty = this.nextData.stopy, this.nextData.stopy = n = i + t.height, this.nextData.cnt = 1), t.x = a, t.y = i, this.updateVal(this.data, "startx", a, Math.min), this.updateVal(this.data, "starty", i, Math.min), this.updateVal(this.data, "stopx", u, Math.max), this.updateVal(this.data, "stopy", n, Math.max), this.updateVal(this.nextData, "startx", a, Math.min), this.updateVal(this.nextData, "starty", i, Math.min), this.updateVal(this.nextData, "stopx", u, Math.max), this.updateVal(this.nextData, "stopy", n, Math.max); }
    init(t) { this.name = "", this.data = { startx: void 0, stopx: void 0, starty: void 0, stopy: void 0, widthLimit: void 0 }, this.nextData = { startx: void 0, stopx: void 0, starty: void 0, stopy: void 0, cnt: 0 }, ae(t.db.getConfig()); }
    bumpLastMargin(t) { this.data.stopx += t, this.data.stopy += t; }
}, ae = d(function (t) { ye(g, t), t?.fontFamily && (g.personFontFamily = g.systemFontFamily = g.messageFontFamily = t.fontFamily), t?.fontSize && (g.personFontSize = g.systemFontSize = g.messageFontSize = t.fontSize), t?.fontWeight && (g.personFontWeight = g.systemFontWeight = g.messageFontWeight = t.fontWeight); }, "setConf"), Ut = d(t => ({ fontFamily: t.boundaryFontFamily, fontSize: t.boundaryFontSize, fontWeight: t.boundaryFontWeight }), "boundaryFont"), Y0 = d(t => ({ fontFamily: t.messageFontFamily, fontSize: t.messageFontSize, fontWeight: t.messageFontWeight }), "messageFont");
function _t(t, e, s, a, u) { let i = e[t]; if (!i.width)
    if (s)
        i.text = ve(i.text, u, a), i.textLines = i.text.split(Yt.lineBreakRegex).length, i.width = u, i.height = ee(i.text, a);
    else {
        let n = i.text.split(Yt.lineBreakRegex);
        i.textLines = n.length;
        let l = 0;
        i.height = 0, i.width = 0;
        for (let r of n)
            i.width = Math.max(wt(r, a), i.width), l = ee(r, a), i.height = i.height + l;
    } return i; }
d(_t, "calcC4ShapeTextWH");
var Be = d(function (t, e, s) { let a = s.data.startx, u = s.data.starty; e.x = a, e.y = u, e.width = s.data.stopx - a, e.height = s.data.stopy - u, e.label.y = g.c4ShapeMargin - 35; let i = e.wrap && g.wrap, n = Ut(g); n.fontSize = n.fontSize + 2, n.fontWeight = "bold"; let l = wt(e.label.text, n); _t("label", e, i, n, l), z.drawBoundary(t, e, g); }, "drawBoundary"), Ve = d(function (t, e, s, a) { return Rt(this, null, function* () { let u = Et(), i = u.look ?? "classic", n = { config: u }, l = e.attr("id") ?? "", r = a.map(y => s[Number(y)]), h = d(y => { let f = y.shape ? ke[y.shape] : void 0; if (!f)
    throw new Error(`C4: no shape handler for "${y.shape}"`); return f; }, "shapeHandlerFor"); yield Promise.all(r.map(y => Rt(null, null, function* () { let f = Te(y, g, g.c4ShapePadding, i, g.width); f.domId = `${l}-${f.id}`; let _ = yield h(f)(e, f, n); y.width = f.width ?? g.width, y.height = f.height ?? g.height, y.margin = g.c4ShapeMargin, _.remove(); }))); for (let y of r)
    t.insert(y); yield Promise.all(r.map(y => Rt(null, null, function* () { let f = Te(y, g, g.c4ShapePadding, i, g.width); f.domId = `${l}-${f.id}`, f.x = y.x + y.width / 2, f.y = y.y + y.height / 2; let _ = e.append("g").attr("transform", `translate(${y.x + y.width / 2}, ${y.y + y.height / 2})`); yield h(f)(_, f, n), y.intersect = f.intersect; }))), t.bumpLastMargin(g.c4ShapeMargin); }); }, "drawC4ShapeArray"), F0 = class {
    static { d(this, "Point"); }
    constructor(t, e) { this.x = t, this.y = e; }
}, Ce = d(function (t, e) { if (!t.intersect)
    throw new Error(`C4 shape "${t.alias}" has no intersect function. Please report this to https://github.com/mermaid-js/mermaid/issues`); let { x: s, y: a } = t.intersect(e); return new F0(s, a); }, "getIntersectPoint"), U0 = d(function (t, e) { let s = { x: 0, y: 0 }; s.x = e.x + e.width / 2, s.y = e.y + e.height / 2; let a = Ce(t, s); s.x = t.x + t.width / 2, s.y = t.y + t.height / 2; let u = Ce(e, s); return { startPoint: a, endPoint: u }; }, "getIntersectPoints"), j0 = d(function (t, e, s, a, u) { let i = a.db.getC4Type(), n = 0; for (let l of e) {
    n = n + 1;
    let r = l.wrap && g.wrap, h = Y0(g);
    i === "C4Dynamic" && (l.label.text = n + ": " + l.label.text);
    let y = wt(l.label.text, h);
    _t("label", l, r, h, y), l.techn && l.techn.text !== "" && (y = wt(l.techn.text, h), _t("techn", l, r, h, y)), l.descr && l.descr.text !== "" && (y = wt(l.descr.text, h), _t("descr", l, r, h, y));
    let f = s(l.from), _ = s(l.to);
    if (!f || !_)
        throw new Error(`C4 rel "${l.from}" -> "${l.to}" references an unknown shape`);
    let v = U0(f, _);
    if (!v.startPoint || !v.endPoint)
        throw new Error(`Could not calculate intersection points for rel "${l.from}" -> "${l.to}"`);
    l.startPoint = v.startPoint, l.endPoint = v.endPoint;
} z.drawRels(t, e, g, u); }, "drawRels");
function le(t, e, s, a, u) { return Rt(this, null, function* () { let i = u.db, n = new Me(u); n.data.widthLimit = s.data.widthLimit / Math.min(se, a.length); for (let [l, r] of a.entries()) {
    let h = 0;
    r.image = { width: 0, height: 0, Y: 0 }, r.sprite && (r.image.width = 48, r.image.height = 48, r.image.Y = h, h = r.image.Y + r.image.height);
    let y = r.wrap && g.wrap, f = Ut(g);
    f.fontSize = f.fontSize + 2, f.fontWeight = "bold";
    let _ = _t("label", r, y, f, n.data.widthLimit);
    if (_.Y = h + 8, h = _.Y + _.height, r.type && r.type.text !== "") {
        r.type.text = "[" + r.type.text + "]";
        let O = Ut(g), P = _t("type", r, y, O, n.data.widthLimit);
        P.Y = h + 5, h = P.Y + P.height;
    }
    if (r.descr && r.descr.text !== "") {
        let O = Ut(g);
        O.fontSize = O.fontSize - 2;
        let P = _t("descr", r, y, O, n.data.widthLimit);
        P.Y = h + 20, h = P.Y + P.height;
    }
    if (l == 0 || l % se === 0) {
        let O = s.data.startx + g.diagramMarginX, P = s.data.stopy + g.diagramMarginY + h;
        n.setData(O, O, P, P);
    }
    else {
        let O = n.data.stopx !== n.data.startx ? n.data.stopx + g.diagramMarginX : n.data.startx, P = n.data.starty;
        n.setData(O, O, P, P);
    }
    n.name = r.alias;
    let v = i.getC4ShapeArray(r.alias), w = i.getC4ShapeKeys(r.alias);
    w.length > 0 && (yield Ve(n, t, v, w)), e = r.alias;
    let N = i.getBoundaries(e);
    N.length > 0 && (yield le(t, e, n, N, u)), r.alias !== "global" && Be(t, r, n), s.data.stopy = Math.max(n.data.stopy + g.c4ShapeMargin, s.data.stopy), s.data.stopx = Math.max(n.data.stopx + g.c4ShapeMargin, s.data.stopx), Nt = Math.max(Nt, s.data.stopx), At = Math.max(At, s.data.stopy);
} }); }
d(le, "drawInsideBoundary");
var z0 = d(function (t, e, s, a) { return Rt(this, null, function* () { g = we("c4"); let u = Et().securityLevel, { root: i } = w0(e, u), n = a.db; n.setWrap(g.wrap), Ie = n.getC4ShapeInRow(), se = n.getC4BoundaryInRow(), $t.debug(`C:${JSON.stringify(g, null, 2)}`); let l = i.select(`[id="${e}"]`); z.insertComputerIcon(l, e), z.insertDatabaseIcon(l, e), z.insertClockIcon(l, e); let r = new Me(a); r.setData(g.diagramMarginX, g.diagramMarginX, g.diagramMarginY, g.diagramMarginY), r.data.widthLimit = screen.availWidth, Nt = g.diagramMarginX, At = g.diagramMarginY; let h = n.getTitle(), y = n.getBoundaries(""); yield le(l, "", r, y, a), z.insertArrowHead(l, e), z.insertArrowEnd(l, e), z.insertArrowCrossHead(l, e), z.insertArrowFilledHead(l, e), j0(l, n.getRels(), n.getC4Shape, a, e), r.data.stopx = Nt, r.data.stopy = At; let f = r.data, _ = f.startx, v = f.starty, N = At - v + 2 * g.diagramMarginY, O = Nt - _, P = O + 2 * g.diagramMarginX; h && l.append("text").text(h).attr("x", O / 2 - 4 * g.diagramMarginX).attr("y", v + g.diagramMarginY), be(l, N, P, g.useMaxWidth); let M = h ? 60 : 0; l.attr("viewBox", _ - g.diagramMarginX + " -" + (g.diagramMarginY + M) + " " + P + " " + (N + M)), $t.debug("models:", f); }); }, "draw"), Re = { drawPersonOrSystemArray: Ve, drawBoundary: Be, setConf: ae, draw: z0 }, W0 = d(() => {
    let t = Et().c4 ?? {}, e = new CSSStyleSheet;
    for (let s of Le) {
        let a = e.cssRules[e.insertRule(`.c4-shape.c4-${s} .label {}`, e.cssRules.length)], u = t[`${s}FontFamily`], i = t[`${s}FontSize`], n = t[`${s}FontWeight`];
        u && a.style.setProperty("font-family", u), i && a.style.setProperty("font-size", typeof i == "number" ? `${i}px` : i), n && a.style.setProperty("font-weight", String(n));
    }
    return [...e.cssRules].filter(s => s.style.length > 0).map(s => `  ${s.cssText}`).join(`
`);
}, "elementFontStyles"), X0 = d(t => `.person {
    stroke: ${t.personBorder};
    fill: ${t.personBkg};
  }
${W0()}

  /* The element font colour is set inline per element (default white); the
     label text takes it via currentColor. */
  .c4-shape .label,
  .c4-shape .label text {
    color: inherit;
    fill: currentColor;
  }
  /* Structurizr typography: bold name, smaller stereotype/type and description lines. */
  .c4-shape .label .c4-name {
    font-weight: bold;
  }
  .c4-shape .label .c4-type {
    font-size: 0.75em;
  }
  .c4-shape .label .c4-descr {
    font-size: 0.82em;
  }
  .c4-shape .basic,
  .c4-shape rect,
  .c4-shape path,
  .c4-shape circle,
  .c4-shape ellipse,
  .c4-shape line {
    stroke-width: 2px;
  }
`, "getStyles"), q0 = X0, s1 = { parser: We, db: re, renderer: Re, styles: q0, init: d(({ c4: t, wrap: e }) => { Re.setConf(t), re.setWrap(e); }, "init") };
export { s1 as diagram };
