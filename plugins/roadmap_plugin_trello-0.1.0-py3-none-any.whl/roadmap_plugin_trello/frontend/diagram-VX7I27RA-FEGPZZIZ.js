import { a as ge } from "@nf-internal/chunk-CDENLQJG";
import { a as Se } from "@nf-internal/chunk-ZLCFE4AJ";
import "@nf-internal/chunk-VZQGJMQ7";
import "@nf-internal/chunk-JAYRGFT2";
import "@nf-internal/chunk-IOH7GM72";
import "@nf-internal/chunk-GUSNYLY2";
import "@nf-internal/chunk-GCCWOIHF";
import "@nf-internal/chunk-OPZQWBKG";
import "@nf-internal/chunk-HWQKKMJK";
import "@nf-internal/chunk-CZ6NO76D";
import "@nf-internal/chunk-3T7BLYHO";
import "@nf-internal/chunk-ECYPFJR7";
import "@nf-internal/chunk-HS5YSWJK";
import "@nf-internal/chunk-EQ4SU2R5";
import { a as ye } from "@nf-internal/chunk-WVCFK4LD";
import "@nf-internal/chunk-JJBBOCN6";
import "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-ZQAEIOWN";
import "@nf-internal/chunk-EPGORQP5";
import { a as fe } from "@nf-internal/chunk-YQ6X4GJP";
import { c as ue, d as $ } from "@nf-internal/chunk-GP7LUXUQ";
import { o as I } from "@nf-internal/chunk-FDRUJGNH";
import "@nf-internal/chunk-2MBYSHM6";
import { O as se, T as re, U as ne, V as oe, W as ie, X as ce, Y as pe, Z as de, i as ae, k as le, u as R } from "@nf-internal/chunk-LEJRRF65";
import { b as H, h as V, j as N, k as he, l as me, m as B } from "@nf-internal/chunk-RZWXGGKD";
import { a as h } from "@nf-internal/chunk-YUSHYV7C";
import { a as Y, f as te } from "@nf-internal/chunk-OSQMNGTH";
var xe = class {
    constructor() { this.nodes = [], this.levels = new Map, this.outerNodes = [], this.classes = new Map, this.setAccTitle = ne, this.getAccTitle = oe, this.setDiagramTitle = pe, this.getDiagramTitle = de, this.getAccDescription = ce, this.setAccDescription = ie; }
    static { h(this, "TreeMapDB"); }
    getNodes() { return this.nodes; }
    getConfig() { let r = le, s = R(); return I(Y(Y({}, r.treemap), s.treemap ?? {})); }
    addNode(r, s) { this.nodes.push(r), this.levels.set(r, s), s === 0 && (this.outerNodes.push(r), this.root ??= r); }
    getRoot() { return { name: "", children: this.outerNodes }; }
    addClass(r, s) { let i = this.classes.get(r) ?? { id: r, styles: [], textStyles: [] }, c = s.replace(/\\,/g, "\xA7\xA7\xA7").replace(/,/g, ";").replace(/§§§/g, ",").split(";"); c && c.forEach(l => { ue(l) && (i?.textStyles ? i.textStyles.push(l) : i.textStyles = [l]), i?.styles ? i.styles.push(l) : i.styles = [l]; }), this.classes.set(r, i); }
    getClasses() { return this.classes; }
    getStylesForClass(r) { return this.classes.get(r)?.styles ?? []; }
    clear() { re(), this.nodes = [], this.levels = new Map, this.outerNodes = [], this.classes = new Map, this.root = void 0; }
};
function be(r) { if (!r.length)
    return []; let s = [], i = []; return r.forEach(c => { let l = { name: c.name, children: c.type === "Leaf" ? void 0 : [] }; for (l.classSelector = c?.classSelector, c?.cssCompiledStyles && (l.cssCompiledStyles = c.cssCompiledStyles), c.type === "Leaf" && c.value !== void 0 && (l.value = c.value); i.length > 0 && i[i.length - 1].level >= c.level;)
    i.pop(); if (i.length === 0)
    s.push(l);
else {
    let n = i[i.length - 1].node;
    n.children ? n.children.push(l) : n.children = [l];
} c.type !== "Leaf" && i.push({ node: l, level: c.level }); }), s; }
h(be, "buildHierarchy");
var ze = h((r, s) => { ge(r, s); let i = []; for (let n of r.TreemapRows ?? [])
    n.$type === "ClassDefStatement" && s.addClass(n.className ?? "", n.styleText ?? ""); for (let n of r.TreemapRows ?? []) {
    let d = n.item;
    if (!d)
        continue;
    let m = n.indent ? parseInt(n.indent) : 0, k = Ae(d), a = d.classSelector ? s.getStylesForClass(d.classSelector) : [], A = a.length > 0 ? a : void 0, b = { level: m, name: k, type: d.$type, value: d.value, classSelector: d.classSelector, cssCompiledStyles: A };
    i.push(b);
} let c = be(i), l = h((n, d) => { for (let m of n)
    s.addNode(m, d), m.children && m.children.length > 0 && l(m.children, d + 1); }, "addNodesRecursively"); l(c, 0); }, "populate"), Ae = h(r => r.name ? String(r.name) : "", "getItemName"), ve = { parser: { yy: void 0 }, parse: h(r => te(null, null, function* () { try {
        let i = yield Se("treemap", r);
        H.debug("Treemap AST:", i);
        let c = ve.parser?.yy;
        if (!(c instanceof xe))
            throw new Error("parser.parser?.yy was not a TreemapDB. This is due to a bug within Mermaid, please report this issue at https://github.com/mermaid-js/mermaid/issues.");
        ze(i, c);
    }
    catch (s) {
        throw H.error("Error parsing treemap:", s), s;
    } }), "parse") }, Pe = 10, z = 10, M = 25, De = h((r, s, i, c) => { let l = c.db, n = l.getConfig(), d = n.padding ?? Pe, m = l.getDiagramTitle(), k = l.getRoot(), { themeVariables: a } = R(); if (!k)
    return; let A = m ? 30 : 0, b = fe(s), j = n.nodeWidth ? n.nodeWidth * z : 960, U = n.nodeHeight ? n.nodeHeight * z : 500, O = j, q = U + A; b.attr("viewBox", `0 0 ${O} ${q}`), se(b, q, O, n.useMaxWidth); let v; try {
    let e = n.valueFormat || ",";
    if (e === "$0,0")
        v = h(t => "$" + N(",")(t), "valueFormat");
    else if (e.startsWith("$") && e.includes(",")) {
        let t = /\.\d+/.exec(e), o = t ? t[0] : "";
        v = h(f => "$" + N("," + o)(f), "valueFormat");
    }
    else if (e.startsWith("$")) {
        let t = e.substring(1);
        v = h(o => "$" + N(t || "")(o), "valueFormat");
    }
    else
        v = N(e);
}
catch (e) {
    H.error("Error creating format function:", e), v = N(",");
} let P = B().range(["transparent", a.cScale0, a.cScale1, a.cScale2, a.cScale3, a.cScale4, a.cScale5, a.cScale6, a.cScale7, a.cScale8, a.cScale9, a.cScale10, a.cScale11]), Ce = B().range(["transparent", a.cScalePeer0, a.cScalePeer1, a.cScalePeer2, a.cScalePeer3, a.cScalePeer4, a.cScalePeer5, a.cScalePeer6, a.cScalePeer7, a.cScalePeer8, a.cScalePeer9, a.cScalePeer10, a.cScalePeer11]), W = B().range([a.cScaleLabel0, a.cScaleLabel1, a.cScaleLabel2, a.cScaleLabel3, a.cScaleLabel4, a.cScaleLabel5, a.cScaleLabel6, a.cScaleLabel7, a.cScaleLabel8, a.cScaleLabel9, a.cScaleLabel10, a.cScaleLabel11]); m && b.append("text").attr("x", O / 2).attr("y", A / 2).attr("class", "treemapTitle").attr("text-anchor", "middle").attr("dominant-baseline", "middle").text(m); let J = b.append("g").attr("transform", `translate(0, ${A})`).attr("class", "treemapContainer"), we = he(k).sum(e => e.value ?? 0).sort((e, t) => (t.value ?? 0) - (e.value ?? 0)), K = me().size([j, U]).paddingTop(e => e.children && e.children.length > 0 ? M + z : 0).paddingInner(d).paddingLeft(e => e.children && e.children.length > 0 ? z : 0).paddingRight(e => e.children && e.children.length > 0 ? z : 0).paddingBottom(e => e.children && e.children.length > 0 ? z : 0).round(!0)(we), Te = K.descendants().filter(e => e.children && e.children.length > 0), D = J.selectAll(".treemapSection").data(Te).enter().append("g").attr("class", "treemapSection").attr("transform", e => `translate(${e.x0},${e.y0})`); D.append("rect").attr("width", e => e.x1 - e.x0).attr("height", M).attr("class", "treemapSectionHeader").attr("fill", "none").attr("fill-opacity", .6).attr("stroke-width", .6).attr("style", e => e.depth === 0 ? "display: none;" : ""), D.append("clipPath").attr("id", (e, t) => `clip-section-${s}-${t}`).append("rect").attr("width", e => Math.max(0, e.x1 - e.x0 - 12)).attr("height", M), D.append("rect").attr("width", e => e.x1 - e.x0).attr("height", e => e.y1 - e.y0).attr("class", (e, t) => `treemapSection section${t}`).attr("fill", e => P(e.data.name)).attr("fill-opacity", .6).attr("stroke", e => Ce(e.data.name)).attr("stroke-width", 2).attr("stroke-opacity", .4).attr("style", e => { if (e.depth === 0)
    return "display: none;"; let t = $({ cssCompiledStyles: e.data.cssCompiledStyles }); return t.nodeStyles + ";" + t.borderStyles.join(";"); }), D.append("text").attr("class", "treemapSectionLabel").attr("x", 6).attr("y", M / 2).attr("dominant-baseline", "middle").text(e => e.depth === 0 ? "" : e.data.name).attr("font-weight", "bold").attr("clip-path", (e, t) => `url(#clip-section-${s}-${t})`).attr("style", e => { if (e.depth === 0)
    return "display: none;"; let t = "dominant-baseline: middle; font-size: 12px; fill:" + W(e.data.name) + "; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;", o = $({ cssCompiledStyles: e.data.cssCompiledStyles }); return t + o.labelStyles.replace("color:", "fill:"); }).each(function (e) { if (e.depth === 0)
    return; let t = V(this), o = e.data.name; t.text(o); let f = e.x1 - e.x0, y = 6, u; n.showValues !== !1 && e.value ? u = f - 10 - 30 - 10 - y : u = f - y - 6; let p = Math.max(15, u), w = t.node(); if (w.getComputedTextLength() > p) {
    let T = o;
    for (; T.length > 0;) {
        if (T = o.substring(0, T.length - 1), T.length === 0) {
            t.text("..."), w.getComputedTextLength() > p && t.text("");
            break;
        }
        if (t.text(T + "..."), w.getComputedTextLength() <= p)
            break;
    }
} }), n.showValues !== !1 && D.append("text").attr("class", "treemapSectionValue").attr("x", e => e.x1 - e.x0 - 10).attr("y", M / 2).attr("text-anchor", "end").attr("dominant-baseline", "middle").text(e => e.value ? v(e.value) : "").attr("font-style", "italic").attr("style", e => { if (e.depth === 0)
    return "display: none;"; let t = "text-anchor: end; dominant-baseline: middle; font-size: 10px; fill:" + W(e.data.name) + "; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;", o = $({ cssCompiledStyles: e.data.cssCompiledStyles }); return t + o.labelStyles.replace("color:", "fill:"); }); let Q = K.leaves(), S = Q.length > 20, $e = S ? 16 : 38, E = S ? 14 : 28, L = S ? 4 : 8, F = S ? 4 : 6, G = S ? 2 : 4, Z = S ? 8 : 10, X = S ? 1 : 2, _ = J.selectAll(".treemapLeafGroup").data(Q).enter().append("g").attr("class", (e, t) => `treemapNode treemapLeafGroup leaf${t}${e.data.classSelector ? ` ${e.data.classSelector}` : ""}x`).attr("transform", e => `translate(${e.x0},${e.y0})`); _.append("rect").attr("width", e => e.x1 - e.x0).attr("height", e => e.y1 - e.y0).attr("class", "treemapLeaf").attr("fill", e => e.parent ? P(e.parent.data.name) : P(e.data.name)).attr("style", e => $({ cssCompiledStyles: e.data.cssCompiledStyles }).nodeStyles).attr("fill-opacity", .3).attr("stroke", e => e.parent ? P(e.parent.data.name) : P(e.data.name)).attr("stroke-width", 3), _.append("clipPath").attr("id", (e, t) => `clip-${s}-${t}`).append("rect").attr("width", e => Math.max(0, e.x1 - e.x0 - 4)).attr("height", e => Math.max(0, e.y1 - e.y0 - 4)), _.append("text").attr("class", "treemapLabel").attr("x", e => (e.x1 - e.x0) / 2).attr("y", e => (e.y1 - e.y0) / 2).attr("style", e => { let t = `text-anchor: middle; dominant-baseline: middle; font-size: ${$e}px;fill:` + W(e.data.name) + ";", o = $({ cssCompiledStyles: e.data.cssCompiledStyles }); return t + o.labelStyles.replace("color:", "fill:"); }).attr("clip-path", (e, t) => `url(#clip-${s}-${t})`).text(e => e.data.name).each(function (e) { let t = V(this), o = e.x1 - e.x0, f = e.y1 - e.y0, y = t.node(), u = o - 2 * G, C = f - 2 * G; if (u < Z || C < Z) {
    t.style("display", "none");
    return;
} let p = parseInt(t.style("font-size"), 10), w = .6; for (; y.getComputedTextLength() > u && p > L;)
    p--, t.style("font-size", `${p}px`); let g = Math.max(F, Math.min(E, Math.round(p * w))), x = p + X + g; for (; x > C && p > L && (p--, g = Math.max(F, Math.min(E, Math.round(p * w))), !(g < F && p === L));)
    t.style("font-size", `${p}px`), x = p + X + g, g <= F && x > C; t.style("font-size", `${p}px`), S ? (p < L || C < L) && t.style("display", "none") : (y.getComputedTextLength() > u || p < L || C < p) && t.style("display", "none"); }), n.showValues !== !1 && _.append("text").attr("class", "treemapValue").attr("x", t => (t.x1 - t.x0) / 2).attr("y", function (t) { return (t.y1 - t.y0) / 2; }).attr("style", t => { let o = `text-anchor: middle; dominant-baseline: hanging; font-size: ${E}px;fill:` + W(t.data.name) + ";", f = $({ cssCompiledStyles: t.data.cssCompiledStyles }); return o + f.labelStyles.replace("color:", "fill:"); }).attr("clip-path", (t, o) => `url(#clip-${s}-${o})`).text(t => t.value ? v(t.value) : "").each(function (t) { let o = V(this), f = this.parentNode; if (!f) {
    o.style("display", "none");
    return;
} let y = V(f).select(".treemapLabel"); if (y.empty() || y.style("display") === "none") {
    o.style("display", "none");
    return;
} let u = parseFloat(y.style("font-size")), p = Math.max(F, Math.min(E, Math.round(u * .6))); o.style("font-size", `${p}px`); let g = (t.y1 - t.y0) / 2 + u / 2 + X; o.attr("y", g); let x = t.x1 - t.x0, ee = t.y1 - t.y0 - 4, Ne = x - 2 * G; o.node().getComputedTextLength() > Ne || g + p > ee || p < F ? o.style("display", "none") : o.style("display", null); }); let Le = n.diagramPadding ?? 8; ye(b, Le, "flowchart", n?.useMaxWidth || !1); }, "draw"), Ve = h(function (r, s) { return s.db.getClasses(); }, "getClasses"), Me = { draw: De, getClasses: Ve }, ke = { sectionStrokeColor: "black", sectionStrokeWidth: "1", sectionFillColor: "#efefef", leafStrokeColor: "black", leafStrokeWidth: "1", leafFillColor: "#efefef", labelFontSize: "12px", valueFontSize: "10px", titleFontSize: "14px" }, We = h(({ treemap: r } = {}) => {
    let s = ae(), i = R(), c = I(s, i.themeVariables), l = I(ke, r), n = l.titleColor ?? c.titleColor, d = l.labelColor ?? c.textColor, m = l.valueColor ?? c.textColor;
    return `
  .treemapNode.section {
    stroke: ${l.sectionStrokeColor};
    stroke-width: ${l.sectionStrokeWidth};
    fill: ${l.sectionFillColor};
  }
  .treemapNode.leaf {
    stroke: ${l.leafStrokeColor};
    stroke-width: ${l.leafStrokeWidth};
    fill: ${l.leafFillColor};
  }
  .treemapLabel {
    fill: ${d};
    font-size: ${l.labelFontSize};
  }
  .treemapValue {
    fill: ${m};
    font-size: ${l.valueFontSize};
  }
  .treemapTitle {
    fill: ${n};
    font-size: ${l.titleFontSize};
  }
  `;
}, "getStyles"), Ee = We, Je = { parser: ve, get db() { return new xe; }, renderer: Me, styles: Ee };
export { Je as diagram };
