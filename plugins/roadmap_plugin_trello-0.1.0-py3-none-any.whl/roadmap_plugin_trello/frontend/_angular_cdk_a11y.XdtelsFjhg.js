import { a as z, b as M } from "@nf-internal/chunk-FNZSD5JT";
import "@nf-internal/chunk-DKL52G2Q";
import { a as P, b, c as E, d as w, e as B, f as U, g as K, h as $, i as Y, j as G, k as V, l as H } from "@nf-internal/chunk-K3H3OZMK";
import "@nf-internal/chunk-PUBAQWKR";
import { a as y } from "@nf-internal/chunk-SNW5QGG3";
import "@nf-internal/chunk-QLZSQRL7";
import { a as q } from "@nf-internal/chunk-LYW4QERV";
import { a as X } from "@nf-internal/chunk-TTLGK2TK";
import { a as S, b as N, c as F, d as k, e as L, f as x, g as j } from "@nf-internal/chunk-44S5HDKK";
import "@nf-internal/chunk-PACPXHXL";
import { a as D, b as O } from "@nf-internal/chunk-TT7XXVKE";
import { a as p } from "@nf-internal/chunk-ZVGPI6ZI";
import "@nf-internal/chunk-ZGWTKG5Z";
import { a as Z } from "@nf-internal/chunk-RNULGOC3";
import "@nf-internal/chunk-Z4DWJRNS";
import "@nf-internal/chunk-SVIUGILY";
import "@nf-internal/chunk-LAIZNMCN";
import { a as h } from "@nf-internal/chunk-7RHXFCZM";
import { a as J } from "@nf-internal/chunk-RMOXI6XO";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-OSQMNGTH";
import * as _ from "@angular/core";
import { inject as o, DOCUMENT as I, APP_ID as Q, InjectionToken as W, NgZone as ee, Injector as te } from "@angular/core";
import { Subject as se } from "rxjs";
import "rxjs/operators";
import "@angular/platform-browser";
import "@angular/common";
var T = " ";
function re(r, i, t) { let e = d(r, i); t = t.trim(), !e.some(s => s.trim() === t) && (e.push(t), r.setAttribute(i, e.join(T))); }
function ie(r, i, t) { let e = d(r, i); t = t.trim(); let s = e.filter(n => n !== t); s.length ? r.setAttribute(i, s.join(T)) : r.removeAttribute(i); }
function d(r, i) { return r.getAttribute(i)?.match(/\S+/g) ?? []; }
var ye = "cdk-describedby-message-container", R = "cdk-describedby-message", c = "cdk-describedby-host", g = 0, be = (() => { class r {
    _platform = o(h);
    _document = o(I);
    _messageRegistry = new Map;
    _messagesContainer = null;
    _id = `${g++}`;
    constructor() { o(p).load(y), this._id = o(Q) + "-" + g++; }
    describe(t, e, s) { if (!this._canBeDescribed(t, e))
        return; let n = l(e, s); typeof e != "string" ? (v(e, this._id), this._messageRegistry.set(n, { messageElement: e, referenceCount: 0 })) : this._messageRegistry.has(n) || this._createMessageElement(e, s), this._isElementDescribedByMessage(t, n) || this._addMessageReference(t, n); }
    removeDescription(t, e, s) { if (!e || !this._isElementNode(t))
        return; let n = l(e, s); if (this._isElementDescribedByMessage(t, n) && this._removeMessageReference(t, n), typeof e == "string") {
        let a = this._messageRegistry.get(n);
        a && a.referenceCount === 0 && this._deleteMessageElement(n);
    } this._messagesContainer?.childNodes.length === 0 && (this._messagesContainer.remove(), this._messagesContainer = null); }
    ngOnDestroy() { let t = this._document.querySelectorAll(`[${c}="${this._id}"]`); for (let e = 0; e < t.length; e++)
        this._removeCdkDescribedByReferenceIds(t[e]), t[e].removeAttribute(c); this._messagesContainer?.remove(), this._messagesContainer = null, this._messageRegistry.clear(); }
    _createMessageElement(t, e) { let s = this._document.createElement("div"); v(s, this._id), s.textContent = t, e && s.setAttribute("role", e), this._createMessagesContainer(), this._messagesContainer.appendChild(s), this._messageRegistry.set(l(t, e), { messageElement: s, referenceCount: 0 }); }
    _deleteMessageElement(t) { this._messageRegistry.get(t)?.messageElement?.remove(), this._messageRegistry.delete(t); }
    _createMessagesContainer() { if (this._messagesContainer)
        return; let t = "cdk-describedby-message-container", e = this._document.querySelectorAll(`.${t}[platform="server"]`); for (let n = 0; n < e.length; n++)
        e[n].remove(); let s = this._document.createElement("div"); s.style.visibility = "hidden", s.classList.add(t), s.classList.add("cdk-visually-hidden"), this._platform.isBrowser || s.setAttribute("platform", "server"), this._document.body.appendChild(s), this._messagesContainer = s; }
    _removeCdkDescribedByReferenceIds(t) { let e = d(t, "aria-describedby").filter(s => s.indexOf(R) != 0); t.setAttribute("aria-describedby", e.join(" ")); }
    _addMessageReference(t, e) { let s = this._messageRegistry.get(e); re(t, "aria-describedby", s.messageElement.id), t.setAttribute(c, this._id), s.referenceCount++; }
    _removeMessageReference(t, e) { let s = this._messageRegistry.get(e); s.referenceCount--, ie(t, "aria-describedby", s.messageElement.id), t.removeAttribute(c); }
    _isElementDescribedByMessage(t, e) { let s = d(t, "aria-describedby"), n = this._messageRegistry.get(e), a = n && n.messageElement.id; return !!a && s.indexOf(a) != -1; }
    _canBeDescribed(t, e) { if (!this._isElementNode(t))
        return !1; if (e && typeof e == "object")
        return !0; let s = e == null ? "" : `${e}`.trim(), n = t.getAttribute("aria-label"); return s ? !n || n.trim() !== s : !1; }
    _isElementNode(t) { return t.nodeType === this._document.ELEMENT_NODE; }
    static \u0275fac = function (e) { return new (e || r); };
    static \u0275prov = _.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
function l(r, i) { return typeof r == "string" ? `${i || ""}/${r}` : r; }
function v(r, i) { r.id || (r.id = `${R}-${i}-${g++}`); }
var u = class {
    _isNoopTreeKeyManager = !0;
    change = new se;
    destroy() { this.change.complete(); }
    onKeydown() { }
    getActiveItemIndex() { return null; }
    getActiveItem() { return null; }
    focusItem() { }
}, Ee = { provide: M, useFactory: () => () => new u }, f = class extends E {
    _focusTrapManager;
    _inertStrategy;
    get enabled() { return this._enabled; }
    set enabled(i) { this._enabled = i, this._enabled ? this._focusTrapManager.register(this) : this._focusTrapManager.deregister(this); }
    constructor(i, t, e, s, n, a, A, C) { super(i, t, e, s, A.defer, C), this._focusTrapManager = n, this._inertStrategy = a, this._focusTrapManager.register(this); }
    destroy() { this._focusTrapManager.deregister(this), super.destroy(); }
    _enable() { this._inertStrategy.preventFocus(this), this.toggleAnchors(!0); }
    _disable() { this._inertStrategy.allowFocus(this), this.toggleAnchors(!1); }
}, m = class {
    _listener = null;
    preventFocus(i) { this._listener && i._document.removeEventListener("focus", this._listener, !0), this._listener = t => this._trapFocus(i, t), i._ngZone.runOutsideAngular(() => { i._document.addEventListener("focus", this._listener, !0); }); }
    allowFocus(i) { this._listener && (i._document.removeEventListener("focus", this._listener, !0), this._listener = null); }
    _trapFocus(i, t) { let e = t.target, s = i._element; e && !s.contains(e) && !e.closest?.("div.cdk-overlay-pane") && setTimeout(() => { i.enabled && !s.contains(i._document.activeElement) && i.focusFirstTabbableElement(); }); }
}, ne = new W("FOCUS_TRAP_INERT_STRATEGY"), oe = (() => { class r {
    _focusTrapStack = [];
    register(t) { this._focusTrapStack = this._focusTrapStack.filter(s => s !== t); let e = this._focusTrapStack; e.length && e[e.length - 1]._disable(), e.push(t), t._enable(); }
    deregister(t) { t._disable(); let e = this._focusTrapStack, s = e.indexOf(t); s !== -1 && (e.splice(s, 1), e.length && e[e.length - 1]._enable()); }
    static \u0275fac = function (e) { return new (e || r); };
    static \u0275prov = _.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })(), Me = (() => { class r {
    _checker = o(b);
    _ngZone = o(ee);
    _focusTrapManager = o(oe);
    _document = o(I);
    _inertStrategy;
    _injector = o(te);
    constructor() { let t = o(ne, { optional: !0 }); this._inertStrategy = t || new m; }
    create(t, e = { defer: !1 }) { let s; return typeof e == "boolean" ? s = { defer: e } : s = e, new f(t, this._checker, this._ngZone, this._document, this._focusTrapManager, this._inertStrategy, s, this._injector); }
    static \u0275fac = function (e) { return new (e || r); };
    static \u0275prov = _.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
export { H as A11yModule, q as ActiveDescendantKeyManager, be as AriaDescriber, c as CDK_DESCRIBEDBY_HOST_ATTRIBUTE, R as CDK_DESCRIBEDBY_ID_PREFIX, Y as CdkAriaLive, j as CdkMonitorFocus, B as CdkTrapFocus, f as ConfigurableFocusTrap, Me as ConfigurableFocusTrapFactory, m as EventListenerFocusTrapInertStrategy, L as FOCUS_MONITOR_DEFAULT_OPTIONS, ne as FOCUS_TRAP_INERT_STRATEGY, X as FocusKeyManager, x as FocusMonitor, k as FocusMonitorDetectionMode, E as FocusTrap, w as FocusTrapFactory, G as HighContrastMode, V as HighContrastModeDetector, N as INPUT_MODALITY_DETECTOR_DEFAULT_OPTIONS, S as INPUT_MODALITY_DETECTOR_OPTIONS, F as InputModalityDetector, b as InteractivityChecker, P as IsFocusableConfig, K as LIVE_ANNOUNCER_DEFAULT_OPTIONS, U as LIVE_ANNOUNCER_ELEMENT_TOKEN, Z as ListKeyManager, $ as LiveAnnouncer, ye as MESSAGES_CONTAINER_ID, Ee as NOOP_TREE_KEY_MANAGER_FACTORY_PROVIDER, u as NoopTreeKeyManager, M as TREE_KEY_MANAGER, z as TreeKeyManager, J as _IdGenerator, re as addAriaReferencedId, d as getAriaReferenceIds, D as isFakeMousedownFromScreenReader, O as isFakeTouchstartFromScreenReader, ie as removeAriaReferencedId };
