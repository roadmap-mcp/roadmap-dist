import { a as r } from "@nf-internal/chunk-H2DRVGCT";
import { e as o } from "@nf-internal/chunk-OSQMNGTH";
var t = o(r(), 1);
var e = t.default;
var export_HighlightJS = t.default;
export { export_HighlightJS as HighlightJS, e as default };
