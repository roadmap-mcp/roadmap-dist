import { A as M, B as W, C as B, D as G, E as K, F as U, G as Y, a as f, b as C, c as _, d as y, e as E, f as O, g, h, i as F, j as v, k as b, l as N, m as k, n as D, o as P, p as V, q as R, r as l, s as A, t as w, u as x, v as I, w as L, x as T, y as j, z } from "@nf-internal/chunk-DTCUIADE";
import "@nf-internal/chunk-RECHUXGF";
import "@nf-internal/chunk-EAER6ZQJ";
import { d as i, f as a, g as c, i as s, m as u, n as d, o as m, p as S, q as p } from "@nf-internal/chunk-UYYL2GTR";
import "@nf-internal/chunk-FVDLKYOC";
import "@nf-internal/chunk-SMAQMSIK";
import "@nf-internal/chunk-AWGKBVI5";
import "@nf-internal/chunk-ZVGPI6ZI";
import "@nf-internal/chunk-ZGWTKG5Z";
import "@nf-internal/chunk-SVIUGILY";
import "@nf-internal/chunk-LAIZNMCN";
import "@nf-internal/chunk-7RHXFCZM";
import "@nf-internal/chunk-RMOXI6XO";
import { a as o } from "@nf-internal/chunk-5HDY5C2T";
import "@nf-internal/chunk-6QY5OUOO";
import "@nf-internal/chunk-JE6VEUSL";
import "@nf-internal/chunk-MQ6KVUBG";
import "@nf-internal/chunk-XID2BBVI";
import "@nf-internal/chunk-OSQMNGTH";
import * as n from "@angular/core";
import { inject as H, RendererFactory2 as J } from "@angular/core";
import "@angular/common";
import "rxjs";
import "rxjs/operators";
var te = (() => { class t extends l {
    _renderer = H(J).createRenderer(null, null);
    _fullScreenEventName;
    _cleanupFullScreenListener;
    constructor() { super(); }
    ngOnDestroy() { super.ngOnDestroy(), this._cleanupFullScreenListener?.(); }
    _createContainer() { let e = this._getEventName(); super._createContainer(), this._adjustParentForFullscreenChange(), e && (this._cleanupFullScreenListener?.(), this._cleanupFullScreenListener = this._renderer.listen("document", e, () => { this._adjustParentForFullscreenChange(); })); }
    _adjustParentForFullscreenChange() { this._containerElement && (this.getFullscreenElement() || this._document.body).appendChild(this._containerElement); }
    _getEventName() { if (!this._fullScreenEventName) {
        let e = this._document;
        e.fullscreenEnabled ? this._fullScreenEventName = "fullscreenchange" : e.webkitFullscreenEnabled ? this._fullScreenEventName = "webkitfullscreenchange" : e.mozFullScreenEnabled ? this._fullScreenEventName = "mozfullscreenchange" : e.msFullscreenEnabled && (this._fullScreenEventName = "MSFullscreenChange");
    } return this._fullScreenEventName; }
    getFullscreenElement() { let e = this._document; return e.fullscreenElement || e.webkitFullscreenElement || e.mozFullScreenElement || e.msFullscreenElement || null; }
    static \u0275fac = function (r) { return new (r || t); };
    static \u0275prov = n.\u0275\u0275defineInjectable({ token: t, factory: t.\u0275fac, providedIn: "root" });
} return t; })();
export { C as BlockScrollStrategy, K as CDK_CONNECTED_OVERLAY_DEFAULT_CONFIG, U as CdkConnectedOverlay, G as CdkOverlayOrigin, c as CdkScrollable, y as CloseScrollStrategy, k as ConnectedOverlayPositionChange, b as ConnectionPositionPair, x as FlexibleConnectedPositionStrategy, te as FullscreenOverlayContainer, j as GlobalPositionStrategy, O as NoopScrollStrategy, M as OVERLAY_DEFAULT_CONFIG, B as Overlay, v as OverlayConfig, l as OverlayContainer, V as OverlayKeyboardDispatcher, Y as OverlayModule, R as OverlayOutsideClickDispatcher, z as OverlayPositionBuilder, A as OverlayRef, h as RepositionScrollStrategy, L as STANDARD_DROPDOWN_ADJACENT_POSITIONS, I as STANDARD_DROPDOWN_BELOW_POSITIONS, a as ScrollDispatcher, F as ScrollStrategyOptions, N as ScrollingVisibility, s as ViewportRuler, f as createBlockScrollStrategy, _ as createCloseScrollStrategy, w as createFlexibleConnectedPositionStrategy, T as createGlobalPositionStrategy, E as createNoopScrollStrategy, W as createOverlayRef, g as createRepositionScrollStrategy, P as validateHorizontalPosition, D as validateVerticalPosition, i as \u0275\u0275CdkFixedSizeVirtualScroll, p as \u0275\u0275CdkScrollableModule, d as \u0275\u0275CdkVirtualForOf, u as \u0275\u0275CdkVirtualScrollViewport, m as \u0275\u0275CdkVirtualScrollableElement, S as \u0275\u0275CdkVirtualScrollableWindow, o as \u0275\u0275Dir };
