import { a as e, b as r } from "@nf-internal/chunk-SNPNI3X2";
import "@nf-internal/chunk-EPGORQP5";
import "@nf-internal/chunk-OSQMNGTH";
export { e as PacketModule, r as createPacketServices };
