import { c as q, d as K } from "@nf-internal/chunk-ZBOYDPPL";
import { r as E } from "@nf-internal/chunk-FDRUJGNH";
import { H as $, K as L, M as C, N as D, u as H } from "@nf-internal/chunk-LEJRRF65";
import { b as S, h as b } from "@nf-internal/chunk-RZWXGGKD";
import { a as h } from "@nf-internal/chunk-YUSHYV7C";
import { a as I, d as _, e as z, f as y } from "@nf-internal/chunk-OSQMNGTH";
var V = _((R, M) => { (function (t) {
    "use strict";
    var e = function () { }, n = t.requestAnimationFrame || t.webkitRequestAnimationFrame || t.mozRequestAnimationFrame || t.msRequestAnimationFrame || function (s) { return setTimeout(s, 16); };
    function i() { var s = this; s.reads = [], s.writes = [], s.raf = n.bind(t), e("initialized", s); }
    i.prototype = { constructor: i, runTasks: function (s) { e("run tasks"); for (var a; a = s.shift();)
            a(); }, measure: function (s, a) { e("measure"); var o = a ? s.bind(a) : s; return this.reads.push(o), r(this), o; }, mutate: function (s, a) { e("mutate"); var o = a ? s.bind(a) : s; return this.writes.push(o), r(this), o; }, clear: function (s) { return e("clear", s), u(this.reads, s) || u(this.writes, s); }, extend: function (s) { if (e("extend", s), typeof s != "object")
            throw new Error("expected object"); var a = Object.create(this); return c(a, s), a.fastdom = this, a.initialize && a.initialize(), a; }, catch: null };
    function r(s) { s.scheduled || (s.scheduled = !0, s.raf(l.bind(null, s)), e("flush scheduled")); }
    function l(s) { e("flush"); var a = s.writes, o = s.reads, f; try {
        e("flushing reads", o.length), s.runTasks(o), e("flushing writes", a.length), s.runTasks(a);
    }
    catch (d) {
        f = d;
    } if (s.scheduled = !1, (o.length || a.length) && r(s), f)
        if (e("task errored", f.message), s.catch)
            s.catch(f);
        else
            throw f; }
    function u(s, a) { var o = s.indexOf(a); return !!~o && !!s.splice(o, 1); }
    function c(s, a) { for (var o in a)
        a.hasOwnProperty(o) && (s[o] = a[o]); }
    var p = t.fastdom = t.fastdom || new i;
    typeof define == "function" ? define(function () { return p; }) : typeof M == "object" && (M.exports = p);
})(typeof window < "u" ? window : typeof R < "u" ? R : globalThis); });
var G = _((yt, F) => { (function () { var t = { initialize: function () { this._tasks = new Map; }, mutate: function (n, i) { return e(this, "mutate", n, i); }, measure: function (n, i) { return e(this, "measure", n, i); }, clear: function (n) { var i = this._tasks, r = i.get(n); this.fastdom.clear(r), i.delete(n); } }; function e(n, i, r, l) { var u = n._tasks, c = n.fastdom, p, s = new Promise(function (a, o) { p = c[i](function () { u.delete(s); try {
    a(l ? r.call(l) : r());
}
catch (f) {
    o(f);
} }, l); }); return u.set(s, p), s; } (typeof define)[0] == "f" ? define(function () { return t; }) : (typeof F)[0] == "o" ? F.exports = t : window.fastdomPromised = t; })(); });
function N(t) {
    for (var e = [], n = 1; n < arguments.length; n++)
        e[n - 1] = arguments[n];
    var i = Array.from(typeof t == "string" ? [t] : t);
    i[i.length - 1] = i[i.length - 1].replace(/\r?\n([\t ]*)$/, "");
    var r = i.reduce(function (c, p) { var s = p.match(/\n([\t ]+|(?!\s).)/g); return s ? c.concat(s.map(function (a) { var o, f; return (f = (o = a.match(/[\t ]/g)) === null || o === void 0 ? void 0 : o.length) !== null && f !== void 0 ? f : 0; })) : c; }, []);
    if (r.length) {
        var l = new RegExp(`
[	 ]{`.concat(Math.min.apply(Math, r), "}"), "g");
        i = i.map(function (c) {
            return c.replace(l, `
`);
        });
    }
    i[0] = i[0].replace(/^\r?\n/, "");
    var u = i[0];
    return e.forEach(function (c, p) {
        var s = u.match(/(?:^|\n)( *)$/), a = s ? s[1] : "", o = c;
        typeof c == "string" && c.includes(`
`) && (o = String(c).split(`
`).map(function (f, d) { return d === 0 ? f : "".concat(a).concat(f); }).join(`
`)), u += o + i[p + 1];
    }), u;
}
var X = z(V(), 1), Y = z(G(), 1);
import { marked as Z } from "marked";
var j = typeof performance < "u" && typeof performance.now == "function", x = h(() => j ? performance.now() : 0, "now"), W = "\u{1F9DC} ", ut = "Mermaid render", pt = "Mermaid", ft = { parse: "tertiary", prepare: "secondary", measure: "primary", layout: "primary-dark", layoutCore: "error", draw: "primary-light", paint: "secondary-dark", serialize: "tertiary-dark", render: "primary-light" }, wt = class {
    constructor() { this.enabled = !1, this.autoPrint = !0, this.records = [], this.maxRecords = 200, this.roots = [], this.stack = [], this.buckets = {}; }
    static { h(this, "Profiler"); }
    enable() { return this.enabled = !0, this; }
    disable() { return this.enabled = !1, this; }
    start(t) { this.enabled && (this.roots = [], this.stack = [], this.buckets = {}, this.begin(t)); }
    tickSync(t, e) { if (!this.enabled)
        return e(); let n = x(); try {
        return e();
    }
    finally {
        this.buckets[t] = (this.buckets[t] ?? 0) + (x() - n);
    } }
    tick(t, e) { return y(this, null, function* () { if (!this.enabled)
        return e(); let n = x(); try {
        return yield e();
    }
    finally {
        this.buckets[t] = (this.buckets[t] ?? 0) + (x() - n);
    } }); }
    stop() { if (!this.enabled)
        return; for (; this.stack.length > 0;)
        this.end(); let t = this.roots.at(-1), e = this.runLabel ?? t?.name; return t && (this.records.push({ label: e ?? t.name, tree: t, buckets: I({}, this.buckets) }), this.records.length > this.maxRecords && this.records.splice(0, this.records.length - this.maxRecords), this.autoPrint && this.printSummary(t, e)), this.runLabel = void 0, t; }
    begin(t) { if (!this.enabled)
        return; let e = { name: t, start: x(), duration: -1, children: [] }, n = this.stack.at(-1); if (n ? n.children.push(e) : this.roots.push(e), this.stack.push(e), j && typeof performance.mark == "function")
        try {
            performance.mark(`${W}${t} \u25B6`);
        }
        catch { } }
    end() { if (!this.enabled)
        return; let t = this.stack.pop(); if (!t)
        return; let e = x(); if (t.duration = e - t.start, j && typeof performance.measure == "function")
        try {
            performance.measure(`${W}${t.name}`, { start: t.start, end: e, detail: { devtools: { dataType: "track-entry", track: ut, trackGroup: pt, color: ft[t.name] ?? "primary", tooltipText: `${t.name} \u2014 ${t.duration.toFixed(1)} ms` } } });
        }
        catch { } }
    span(t, e) { return y(this, null, function* () { if (!this.enabled)
        return e(); this.begin(t); try {
        return yield e();
    }
    finally {
        this.end();
    } }); }
    report() { return this.records.at(-1)?.tree ?? this.roots.at(-1); }
    clear() { this.records.length = 0, this.roots = [], this.stack = [], this.runLabel = void 0; }
    reset() { this.roots = [], this.stack = []; }
    printSummary(t = this.report(), e) {
        if (!t)
            return;
        let n = t.duration, i = e && e !== t.name ? `${t.name} [${e}]` : t.name, r = ["ms        %    phase"], l = h((c, p) => { let s = "  ".repeat(p), a = c.duration.toFixed(1).padStart(8), o = n > 0 ? `${(c.duration / n * 100).toFixed(0).padStart(3)}%` : "   -"; r.push(`${a}  ${o}  ${s}${c.name}`); for (let f of c.children)
            l(f, p + 1); if (c.children.length > 0) {
            let f = c.children.reduce((m, g) => m + g.duration, 0), d = c.duration - f;
            if (d > .5) {
                let m = d.toFixed(1).padStart(8);
                r.push(`${m}       ${s}  (self)`);
            }
        } }, "walk");
        l(t, 0);
        let u = Object.keys(this.buckets);
        if (u.length > 0) {
            r.push("\u2014\u2014 buckets (summed) \u2014\u2014");
            for (let c of u)
                r.push(`${this.buckets[c].toFixed(1).padStart(8)}       ${c}`);
        }
        console.log(`${W}mermaid render profile \xB7 ${i}
${r.join(`
`)}`);
    }
};
globalThis.injected ??= { includeLargeFeatures: !0, profiling: !1, version: "0.0.0" };
var ht = X.default.extend({ raf(t) { typeof queueMicrotask == "function" ? queueMicrotask(t) : setTimeout(t, 0); } }).extend(Y.default), dt = ht;
function J(t, { markdownAutoWrap: e }) {
    let i = t.replace(/<br\/>/g, `
`).replace(/\n{2,}/g, `
`);
    return N(i);
}
h(J, "preprocessMarkdown");
function Q(t) { return t.split(/\\n|\n|<br\s*\/?>/gi).map(e => e.trim().match(/<[^>]+>|[^\s<>]+/g)?.map(n => ({ content: n, type: "normal" })) ?? []); }
h(Q, "nonMarkdownToLines");
function tt(t, e = {}) {
    let n = J(t, e), i = Z.lexer(n), r = [[]], l = 0;
    function u(c, p = "normal") {
        c.type === "text" ? c.text.split(`
`).forEach((a, o) => { o !== 0 && (l++, r.push([])), a.split(" ").forEach(f => { f = f.replace(/&#39;/g, "'"), f && r[l].push({ content: f, type: p }); }); }) : c.type === "strong" || c.type === "em" ? c.tokens.forEach(s => { u(s, c.type); }) : c.type === "html" && r[l].push({ content: c.text, type: "normal" });
    }
    return h(u, "processNode"), i.forEach(c => { c.type === "paragraph" ? c.tokens?.forEach(p => { u(p); }) : c.type === "html" ? r[l].push({ content: c.text, type: "normal" }) : r[l].push({ content: c.raw, type: "normal" }); }), r;
}
h(tt, "markdownToLines");
function et(t) { return t ? `<p>${t.replace(/\\n|\n/g, "<br />")}</p>` : ""; }
h(et, "nonMarkdownToHTML");
function nt(t, { markdownAutoWrap: e } = {}) { let n = Z.lexer(t); function i(r) { return r.type === "text" ? e === !1 ? r.text.replace(/\n */g, "<br/>").replace(/ /g, "&nbsp;") : r.text.replace(/\n */g, "<br/>") : r.type === "strong" ? `<strong>${r.tokens?.map(i).join("")}</strong>` : r.type === "em" ? `<em>${r.tokens?.map(i).join("")}</em>` : r.type === "paragraph" ? `<p>${r.tokens?.map(i).join("")}</p>` : r.type === "space" ? "" : r.type === "html" ? `${r.text}` : r.type === "escape" ? r.text : (S.warn(`Unsupported markdown: ${r.type}`), r.raw); } return h(i, "output"), n.map(i).join(""); }
h(nt, "markdownToHTML");
function rt(t) { return Intl.Segmenter ? [...new Intl.Segmenter().segment(t)].map(e => e.segment) : [...t]; }
h(rt, "splitTextToChars");
function it(t, e) { let n = rt(e.content); return A(t, [], n, e.type); }
h(it, "splitWordToFitWidth");
function A(t, e, n, i) { if (n.length === 0)
    return [{ content: e.join(""), type: i }, { content: "", type: i }]; let [r, ...l] = n, u = [...e, r]; return t([{ content: u.join(""), type: i }]) ? A(t, u, l, i) : (e.length === 0 && r && (e.push(r), n.shift()), [{ content: e.join(""), type: i }, { content: n.join(""), type: i }]); }
h(A, "splitWordToFitWidthRecursion");
function st(t, e) {
    if (t.some(({ content: n }) => n.includes(`
`)))
        throw new Error("splitLineToFitWidth does not support newlines in the line");
    return T(t, e);
}
h(st, "splitLineToFitWidth");
function T(t, e, n = [], i = []) { if (t.length === 0)
    return i.length > 0 && n.push(i), n.length > 0 ? n : []; let r = ""; t[0].content === " " && (r = " ", t.shift()); let l = t.shift() ?? { content: " ", type: "normal" }, u = [...i]; if (r !== "" && u.push({ content: r, type: "normal" }), u.push(l), e(u))
    return T(t, e, n, u); if (i.length > 0)
    n.push(i), t.unshift(l);
else if (l.content) {
    let [c, p] = it(e, l);
    n.push([c]), p.content && t.unshift(p);
} return T(t, e, n); }
h(T, "splitLineToFitWidthRecursion");
function O(t, e) { e && t.attr("style", e); }
h(O, "applyStyle");
var U = 16384;
function at(u, c, p, s) {
    return y(this, arguments, function* (t, e, n, i, r = !1, l = H()) {
        let a = t.append("foreignObject");
        a.attr("width", `${Math.min(10 * n, U)}px`), a.attr("height", `${Math.min(10 * n, U)}px`);
        let o = a.append("xhtml:div"), f = L(e.label) ? yield C(e.label.replace(D.lineBreakRegex, `
`), l) : $(e.label, l), d = e.isNode ? "nodeLabel" : "edgeLabel", m = o.append("span");
        return m.html(f), O(m, e.labelStyle), m.attr("class", `${d} ${i}`), O(o, e.labelStyle), o.style("display", "table-cell"), o.style("white-space", "nowrap"), o.style("line-height", "1.5"), n !== Number.POSITIVE_INFINITY && (o.style("max-width", n + "px"), o.style("text-align", "center")), o.attr("xmlns", "http://www.w3.org/1999/xhtml"), r && o.attr("class", "labelBkg"), (yield dt.measure(() => o.node().getBoundingClientRect())).width === n && (o.style("display", "table"), o.style("white-space", "break-spaces"), o.style("width", n + "px")), a.node();
    });
}
h(at, "addHtmlSpan");
function v(t, e, n, i = !1) { let r = t.append("tspan").attr("class", "text-outer-tspan").attr("x", 0).attr("y", e * n - .1 + "em").attr("dy", n + "em"); return i && r.attr("text-anchor", "middle"), r; }
h(v, "createTspan");
function ot(t, e, n) { let i = t.append("text"), r = v(i, 1, e); w(r, n); let l = r.node().getComputedTextLength(); return i.remove(), l; }
h(ot, "computeWidthOfText");
function mt(t, e, n) { let i = t.append("text"), r = v(i, 1, e); w(r, [{ content: n, type: "normal" }]); let l = r.node()?.getBoundingClientRect(); return l && i.remove(), l; }
h(mt, "computeDimensionOfText");
function ct(t, e, n, i = !1, r = !1) { let u = e.append("g"), c = u.insert("rect").attr("class", "background").attr("style", "stroke: none"), p = u.append("text").attr("y", "-10.1"); r && p.attr("text-anchor", "middle"); let s = 0; for (let a of n) {
    let o = h(d => ot(u, 1.1, d) <= t, "checkWidth"), f = o(a) ? [a] : st(a, o);
    for (let d of f) {
        let m = v(p, s, 1.1, r);
        w(m, d), s++;
    }
} if (i) {
    let a = p.node().getBBox(), o = 2;
    return c.attr("x", a.x - o).attr("y", a.y - o).attr("width", a.width + 2 * o).attr("height", a.height + 2 * o), u.node();
}
else
    return p.node(); }
h(ct, "createFormattedText");
function P(t) { let e = /&(amp|lt|gt);/g; return t.replace(e, (n, i) => { switch (i) {
    case "amp": return "&";
    case "lt": return "<";
    case "gt": return ">";
    default: return n;
} }); }
h(P, "decodeHTMLEntities");
function w(t, e) { t.text(""), e.forEach((n, i) => { let r = t.append("tspan").attr("font-style", n.type === "em" ? "italic" : "normal").attr("class", "text-inner-tspan").attr("font-weight", n.type === "strong" ? "bold" : "normal"); i === 0 ? r.text(P(n.content)) : r.text(" " + P(n.content)); }); }
h(w, "updateTextContentAndStyles");
function lt(n) { return y(this, arguments, function* (t, e = {}) { let i = []; t.replace(/(fa[bklrs]?):fa-([\w-]+)/g, (l, u, c) => (i.push(y(null, null, function* () { let p = `${u}:${c}`; return (yield q(p)) ? yield K(p, void 0, { class: "label-icon" }) : `<i class='${$(l, e).replace(":", " ")}'></i>`; })), l)); let r = yield Promise.all(i); return t.replace(/(fa[bklrs]?):fa-([\w-]+)/g, () => r.shift() ?? ""); }); }
h(lt, "replaceIconSubstring");
var Et = h((o, ...f) => y(null, [o, ...f], function* (t, e = "", { style: n = "", isTitle: i = !1, classes: r = "", useHtmlLabels: l = !0, markdown: u = !0, isNode: c = !0, width: p = 200, addSvgBackground: s = !1 } = {}, a) { if (S.debug("XYZ createText", e, n, i, r, l, c, "addSvgBackground: ", s), l) {
    let d = u ? nt(e, a) : et(e), m = yield lt(E(d), a), g = e.replace(/\\\\/g, "\\"), k = { isNode: c, label: L(e) ? g : m, labelStyle: n.replace("fill:", "color:") };
    return yield at(t, k, p, r, s, a);
}
else {
    let d = E(e.replace(/<br\s*\/?>/g, "<br/>")), m = u ? tt(d.replace("<br>", "<br/>"), a) : Q(d), g = ct(p, t, m, e ? s : !1, !c);
    if (c) {
        /stroke:/.exec(n) && (n = n.replace("stroke:", "lineColor:"));
        let k = n.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
        b(g).attr("style", k);
    }
    else {
        let k = n.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/background:/g, "fill:");
        b(g).select("rect").attr("style", k.replace(/background:/g, "fill:"));
        let B = n.replace(/stroke:[^;]+;?/g, "").replace(/stroke-width:[^;]+;?/g, "").replace(/fill:[^;]+;?/g, "").replace(/color:/g, "fill:");
        b(g).select("text").attr("style", B);
    }
    return i ? b(g).selectAll("tspan.text-outer-tspan").classed("title-row", !0) : b(g).selectAll("tspan.text-outer-tspan").classed("row", !0), g;
} }), "createText");
export { N as a, dt as b, mt as c, Et as d };
