#!/usr/bin/env node
import { j as c } from "@nf-internal/chunk-IGLPM555";
import { f as u } from "@nf-internal/chunk-OSQMNGTH";
import { promises as q } from "node:fs";
import { dirname as v, resolve as h } from "node:path";
import { homedir as G } from "node:os";
import { createRequire as L } from "node:module";
import { pathToFileURL as z } from "node:url";
var { access: A, readFile: F, writeFile: D } = q, N = L(import.meta.url);
function T(o) {
    return u(this, null, function* () {
        function j() { return u(this, null, function* () { let { spawn: e } = yield import("child_process"), { fileURLToPath: s } = yield import("url"), i = { cwd: o.cwd(), env: o.env, stdio: "inherit" }, n = v(s(import.meta.url)), r = yield F(h(n, "../man/marked.1.md"), "utf8"); yield new Promise(p => { let a = e("man", [h(n, "../man/marked.1")], i); o.on("SIGINT", () => { a.kill("SIGINT"); }), a.on("error", () => { console.log(r); }).on("close", p); }); }); }
        function C() { return u(this, null, function* () { let e = N("../package.json"); console.log(e.version); }); }
        function I(e) {
            return u(this, null, function* () {
                let s = [], i = {}, n, r, p, a, k, d, m, b;
                function _() { let t = e.shift(); return t.indexOf("--") === 0 ? (t = t.split("="), t.length > 1 && e.unshift(t.slice(1).join("=")), t = t[0]) : t[0] === "-" && t.length > 2 && (e = t.substring(1).split("").map(function (l) { return "-" + l; }).concat(e), t = e.shift()), t; }
                for (; e.length;)
                    switch (a = _(), a) {
                        case "-o":
                        case "--output":
                            r = e.shift();
                            break;
                        case "-i":
                        case "--input":
                            n = e.shift();
                            break;
                        case "-s":
                        case "--string":
                            p = e.shift();
                            break;
                        case "-t":
                        case "--tokens":
                            k = !0;
                            break;
                        case "-c":
                        case "--config":
                            d = e.shift();
                            break;
                        case "-n":
                        case "--no-clobber":
                            b = !0;
                            break;
                        case "-h":
                        case "--help": return yield j();
                        case "-v":
                        case "--version": return yield C();
                        default:
                            if (a.indexOf("--") === 0) {
                                if (m = S(a.replace(/^--(no-)?/, "")), !(m in c.defaults))
                                    continue;
                                a.indexOf("--no-") === 0 ? i[m] = typeof c.defaults[m] != "boolean" ? null : !1 : i[m] = typeof c.defaults[m] != "boolean" ? e.shift() : !0;
                            }
                            else
                                s.push(a);
                            break;
                    }
                function U() { return u(this, null, function* () { if (p)
                    return p; if (!n) {
                    if (s.length === 0)
                        return yield O();
                    n = s.pop();
                } return yield F(n, "utf8"); }); }
                function g(t) { return h(t.replace(/^~/, G)); }
                function w(t) { return A(g(t)).then(() => !0, () => !1); }
                function y(t) { return u(this, null, function* () { let l = g(t), f; try {
                    f = N(l);
                }
                catch (R) {
                    if (R.code !== "ERR_REQUIRE_ESM")
                        throw R;
                    f = yield import(z(l).href);
                } f.default && (f = f.default), typeof f == "function" ? f(c) : c.use(f); }); }
                let x = yield U();
                if (d) {
                    if (!(yield w(d)))
                        throw Error(`Cannot load config file '${d}'`);
                    yield y(d);
                }
                else {
                    let t = ["~/.marked.json", "~/.marked.js", "~/.marked/index.js"];
                    for (let l of t)
                        if (yield w(l)) {
                            yield y(l);
                            break;
                        }
                }
                let E = k ? JSON.stringify(c.lexer(x, i), null, 2) : yield c.parse(x, i);
                if (r) {
                    if (b && (yield w(r)))
                        throw Error("marked: output file '" + r + `' already exists, disable the '-n' / '--no-clobber' flag to overwrite
`);
                    return yield D(r, E);
                }
                o.stdout.write(E + `
`);
            });
        }
        function O() { return new Promise((e, s) => { let i = o.stdin, n = ""; i.setEncoding("utf8"), i.on("data", function (r) { n += r; }), i.on("error", function (r) { s(r); }), i.on("end", function () { e(n); }), i.resume(); }); }
        function S(e) { return e.replace(/(\w)-(\w)/g, function (s, i, n) { return i + n.toUpperCase(); }); }
        try {
            yield I(o.argv.slice()), o.exit(0);
        }
        catch (e) {
            return e.code === "ENOENT" ? o.stderr.write("marked: " + e.path + ": No such file or directory") : o.stderr.write(e.message), o.exit(1);
        }
    });
}
process.title = "marked";
T(process);
