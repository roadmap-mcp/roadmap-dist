import { a as ie, b as wr, f as z } from "@nf-internal/chunk-OSQMNGTH";
var kw = Object.create, Is = Object.defineProperty, Ow = Object.getOwnPropertyDescriptor, hp = Object.getOwnPropertyNames, Lw = Object.getPrototypeOf, Dw = Object.prototype.hasOwnProperty, s = (e, t) => Is(e, "name", { value: t, configurable: !0 }), xw = (e, t) => function () { return e && (t = (0, e[hp(e)[0]])(e = 0)), t; }, Y = (e, t) => function () { return t || (0, e[hp(e)[0]])((t = { exports: {} }).exports, t), t.exports; }, zr = (e, t) => { for (var r in t)
    Is(e, r, { get: t[r], enumerable: !0 }); }, jo = (e, t, r, n) => { if (t && typeof t == "object" || typeof t == "function")
    for (let a of hp(t))
        !Dw.call(e, a) && a !== r && Is(e, a, { get: () => t[a], enumerable: !(n = Ow(t, a)) || n.enumerable }); return e; }, Nl = (e, t, r) => (jo(e, t, "default"), r && jo(r, t, "default")), yp = (e, t, r) => (r = e != null ? kw(Lw(e)) : {}, jo(t || !e || !e.__esModule ? Is(r, "default", { value: e, enumerable: !0 }) : r, e)), gp = e => jo(Is({}, "__esModule", { value: !0 }), e), Pl = {};
zr(Pl, { AnnotatedTextEdit: () => sr, ChangeAnnotation: () => Zr, ChangeAnnotationIdentifier: () => qe, CodeAction: () => Yc, CodeActionContext: () => Hc, CodeActionKind: () => Vc, CodeActionTriggerKind: () => Bi, CodeDescription: () => Cc, CodeLens: () => Xc, Color: () => vo, ColorInformation: () => Tc, ColorPresentation: () => $c, Command: () => Jr, CompletionItem: () => Dc, CompletionItemKind: () => Ic, CompletionItemLabelDetails: () => Lc, CompletionItemTag: () => Pc, CompletionList: () => xc, CreateFile: () => ua, DeleteFile: () => fa, Diagnostic: () => Fi, DiagnosticRelatedInformation: () => To, DiagnosticSeverity: () => Ec, DiagnosticTag: () => bc, DocumentHighlight: () => jc, DocumentHighlightKind: () => zc, DocumentLink: () => Zc, DocumentSymbol: () => Wc, DocumentUri: () => yc, EOL: () => _g, FoldingRange: () => Ac, FoldingRangeKind: () => Rc, FormattingOptions: () => Jc, Hover: () => Mc, InlayHint: () => lf, InlayHintKind: () => Ao, InlayHintLabelPart: () => Eo, InlineCompletionContext: () => mf, InlineCompletionItem: () => cf, InlineCompletionList: () => ff, InlineCompletionTriggerKind: () => pf, InlineValueContext: () => of, InlineValueEvaluatableExpression: () => sf, InlineValueText: () => nf, InlineValueVariableLookup: () => af, InsertReplaceEdit: () => kc, InsertTextFormat: () => Nc, InsertTextMode: () => Oc, Location: () => Gi, LocationLink: () => vc, MarkedString: () => Ui, MarkupContent: () => pa, MarkupKind: () => Ro, OptionalVersionedTextDocumentIdentifier: () => ji, ParameterInformation: () => Gc, Position: () => ae, Range: () => Z, RenameFile: () => ca, SelectedCompletionInfo: () => df, SelectionRange: () => Qc, SemanticTokenModifiers: () => tf, SemanticTokenTypes: () => ef, SemanticTokens: () => rf, SignatureInformation: () => Fc, StringValue: () => uf, SymbolInformation: () => Kc, SymbolKind: () => Uc, SymbolTag: () => Bc, TextDocument: () => yf, TextDocumentEdit: () => zi, TextDocumentIdentifier: () => _c, TextDocumentItem: () => wc, TextEdit: () => Bt, URI: () => go, VersionedTextDocumentIdentifier: () => Sc, WorkspaceChange: () => Cg, WorkspaceEdit: () => $o, WorkspaceFolder: () => hf, WorkspaceSymbol: () => qc, integer: () => gc, uinteger: () => Mi });
var yc, go, gc, Mi, ae, Z, Gi, vc, vo, Tc, $c, Rc, Ac, To, Ec, bc, Cc, Fi, Jr, Bt, Zr, qe, sr, zi, ua, ca, fa, $o, Ci, zu, Cg, _c, Sc, ji, wc, Ro, pa, Ic, Nc, Pc, kc, Oc, Lc, Dc, xc, Ui, Mc, Gc, Fc, zc, jc, Uc, Bc, Kc, qc, Wc, Vc, Bi, Hc, Yc, Xc, Jc, Zc, Qc, ef, tf, rf, nf, af, sf, of, Ao, Eo, lf, uf, cf, ff, pf, df, mf, hf, _g, yf, th, R, Ns = xw({ "../../node_modules/.pnpm/vscode-languageserver-types@3.17.5/node_modules/vscode-languageserver-types/lib/esm/main.js"() {
        "use strict";
        (function (e) { function t(r) { return typeof r == "string"; } s(t, "is"), e.is = t; })(yc || (yc = {})), (function (e) { function t(r) { return typeof r == "string"; } s(t, "is"), e.is = t; })(go || (go = {})), (function (e) { e.MIN_VALUE = -2147483648, e.MAX_VALUE = 2147483647; function t(r) { return typeof r == "number" && e.MIN_VALUE <= r && r <= e.MAX_VALUE; } s(t, "is"), e.is = t; })(gc || (gc = {})), (function (e) { e.MIN_VALUE = 0, e.MAX_VALUE = 2147483647; function t(r) { return typeof r == "number" && e.MIN_VALUE <= r && r <= e.MAX_VALUE; } s(t, "is"), e.is = t; })(Mi || (Mi = {})), (function (e) { function t(n, a) { return n === Number.MAX_VALUE && (n = Mi.MAX_VALUE), a === Number.MAX_VALUE && (a = Mi.MAX_VALUE), { line: n, character: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && R.uinteger(a.line) && R.uinteger(a.character); } s(r, "is"), e.is = r; })(ae || (ae = {})), (function (e) { function t(n, a, i, o) { if (R.uinteger(n) && R.uinteger(a) && R.uinteger(i) && R.uinteger(o))
            return { start: ae.create(n, a), end: ae.create(i, o) }; if (ae.is(n) && ae.is(a))
            return { start: n, end: a }; throw new Error(`Range#create called with invalid arguments[${n}, ${a}, ${i}, ${o}]`); } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && ae.is(a.start) && ae.is(a.end); } s(r, "is"), e.is = r; })(Z || (Z = {})), (function (e) { function t(n, a) { return { uri: n, range: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && Z.is(a.range) && (R.string(a.uri) || R.undefined(a.uri)); } s(r, "is"), e.is = r; })(Gi || (Gi = {})), (function (e) { function t(n, a, i, o) { return { targetUri: n, targetRange: a, targetSelectionRange: i, originSelectionRange: o }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && Z.is(a.targetRange) && R.string(a.targetUri) && Z.is(a.targetSelectionRange) && (Z.is(a.originSelectionRange) || R.undefined(a.originSelectionRange)); } s(r, "is"), e.is = r; })(vc || (vc = {})), (function (e) { function t(n, a, i, o) { return { red: n, green: a, blue: i, alpha: o }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && R.numberRange(a.red, 0, 1) && R.numberRange(a.green, 0, 1) && R.numberRange(a.blue, 0, 1) && R.numberRange(a.alpha, 0, 1); } s(r, "is"), e.is = r; })(vo || (vo = {})), (function (e) { function t(n, a) { return { range: n, color: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && Z.is(a.range) && vo.is(a.color); } s(r, "is"), e.is = r; })(Tc || (Tc = {})), (function (e) { function t(n, a, i) { return { label: n, textEdit: a, additionalTextEdits: i }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && R.string(a.label) && (R.undefined(a.textEdit) || Bt.is(a)) && (R.undefined(a.additionalTextEdits) || R.typedArray(a.additionalTextEdits, Bt.is)); } s(r, "is"), e.is = r; })($c || ($c = {})), (function (e) { e.Comment = "comment", e.Imports = "imports", e.Region = "region"; })(Rc || (Rc = {})), (function (e) { function t(n, a, i, o, l, u) { let c = { startLine: n, endLine: a }; return R.defined(i) && (c.startCharacter = i), R.defined(o) && (c.endCharacter = o), R.defined(l) && (c.kind = l), R.defined(u) && (c.collapsedText = u), c; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && R.uinteger(a.startLine) && R.uinteger(a.startLine) && (R.undefined(a.startCharacter) || R.uinteger(a.startCharacter)) && (R.undefined(a.endCharacter) || R.uinteger(a.endCharacter)) && (R.undefined(a.kind) || R.string(a.kind)); } s(r, "is"), e.is = r; })(Ac || (Ac = {})), (function (e) { function t(n, a) { return { location: n, message: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && Gi.is(a.location) && R.string(a.message); } s(r, "is"), e.is = r; })(To || (To = {})), (function (e) { e.Error = 1, e.Warning = 2, e.Information = 3, e.Hint = 4; })(Ec || (Ec = {})), (function (e) { e.Unnecessary = 1, e.Deprecated = 2; })(bc || (bc = {})), (function (e) { function t(r) { let n = r; return R.objectLiteral(n) && R.string(n.href); } s(t, "is"), e.is = t; })(Cc || (Cc = {})), (function (e) { function t(n, a, i, o, l, u) { let c = { range: n, message: a }; return R.defined(i) && (c.severity = i), R.defined(o) && (c.code = o), R.defined(l) && (c.source = l), R.defined(u) && (c.relatedInformation = u), c; } s(t, "create"), e.create = t; function r(n) { var a; let i = n; return R.defined(i) && Z.is(i.range) && R.string(i.message) && (R.number(i.severity) || R.undefined(i.severity)) && (R.integer(i.code) || R.string(i.code) || R.undefined(i.code)) && (R.undefined(i.codeDescription) || R.string((a = i.codeDescription) === null || a === void 0 ? void 0 : a.href)) && (R.string(i.source) || R.undefined(i.source)) && (R.undefined(i.relatedInformation) || R.typedArray(i.relatedInformation, To.is)); } s(r, "is"), e.is = r; })(Fi || (Fi = {})), (function (e) { function t(n, a, ...i) { let o = { title: n, command: a }; return R.defined(i) && i.length > 0 && (o.arguments = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.string(a.title) && R.string(a.command); } s(r, "is"), e.is = r; })(Jr || (Jr = {})), (function (e) { function t(i, o) { return { range: i, newText: o }; } s(t, "replace"), e.replace = t; function r(i, o) { return { range: { start: i, end: i }, newText: o }; } s(r, "insert"), e.insert = r; function n(i) { return { range: i, newText: "" }; } s(n, "del"), e.del = n; function a(i) { let o = i; return R.objectLiteral(o) && R.string(o.newText) && Z.is(o.range); } s(a, "is"), e.is = a; })(Bt || (Bt = {})), (function (e) { function t(n, a, i) { let o = { label: n }; return a !== void 0 && (o.needsConfirmation = a), i !== void 0 && (o.description = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && R.string(a.label) && (R.boolean(a.needsConfirmation) || a.needsConfirmation === void 0) && (R.string(a.description) || a.description === void 0); } s(r, "is"), e.is = r; })(Zr || (Zr = {})), (function (e) { function t(r) { let n = r; return R.string(n); } s(t, "is"), e.is = t; })(qe || (qe = {})), (function (e) { function t(i, o, l) { return { range: i, newText: o, annotationId: l }; } s(t, "replace"), e.replace = t; function r(i, o, l) { return { range: { start: i, end: i }, newText: o, annotationId: l }; } s(r, "insert"), e.insert = r; function n(i, o) { return { range: i, newText: "", annotationId: o }; } s(n, "del"), e.del = n; function a(i) { let o = i; return Bt.is(o) && (Zr.is(o.annotationId) || qe.is(o.annotationId)); } s(a, "is"), e.is = a; })(sr || (sr = {})), (function (e) { function t(n, a) { return { textDocument: n, edits: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && ji.is(a.textDocument) && Array.isArray(a.edits); } s(r, "is"), e.is = r; })(zi || (zi = {})), (function (e) { function t(n, a, i) { let o = { kind: "create", uri: n }; return a !== void 0 && (a.overwrite !== void 0 || a.ignoreIfExists !== void 0) && (o.options = a), i !== void 0 && (o.annotationId = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && a.kind === "create" && R.string(a.uri) && (a.options === void 0 || (a.options.overwrite === void 0 || R.boolean(a.options.overwrite)) && (a.options.ignoreIfExists === void 0 || R.boolean(a.options.ignoreIfExists))) && (a.annotationId === void 0 || qe.is(a.annotationId)); } s(r, "is"), e.is = r; })(ua || (ua = {})), (function (e) { function t(n, a, i, o) { let l = { kind: "rename", oldUri: n, newUri: a }; return i !== void 0 && (i.overwrite !== void 0 || i.ignoreIfExists !== void 0) && (l.options = i), o !== void 0 && (l.annotationId = o), l; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && a.kind === "rename" && R.string(a.oldUri) && R.string(a.newUri) && (a.options === void 0 || (a.options.overwrite === void 0 || R.boolean(a.options.overwrite)) && (a.options.ignoreIfExists === void 0 || R.boolean(a.options.ignoreIfExists))) && (a.annotationId === void 0 || qe.is(a.annotationId)); } s(r, "is"), e.is = r; })(ca || (ca = {})), (function (e) { function t(n, a, i) { let o = { kind: "delete", uri: n }; return a !== void 0 && (a.recursive !== void 0 || a.ignoreIfNotExists !== void 0) && (o.options = a), i !== void 0 && (o.annotationId = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && a.kind === "delete" && R.string(a.uri) && (a.options === void 0 || (a.options.recursive === void 0 || R.boolean(a.options.recursive)) && (a.options.ignoreIfNotExists === void 0 || R.boolean(a.options.ignoreIfNotExists))) && (a.annotationId === void 0 || qe.is(a.annotationId)); } s(r, "is"), e.is = r; })(fa || (fa = {})), (function (e) { function t(r) { let n = r; return n && (n.changes !== void 0 || n.documentChanges !== void 0) && (n.documentChanges === void 0 || n.documentChanges.every(a => R.string(a.kind) ? ua.is(a) || ca.is(a) || fa.is(a) : zi.is(a))); } s(t, "is"), e.is = t; })($o || ($o = {})), Ci = class {
            static { s(this, "TextEditChangeImpl"); }
            constructor(e, t) { this.edits = e, this.changeAnnotations = t; }
            insert(e, t, r) { let n, a; if (r === void 0 ? n = Bt.insert(e, t) : qe.is(r) ? (a = r, n = sr.insert(e, t, r)) : (this.assertChangeAnnotations(this.changeAnnotations), a = this.changeAnnotations.manage(r), n = sr.insert(e, t, a)), this.edits.push(n), a !== void 0)
                return a; }
            replace(e, t, r) { let n, a; if (r === void 0 ? n = Bt.replace(e, t) : qe.is(r) ? (a = r, n = sr.replace(e, t, r)) : (this.assertChangeAnnotations(this.changeAnnotations), a = this.changeAnnotations.manage(r), n = sr.replace(e, t, a)), this.edits.push(n), a !== void 0)
                return a; }
            delete(e, t) { let r, n; if (t === void 0 ? r = Bt.del(e) : qe.is(t) ? (n = t, r = sr.del(e, t)) : (this.assertChangeAnnotations(this.changeAnnotations), n = this.changeAnnotations.manage(t), r = sr.del(e, n)), this.edits.push(r), n !== void 0)
                return n; }
            add(e) { this.edits.push(e); }
            all() { return this.edits; }
            clear() { this.edits.splice(0, this.edits.length); }
            assertChangeAnnotations(e) { if (e === void 0)
                throw new Error("Text edit change is not configured to manage change annotations."); }
        }, zu = class {
            static { s(this, "ChangeAnnotations"); }
            constructor(e) { this._annotations = e === void 0 ? Object.create(null) : e, this._counter = 0, this._size = 0; }
            all() { return this._annotations; }
            get size() { return this._size; }
            manage(e, t) { let r; if (qe.is(e) ? r = e : (r = this.nextId(), t = e), this._annotations[r] !== void 0)
                throw new Error(`Id ${r} is already in use.`); if (t === void 0)
                throw new Error(`No annotation provided for id ${r}`); return this._annotations[r] = t, this._size++, r; }
            nextId() { return this._counter++, this._counter.toString(); }
        }, Cg = class {
            static { s(this, "WorkspaceChange"); }
            constructor(e) { this._textEditChanges = Object.create(null), e !== void 0 ? (this._workspaceEdit = e, e.documentChanges ? (this._changeAnnotations = new zu(e.changeAnnotations), e.changeAnnotations = this._changeAnnotations.all(), e.documentChanges.forEach(t => { if (zi.is(t)) {
                let r = new Ci(t.edits, this._changeAnnotations);
                this._textEditChanges[t.textDocument.uri] = r;
            } })) : e.changes && Object.keys(e.changes).forEach(t => { let r = new Ci(e.changes[t]); this._textEditChanges[t] = r; })) : this._workspaceEdit = {}; }
            get edit() { return this.initDocumentChanges(), this._changeAnnotations !== void 0 && (this._changeAnnotations.size === 0 ? this._workspaceEdit.changeAnnotations = void 0 : this._workspaceEdit.changeAnnotations = this._changeAnnotations.all()), this._workspaceEdit; }
            getTextEditChange(e) { if (ji.is(e)) {
                if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
                    throw new Error("Workspace edit is not configured for document changes.");
                let t = { uri: e.uri, version: e.version }, r = this._textEditChanges[t.uri];
                if (!r) {
                    let n = [], a = { textDocument: t, edits: n };
                    this._workspaceEdit.documentChanges.push(a), r = new Ci(n, this._changeAnnotations), this._textEditChanges[t.uri] = r;
                }
                return r;
            }
            else {
                if (this.initChanges(), this._workspaceEdit.changes === void 0)
                    throw new Error("Workspace edit is not configured for normal text edit changes.");
                let t = this._textEditChanges[e];
                if (!t) {
                    let r = [];
                    this._workspaceEdit.changes[e] = r, t = new Ci(r), this._textEditChanges[e] = t;
                }
                return t;
            } }
            initDocumentChanges() { this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0 && (this._changeAnnotations = new zu, this._workspaceEdit.documentChanges = [], this._workspaceEdit.changeAnnotations = this._changeAnnotations.all()); }
            initChanges() { this._workspaceEdit.documentChanges === void 0 && this._workspaceEdit.changes === void 0 && (this._workspaceEdit.changes = Object.create(null)); }
            createFile(e, t, r) { if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
                throw new Error("Workspace edit is not configured for document changes."); let n; Zr.is(t) || qe.is(t) ? n = t : r = t; let a, i; if (n === void 0 ? a = ua.create(e, r) : (i = qe.is(n) ? n : this._changeAnnotations.manage(n), a = ua.create(e, r, i)), this._workspaceEdit.documentChanges.push(a), i !== void 0)
                return i; }
            renameFile(e, t, r, n) { if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
                throw new Error("Workspace edit is not configured for document changes."); let a; Zr.is(r) || qe.is(r) ? a = r : n = r; let i, o; if (a === void 0 ? i = ca.create(e, t, n) : (o = qe.is(a) ? a : this._changeAnnotations.manage(a), i = ca.create(e, t, n, o)), this._workspaceEdit.documentChanges.push(i), o !== void 0)
                return o; }
            deleteFile(e, t, r) { if (this.initDocumentChanges(), this._workspaceEdit.documentChanges === void 0)
                throw new Error("Workspace edit is not configured for document changes."); let n; Zr.is(t) || qe.is(t) ? n = t : r = t; let a, i; if (n === void 0 ? a = fa.create(e, r) : (i = qe.is(n) ? n : this._changeAnnotations.manage(n), a = fa.create(e, r, i)), this._workspaceEdit.documentChanges.push(a), i !== void 0)
                return i; }
        }, (function (e) { function t(n) { return { uri: n }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.string(a.uri); } s(r, "is"), e.is = r; })(_c || (_c = {})), (function (e) { function t(n, a) { return { uri: n, version: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.string(a.uri) && R.integer(a.version); } s(r, "is"), e.is = r; })(Sc || (Sc = {})), (function (e) { function t(n, a) { return { uri: n, version: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.string(a.uri) && (a.version === null || R.integer(a.version)); } s(r, "is"), e.is = r; })(ji || (ji = {})), (function (e) { function t(n, a, i, o) { return { uri: n, languageId: a, version: i, text: o }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.string(a.uri) && R.string(a.languageId) && R.integer(a.version) && R.string(a.text); } s(r, "is"), e.is = r; })(wc || (wc = {})), (function (e) { e.PlainText = "plaintext", e.Markdown = "markdown"; function t(r) { let n = r; return n === e.PlainText || n === e.Markdown; } s(t, "is"), e.is = t; })(Ro || (Ro = {})), (function (e) { function t(r) { let n = r; return R.objectLiteral(r) && Ro.is(n.kind) && R.string(n.value); } s(t, "is"), e.is = t; })(pa || (pa = {})), (function (e) { e.Text = 1, e.Method = 2, e.Function = 3, e.Constructor = 4, e.Field = 5, e.Variable = 6, e.Class = 7, e.Interface = 8, e.Module = 9, e.Property = 10, e.Unit = 11, e.Value = 12, e.Enum = 13, e.Keyword = 14, e.Snippet = 15, e.Color = 16, e.File = 17, e.Reference = 18, e.Folder = 19, e.EnumMember = 20, e.Constant = 21, e.Struct = 22, e.Event = 23, e.Operator = 24, e.TypeParameter = 25; })(Ic || (Ic = {})), (function (e) { e.PlainText = 1, e.Snippet = 2; })(Nc || (Nc = {})), (function (e) { e.Deprecated = 1; })(Pc || (Pc = {})), (function (e) { function t(n, a, i) { return { newText: n, insert: a, replace: i }; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && R.string(a.newText) && Z.is(a.insert) && Z.is(a.replace); } s(r, "is"), e.is = r; })(kc || (kc = {})), (function (e) { e.asIs = 1, e.adjustIndentation = 2; })(Oc || (Oc = {})), (function (e) { function t(r) { let n = r; return n && (R.string(n.detail) || n.detail === void 0) && (R.string(n.description) || n.description === void 0); } s(t, "is"), e.is = t; })(Lc || (Lc = {})), (function (e) { function t(r) { return { label: r }; } s(t, "create"), e.create = t; })(Dc || (Dc = {})), (function (e) { function t(r, n) { return { items: r || [], isIncomplete: !!n }; } s(t, "create"), e.create = t; })(xc || (xc = {})), (function (e) { function t(n) { return n.replace(/[\\`*_{}[\]()#+\-.!]/g, "\\$&"); } s(t, "fromPlainText"), e.fromPlainText = t; function r(n) { let a = n; return R.string(a) || R.objectLiteral(a) && R.string(a.language) && R.string(a.value); } s(r, "is"), e.is = r; })(Ui || (Ui = {})), (function (e) { function t(r) { let n = r; return !!n && R.objectLiteral(n) && (pa.is(n.contents) || Ui.is(n.contents) || R.typedArray(n.contents, Ui.is)) && (r.range === void 0 || Z.is(r.range)); } s(t, "is"), e.is = t; })(Mc || (Mc = {})), (function (e) { function t(r, n) { return n ? { label: r, documentation: n } : { label: r }; } s(t, "create"), e.create = t; })(Gc || (Gc = {})), (function (e) { function t(r, n, ...a) { let i = { label: r }; return R.defined(n) && (i.documentation = n), R.defined(a) ? i.parameters = a : i.parameters = [], i; } s(t, "create"), e.create = t; })(Fc || (Fc = {})), (function (e) { e.Text = 1, e.Read = 2, e.Write = 3; })(zc || (zc = {})), (function (e) { function t(r, n) { let a = { range: r }; return R.number(n) && (a.kind = n), a; } s(t, "create"), e.create = t; })(jc || (jc = {})), (function (e) { e.File = 1, e.Module = 2, e.Namespace = 3, e.Package = 4, e.Class = 5, e.Method = 6, e.Property = 7, e.Field = 8, e.Constructor = 9, e.Enum = 10, e.Interface = 11, e.Function = 12, e.Variable = 13, e.Constant = 14, e.String = 15, e.Number = 16, e.Boolean = 17, e.Array = 18, e.Object = 19, e.Key = 20, e.Null = 21, e.EnumMember = 22, e.Struct = 23, e.Event = 24, e.Operator = 25, e.TypeParameter = 26; })(Uc || (Uc = {})), (function (e) { e.Deprecated = 1; })(Bc || (Bc = {})), (function (e) { function t(r, n, a, i, o) { let l = { name: r, kind: n, location: { uri: i, range: a } }; return o && (l.containerName = o), l; } s(t, "create"), e.create = t; })(Kc || (Kc = {})), (function (e) { function t(r, n, a, i) { return i !== void 0 ? { name: r, kind: n, location: { uri: a, range: i } } : { name: r, kind: n, location: { uri: a } }; } s(t, "create"), e.create = t; })(qc || (qc = {})), (function (e) { function t(n, a, i, o, l, u) { let c = { name: n, detail: a, kind: i, range: o, selectionRange: l }; return u !== void 0 && (c.children = u), c; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && R.string(a.name) && R.number(a.kind) && Z.is(a.range) && Z.is(a.selectionRange) && (a.detail === void 0 || R.string(a.detail)) && (a.deprecated === void 0 || R.boolean(a.deprecated)) && (a.children === void 0 || Array.isArray(a.children)) && (a.tags === void 0 || Array.isArray(a.tags)); } s(r, "is"), e.is = r; })(Wc || (Wc = {})), (function (e) { e.Empty = "", e.QuickFix = "quickfix", e.Refactor = "refactor", e.RefactorExtract = "refactor.extract", e.RefactorInline = "refactor.inline", e.RefactorRewrite = "refactor.rewrite", e.Source = "source", e.SourceOrganizeImports = "source.organizeImports", e.SourceFixAll = "source.fixAll"; })(Vc || (Vc = {})), (function (e) { e.Invoked = 1, e.Automatic = 2; })(Bi || (Bi = {})), (function (e) { function t(n, a, i) { let o = { diagnostics: n }; return a != null && (o.only = a), i != null && (o.triggerKind = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.typedArray(a.diagnostics, Fi.is) && (a.only === void 0 || R.typedArray(a.only, R.string)) && (a.triggerKind === void 0 || a.triggerKind === Bi.Invoked || a.triggerKind === Bi.Automatic); } s(r, "is"), e.is = r; })(Hc || (Hc = {})), (function (e) { function t(n, a, i) { let o = { title: n }, l = !0; return typeof a == "string" ? (l = !1, o.kind = a) : Jr.is(a) ? o.command = a : o.edit = a, l && i !== void 0 && (o.kind = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return a && R.string(a.title) && (a.diagnostics === void 0 || R.typedArray(a.diagnostics, Fi.is)) && (a.kind === void 0 || R.string(a.kind)) && (a.edit !== void 0 || a.command !== void 0) && (a.command === void 0 || Jr.is(a.command)) && (a.isPreferred === void 0 || R.boolean(a.isPreferred)) && (a.edit === void 0 || $o.is(a.edit)); } s(r, "is"), e.is = r; })(Yc || (Yc = {})), (function (e) { function t(n, a) { let i = { range: n }; return R.defined(a) && (i.data = a), i; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && Z.is(a.range) && (R.undefined(a.command) || Jr.is(a.command)); } s(r, "is"), e.is = r; })(Xc || (Xc = {})), (function (e) { function t(n, a) { return { tabSize: n, insertSpaces: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && R.uinteger(a.tabSize) && R.boolean(a.insertSpaces); } s(r, "is"), e.is = r; })(Jc || (Jc = {})), (function (e) { function t(n, a, i) { return { range: n, target: a, data: i }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && Z.is(a.range) && (R.undefined(a.target) || R.string(a.target)); } s(r, "is"), e.is = r; })(Zc || (Zc = {})), (function (e) { function t(n, a) { return { range: n, parent: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && Z.is(a.range) && (a.parent === void 0 || e.is(a.parent)); } s(r, "is"), e.is = r; })(Qc || (Qc = {})), (function (e) { e.namespace = "namespace", e.type = "type", e.class = "class", e.enum = "enum", e.interface = "interface", e.struct = "struct", e.typeParameter = "typeParameter", e.parameter = "parameter", e.variable = "variable", e.property = "property", e.enumMember = "enumMember", e.event = "event", e.function = "function", e.method = "method", e.macro = "macro", e.keyword = "keyword", e.modifier = "modifier", e.comment = "comment", e.string = "string", e.number = "number", e.regexp = "regexp", e.operator = "operator", e.decorator = "decorator"; })(ef || (ef = {})), (function (e) { e.declaration = "declaration", e.definition = "definition", e.readonly = "readonly", e.static = "static", e.deprecated = "deprecated", e.abstract = "abstract", e.async = "async", e.modification = "modification", e.documentation = "documentation", e.defaultLibrary = "defaultLibrary"; })(tf || (tf = {})), (function (e) { function t(r) { let n = r; return R.objectLiteral(n) && (n.resultId === void 0 || typeof n.resultId == "string") && Array.isArray(n.data) && (n.data.length === 0 || typeof n.data[0] == "number"); } s(t, "is"), e.is = t; })(rf || (rf = {})), (function (e) { function t(n, a) { return { range: n, text: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return a != null && Z.is(a.range) && R.string(a.text); } s(r, "is"), e.is = r; })(nf || (nf = {})), (function (e) { function t(n, a, i) { return { range: n, variableName: a, caseSensitiveLookup: i }; } s(t, "create"), e.create = t; function r(n) { let a = n; return a != null && Z.is(a.range) && R.boolean(a.caseSensitiveLookup) && (R.string(a.variableName) || a.variableName === void 0); } s(r, "is"), e.is = r; })(af || (af = {})), (function (e) { function t(n, a) { return { range: n, expression: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return a != null && Z.is(a.range) && (R.string(a.expression) || a.expression === void 0); } s(r, "is"), e.is = r; })(sf || (sf = {})), (function (e) { function t(n, a) { return { frameId: n, stoppedLocation: a }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.defined(a) && Z.is(n.stoppedLocation); } s(r, "is"), e.is = r; })(of || (of = {})), (function (e) { e.Type = 1, e.Parameter = 2; function t(r) { return r === 1 || r === 2; } s(t, "is"), e.is = t; })(Ao || (Ao = {})), (function (e) { function t(n) { return { value: n }; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && (a.tooltip === void 0 || R.string(a.tooltip) || pa.is(a.tooltip)) && (a.location === void 0 || Gi.is(a.location)) && (a.command === void 0 || Jr.is(a.command)); } s(r, "is"), e.is = r; })(Eo || (Eo = {})), (function (e) { function t(n, a, i) { let o = { position: n, label: a }; return i !== void 0 && (o.kind = i), o; } s(t, "create"), e.create = t; function r(n) { let a = n; return R.objectLiteral(a) && ae.is(a.position) && (R.string(a.label) || R.typedArray(a.label, Eo.is)) && (a.kind === void 0 || Ao.is(a.kind)) && a.textEdits === void 0 || R.typedArray(a.textEdits, Bt.is) && (a.tooltip === void 0 || R.string(a.tooltip) || pa.is(a.tooltip)) && (a.paddingLeft === void 0 || R.boolean(a.paddingLeft)) && (a.paddingRight === void 0 || R.boolean(a.paddingRight)); } s(r, "is"), e.is = r; })(lf || (lf = {})), (function (e) { function t(r) { return { kind: "snippet", value: r }; } s(t, "createSnippet"), e.createSnippet = t; })(uf || (uf = {})), (function (e) { function t(r, n, a, i) { return { insertText: r, filterText: n, range: a, command: i }; } s(t, "create"), e.create = t; })(cf || (cf = {})), (function (e) { function t(r) { return { items: r }; } s(t, "create"), e.create = t; })(ff || (ff = {})), (function (e) { e.Invoked = 0, e.Automatic = 1; })(pf || (pf = {})), (function (e) { function t(r, n) { return { range: r, text: n }; } s(t, "create"), e.create = t; })(df || (df = {})), (function (e) { function t(r, n) { return { triggerKind: r, selectedCompletionInfo: n }; } s(t, "create"), e.create = t; })(mf || (mf = {})), (function (e) { function t(r) { let n = r; return R.objectLiteral(n) && go.is(n.uri) && R.string(n.name); } s(t, "is"), e.is = t; })(hf || (hf = {})), _g = [`
`, `\r
`, "\r"], (function (e) { function t(i, o, l, u) { return new th(i, o, l, u); } s(t, "create"), e.create = t; function r(i) { let o = i; return !!(R.defined(o) && R.string(o.uri) && (R.undefined(o.languageId) || R.string(o.languageId)) && R.uinteger(o.lineCount) && R.func(o.getText) && R.func(o.positionAt) && R.func(o.offsetAt)); } s(r, "is"), e.is = r; function n(i, o) { let l = i.getText(), u = a(o, (f, p) => { let m = f.range.start.line - p.range.start.line; return m === 0 ? f.range.start.character - p.range.start.character : m; }), c = l.length; for (let f = u.length - 1; f >= 0; f--) {
            let p = u[f], m = i.offsetAt(p.range.start), g = i.offsetAt(p.range.end);
            if (g <= c)
                l = l.substring(0, m) + p.newText + l.substring(g, l.length);
            else
                throw new Error("Overlapping edit");
            c = m;
        } return l; } s(n, "applyEdits"), e.applyEdits = n; function a(i, o) { if (i.length <= 1)
            return i; let l = i.length / 2 | 0, u = i.slice(0, l), c = i.slice(l); a(u, o), a(c, o); let f = 0, p = 0, m = 0; for (; f < u.length && p < c.length;)
            o(u[f], c[p]) <= 0 ? i[m++] = u[f++] : i[m++] = c[p++]; for (; f < u.length;)
            i[m++] = u[f++]; for (; p < c.length;)
            i[m++] = c[p++]; return i; } s(a, "mergeSort"); })(yf || (yf = {})), th = class {
            static { s(this, "FullTextDocument"); }
            constructor(e, t, r, n) { this._uri = e, this._languageId = t, this._version = r, this._content = n, this._lineOffsets = void 0; }
            get uri() { return this._uri; }
            get languageId() { return this._languageId; }
            get version() { return this._version; }
            getText(e) { if (e) {
                let t = this.offsetAt(e.start), r = this.offsetAt(e.end);
                return this._content.substring(t, r);
            } return this._content; }
            update(e, t) { this._content = e.text, this._version = t, this._lineOffsets = void 0; }
            getLineOffsets() {
                if (this._lineOffsets === void 0) {
                    let e = [], t = this._content, r = !0;
                    for (let n = 0; n < t.length; n++) {
                        r && (e.push(n), r = !1);
                        let a = t.charAt(n);
                        r = a === "\r" || a === `
`, a === "\r" && n + 1 < t.length && t.charAt(n + 1) === `
` && n++;
                    }
                    r && t.length > 0 && e.push(t.length), this._lineOffsets = e;
                }
                return this._lineOffsets;
            }
            positionAt(e) { e = Math.max(Math.min(e, this._content.length), 0); let t = this.getLineOffsets(), r = 0, n = t.length; if (n === 0)
                return ae.create(0, e); for (; r < n;) {
                let i = Math.floor((r + n) / 2);
                t[i] > e ? n = i : r = i + 1;
            } let a = r - 1; return ae.create(a, e - t[a]); }
            offsetAt(e) { let t = this.getLineOffsets(); if (e.line >= t.length)
                return this._content.length; if (e.line < 0)
                return 0; let r = t[e.line], n = e.line + 1 < t.length ? t[e.line + 1] : this._content.length; return Math.max(Math.min(r + e.character, n), r); }
            get lineCount() { return this.getLineOffsets().length; }
        }, (function (e) { let t = Object.prototype.toString; function r(g) { return typeof g < "u"; } s(r, "defined"), e.defined = r; function n(g) { return typeof g > "u"; } s(n, "undefined"), e.undefined = n; function a(g) { return g === !0 || g === !1; } s(a, "boolean"), e.boolean = a; function i(g) { return t.call(g) === "[object String]"; } s(i, "string"), e.string = i; function o(g) { return t.call(g) === "[object Number]"; } s(o, "number"), e.number = o; function l(g, v, _) { return t.call(g) === "[object Number]" && v <= g && g <= _; } s(l, "numberRange"), e.numberRange = l; function u(g) { return t.call(g) === "[object Number]" && -2147483648 <= g && g <= 2147483647; } s(u, "integer"), e.integer = u; function c(g) { return t.call(g) === "[object Number]" && 0 <= g && g <= 2147483647; } s(c, "uinteger"), e.uinteger = c; function f(g) { return t.call(g) === "[object Function]"; } s(f, "func"), e.func = f; function p(g) { return g !== null && typeof g == "object"; } s(p, "objectLiteral"), e.objectLiteral = p; function m(g, v) { return Array.isArray(g) && g.every(v); } s(m, "typedArray"), e.typedArray = m; })(R || (R = {}));
    } }), wn = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/ral.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 });
        var t;
        function r() { if (t === void 0)
            throw new Error("No runtime abstraction layer installed"); return t; }
        s(r, "RAL"), (function (n) { function a(i) { if (i === void 0)
            throw new Error("No runtime abstraction layer provided"); t = i; } s(a, "install"), n.install = a; })(r || (r = {})), e.default = r;
    } }), Ps = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/is.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.stringArray = e.array = e.func = e.error = e.number = e.string = e.boolean = void 0;
        function t(u) { return u === !0 || u === !1; }
        s(t, "boolean"), e.boolean = t;
        function r(u) { return typeof u == "string" || u instanceof String; }
        s(r, "string"), e.string = r;
        function n(u) { return typeof u == "number" || u instanceof Number; }
        s(n, "number"), e.number = n;
        function a(u) { return u instanceof Error; }
        s(a, "error"), e.error = a;
        function i(u) { return typeof u == "function"; }
        s(i, "func"), e.func = i;
        function o(u) { return Array.isArray(u); }
        s(o, "array"), e.array = o;
        function l(u) { return o(u) && u.every(c => r(c)); }
        s(l, "stringArray"), e.stringArray = l;
    } }), Ha = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/events.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.Emitter = e.Event = void 0;
        var t = wn(), r;
        (function (i) { let o = { dispose() { } }; i.None = function () { return o; }; })(r || (e.Event = r = {}));
        var n = class {
            static { s(this, "CallbackList"); }
            add(i, o = null, l) { this._callbacks || (this._callbacks = [], this._contexts = []), this._callbacks.push(i), this._contexts.push(o), Array.isArray(l) && l.push({ dispose: s(() => this.remove(i, o), "dispose") }); }
            remove(i, o = null) { if (!this._callbacks)
                return; let l = !1; for (let u = 0, c = this._callbacks.length; u < c; u++)
                if (this._callbacks[u] === i)
                    if (this._contexts[u] === o) {
                        this._callbacks.splice(u, 1), this._contexts.splice(u, 1);
                        return;
                    }
                    else
                        l = !0; if (l)
                throw new Error("When adding a listener with a context, you should remove it with the same context"); }
            invoke(...i) { if (!this._callbacks)
                return []; let o = [], l = this._callbacks.slice(0), u = this._contexts.slice(0); for (let c = 0, f = l.length; c < f; c++)
                try {
                    o.push(l[c].apply(u[c], i));
                }
                catch (p) {
                    (0, t.default)().console.error(p);
                } return o; }
            isEmpty() { return !this._callbacks || this._callbacks.length === 0; }
            dispose() { this._callbacks = void 0, this._contexts = void 0; }
        }, a = class Sg {
            static { s(this, "Emitter"); }
            constructor(o) { this._options = o; }
            get event() { return this._event || (this._event = (o, l, u) => { this._callbacks || (this._callbacks = new n), this._options && this._options.onFirstListenerAdd && this._callbacks.isEmpty() && this._options.onFirstListenerAdd(this), this._callbacks.add(o, l); let c = { dispose: s(() => { this._callbacks && (this._callbacks.remove(o, l), c.dispose = Sg._noop, this._options && this._options.onLastListenerRemove && this._callbacks.isEmpty() && this._options.onLastListenerRemove(this)); }, "dispose") }; return Array.isArray(u) && u.push(c), c; }), this._event; }
            fire(o) { this._callbacks && this._callbacks.invoke.call(this._callbacks, o); }
            dispose() { this._callbacks && (this._callbacks.dispose(), this._callbacks = void 0); }
        };
        e.Emitter = a, a._noop = function () { };
    } }), kl = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/cancellation.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.CancellationTokenSource = e.CancellationToken = void 0;
        var t = wn(), r = Ps(), n = Ha(), a;
        (function (u) { u.None = Object.freeze({ isCancellationRequested: !1, onCancellationRequested: n.Event.None }), u.Cancelled = Object.freeze({ isCancellationRequested: !0, onCancellationRequested: n.Event.None }); function c(f) { let p = f; return p && (p === u.None || p === u.Cancelled || r.boolean(p.isCancellationRequested) && !!p.onCancellationRequested); } s(c, "is"), u.is = c; })(a || (e.CancellationToken = a = {}));
        var i = Object.freeze(function (u, c) { let f = (0, t.default)().timer.setTimeout(u.bind(c), 0); return { dispose() { f.dispose(); } }; }), o = class {
            static { s(this, "MutableToken"); }
            constructor() { this._isCancelled = !1; }
            cancel() { this._isCancelled || (this._isCancelled = !0, this._emitter && (this._emitter.fire(void 0), this.dispose())); }
            get isCancellationRequested() { return this._isCancelled; }
            get onCancellationRequested() { return this._isCancelled ? i : (this._emitter || (this._emitter = new n.Emitter), this._emitter.event); }
            dispose() { this._emitter && (this._emitter.dispose(), this._emitter = void 0); }
        }, l = class {
            static { s(this, "CancellationTokenSource"); }
            get token() { return this._token || (this._token = new o), this._token; }
            cancel() { this._token ? this._token.cancel() : this._token = a.Cancelled; }
            dispose() { this._token ? this._token instanceof o && this._token.dispose() : this._token = a.None; }
        };
        e.CancellationTokenSource = l;
    } }), wg = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/messages.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.Message = e.NotificationType9 = e.NotificationType8 = e.NotificationType7 = e.NotificationType6 = e.NotificationType5 = e.NotificationType4 = e.NotificationType3 = e.NotificationType2 = e.NotificationType1 = e.NotificationType0 = e.NotificationType = e.RequestType9 = e.RequestType8 = e.RequestType7 = e.RequestType6 = e.RequestType5 = e.RequestType4 = e.RequestType3 = e.RequestType2 = e.RequestType1 = e.RequestType = e.RequestType0 = e.AbstractMessageSignature = e.ParameterStructures = e.ResponseError = e.ErrorCodes = void 0;
        var t = Ps(), r = (function (y) { return y.ParseError = -32700, y.InvalidRequest = -32600, y.MethodNotFound = -32601, y.InvalidParams = -32602, y.InternalError = -32603, y.jsonrpcReservedErrorRangeStart = -32099, y.serverErrorStart = -32099, y.MessageWriteError = -32099, y.MessageReadError = -32098, y.PendingResponseRejected = -32097, y.ConnectionInactive = -32096, y.ServerNotInitialized = -32002, y.UnknownErrorCode = -32001, y.jsonrpcReservedErrorRangeEnd = -32e3, y.serverErrorEnd = -32e3, y; })(r || (e.ErrorCodes = r = {})), n = class Ig extends Error {
            static { s(this, "ResponseError"); }
            constructor(A, T, $) { super(T), this.code = t.number(A) ? A : r.UnknownErrorCode, this.data = $, Object.setPrototypeOf(this, Ig.prototype); }
            toJson() { let A = { code: this.code, message: this.message }; return this.data !== void 0 && (A.data = this.data), A; }
        };
        e.ResponseError = n;
        var a = class bo {
            static { s(this, "ParameterStructures"); }
            constructor(A) { this.kind = A; }
            static is(A) { return A === bo.auto || A === bo.byName || A === bo.byPosition; }
            toString() { return this.kind; }
        };
        e.ParameterStructures = a, a.auto = new a("auto"), a.byPosition = new a("byPosition"), a.byName = new a("byName");
        var i = class {
            static { s(this, "AbstractMessageSignature"); }
            constructor(y, A) { this.method = y, this.numberOfParams = A; }
            get parameterStructures() { return a.auto; }
        };
        e.AbstractMessageSignature = i;
        var o = class extends i {
            static { s(this, "RequestType0"); }
            constructor(y) { super(y, 0); }
        };
        e.RequestType0 = o;
        var l = class extends i {
            static { s(this, "RequestType"); }
            constructor(y, A = a.auto) { super(y, 1), this._parameterStructures = A; }
            get parameterStructures() { return this._parameterStructures; }
        };
        e.RequestType = l;
        var u = class extends i {
            static { s(this, "RequestType1"); }
            constructor(y, A = a.auto) { super(y, 1), this._parameterStructures = A; }
            get parameterStructures() { return this._parameterStructures; }
        };
        e.RequestType1 = u;
        var c = class extends i {
            static { s(this, "RequestType2"); }
            constructor(y) { super(y, 2); }
        };
        e.RequestType2 = c;
        var f = class extends i {
            static { s(this, "RequestType3"); }
            constructor(y) { super(y, 3); }
        };
        e.RequestType3 = f;
        var p = class extends i {
            static { s(this, "RequestType4"); }
            constructor(y) { super(y, 4); }
        };
        e.RequestType4 = p;
        var m = class extends i {
            static { s(this, "RequestType5"); }
            constructor(y) { super(y, 5); }
        };
        e.RequestType5 = m;
        var g = class extends i {
            static { s(this, "RequestType6"); }
            constructor(y) { super(y, 6); }
        };
        e.RequestType6 = g;
        var v = class extends i {
            static { s(this, "RequestType7"); }
            constructor(y) { super(y, 7); }
        };
        e.RequestType7 = v;
        var _ = class extends i {
            static { s(this, "RequestType8"); }
            constructor(y) { super(y, 8); }
        };
        e.RequestType8 = _;
        var N = class extends i {
            static { s(this, "RequestType9"); }
            constructor(y) { super(y, 9); }
        };
        e.RequestType9 = N;
        var w = class extends i {
            static { s(this, "NotificationType"); }
            constructor(y, A = a.auto) { super(y, 1), this._parameterStructures = A; }
            get parameterStructures() { return this._parameterStructures; }
        };
        e.NotificationType = w;
        var S = class extends i {
            static { s(this, "NotificationType0"); }
            constructor(y) { super(y, 0); }
        };
        e.NotificationType0 = S;
        var E = class extends i {
            static { s(this, "NotificationType1"); }
            constructor(y, A = a.auto) { super(y, 1), this._parameterStructures = A; }
            get parameterStructures() { return this._parameterStructures; }
        };
        e.NotificationType1 = E;
        var I = class extends i {
            static { s(this, "NotificationType2"); }
            constructor(y) { super(y, 2); }
        };
        e.NotificationType2 = I;
        var j = class extends i {
            static { s(this, "NotificationType3"); }
            constructor(y) { super(y, 3); }
        };
        e.NotificationType3 = j;
        var Q = class extends i {
            static { s(this, "NotificationType4"); }
            constructor(y) { super(y, 4); }
        };
        e.NotificationType4 = Q;
        var X = class extends i {
            static { s(this, "NotificationType5"); }
            constructor(y) { super(y, 5); }
        };
        e.NotificationType5 = X;
        var fe = class extends i {
            static { s(this, "NotificationType6"); }
            constructor(y) { super(y, 6); }
        };
        e.NotificationType6 = fe;
        var ye = class extends i {
            static { s(this, "NotificationType7"); }
            constructor(y) { super(y, 7); }
        };
        e.NotificationType7 = ye;
        var pe = class extends i {
            static { s(this, "NotificationType8"); }
            constructor(y) { super(y, 8); }
        };
        e.NotificationType8 = pe;
        var k = class extends i {
            static { s(this, "NotificationType9"); }
            constructor(y) { super(y, 9); }
        };
        e.NotificationType9 = k;
        var b;
        (function (y) { function A(C) { let O = C; return O && t.string(O.method) && (t.string(O.id) || t.number(O.id)); } s(A, "isRequest"), y.isRequest = A; function T(C) { let O = C; return O && t.string(O.method) && C.id === void 0; } s(T, "isNotification"), y.isNotification = T; function $(C) { let O = C; return O && (O.result !== void 0 || !!O.error) && (t.string(O.id) || t.number(O.id) || O.id === null); } s($, "isResponse"), y.isResponse = $; })(b || (e.Message = b = {}));
    } }), Ng = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/linkedMap.js"(e) {
        "use strict";
        var t;
        Object.defineProperty(e, "__esModule", { value: !0 }), e.LRUCache = e.LinkedMap = e.Touch = void 0;
        var r;
        (function (i) { i.None = 0, i.First = 1, i.AsOld = i.First, i.Last = 2, i.AsNew = i.Last; })(r || (e.Touch = r = {}));
        var n = class {
            static { s(this, "LinkedMap"); }
            constructor() { this[t] = "LinkedMap", this._map = new Map, this._head = void 0, this._tail = void 0, this._size = 0, this._state = 0; }
            clear() { this._map.clear(), this._head = void 0, this._tail = void 0, this._size = 0, this._state++; }
            isEmpty() { return !this._head && !this._tail; }
            get size() { return this._size; }
            get first() { return this._head?.value; }
            get last() { return this._tail?.value; }
            has(i) { return this._map.has(i); }
            get(i, o = r.None) { let l = this._map.get(i); if (l)
                return o !== r.None && this.touch(l, o), l.value; }
            set(i, o, l = r.None) { let u = this._map.get(i); if (u)
                u.value = o, l !== r.None && this.touch(u, l);
            else {
                switch (u = { key: i, value: o, next: void 0, previous: void 0 }, l) {
                    case r.None:
                        this.addItemLast(u);
                        break;
                    case r.First:
                        this.addItemFirst(u);
                        break;
                    case r.Last:
                        this.addItemLast(u);
                        break;
                    default:
                        this.addItemLast(u);
                        break;
                }
                this._map.set(i, u), this._size++;
            } return this; }
            delete(i) { return !!this.remove(i); }
            remove(i) { let o = this._map.get(i); if (o)
                return this._map.delete(i), this.removeItem(o), this._size--, o.value; }
            shift() { if (!this._head && !this._tail)
                return; if (!this._head || !this._tail)
                throw new Error("Invalid list"); let i = this._head; return this._map.delete(i.key), this.removeItem(i), this._size--, i.value; }
            forEach(i, o) { let l = this._state, u = this._head; for (; u;) {
                if (o ? i.bind(o)(u.value, u.key, this) : i(u.value, u.key, this), this._state !== l)
                    throw new Error("LinkedMap got modified during iteration.");
                u = u.next;
            } }
            keys() { let i = this._state, o = this._head, l = { [Symbol.iterator]: () => l, next: s(() => { if (this._state !== i)
                    throw new Error("LinkedMap got modified during iteration."); if (o) {
                    let u = { value: o.key, done: !1 };
                    return o = o.next, u;
                }
                else
                    return { value: void 0, done: !0 }; }, "next") }; return l; }
            values() { let i = this._state, o = this._head, l = { [Symbol.iterator]: () => l, next: s(() => { if (this._state !== i)
                    throw new Error("LinkedMap got modified during iteration."); if (o) {
                    let u = { value: o.value, done: !1 };
                    return o = o.next, u;
                }
                else
                    return { value: void 0, done: !0 }; }, "next") }; return l; }
            entries() { let i = this._state, o = this._head, l = { [Symbol.iterator]: () => l, next: s(() => { if (this._state !== i)
                    throw new Error("LinkedMap got modified during iteration."); if (o) {
                    let u = { value: [o.key, o.value], done: !1 };
                    return o = o.next, u;
                }
                else
                    return { value: void 0, done: !0 }; }, "next") }; return l; }
            [(t = Symbol.toStringTag, Symbol.iterator)]() { return this.entries(); }
            trimOld(i) { if (i >= this.size)
                return; if (i === 0) {
                this.clear();
                return;
            } let o = this._head, l = this.size; for (; o && l > i;)
                this._map.delete(o.key), o = o.next, l--; this._head = o, this._size = l, o && (o.previous = void 0), this._state++; }
            addItemFirst(i) { if (!this._head && !this._tail)
                this._tail = i;
            else if (this._head)
                i.next = this._head, this._head.previous = i;
            else
                throw new Error("Invalid list"); this._head = i, this._state++; }
            addItemLast(i) { if (!this._head && !this._tail)
                this._head = i;
            else if (this._tail)
                i.previous = this._tail, this._tail.next = i;
            else
                throw new Error("Invalid list"); this._tail = i, this._state++; }
            removeItem(i) { if (i === this._head && i === this._tail)
                this._head = void 0, this._tail = void 0;
            else if (i === this._head) {
                if (!i.next)
                    throw new Error("Invalid list");
                i.next.previous = void 0, this._head = i.next;
            }
            else if (i === this._tail) {
                if (!i.previous)
                    throw new Error("Invalid list");
                i.previous.next = void 0, this._tail = i.previous;
            }
            else {
                let o = i.next, l = i.previous;
                if (!o || !l)
                    throw new Error("Invalid list");
                o.previous = l, l.next = o;
            } i.next = void 0, i.previous = void 0, this._state++; }
            touch(i, o) { if (!this._head || !this._tail)
                throw new Error("Invalid list"); if (!(o !== r.First && o !== r.Last)) {
                if (o === r.First) {
                    if (i === this._head)
                        return;
                    let l = i.next, u = i.previous;
                    i === this._tail ? (u.next = void 0, this._tail = u) : (l.previous = u, u.next = l), i.previous = void 0, i.next = this._head, this._head.previous = i, this._head = i, this._state++;
                }
                else if (o === r.Last) {
                    if (i === this._tail)
                        return;
                    let l = i.next, u = i.previous;
                    i === this._head ? (l.previous = void 0, this._head = l) : (l.previous = u, u.next = l), i.next = void 0, i.previous = this._tail, this._tail.next = i, this._tail = i, this._state++;
                }
            } }
            toJSON() { let i = []; return this.forEach((o, l) => { i.push([l, o]); }), i; }
            fromJSON(i) { this.clear(); for (let [o, l] of i)
                this.set(o, l); }
        };
        e.LinkedMap = n;
        var a = class extends n {
            static { s(this, "LRUCache"); }
            constructor(i, o = 1) { super(), this._limit = i, this._ratio = Math.min(Math.max(0, o), 1); }
            get limit() { return this._limit; }
            set limit(i) { this._limit = i, this.checkTrim(); }
            get ratio() { return this._ratio; }
            set ratio(i) { this._ratio = Math.min(Math.max(0, i), 1), this.checkTrim(); }
            get(i, o = r.AsNew) { return super.get(i, o); }
            peek(i) { return super.get(i, r.None); }
            set(i, o) { return super.set(i, o, r.Last), this.checkTrim(), this; }
            checkTrim() { this.size > this._limit && this.trimOld(Math.round(this._limit * this._ratio)); }
        };
        e.LRUCache = a;
    } }), Mw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/disposable.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.Disposable = void 0;
        var t;
        (function (r) { function n(a) { return { dispose: a }; } s(n, "create"), r.create = n; })(t || (e.Disposable = t = {}));
    } }), Gw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/sharedArrayCancellation.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.SharedArrayReceiverStrategy = e.SharedArraySenderStrategy = void 0;
        var t = kl(), r = (function (l) { return l.Continue = 0, l.Cancelled = 1, l; })(r || {}), n = class {
            static { s(this, "SharedArraySenderStrategy"); }
            constructor() { this.buffers = new Map; }
            enableCancellation(l) { if (l.id === null)
                return; let u = new SharedArrayBuffer(4), c = new Int32Array(u, 0, 1); c[0] = r.Continue, this.buffers.set(l.id, u), l.$cancellationData = u; }
            sendCancellation(l, u) { return z(this, null, function* () { let c = this.buffers.get(u); if (c === void 0)
                return; let f = new Int32Array(c, 0, 1); Atomics.store(f, 0, r.Cancelled); }); }
            cleanup(l) { this.buffers.delete(l); }
            dispose() { this.buffers.clear(); }
        };
        e.SharedArraySenderStrategy = n;
        var a = class {
            static { s(this, "SharedArrayBufferCancellationToken"); }
            constructor(l) { this.data = new Int32Array(l, 0, 1); }
            get isCancellationRequested() { return Atomics.load(this.data, 0) === r.Cancelled; }
            get onCancellationRequested() { throw new Error("Cancellation over SharedArrayBuffer doesn't support cancellation events"); }
        }, i = class {
            static { s(this, "SharedArrayBufferCancellationTokenSource"); }
            constructor(l) { this.token = new a(l); }
            cancel() { }
            dispose() { }
        }, o = class {
            static { s(this, "SharedArrayReceiverStrategy"); }
            constructor() { this.kind = "request"; }
            createCancellationTokenSource(l) { let u = l.$cancellationData; return u === void 0 ? new t.CancellationTokenSource : new i(u); }
        };
        e.SharedArrayReceiverStrategy = o;
    } }), Pg = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/semaphore.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.Semaphore = void 0;
        var t = wn(), r = class {
            static { s(this, "Semaphore"); }
            constructor(n = 1) { if (n <= 0)
                throw new Error("Capacity must be greater than 0"); this._capacity = n, this._active = 0, this._waiting = []; }
            lock(n) { return new Promise((a, i) => { this._waiting.push({ thunk: n, resolve: a, reject: i }), this.runNext(); }); }
            get active() { return this._active; }
            runNext() { this._waiting.length === 0 || this._active === this._capacity || (0, t.default)().timer.setImmediate(() => this.doRunNext()); }
            doRunNext() { if (this._waiting.length === 0 || this._active === this._capacity)
                return; let n = this._waiting.shift(); if (this._active++, this._active > this._capacity)
                throw new Error("To many thunks active"); try {
                let a = n.thunk();
                a instanceof Promise ? a.then(i => { this._active--, n.resolve(i), this.runNext(); }, i => { this._active--, n.reject(i), this.runNext(); }) : (this._active--, n.resolve(a), this.runNext());
            }
            catch (a) {
                this._active--, n.reject(a), this.runNext();
            } }
        };
        e.Semaphore = r;
    } }), Fw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/messageReader.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ReadableStreamMessageReader = e.AbstractMessageReader = e.MessageReader = void 0;
        var t = wn(), r = Ps(), n = Ha(), a = Pg(), i;
        (function (c) { function f(p) { let m = p; return m && r.func(m.listen) && r.func(m.dispose) && r.func(m.onError) && r.func(m.onClose) && r.func(m.onPartialMessage); } s(f, "is"), c.is = f; })(i || (e.MessageReader = i = {}));
        var o = class {
            static { s(this, "AbstractMessageReader"); }
            constructor() { this.errorEmitter = new n.Emitter, this.closeEmitter = new n.Emitter, this.partialMessageEmitter = new n.Emitter; }
            dispose() { this.errorEmitter.dispose(), this.closeEmitter.dispose(); }
            get onError() { return this.errorEmitter.event; }
            fireError(c) { this.errorEmitter.fire(this.asError(c)); }
            get onClose() { return this.closeEmitter.event; }
            fireClose() { this.closeEmitter.fire(void 0); }
            get onPartialMessage() { return this.partialMessageEmitter.event; }
            firePartialMessage(c) { this.partialMessageEmitter.fire(c); }
            asError(c) { return c instanceof Error ? c : new Error(`Reader received error. Reason: ${r.string(c.message) ? c.message : "unknown"}`); }
        };
        e.AbstractMessageReader = o;
        var l;
        (function (c) { function f(p) { let m, g, v, _ = new Map, N, w = new Map; if (p === void 0 || typeof p == "string")
            m = p ?? "utf-8";
        else {
            if (m = p.charset ?? "utf-8", p.contentDecoder !== void 0 && (v = p.contentDecoder, _.set(v.name, v)), p.contentDecoders !== void 0)
                for (let S of p.contentDecoders)
                    _.set(S.name, S);
            if (p.contentTypeDecoder !== void 0 && (N = p.contentTypeDecoder, w.set(N.name, N)), p.contentTypeDecoders !== void 0)
                for (let S of p.contentTypeDecoders)
                    w.set(S.name, S);
        } return N === void 0 && (N = (0, t.default)().applicationJson.decoder, w.set(N.name, N)), { charset: m, contentDecoder: v, contentDecoders: _, contentTypeDecoder: N, contentTypeDecoders: w }; } s(f, "fromOptions"), c.fromOptions = f; })(l || (l = {}));
        var u = class extends o {
            static { s(this, "ReadableStreamMessageReader"); }
            constructor(c, f) { super(), this.readable = c, this.options = l.fromOptions(f), this.buffer = (0, t.default)().messageBuffer.create(this.options.charset), this._partialMessageTimeout = 1e4, this.nextMessageLength = -1, this.messageToken = 0, this.readSemaphore = new a.Semaphore(1); }
            set partialMessageTimeout(c) { this._partialMessageTimeout = c; }
            get partialMessageTimeout() { return this._partialMessageTimeout; }
            listen(c) { this.nextMessageLength = -1, this.messageToken = 0, this.partialMessageTimer = void 0, this.callback = c; let f = this.readable.onData(p => { this.onData(p); }); return this.readable.onError(p => this.fireError(p)), this.readable.onClose(() => this.fireClose()), f; }
            onData(c) {
                try {
                    for (this.buffer.append(c);;) {
                        if (this.nextMessageLength === -1) {
                            let p = this.buffer.tryReadHeaders(!0);
                            if (!p)
                                return;
                            let m = p.get("content-length");
                            if (!m) {
                                this.fireError(new Error(`Header must provide a Content-Length property.
${JSON.stringify(Object.fromEntries(p))}`));
                                return;
                            }
                            let g = parseInt(m);
                            if (isNaN(g)) {
                                this.fireError(new Error(`Content-Length value must be a number. Got ${m}`));
                                return;
                            }
                            this.nextMessageLength = g;
                        }
                        let f = this.buffer.tryReadBody(this.nextMessageLength);
                        if (f === void 0) {
                            this.setPartialMessageTimer();
                            return;
                        }
                        this.clearPartialMessageTimer(), this.nextMessageLength = -1, this.readSemaphore.lock(() => z(this, null, function* () { let p = this.options.contentDecoder !== void 0 ? yield this.options.contentDecoder.decode(f) : f, m = yield this.options.contentTypeDecoder.decode(p, this.options); this.callback(m); })).catch(p => { this.fireError(p); });
                    }
                }
                catch (f) {
                    this.fireError(f);
                }
            }
            clearPartialMessageTimer() { this.partialMessageTimer && (this.partialMessageTimer.dispose(), this.partialMessageTimer = void 0); }
            setPartialMessageTimer() { this.clearPartialMessageTimer(), !(this._partialMessageTimeout <= 0) && (this.partialMessageTimer = (0, t.default)().timer.setTimeout((c, f) => { this.partialMessageTimer = void 0, c === this.messageToken && (this.firePartialMessage({ messageToken: c, waitingTime: f }), this.setPartialMessageTimer()); }, this._partialMessageTimeout, this.messageToken, this._partialMessageTimeout)); }
        };
        e.ReadableStreamMessageReader = u;
    } }), zw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/messageWriter.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.WriteableStreamMessageWriter = e.AbstractMessageWriter = e.MessageWriter = void 0;
        var t = wn(), r = Ps(), n = Pg(), a = Ha(), i = "Content-Length: ", o = `\r
`, l;
        (function (p) { function m(g) { let v = g; return v && r.func(v.dispose) && r.func(v.onClose) && r.func(v.onError) && r.func(v.write); } s(m, "is"), p.is = m; })(l || (e.MessageWriter = l = {}));
        var u = class {
            static { s(this, "AbstractMessageWriter"); }
            constructor() { this.errorEmitter = new a.Emitter, this.closeEmitter = new a.Emitter; }
            dispose() { this.errorEmitter.dispose(), this.closeEmitter.dispose(); }
            get onError() { return this.errorEmitter.event; }
            fireError(p, m, g) { this.errorEmitter.fire([this.asError(p), m, g]); }
            get onClose() { return this.closeEmitter.event; }
            fireClose() { this.closeEmitter.fire(void 0); }
            asError(p) { return p instanceof Error ? p : new Error(`Writer received error. Reason: ${r.string(p.message) ? p.message : "unknown"}`); }
        };
        e.AbstractMessageWriter = u;
        var c;
        (function (p) { function m(g) { return g === void 0 || typeof g == "string" ? { charset: g ?? "utf-8", contentTypeEncoder: (0, t.default)().applicationJson.encoder } : { charset: g.charset ?? "utf-8", contentEncoder: g.contentEncoder, contentTypeEncoder: g.contentTypeEncoder ?? (0, t.default)().applicationJson.encoder }; } s(m, "fromOptions"), p.fromOptions = m; })(c || (c = {}));
        var f = class extends u {
            static { s(this, "WriteableStreamMessageWriter"); }
            constructor(p, m) { super(), this.writable = p, this.options = c.fromOptions(m), this.errorCount = 0, this.writeSemaphore = new n.Semaphore(1), this.writable.onError(g => this.fireError(g)), this.writable.onClose(() => this.fireClose()); }
            write(p) { return z(this, null, function* () { return this.writeSemaphore.lock(() => z(this, null, function* () { return this.options.contentTypeEncoder.encode(p, this.options).then(g => this.options.contentEncoder !== void 0 ? this.options.contentEncoder.encode(g) : g).then(g => { let v = []; return v.push(i, g.byteLength.toString(), o), v.push(o), this.doWrite(p, v, g); }, g => { throw this.fireError(g), g; }); })); }); }
            doWrite(p, m, g) { return z(this, null, function* () { try {
                return yield this.writable.write(m.join(""), "ascii"), this.writable.write(g);
            }
            catch (v) {
                return this.handleError(v, p), Promise.reject(v);
            } }); }
            handleError(p, m) { this.errorCount++, this.fireError(p, m, this.errorCount); }
            end() { this.writable.end(); }
        };
        e.WriteableStreamMessageWriter = f;
    } }), jw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/messageBuffer.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.AbstractMessageBuffer = void 0;
        var t = 13, r = 10, n = `\r
`, a = class {
            static { s(this, "AbstractMessageBuffer"); }
            constructor(i = "utf-8") { this._encoding = i, this._chunks = [], this._totalLength = 0; }
            get encoding() { return this._encoding; }
            append(i) { let o = typeof i == "string" ? this.fromString(i, this._encoding) : i; this._chunks.push(o), this._totalLength += o.byteLength; }
            tryReadHeaders(i = !1) {
                if (this._chunks.length === 0)
                    return;
                let o = 0, l = 0, u = 0, c = 0;
                e: for (; l < this._chunks.length;) {
                    let g = this._chunks[l];
                    for (u = 0; u < g.length;) {
                        switch (g[u]) {
                            case t:
                                switch (o) {
                                    case 0:
                                        o = 1;
                                        break;
                                    case 2:
                                        o = 3;
                                        break;
                                    default: o = 0;
                                }
                                break;
                            case r:
                                switch (o) {
                                    case 1:
                                        o = 2;
                                        break;
                                    case 3:
                                        o = 4, u++;
                                        break e;
                                    default: o = 0;
                                }
                                break;
                            default: o = 0;
                        }
                        u++;
                    }
                    c += g.byteLength, l++;
                }
                if (o !== 4)
                    return;
                let f = this._read(c + u), p = new Map, m = this.toString(f, "ascii").split(n);
                if (m.length < 2)
                    return p;
                for (let g = 0; g < m.length - 2; g++) {
                    let v = m[g], _ = v.indexOf(":");
                    if (_ === -1)
                        throw new Error(`Message header must separate key and value using ':'
${v}`);
                    let N = v.substr(0, _), w = v.substr(_ + 1).trim();
                    p.set(i ? N.toLowerCase() : N, w);
                }
                return p;
            }
            tryReadBody(i) { if (!(this._totalLength < i))
                return this._read(i); }
            get numberOfBytes() { return this._totalLength; }
            _read(i) { if (i === 0)
                return this.emptyBuffer(); if (i > this._totalLength)
                throw new Error("Cannot read so many bytes!"); if (this._chunks[0].byteLength === i) {
                let c = this._chunks[0];
                return this._chunks.shift(), this._totalLength -= i, this.asNative(c);
            } if (this._chunks[0].byteLength > i) {
                let c = this._chunks[0], f = this.asNative(c, i);
                return this._chunks[0] = c.slice(i), this._totalLength -= i, f;
            } let o = this.allocNative(i), l = 0, u = 0; for (; i > 0;) {
                let c = this._chunks[u];
                if (c.byteLength > i) {
                    let f = c.slice(0, i);
                    o.set(f, l), l += i, this._chunks[u] = c.slice(i), this._totalLength -= i, i -= i;
                }
                else
                    o.set(c, l), l += c.byteLength, this._chunks.shift(), this._totalLength -= c.byteLength, i -= c.byteLength;
            } return o; }
        };
        e.AbstractMessageBuffer = a;
    } }), Uw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/connection.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.createMessageConnection = e.ConnectionOptions = e.MessageStrategy = e.CancellationStrategy = e.CancellationSenderStrategy = e.CancellationReceiverStrategy = e.RequestCancellationReceiverStrategy = e.IdCancellationReceiverStrategy = e.ConnectionStrategy = e.ConnectionError = e.ConnectionErrors = e.LogTraceNotification = e.SetTraceNotification = e.TraceFormat = e.TraceValues = e.Trace = e.NullLogger = e.ProgressType = e.ProgressToken = void 0;
        var t = wn(), r = Ps(), n = wg(), a = Ng(), i = Ha(), o = kl(), l;
        (function (y) { y.type = new n.NotificationType("$/cancelRequest"); })(l || (l = {}));
        var u;
        (function (y) { function A(T) { return typeof T == "string" || typeof T == "number"; } s(A, "is"), y.is = A; })(u || (e.ProgressToken = u = {}));
        var c;
        (function (y) { y.type = new n.NotificationType("$/progress"); })(c || (c = {}));
        var f = class {
            static { s(this, "ProgressType"); }
            constructor() { }
        };
        e.ProgressType = f;
        var p;
        (function (y) { function A(T) { return r.func(T); } s(A, "is"), y.is = A; })(p || (p = {})), e.NullLogger = Object.freeze({ error: s(() => { }, "error"), warn: s(() => { }, "warn"), info: s(() => { }, "info"), log: s(() => { }, "log") });
        var m = (function (y) { return y[y.Off = 0] = "Off", y[y.Messages = 1] = "Messages", y[y.Compact = 2] = "Compact", y[y.Verbose = 3] = "Verbose", y; })(m || (e.Trace = m = {})), g = (function (y) { return y.Off = "off", y.Messages = "messages", y.Compact = "compact", y.Verbose = "verbose", y; })(g || (e.TraceValues = g = {}));
        (function (y) { function A($) { if (!r.string($))
            return y.Off; switch ($ = $.toLowerCase(), $) {
            case "off": return y.Off;
            case "messages": return y.Messages;
            case "compact": return y.Compact;
            case "verbose": return y.Verbose;
            default: return y.Off;
        } } s(A, "fromString"), y.fromString = A; function T($) { switch ($) {
            case y.Off: return "off";
            case y.Messages: return "messages";
            case y.Compact: return "compact";
            case y.Verbose: return "verbose";
            default: return "off";
        } } s(T, "toString"), y.toString = T; })(m || (e.Trace = m = {}));
        var v = (function (y) { return y.Text = "text", y.JSON = "json", y; })(v || (e.TraceFormat = v = {}));
        (function (y) { function A(T) { return r.string(T) ? (T = T.toLowerCase(), T === "json" ? y.JSON : y.Text) : y.Text; } s(A, "fromString"), y.fromString = A; })(v || (e.TraceFormat = v = {}));
        var _;
        (function (y) { y.type = new n.NotificationType("$/setTrace"); })(_ || (e.SetTraceNotification = _ = {}));
        var N;
        (function (y) { y.type = new n.NotificationType("$/logTrace"); })(N || (e.LogTraceNotification = N = {}));
        var w = (function (y) { return y[y.Closed = 1] = "Closed", y[y.Disposed = 2] = "Disposed", y[y.AlreadyListening = 3] = "AlreadyListening", y; })(w || (e.ConnectionErrors = w = {})), S = class kg extends Error {
            static { s(this, "ConnectionError"); }
            constructor(A, T) { super(T), this.code = A, Object.setPrototypeOf(this, kg.prototype); }
        };
        e.ConnectionError = S;
        var E;
        (function (y) { function A(T) { let $ = T; return $ && r.func($.cancelUndispatched); } s(A, "is"), y.is = A; })(E || (e.ConnectionStrategy = E = {}));
        var I;
        (function (y) { function A(T) { let $ = T; return $ && ($.kind === void 0 || $.kind === "id") && r.func($.createCancellationTokenSource) && ($.dispose === void 0 || r.func($.dispose)); } s(A, "is"), y.is = A; })(I || (e.IdCancellationReceiverStrategy = I = {}));
        var j;
        (function (y) { function A(T) { let $ = T; return $ && $.kind === "request" && r.func($.createCancellationTokenSource) && ($.dispose === void 0 || r.func($.dispose)); } s(A, "is"), y.is = A; })(j || (e.RequestCancellationReceiverStrategy = j = {}));
        var Q;
        (function (y) { y.Message = Object.freeze({ createCancellationTokenSource(T) { return new o.CancellationTokenSource; } }); function A(T) { return I.is(T) || j.is(T); } s(A, "is"), y.is = A; })(Q || (e.CancellationReceiverStrategy = Q = {}));
        var X;
        (function (y) { y.Message = Object.freeze({ sendCancellation(T, $) { return T.sendNotification(l.type, { id: $ }); }, cleanup(T) { } }); function A(T) { let $ = T; return $ && r.func($.sendCancellation) && r.func($.cleanup); } s(A, "is"), y.is = A; })(X || (e.CancellationSenderStrategy = X = {}));
        var fe;
        (function (y) { y.Message = Object.freeze({ receiver: Q.Message, sender: X.Message }); function A(T) { let $ = T; return $ && Q.is($.receiver) && X.is($.sender); } s(A, "is"), y.is = A; })(fe || (e.CancellationStrategy = fe = {}));
        var ye;
        (function (y) { function A(T) { let $ = T; return $ && r.func($.handleMessage); } s(A, "is"), y.is = A; })(ye || (e.MessageStrategy = ye = {}));
        var pe;
        (function (y) { function A(T) { let $ = T; return $ && (fe.is($.cancellationStrategy) || E.is($.connectionStrategy) || ye.is($.messageStrategy)); } s(A, "is"), y.is = A; })(pe || (e.ConnectionOptions = pe = {}));
        var k = (function (y) { return y[y.New = 1] = "New", y[y.Listening = 2] = "Listening", y[y.Closed = 3] = "Closed", y[y.Disposed = 4] = "Disposed", y; })(k || {});
        function b(y, A, T, $) {
            let C = T !== void 0 ? T : e.NullLogger, O = 0, x = 0, D = 0, U = "2.0", G, ue = new Map, q, se = new Map, Be = new Map, Ce, Ae = new a.LinkedMap, xe = new Map, Ke = new Set, Le = new Map, re = m.Off, ft = v.Text, _e, _t = k.New, Yn = new i.Emitter, ai = new i.Emitter, ii = new i.Emitter, si = new i.Emitter, oi = new i.Emitter, St = $ && $.cancellationStrategy ? $.cancellationStrategy : fe.Message;
            function Xn(h) { if (h === null)
                throw new Error("Can't send requests with id null since the response can't be correlated."); return "req-" + h.toString(); }
            s(Xn, "createRequestQueueKey");
            function li(h) { return h === null ? "res-unknown-" + (++D).toString() : "res-" + h.toString(); }
            s(li, "createResponseQueueKey");
            function ui() { return "not-" + (++x).toString(); }
            s(ui, "createNotificationQueueKey");
            function ci(h, P) { n.Message.isRequest(P) ? h.set(Xn(P.id), P) : n.Message.isResponse(P) ? h.set(li(P.id), P) : h.set(ui(), P); }
            s(ci, "addMessageToQueue");
            function fi(h) { }
            s(fi, "cancelUndispatched");
            function Jn() { return _t === k.Listening; }
            s(Jn, "isListening");
            function Zn() { return _t === k.Closed; }
            s(Zn, "isClosed");
            function Ft() { return _t === k.Disposed; }
            s(Ft, "isDisposed");
            function Qn() { (_t === k.New || _t === k.Listening) && (_t = k.Closed, ai.fire(void 0)); }
            s(Qn, "closeHandler");
            function pi(h) { Yn.fire([h, void 0, void 0]); }
            s(pi, "readErrorHandler");
            function di(h) { Yn.fire(h); }
            s(di, "writeErrorHandler"), y.onClose(Qn), y.onError(pi), A.onClose(Qn), A.onError(di);
            function ea() { Ce || Ae.size === 0 || (Ce = (0, t.default)().timer.setImmediate(() => { Ce = void 0, mi(); })); }
            s(ea, "triggerMessageQueue");
            function ta(h) { n.Message.isRequest(h) ? hi(h) : n.Message.isNotification(h) ? gi(h) : n.Message.isResponse(h) ? yi(h) : vi(h); }
            s(ta, "handleMessage");
            function mi() { if (Ae.size === 0)
                return; let h = Ae.shift(); try {
                let P = $?.messageStrategy;
                ye.is(P) ? P.handleMessage(h, ta) : ta(h);
            }
            finally {
                ea();
            } }
            s(mi, "processMessageQueue");
            let Js = s(h => { try {
                if (n.Message.isNotification(h) && h.method === l.type.method) {
                    let P = h.params.id, L = Xn(P), M = Ae.get(L);
                    if (n.Message.isRequest(M)) {
                        let ce = $?.connectionStrategy, Se = ce && ce.cancelUndispatched ? ce.cancelUndispatched(M, fi) : void 0;
                        if (Se && (Se.error !== void 0 || Se.result !== void 0)) {
                            Ae.delete(L), Le.delete(P), Se.id = M.id, Sr(Se, h.method, Date.now()), A.write(Se).catch(() => C.error("Sending response for canceled message failed."));
                            return;
                        }
                    }
                    let ge = Le.get(P);
                    if (ge !== void 0) {
                        ge.cancel(), qr(h);
                        return;
                    }
                    else
                        Ke.add(P);
                }
                ci(Ae, h);
            }
            finally {
                ea();
            } }, "callback");
            function hi(h) { if (Ft())
                return; function P(ee, Ee, oe) { let Me = { jsonrpc: U, id: h.id }; ee instanceof n.ResponseError ? Me.error = ee.toJson() : Me.result = ee === void 0 ? null : ee, Sr(Me, Ee, oe), A.write(Me).catch(() => C.error("Sending response failed.")); } s(P, "reply"); function L(ee, Ee, oe) { let Me = { jsonrpc: U, id: h.id, error: ee.toJson() }; Sr(Me, Ee, oe), A.write(Me).catch(() => C.error("Sending response failed.")); } s(L, "replyError"); function M(ee, Ee, oe) { ee === void 0 && (ee = null); let Me = { jsonrpc: U, id: h.id, result: ee }; Sr(Me, Ee, oe), A.write(Me).catch(() => C.error("Sending response failed.")); } s(M, "replySuccess"), Ri(h); let ge = ue.get(h.method), ce, Se; ge && (ce = ge.type, Se = ge.handler); let Ne = Date.now(); if (Se || G) {
                let ee = h.id ?? String(Date.now()), Ee = I.is(St.receiver) ? St.receiver.createCancellationTokenSource(ee) : St.receiver.createCancellationTokenSource(h);
                h.id !== null && Ke.has(h.id) && Ee.cancel(), h.id !== null && Le.set(ee, Ee);
                try {
                    let oe;
                    if (Se)
                        if (h.params === void 0) {
                            if (ce !== void 0 && ce.numberOfParams !== 0) {
                                L(new n.ResponseError(n.ErrorCodes.InvalidParams, `Request ${h.method} defines ${ce.numberOfParams} params but received none.`), h.method, Ne);
                                return;
                            }
                            oe = Se(Ee.token);
                        }
                        else if (Array.isArray(h.params)) {
                            if (ce !== void 0 && ce.parameterStructures === n.ParameterStructures.byName) {
                                L(new n.ResponseError(n.ErrorCodes.InvalidParams, `Request ${h.method} defines parameters by name but received parameters by position`), h.method, Ne);
                                return;
                            }
                            oe = Se(...h.params, Ee.token);
                        }
                        else {
                            if (ce !== void 0 && ce.parameterStructures === n.ParameterStructures.byPosition) {
                                L(new n.ResponseError(n.ErrorCodes.InvalidParams, `Request ${h.method} defines parameters by position but received parameters by name`), h.method, Ne);
                                return;
                            }
                            oe = Se(h.params, Ee.token);
                        }
                    else
                        G && (oe = G(h.method, h.params, Ee.token));
                    let Me = oe;
                    oe ? Me.then ? Me.then(Xe => { Le.delete(ee), P(Xe, h.method, Ne); }, Xe => { Le.delete(ee), Xe instanceof n.ResponseError ? L(Xe, h.method, Ne) : Xe && r.string(Xe.message) ? L(new n.ResponseError(n.ErrorCodes.InternalError, `Request ${h.method} failed with message: ${Xe.message}`), h.method, Ne) : L(new n.ResponseError(n.ErrorCodes.InternalError, `Request ${h.method} failed unexpectedly without providing any details.`), h.method, Ne); }) : (Le.delete(ee), P(oe, h.method, Ne)) : (Le.delete(ee), M(oe, h.method, Ne));
                }
                catch (oe) {
                    Le.delete(ee), oe instanceof n.ResponseError ? P(oe, h.method, Ne) : oe && r.string(oe.message) ? L(new n.ResponseError(n.ErrorCodes.InternalError, `Request ${h.method} failed with message: ${oe.message}`), h.method, Ne) : L(new n.ResponseError(n.ErrorCodes.InternalError, `Request ${h.method} failed unexpectedly without providing any details.`), h.method, Ne);
                }
            }
            else
                L(new n.ResponseError(n.ErrorCodes.MethodNotFound, `Unhandled method ${h.method}`), h.method, Ne); }
            s(hi, "handleRequest");
            function yi(h) {
                if (!Ft())
                    if (h.id === null)
                        h.error ? C.error(`Received response message without id: Error is: 
${JSON.stringify(h.error, void 0, 4)}`) : C.error("Received response message without id. No further error information provided.");
                    else {
                        let P = h.id, L = xe.get(P);
                        if (Ai(h, L), L !== void 0) {
                            xe.delete(P);
                            try {
                                if (h.error) {
                                    let M = h.error;
                                    L.reject(new n.ResponseError(M.code, M.message, M.data));
                                }
                                else if (h.result !== void 0)
                                    L.resolve(h.result);
                                else
                                    throw new Error("Should never happen.");
                            }
                            catch (M) {
                                M.message ? C.error(`Response handler '${L.method}' failed with message: ${M.message}`) : C.error(`Response handler '${L.method}' failed unexpectedly.`);
                            }
                        }
                    }
            }
            s(yi, "handleResponse");
            function gi(h) { if (Ft())
                return; let P, L; if (h.method === l.type.method) {
                let M = h.params.id;
                Ke.delete(M), qr(h);
                return;
            }
            else {
                let M = se.get(h.method);
                M && (L = M.handler, P = M.type);
            } if (L || q)
                try {
                    if (qr(h), L)
                        if (h.params === void 0)
                            P !== void 0 && P.numberOfParams !== 0 && P.parameterStructures !== n.ParameterStructures.byName && C.error(`Notification ${h.method} defines ${P.numberOfParams} params but received none.`), L();
                        else if (Array.isArray(h.params)) {
                            let M = h.params;
                            h.method === c.type.method && M.length === 2 && u.is(M[0]) ? L({ token: M[0], value: M[1] }) : (P !== void 0 && (P.parameterStructures === n.ParameterStructures.byName && C.error(`Notification ${h.method} defines parameters by name but received parameters by position`), P.numberOfParams !== h.params.length && C.error(`Notification ${h.method} defines ${P.numberOfParams} params but received ${M.length} arguments`)), L(...M));
                        }
                        else
                            P !== void 0 && P.parameterStructures === n.ParameterStructures.byPosition && C.error(`Notification ${h.method} defines parameters by position but received parameters by name`), L(h.params);
                    else
                        q && q(h.method, h.params);
                }
                catch (M) {
                    M.message ? C.error(`Notification handler '${h.method}' failed with message: ${M.message}`) : C.error(`Notification handler '${h.method}' failed unexpectedly.`);
                }
            else
                ii.fire(h); }
            s(gi, "handleNotification");
            function vi(h) {
                if (!h) {
                    C.error("Received empty message.");
                    return;
                }
                C.error(`Received message which is neither a response nor a notification message:
${JSON.stringify(h, null, 4)}`);
                let P = h;
                if (r.string(P.id) || r.number(P.id)) {
                    let L = P.id, M = xe.get(L);
                    M && M.reject(new Error("The received response has neither a result nor an error property."));
                }
            }
            s(vi, "handleInvalidMessage");
            function $t(h) { if (h != null)
                switch (re) {
                    case m.Verbose: return JSON.stringify(h, null, 4);
                    case m.Compact: return JSON.stringify(h);
                    default: return;
                } }
            s($t, "stringifyTrace");
            function Ti(h) {
                if (!(re === m.Off || !_e))
                    if (ft === v.Text) {
                        let P;
                        (re === m.Verbose || re === m.Compact) && h.params && (P = `Params: ${$t(h.params)}

`), _e.log(`Sending request '${h.method} - (${h.id})'.`, P);
                    }
                    else
                        zt("send-request", h);
            }
            s(Ti, "traceSendingRequest");
            function $i(h) {
                if (!(re === m.Off || !_e))
                    if (ft === v.Text) {
                        let P;
                        (re === m.Verbose || re === m.Compact) && (h.params ? P = `Params: ${$t(h.params)}

` : P = `No parameters provided.

`), _e.log(`Sending notification '${h.method}'.`, P);
                    }
                    else
                        zt("send-notification", h);
            }
            s($i, "traceSendingNotification");
            function Sr(h, P, L) {
                if (!(re === m.Off || !_e))
                    if (ft === v.Text) {
                        let M;
                        (re === m.Verbose || re === m.Compact) && (h.error && h.error.data ? M = `Error data: ${$t(h.error.data)}

` : h.result ? M = `Result: ${$t(h.result)}

` : h.error === void 0 && (M = `No result returned.

`)), _e.log(`Sending response '${P} - (${h.id})'. Processing request took ${Date.now() - L}ms`, M);
                    }
                    else
                        zt("send-response", h);
            }
            s(Sr, "traceSendingResponse");
            function Ri(h) {
                if (!(re === m.Off || !_e))
                    if (ft === v.Text) {
                        let P;
                        (re === m.Verbose || re === m.Compact) && h.params && (P = `Params: ${$t(h.params)}

`), _e.log(`Received request '${h.method} - (${h.id})'.`, P);
                    }
                    else
                        zt("receive-request", h);
            }
            s(Ri, "traceReceivedRequest");
            function qr(h) {
                if (!(re === m.Off || !_e || h.method === N.type.method))
                    if (ft === v.Text) {
                        let P;
                        (re === m.Verbose || re === m.Compact) && (h.params ? P = `Params: ${$t(h.params)}

` : P = `No parameters provided.

`), _e.log(`Received notification '${h.method}'.`, P);
                    }
                    else
                        zt("receive-notification", h);
            }
            s(qr, "traceReceivedNotification");
            function Ai(h, P) {
                if (!(re === m.Off || !_e))
                    if (ft === v.Text) {
                        let L;
                        if ((re === m.Verbose || re === m.Compact) && (h.error && h.error.data ? L = `Error data: ${$t(h.error.data)}

` : h.result ? L = `Result: ${$t(h.result)}

` : h.error === void 0 && (L = `No result returned.

`)), P) {
                            let M = h.error ? ` Request failed: ${h.error.message} (${h.error.code}).` : "";
                            _e.log(`Received response '${P.method} - (${h.id})' in ${Date.now() - P.timerStart}ms.${M}`, L);
                        }
                        else
                            _e.log(`Received response ${h.id} without active response promise.`, L);
                    }
                    else
                        zt("receive-response", h);
            }
            s(Ai, "traceReceivedResponse");
            function zt(h, P) { if (!_e || re === m.Off)
                return; let L = { isLSPMessage: !0, type: h, message: P, timestamp: Date.now() }; _e.log(L); }
            s(zt, "logLSPMessage");
            function rr() { if (Zn())
                throw new S(w.Closed, "Connection is closed."); if (Ft())
                throw new S(w.Disposed, "Connection is disposed."); }
            s(rr, "throwIfClosedOrDisposed");
            function Ei() { if (Jn())
                throw new S(w.AlreadyListening, "Connection is already listening"); }
            s(Ei, "throwIfListening");
            function bi() { if (!Jn())
                throw new Error("Call listen() first."); }
            s(bi, "throwIfNotListening");
            function nr(h) { return h === void 0 ? null : h; }
            s(nr, "undefinedToNull");
            function ra(h) { if (h !== null)
                return h; }
            s(ra, "nullToUndefined");
            function d(h) { return h != null && !Array.isArray(h) && typeof h == "object"; }
            s(d, "isNamedParam");
            function ne(h, P) { switch (h) {
                case n.ParameterStructures.auto: return d(P) ? ra(P) : [nr(P)];
                case n.ParameterStructures.byName:
                    if (!d(P))
                        throw new Error("Received parameters by name but param is not an object literal.");
                    return ra(P);
                case n.ParameterStructures.byPosition: return [nr(P)];
                default: throw new Error(`Unknown parameter structure ${h.toString()}`);
            } }
            s(ne, "computeSingleParam");
            function Re(h, P) { let L, M = h.numberOfParams; switch (M) {
                case 0:
                    L = void 0;
                    break;
                case 1:
                    L = ne(h.parameterStructures, P[0]);
                    break;
                default:
                    L = [];
                    for (let ge = 0; ge < P.length && ge < M; ge++)
                        L.push(nr(P[ge]));
                    if (P.length < M)
                        for (let ge = P.length; ge < M; ge++)
                            L.push(null);
                    break;
            } return L; }
            s(Re, "computeMessageParams");
            let H = { sendNotification: s((h, ...P) => { rr(); let L, M; if (r.string(h)) {
                    L = h;
                    let ce = P[0], Se = 0, Ne = n.ParameterStructures.auto;
                    n.ParameterStructures.is(ce) && (Se = 1, Ne = ce);
                    let ee = P.length, Ee = ee - Se;
                    switch (Ee) {
                        case 0:
                            M = void 0;
                            break;
                        case 1:
                            M = ne(Ne, P[Se]);
                            break;
                        default:
                            if (Ne === n.ParameterStructures.byName)
                                throw new Error(`Received ${Ee} parameters for 'by Name' notification parameter structure.`);
                            M = P.slice(Se, ee).map(oe => nr(oe));
                            break;
                    }
                }
                else {
                    let ce = P;
                    L = h.method, M = Re(h, ce);
                } let ge = { jsonrpc: U, method: L, params: M }; return $i(ge), A.write(ge).catch(ce => { throw C.error("Sending notification failed."), ce; }); }, "sendNotification"), onNotification: s((h, P) => { rr(); let L; return r.func(h) ? q = h : P && (r.string(h) ? (L = h, se.set(h, { type: void 0, handler: P })) : (L = h.method, se.set(h.method, { type: h, handler: P }))), { dispose: s(() => { L !== void 0 ? se.delete(L) : q = void 0; }, "dispose") }; }, "onNotification"), onProgress: s((h, P, L) => { if (Be.has(P))
                    throw new Error(`Progress handler for token ${P} already registered`); return Be.set(P, L), { dispose: s(() => { Be.delete(P); }, "dispose") }; }, "onProgress"), sendProgress: s((h, P, L) => H.sendNotification(c.type, { token: P, value: L }), "sendProgress"), onUnhandledProgress: si.event, sendRequest: s((h, ...P) => { rr(), bi(); let L, M, ge; if (r.string(h)) {
                    L = h;
                    let ee = P[0], Ee = P[P.length - 1], oe = 0, Me = n.ParameterStructures.auto;
                    n.ParameterStructures.is(ee) && (oe = 1, Me = ee);
                    let Xe = P.length;
                    o.CancellationToken.is(Ee) && (Xe = Xe - 1, ge = Ee);
                    let jt = Xe - oe;
                    switch (jt) {
                        case 0:
                            M = void 0;
                            break;
                        case 1:
                            M = ne(Me, P[oe]);
                            break;
                        default:
                            if (Me === n.ParameterStructures.byName)
                                throw new Error(`Received ${jt} parameters for 'by Name' request parameter structure.`);
                            M = P.slice(oe, Xe).map(Pw => nr(Pw));
                            break;
                    }
                }
                else {
                    let ee = P;
                    L = h.method, M = Re(h, ee);
                    let Ee = h.numberOfParams;
                    ge = o.CancellationToken.is(ee[Ee]) ? ee[Ee] : void 0;
                } let ce = O++, Se; ge && (Se = ge.onCancellationRequested(() => { let ee = St.sender.sendCancellation(H, ce); return ee === void 0 ? (C.log(`Received no promise from cancellation strategy when cancelling id ${ce}`), Promise.resolve()) : ee.catch(() => { C.log(`Sending cancellation messages for id ${ce} failed`); }); })); let Ne = { jsonrpc: U, id: ce, method: L, params: M }; return Ti(Ne), typeof St.sender.enableCancellation == "function" && St.sender.enableCancellation(Ne), new Promise((ee, Ee) => z(null, null, function* () { let oe = s(jt => { ee(jt), St.sender.cleanup(ce), Se?.dispose(); }, "resolveWithCleanup"), Me = s(jt => { Ee(jt), St.sender.cleanup(ce), Se?.dispose(); }, "rejectWithCleanup"), Xe = { method: L, timerStart: Date.now(), resolve: oe, reject: Me }; try {
                    yield A.write(Ne), xe.set(ce, Xe);
                }
                catch (jt) {
                    throw C.error("Sending request failed."), Xe.reject(new n.ResponseError(n.ErrorCodes.MessageWriteError, jt.message ? jt.message : "Unknown reason")), jt;
                } })); }, "sendRequest"), onRequest: s((h, P) => { rr(); let L = null; return p.is(h) ? (L = void 0, G = h) : r.string(h) ? (L = null, P !== void 0 && (L = h, ue.set(h, { handler: P, type: void 0 }))) : P !== void 0 && (L = h.method, ue.set(h.method, { type: h, handler: P })), { dispose: s(() => { L !== null && (L !== void 0 ? ue.delete(L) : G = void 0); }, "dispose") }; }, "onRequest"), hasPendingResponse: s(() => xe.size > 0, "hasPendingResponse"), trace: s((h, P, L) => z(null, null, function* () { let M = !1, ge = v.Text; L !== void 0 && (r.boolean(L) ? M = L : (M = L.sendNotification || !1, ge = L.traceFormat || v.Text)), re = h, ft = ge, re === m.Off ? _e = void 0 : _e = P, M && !Zn() && !Ft() && (yield H.sendNotification(_.type, { value: m.toString(h) })); }), "trace"), onError: Yn.event, onClose: ai.event, onUnhandledNotification: ii.event, onDispose: oi.event, end: s(() => { A.end(); }, "end"), dispose: s(() => { if (Ft())
                    return; _t = k.Disposed, oi.fire(void 0); let h = new n.ResponseError(n.ErrorCodes.PendingResponseRejected, "Pending response rejected since connection got disposed"); for (let P of xe.values())
                    P.reject(h); xe = new Map, Le = new Map, Ke = new Set, Ae = new a.LinkedMap, r.func(A.dispose) && A.dispose(), r.func(y.dispose) && y.dispose(); }, "dispose"), listen: s(() => { rr(), Ei(), _t = k.Listening, y.listen(Js); }, "listen"), inspect: s(() => { (0, t.default)().console.log("inspect"); }, "inspect") };
            return H.onNotification(N.type, h => { if (re === m.Off || !_e)
                return; let P = re === m.Verbose || re === m.Compact; _e.log(h.message, P ? h.verbose : void 0); }), H.onNotification(c.type, h => { let P = Be.get(h.token); P ? P(h.value) : si.fire(h); }), H;
        }
        s(b, "createMessageConnection"), e.createMessageConnection = b;
    } }), gf = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/common/api.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ProgressType = e.ProgressToken = e.createMessageConnection = e.NullLogger = e.ConnectionOptions = e.ConnectionStrategy = e.AbstractMessageBuffer = e.WriteableStreamMessageWriter = e.AbstractMessageWriter = e.MessageWriter = e.ReadableStreamMessageReader = e.AbstractMessageReader = e.MessageReader = e.SharedArrayReceiverStrategy = e.SharedArraySenderStrategy = e.CancellationToken = e.CancellationTokenSource = e.Emitter = e.Event = e.Disposable = e.LRUCache = e.Touch = e.LinkedMap = e.ParameterStructures = e.NotificationType9 = e.NotificationType8 = e.NotificationType7 = e.NotificationType6 = e.NotificationType5 = e.NotificationType4 = e.NotificationType3 = e.NotificationType2 = e.NotificationType1 = e.NotificationType0 = e.NotificationType = e.ErrorCodes = e.ResponseError = e.RequestType9 = e.RequestType8 = e.RequestType7 = e.RequestType6 = e.RequestType5 = e.RequestType4 = e.RequestType3 = e.RequestType2 = e.RequestType1 = e.RequestType0 = e.RequestType = e.Message = e.RAL = void 0, e.MessageStrategy = e.CancellationStrategy = e.CancellationSenderStrategy = e.CancellationReceiverStrategy = e.ConnectionError = e.ConnectionErrors = e.LogTraceNotification = e.SetTraceNotification = e.TraceFormat = e.TraceValues = e.Trace = void 0;
        var t = wg();
        Object.defineProperty(e, "Message", { enumerable: !0, get: s(function () { return t.Message; }, "get") }), Object.defineProperty(e, "RequestType", { enumerable: !0, get: s(function () { return t.RequestType; }, "get") }), Object.defineProperty(e, "RequestType0", { enumerable: !0, get: s(function () { return t.RequestType0; }, "get") }), Object.defineProperty(e, "RequestType1", { enumerable: !0, get: s(function () { return t.RequestType1; }, "get") }), Object.defineProperty(e, "RequestType2", { enumerable: !0, get: s(function () { return t.RequestType2; }, "get") }), Object.defineProperty(e, "RequestType3", { enumerable: !0, get: s(function () { return t.RequestType3; }, "get") }), Object.defineProperty(e, "RequestType4", { enumerable: !0, get: s(function () { return t.RequestType4; }, "get") }), Object.defineProperty(e, "RequestType5", { enumerable: !0, get: s(function () { return t.RequestType5; }, "get") }), Object.defineProperty(e, "RequestType6", { enumerable: !0, get: s(function () { return t.RequestType6; }, "get") }), Object.defineProperty(e, "RequestType7", { enumerable: !0, get: s(function () { return t.RequestType7; }, "get") }), Object.defineProperty(e, "RequestType8", { enumerable: !0, get: s(function () { return t.RequestType8; }, "get") }), Object.defineProperty(e, "RequestType9", { enumerable: !0, get: s(function () { return t.RequestType9; }, "get") }), Object.defineProperty(e, "ResponseError", { enumerable: !0, get: s(function () { return t.ResponseError; }, "get") }), Object.defineProperty(e, "ErrorCodes", { enumerable: !0, get: s(function () { return t.ErrorCodes; }, "get") }), Object.defineProperty(e, "NotificationType", { enumerable: !0, get: s(function () { return t.NotificationType; }, "get") }), Object.defineProperty(e, "NotificationType0", { enumerable: !0, get: s(function () { return t.NotificationType0; }, "get") }), Object.defineProperty(e, "NotificationType1", { enumerable: !0, get: s(function () { return t.NotificationType1; }, "get") }), Object.defineProperty(e, "NotificationType2", { enumerable: !0, get: s(function () { return t.NotificationType2; }, "get") }), Object.defineProperty(e, "NotificationType3", { enumerable: !0, get: s(function () { return t.NotificationType3; }, "get") }), Object.defineProperty(e, "NotificationType4", { enumerable: !0, get: s(function () { return t.NotificationType4; }, "get") }), Object.defineProperty(e, "NotificationType5", { enumerable: !0, get: s(function () { return t.NotificationType5; }, "get") }), Object.defineProperty(e, "NotificationType6", { enumerable: !0, get: s(function () { return t.NotificationType6; }, "get") }), Object.defineProperty(e, "NotificationType7", { enumerable: !0, get: s(function () { return t.NotificationType7; }, "get") }), Object.defineProperty(e, "NotificationType8", { enumerable: !0, get: s(function () { return t.NotificationType8; }, "get") }), Object.defineProperty(e, "NotificationType9", { enumerable: !0, get: s(function () { return t.NotificationType9; }, "get") }), Object.defineProperty(e, "ParameterStructures", { enumerable: !0, get: s(function () { return t.ParameterStructures; }, "get") });
        var r = Ng();
        Object.defineProperty(e, "LinkedMap", { enumerable: !0, get: s(function () { return r.LinkedMap; }, "get") }), Object.defineProperty(e, "LRUCache", { enumerable: !0, get: s(function () { return r.LRUCache; }, "get") }), Object.defineProperty(e, "Touch", { enumerable: !0, get: s(function () { return r.Touch; }, "get") });
        var n = Mw();
        Object.defineProperty(e, "Disposable", { enumerable: !0, get: s(function () { return n.Disposable; }, "get") });
        var a = Ha();
        Object.defineProperty(e, "Event", { enumerable: !0, get: s(function () { return a.Event; }, "get") }), Object.defineProperty(e, "Emitter", { enumerable: !0, get: s(function () { return a.Emitter; }, "get") });
        var i = kl();
        Object.defineProperty(e, "CancellationTokenSource", { enumerable: !0, get: s(function () { return i.CancellationTokenSource; }, "get") }), Object.defineProperty(e, "CancellationToken", { enumerable: !0, get: s(function () { return i.CancellationToken; }, "get") });
        var o = Gw();
        Object.defineProperty(e, "SharedArraySenderStrategy", { enumerable: !0, get: s(function () { return o.SharedArraySenderStrategy; }, "get") }), Object.defineProperty(e, "SharedArrayReceiverStrategy", { enumerable: !0, get: s(function () { return o.SharedArrayReceiverStrategy; }, "get") });
        var l = Fw();
        Object.defineProperty(e, "MessageReader", { enumerable: !0, get: s(function () { return l.MessageReader; }, "get") }), Object.defineProperty(e, "AbstractMessageReader", { enumerable: !0, get: s(function () { return l.AbstractMessageReader; }, "get") }), Object.defineProperty(e, "ReadableStreamMessageReader", { enumerable: !0, get: s(function () { return l.ReadableStreamMessageReader; }, "get") });
        var u = zw();
        Object.defineProperty(e, "MessageWriter", { enumerable: !0, get: s(function () { return u.MessageWriter; }, "get") }), Object.defineProperty(e, "AbstractMessageWriter", { enumerable: !0, get: s(function () { return u.AbstractMessageWriter; }, "get") }), Object.defineProperty(e, "WriteableStreamMessageWriter", { enumerable: !0, get: s(function () { return u.WriteableStreamMessageWriter; }, "get") });
        var c = jw();
        Object.defineProperty(e, "AbstractMessageBuffer", { enumerable: !0, get: s(function () { return c.AbstractMessageBuffer; }, "get") });
        var f = Uw();
        Object.defineProperty(e, "ConnectionStrategy", { enumerable: !0, get: s(function () { return f.ConnectionStrategy; }, "get") }), Object.defineProperty(e, "ConnectionOptions", { enumerable: !0, get: s(function () { return f.ConnectionOptions; }, "get") }), Object.defineProperty(e, "NullLogger", { enumerable: !0, get: s(function () { return f.NullLogger; }, "get") }), Object.defineProperty(e, "createMessageConnection", { enumerable: !0, get: s(function () { return f.createMessageConnection; }, "get") }), Object.defineProperty(e, "ProgressToken", { enumerable: !0, get: s(function () { return f.ProgressToken; }, "get") }), Object.defineProperty(e, "ProgressType", { enumerable: !0, get: s(function () { return f.ProgressType; }, "get") }), Object.defineProperty(e, "Trace", { enumerable: !0, get: s(function () { return f.Trace; }, "get") }), Object.defineProperty(e, "TraceValues", { enumerable: !0, get: s(function () { return f.TraceValues; }, "get") }), Object.defineProperty(e, "TraceFormat", { enumerable: !0, get: s(function () { return f.TraceFormat; }, "get") }), Object.defineProperty(e, "SetTraceNotification", { enumerable: !0, get: s(function () { return f.SetTraceNotification; }, "get") }), Object.defineProperty(e, "LogTraceNotification", { enumerable: !0, get: s(function () { return f.LogTraceNotification; }, "get") }), Object.defineProperty(e, "ConnectionErrors", { enumerable: !0, get: s(function () { return f.ConnectionErrors; }, "get") }), Object.defineProperty(e, "ConnectionError", { enumerable: !0, get: s(function () { return f.ConnectionError; }, "get") }), Object.defineProperty(e, "CancellationReceiverStrategy", { enumerable: !0, get: s(function () { return f.CancellationReceiverStrategy; }, "get") }), Object.defineProperty(e, "CancellationSenderStrategy", { enumerable: !0, get: s(function () { return f.CancellationSenderStrategy; }, "get") }), Object.defineProperty(e, "CancellationStrategy", { enumerable: !0, get: s(function () { return f.CancellationStrategy; }, "get") }), Object.defineProperty(e, "MessageStrategy", { enumerable: !0, get: s(function () { return f.MessageStrategy; }, "get") });
        var p = wn();
        e.RAL = p.default;
    } }), Bw = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/browser/ril.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 });
        var t = gf(), r = class Og extends t.AbstractMessageBuffer {
            static { s(this, "MessageBuffer"); }
            constructor(c = "utf-8") { super(c), this.asciiDecoder = new TextDecoder("ascii"); }
            emptyBuffer() { return Og.emptyBuffer; }
            fromString(c, f) { return new TextEncoder().encode(c); }
            toString(c, f) { return f === "ascii" ? this.asciiDecoder.decode(c) : new TextDecoder(f).decode(c); }
            asNative(c, f) { return f === void 0 ? c : c.slice(0, f); }
            allocNative(c) { return new Uint8Array(c); }
        };
        r.emptyBuffer = new Uint8Array(0);
        var n = class {
            static { s(this, "ReadableStreamWrapper"); }
            constructor(u) { this.socket = u, this._onData = new t.Emitter, this._messageListener = c => { c.data.arrayBuffer().then(p => { this._onData.fire(new Uint8Array(p)); }, () => { (0, t.RAL)().console.error("Converting blob to array buffer failed."); }); }, this.socket.addEventListener("message", this._messageListener); }
            onClose(u) { return this.socket.addEventListener("close", u), t.Disposable.create(() => this.socket.removeEventListener("close", u)); }
            onError(u) { return this.socket.addEventListener("error", u), t.Disposable.create(() => this.socket.removeEventListener("error", u)); }
            onEnd(u) { return this.socket.addEventListener("end", u), t.Disposable.create(() => this.socket.removeEventListener("end", u)); }
            onData(u) { return this._onData.event(u); }
        }, a = class {
            static { s(this, "WritableStreamWrapper"); }
            constructor(u) { this.socket = u; }
            onClose(u) { return this.socket.addEventListener("close", u), t.Disposable.create(() => this.socket.removeEventListener("close", u)); }
            onError(u) { return this.socket.addEventListener("error", u), t.Disposable.create(() => this.socket.removeEventListener("error", u)); }
            onEnd(u) { return this.socket.addEventListener("end", u), t.Disposable.create(() => this.socket.removeEventListener("end", u)); }
            write(u, c) { if (typeof u == "string") {
                if (c !== void 0 && c !== "utf-8")
                    throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${c}`);
                this.socket.send(u);
            }
            else
                this.socket.send(u); return Promise.resolve(); }
            end() { this.socket.close(); }
        }, i = new TextEncoder, o = Object.freeze({ messageBuffer: Object.freeze({ create: s(u => new r(u), "create") }), applicationJson: Object.freeze({ encoder: Object.freeze({ name: "application/json", encode: s((u, c) => { if (c.charset !== "utf-8")
                        throw new Error(`In a Browser environments only utf-8 text encoding is supported. But got encoding: ${c.charset}`); return Promise.resolve(i.encode(JSON.stringify(u, void 0, 0))); }, "encode") }), decoder: Object.freeze({ name: "application/json", decode: s((u, c) => { if (!(u instanceof Uint8Array))
                        throw new Error("In a Browser environments only Uint8Arrays are supported."); return Promise.resolve(JSON.parse(new TextDecoder(c.charset).decode(u))); }, "decode") }) }), stream: Object.freeze({ asReadableStream: s(u => new n(u), "asReadableStream"), asWritableStream: s(u => new a(u), "asWritableStream") }), console, timer: Object.freeze({ setTimeout(u, c, ...f) { let p = setTimeout(u, c, ...f); return { dispose: s(() => clearTimeout(p), "dispose") }; }, setImmediate(u, ...c) { let f = setTimeout(u, 0, ...c); return { dispose: s(() => clearTimeout(f), "dispose") }; }, setInterval(u, c, ...f) { let p = setInterval(u, c, ...f); return { dispose: s(() => clearInterval(p), "dispose") }; } }) });
        function l() { return o; }
        s(l, "RIL"), (function (u) { function c() { t.RAL.install(o); } s(c, "install"), u.install = c; })(l || (l = {})), e.default = l;
    } }), Ya = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/lib/browser/main.js"(e) {
        "use strict";
        var t = e && e.__createBinding || (Object.create ? function (u, c, f, p) { p === void 0 && (p = f); var m = Object.getOwnPropertyDescriptor(c, f); (!m || ("get" in m ? !c.__esModule : m.writable || m.configurable)) && (m = { enumerable: !0, get: s(function () { return c[f]; }, "get") }), Object.defineProperty(u, p, m); } : function (u, c, f, p) { p === void 0 && (p = f), u[p] = c[f]; }), r = e && e.__exportStar || function (u, c) { for (var f in u)
            f !== "default" && !Object.prototype.hasOwnProperty.call(c, f) && t(c, u, f); };
        Object.defineProperty(e, "__esModule", { value: !0 }), e.createMessageConnection = e.BrowserMessageWriter = e.BrowserMessageReader = void 0;
        var n = Bw();
        n.default.install();
        var a = gf();
        r(gf(), e);
        var i = class extends a.AbstractMessageReader {
            static { s(this, "BrowserMessageReader"); }
            constructor(u) { super(), this._onData = new a.Emitter, this._messageListener = c => { this._onData.fire(c.data); }, u.addEventListener("error", c => this.fireError(c)), u.onmessage = this._messageListener; }
            listen(u) { return this._onData.event(u); }
        };
        e.BrowserMessageReader = i;
        var o = class extends a.AbstractMessageWriter {
            static { s(this, "BrowserMessageWriter"); }
            constructor(u) { super(), this.port = u, this.errorCount = 0, u.addEventListener("error", c => this.fireError(c)); }
            write(u) { try {
                return this.port.postMessage(u), Promise.resolve();
            }
            catch (c) {
                return this.handleError(c, u), Promise.reject(c);
            } }
            handleError(u, c) { this.errorCount++, this.fireError(u, c, this.errorCount); }
            end() { }
        };
        e.BrowserMessageWriter = o;
        function l(u, c, f, p) { return f === void 0 && (f = a.NullLogger), a.ConnectionStrategy.is(p) && (p = { connectionStrategy: p }), (0, a.createMessageConnection)(u, c, f, p); }
        s(l, "createMessageConnection"), e.createMessageConnection = l;
    } }), rh = Y({ "../../node_modules/.pnpm/vscode-jsonrpc@8.2.0/node_modules/vscode-jsonrpc/browser.js"(e, t) {
        "use strict";
        t.exports = Ya();
    } }), be = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/messages.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ProtocolNotificationType = e.ProtocolNotificationType0 = e.ProtocolRequestType = e.ProtocolRequestType0 = e.RegistrationType = e.MessageDirection = void 0;
        var t = Ya(), r = (function (u) { return u.clientToServer = "clientToServer", u.serverToClient = "serverToClient", u.both = "both", u; })(r || (e.MessageDirection = r = {})), n = class {
            static { s(this, "RegistrationType"); }
            constructor(u) { this.method = u; }
        };
        e.RegistrationType = n;
        var a = class extends t.RequestType0 {
            static { s(this, "ProtocolRequestType0"); }
            constructor(u) { super(u); }
        };
        e.ProtocolRequestType0 = a;
        var i = class extends t.RequestType {
            static { s(this, "ProtocolRequestType"); }
            constructor(u) { super(u, t.ParameterStructures.byName); }
        };
        e.ProtocolRequestType = i;
        var o = class extends t.NotificationType0 {
            static { s(this, "ProtocolNotificationType0"); }
            constructor(u) { super(u); }
        };
        e.ProtocolNotificationType0 = o;
        var l = class extends t.NotificationType {
            static { s(this, "ProtocolNotificationType"); }
            constructor(u) { super(u, t.ParameterStructures.byName); }
        };
        e.ProtocolNotificationType = l;
    } }), vp = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/utils/is.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.objectLiteral = e.typedArray = e.stringArray = e.array = e.func = e.error = e.number = e.string = e.boolean = void 0;
        function t(f) { return f === !0 || f === !1; }
        s(t, "boolean"), e.boolean = t;
        function r(f) { return typeof f == "string" || f instanceof String; }
        s(r, "string"), e.string = r;
        function n(f) { return typeof f == "number" || f instanceof Number; }
        s(n, "number"), e.number = n;
        function a(f) { return f instanceof Error; }
        s(a, "error"), e.error = a;
        function i(f) { return typeof f == "function"; }
        s(i, "func"), e.func = i;
        function o(f) { return Array.isArray(f); }
        s(o, "array"), e.array = o;
        function l(f) { return o(f) && f.every(p => r(p)); }
        s(l, "stringArray"), e.stringArray = l;
        function u(f, p) { return Array.isArray(f) && f.every(p); }
        s(u, "typedArray"), e.typedArray = u;
        function c(f) { return f !== null && typeof f == "object"; }
        s(c, "objectLiteral"), e.objectLiteral = c;
    } }), Kw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.implementation.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ImplementationRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/implementation", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.ImplementationRequest = r = {}));
    } }), qw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.typeDefinition.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.TypeDefinitionRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/typeDefinition", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.TypeDefinitionRequest = r = {}));
    } }), Ww = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.workspaceFolder.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.DidChangeWorkspaceFoldersNotification = e.WorkspaceFoldersRequest = void 0;
        var t = be(), r;
        (function (a) { a.method = "workspace/workspaceFolders", a.messageDirection = t.MessageDirection.serverToClient, a.type = new t.ProtocolRequestType0(a.method); })(r || (e.WorkspaceFoldersRequest = r = {}));
        var n;
        (function (a) { a.method = "workspace/didChangeWorkspaceFolders", a.messageDirection = t.MessageDirection.clientToServer, a.type = new t.ProtocolNotificationType(a.method); })(n || (e.DidChangeWorkspaceFoldersNotification = n = {}));
    } }), Vw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.configuration.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ConfigurationRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "workspace/configuration", n.messageDirection = t.MessageDirection.serverToClient, n.type = new t.ProtocolRequestType(n.method); })(r || (e.ConfigurationRequest = r = {}));
    } }), Hw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.colorProvider.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ColorPresentationRequest = e.DocumentColorRequest = void 0;
        var t = be(), r;
        (function (a) { a.method = "textDocument/documentColor", a.messageDirection = t.MessageDirection.clientToServer, a.type = new t.ProtocolRequestType(a.method); })(r || (e.DocumentColorRequest = r = {}));
        var n;
        (function (a) { a.method = "textDocument/colorPresentation", a.messageDirection = t.MessageDirection.clientToServer, a.type = new t.ProtocolRequestType(a.method); })(n || (e.ColorPresentationRequest = n = {}));
    } }), Yw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.foldingRange.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.FoldingRangeRefreshRequest = e.FoldingRangeRequest = void 0;
        var t = be(), r;
        (function (a) { a.method = "textDocument/foldingRange", a.messageDirection = t.MessageDirection.clientToServer, a.type = new t.ProtocolRequestType(a.method); })(r || (e.FoldingRangeRequest = r = {}));
        var n;
        (function (a) { a.method = "workspace/foldingRange/refresh", a.messageDirection = t.MessageDirection.serverToClient, a.type = new t.ProtocolRequestType0(a.method); })(n || (e.FoldingRangeRefreshRequest = n = {}));
    } }), Xw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.declaration.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.DeclarationRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/declaration", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.DeclarationRequest = r = {}));
    } }), Jw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.selectionRange.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.SelectionRangeRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/selectionRange", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.SelectionRangeRequest = r = {}));
    } }), Zw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.progress.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.WorkDoneProgressCancelNotification = e.WorkDoneProgressCreateRequest = e.WorkDoneProgress = void 0;
        var t = Ya(), r = be(), n;
        (function (o) { o.type = new t.ProgressType; function l(u) { return u === o.type; } s(l, "is"), o.is = l; })(n || (e.WorkDoneProgress = n = {}));
        var a;
        (function (o) { o.method = "window/workDoneProgress/create", o.messageDirection = r.MessageDirection.serverToClient, o.type = new r.ProtocolRequestType(o.method); })(a || (e.WorkDoneProgressCreateRequest = a = {}));
        var i;
        (function (o) { o.method = "window/workDoneProgress/cancel", o.messageDirection = r.MessageDirection.clientToServer, o.type = new r.ProtocolNotificationType(o.method); })(i || (e.WorkDoneProgressCancelNotification = i = {}));
    } }), Qw = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.callHierarchy.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.CallHierarchyOutgoingCallsRequest = e.CallHierarchyIncomingCallsRequest = e.CallHierarchyPrepareRequest = void 0;
        var t = be(), r;
        (function (i) { i.method = "textDocument/prepareCallHierarchy", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(r || (e.CallHierarchyPrepareRequest = r = {}));
        var n;
        (function (i) { i.method = "callHierarchy/incomingCalls", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(n || (e.CallHierarchyIncomingCallsRequest = n = {}));
        var a;
        (function (i) { i.method = "callHierarchy/outgoingCalls", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(a || (e.CallHierarchyOutgoingCallsRequest = a = {}));
    } }), eI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.semanticTokens.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.SemanticTokensRefreshRequest = e.SemanticTokensRangeRequest = e.SemanticTokensDeltaRequest = e.SemanticTokensRequest = e.SemanticTokensRegistrationType = e.TokenFormat = void 0;
        var t = be(), r = (function (u) { return u.Relative = "relative", u; })(r || (e.TokenFormat = r = {})), n;
        (function (u) { u.method = "textDocument/semanticTokens", u.type = new t.RegistrationType(u.method); })(n || (e.SemanticTokensRegistrationType = n = {}));
        var a;
        (function (u) { u.method = "textDocument/semanticTokens/full", u.messageDirection = t.MessageDirection.clientToServer, u.type = new t.ProtocolRequestType(u.method), u.registrationMethod = n.method; })(a || (e.SemanticTokensRequest = a = {}));
        var i;
        (function (u) { u.method = "textDocument/semanticTokens/full/delta", u.messageDirection = t.MessageDirection.clientToServer, u.type = new t.ProtocolRequestType(u.method), u.registrationMethod = n.method; })(i || (e.SemanticTokensDeltaRequest = i = {}));
        var o;
        (function (u) { u.method = "textDocument/semanticTokens/range", u.messageDirection = t.MessageDirection.clientToServer, u.type = new t.ProtocolRequestType(u.method), u.registrationMethod = n.method; })(o || (e.SemanticTokensRangeRequest = o = {}));
        var l;
        (function (u) { u.method = "workspace/semanticTokens/refresh", u.messageDirection = t.MessageDirection.serverToClient, u.type = new t.ProtocolRequestType0(u.method); })(l || (e.SemanticTokensRefreshRequest = l = {}));
    } }), tI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.showDocument.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.ShowDocumentRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "window/showDocument", n.messageDirection = t.MessageDirection.serverToClient, n.type = new t.ProtocolRequestType(n.method); })(r || (e.ShowDocumentRequest = r = {}));
    } }), rI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.linkedEditingRange.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.LinkedEditingRangeRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/linkedEditingRange", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.LinkedEditingRangeRequest = r = {}));
    } }), nI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.fileOperations.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.WillDeleteFilesRequest = e.DidDeleteFilesNotification = e.DidRenameFilesNotification = e.WillRenameFilesRequest = e.DidCreateFilesNotification = e.WillCreateFilesRequest = e.FileOperationPatternKind = void 0;
        var t = be(), r = (function (c) { return c.file = "file", c.folder = "folder", c; })(r || (e.FileOperationPatternKind = r = {})), n;
        (function (c) { c.method = "workspace/willCreateFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method); })(n || (e.WillCreateFilesRequest = n = {}));
        var a;
        (function (c) { c.method = "workspace/didCreateFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method); })(a || (e.DidCreateFilesNotification = a = {}));
        var i;
        (function (c) { c.method = "workspace/willRenameFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method); })(i || (e.WillRenameFilesRequest = i = {}));
        var o;
        (function (c) { c.method = "workspace/didRenameFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method); })(o || (e.DidRenameFilesNotification = o = {}));
        var l;
        (function (c) { c.method = "workspace/didDeleteFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolNotificationType(c.method); })(l || (e.DidDeleteFilesNotification = l = {}));
        var u;
        (function (c) { c.method = "workspace/willDeleteFiles", c.messageDirection = t.MessageDirection.clientToServer, c.type = new t.ProtocolRequestType(c.method); })(u || (e.WillDeleteFilesRequest = u = {}));
    } }), aI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.moniker.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.MonikerRequest = e.MonikerKind = e.UniquenessLevel = void 0;
        var t = be(), r = (function (i) { return i.document = "document", i.project = "project", i.group = "group", i.scheme = "scheme", i.global = "global", i; })(r || (e.UniquenessLevel = r = {})), n = (function (i) { return i.$import = "import", i.$export = "export", i.local = "local", i; })(n || (e.MonikerKind = n = {})), a;
        (function (i) { i.method = "textDocument/moniker", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(a || (e.MonikerRequest = a = {}));
    } }), iI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.typeHierarchy.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.TypeHierarchySubtypesRequest = e.TypeHierarchySupertypesRequest = e.TypeHierarchyPrepareRequest = void 0;
        var t = be(), r;
        (function (i) { i.method = "textDocument/prepareTypeHierarchy", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(r || (e.TypeHierarchyPrepareRequest = r = {}));
        var n;
        (function (i) { i.method = "typeHierarchy/supertypes", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(n || (e.TypeHierarchySupertypesRequest = n = {}));
        var a;
        (function (i) { i.method = "typeHierarchy/subtypes", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(a || (e.TypeHierarchySubtypesRequest = a = {}));
    } }), sI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.inlineValue.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.InlineValueRefreshRequest = e.InlineValueRequest = void 0;
        var t = be(), r;
        (function (a) { a.method = "textDocument/inlineValue", a.messageDirection = t.MessageDirection.clientToServer, a.type = new t.ProtocolRequestType(a.method); })(r || (e.InlineValueRequest = r = {}));
        var n;
        (function (a) { a.method = "workspace/inlineValue/refresh", a.messageDirection = t.MessageDirection.serverToClient, a.type = new t.ProtocolRequestType0(a.method); })(n || (e.InlineValueRefreshRequest = n = {}));
    } }), oI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.inlayHint.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.InlayHintRefreshRequest = e.InlayHintResolveRequest = e.InlayHintRequest = void 0;
        var t = be(), r;
        (function (i) { i.method = "textDocument/inlayHint", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(r || (e.InlayHintRequest = r = {}));
        var n;
        (function (i) { i.method = "inlayHint/resolve", i.messageDirection = t.MessageDirection.clientToServer, i.type = new t.ProtocolRequestType(i.method); })(n || (e.InlayHintResolveRequest = n = {}));
        var a;
        (function (i) { i.method = "workspace/inlayHint/refresh", i.messageDirection = t.MessageDirection.serverToClient, i.type = new t.ProtocolRequestType0(i.method); })(a || (e.InlayHintRefreshRequest = a = {}));
    } }), lI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.diagnostic.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.DiagnosticRefreshRequest = e.WorkspaceDiagnosticRequest = e.DocumentDiagnosticRequest = e.DocumentDiagnosticReportKind = e.DiagnosticServerCancellationData = void 0;
        var t = Ya(), r = vp(), n = be(), a;
        (function (c) { function f(p) { let m = p; return m && r.boolean(m.retriggerRequest); } s(f, "is"), c.is = f; })(a || (e.DiagnosticServerCancellationData = a = {}));
        var i = (function (c) { return c.Full = "full", c.Unchanged = "unchanged", c; })(i || (e.DocumentDiagnosticReportKind = i = {})), o;
        (function (c) { c.method = "textDocument/diagnostic", c.messageDirection = n.MessageDirection.clientToServer, c.type = new n.ProtocolRequestType(c.method), c.partialResult = new t.ProgressType; })(o || (e.DocumentDiagnosticRequest = o = {}));
        var l;
        (function (c) { c.method = "workspace/diagnostic", c.messageDirection = n.MessageDirection.clientToServer, c.type = new n.ProtocolRequestType(c.method), c.partialResult = new t.ProgressType; })(l || (e.WorkspaceDiagnosticRequest = l = {}));
        var u;
        (function (c) { c.method = "workspace/diagnostic/refresh", c.messageDirection = n.MessageDirection.serverToClient, c.type = new n.ProtocolRequestType0(c.method); })(u || (e.DiagnosticRefreshRequest = u = {}));
    } }), uI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.notebook.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.DidCloseNotebookDocumentNotification = e.DidSaveNotebookDocumentNotification = e.DidChangeNotebookDocumentNotification = e.NotebookCellArrayChange = e.DidOpenNotebookDocumentNotification = e.NotebookDocumentSyncRegistrationType = e.NotebookDocument = e.NotebookCell = e.ExecutionSummary = e.NotebookCellKind = void 0;
        var t = (Ns(), gp(Pl)), r = vp(), n = be(), a;
        (function (v) { v.Markup = 1, v.Code = 2; function _(N) { return N === 1 || N === 2; } s(_, "is"), v.is = _; })(a || (e.NotebookCellKind = a = {}));
        var i;
        (function (v) { function _(S, E) { let I = { executionOrder: S }; return (E === !0 || E === !1) && (I.success = E), I; } s(_, "create"), v.create = _; function N(S) { let E = S; return r.objectLiteral(E) && t.uinteger.is(E.executionOrder) && (E.success === void 0 || r.boolean(E.success)); } s(N, "is"), v.is = N; function w(S, E) { return S === E ? !0 : S == null || E === null || E === void 0 ? !1 : S.executionOrder === E.executionOrder && S.success === E.success; } s(w, "equals"), v.equals = w; })(i || (e.ExecutionSummary = i = {}));
        var o;
        (function (v) { function _(E, I) { return { kind: E, document: I }; } s(_, "create"), v.create = _; function N(E) { let I = E; return r.objectLiteral(I) && a.is(I.kind) && t.DocumentUri.is(I.document) && (I.metadata === void 0 || r.objectLiteral(I.metadata)); } s(N, "is"), v.is = N; function w(E, I) { let j = new Set; return E.document !== I.document && j.add("document"), E.kind !== I.kind && j.add("kind"), E.executionSummary !== I.executionSummary && j.add("executionSummary"), (E.metadata !== void 0 || I.metadata !== void 0) && !S(E.metadata, I.metadata) && j.add("metadata"), (E.executionSummary !== void 0 || I.executionSummary !== void 0) && !i.equals(E.executionSummary, I.executionSummary) && j.add("executionSummary"), j; } s(w, "diff"), v.diff = w; function S(E, I) { if (E === I)
            return !0; if (E == null || I === null || I === void 0 || typeof E != typeof I || typeof E != "object")
            return !1; let j = Array.isArray(E), Q = Array.isArray(I); if (j !== Q)
            return !1; if (j && Q) {
            if (E.length !== I.length)
                return !1;
            for (let X = 0; X < E.length; X++)
                if (!S(E[X], I[X]))
                    return !1;
        } if (r.objectLiteral(E) && r.objectLiteral(I)) {
            let X = Object.keys(E), fe = Object.keys(I);
            if (X.length !== fe.length || (X.sort(), fe.sort(), !S(X, fe)))
                return !1;
            for (let ye = 0; ye < X.length; ye++) {
                let pe = X[ye];
                if (!S(E[pe], I[pe]))
                    return !1;
            }
        } return !0; } s(S, "equalsMetadata"); })(o || (e.NotebookCell = o = {}));
        var l;
        (function (v) { function _(w, S, E, I) { return { uri: w, notebookType: S, version: E, cells: I }; } s(_, "create"), v.create = _; function N(w) { let S = w; return r.objectLiteral(S) && r.string(S.uri) && t.integer.is(S.version) && r.typedArray(S.cells, o.is); } s(N, "is"), v.is = N; })(l || (e.NotebookDocument = l = {}));
        var u;
        (function (v) { v.method = "notebookDocument/sync", v.messageDirection = n.MessageDirection.clientToServer, v.type = new n.RegistrationType(v.method); })(u || (e.NotebookDocumentSyncRegistrationType = u = {}));
        var c;
        (function (v) { v.method = "notebookDocument/didOpen", v.messageDirection = n.MessageDirection.clientToServer, v.type = new n.ProtocolNotificationType(v.method), v.registrationMethod = u.method; })(c || (e.DidOpenNotebookDocumentNotification = c = {}));
        var f;
        (function (v) { function _(w) { let S = w; return r.objectLiteral(S) && t.uinteger.is(S.start) && t.uinteger.is(S.deleteCount) && (S.cells === void 0 || r.typedArray(S.cells, o.is)); } s(_, "is"), v.is = _; function N(w, S, E) { let I = { start: w, deleteCount: S }; return E !== void 0 && (I.cells = E), I; } s(N, "create"), v.create = N; })(f || (e.NotebookCellArrayChange = f = {}));
        var p;
        (function (v) { v.method = "notebookDocument/didChange", v.messageDirection = n.MessageDirection.clientToServer, v.type = new n.ProtocolNotificationType(v.method), v.registrationMethod = u.method; })(p || (e.DidChangeNotebookDocumentNotification = p = {}));
        var m;
        (function (v) { v.method = "notebookDocument/didSave", v.messageDirection = n.MessageDirection.clientToServer, v.type = new n.ProtocolNotificationType(v.method), v.registrationMethod = u.method; })(m || (e.DidSaveNotebookDocumentNotification = m = {}));
        var g;
        (function (v) { v.method = "notebookDocument/didClose", v.messageDirection = n.MessageDirection.clientToServer, v.type = new n.ProtocolNotificationType(v.method), v.registrationMethod = u.method; })(g || (e.DidCloseNotebookDocumentNotification = g = {}));
    } }), cI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.inlineCompletion.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.InlineCompletionRequest = void 0;
        var t = be(), r;
        (function (n) { n.method = "textDocument/inlineCompletion", n.messageDirection = t.MessageDirection.clientToServer, n.type = new t.ProtocolRequestType(n.method); })(r || (e.InlineCompletionRequest = r = {}));
    } }), fI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/protocol.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.WorkspaceSymbolRequest = e.CodeActionResolveRequest = e.CodeActionRequest = e.DocumentSymbolRequest = e.DocumentHighlightRequest = e.ReferencesRequest = e.DefinitionRequest = e.SignatureHelpRequest = e.SignatureHelpTriggerKind = e.HoverRequest = e.CompletionResolveRequest = e.CompletionRequest = e.CompletionTriggerKind = e.PublishDiagnosticsNotification = e.WatchKind = e.RelativePattern = e.FileChangeType = e.DidChangeWatchedFilesNotification = e.WillSaveTextDocumentWaitUntilRequest = e.WillSaveTextDocumentNotification = e.TextDocumentSaveReason = e.DidSaveTextDocumentNotification = e.DidCloseTextDocumentNotification = e.DidChangeTextDocumentNotification = e.TextDocumentContentChangeEvent = e.DidOpenTextDocumentNotification = e.TextDocumentSyncKind = e.TelemetryEventNotification = e.LogMessageNotification = e.ShowMessageRequest = e.ShowMessageNotification = e.MessageType = e.DidChangeConfigurationNotification = e.ExitNotification = e.ShutdownRequest = e.InitializedNotification = e.InitializeErrorCodes = e.InitializeRequest = e.WorkDoneProgressOptions = e.TextDocumentRegistrationOptions = e.StaticRegistrationOptions = e.PositionEncodingKind = e.FailureHandlingKind = e.ResourceOperationKind = e.UnregistrationRequest = e.RegistrationRequest = e.DocumentSelector = e.NotebookCellTextDocumentFilter = e.NotebookDocumentFilter = e.TextDocumentFilter = void 0, e.MonikerRequest = e.MonikerKind = e.UniquenessLevel = e.WillDeleteFilesRequest = e.DidDeleteFilesNotification = e.WillRenameFilesRequest = e.DidRenameFilesNotification = e.WillCreateFilesRequest = e.DidCreateFilesNotification = e.FileOperationPatternKind = e.LinkedEditingRangeRequest = e.ShowDocumentRequest = e.SemanticTokensRegistrationType = e.SemanticTokensRefreshRequest = e.SemanticTokensRangeRequest = e.SemanticTokensDeltaRequest = e.SemanticTokensRequest = e.TokenFormat = e.CallHierarchyPrepareRequest = e.CallHierarchyOutgoingCallsRequest = e.CallHierarchyIncomingCallsRequest = e.WorkDoneProgressCancelNotification = e.WorkDoneProgressCreateRequest = e.WorkDoneProgress = e.SelectionRangeRequest = e.DeclarationRequest = e.FoldingRangeRefreshRequest = e.FoldingRangeRequest = e.ColorPresentationRequest = e.DocumentColorRequest = e.ConfigurationRequest = e.DidChangeWorkspaceFoldersNotification = e.WorkspaceFoldersRequest = e.TypeDefinitionRequest = e.ImplementationRequest = e.ApplyWorkspaceEditRequest = e.ExecuteCommandRequest = e.PrepareRenameRequest = e.RenameRequest = e.PrepareSupportDefaultBehavior = e.DocumentOnTypeFormattingRequest = e.DocumentRangesFormattingRequest = e.DocumentRangeFormattingRequest = e.DocumentFormattingRequest = e.DocumentLinkResolveRequest = e.DocumentLinkRequest = e.CodeLensRefreshRequest = e.CodeLensResolveRequest = e.CodeLensRequest = e.WorkspaceSymbolResolveRequest = void 0, e.InlineCompletionRequest = e.DidCloseNotebookDocumentNotification = e.DidSaveNotebookDocumentNotification = e.DidChangeNotebookDocumentNotification = e.NotebookCellArrayChange = e.DidOpenNotebookDocumentNotification = e.NotebookDocumentSyncRegistrationType = e.NotebookDocument = e.NotebookCell = e.ExecutionSummary = e.NotebookCellKind = e.DiagnosticRefreshRequest = e.WorkspaceDiagnosticRequest = e.DocumentDiagnosticRequest = e.DocumentDiagnosticReportKind = e.DiagnosticServerCancellationData = e.InlayHintRefreshRequest = e.InlayHintResolveRequest = e.InlayHintRequest = e.InlineValueRefreshRequest = e.InlineValueRequest = e.TypeHierarchySupertypesRequest = e.TypeHierarchySubtypesRequest = e.TypeHierarchyPrepareRequest = void 0;
        var t = be(), r = (Ns(), gp(Pl)), n = vp(), a = Kw();
        Object.defineProperty(e, "ImplementationRequest", { enumerable: !0, get: s(function () { return a.ImplementationRequest; }, "get") });
        var i = qw();
        Object.defineProperty(e, "TypeDefinitionRequest", { enumerable: !0, get: s(function () { return i.TypeDefinitionRequest; }, "get") });
        var o = Ww();
        Object.defineProperty(e, "WorkspaceFoldersRequest", { enumerable: !0, get: s(function () { return o.WorkspaceFoldersRequest; }, "get") }), Object.defineProperty(e, "DidChangeWorkspaceFoldersNotification", { enumerable: !0, get: s(function () { return o.DidChangeWorkspaceFoldersNotification; }, "get") });
        var l = Vw();
        Object.defineProperty(e, "ConfigurationRequest", { enumerable: !0, get: s(function () { return l.ConfigurationRequest; }, "get") });
        var u = Hw();
        Object.defineProperty(e, "DocumentColorRequest", { enumerable: !0, get: s(function () { return u.DocumentColorRequest; }, "get") }), Object.defineProperty(e, "ColorPresentationRequest", { enumerable: !0, get: s(function () { return u.ColorPresentationRequest; }, "get") });
        var c = Yw();
        Object.defineProperty(e, "FoldingRangeRequest", { enumerable: !0, get: s(function () { return c.FoldingRangeRequest; }, "get") }), Object.defineProperty(e, "FoldingRangeRefreshRequest", { enumerable: !0, get: s(function () { return c.FoldingRangeRefreshRequest; }, "get") });
        var f = Xw();
        Object.defineProperty(e, "DeclarationRequest", { enumerable: !0, get: s(function () { return f.DeclarationRequest; }, "get") });
        var p = Jw();
        Object.defineProperty(e, "SelectionRangeRequest", { enumerable: !0, get: s(function () { return p.SelectionRangeRequest; }, "get") });
        var m = Zw();
        Object.defineProperty(e, "WorkDoneProgress", { enumerable: !0, get: s(function () { return m.WorkDoneProgress; }, "get") }), Object.defineProperty(e, "WorkDoneProgressCreateRequest", { enumerable: !0, get: s(function () { return m.WorkDoneProgressCreateRequest; }, "get") }), Object.defineProperty(e, "WorkDoneProgressCancelNotification", { enumerable: !0, get: s(function () { return m.WorkDoneProgressCancelNotification; }, "get") });
        var g = Qw();
        Object.defineProperty(e, "CallHierarchyIncomingCallsRequest", { enumerable: !0, get: s(function () { return g.CallHierarchyIncomingCallsRequest; }, "get") }), Object.defineProperty(e, "CallHierarchyOutgoingCallsRequest", { enumerable: !0, get: s(function () { return g.CallHierarchyOutgoingCallsRequest; }, "get") }), Object.defineProperty(e, "CallHierarchyPrepareRequest", { enumerable: !0, get: s(function () { return g.CallHierarchyPrepareRequest; }, "get") });
        var v = eI();
        Object.defineProperty(e, "TokenFormat", { enumerable: !0, get: s(function () { return v.TokenFormat; }, "get") }), Object.defineProperty(e, "SemanticTokensRequest", { enumerable: !0, get: s(function () { return v.SemanticTokensRequest; }, "get") }), Object.defineProperty(e, "SemanticTokensDeltaRequest", { enumerable: !0, get: s(function () { return v.SemanticTokensDeltaRequest; }, "get") }), Object.defineProperty(e, "SemanticTokensRangeRequest", { enumerable: !0, get: s(function () { return v.SemanticTokensRangeRequest; }, "get") }), Object.defineProperty(e, "SemanticTokensRefreshRequest", { enumerable: !0, get: s(function () { return v.SemanticTokensRefreshRequest; }, "get") }), Object.defineProperty(e, "SemanticTokensRegistrationType", { enumerable: !0, get: s(function () { return v.SemanticTokensRegistrationType; }, "get") });
        var _ = tI();
        Object.defineProperty(e, "ShowDocumentRequest", { enumerable: !0, get: s(function () { return _.ShowDocumentRequest; }, "get") });
        var N = rI();
        Object.defineProperty(e, "LinkedEditingRangeRequest", { enumerable: !0, get: s(function () { return N.LinkedEditingRangeRequest; }, "get") });
        var w = nI();
        Object.defineProperty(e, "FileOperationPatternKind", { enumerable: !0, get: s(function () { return w.FileOperationPatternKind; }, "get") }), Object.defineProperty(e, "DidCreateFilesNotification", { enumerable: !0, get: s(function () { return w.DidCreateFilesNotification; }, "get") }), Object.defineProperty(e, "WillCreateFilesRequest", { enumerable: !0, get: s(function () { return w.WillCreateFilesRequest; }, "get") }), Object.defineProperty(e, "DidRenameFilesNotification", { enumerable: !0, get: s(function () { return w.DidRenameFilesNotification; }, "get") }), Object.defineProperty(e, "WillRenameFilesRequest", { enumerable: !0, get: s(function () { return w.WillRenameFilesRequest; }, "get") }), Object.defineProperty(e, "DidDeleteFilesNotification", { enumerable: !0, get: s(function () { return w.DidDeleteFilesNotification; }, "get") }), Object.defineProperty(e, "WillDeleteFilesRequest", { enumerable: !0, get: s(function () { return w.WillDeleteFilesRequest; }, "get") });
        var S = aI();
        Object.defineProperty(e, "UniquenessLevel", { enumerable: !0, get: s(function () { return S.UniquenessLevel; }, "get") }), Object.defineProperty(e, "MonikerKind", { enumerable: !0, get: s(function () { return S.MonikerKind; }, "get") }), Object.defineProperty(e, "MonikerRequest", { enumerable: !0, get: s(function () { return S.MonikerRequest; }, "get") });
        var E = iI();
        Object.defineProperty(e, "TypeHierarchyPrepareRequest", { enumerable: !0, get: s(function () { return E.TypeHierarchyPrepareRequest; }, "get") }), Object.defineProperty(e, "TypeHierarchySubtypesRequest", { enumerable: !0, get: s(function () { return E.TypeHierarchySubtypesRequest; }, "get") }), Object.defineProperty(e, "TypeHierarchySupertypesRequest", { enumerable: !0, get: s(function () { return E.TypeHierarchySupertypesRequest; }, "get") });
        var I = sI();
        Object.defineProperty(e, "InlineValueRequest", { enumerable: !0, get: s(function () { return I.InlineValueRequest; }, "get") }), Object.defineProperty(e, "InlineValueRefreshRequest", { enumerable: !0, get: s(function () { return I.InlineValueRefreshRequest; }, "get") });
        var j = oI();
        Object.defineProperty(e, "InlayHintRequest", { enumerable: !0, get: s(function () { return j.InlayHintRequest; }, "get") }), Object.defineProperty(e, "InlayHintResolveRequest", { enumerable: !0, get: s(function () { return j.InlayHintResolveRequest; }, "get") }), Object.defineProperty(e, "InlayHintRefreshRequest", { enumerable: !0, get: s(function () { return j.InlayHintRefreshRequest; }, "get") });
        var Q = lI();
        Object.defineProperty(e, "DiagnosticServerCancellationData", { enumerable: !0, get: s(function () { return Q.DiagnosticServerCancellationData; }, "get") }), Object.defineProperty(e, "DocumentDiagnosticReportKind", { enumerable: !0, get: s(function () { return Q.DocumentDiagnosticReportKind; }, "get") }), Object.defineProperty(e, "DocumentDiagnosticRequest", { enumerable: !0, get: s(function () { return Q.DocumentDiagnosticRequest; }, "get") }), Object.defineProperty(e, "WorkspaceDiagnosticRequest", { enumerable: !0, get: s(function () { return Q.WorkspaceDiagnosticRequest; }, "get") }), Object.defineProperty(e, "DiagnosticRefreshRequest", { enumerable: !0, get: s(function () { return Q.DiagnosticRefreshRequest; }, "get") });
        var X = uI();
        Object.defineProperty(e, "NotebookCellKind", { enumerable: !0, get: s(function () { return X.NotebookCellKind; }, "get") }), Object.defineProperty(e, "ExecutionSummary", { enumerable: !0, get: s(function () { return X.ExecutionSummary; }, "get") }), Object.defineProperty(e, "NotebookCell", { enumerable: !0, get: s(function () { return X.NotebookCell; }, "get") }), Object.defineProperty(e, "NotebookDocument", { enumerable: !0, get: s(function () { return X.NotebookDocument; }, "get") }), Object.defineProperty(e, "NotebookDocumentSyncRegistrationType", { enumerable: !0, get: s(function () { return X.NotebookDocumentSyncRegistrationType; }, "get") }), Object.defineProperty(e, "DidOpenNotebookDocumentNotification", { enumerable: !0, get: s(function () { return X.DidOpenNotebookDocumentNotification; }, "get") }), Object.defineProperty(e, "NotebookCellArrayChange", { enumerable: !0, get: s(function () { return X.NotebookCellArrayChange; }, "get") }), Object.defineProperty(e, "DidChangeNotebookDocumentNotification", { enumerable: !0, get: s(function () { return X.DidChangeNotebookDocumentNotification; }, "get") }), Object.defineProperty(e, "DidSaveNotebookDocumentNotification", { enumerable: !0, get: s(function () { return X.DidSaveNotebookDocumentNotification; }, "get") }), Object.defineProperty(e, "DidCloseNotebookDocumentNotification", { enumerable: !0, get: s(function () { return X.DidCloseNotebookDocumentNotification; }, "get") });
        var fe = cI();
        Object.defineProperty(e, "InlineCompletionRequest", { enumerable: !0, get: s(function () { return fe.InlineCompletionRequest; }, "get") });
        var ye;
        (function (d) { function ne(Re) { let H = Re; return n.string(H) || n.string(H.language) || n.string(H.scheme) || n.string(H.pattern); } s(ne, "is"), d.is = ne; })(ye || (e.TextDocumentFilter = ye = {}));
        var pe;
        (function (d) { function ne(Re) { let H = Re; return n.objectLiteral(H) && (n.string(H.notebookType) || n.string(H.scheme) || n.string(H.pattern)); } s(ne, "is"), d.is = ne; })(pe || (e.NotebookDocumentFilter = pe = {}));
        var k;
        (function (d) { function ne(Re) { let H = Re; return n.objectLiteral(H) && (n.string(H.notebook) || pe.is(H.notebook)) && (H.language === void 0 || n.string(H.language)); } s(ne, "is"), d.is = ne; })(k || (e.NotebookCellTextDocumentFilter = k = {}));
        var b;
        (function (d) { function ne(Re) { if (!Array.isArray(Re))
            return !1; for (let H of Re)
            if (!n.string(H) && !ye.is(H) && !k.is(H))
                return !1; return !0; } s(ne, "is"), d.is = ne; })(b || (e.DocumentSelector = b = {}));
        var y;
        (function (d) { d.method = "client/registerCapability", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolRequestType(d.method); })(y || (e.RegistrationRequest = y = {}));
        var A;
        (function (d) { d.method = "client/unregisterCapability", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolRequestType(d.method); })(A || (e.UnregistrationRequest = A = {}));
        var T = (function (d) { return d.Create = "create", d.Rename = "rename", d.Delete = "delete", d; })(T || (e.ResourceOperationKind = T = {})), $ = (function (d) { return d.Abort = "abort", d.Transactional = "transactional", d.TextOnlyTransactional = "textOnlyTransactional", d.Undo = "undo", d; })($ || (e.FailureHandlingKind = $ = {})), C = (function (d) { return d.UTF8 = "utf-8", d.UTF16 = "utf-16", d.UTF32 = "utf-32", d; })(C || (e.PositionEncodingKind = C = {})), O;
        (function (d) { function ne(Re) { let H = Re; return H && n.string(H.id) && H.id.length > 0; } s(ne, "hasId"), d.hasId = ne; })(O || (e.StaticRegistrationOptions = O = {}));
        var x;
        (function (d) { function ne(Re) { let H = Re; return H && (H.documentSelector === null || b.is(H.documentSelector)); } s(ne, "is"), d.is = ne; })(x || (e.TextDocumentRegistrationOptions = x = {}));
        var D;
        (function (d) { function ne(H) { let h = H; return n.objectLiteral(h) && (h.workDoneProgress === void 0 || n.boolean(h.workDoneProgress)); } s(ne, "is"), d.is = ne; function Re(H) { let h = H; return h && n.boolean(h.workDoneProgress); } s(Re, "hasWorkDoneProgress"), d.hasWorkDoneProgress = Re; })(D || (e.WorkDoneProgressOptions = D = {}));
        var U;
        (function (d) { d.method = "initialize", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(U || (e.InitializeRequest = U = {}));
        var G = (function (d) { return d.unknownProtocolVersion = 1, d; })(G || (e.InitializeErrorCodes = G = {})), ue;
        (function (d) { d.method = "initialized", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(ue || (e.InitializedNotification = ue = {}));
        var q;
        (function (d) { d.method = "shutdown", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType0(d.method); })(q || (e.ShutdownRequest = q = {}));
        var se;
        (function (d) { d.method = "exit", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType0(d.method); })(se || (e.ExitNotification = se = {}));
        var Be;
        (function (d) { d.method = "workspace/didChangeConfiguration", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(Be || (e.DidChangeConfigurationNotification = Be = {}));
        var Ce = (function (d) { return d.Error = 1, d.Warning = 2, d.Info = 3, d.Log = 4, d.Debug = 5, d; })(Ce || (e.MessageType = Ce = {})), Ae;
        (function (d) { d.method = "window/showMessage", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolNotificationType(d.method); })(Ae || (e.ShowMessageNotification = Ae = {}));
        var xe;
        (function (d) { d.method = "window/showMessageRequest", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolRequestType(d.method); })(xe || (e.ShowMessageRequest = xe = {}));
        var Ke;
        (function (d) { d.method = "window/logMessage", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolNotificationType(d.method); })(Ke || (e.LogMessageNotification = Ke = {}));
        var Le;
        (function (d) { d.method = "telemetry/event", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolNotificationType(d.method); })(Le || (e.TelemetryEventNotification = Le = {}));
        var re = (function (d) { return d.None = 0, d.Full = 1, d.Incremental = 2, d; })(re || (e.TextDocumentSyncKind = re = {})), ft;
        (function (d) { d.method = "textDocument/didOpen", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(ft || (e.DidOpenTextDocumentNotification = ft = {}));
        var _e;
        (function (d) { function ne(H) { let h = H; return h != null && typeof h.text == "string" && h.range !== void 0 && (h.rangeLength === void 0 || typeof h.rangeLength == "number"); } s(ne, "isIncremental"), d.isIncremental = ne; function Re(H) { let h = H; return h != null && typeof h.text == "string" && h.range === void 0 && h.rangeLength === void 0; } s(Re, "isFull"), d.isFull = Re; })(_e || (e.TextDocumentContentChangeEvent = _e = {}));
        var _t;
        (function (d) { d.method = "textDocument/didChange", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(_t || (e.DidChangeTextDocumentNotification = _t = {}));
        var Yn;
        (function (d) { d.method = "textDocument/didClose", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(Yn || (e.DidCloseTextDocumentNotification = Yn = {}));
        var ai;
        (function (d) { d.method = "textDocument/didSave", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(ai || (e.DidSaveTextDocumentNotification = ai = {}));
        var ii = (function (d) { return d.Manual = 1, d.AfterDelay = 2, d.FocusOut = 3, d; })(ii || (e.TextDocumentSaveReason = ii = {})), si;
        (function (d) { d.method = "textDocument/willSave", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(si || (e.WillSaveTextDocumentNotification = si = {}));
        var oi;
        (function (d) { d.method = "textDocument/willSaveWaitUntil", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(oi || (e.WillSaveTextDocumentWaitUntilRequest = oi = {}));
        var St;
        (function (d) { d.method = "workspace/didChangeWatchedFiles", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolNotificationType(d.method); })(St || (e.DidChangeWatchedFilesNotification = St = {}));
        var Xn = (function (d) { return d.Created = 1, d.Changed = 2, d.Deleted = 3, d; })(Xn || (e.FileChangeType = Xn = {})), li;
        (function (d) { function ne(Re) { let H = Re; return n.objectLiteral(H) && (r.URI.is(H.baseUri) || r.WorkspaceFolder.is(H.baseUri)) && n.string(H.pattern); } s(ne, "is"), d.is = ne; })(li || (e.RelativePattern = li = {}));
        var ui = (function (d) { return d.Create = 1, d.Change = 2, d.Delete = 4, d; })(ui || (e.WatchKind = ui = {})), ci;
        (function (d) { d.method = "textDocument/publishDiagnostics", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolNotificationType(d.method); })(ci || (e.PublishDiagnosticsNotification = ci = {}));
        var fi = (function (d) { return d.Invoked = 1, d.TriggerCharacter = 2, d.TriggerForIncompleteCompletions = 3, d; })(fi || (e.CompletionTriggerKind = fi = {})), Jn;
        (function (d) { d.method = "textDocument/completion", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Jn || (e.CompletionRequest = Jn = {}));
        var Zn;
        (function (d) { d.method = "completionItem/resolve", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Zn || (e.CompletionResolveRequest = Zn = {}));
        var Ft;
        (function (d) { d.method = "textDocument/hover", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Ft || (e.HoverRequest = Ft = {}));
        var Qn = (function (d) { return d.Invoked = 1, d.TriggerCharacter = 2, d.ContentChange = 3, d; })(Qn || (e.SignatureHelpTriggerKind = Qn = {})), pi;
        (function (d) { d.method = "textDocument/signatureHelp", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(pi || (e.SignatureHelpRequest = pi = {}));
        var di;
        (function (d) { d.method = "textDocument/definition", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(di || (e.DefinitionRequest = di = {}));
        var ea;
        (function (d) { d.method = "textDocument/references", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(ea || (e.ReferencesRequest = ea = {}));
        var ta;
        (function (d) { d.method = "textDocument/documentHighlight", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(ta || (e.DocumentHighlightRequest = ta = {}));
        var mi;
        (function (d) { d.method = "textDocument/documentSymbol", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(mi || (e.DocumentSymbolRequest = mi = {}));
        var Js;
        (function (d) { d.method = "textDocument/codeAction", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Js || (e.CodeActionRequest = Js = {}));
        var hi;
        (function (d) { d.method = "codeAction/resolve", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(hi || (e.CodeActionResolveRequest = hi = {}));
        var yi;
        (function (d) { d.method = "workspace/symbol", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(yi || (e.WorkspaceSymbolRequest = yi = {}));
        var gi;
        (function (d) { d.method = "workspaceSymbol/resolve", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(gi || (e.WorkspaceSymbolResolveRequest = gi = {}));
        var vi;
        (function (d) { d.method = "textDocument/codeLens", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(vi || (e.CodeLensRequest = vi = {}));
        var $t;
        (function (d) { d.method = "codeLens/resolve", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })($t || (e.CodeLensResolveRequest = $t = {}));
        var Ti;
        (function (d) { d.method = "workspace/codeLens/refresh", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolRequestType0(d.method); })(Ti || (e.CodeLensRefreshRequest = Ti = {}));
        var $i;
        (function (d) { d.method = "textDocument/documentLink", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })($i || (e.DocumentLinkRequest = $i = {}));
        var Sr;
        (function (d) { d.method = "documentLink/resolve", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Sr || (e.DocumentLinkResolveRequest = Sr = {}));
        var Ri;
        (function (d) { d.method = "textDocument/formatting", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Ri || (e.DocumentFormattingRequest = Ri = {}));
        var qr;
        (function (d) { d.method = "textDocument/rangeFormatting", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(qr || (e.DocumentRangeFormattingRequest = qr = {}));
        var Ai;
        (function (d) { d.method = "textDocument/rangesFormatting", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Ai || (e.DocumentRangesFormattingRequest = Ai = {}));
        var zt;
        (function (d) { d.method = "textDocument/onTypeFormatting", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(zt || (e.DocumentOnTypeFormattingRequest = zt = {}));
        var rr = (function (d) { return d.Identifier = 1, d; })(rr || (e.PrepareSupportDefaultBehavior = rr = {})), Ei;
        (function (d) { d.method = "textDocument/rename", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(Ei || (e.RenameRequest = Ei = {}));
        var bi;
        (function (d) { d.method = "textDocument/prepareRename", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(bi || (e.PrepareRenameRequest = bi = {}));
        var nr;
        (function (d) { d.method = "workspace/executeCommand", d.messageDirection = t.MessageDirection.clientToServer, d.type = new t.ProtocolRequestType(d.method); })(nr || (e.ExecuteCommandRequest = nr = {}));
        var ra;
        (function (d) { d.method = "workspace/applyEdit", d.messageDirection = t.MessageDirection.serverToClient, d.type = new t.ProtocolRequestType("workspace/applyEdit"); })(ra || (e.ApplyWorkspaceEditRequest = ra = {}));
    } }), pI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/connection.js"(e) {
        "use strict";
        Object.defineProperty(e, "__esModule", { value: !0 }), e.createProtocolConnection = void 0;
        var t = Ya();
        function r(n, a, i, o) { return t.ConnectionStrategy.is(o) && (o = { connectionStrategy: o }), (0, t.createMessageConnection)(n, a, i, o); }
        s(r, "createProtocolConnection"), e.createProtocolConnection = r;
    } }), dI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/common/api.js"(e) {
        "use strict";
        var t = e && e.__createBinding || (Object.create ? function (i, o, l, u) { u === void 0 && (u = l); var c = Object.getOwnPropertyDescriptor(o, l); (!c || ("get" in c ? !o.__esModule : c.writable || c.configurable)) && (c = { enumerable: !0, get: s(function () { return o[l]; }, "get") }), Object.defineProperty(i, u, c); } : function (i, o, l, u) { u === void 0 && (u = l), i[u] = o[l]; }), r = e && e.__exportStar || function (i, o) { for (var l in i)
            l !== "default" && !Object.prototype.hasOwnProperty.call(o, l) && t(o, i, l); };
        Object.defineProperty(e, "__esModule", { value: !0 }), e.LSPErrorCodes = e.createProtocolConnection = void 0, r(Ya(), e), r((Ns(), gp(Pl)), e), r(be(), e), r(fI(), e);
        var n = pI();
        Object.defineProperty(e, "createProtocolConnection", { enumerable: !0, get: s(function () { return n.createProtocolConnection; }, "get") });
        var a = (function (i) { return i.lspReservedErrorRangeStart = -32899, i.RequestFailed = -32803, i.ServerCancelled = -32802, i.ContentModified = -32801, i.RequestCancelled = -32800, i.lspReservedErrorRangeEnd = -32800, i; })(a || (e.LSPErrorCodes = a = {}));
    } }), mI = Y({ "../../node_modules/.pnpm/vscode-languageserver-protocol@3.17.5/node_modules/vscode-languageserver-protocol/lib/browser/main.js"(e) {
        "use strict";
        var t = e && e.__createBinding || (Object.create ? function (i, o, l, u) { u === void 0 && (u = l); var c = Object.getOwnPropertyDescriptor(o, l); (!c || ("get" in c ? !o.__esModule : c.writable || c.configurable)) && (c = { enumerable: !0, get: s(function () { return o[l]; }, "get") }), Object.defineProperty(i, u, c); } : function (i, o, l, u) { u === void 0 && (u = l), i[u] = o[l]; }), r = e && e.__exportStar || function (i, o) { for (var l in i)
            l !== "default" && !Object.prototype.hasOwnProperty.call(o, l) && t(o, i, l); };
        Object.defineProperty(e, "__esModule", { value: !0 }), e.createProtocolConnection = void 0;
        var n = rh();
        r(rh(), e), r(dI(), e);
        function a(i, o, l, u) { return (0, n.createMessageConnection)(i, o, l, u); }
        s(a, "createProtocolConnection"), e.createProtocolConnection = a;
    } }), Lg = {};
zr(Lg, { AbstractAstReflection: () => Rp, AbstractCstNode: () => Am, AbstractLangiumParser: () => bm, AbstractParserErrorMessageProvider: () => bS, AbstractThreadedAsyncParser: () => BG, AstUtils: () => Ap, BiMap: () => Cl, Cancellation: () => me, CompositeCstNodeImpl: () => wu, ContextCache: () => Du, CstNodeBuilder: () => $S, CstUtils: () => Tp, DEFAULT_TOKENIZE_OPTIONS: () => Um, DONE_RESULT: () => Je, DatatypeSymbol: () => Rl, DefaultAstNodeDescriptionProvider: () => ew, DefaultAstNodeLocator: () => rw, DefaultAsyncParser: () => $w, DefaultCommentProvider: () => Tw, DefaultConfigurationProvider: () => nw, DefaultDocumentBuilder: () => aw, DefaultDocumentValidator: () => QS, DefaultHydrator: () => Aw, DefaultIndexManager: () => iw, DefaultJsonSerializer: () => YS, DefaultLangiumDocumentFactory: () => zS, DefaultLangiumDocuments: () => jS, DefaultLangiumProfiler: () => HG, DefaultLexer: () => Bm, DefaultLexerErrorMessageProvider: () => ow, DefaultLinker: () => US, DefaultNameProvider: () => BS, DefaultReferenceDescriptionProvider: () => tw, DefaultReferences: () => KS, DefaultScopeComputation: () => qS, DefaultScopeProvider: () => HS, DefaultServiceRegistry: () => XS, DefaultTokenBuilder: () => Pu, DefaultValueConverter: () => Pm, DefaultWorkspaceLock: () => Rw, DefaultWorkspaceManager: () => sw, Deferred: () => Rr, Disposable: () => En, DisposableCache: () => Lu, DocumentCache: () => VS, DocumentState: () => J, DocumentValidator: () => Pt, EMPTY_SCOPE: () => FG, EMPTY_STREAM: () => Ma, EmptyFileSystem: () => Sw, EmptyFileSystemProvider: () => _w, ErrorWithLocation: () => jl, GrammarAST: () => Mg, GrammarUtils: () => Zp, IndentationAwareLexer: () => qG, IndentationAwareTokenBuilder: () => Cw, JSDocDocumentationProvider: () => vw, LangiumCompletionParser: () => CS, LangiumParser: () => ES, LangiumParserErrorMessageProvider: () => Cm, LeafCstNodeImpl: () => $l, LexingMode: () => ka, MapScope: () => GG, Module: () => Ew, MultiMap: () => Ar, MultiMapScope: () => WS, OperationCancelled: () => Ht, ParserWorker: () => KG, ProfilingTask: () => Iw, Reduction: () => ds, RefResolving: () => rn, RegExpUtils: () => ed, RootCstNodeImpl: () => Em, SimpleCache: () => Mm, StreamImpl: () => Vt, StreamScope: () => Vf, TextDocument: () => El, TreeStreamImpl: () => Ga, URI: () => mt, UriTrie: () => Dm, UriUtils: () => Qe, VALIDATE_EACH_NODE: () => ZS, ValidationCategory: () => _l, ValidationRegistry: () => JS, ValueConverter: () => Wt, WorkspaceCache: () => Gm, assertCondition: () => Qp, assertUnreachable: () => jr, createCompletionParser: () => wm, createDefaultCoreModule: () => Xm, createDefaultSharedCoreModule: () => Jm, createGrammarConfig: () => vd, createLangiumParser: () => Im, createParser: () => Iu, delayNextTick: () => ku, diagnosticData: () => Rn, eagerLoad: () => Zm, getDiagnosticRange: () => zm, indentationBuilderDefaultOptions: () => Zf, inject: () => Il, interruptAndCheck: () => je, isAstNode: () => De, isAstNodeDescription: () => $p, isAstNodeWithComment: () => Fm, isCompositeCstNode: () => dr, isIMultiModeLexerDefinition: () => Gu, isJSDoc: () => qm, isLeafCstNode: () => In, isLinkingError: () => on, isMultiReference: () => Yt, isNamed: () => xm, isOperationCancelled: () => Hn, isReference: () => Ze, isRootCstNode: () => Ol, isTokenTypeArray: () => Mu, isTokenTypeDictionary: () => Sl, loadGrammarFromJson: () => Ue, parseJSDoc: () => Km, prepareLangiumParser: () => Nm, setInterruptionPeriod: () => km, startCancelableOperation: () => Ou, stream: () => le, toDiagnosticData: () => jm, toDiagnosticSeverity: () => fs });
var Tp = {};
zr(Tp, { DefaultNameRegexp: () => Vp, RangeComparison: () => fr, compareRange: () => qp, findCommentNode: () => Hp, findDeclarationNodeAtOffset: () => rv, findLeafNodeAtOffset: () => zl, findLeafNodeBeforeOffset: () => Yp, flattenCst: () => tv, getDatatypeNode: () => ev, getInteriorNodes: () => iv, getNextNode: () => nv, getPreviousNode: () => Jp, getStartlineNode: () => av, inRange: () => Wp, isChildNode: () => Kp, isCommentNode: () => al, streamCst: () => Ua, toDocumentSegment: () => Ba, tokenToRange: () => ms });
function De(e) { return typeof e == "object" && e !== null && typeof e.$type == "string"; }
s(De, "isAstNode");
function Ze(e) { return typeof e == "object" && e !== null && typeof e.$refText == "string" && "ref" in e; }
s(Ze, "isReference");
function Yt(e) { return typeof e == "object" && e !== null && typeof e.$refText == "string" && "items" in e; }
s(Yt, "isMultiReference");
function $p(e) { return typeof e == "object" && e !== null && typeof e.name == "string" && typeof e.type == "string" && typeof e.path == "string"; }
s($p, "isAstNodeDescription");
function on(e) { return typeof e == "object" && e !== null && typeof e.info == "object" && typeof e.message == "string"; }
s(on, "isLinkingError");
var Rp = class {
    static { s(this, "AbstractAstReflection"); }
    constructor() { this.subtypes = {}, this.allSubtypes = {}; }
    getAllTypes() { return Object.keys(this.types); }
    getReferenceType(e) { let t = this.types[e.container.$type]; if (!t)
        throw new Error(`Type ${e.container.$type || "undefined"} not found.`); let r = t.properties[e.property]?.referenceType; if (!r)
        throw new Error(`Property ${e.property || "undefined"} of type ${e.container.$type} is not a reference.`); return r; }
    getTypeMetaData(e) { let t = this.types[e]; return t || { name: e, properties: {}, superTypes: [] }; }
    isInstance(e, t) { return De(e) && this.isSubtype(e.$type, t); }
    isSubtype(e, t) { if (e === t)
        return !0; let r = this.subtypes[e]; r || (r = this.subtypes[e] = {}); let n = r[t]; if (n !== void 0)
        return n; {
        let a = this.types[e], i = a ? a.superTypes.some(o => this.isSubtype(o, t)) : !1;
        return r[t] = i, i;
    } }
    getAllSubTypes(e) { let t = this.allSubtypes[e]; if (t)
        return t; {
        let r = this.getAllTypes(), n = [];
        for (let a of r)
            this.isSubtype(a, e) && n.push(a);
        return this.allSubtypes[e] = n, n;
    } }
};
function dr(e) { return typeof e == "object" && e !== null && Array.isArray(e.content); }
s(dr, "isCompositeCstNode");
function In(e) { return typeof e == "object" && e !== null && typeof e.tokenType == "object"; }
s(In, "isLeafCstNode");
function Ol(e) { return dr(e) && typeof e.fullText == "string"; }
s(Ol, "isRootCstNode");
var Vt = class or {
    static { s(this, "StreamImpl"); }
    constructor(t, r) { this.startFn = t, this.nextFn = r; }
    iterator() { let t = { state: this.startFn(), next: s(() => this.nextFn(t.state), "next"), [Symbol.iterator]: () => t }; return t; }
    [Symbol.iterator]() { return this.iterator(); }
    isEmpty() { return !!this.iterator().next().done; }
    count() { let t = this.iterator(), r = 0, n = t.next(); for (; !n.done;)
        r++, n = t.next(); return r; }
    toArray() { let t = [], r = this.iterator(), n; do
        n = r.next(), n.value !== void 0 && t.push(n.value);
    while (!n.done); return t; }
    toSet() { return new Set(this); }
    toMap(t, r) { let n = this.map(a => [t ? t(a) : a, r ? r(a) : a]); return new Map(n); }
    toString() { return this.join(); }
    concat(t) { return new or(() => ({ first: this.startFn(), firstDone: !1, iterator: t[Symbol.iterator]() }), r => { let n; if (!r.firstDone) {
        do
            if (n = this.nextFn(r.first), !n.done)
                return n;
        while (!n.done);
        r.firstDone = !0;
    } do
        if (n = r.iterator.next(), !n.done)
            return n;
    while (!n.done); return Je; }); }
    join(t = ",") { let r = this.iterator(), n = "", a, i = !1; do
        a = r.next(), a.done || (i && (n += t), n += Dg(a.value)), i = !0;
    while (!a.done); return n; }
    indexOf(t, r = 0) { let n = this.iterator(), a = 0, i = n.next(); for (; !i.done;) {
        if (a >= r && i.value === t)
            return a;
        i = n.next(), a++;
    } return -1; }
    every(t) { let r = this.iterator(), n = r.next(); for (; !n.done;) {
        if (!t(n.value))
            return !1;
        n = r.next();
    } return !0; }
    some(t) { let r = this.iterator(), n = r.next(); for (; !n.done;) {
        if (t(n.value))
            return !0;
        n = r.next();
    } return !1; }
    forEach(t) { let r = this.iterator(), n = 0, a = r.next(); for (; !a.done;)
        t(a.value, n), a = r.next(), n++; }
    map(t) { return new or(this.startFn, r => { let { done: n, value: a } = this.nextFn(r); return n ? Je : { done: !1, value: t(a) }; }); }
    filter(t) { return new or(this.startFn, r => { let n; do
        if (n = this.nextFn(r), !n.done && t(n.value))
            return n;
    while (!n.done); return Je; }); }
    nonNullable() { return this.filter(t => t != null); }
    reduce(t, r) { let n = this.iterator(), a = r, i = n.next(); for (; !i.done;)
        a === void 0 ? a = i.value : a = t(a, i.value), i = n.next(); return a; }
    reduceRight(t, r) { return this.recursiveReduce(this.iterator(), t, r); }
    recursiveReduce(t, r, n) { let a = t.next(); if (a.done)
        return n; let i = this.recursiveReduce(t, r, n); return i === void 0 ? a.value : r(i, a.value); }
    find(t) { let r = this.iterator(), n = r.next(); for (; !n.done;) {
        if (t(n.value))
            return n.value;
        n = r.next();
    } }
    findIndex(t) { let r = this.iterator(), n = 0, a = r.next(); for (; !a.done;) {
        if (t(a.value))
            return n;
        a = r.next(), n++;
    } return -1; }
    includes(t) { let r = this.iterator(), n = r.next(); for (; !n.done;) {
        if (n.value === t)
            return !0;
        n = r.next();
    } return !1; }
    flatMap(t) { return new or(() => ({ this: this.startFn() }), r => { do {
        if (r.iterator) {
            let i = r.iterator.next();
            if (i.done)
                r.iterator = void 0;
            else
                return i;
        }
        let { done: n, value: a } = this.nextFn(r.this);
        if (!n) {
            let i = t(a);
            if (ps(i))
                r.iterator = i[Symbol.iterator]();
            else
                return { done: !1, value: i };
        }
    } while (r.iterator); return Je; }); }
    flat(t) { if (t === void 0 && (t = 1), t <= 0)
        return this; let r = t > 1 ? this.flat(t - 1) : this; return new or(() => ({ this: r.startFn() }), n => { do {
        if (n.iterator) {
            let o = n.iterator.next();
            if (o.done)
                n.iterator = void 0;
            else
                return o;
        }
        let { done: a, value: i } = r.nextFn(n.this);
        if (!a)
            if (ps(i))
                n.iterator = i[Symbol.iterator]();
            else
                return { done: !1, value: i };
    } while (n.iterator); return Je; }); }
    head() { let r = this.iterator().next(); if (!r.done)
        return r.value; }
    tail(t = 1) { return new or(() => { let r = this.startFn(); for (let n = 0; n < t; n++)
        if (this.nextFn(r).done)
            return r; return r; }, this.nextFn); }
    limit(t) { return new or(() => ({ size: 0, state: this.startFn() }), r => (r.size++, r.size > t ? Je : this.nextFn(r.state))); }
    distinct(t) { return new or(() => ({ set: new Set, internalState: this.startFn() }), r => { let n; do
        if (n = this.nextFn(r.internalState), !n.done) {
            let a = t ? t(n.value) : n.value;
            if (!r.set.has(a))
                return r.set.add(a), n;
        }
    while (!n.done); return Je; }); }
    exclude(t, r) { let n = new Set; for (let a of t) {
        let i = r ? r(a) : a;
        n.add(i);
    } return this.filter(a => { let i = r ? r(a) : a; return !n.has(i); }); }
};
function Dg(e) { return typeof e == "string" ? e : typeof e > "u" ? "undefined" : typeof e.toString == "function" ? e.toString() : Object.prototype.toString.call(e); }
s(Dg, "toString");
function ps(e) { return !!e && typeof e[Symbol.iterator] == "function"; }
s(ps, "isIterable");
var Ma = new Vt(() => { }, () => Je), Je = Object.freeze({ done: !0, value: void 0 });
function le(...e) { if (e.length === 1) {
    let t = e[0];
    if (t instanceof Vt)
        return t;
    if (ps(t))
        return new Vt(() => t[Symbol.iterator](), r => r.next());
    if (typeof t.length == "number")
        return new Vt(() => ({ index: 0 }), r => r.index < t.length ? { done: !1, value: t[r.index++] } : Je);
} return e.length > 1 ? new Vt(() => ({ collIndex: 0, arrIndex: 0 }), t => { do {
    if (t.iterator) {
        let r = t.iterator.next();
        if (!r.done)
            return r;
        t.iterator = void 0;
    }
    if (t.array) {
        if (t.arrIndex < t.array.length)
            return { done: !1, value: t.array[t.arrIndex++] };
        t.array = void 0, t.arrIndex = 0;
    }
    if (t.collIndex < e.length) {
        let r = e[t.collIndex++];
        ps(r) ? t.iterator = r[Symbol.iterator]() : r && typeof r.length == "number" && (t.array = r);
    }
} while (t.iterator || t.array || t.collIndex < e.length); return Je; }) : Ma; }
s(le, "stream");
var Ga = class extends Vt {
    static { s(this, "TreeStreamImpl"); }
    constructor(e, t, r) { super(() => ({ iterators: r?.includeRoot ? [[e][Symbol.iterator]()] : [t(e)[Symbol.iterator]()], pruned: !1 }), n => { for (n.pruned && (n.iterators.pop(), n.pruned = !1); n.iterators.length > 0;) {
        let i = n.iterators[n.iterators.length - 1].next();
        if (i.done)
            n.iterators.pop();
        else
            return n.iterators.push(t(i.value)[Symbol.iterator]()), i;
    } return Je; }); }
    iterator() { let e = { state: this.startFn(), next: s(() => this.nextFn(e.state), "next"), prune: s(() => { e.state.pruned = !0; }, "prune"), [Symbol.iterator]: () => e }; return e; }
}, ds;
(function (e) { function t(i) { return i.reduce((o, l) => o + l, 0); } s(t, "sum"), e.sum = t; function r(i) { return i.reduce((o, l) => o * l, 0); } s(r, "product"), e.product = r; function n(i) { return i.reduce((o, l) => Math.min(o, l)); } s(n, "min"), e.min = n; function a(i) { return i.reduce((o, l) => Math.max(o, l)); } s(a, "max"), e.max = a; })(ds || (ds = {}));
var Ap = {};
zr(Ap, { assignMandatoryProperties: () => Ep, copyAstNode: () => Ko, findRootNode: () => Oa, getContainerOfType: () => Nn, getDocument: () => kt, getReferenceNodes: () => Uo, hasContainerOfType: () => xg, linkContentToContainer: () => Fa, streamAllContents: () => Er, streamAst: () => Ot, streamContents: () => ks, streamReferences: () => za });
function Fa(e, t = {}) { for (let [r, n] of Object.entries(e))
    r.startsWith("$") || (Array.isArray(n) ? n.forEach((a, i) => { De(a) && (a.$container = e, a.$containerProperty = r, a.$containerIndex = i, t.deep && Fa(a, t)); }) : De(n) && (n.$container = e, n.$containerProperty = r, t.deep && Fa(n, t))); }
s(Fa, "linkContentToContainer");
function Nn(e, t) { let r = e; for (; r;) {
    if (t(r))
        return r;
    r = r.$container;
} }
s(Nn, "getContainerOfType");
function xg(e, t) { let r = e; for (; r;) {
    if (t(r))
        return !0;
    r = r.$container;
} return !1; }
s(xg, "hasContainerOfType");
function kt(e) { let r = Oa(e).$document; if (!r)
    throw new Error("AST node has no document."); return r; }
s(kt, "getDocument");
function Oa(e) { for (; e.$container;)
    e = e.$container; return e; }
s(Oa, "findRootNode");
function Uo(e) { return Ze(e) ? e.ref ? [e.ref] : [] : Yt(e) ? e.items.map(t => t.ref) : []; }
s(Uo, "getReferenceNodes");
function ks(e, t) { if (!e)
    throw new Error("Node must be an AstNode."); let r = t?.range; return new Vt(() => ({ keys: Object.keys(e), keyIndex: 0, arrayIndex: 0 }), n => { for (; n.keyIndex < n.keys.length;) {
    let a = n.keys[n.keyIndex];
    if (!a.startsWith("$")) {
        let i = e[a];
        if (De(i)) {
            if (n.keyIndex++, Bo(i, r))
                return { done: !1, value: i };
        }
        else if (Array.isArray(i)) {
            for (; n.arrayIndex < i.length;) {
                let o = n.arrayIndex++, l = i[o];
                if (De(l) && Bo(l, r))
                    return { done: !1, value: l };
            }
            n.arrayIndex = 0;
        }
    }
    n.keyIndex++;
} return Je; }); }
s(ks, "streamContents");
function Er(e, t) { if (!e)
    throw new Error("Root node must be an AstNode."); return new Ga(e, r => ks(r, t)); }
s(Er, "streamAllContents");
function Ot(e, t) { if (e) {
    if (t?.range && !Bo(e, t.range))
        return new Ga(e, () => []);
}
else
    throw new Error("Root node must be an AstNode."); return new Ga(e, r => ks(r, t), { includeRoot: !0 }); }
s(Ot, "streamAst");
function Bo(e, t) { if (!t)
    return !0; let r = e.$cstNode?.range; return r ? Wp(r, t) : !1; }
s(Bo, "isAstNodeInRange");
function za(e) { return new Vt(() => ({ keys: Object.keys(e), keyIndex: 0, arrayIndex: 0 }), t => { for (; t.keyIndex < t.keys.length;) {
    let r = t.keys[t.keyIndex];
    if (!r.startsWith("$")) {
        let n = e[r];
        if (Ze(n) || Yt(n))
            return t.keyIndex++, { done: !1, value: { reference: n, container: e, property: r } };
        if (Array.isArray(n)) {
            for (; t.arrayIndex < n.length;) {
                let a = t.arrayIndex++, i = n[a];
                if (Ze(i) || Yt(n))
                    return { done: !1, value: { reference: i, container: e, property: r, index: a } };
            }
            t.arrayIndex = 0;
        }
    }
    t.keyIndex++;
} return Je; }); }
s(za, "streamReferences");
function Ep(e, t) { let r = e.getTypeMetaData(t.$type), n = t; for (let a of Object.values(r.properties))
    a.defaultValue !== void 0 && n[a.name] === void 0 && (n[a.name] = bp(a.defaultValue)); }
s(Ep, "assignMandatoryProperties");
function bp(e) { return Array.isArray(e) ? [...e.map(bp)] : e; }
s(bp, "copyDefaultValue");
function Ko(e, t, r) { let n = { $type: e.$type }; r && (r.set(e, n), r.set(n, e)); for (let [a, i] of Object.entries(e))
    if (!a.startsWith("$"))
        if (De(i))
            n[a] = Ko(i, t, r);
        else if (Ze(i))
            n[a] = t(n, a, i.$refNode, i.$refText, i);
        else if (Array.isArray(i)) {
            let o = [];
            for (let l of i)
                De(l) ? o.push(Ko(l, t, r)) : Ze(l) ? o.push(t(n, a, l.$refNode, l.$refText, l)) : o.push(l);
            n[a] = o;
        }
        else
            n[a] = i; return Fa(n, { deep: !0 }), n; }
s(Ko, "copyAstNode");
var Mg = {};
zr(Mg, { AbstractElement: () => at, AbstractParserRule: () => Ji, AbstractRule: () => ba, AbstractType: () => pt, Action: () => Nr, Alternatives: () => Zi, ArrayLiteral: () => qo, ArrayType: () => Wo, Assignment: () => Pr, BooleanLiteral: () => Vo, CharacterRange: () => kr, Condition: () => Or, Conjunction: () => Qi, CrossReference: () => Lr, Disjunction: () => es, EndOfFile: () => Ho, Grammar: () => ur, GrammarImport: () => Yo, Group: () => ln, InferredType: () => Xo, InfixRule: () => qt, InfixRuleOperatorList: () => ts, InfixRuleOperators: () => Jo, Interface: () => Ca, Keyword: () => _a, LangiumGrammarAstReflection: () => Bp, LangiumGrammarTerminals: () => hI, NamedArgument: () => Sa, NegatedToken: () => un, Negation: () => Zo, NumberLiteral: () => Qo, Parameter: () => wa, ParameterReference: () => el, ParserRule: () => wt, ReferenceType: () => rs, RegexToken: () => cn, ReturnType: () => tl, RuleCall: () => fn, SimpleType: () => Ia, StringLiteral: () => rl, TerminalAlternatives: () => pn, TerminalElement: () => it, TerminalGroup: () => dn, TerminalRule: () => cr, TerminalRuleCall: () => mn, Type: () => ns, TypeAttribute: () => hn, TypeDefinition: () => yn, UnionType: () => nl, UnorderedGroup: () => as, UntilToken: () => gn, ValueLiteral: () => vn, Wildcard: () => Na, isAbstractElement: () => Ll, isAbstractParserRule: () => Pn, isAbstractRule: () => Gg, isAbstractType: () => Fg, isAction: () => Dr, isAlternatives: () => Dl, isArrayLiteral: () => zg, isArrayType: () => Cp, isAssignment: () => mr, isBooleanLiteral: () => _p, isCharacterRange: () => Sp, isCondition: () => jg, isConjunction: () => wp, isCrossReference: () => kn, isDisjunction: () => Ip, isEndOfFile: () => Np, isGrammar: () => Ug, isGrammarImport: () => Bg, isGroup: () => On, isInferredType: () => Os, isInfixRule: () => ja, isInfixRuleOperatorList: () => Kg, isInfixRuleOperators: () => qg, isInterface: () => Pp, isKeyword: () => hr, isNamedArgument: () => Wg, isNegatedToken: () => kp, isNegation: () => Op, isNumberLiteral: () => Vg, isParameter: () => Hg, isParameterReference: () => Lp, isParserRule: () => et, isReferenceType: () => Dp, isRegexToken: () => xp, isReturnType: () => Mp, isRuleCall: () => yr, isSimpleType: () => xl, isStringLiteral: () => Yg, isTerminalAlternatives: () => Gp, isTerminalElement: () => Xg, isTerminalGroup: () => Fp, isTerminalRule: () => bt, isTerminalRuleCall: () => Ml, isType: () => Gl, isTypeAttribute: () => Jg, isTypeDefinition: () => Zg, isUnionType: () => zp, isUnorderedGroup: () => Fl, isUntilToken: () => jp, isValueLiteral: () => Qg, isWildcard: () => Up, reflection: () => B });
var hI = { ID: /\^?[_a-zA-Z][\w_]*/, STRING: /"(\\.|[^"\\])*"|'(\\.|[^'\\])*'/, NUMBER: /NaN|-?((\d*\.\d+|\d+)([Ee][+-]?\d+)?|Infinity)/, RegexLiteral: /\/(?![*+?])(?:[^\r\n\[/\\]|\\.|\[(?:[^\r\n\]\\]|\\.)*\])+\/[a-z]*/, WS: /\s+/, ML_COMMENT: /\/\*[\s\S]*?\*\//, SL_COMMENT: /\/\/[^\n\r]*/ }, at = { $type: "AbstractElement", cardinality: "cardinality" };
function Ll(e) { return B.isInstance(e, at.$type); }
s(Ll, "isAbstractElement");
var Ji = { $type: "AbstractParserRule" };
function Pn(e) { return B.isInstance(e, Ji.$type); }
s(Pn, "isAbstractParserRule");
var ba = { $type: "AbstractRule" };
function Gg(e) { return B.isInstance(e, ba.$type); }
s(Gg, "isAbstractRule");
var pt = { $type: "AbstractType" };
function Fg(e) { return B.isInstance(e, pt.$type); }
s(Fg, "isAbstractType");
var Nr = { $type: "Action", cardinality: "cardinality", feature: "feature", inferredType: "inferredType", operator: "operator", type: "type" };
function Dr(e) { return B.isInstance(e, Nr.$type); }
s(Dr, "isAction");
var Zi = { $type: "Alternatives", cardinality: "cardinality", elements: "elements" };
function Dl(e) { return B.isInstance(e, Zi.$type); }
s(Dl, "isAlternatives");
var qo = { $type: "ArrayLiteral", elements: "elements" };
function zg(e) { return B.isInstance(e, qo.$type); }
s(zg, "isArrayLiteral");
var Wo = { $type: "ArrayType", elementType: "elementType" };
function Cp(e) { return B.isInstance(e, Wo.$type); }
s(Cp, "isArrayType");
var Pr = { $type: "Assignment", cardinality: "cardinality", feature: "feature", operator: "operator", predicate: "predicate", terminal: "terminal" };
function mr(e) { return B.isInstance(e, Pr.$type); }
s(mr, "isAssignment");
var Vo = { $type: "BooleanLiteral", true: "true" };
function _p(e) { return B.isInstance(e, Vo.$type); }
s(_p, "isBooleanLiteral");
var kr = { $type: "CharacterRange", cardinality: "cardinality", left: "left", lookahead: "lookahead", parenthesized: "parenthesized", right: "right" };
function Sp(e) { return B.isInstance(e, kr.$type); }
s(Sp, "isCharacterRange");
var Or = { $type: "Condition" };
function jg(e) { return B.isInstance(e, Or.$type); }
s(jg, "isCondition");
var Qi = { $type: "Conjunction", left: "left", right: "right" };
function wp(e) { return B.isInstance(e, Qi.$type); }
s(wp, "isConjunction");
var Lr = { $type: "CrossReference", cardinality: "cardinality", deprecatedSyntax: "deprecatedSyntax", isMulti: "isMulti", terminal: "terminal", type: "type" };
function kn(e) { return B.isInstance(e, Lr.$type); }
s(kn, "isCrossReference");
var es = { $type: "Disjunction", left: "left", right: "right" };
function Ip(e) { return B.isInstance(e, es.$type); }
s(Ip, "isDisjunction");
var Ho = { $type: "EndOfFile", cardinality: "cardinality" };
function Np(e) { return B.isInstance(e, Ho.$type); }
s(Np, "isEndOfFile");
var ur = { $type: "Grammar", imports: "imports", interfaces: "interfaces", isDeclared: "isDeclared", name: "name", rules: "rules", types: "types" };
function Ug(e) { return B.isInstance(e, ur.$type); }
s(Ug, "isGrammar");
var Yo = { $type: "GrammarImport", path: "path" };
function Bg(e) { return B.isInstance(e, Yo.$type); }
s(Bg, "isGrammarImport");
var ln = { $type: "Group", cardinality: "cardinality", elements: "elements", guardCondition: "guardCondition", predicate: "predicate" };
function On(e) { return B.isInstance(e, ln.$type); }
s(On, "isGroup");
var Xo = { $type: "InferredType", name: "name" };
function Os(e) { return B.isInstance(e, Xo.$type); }
s(Os, "isInferredType");
var qt = { $type: "InfixRule", call: "call", dataType: "dataType", inferredType: "inferredType", name: "name", operators: "operators", parameters: "parameters", returnType: "returnType" };
function ja(e) { return B.isInstance(e, qt.$type); }
s(ja, "isInfixRule");
var ts = { $type: "InfixRuleOperatorList", associativity: "associativity", operators: "operators" };
function Kg(e) { return B.isInstance(e, ts.$type); }
s(Kg, "isInfixRuleOperatorList");
var Jo = { $type: "InfixRuleOperators", precedences: "precedences" };
function qg(e) { return B.isInstance(e, Jo.$type); }
s(qg, "isInfixRuleOperators");
var Ca = { $type: "Interface", attributes: "attributes", name: "name", superTypes: "superTypes" };
function Pp(e) { return B.isInstance(e, Ca.$type); }
s(Pp, "isInterface");
var _a = { $type: "Keyword", cardinality: "cardinality", predicate: "predicate", value: "value" };
function hr(e) { return B.isInstance(e, _a.$type); }
s(hr, "isKeyword");
var Sa = { $type: "NamedArgument", calledByName: "calledByName", parameter: "parameter", value: "value" };
function Wg(e) { return B.isInstance(e, Sa.$type); }
s(Wg, "isNamedArgument");
var un = { $type: "NegatedToken", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized", terminal: "terminal" };
function kp(e) { return B.isInstance(e, un.$type); }
s(kp, "isNegatedToken");
var Zo = { $type: "Negation", value: "value" };
function Op(e) { return B.isInstance(e, Zo.$type); }
s(Op, "isNegation");
var Qo = { $type: "NumberLiteral", value: "value" };
function Vg(e) { return B.isInstance(e, Qo.$type); }
s(Vg, "isNumberLiteral");
var wa = { $type: "Parameter", name: "name" };
function Hg(e) { return B.isInstance(e, wa.$type); }
s(Hg, "isParameter");
var el = { $type: "ParameterReference", parameter: "parameter" };
function Lp(e) { return B.isInstance(e, el.$type); }
s(Lp, "isParameterReference");
var wt = { $type: "ParserRule", dataType: "dataType", definition: "definition", entry: "entry", fragment: "fragment", inferredType: "inferredType", name: "name", parameters: "parameters", returnType: "returnType" };
function et(e) { return B.isInstance(e, wt.$type); }
s(et, "isParserRule");
var rs = { $type: "ReferenceType", isMulti: "isMulti", referenceType: "referenceType" };
function Dp(e) { return B.isInstance(e, rs.$type); }
s(Dp, "isReferenceType");
var cn = { $type: "RegexToken", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized", regex: "regex" };
function xp(e) { return B.isInstance(e, cn.$type); }
s(xp, "isRegexToken");
var tl = { $type: "ReturnType", name: "name" };
function Mp(e) { return B.isInstance(e, tl.$type); }
s(Mp, "isReturnType");
var fn = { $type: "RuleCall", arguments: "arguments", cardinality: "cardinality", predicate: "predicate", rule: "rule" };
function yr(e) { return B.isInstance(e, fn.$type); }
s(yr, "isRuleCall");
var Ia = { $type: "SimpleType", primitiveType: "primitiveType", stringType: "stringType", typeRef: "typeRef" };
function xl(e) { return B.isInstance(e, Ia.$type); }
s(xl, "isSimpleType");
var rl = { $type: "StringLiteral", value: "value" };
function Yg(e) { return B.isInstance(e, rl.$type); }
s(Yg, "isStringLiteral");
var pn = { $type: "TerminalAlternatives", cardinality: "cardinality", elements: "elements", lookahead: "lookahead", parenthesized: "parenthesized" };
function Gp(e) { return B.isInstance(e, pn.$type); }
s(Gp, "isTerminalAlternatives");
var it = { $type: "TerminalElement", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized" };
function Xg(e) { return B.isInstance(e, it.$type); }
s(Xg, "isTerminalElement");
var dn = { $type: "TerminalGroup", cardinality: "cardinality", elements: "elements", lookahead: "lookahead", parenthesized: "parenthesized" };
function Fp(e) { return B.isInstance(e, dn.$type); }
s(Fp, "isTerminalGroup");
var cr = { $type: "TerminalRule", definition: "definition", fragment: "fragment", hidden: "hidden", name: "name", type: "type" };
function bt(e) { return B.isInstance(e, cr.$type); }
s(bt, "isTerminalRule");
var mn = { $type: "TerminalRuleCall", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized", rule: "rule" };
function Ml(e) { return B.isInstance(e, mn.$type); }
s(Ml, "isTerminalRuleCall");
var ns = { $type: "Type", name: "name", type: "type" };
function Gl(e) { return B.isInstance(e, ns.$type); }
s(Gl, "isType");
var hn = { $type: "TypeAttribute", defaultValue: "defaultValue", isOptional: "isOptional", name: "name", type: "type" };
function Jg(e) { return B.isInstance(e, hn.$type); }
s(Jg, "isTypeAttribute");
var yn = { $type: "TypeDefinition" };
function Zg(e) { return B.isInstance(e, yn.$type); }
s(Zg, "isTypeDefinition");
var nl = { $type: "UnionType", types: "types" };
function zp(e) { return B.isInstance(e, nl.$type); }
s(zp, "isUnionType");
var as = { $type: "UnorderedGroup", cardinality: "cardinality", elements: "elements" };
function Fl(e) { return B.isInstance(e, as.$type); }
s(Fl, "isUnorderedGroup");
var gn = { $type: "UntilToken", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized", terminal: "terminal" };
function jp(e) { return B.isInstance(e, gn.$type); }
s(jp, "isUntilToken");
var vn = { $type: "ValueLiteral" };
function Qg(e) { return B.isInstance(e, vn.$type); }
s(Qg, "isValueLiteral");
var Na = { $type: "Wildcard", cardinality: "cardinality", lookahead: "lookahead", parenthesized: "parenthesized" };
function Up(e) { return B.isInstance(e, Na.$type); }
s(Up, "isWildcard");
var Bp = class extends Rp {
    static { s(this, "LangiumGrammarAstReflection"); }
    constructor() { super(...arguments), this.types = { AbstractElement: { name: at.$type, properties: { cardinality: { name: at.cardinality } }, superTypes: [] }, AbstractParserRule: { name: Ji.$type, properties: {}, superTypes: [ba.$type, pt.$type] }, AbstractRule: { name: ba.$type, properties: {}, superTypes: [] }, AbstractType: { name: pt.$type, properties: {}, superTypes: [] }, Action: { name: Nr.$type, properties: { cardinality: { name: Nr.cardinality }, feature: { name: Nr.feature }, inferredType: { name: Nr.inferredType }, operator: { name: Nr.operator }, type: { name: Nr.type, referenceType: pt.$type } }, superTypes: [at.$type] }, Alternatives: { name: Zi.$type, properties: { cardinality: { name: Zi.cardinality }, elements: { name: Zi.elements, defaultValue: [] } }, superTypes: [at.$type] }, ArrayLiteral: { name: qo.$type, properties: { elements: { name: qo.elements, defaultValue: [] } }, superTypes: [vn.$type] }, ArrayType: { name: Wo.$type, properties: { elementType: { name: Wo.elementType } }, superTypes: [yn.$type] }, Assignment: { name: Pr.$type, properties: { cardinality: { name: Pr.cardinality }, feature: { name: Pr.feature }, operator: { name: Pr.operator }, predicate: { name: Pr.predicate }, terminal: { name: Pr.terminal } }, superTypes: [at.$type] }, BooleanLiteral: { name: Vo.$type, properties: { true: { name: Vo.true, defaultValue: !1 } }, superTypes: [Or.$type, vn.$type] }, CharacterRange: { name: kr.$type, properties: { cardinality: { name: kr.cardinality }, left: { name: kr.left }, lookahead: { name: kr.lookahead }, parenthesized: { name: kr.parenthesized, defaultValue: !1 }, right: { name: kr.right } }, superTypes: [it.$type] }, Condition: { name: Or.$type, properties: {}, superTypes: [] }, Conjunction: { name: Qi.$type, properties: { left: { name: Qi.left }, right: { name: Qi.right } }, superTypes: [Or.$type] }, CrossReference: { name: Lr.$type, properties: { cardinality: { name: Lr.cardinality }, deprecatedSyntax: { name: Lr.deprecatedSyntax, defaultValue: !1 }, isMulti: { name: Lr.isMulti, defaultValue: !1 }, terminal: { name: Lr.terminal }, type: { name: Lr.type, referenceType: pt.$type } }, superTypes: [at.$type] }, Disjunction: { name: es.$type, properties: { left: { name: es.left }, right: { name: es.right } }, superTypes: [Or.$type] }, EndOfFile: { name: Ho.$type, properties: { cardinality: { name: Ho.cardinality } }, superTypes: [at.$type] }, Grammar: { name: ur.$type, properties: { imports: { name: ur.imports, defaultValue: [] }, interfaces: { name: ur.interfaces, defaultValue: [] }, isDeclared: { name: ur.isDeclared, defaultValue: !1 }, name: { name: ur.name }, rules: { name: ur.rules, defaultValue: [] }, types: { name: ur.types, defaultValue: [] } }, superTypes: [] }, GrammarImport: { name: Yo.$type, properties: { path: { name: Yo.path } }, superTypes: [] }, Group: { name: ln.$type, properties: { cardinality: { name: ln.cardinality }, elements: { name: ln.elements, defaultValue: [] }, guardCondition: { name: ln.guardCondition }, predicate: { name: ln.predicate } }, superTypes: [at.$type] }, InferredType: { name: Xo.$type, properties: { name: { name: Xo.name } }, superTypes: [pt.$type] }, InfixRule: { name: qt.$type, properties: { call: { name: qt.call }, dataType: { name: qt.dataType }, inferredType: { name: qt.inferredType }, name: { name: qt.name }, operators: { name: qt.operators }, parameters: { name: qt.parameters, defaultValue: [] }, returnType: { name: qt.returnType, referenceType: pt.$type } }, superTypes: [Ji.$type] }, InfixRuleOperatorList: { name: ts.$type, properties: { associativity: { name: ts.associativity }, operators: { name: ts.operators, defaultValue: [] } }, superTypes: [] }, InfixRuleOperators: { name: Jo.$type, properties: { precedences: { name: Jo.precedences, defaultValue: [] } }, superTypes: [] }, Interface: { name: Ca.$type, properties: { attributes: { name: Ca.attributes, defaultValue: [] }, name: { name: Ca.name }, superTypes: { name: Ca.superTypes, defaultValue: [], referenceType: pt.$type } }, superTypes: [pt.$type] }, Keyword: { name: _a.$type, properties: { cardinality: { name: _a.cardinality }, predicate: { name: _a.predicate }, value: { name: _a.value } }, superTypes: [at.$type] }, NamedArgument: { name: Sa.$type, properties: { calledByName: { name: Sa.calledByName, defaultValue: !1 }, parameter: { name: Sa.parameter, referenceType: wa.$type }, value: { name: Sa.value } }, superTypes: [] }, NegatedToken: { name: un.$type, properties: { cardinality: { name: un.cardinality }, lookahead: { name: un.lookahead }, parenthesized: { name: un.parenthesized, defaultValue: !1 }, terminal: { name: un.terminal } }, superTypes: [it.$type] }, Negation: { name: Zo.$type, properties: { value: { name: Zo.value } }, superTypes: [Or.$type] }, NumberLiteral: { name: Qo.$type, properties: { value: { name: Qo.value } }, superTypes: [vn.$type] }, Parameter: { name: wa.$type, properties: { name: { name: wa.name } }, superTypes: [] }, ParameterReference: { name: el.$type, properties: { parameter: { name: el.parameter, referenceType: wa.$type } }, superTypes: [Or.$type] }, ParserRule: { name: wt.$type, properties: { dataType: { name: wt.dataType }, definition: { name: wt.definition }, entry: { name: wt.entry, defaultValue: !1 }, fragment: { name: wt.fragment, defaultValue: !1 }, inferredType: { name: wt.inferredType }, name: { name: wt.name }, parameters: { name: wt.parameters, defaultValue: [] }, returnType: { name: wt.returnType, referenceType: pt.$type } }, superTypes: [Ji.$type] }, ReferenceType: { name: rs.$type, properties: { isMulti: { name: rs.isMulti, defaultValue: !1 }, referenceType: { name: rs.referenceType } }, superTypes: [yn.$type] }, RegexToken: { name: cn.$type, properties: { cardinality: { name: cn.cardinality }, lookahead: { name: cn.lookahead }, parenthesized: { name: cn.parenthesized, defaultValue: !1 }, regex: { name: cn.regex } }, superTypes: [it.$type] }, ReturnType: { name: tl.$type, properties: { name: { name: tl.name } }, superTypes: [] }, RuleCall: { name: fn.$type, properties: { arguments: { name: fn.arguments, defaultValue: [] }, cardinality: { name: fn.cardinality }, predicate: { name: fn.predicate }, rule: { name: fn.rule, referenceType: ba.$type } }, superTypes: [at.$type] }, SimpleType: { name: Ia.$type, properties: { primitiveType: { name: Ia.primitiveType }, stringType: { name: Ia.stringType }, typeRef: { name: Ia.typeRef, referenceType: pt.$type } }, superTypes: [yn.$type] }, StringLiteral: { name: rl.$type, properties: { value: { name: rl.value } }, superTypes: [vn.$type] }, TerminalAlternatives: { name: pn.$type, properties: { cardinality: { name: pn.cardinality }, elements: { name: pn.elements, defaultValue: [] }, lookahead: { name: pn.lookahead }, parenthesized: { name: pn.parenthesized, defaultValue: !1 } }, superTypes: [it.$type] }, TerminalElement: { name: it.$type, properties: { cardinality: { name: it.cardinality }, lookahead: { name: it.lookahead }, parenthesized: { name: it.parenthesized, defaultValue: !1 } }, superTypes: [at.$type] }, TerminalGroup: { name: dn.$type, properties: { cardinality: { name: dn.cardinality }, elements: { name: dn.elements, defaultValue: [] }, lookahead: { name: dn.lookahead }, parenthesized: { name: dn.parenthesized, defaultValue: !1 } }, superTypes: [it.$type] }, TerminalRule: { name: cr.$type, properties: { definition: { name: cr.definition }, fragment: { name: cr.fragment, defaultValue: !1 }, hidden: { name: cr.hidden, defaultValue: !1 }, name: { name: cr.name }, type: { name: cr.type } }, superTypes: [ba.$type] }, TerminalRuleCall: { name: mn.$type, properties: { cardinality: { name: mn.cardinality }, lookahead: { name: mn.lookahead }, parenthesized: { name: mn.parenthesized, defaultValue: !1 }, rule: { name: mn.rule, referenceType: cr.$type } }, superTypes: [it.$type] }, Type: { name: ns.$type, properties: { name: { name: ns.name }, type: { name: ns.type } }, superTypes: [pt.$type] }, TypeAttribute: { name: hn.$type, properties: { defaultValue: { name: hn.defaultValue }, isOptional: { name: hn.isOptional, defaultValue: !1 }, name: { name: hn.name }, type: { name: hn.type } }, superTypes: [] }, TypeDefinition: { name: yn.$type, properties: {}, superTypes: [] }, UnionType: { name: nl.$type, properties: { types: { name: nl.types, defaultValue: [] } }, superTypes: [yn.$type] }, UnorderedGroup: { name: as.$type, properties: { cardinality: { name: as.cardinality }, elements: { name: as.elements, defaultValue: [] } }, superTypes: [at.$type] }, UntilToken: { name: gn.$type, properties: { cardinality: { name: gn.cardinality }, lookahead: { name: gn.lookahead }, parenthesized: { name: gn.parenthesized, defaultValue: !1 }, terminal: { name: gn.terminal } }, superTypes: [it.$type] }, ValueLiteral: { name: vn.$type, properties: {}, superTypes: [] }, Wildcard: { name: Na.$type, properties: { cardinality: { name: Na.cardinality }, lookahead: { name: Na.lookahead }, parenthesized: { name: Na.parenthesized, defaultValue: !1 } }, superTypes: [it.$type] } }; }
}, B = new Bp;
function ev(e) { let t = e, r = !1; for (; t;) {
    let n = Nn(t.grammarSource, et);
    if (n && n.dataType)
        t = t.container, r = !0;
    else
        return r ? t : void 0;
} }
s(ev, "getDatatypeNode");
function Ua(e) { return new Ga(e, t => dr(t) ? t.content : [], { includeRoot: !0 }); }
s(Ua, "streamCst");
function tv(e) { return Ua(e).filter(In); }
s(tv, "flattenCst");
function Kp(e, t) { for (; e.container;)
    if (e = e.container, e === t)
        return !0; return !1; }
s(Kp, "isChildNode");
function ms(e) { return { start: { character: e.startColumn - 1, line: e.startLine - 1 }, end: { character: e.endColumn, line: e.endLine - 1 } }; }
s(ms, "tokenToRange");
function Ba(e) { if (!e)
    return; let { offset: t, end: r, range: n } = e; return { range: n, offset: t, end: r, length: r - t }; }
s(Ba, "toDocumentSegment");
var fr = (function (e) { return e[e.Before = 0] = "Before", e[e.After = 1] = "After", e[e.OverlapFront = 2] = "OverlapFront", e[e.OverlapBack = 3] = "OverlapBack", e[e.Inside = 4] = "Inside", e[e.Outside = 5] = "Outside", e; })(fr || {});
function qp(e, t) { if (e.end.line < t.start.line || e.end.line === t.start.line && e.end.character <= t.start.character)
    return fr.Before; if (e.start.line > t.end.line || e.start.line === t.end.line && e.start.character >= t.end.character)
    return fr.After; let r = e.start.line > t.start.line || e.start.line === t.start.line && e.start.character >= t.start.character, n = e.end.line < t.end.line || e.end.line === t.end.line && e.end.character <= t.end.character; return r && n ? fr.Inside : r ? fr.OverlapBack : n ? fr.OverlapFront : fr.Outside; }
s(qp, "compareRange");
function Wp(e, t) { return qp(e, t) > fr.After; }
s(Wp, "inRange");
var Vp = /^[\w\p{L}]$/u;
function rv(e, t, r = Vp) { if (e) {
    if (t > 0) {
        let n = t - e.offset, a = e.text.charAt(n);
        r.test(a) || t--;
    }
    return zl(e, t);
} }
s(rv, "findDeclarationNodeAtOffset");
function Hp(e, t) { if (e) {
    let r = Jp(e, !0);
    if (r && al(r, t))
        return r;
    if (Ol(e)) {
        let n = e.content.findIndex(a => !a.hidden);
        for (let a = n - 1; a >= 0; a--) {
            let i = e.content[a];
            if (al(i, t))
                return i;
        }
    }
} }
s(Hp, "findCommentNode");
function al(e, t) { return In(e) && t.includes(e.tokenType.name); }
s(al, "isCommentNode");
function zl(e, t) { if (In(e))
    return e; if (dr(e)) {
    let r = Xp(e, t, !1);
    if (r)
        return zl(r, t);
} }
s(zl, "findLeafNodeAtOffset");
function Yp(e, t) { if (In(e))
    return e; if (dr(e)) {
    let r = Xp(e, t, !0);
    if (r)
        return Yp(r, t);
} }
s(Yp, "findLeafNodeBeforeOffset");
function Xp(e, t, r) { let n = 0, a = e.content.length - 1, i; for (; n <= a;) {
    let o = Math.floor((n + a) / 2), l = e.content[o];
    if (l.offset <= t && l.end > t)
        return l;
    l.end <= t ? (i = r ? l : void 0, n = o + 1) : a = o - 1;
} return i; }
s(Xp, "binarySearch");
function Jp(e, t = !0) { for (; e.container;) {
    let r = e.container, n = r.content.indexOf(e);
    for (; n > 0;) {
        n--;
        let a = r.content[n];
        if (t || !a.hidden)
            return a;
    }
    e = r;
} }
s(Jp, "getPreviousNode");
function nv(e, t = !0) { for (; e.container;) {
    let r = e.container, n = r.content.indexOf(e), a = r.content.length - 1;
    for (; n < a;) {
        n++;
        let i = r.content[n];
        if (t || !i.hidden)
            return i;
    }
    e = r;
} }
s(nv, "getNextNode");
function av(e) { if (e.range.start.character === 0)
    return e; let t = e.range.start.line, r = e, n; for (; e.container;) {
    let a = e.container, i = n ?? a.content.indexOf(e);
    if (i === 0 ? (e = a, n = void 0) : (n = i - 1, e = a.content[n]), e.range.start.line !== t)
        break;
    r = e;
} return r; }
s(av, "getStartlineNode");
function iv(e, t) { let r = sv(e, t); return r ? r.parent.content.slice(r.a + 1, r.b) : []; }
s(iv, "getInteriorNodes");
function sv(e, t) { let r = vf(e), n = vf(t), a; for (let i = 0; i < r.length && i < n.length; i++) {
    let o = r[i], l = n[i];
    if (o.parent === l.parent)
        a = { parent: o.parent, a: o.index, b: l.index };
    else
        break;
} return a; }
s(sv, "getCommonParent");
function vf(e) { let t = []; for (; e.container;) {
    let r = e.container, n = r.content.indexOf(e);
    t.push({ parent: r, index: n }), e = r;
} return t.reverse(); }
s(vf, "getParentChain");
var Zp = {};
zr(Zp, { findAssignment: () => fd, findNameAssignment: () => Hl, findNodeForKeyword: () => cd, findNodeForProperty: () => ql, findNodesForKeyword: () => dv, findNodesForKeywordInternal: () => Vl, findNodesForProperty: () => ud, getActionAtElement: () => dd, getActionType: () => hd, getAllReachableRules: () => Kl, getAllRulesUsedForCrossReferences: () => pv, getCrossReferenceTerminal: () => od, getEntryRule: () => ad, getExplicitRuleType: () => Ds, getHiddenRules: () => id, getRuleType: () => yd, getRuleTypeName: () => vv, getTypeName: () => bn, isArrayCardinality: () => hv, isArrayOperator: () => yv, isCommentTerminal: () => ld, isDataType: () => gv, isDataTypeRule: () => Ls, isOptionalCardinality: () => mv, terminalRegex: () => xs });
var jl = class extends Error {
    static { s(this, "ErrorWithLocation"); }
    constructor(e, t) { super(e ? `${t} at ${e.range.start.line}:${e.range.start.character}` : t); }
};
function jr(e, t = "Error: Got unexpected value.") { throw new Error(t); }
s(jr, "assertUnreachable");
function Qp(e, t = "Error: Condition is violated.") { if (!e)
    throw new Error(t); }
s(Qp, "assertCondition");
var ed = {};
zr(ed, { NEWLINE_REGEXP: () => lv, escapeRegExp: () => Xa, getTerminalParts: () => cv, isMultilineComment: () => td, isWhitespace: () => Bl, partialMatches: () => rd, partialRegExp: () => nd, whitespaceCharacters: () => fv });
function W(e) { return e.charCodeAt(0); }
s(W, "cc");
function Co(e, t) { Array.isArray(e) ? e.forEach(function (r) { t.push(r); }) : t.push(e); }
s(Co, "insertToSet");
function da(e, t) { if (e[t] === !0)
    throw "duplicate flag " + t; let r = e[t]; e[t] = !0; }
s(da, "addFlag");
function Qr(e) { if (e === void 0)
    throw Error("Internal Error - Should never get here!"); return !0; }
s(Qr, "ASSERT_EXISTS");
function Ki() { throw Error("Internal Error - Should never get here!"); }
s(Ki, "ASSERT_NEVER_REACH_HERE");
function Tf(e) { return e.type === "Character"; }
s(Tf, "isCharacter");
var il = [];
for (let e = W("0"); e <= W("9"); e++)
    il.push(e);
var sl = [W("_")].concat(il);
for (let e = W("a"); e <= W("z"); e++)
    sl.push(e);
for (let e = W("A"); e <= W("Z"); e++)
    sl.push(e);
var nh = [W(" "), W("\f"), W(`
`), W("\r"), W("	"), W("\v"), W("	"), W("\xA0"), W("\u1680"), W("\u2000"), W("\u2001"), W("\u2002"), W("\u2003"), W("\u2004"), W("\u2005"), W("\u2006"), W("\u2007"), W("\u2008"), W("\u2009"), W("\u200A"), W("\u2028"), W("\u2029"), W("\u202F"), W("\u205F"), W("\u3000"), W("\uFEFF")], yI = /[0-9a-fA-F]/, Zs = /[0-9]/, gI = /[1-9]/, ov = class {
    static { s(this, "RegExpParser"); }
    constructor() { this.idx = 0, this.input = "", this.groupIdx = 0; }
    saveState() { return { idx: this.idx, input: this.input, groupIdx: this.groupIdx }; }
    restoreState(e) { this.idx = e.idx, this.input = e.input, this.groupIdx = e.groupIdx; }
    pattern(e) { this.idx = 0, this.input = e, this.groupIdx = 0, this.consumeChar("/"); let t = this.disjunction(); this.consumeChar("/"); let r = { type: "Flags", loc: { begin: this.idx, end: e.length }, global: !1, ignoreCase: !1, multiLine: !1, unicode: !1, sticky: !1 }; for (; this.isRegExpFlag();)
        switch (this.popChar()) {
            case "g":
                da(r, "global");
                break;
            case "i":
                da(r, "ignoreCase");
                break;
            case "m":
                da(r, "multiLine");
                break;
            case "u":
                da(r, "unicode");
                break;
            case "y":
                da(r, "sticky");
                break;
        } if (this.idx !== this.input.length)
        throw Error("Redundant input: " + this.input.substring(this.idx)); return { type: "Pattern", flags: r, value: t, loc: this.loc(0) }; }
    disjunction() { let e = [], t = this.idx; for (e.push(this.alternative()); this.peekChar() === "|";)
        this.consumeChar("|"), e.push(this.alternative()); return { type: "Disjunction", value: e, loc: this.loc(t) }; }
    alternative() { let e = [], t = this.idx; for (; this.isTerm();)
        e.push(this.term()); return { type: "Alternative", value: e, loc: this.loc(t) }; }
    term() { return this.isAssertion() ? this.assertion() : this.atom(); }
    assertion() { let e = this.idx; switch (this.popChar()) {
        case "^": return { type: "StartAnchor", loc: this.loc(e) };
        case "$": return { type: "EndAnchor", loc: this.loc(e) };
        case "\\":
            switch (this.popChar()) {
                case "b": return { type: "WordBoundary", loc: this.loc(e) };
                case "B": return { type: "NonWordBoundary", loc: this.loc(e) };
            }
            throw Error("Invalid Assertion Escape");
        case "(":
            this.consumeChar("?");
            let t;
            switch (this.popChar()) {
                case "=":
                    t = "Lookahead";
                    break;
                case "!":
                    t = "NegativeLookahead";
                    break;
                case "<": {
                    switch (this.popChar()) {
                        case "=":
                            t = "Lookbehind";
                            break;
                        case "!": t = "NegativeLookbehind";
                    }
                    break;
                }
            }
            Qr(t);
            let r = this.disjunction();
            return this.consumeChar(")"), { type: t, value: r, loc: this.loc(e) };
    } return Ki(); }
    quantifier(e = !1) { let t, r = this.idx; switch (this.popChar()) {
        case "*":
            t = { atLeast: 0, atMost: 1 / 0 };
            break;
        case "+":
            t = { atLeast: 1, atMost: 1 / 0 };
            break;
        case "?":
            t = { atLeast: 0, atMost: 1 };
            break;
        case "{":
            let n = this.integerIncludingZero();
            switch (this.popChar()) {
                case "}":
                    t = { atLeast: n, atMost: n };
                    break;
                case ",":
                    let a;
                    this.isDigit() ? (a = this.integerIncludingZero(), t = { atLeast: n, atMost: a }) : t = { atLeast: n, atMost: 1 / 0 }, this.consumeChar("}");
                    break;
            }
            if (e === !0 && t === void 0)
                return;
            Qr(t);
            break;
    } if (!(e === !0 && t === void 0) && Qr(t))
        return this.peekChar(0) === "?" ? (this.consumeChar("?"), t.greedy = !1) : t.greedy = !0, t.type = "Quantifier", t.loc = this.loc(r), t; }
    atom() { let e, t = this.idx; switch (this.peekChar()) {
        case ".":
            e = this.dotAll();
            break;
        case "\\":
            e = this.atomEscape();
            break;
        case "[":
            e = this.characterClass();
            break;
        case "(":
            e = this.group();
            break;
    } return e === void 0 && this.isPatternCharacter() && (e = this.patternCharacter()), Qr(e) ? (e.loc = this.loc(t), this.isQuantifier() && (e.quantifier = this.quantifier()), e) : Ki(); }
    dotAll() {
        return this.consumeChar("."), { type: "Set", complement: !0, value: [W(`
`), W("\r"), W("\u2028"), W("\u2029")] };
    }
    atomEscape() { switch (this.consumeChar("\\"), this.peekChar()) {
        case "1":
        case "2":
        case "3":
        case "4":
        case "5":
        case "6":
        case "7":
        case "8":
        case "9": return this.decimalEscapeAtom();
        case "d":
        case "D":
        case "s":
        case "S":
        case "w":
        case "W": return this.characterClassEscape();
        case "f":
        case "n":
        case "r":
        case "t":
        case "v": return this.controlEscapeAtom();
        case "c": return this.controlLetterEscapeAtom();
        case "0": return this.nulCharacterAtom();
        case "x": return this.hexEscapeSequenceAtom();
        case "u": return this.regExpUnicodeEscapeSequenceAtom();
        default: return this.identityEscapeAtom();
    } }
    decimalEscapeAtom() { return { type: "GroupBackReference", value: this.positiveInteger() }; }
    characterClassEscape() { let e, t = !1; switch (this.popChar()) {
        case "d":
            e = il;
            break;
        case "D":
            e = il, t = !0;
            break;
        case "s":
            e = nh;
            break;
        case "S":
            e = nh, t = !0;
            break;
        case "w":
            e = sl;
            break;
        case "W":
            e = sl, t = !0;
            break;
    } return Qr(e) ? { type: "Set", value: e, complement: t } : Ki(); }
    controlEscapeAtom() {
        let e;
        switch (this.popChar()) {
            case "f":
                e = W("\f");
                break;
            case "n":
                e = W(`
`);
                break;
            case "r":
                e = W("\r");
                break;
            case "t":
                e = W("	");
                break;
            case "v":
                e = W("\v");
                break;
        }
        return Qr(e) ? { type: "Character", value: e } : Ki();
    }
    controlLetterEscapeAtom() { this.consumeChar("c"); let e = this.popChar(); if (/[a-zA-Z]/.test(e) === !1)
        throw Error("Invalid "); return { type: "Character", value: e.toUpperCase().charCodeAt(0) - 64 }; }
    nulCharacterAtom() { return this.consumeChar("0"), { type: "Character", value: W("\0") }; }
    hexEscapeSequenceAtom() { return this.consumeChar("x"), this.parseHexDigits(2); }
    regExpUnicodeEscapeSequenceAtom() { return this.consumeChar("u"), this.parseHexDigits(4); }
    identityEscapeAtom() { let e = this.popChar(); return { type: "Character", value: W(e) }; }
    classPatternCharacterAtom() {
        switch (this.peekChar()) {
            case `
`:
            case "\r":
            case "\u2028":
            case "\u2029":
            case "\\":
            case "]": throw Error("TBD");
            default:
                let e = this.popChar();
                return { type: "Character", value: W(e) };
        }
    }
    characterClass() { let e = [], t = !1; for (this.consumeChar("["), this.peekChar(0) === "^" && (this.consumeChar("^"), t = !0); this.isClassAtom();) {
        let r = this.classAtom(), n = r.type === "Character";
        if (Tf(r) && this.isRangeDash()) {
            this.consumeChar("-");
            let a = this.classAtom(), i = a.type === "Character";
            if (Tf(a)) {
                if (a.value < r.value)
                    throw Error("Range out of order in character class");
                e.push({ from: r.value, to: a.value });
            }
            else
                Co(r.value, e), e.push(W("-")), Co(a.value, e);
        }
        else
            Co(r.value, e);
    } return this.consumeChar("]"), { type: "Set", complement: t, value: e }; }
    classAtom() {
        switch (this.peekChar()) {
            case "]":
            case `
`:
            case "\r":
            case "\u2028":
            case "\u2029": throw Error("TBD");
            case "\\": return this.classEscape();
            default: return this.classPatternCharacterAtom();
        }
    }
    classEscape() { switch (this.consumeChar("\\"), this.peekChar()) {
        case "b": return this.consumeChar("b"), { type: "Character", value: W("\b") };
        case "d":
        case "D":
        case "s":
        case "S":
        case "w":
        case "W": return this.characterClassEscape();
        case "f":
        case "n":
        case "r":
        case "t":
        case "v": return this.controlEscapeAtom();
        case "c": return this.controlLetterEscapeAtom();
        case "0": return this.nulCharacterAtom();
        case "x": return this.hexEscapeSequenceAtom();
        case "u": return this.regExpUnicodeEscapeSequenceAtom();
        default: return this.identityEscapeAtom();
    } }
    group() { let e = !0; this.consumeChar("("), this.peekChar(0) === "?" ? (this.consumeChar("?"), this.consumeChar(":"), e = !1) : this.groupIdx++; let t = this.disjunction(); this.consumeChar(")"); let r = { type: "Group", capturing: e, value: t }; return e && (r.idx = this.groupIdx), r; }
    positiveInteger() { let e = this.popChar(); if (gI.test(e) === !1)
        throw Error("Expecting a positive integer"); for (; Zs.test(this.peekChar(0));)
        e += this.popChar(); return parseInt(e, 10); }
    integerIncludingZero() { let e = this.popChar(); if (Zs.test(e) === !1)
        throw Error("Expecting an integer"); for (; Zs.test(this.peekChar(0));)
        e += this.popChar(); return parseInt(e, 10); }
    patternCharacter() {
        let e = this.popChar();
        switch (e) {
            case `
`:
            case "\r":
            case "\u2028":
            case "\u2029":
            case "^":
            case "$":
            case "\\":
            case ".":
            case "*":
            case "+":
            case "?":
            case "(":
            case ")":
            case "[":
            case "|": throw Error("TBD");
            default: return { type: "Character", value: W(e) };
        }
    }
    isRegExpFlag() { switch (this.peekChar(0)) {
        case "g":
        case "i":
        case "m":
        case "u":
        case "y": return !0;
        default: return !1;
    } }
    isRangeDash() { return this.peekChar() === "-" && this.isClassAtom(1); }
    isDigit() { return Zs.test(this.peekChar(0)); }
    isClassAtom(e = 0) {
        switch (this.peekChar(e)) {
            case "]":
            case `
`:
            case "\r":
            case "\u2028":
            case "\u2029": return !1;
            default: return !0;
        }
    }
    isTerm() { return this.isAtom() || this.isAssertion(); }
    isAtom() { if (this.isPatternCharacter())
        return !0; switch (this.peekChar(0)) {
        case ".":
        case "\\":
        case "[":
        case "(": return !0;
        default: return !1;
    } }
    isAssertion() { switch (this.peekChar(0)) {
        case "^":
        case "$": return !0;
        case "\\": switch (this.peekChar(1)) {
            case "b":
            case "B": return !0;
            default: return !1;
        }
        case "(": return this.peekChar(1) === "?" && (this.peekChar(2) === "=" || this.peekChar(2) === "!" || this.peekChar(2) === "<" && (this.peekChar(3) === "=" || this.peekChar(3) === "!"));
        default: return !1;
    } }
    isQuantifier() { let e = this.saveState(); try {
        return this.quantifier(!0) !== void 0;
    }
    catch {
        return !1;
    }
    finally {
        this.restoreState(e);
    } }
    isPatternCharacter() {
        switch (this.peekChar()) {
            case "^":
            case "$":
            case "\\":
            case ".":
            case "*":
            case "+":
            case "?":
            case "(":
            case ")":
            case "[":
            case "|":
            case "/":
            case `
`:
            case "\r":
            case "\u2028":
            case "\u2029": return !1;
            default: return !0;
        }
    }
    parseHexDigits(e) { let t = ""; for (let n = 0; n < e; n++) {
        let a = this.popChar();
        if (yI.test(a) === !1)
            throw Error("Expecting a HexDecimal digits");
        t += a;
    } return { type: "Character", value: parseInt(t, 16) }; }
    peekChar(e = 0) { return this.input[this.idx + e]; }
    popChar() { let e = this.peekChar(0); return this.consumeChar(void 0), e; }
    consumeChar(e) { if (e !== void 0 && this.input[this.idx] !== e)
        throw Error("Expected: '" + e + "' but found: '" + this.input[this.idx] + "' at offset: " + this.idx); if (this.idx >= this.input.length)
        throw Error("Unexpected end of input"); this.idx++; }
    loc(e) { return { begin: e, end: this.idx }; }
}, Ul = class {
    static { s(this, "BaseRegExpVisitor"); }
    visitChildren(e) { for (let t in e) {
        let r = e[t];
        e.hasOwnProperty(t) && (r.type !== void 0 ? this.visit(r) : Array.isArray(r) && r.forEach(n => { this.visit(n); }, this));
    } }
    visit(e) { switch (e.type) {
        case "Pattern":
            this.visitPattern(e);
            break;
        case "Flags":
            this.visitFlags(e);
            break;
        case "Disjunction":
            this.visitDisjunction(e);
            break;
        case "Alternative":
            this.visitAlternative(e);
            break;
        case "StartAnchor":
            this.visitStartAnchor(e);
            break;
        case "EndAnchor":
            this.visitEndAnchor(e);
            break;
        case "WordBoundary":
            this.visitWordBoundary(e);
            break;
        case "NonWordBoundary":
            this.visitNonWordBoundary(e);
            break;
        case "Lookahead":
            this.visitLookahead(e);
            break;
        case "NegativeLookahead":
            this.visitNegativeLookahead(e);
            break;
        case "Lookbehind":
            this.visitLookbehind(e);
            break;
        case "NegativeLookbehind":
            this.visitNegativeLookbehind(e);
            break;
        case "Character":
            this.visitCharacter(e);
            break;
        case "Set":
            this.visitSet(e);
            break;
        case "Group":
            this.visitGroup(e);
            break;
        case "GroupBackReference":
            this.visitGroupBackReference(e);
            break;
        case "Quantifier":
            this.visitQuantifier(e);
            break;
    } this.visitChildren(e); }
    visitPattern(e) { }
    visitFlags(e) { }
    visitDisjunction(e) { }
    visitAlternative(e) { }
    visitStartAnchor(e) { }
    visitEndAnchor(e) { }
    visitWordBoundary(e) { }
    visitNonWordBoundary(e) { }
    visitLookahead(e) { }
    visitNegativeLookahead(e) { }
    visitLookbehind(e) { }
    visitNegativeLookbehind(e) { }
    visitCharacter(e) { }
    visitSet(e) { }
    visitGroup(e) { }
    visitGroupBackReference(e) { }
    visitQuantifier(e) { }
}, lv = /\r?\n/gm, uv = new ov, vI = class extends Ul {
    static { s(this, "TerminalRegExpVisitor"); }
    constructor() { super(...arguments), this.isStarting = !0, this.endRegexpStack = [], this.multiline = !1; }
    get endRegex() { return this.endRegexpStack.join(""); }
    reset(e) { this.multiline = !1, this.regex = e, this.startRegexp = "", this.isStarting = !0, this.endRegexpStack = []; }
    visitGroup(e) { e.quantifier && (this.isStarting = !1, this.endRegexpStack = []); }
    visitCharacter(e) {
        let t = String.fromCharCode(e.value);
        if (!this.multiline && t === `
` && (this.multiline = !0), e.quantifier)
            this.isStarting = !1, this.endRegexpStack = [];
        else {
            let r = Xa(t);
            this.endRegexpStack.push(r), this.isStarting && (this.startRegexp += r);
        }
    }
    visitSet(e) {
        if (!this.multiline) {
            let t = this.regex.substring(e.loc.begin, e.loc.end), r = new RegExp(t);
            this.multiline = !!`
`.match(r);
        }
        if (e.quantifier)
            this.isStarting = !1, this.endRegexpStack = [];
        else {
            let t = this.regex.substring(e.loc.begin, e.loc.end);
            this.endRegexpStack.push(t), this.isStarting && (this.startRegexp += t);
        }
    }
    visitChildren(e) { e.type === "Group" && e.quantifier || super.visitChildren(e); }
}, Tn = new vI;
function cv(e) { try {
    typeof e != "string" && (e = e.source), e = `/${e}/`;
    let t = uv.pattern(e), r = [];
    for (let n of t.value.value)
        Tn.reset(e), Tn.visit(n), r.push({ start: Tn.startRegexp, end: Tn.endRegex });
    return r;
}
catch {
    return [];
} }
s(cv, "getTerminalParts");
function td(e) { try {
    return typeof e == "string" && (e = new RegExp(e)), e = e.toString(), Tn.reset(e), Tn.visit(uv.pattern(e)), Tn.multiline;
}
catch {
    return !1;
} }
s(td, "isMultilineComment");
var fv = `\f
\r	\v \xA0\u1680\u2000\u2001\u2002\u2003\u2004\u2005\u2006\u2007\u2008\u2009\u200A\u2028\u2029\u202F\u205F\u3000\uFEFF`.split("");
function Bl(e) { let t = typeof e == "string" ? new RegExp(e) : e; return fv.some(r => t.test(r)); }
s(Bl, "isWhitespace");
function Xa(e) { return e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"); }
s(Xa, "escapeRegExp");
function rd(e, t) { let r = nd(e), n = t.match(r); return !!n && n[0].length > 0; }
s(rd, "partialMatches");
function nd(e) { typeof e == "string" && (e = new RegExp(e)); let t = e, r = e.source, n = 0; function a() { let i = "", o; function l(c) { i += r.substr(n, c), n += c; } s(l, "appendRaw"); function u(c) { i += "(?:" + r.substr(n, c) + "|$)", n += c; } for (s(u, "appendOptional"); n < r.length;)
    switch (r[n]) {
        case "\\":
            switch (r[n + 1]) {
                case "c":
                    u(3);
                    break;
                case "x":
                    u(4);
                    break;
                case "u":
                    t.unicode ? r[n + 2] === "{" ? u(r.indexOf("}", n) - n + 1) : u(6) : u(2);
                    break;
                case "p":
                case "P":
                    t.unicode ? u(r.indexOf("}", n) - n + 1) : u(2);
                    break;
                case "k":
                    u(r.indexOf(">", n) - n + 1);
                    break;
                default:
                    u(2);
                    break;
            }
            break;
        case "[":
            o = /\[(?:\\.|.)*?\]/g, o.lastIndex = n, o = o.exec(r) || [], u(o[0].length);
            break;
        case "|":
        case "^":
        case "$":
        case "*":
        case "+":
        case "?":
            l(1);
            break;
        case "{":
            o = /\{\d+,?\d*\}/g, o.lastIndex = n, o = o.exec(r), o ? l(o[0].length) : u(1);
            break;
        case "(":
            if (r[n + 1] === "?")
                switch (r[n + 2]) {
                    case ":":
                        i += "(?:", n += 3, i += a() + "|$)";
                        break;
                    case "=":
                        i += "(?=", n += 3, i += a() + ")";
                        break;
                    case "!":
                        o = n, n += 3, a(), i += r.substr(o, n - o);
                        break;
                    case "<":
                        switch (r[n + 3]) {
                            case "=":
                            case "!":
                                o = n, n += 4, a(), i += r.substr(o, n - o);
                                break;
                            default:
                                l(r.indexOf(">", n) - n + 1), i += a() + "|$)";
                                break;
                        }
                        break;
                }
            else
                l(1), i += a() + "|$)";
            break;
        case ")": return ++n, i;
        default:
            u(1);
            break;
    } return i; } return s(a, "process"), new RegExp(a(), e.flags); }
s(nd, "partialRegExp");
function ad(e) { return e.rules.find(t => et(t) && t.entry); }
s(ad, "getEntryRule");
function id(e) { return e.rules.filter(t => bt(t) && t.hidden); }
s(id, "getHiddenRules");
function Kl(e, t) { let r = new Set, n = ad(e); if (!n)
    return new Set(e.rules); let a = [n].concat(id(e)); for (let o of a)
    sd(o, r, t); let i = new Set; for (let o of e.rules)
    (r.has(o.name) || bt(o) && o.hidden) && i.add(o); return i; }
s(Kl, "getAllReachableRules");
function sd(e, t, r) { t.add(e.name), Er(e).forEach(n => { if (yr(n) || r && Ml(n)) {
    let a = n.rule.ref;
    a && !t.has(a.name) && sd(a, t, r);
} }); }
s(sd, "ruleDfs");
function pv(e) { let t = new Set; return Er(e).forEach(r => { kn(r) && (et(r.type.ref) && t.add(r.type.ref), Os(r.type.ref) && et(r.type.ref.$container) && t.add(r.type.ref.$container)); }), t; }
s(pv, "getAllRulesUsedForCrossReferences");
function od(e) { if (e.terminal)
    return e.terminal; if (e.type.ref)
    return Hl(e.type.ref)?.terminal; }
s(od, "getCrossReferenceTerminal");
function ld(e) { return e.hidden && !Bl(xs(e)); }
s(ld, "isCommentTerminal");
function ud(e, t) { return !e || !t ? [] : Wl(e, t, e.astNode, !0); }
s(ud, "findNodesForProperty");
function ql(e, t, r) { if (!e || !t)
    return; let n = Wl(e, t, e.astNode, !0); if (n.length !== 0)
    return r !== void 0 ? r = Math.max(0, Math.min(r, n.length - 1)) : r = 0, n[r]; }
s(ql, "findNodeForProperty");
function Wl(e, t, r, n) { if (!n) {
    let a = Nn(e.grammarSource, mr);
    if (a && a.feature === t)
        return [e];
} return dr(e) && e.astNode === r ? e.content.flatMap(a => Wl(a, t, r, !1)) : []; }
s(Wl, "findNodesForPropertyInternal");
function dv(e, t) { return e ? Vl(e, t, e?.astNode) : []; }
s(dv, "findNodesForKeyword");
function cd(e, t, r) { if (!e)
    return; let n = Vl(e, t, e?.astNode); if (n.length !== 0)
    return r !== void 0 ? r = Math.max(0, Math.min(r, n.length - 1)) : r = 0, n[r]; }
s(cd, "findNodeForKeyword");
function Vl(e, t, r) { if (e.astNode !== r)
    return []; if (hr(e.grammarSource) && e.grammarSource.value === t)
    return [e]; let n = Ua(e).iterator(), a, i = []; do
    if (a = n.next(), !a.done) {
        let o = a.value;
        o.astNode === r ? hr(o.grammarSource) && o.grammarSource.value === t && i.push(o) : n.prune();
    }
while (!a.done); return i; }
s(Vl, "findNodesForKeywordInternal");
function fd(e) { let t = e.astNode; for (; t === e.container?.astNode;) {
    let r = Nn(e.grammarSource, mr);
    if (r)
        return r;
    e = e.container;
} }
s(fd, "findAssignment");
function Hl(e) { let t = e; return Os(t) && (Dr(t.$container) ? t = t.$container.$container : Pn(t.$container) ? t = t.$container : jr(t.$container)), pd(e, t, new Map); }
s(Hl, "findNameAssignment");
function pd(e, t, r) { function n(a, i) { let o; return Nn(a, mr) || (o = pd(i, i, r)), r.set(e, o), o; } if (s(n, "go"), r.has(e))
    return r.get(e); r.set(e, void 0); for (let a of Er(t)) {
    if (mr(a) && a.feature.toLowerCase() === "name")
        return r.set(e, a), a;
    if (yr(a) && et(a.rule.ref))
        return n(a, a.rule.ref);
    if (xl(a) && a.typeRef?.ref)
        return n(a, a.typeRef.ref);
} }
s(pd, "findNameAssignmentInternal");
function dd(e) { let t = e.$container; if (On(t)) {
    let r = t.elements, n = r.indexOf(e);
    for (let a = n - 1; a >= 0; a--) {
        let i = r[a];
        if (Dr(i))
            return i;
        {
            let o = Er(r[a]).find(Dr);
            if (o)
                return o;
        }
    }
} if (Ll(t))
    return dd(t); }
s(dd, "getActionAtElement");
function mv(e, t) { return e === "?" || e === "*" || On(t) && !!t.guardCondition; }
s(mv, "isOptionalCardinality");
function hv(e) { return e === "*" || e === "+"; }
s(hv, "isArrayCardinality");
function yv(e) { return e === "+="; }
s(yv, "isArrayOperator");
function Ls(e) { return md(e, new Set); }
s(Ls, "isDataTypeRule");
function md(e, t) { if (t.has(e))
    return !0; t.add(e); for (let r of Er(e))
    if (yr(r)) {
        if (!r.rule.ref || et(r.rule.ref) && !md(r.rule.ref, t) || ja(r.rule.ref))
            return !1;
    }
    else {
        if (mr(r))
            return !1;
        if (Dr(r))
            return !1;
    } return !!e.definition; }
s(md, "isDataTypeRuleInternal");
function gv(e) { return ol(e.type, new Set); }
s(gv, "isDataType");
function ol(e, t) { if (t.has(e))
    return !0; if (t.add(e), Cp(e))
    return !1; if (Dp(e))
    return !1; if (zp(e))
    return e.types.every(r => ol(r, t)); if (xl(e)) {
    if (e.primitiveType !== void 0)
        return !0;
    if (e.stringType !== void 0)
        return !0;
    if (e.typeRef !== void 0) {
        let r = e.typeRef.ref;
        return Gl(r) ? ol(r.type, t) : !1;
    }
    else
        return !1;
}
else
    return !1; }
s(ol, "isDataTypeInternal");
function Ds(e) { if (!bt(e)) {
    if (e.inferredType)
        return e.inferredType.name;
    if (e.dataType)
        return e.dataType;
    if (e.returnType) {
        let t = e.returnType.ref;
        if (t)
            return t.name;
    }
} }
s(Ds, "getExplicitRuleType");
function bn(e) { if (Pn(e))
    return et(e) && Ls(e) ? e.name : Ds(e) ?? e.name; if (Pp(e) || Gl(e) || Mp(e))
    return e.name; if (Dr(e)) {
    let t = hd(e);
    if (t)
        return t;
}
else if (Os(e))
    return e.name; throw new Error("Cannot get name of Unknown Type"); }
s(bn, "getTypeName");
function hd(e) { if (e.inferredType)
    return e.inferredType.name; if (e.type?.ref)
    return bn(e.type.ref); }
s(hd, "getActionType");
function vv(e) { return bt(e) ? e.type?.name ?? "string" : et(e) && Ls(e) ? e.name : Ds(e) ?? e.name; }
s(vv, "getRuleTypeName");
function yd(e) { return bt(e) ? e.type?.name ?? "string" : Ds(e) ?? e.name; }
s(yd, "getRuleType");
function xs(e) { let t = { s: !1, i: !1, u: !1 }, r = Ln(e.definition, t), n = Object.entries(t).filter(([, a]) => a).map(([a]) => a).join(""); return new RegExp(r, n); }
s(xs, "terminalRegex");
var gd = /[\s\S]/.source;
function Ln(e, t) { if (Gp(e))
    return Tv(e); if (Fp(e))
    return $v(e); if (Sp(e))
    return Ev(e); if (Ml(e)) {
    let r = e.rule.ref;
    if (!r)
        throw new Error("Missing rule reference.");
    return Xt(Ln(r.definition), { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized });
}
else {
    if (kp(e))
        return Av(e);
    if (jp(e))
        return Rv(e);
    if (xp(e)) {
        let r = e.regex.lastIndexOf("/"), n = e.regex.substring(1, r), a = e.regex.substring(r + 1);
        return t && (t.i = a.includes("i"), t.s = a.includes("s"), t.u = a.includes("u")), Xt(n, { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized, wrap: !1 });
    }
    else {
        if (Up(e))
            return Xt(gd, { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized });
        throw new Error(`Invalid terminal element: ${e?.$type}, ${e?.$cstNode?.text}`);
    }
} }
s(Ln, "abstractElementToRegex");
function Tv(e) { return Xt(e.elements.map(t => Ln(t)).join("|"), { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized, wrap: !1 }); }
s(Tv, "terminalAlternativesToRegex");
function $v(e) { return Xt(e.elements.map(t => Ln(t)).join(""), { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized, wrap: !1 }); }
s($v, "terminalGroupToRegex");
function Rv(e) { return Xt(`${gd}*?${Ln(e.terminal)}`, { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized }); }
s(Rv, "untilTokenToRegex");
function Av(e) { return Xt(`(?!${Ln(e.terminal)})${gd}*?`, { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized }); }
s(Av, "negateTokenToRegex");
function Ev(e) { return e.right ? Xt(`[${_o(e.left)}-${_o(e.right)}]`, { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized, wrap: !1 }) : Xt(_o(e.left), { cardinality: e.cardinality, lookahead: e.lookahead, parenthesized: e.parenthesized, wrap: !1 }); }
s(Ev, "characterRangeToRegex");
function _o(e) { return Xa(e.value); }
s(_o, "keywordToRegex");
function Xt(e, t) { return (t.parenthesized || t.lookahead || t.wrap !== !1) && (e = `(${t.lookahead ?? (t.parenthesized ? "" : "?:")}${e})`), t.cardinality ? `${e}${t.cardinality}` : e; }
s(Xt, "withCardinality");
function vd(e) { let t = [], r = e.Grammar; for (let n of r.rules)
    bt(n) && ld(n) && td(xs(n)) && t.push(n.name); return { multilineCommentRules: t, nameRegexp: Vp }; }
s(vd, "createGrammarConfig");
var TI = typeof global == "object" && global && global.Object === Object && global, bv = TI, $I = typeof self == "object" && self && self.Object === Object && self, RI = bv || $I || Function("return this")(), Zt = RI, AI = Zt.Symbol, At = AI, Cv = Object.prototype, EI = Cv.hasOwnProperty, bI = Cv.toString, _i = At ? At.toStringTag : void 0;
function _v(e) { var t = EI.call(e, _i), r = e[_i]; try {
    e[_i] = void 0;
    var n = !0;
}
catch { } var a = bI.call(e); return n && (t ? e[_i] = r : delete e[_i]), a; }
s(_v, "getRawTag");
var CI = _v, _I = Object.prototype, SI = _I.toString;
function Sv(e) { return SI.call(e); }
s(Sv, "objectToString");
var wI = Sv, II = "[object Null]", NI = "[object Undefined]", ah = At ? At.toStringTag : void 0;
function wv(e) { return e == null ? e === void 0 ? NI : II : ah && ah in Object(e) ? CI(e) : wI(e); }
s(wv, "baseGetTag");
var Ur = wv;
function Iv(e) { return e != null && typeof e == "object"; }
s(Iv, "isObjectLike");
var xt = Iv, PI = "[object Symbol]";
function Nv(e) { return typeof e == "symbol" || xt(e) && Ur(e) == PI; }
s(Nv, "isSymbol");
var Yl = Nv;
function Pv(e, t) { for (var r = -1, n = e == null ? 0 : e.length, a = Array(n); ++r < n;)
    a[r] = t(e[r], r, e); return a; }
s(Pv, "arrayMap");
var Ms = Pv, kI = Array.isArray, te = kI, OI = 1 / 0, ih = At ? At.prototype : void 0, sh = ih ? ih.toString : void 0;
function Td(e) { if (typeof e == "string")
    return e; if (te(e))
    return Ms(e, Td) + ""; if (Yl(e))
    return sh ? sh.call(e) : ""; var t = e + ""; return t == "0" && 1 / e == -OI ? "-0" : t; }
s(Td, "baseToString");
var LI = Td, DI = /\s/;
function kv(e) { for (var t = e.length; t-- && DI.test(e.charAt(t));)
    ; return t; }
s(kv, "trimmedEndIndex");
var xI = kv, MI = /^\s+/;
function Ov(e) { return e && e.slice(0, xI(e) + 1).replace(MI, ""); }
s(Ov, "baseTrim");
var GI = Ov;
function Lv(e) { var t = typeof e; return e != null && (t == "object" || t == "function"); }
s(Lv, "isObject");
var Et = Lv, oh = NaN, FI = /^[-+]0x[0-9a-f]+$/i, zI = /^0b[01]+$/i, jI = /^0o[0-7]+$/i, UI = parseInt;
function Dv(e) { if (typeof e == "number")
    return e; if (Yl(e))
    return oh; if (Et(e)) {
    var t = typeof e.valueOf == "function" ? e.valueOf() : e;
    e = Et(t) ? t + "" : t;
} if (typeof e != "string")
    return e === 0 ? e : +e; e = GI(e); var r = zI.test(e); return r || jI.test(e) ? UI(e.slice(2), r ? 2 : 8) : FI.test(e) ? oh : +e; }
s(Dv, "toNumber");
var BI = Dv, lh = 1 / 0, KI = 17976931348623157e292;
function xv(e) { if (!e)
    return e === 0 ? e : 0; if (e = BI(e), e === lh || e === -lh) {
    var t = e < 0 ? -1 : 1;
    return t * KI;
} return e === e ? e : 0; }
s(xv, "toFinite");
var qI = xv;
function Mv(e) { var t = qI(e), r = t % 1; return t === t ? r ? t - r : t : 0; }
s(Mv, "toInteger");
var Gs = Mv;
function Gv(e) { return e; }
s(Gv, "identity");
var Fs = Gv, WI = "[object AsyncFunction]", VI = "[object Function]", HI = "[object GeneratorFunction]", YI = "[object Proxy]";
function Fv(e) { if (!Et(e))
    return !1; var t = Ur(e); return t == VI || t == HI || t == WI || t == YI; }
s(Fv, "isFunction");
var br = Fv, XI = Zt["__core-js_shared__"], ju = XI, uh = (function () { var e = /[^.]+$/.exec(ju && ju.keys && ju.keys.IE_PROTO || ""); return e ? "Symbol(src)_1." + e : ""; })();
function zv(e) { return !!uh && uh in e; }
s(zv, "isMasked");
var JI = zv, ZI = Function.prototype, QI = ZI.toString;
function jv(e) { if (e != null) {
    try {
        return QI.call(e);
    }
    catch { }
    try {
        return e + "";
    }
    catch { }
} return ""; }
s(jv, "toSource");
var Dn = jv, eN = /[\\^$.*+?()[\]{}|]/g, tN = /^\[object .+?Constructor\]$/, rN = Function.prototype, nN = Object.prototype, aN = rN.toString, iN = nN.hasOwnProperty, sN = RegExp("^" + aN.call(iN).replace(eN, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
function Uv(e) { if (!Et(e) || JI(e))
    return !1; var t = br(e) ? sN : tN; return t.test(Dn(e)); }
s(Uv, "baseIsNative");
var oN = Uv;
function Bv(e, t) { return e?.[t]; }
s(Bv, "getValue");
var lN = Bv;
function Kv(e, t) { var r = lN(e, t); return oN(r) ? r : void 0; }
s(Kv, "getNative");
var xn = Kv, uN = xn(Zt, "WeakMap"), $f = uN, ch = Object.create, cN = (function () { function e() { } return s(e, "object"), function (t) { if (!Et(t))
    return {}; if (ch)
    return ch(t); e.prototype = t; var r = new e; return e.prototype = void 0, r; }; })(), fN = cN;
function qv(e, t, r) { switch (r.length) {
    case 0: return e.call(t);
    case 1: return e.call(t, r[0]);
    case 2: return e.call(t, r[0], r[1]);
    case 3: return e.call(t, r[0], r[1], r[2]);
} return e.apply(t, r); }
s(qv, "apply");
var pN = qv;
function Wv() { }
s(Wv, "noop");
var ze = Wv;
function Vv(e, t) { var r = -1, n = e.length; for (t || (t = Array(n)); ++r < n;)
    t[r] = e[r]; return t; }
s(Vv, "copyArray");
var dN = Vv, mN = 800, hN = 16, yN = Date.now;
function Hv(e) { var t = 0, r = 0; return function () { var n = yN(), a = hN - (n - r); if (r = n, a > 0) {
    if (++t >= mN)
        return arguments[0];
}
else
    t = 0; return e.apply(void 0, arguments); }; }
s(Hv, "shortOut");
var gN = Hv;
function Yv(e) { return function () { return e; }; }
s(Yv, "constant");
var vN = Yv, TN = (function () { try {
    var e = xn(Object, "defineProperty");
    return e({}, "", {}), e;
}
catch { } })(), ll = TN, $N = ll ? function (e, t) { return ll(e, "toString", { configurable: !0, enumerable: !1, value: vN(t), writable: !0 }); } : Fs, RN = $N, AN = gN(RN), EN = AN;
function Xv(e, t) { for (var r = -1, n = e == null ? 0 : e.length; ++r < n && t(e[r], r, e) !== !1;)
    ; return e; }
s(Xv, "arrayEach");
var Jv = Xv;
function Zv(e, t, r, n) { for (var a = e.length, i = r + (n ? 1 : -1); n ? i-- : ++i < a;)
    if (t(e[i], i, e))
        return i; return -1; }
s(Zv, "baseFindIndex");
var Qv = Zv;
function eT(e) { return e !== e; }
s(eT, "baseIsNaN");
var bN = eT;
function tT(e, t, r) { for (var n = r - 1, a = e.length; ++n < a;)
    if (e[n] === t)
        return n; return -1; }
s(tT, "strictIndexOf");
var CN = tT;
function rT(e, t, r) { return t === t ? CN(e, t, r) : Qv(e, bN, r); }
s(rT, "baseIndexOf");
var $d = rT;
function nT(e, t) { var r = e == null ? 0 : e.length; return !!r && $d(e, t, 0) > -1; }
s(nT, "arrayIncludes");
var aT = nT, _N = 9007199254740991, SN = /^(?:0|[1-9]\d*)$/;
function iT(e, t) { var r = typeof e; return t = t ?? _N, !!t && (r == "number" || r != "symbol" && SN.test(e)) && e > -1 && e % 1 == 0 && e < t; }
s(iT, "isIndex");
var Xl = iT;
function sT(e, t, r) { t == "__proto__" && ll ? ll(e, t, { configurable: !0, enumerable: !0, value: r, writable: !0 }) : e[t] = r; }
s(sT, "baseAssignValue");
var Rd = sT;
function oT(e, t) { return e === t || e !== e && t !== t; }
s(oT, "eq");
var zs = oT, wN = Object.prototype, IN = wN.hasOwnProperty;
function lT(e, t, r) { var n = e[t]; (!(IN.call(e, t) && zs(n, r)) || r === void 0 && !(t in e)) && Rd(e, t, r); }
s(lT, "assignValue");
var Jl = lT;
function uT(e, t, r, n) { var a = !r; r || (r = {}); for (var i = -1, o = t.length; ++i < o;) {
    var l = t[i], u = n ? n(r[l], e[l], l, r, e) : void 0;
    u === void 0 && (u = e[l]), a ? Rd(r, l, u) : Jl(r, l, u);
} return r; }
s(uT, "copyObject");
var js = uT, fh = Math.max;
function cT(e, t, r) { return t = fh(t === void 0 ? e.length - 1 : t, 0), function () { for (var n = arguments, a = -1, i = fh(n.length - t, 0), o = Array(i); ++a < i;)
    o[a] = n[t + a]; a = -1; for (var l = Array(t + 1); ++a < t;)
    l[a] = n[a]; return l[t] = r(o), pN(e, this, l); }; }
s(cT, "overRest");
var NN = cT;
function fT(e, t) { return EN(NN(e, t, Fs), e + ""); }
s(fT, "baseRest");
var Ad = fT, PN = 9007199254740991;
function pT(e) { return typeof e == "number" && e > -1 && e % 1 == 0 && e <= PN; }
s(pT, "isLength");
var Ed = pT;
function dT(e) { return e != null && Ed(e.length) && !br(e); }
s(dT, "isArrayLike");
var Qt = dT;
function mT(e, t, r) { if (!Et(r))
    return !1; var n = typeof t; return (n == "number" ? Qt(r) && Xl(t, r.length) : n == "string" && t in r) ? zs(r[t], e) : !1; }
s(mT, "isIterateeCall");
var Zl = mT;
function hT(e) { return Ad(function (t, r) { var n = -1, a = r.length, i = a > 1 ? r[a - 1] : void 0, o = a > 2 ? r[2] : void 0; for (i = e.length > 3 && typeof i == "function" ? (a--, i) : void 0, o && Zl(r[0], r[1], o) && (i = a < 3 ? void 0 : i, a = 1), t = Object(t); ++n < a;) {
    var l = r[n];
    l && e(t, l, n, i);
} return t; }); }
s(hT, "createAssigner");
var kN = hT, ON = Object.prototype;
function yT(e) { var t = e && e.constructor, r = typeof t == "function" && t.prototype || ON; return e === r; }
s(yT, "isPrototype");
var Us = yT;
function gT(e, t) { for (var r = -1, n = Array(e); ++r < e;)
    n[r] = t(r); return n; }
s(gT, "baseTimes");
var LN = gT, DN = "[object Arguments]";
function vT(e) { return xt(e) && Ur(e) == DN; }
s(vT, "baseIsArguments");
var ph = vT, TT = Object.prototype, xN = TT.hasOwnProperty, MN = TT.propertyIsEnumerable, GN = ph((function () { return arguments; })()) ? ph : function (e) { return xt(e) && xN.call(e, "callee") && !MN.call(e, "callee"); }, Ql = GN;
function $T() { return !1; }
s($T, "stubFalse");
var FN = $T, RT = typeof exports == "object" && exports && !exports.nodeType && exports, dh = RT && typeof module == "object" && module && !module.nodeType && module, zN = dh && dh.exports === RT, mh = zN ? Zt.Buffer : void 0, jN = mh ? mh.isBuffer : void 0, UN = jN || FN, hs = UN, BN = "[object Arguments]", KN = "[object Array]", qN = "[object Boolean]", WN = "[object Date]", VN = "[object Error]", HN = "[object Function]", YN = "[object Map]", XN = "[object Number]", JN = "[object Object]", ZN = "[object RegExp]", QN = "[object Set]", eP = "[object String]", tP = "[object WeakMap]", rP = "[object ArrayBuffer]", nP = "[object DataView]", aP = "[object Float32Array]", iP = "[object Float64Array]", sP = "[object Int8Array]", oP = "[object Int16Array]", lP = "[object Int32Array]", uP = "[object Uint8Array]", cP = "[object Uint8ClampedArray]", fP = "[object Uint16Array]", pP = "[object Uint32Array]", ve = {};
ve[aP] = ve[iP] = ve[sP] = ve[oP] = ve[lP] = ve[uP] = ve[cP] = ve[fP] = ve[pP] = !0;
ve[BN] = ve[KN] = ve[rP] = ve[qN] = ve[nP] = ve[WN] = ve[VN] = ve[HN] = ve[YN] = ve[XN] = ve[JN] = ve[ZN] = ve[QN] = ve[eP] = ve[tP] = !1;
function AT(e) { return xt(e) && Ed(e.length) && !!ve[Ur(e)]; }
s(AT, "baseIsTypedArray");
var dP = AT;
function ET(e) { return function (t) { return e(t); }; }
s(ET, "baseUnary");
var Bs = ET, bT = typeof exports == "object" && exports && !exports.nodeType && exports, is = bT && typeof module == "object" && module && !module.nodeType && module, mP = is && is.exports === bT, Uu = mP && bv.process, hP = (function () { try {
    var e = is && is.require && is.require("util").types;
    return e || Uu && Uu.binding && Uu.binding("util");
}
catch { } })(), xr = hP, hh = xr && xr.isTypedArray, yP = hh ? Bs(hh) : dP, bd = yP, gP = Object.prototype, vP = gP.hasOwnProperty;
function CT(e, t) { var r = te(e), n = !r && Ql(e), a = !r && !n && hs(e), i = !r && !n && !a && bd(e), o = r || n || a || i, l = o ? LN(e.length, String) : [], u = l.length; for (var c in e)
    (t || vP.call(e, c)) && !(o && (c == "length" || a && (c == "offset" || c == "parent") || i && (c == "buffer" || c == "byteLength" || c == "byteOffset") || Xl(c, u))) && l.push(c); return l; }
s(CT, "arrayLikeKeys");
var _T = CT;
function ST(e, t) { return function (r) { return e(t(r)); }; }
s(ST, "overArg");
var wT = ST, TP = wT(Object.keys, Object), $P = TP, RP = Object.prototype, AP = RP.hasOwnProperty;
function IT(e) { if (!Us(e))
    return $P(e); var t = []; for (var r in Object(e))
    AP.call(e, r) && r != "constructor" && t.push(r); return t; }
s(IT, "baseKeys");
var NT = IT;
function PT(e) { return Qt(e) ? _T(e) : NT(e); }
s(PT, "keys");
var ht = PT, EP = Object.prototype, bP = EP.hasOwnProperty, CP = kN(function (e, t) { if (Us(t) || Qt(t)) {
    js(t, ht(t), e);
    return;
} for (var r in t)
    bP.call(t, r) && Jl(e, r, t[r]); }), yt = CP;
function kT(e) { var t = []; if (e != null)
    for (var r in Object(e))
        t.push(r); return t; }
s(kT, "nativeKeysIn");
var _P = kT, SP = Object.prototype, wP = SP.hasOwnProperty;
function OT(e) { if (!Et(e))
    return _P(e); var t = Us(e), r = []; for (var n in e)
    n == "constructor" && (t || !wP.call(e, n)) || r.push(n); return r; }
s(OT, "baseKeysIn");
var IP = OT;
function LT(e) { return Qt(e) ? _T(e, !0) : IP(e); }
s(LT, "keysIn");
var eu = LT, NP = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, PP = /^\w*$/;
function DT(e, t) { if (te(e))
    return !1; var r = typeof e; return r == "number" || r == "symbol" || r == "boolean" || e == null || Yl(e) ? !0 : PP.test(e) || !NP.test(e) || t != null && e in Object(t); }
s(DT, "isKey");
var Cd = DT, kP = xn(Object, "create"), ys = kP;
function xT() { this.__data__ = ys ? ys(null) : {}, this.size = 0; }
s(xT, "hashClear");
var OP = xT;
function MT(e) { var t = this.has(e) && delete this.__data__[e]; return this.size -= t ? 1 : 0, t; }
s(MT, "hashDelete");
var LP = MT, DP = "__lodash_hash_undefined__", xP = Object.prototype, MP = xP.hasOwnProperty;
function GT(e) { var t = this.__data__; if (ys) {
    var r = t[e];
    return r === DP ? void 0 : r;
} return MP.call(t, e) ? t[e] : void 0; }
s(GT, "hashGet");
var GP = GT, FP = Object.prototype, zP = FP.hasOwnProperty;
function FT(e) { var t = this.__data__; return ys ? t[e] !== void 0 : zP.call(t, e); }
s(FT, "hashHas");
var jP = FT, UP = "__lodash_hash_undefined__";
function zT(e, t) { var r = this.__data__; return this.size += this.has(e) ? 0 : 1, r[e] = ys && t === void 0 ? UP : t, this; }
s(zT, "hashSet");
var BP = zT;
function Mn(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(Mn, "Hash");
Mn.prototype.clear = OP;
Mn.prototype.delete = LP;
Mn.prototype.get = GP;
Mn.prototype.has = jP;
Mn.prototype.set = BP;
var yh = Mn;
function jT() { this.__data__ = [], this.size = 0; }
s(jT, "listCacheClear");
var KP = jT;
function UT(e, t) { for (var r = e.length; r--;)
    if (zs(e[r][0], t))
        return r; return -1; }
s(UT, "assocIndexOf");
var tu = UT, qP = Array.prototype, WP = qP.splice;
function BT(e) { var t = this.__data__, r = tu(t, e); if (r < 0)
    return !1; var n = t.length - 1; return r == n ? t.pop() : WP.call(t, r, 1), --this.size, !0; }
s(BT, "listCacheDelete");
var VP = BT;
function KT(e) { var t = this.__data__, r = tu(t, e); return r < 0 ? void 0 : t[r][1]; }
s(KT, "listCacheGet");
var HP = KT;
function qT(e) { return tu(this.__data__, e) > -1; }
s(qT, "listCacheHas");
var YP = qT;
function WT(e, t) { var r = this.__data__, n = tu(r, e); return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this; }
s(WT, "listCacheSet");
var XP = WT;
function Gn(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(Gn, "ListCache");
Gn.prototype.clear = KP;
Gn.prototype.delete = VP;
Gn.prototype.get = HP;
Gn.prototype.has = YP;
Gn.prototype.set = XP;
var ru = Gn, JP = xn(Zt, "Map"), gs = JP;
function VT() { this.size = 0, this.__data__ = { hash: new yh, map: new (gs || ru), string: new yh }; }
s(VT, "mapCacheClear");
var ZP = VT;
function HT(e) { var t = typeof e; return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null; }
s(HT, "isKeyable");
var QP = HT;
function YT(e, t) { var r = e.__data__; return QP(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map; }
s(YT, "getMapData");
var nu = YT;
function XT(e) { var t = nu(this, e).delete(e); return this.size -= t ? 1 : 0, t; }
s(XT, "mapCacheDelete");
var ek = XT;
function JT(e) { return nu(this, e).get(e); }
s(JT, "mapCacheGet");
var tk = JT;
function ZT(e) { return nu(this, e).has(e); }
s(ZT, "mapCacheHas");
var rk = ZT;
function QT(e, t) { var r = nu(this, e), n = r.size; return r.set(e, t), this.size += r.size == n ? 0 : 1, this; }
s(QT, "mapCacheSet");
var nk = QT;
function Fn(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(Fn, "MapCache");
Fn.prototype.clear = ZP;
Fn.prototype.delete = ek;
Fn.prototype.get = tk;
Fn.prototype.has = rk;
Fn.prototype.set = nk;
var au = Fn, ak = "Expected a function";
function iu(e, t) { if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(ak); var r = s(function () { var n = arguments, a = t ? t.apply(this, n) : n[0], i = r.cache; if (i.has(a))
    return i.get(a); var o = e.apply(this, n); return r.cache = i.set(a, o) || i, o; }, "memoized"); return r.cache = new (iu.Cache || au), r; }
s(iu, "memoize");
iu.Cache = au;
var ik = iu, sk = 500;
function e$(e) { var t = ik(e, function (n) { return r.size === sk && r.clear(), n; }), r = t.cache; return t; }
s(e$, "memoizeCapped");
var ok = e$, lk = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, uk = /\\(\\)?/g, ck = ok(function (e) { var t = []; return e.charCodeAt(0) === 46 && t.push(""), e.replace(lk, function (r, n, a, i) { t.push(a ? i.replace(uk, "$1") : n || r); }), t; }), fk = ck;
function t$(e) { return e == null ? "" : LI(e); }
s(t$, "toString");
var pk = t$;
function r$(e, t) { return te(e) ? e : Cd(e, t) ? [e] : fk(pk(e)); }
s(r$, "castPath");
var su = r$, dk = 1 / 0;
function n$(e) { if (typeof e == "string" || Yl(e))
    return e; var t = e + ""; return t == "0" && 1 / e == -dk ? "-0" : t; }
s(n$, "toKey");
var Ks = n$;
function a$(e, t) { t = su(t, e); for (var r = 0, n = t.length; e != null && r < n;)
    e = e[Ks(t[r++])]; return r && r == n ? e : void 0; }
s(a$, "baseGet");
var _d = a$;
function i$(e, t, r) { var n = e == null ? void 0 : _d(e, t); return n === void 0 ? r : n; }
s(i$, "get");
var mk = i$;
function s$(e, t) { for (var r = -1, n = t.length, a = e.length; ++r < n;)
    e[a + r] = t[r]; return e; }
s(s$, "arrayPush");
var Sd = s$, gh = At ? At.isConcatSpreadable : void 0;
function o$(e) { return te(e) || Ql(e) || !!(gh && e && e[gh]); }
s(o$, "isFlattenable");
var hk = o$;
function wd(e, t, r, n, a) { var i = -1, o = e.length; for (r || (r = hk), a || (a = []); ++i < o;) {
    var l = e[i];
    t > 0 && r(l) ? t > 1 ? wd(l, t - 1, r, n, a) : Sd(a, l) : n || (a[a.length] = l);
} return a; }
s(wd, "baseFlatten");
var Id = wd;
function l$(e) { var t = e == null ? 0 : e.length; return t ? Id(e, 1) : []; }
s(l$, "flatten");
var Lt = l$, yk = wT(Object.getPrototypeOf, Object), u$ = yk;
function c$(e, t, r) { var n = -1, a = e.length; t < 0 && (t = -t > a ? 0 : a + t), r = r > a ? a : r, r < 0 && (r += a), a = t > r ? 0 : r - t >>> 0, t >>>= 0; for (var i = Array(a); ++n < a;)
    i[n] = e[n + t]; return i; }
s(c$, "baseSlice");
var f$ = c$;
function p$(e, t, r, n) { var a = -1, i = e == null ? 0 : e.length; for (n && i && (r = e[++a]); ++a < i;)
    r = t(r, e[a], a, e); return r; }
s(p$, "arrayReduce");
var gk = p$;
function d$() { this.__data__ = new ru, this.size = 0; }
s(d$, "stackClear");
var vk = d$;
function m$(e) { var t = this.__data__, r = t.delete(e); return this.size = t.size, r; }
s(m$, "stackDelete");
var Tk = m$;
function h$(e) { return this.__data__.get(e); }
s(h$, "stackGet");
var $k = h$;
function y$(e) { return this.__data__.has(e); }
s(y$, "stackHas");
var Rk = y$, Ak = 200;
function g$(e, t) { var r = this.__data__; if (r instanceof ru) {
    var n = r.__data__;
    if (!gs || n.length < Ak - 1)
        return n.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new au(n);
} return r.set(e, t), this.size = r.size, this; }
s(g$, "stackSet");
var Ek = g$;
function zn(e) { var t = this.__data__ = new ru(e); this.size = t.size; }
s(zn, "Stack");
zn.prototype.clear = vk;
zn.prototype.delete = Tk;
zn.prototype.get = $k;
zn.prototype.has = Rk;
zn.prototype.set = Ek;
var ss = zn;
function v$(e, t) { return e && js(t, ht(t), e); }
s(v$, "baseAssign");
var bk = v$;
function T$(e, t) { return e && js(t, eu(t), e); }
s(T$, "baseAssignIn");
var Ck = T$, $$ = typeof exports == "object" && exports && !exports.nodeType && exports, vh = $$ && typeof module == "object" && module && !module.nodeType && module, _k = vh && vh.exports === $$, Th = _k ? Zt.Buffer : void 0, $h = Th ? Th.allocUnsafe : void 0;
function R$(e, t) { if (t)
    return e.slice(); var r = e.length, n = $h ? $h(r) : new e.constructor(r); return e.copy(n), n; }
s(R$, "cloneBuffer");
var Sk = R$;
function A$(e, t) { for (var r = -1, n = e == null ? 0 : e.length, a = 0, i = []; ++r < n;) {
    var o = e[r];
    t(o, r, e) && (i[a++] = o);
} return i; }
s(A$, "arrayFilter");
var Nd = A$;
function E$() { return []; }
s(E$, "stubArray");
var b$ = E$, wk = Object.prototype, Ik = wk.propertyIsEnumerable, Rh = Object.getOwnPropertySymbols, Nk = Rh ? function (e) { return e == null ? [] : (e = Object(e), Nd(Rh(e), function (t) { return Ik.call(e, t); })); } : b$, Pd = Nk;
function C$(e, t) { return js(e, Pd(e), t); }
s(C$, "copySymbols");
var Pk = C$, kk = Object.getOwnPropertySymbols, Ok = kk ? function (e) { for (var t = []; e;)
    Sd(t, Pd(e)), e = u$(e); return t; } : b$, _$ = Ok;
function S$(e, t) { return js(e, _$(e), t); }
s(S$, "copySymbolsIn");
var Lk = S$;
function w$(e, t, r) { var n = t(e); return te(e) ? n : Sd(n, r(e)); }
s(w$, "baseGetAllKeys");
var I$ = w$;
function N$(e) { return I$(e, ht, Pd); }
s(N$, "getAllKeys");
var Rf = N$;
function P$(e) { return I$(e, eu, _$); }
s(P$, "getAllKeysIn");
var k$ = P$, Dk = xn(Zt, "DataView"), Af = Dk, xk = xn(Zt, "Promise"), Ef = xk, Mk = xn(Zt, "Set"), La = Mk, Ah = "[object Map]", Gk = "[object Object]", Eh = "[object Promise]", bh = "[object Set]", Ch = "[object WeakMap]", _h = "[object DataView]", Fk = Dn(Af), zk = Dn(gs), jk = Dn(Ef), Uk = Dn(La), Bk = Dn($f), en = Ur;
(Af && en(new Af(new ArrayBuffer(1))) != _h || gs && en(new gs) != Ah || Ef && en(Ef.resolve()) != Eh || La && en(new La) != bh || $f && en(new $f) != Ch) && (en = s(function (e) { var t = Ur(e), r = t == Gk ? e.constructor : void 0, n = r ? Dn(r) : ""; if (n)
    switch (n) {
        case Fk: return _h;
        case zk: return Ah;
        case jk: return Eh;
        case Uk: return bh;
        case Bk: return Ch;
    } return t; }, "getTag"));
var Ka = en, Kk = Object.prototype, qk = Kk.hasOwnProperty;
function O$(e) { var t = e.length, r = new e.constructor(t); return t && typeof e[0] == "string" && qk.call(e, "index") && (r.index = e.index, r.input = e.input), r; }
s(O$, "initCloneArray");
var Wk = O$, Vk = Zt.Uint8Array, ul = Vk;
function L$(e) { var t = new e.constructor(e.byteLength); return new ul(t).set(new ul(e)), t; }
s(L$, "cloneArrayBuffer");
var kd = L$;
function D$(e, t) { var r = t ? kd(e.buffer) : e.buffer; return new e.constructor(r, e.byteOffset, e.byteLength); }
s(D$, "cloneDataView");
var Hk = D$, Yk = /\w*$/;
function x$(e) { var t = new e.constructor(e.source, Yk.exec(e)); return t.lastIndex = e.lastIndex, t; }
s(x$, "cloneRegExp");
var Xk = x$, Sh = At ? At.prototype : void 0, wh = Sh ? Sh.valueOf : void 0;
function M$(e) { return wh ? Object(wh.call(e)) : {}; }
s(M$, "cloneSymbol");
var Jk = M$;
function G$(e, t) { var r = t ? kd(e.buffer) : e.buffer; return new e.constructor(r, e.byteOffset, e.length); }
s(G$, "cloneTypedArray");
var Zk = G$, Qk = "[object Boolean]", eO = "[object Date]", tO = "[object Map]", rO = "[object Number]", nO = "[object RegExp]", aO = "[object Set]", iO = "[object String]", sO = "[object Symbol]", oO = "[object ArrayBuffer]", lO = "[object DataView]", uO = "[object Float32Array]", cO = "[object Float64Array]", fO = "[object Int8Array]", pO = "[object Int16Array]", dO = "[object Int32Array]", mO = "[object Uint8Array]", hO = "[object Uint8ClampedArray]", yO = "[object Uint16Array]", gO = "[object Uint32Array]";
function F$(e, t, r) { var n = e.constructor; switch (t) {
    case oO: return kd(e);
    case Qk:
    case eO: return new n(+e);
    case lO: return Hk(e, r);
    case uO:
    case cO:
    case fO:
    case pO:
    case dO:
    case mO:
    case hO:
    case yO:
    case gO: return Zk(e, r);
    case tO: return new n;
    case rO:
    case iO: return new n(e);
    case nO: return Xk(e);
    case aO: return new n;
    case sO: return Jk(e);
} }
s(F$, "initCloneByTag");
var vO = F$;
function z$(e) { return typeof e.constructor == "function" && !Us(e) ? fN(u$(e)) : {}; }
s(z$, "initCloneObject");
var TO = z$, $O = "[object Map]";
function j$(e) { return xt(e) && Ka(e) == $O; }
s(j$, "baseIsMap");
var RO = j$, Ih = xr && xr.isMap, AO = Ih ? Bs(Ih) : RO, EO = AO, bO = "[object Set]";
function U$(e) { return xt(e) && Ka(e) == bO; }
s(U$, "baseIsSet");
var CO = U$, Nh = xr && xr.isSet, _O = Nh ? Bs(Nh) : CO, SO = _O, wO = 1, IO = 2, NO = 4, B$ = "[object Arguments]", PO = "[object Array]", kO = "[object Boolean]", OO = "[object Date]", LO = "[object Error]", K$ = "[object Function]", DO = "[object GeneratorFunction]", xO = "[object Map]", MO = "[object Number]", q$ = "[object Object]", GO = "[object RegExp]", FO = "[object Set]", zO = "[object String]", jO = "[object Symbol]", UO = "[object WeakMap]", BO = "[object ArrayBuffer]", KO = "[object DataView]", qO = "[object Float32Array]", WO = "[object Float64Array]", VO = "[object Int8Array]", HO = "[object Int16Array]", YO = "[object Int32Array]", XO = "[object Uint8Array]", JO = "[object Uint8ClampedArray]", ZO = "[object Uint16Array]", QO = "[object Uint32Array]", de = {};
de[B$] = de[PO] = de[BO] = de[KO] = de[kO] = de[OO] = de[qO] = de[WO] = de[VO] = de[HO] = de[YO] = de[xO] = de[MO] = de[q$] = de[GO] = de[FO] = de[zO] = de[jO] = de[XO] = de[JO] = de[ZO] = de[QO] = !0;
de[LO] = de[K$] = de[UO] = !1;
function os(e, t, r, n, a, i) { var o, l = t & wO, u = t & IO, c = t & NO; if (r && (o = a ? r(e, n, a, i) : r(e)), o !== void 0)
    return o; if (!Et(e))
    return e; var f = te(e); if (f) {
    if (o = Wk(e), !l)
        return dN(e, o);
}
else {
    var p = Ka(e), m = p == K$ || p == DO;
    if (hs(e))
        return Sk(e, l);
    if (p == q$ || p == B$ || m && !a) {
        if (o = u || m ? {} : TO(e), !l)
            return u ? Lk(e, Ck(o, e)) : Pk(e, bk(o, e));
    }
    else {
        if (!de[p])
            return a ? e : {};
        o = vO(e, p, l);
    }
} i || (i = new ss); var g = i.get(e); if (g)
    return g; i.set(e, o), SO(e) ? e.forEach(function (N) { o.add(os(N, t, r, N, e, i)); }) : EO(e) && e.forEach(function (N, w) { o.set(w, os(N, t, r, w, e, i)); }); var v = c ? u ? k$ : Rf : u ? eu : ht, _ = f ? void 0 : v(e); return Jv(_ || e, function (N, w) { _ && (w = N, N = e[w]), Jl(o, w, os(N, t, r, w, e, i)); }), o; }
s(os, "baseClone");
var e0 = os, t0 = 4;
function W$(e) { return e0(e, t0); }
s(W$, "clone");
var Ye = W$;
function V$(e) { for (var t = -1, r = e == null ? 0 : e.length, n = 0, a = []; ++t < r;) {
    var i = e[t];
    i && (a[n++] = i);
} return a; }
s(V$, "compact");
var qs = V$, r0 = "__lodash_hash_undefined__";
function H$(e) { return this.__data__.set(e, r0), this; }
s(H$, "setCacheAdd");
var n0 = H$;
function Y$(e) { return this.__data__.has(e); }
s(Y$, "setCacheHas");
var a0 = Y$;
function vs(e) { var t = -1, r = e == null ? 0 : e.length; for (this.__data__ = new au; ++t < r;)
    this.add(e[t]); }
s(vs, "SetCache");
vs.prototype.add = vs.prototype.push = n0;
vs.prototype.has = a0;
var Od = vs;
function X$(e, t) { for (var r = -1, n = e == null ? 0 : e.length; ++r < n;)
    if (t(e[r], r, e))
        return !0; return !1; }
s(X$, "arraySome");
var J$ = X$;
function Z$(e, t) { return e.has(t); }
s(Z$, "cacheHas");
var Ld = Z$, i0 = 1, s0 = 2;
function Q$(e, t, r, n, a, i) { var o = r & i0, l = e.length, u = t.length; if (l != u && !(o && u > l))
    return !1; var c = i.get(e), f = i.get(t); if (c && f)
    return c == t && f == e; var p = -1, m = !0, g = r & s0 ? new Od : void 0; for (i.set(e, t), i.set(t, e); ++p < l;) {
    var v = e[p], _ = t[p];
    if (n)
        var N = o ? n(_, v, p, t, e, i) : n(v, _, p, e, t, i);
    if (N !== void 0) {
        if (N)
            continue;
        m = !1;
        break;
    }
    if (g) {
        if (!J$(t, function (w, S) { if (!Ld(g, S) && (v === w || a(v, w, r, n, i)))
            return g.push(S); })) {
            m = !1;
            break;
        }
    }
    else if (!(v === _ || a(v, _, r, n, i))) {
        m = !1;
        break;
    }
} return i.delete(e), i.delete(t), m; }
s(Q$, "equalArrays");
var eR = Q$;
function tR(e) { var t = -1, r = Array(e.size); return e.forEach(function (n, a) { r[++t] = [a, n]; }), r; }
s(tR, "mapToArray");
var o0 = tR;
function rR(e) { var t = -1, r = Array(e.size); return e.forEach(function (n) { r[++t] = n; }), r; }
s(rR, "setToArray");
var Dd = rR, l0 = 1, u0 = 2, c0 = "[object Boolean]", f0 = "[object Date]", p0 = "[object Error]", d0 = "[object Map]", m0 = "[object Number]", h0 = "[object RegExp]", y0 = "[object Set]", g0 = "[object String]", v0 = "[object Symbol]", T0 = "[object ArrayBuffer]", $0 = "[object DataView]", Ph = At ? At.prototype : void 0, Bu = Ph ? Ph.valueOf : void 0;
function nR(e, t, r, n, a, i, o) { switch (r) {
    case $0:
        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset)
            return !1;
        e = e.buffer, t = t.buffer;
    case T0: return !(e.byteLength != t.byteLength || !i(new ul(e), new ul(t)));
    case c0:
    case f0:
    case m0: return zs(+e, +t);
    case p0: return e.name == t.name && e.message == t.message;
    case h0:
    case g0: return e == t + "";
    case d0: var l = o0;
    case y0:
        var u = n & l0;
        if (l || (l = Dd), e.size != t.size && !u)
            return !1;
        var c = o.get(e);
        if (c)
            return c == t;
        n |= u0, o.set(e, t);
        var f = eR(l(e), l(t), n, a, i, o);
        return o.delete(e), f;
    case v0: if (Bu)
        return Bu.call(e) == Bu.call(t);
} return !1; }
s(nR, "equalByTag");
var R0 = nR, A0 = 1, E0 = Object.prototype, b0 = E0.hasOwnProperty;
function aR(e, t, r, n, a, i) { var o = r & A0, l = Rf(e), u = l.length, c = Rf(t), f = c.length; if (u != f && !o)
    return !1; for (var p = u; p--;) {
    var m = l[p];
    if (!(o ? m in t : b0.call(t, m)))
        return !1;
} var g = i.get(e), v = i.get(t); if (g && v)
    return g == t && v == e; var _ = !0; i.set(e, t), i.set(t, e); for (var N = o; ++p < u;) {
    m = l[p];
    var w = e[m], S = t[m];
    if (n)
        var E = o ? n(S, w, m, t, e, i) : n(w, S, m, e, t, i);
    if (!(E === void 0 ? w === S || a(w, S, r, n, i) : E)) {
        _ = !1;
        break;
    }
    N || (N = m == "constructor");
} if (_ && !N) {
    var I = e.constructor, j = t.constructor;
    I != j && "constructor" in e && "constructor" in t && !(typeof I == "function" && I instanceof I && typeof j == "function" && j instanceof j) && (_ = !1);
} return i.delete(e), i.delete(t), _; }
s(aR, "equalObjects");
var C0 = aR, _0 = 1, kh = "[object Arguments]", Oh = "[object Array]", Qs = "[object Object]", S0 = Object.prototype, Lh = S0.hasOwnProperty;
function iR(e, t, r, n, a, i) { var o = te(e), l = te(t), u = o ? Oh : Ka(e), c = l ? Oh : Ka(t); u = u == kh ? Qs : u, c = c == kh ? Qs : c; var f = u == Qs, p = c == Qs, m = u == c; if (m && hs(e)) {
    if (!hs(t))
        return !1;
    o = !0, f = !1;
} if (m && !f)
    return i || (i = new ss), o || bd(e) ? eR(e, t, r, n, a, i) : R0(e, t, u, r, n, a, i); if (!(r & _0)) {
    var g = f && Lh.call(e, "__wrapped__"), v = p && Lh.call(t, "__wrapped__");
    if (g || v) {
        var _ = g ? e.value() : e, N = v ? t.value() : t;
        return i || (i = new ss), a(_, N, r, n, i);
    }
} return m ? (i || (i = new ss), C0(e, t, r, n, a, i)) : !1; }
s(iR, "baseIsEqualDeep");
var w0 = iR;
function xd(e, t, r, n, a) { return e === t ? !0 : e == null || t == null || !xt(e) && !xt(t) ? e !== e && t !== t : w0(e, t, r, n, xd, a); }
s(xd, "baseIsEqual");
var sR = xd, I0 = 1, N0 = 2;
function oR(e, t, r, n) { var a = r.length, i = a, o = !n; if (e == null)
    return !i; for (e = Object(e); a--;) {
    var l = r[a];
    if (o && l[2] ? l[1] !== e[l[0]] : !(l[0] in e))
        return !1;
} for (; ++a < i;) {
    l = r[a];
    var u = l[0], c = e[u], f = l[1];
    if (o && l[2]) {
        if (c === void 0 && !(u in e))
            return !1;
    }
    else {
        var p = new ss;
        if (n)
            var m = n(c, f, u, e, t, p);
        if (!(m === void 0 ? sR(f, c, I0 | N0, n, p) : m))
            return !1;
    }
} return !0; }
s(oR, "baseIsMatch");
var P0 = oR;
function lR(e) { return e === e && !Et(e); }
s(lR, "isStrictComparable");
var uR = lR;
function cR(e) { for (var t = ht(e), r = t.length; r--;) {
    var n = t[r], a = e[n];
    t[r] = [n, a, uR(a)];
} return t; }
s(cR, "getMatchData");
var k0 = cR;
function fR(e, t) { return function (r) { return r == null ? !1 : r[e] === t && (t !== void 0 || e in Object(r)); }; }
s(fR, "matchesStrictComparable");
var pR = fR;
function dR(e) { var t = k0(e); return t.length == 1 && t[0][2] ? pR(t[0][0], t[0][1]) : function (r) { return r === e || P0(r, e, t); }; }
s(dR, "baseMatches");
var O0 = dR;
function mR(e, t) { return e != null && t in Object(e); }
s(mR, "baseHasIn");
var L0 = mR;
function hR(e, t, r) { t = su(t, e); for (var n = -1, a = t.length, i = !1; ++n < a;) {
    var o = Ks(t[n]);
    if (!(i = e != null && r(e, o)))
        break;
    e = e[o];
} return i || ++n != a ? i : (a = e == null ? 0 : e.length, !!a && Ed(a) && Xl(o, a) && (te(e) || Ql(e))); }
s(hR, "hasPath");
var yR = hR;
function gR(e, t) { return e != null && yR(e, t, L0); }
s(gR, "hasIn");
var D0 = gR, x0 = 1, M0 = 2;
function vR(e, t) { return Cd(e) && uR(t) ? pR(Ks(e), t) : function (r) { var n = mk(r, e); return n === void 0 && n === t ? D0(r, e) : sR(t, n, x0 | M0); }; }
s(vR, "baseMatchesProperty");
var G0 = vR;
function TR(e) { return function (t) { return t?.[e]; }; }
s(TR, "baseProperty");
var F0 = TR;
function $R(e) { return function (t) { return _d(t, e); }; }
s($R, "basePropertyDeep");
var z0 = $R;
function RR(e) { return Cd(e) ? F0(Ks(e)) : z0(e); }
s(RR, "property");
var j0 = RR;
function AR(e) { return typeof e == "function" ? e : e == null ? Fs : typeof e == "object" ? te(e) ? G0(e[0], e[1]) : O0(e) : j0(e); }
s(AR, "baseIteratee");
var er = AR;
function ER(e, t, r, n) { for (var a = -1, i = e == null ? 0 : e.length; ++a < i;) {
    var o = e[a];
    t(n, o, r(o), e);
} return n; }
s(ER, "arrayAggregator");
var U0 = ER;
function bR(e) { return function (t, r, n) { for (var a = -1, i = Object(t), o = n(t), l = o.length; l--;) {
    var u = o[e ? l : ++a];
    if (r(i[u], u, i) === !1)
        break;
} return t; }; }
s(bR, "createBaseFor");
var B0 = bR, K0 = B0(), q0 = K0;
function CR(e, t) { return e && q0(e, t, ht); }
s(CR, "baseForOwn");
var W0 = CR;
function _R(e, t) { return function (r, n) { if (r == null)
    return r; if (!Qt(r))
    return e(r, n); for (var a = r.length, i = t ? a : -1, o = Object(r); (t ? i-- : ++i < a) && n(o[i], i, o) !== !1;)
    ; return r; }; }
s(_R, "createBaseEach");
var V0 = _R, H0 = V0(W0), jn = H0;
function SR(e, t, r, n) { return jn(e, function (a, i, o) { t(n, a, r(a), o); }), n; }
s(SR, "baseAggregator");
var Y0 = SR;
function wR(e, t) { return function (r, n) { var a = te(r) ? U0 : Y0, i = t ? t() : {}; return a(r, e, er(n, 2), i); }; }
s(wR, "createAggregator");
var X0 = wR, IR = Object.prototype, J0 = IR.hasOwnProperty, Z0 = Ad(function (e, t) { e = Object(e); var r = -1, n = t.length, a = n > 2 ? t[2] : void 0; for (a && Zl(t[0], t[1], a) && (n = 1); ++r < n;)
    for (var i = t[r], o = eu(i), l = -1, u = o.length; ++l < u;) {
        var c = o[l], f = e[c];
        (f === void 0 || zs(f, IR[c]) && !J0.call(e, c)) && (e[c] = i[c]);
    } return e; }), Md = Z0;
function NR(e) { return xt(e) && Qt(e); }
s(NR, "isArrayLikeObject");
var Dh = NR;
function PR(e, t, r) { for (var n = -1, a = e == null ? 0 : e.length; ++n < a;)
    if (r(t, e[n]))
        return !0; return !1; }
s(PR, "arrayIncludesWith");
var kR = PR, Q0 = 200;
function OR(e, t, r, n) { var a = -1, i = aT, o = !0, l = e.length, u = [], c = t.length; if (!l)
    return u; r && (t = Ms(t, Bs(r))), n ? (i = kR, o = !1) : t.length >= Q0 && (i = Ld, o = !1, t = new Od(t)); e: for (; ++a < l;) {
    var f = e[a], p = r == null ? f : r(f);
    if (f = n || f !== 0 ? f : 0, o && p === p) {
        for (var m = c; m--;)
            if (t[m] === p)
                continue e;
        u.push(f);
    }
    else
        i(t, p, n) || u.push(f);
} return u; }
s(OR, "baseDifference");
var eL = OR, tL = Ad(function (e, t) { return Dh(e) ? eL(e, Id(t, 1, Dh, !0)) : []; }), ou = tL;
function LR(e) { var t = e == null ? 0 : e.length; return t ? e[t - 1] : void 0; }
s(LR, "last");
var Cn = LR;
function DR(e, t, r) { var n = e == null ? 0 : e.length; return n ? (t = r || t === void 0 ? 1 : Gs(t), f$(e, t < 0 ? 0 : t, n)) : []; }
s(DR, "drop");
var Ve = DR;
function xR(e, t, r) { var n = e == null ? 0 : e.length; return n ? (t = r || t === void 0 ? 1 : Gs(t), t = n - t, f$(e, 0, t < 0 ? 0 : t)) : []; }
s(xR, "dropRight");
var Ts = xR;
function MR(e) { return typeof e == "function" ? e : Fs; }
s(MR, "castFunction");
var rL = MR;
function GR(e, t) { var r = te(e) ? Jv : jn; return r(e, rL(t)); }
s(GR, "forEach");
var V = GR;
function FR(e, t) { for (var r = -1, n = e == null ? 0 : e.length; ++r < n;)
    if (!t(e[r], r, e))
        return !1; return !0; }
s(FR, "arrayEvery");
var nL = FR;
function zR(e, t) { var r = !0; return jn(e, function (n, a, i) { return r = !!t(n, a, i), r; }), r; }
s(zR, "baseEvery");
var aL = zR;
function jR(e, t, r) { var n = te(e) ? nL : aL; return r && Zl(e, t, r) && (t = void 0), n(e, er(t, 3)); }
s(jR, "every");
var Dt = jR;
function UR(e, t) { var r = []; return jn(e, function (n, a, i) { t(n, a, i) && r.push(n); }), r; }
s(UR, "baseFilter");
var BR = UR;
function KR(e, t) { var r = te(e) ? Nd : BR; return r(e, er(t, 3)); }
s(KR, "filter");
var Ct = KR;
function qR(e) { return function (t, r, n) { var a = Object(t); if (!Qt(t)) {
    var i = er(r, 3);
    t = ht(t), r = s(function (l) { return i(a[l], l, a); }, "predicate");
} var o = e(t, r, n); return o > -1 ? a[i ? t[o] : o] : void 0; }; }
s(qR, "createFind");
var iL = qR, sL = Math.max;
function WR(e, t, r) { var n = e == null ? 0 : e.length; if (!n)
    return -1; var a = r == null ? 0 : Gs(r); return a < 0 && (a = sL(n + a, 0)), Qv(e, er(t, 3), a); }
s(WR, "findIndex");
var oL = WR, lL = iL(oL), qa = lL;
function VR(e) { return e && e.length ? e[0] : void 0; }
s(VR, "head");
var Mt = VR;
function HR(e, t) { var r = -1, n = Qt(e) ? Array(e.length) : []; return jn(e, function (a, i, o) { n[++r] = t(a, i, o); }), n; }
s(HR, "baseMap");
var uL = HR;
function YR(e, t) { var r = te(e) ? Ms : uL; return r(e, er(t, 3)); }
s(YR, "map");
var F = YR;
function XR(e, t) { return Id(F(e, t), 1); }
s(XR, "flatMap");
var Rt = XR, cL = Object.prototype, fL = cL.hasOwnProperty, pL = X0(function (e, t, r) { fL.call(e, r) ? e[r].push(t) : Rd(e, r, [t]); }), dL = pL, mL = Object.prototype, hL = mL.hasOwnProperty;
function JR(e, t) { return e != null && hL.call(e, t); }
s(JR, "baseHas");
var yL = JR;
function ZR(e, t) { return e != null && yR(e, t, yL); }
s(ZR, "has");
var K = ZR, gL = "[object String]";
function QR(e) { return typeof e == "string" || !te(e) && xt(e) && Ur(e) == gL; }
s(QR, "isString");
var st = QR;
function eA(e, t) { return Ms(t, function (r) { return e[r]; }); }
s(eA, "baseValues");
var vL = eA;
function tA(e) { return e == null ? [] : vL(e, ht(e)); }
s(tA, "values");
var Ge = tA, TL = Math.max;
function rA(e, t, r, n) { e = Qt(e) ? e : Ge(e), r = r && !n ? Gs(r) : 0; var a = e.length; return r < 0 && (r = TL(a + r, 0)), st(e) ? r <= a && e.indexOf(t, r) > -1 : !!a && $d(e, t, r) > -1; }
s(rA, "includes");
var nt = rA, $L = Math.max;
function nA(e, t, r) { var n = e == null ? 0 : e.length; if (!n)
    return -1; var a = r == null ? 0 : Gs(r); return a < 0 && (a = $L(n + a, 0)), $d(e, t, a); }
s(nA, "indexOf");
var xh = nA, RL = "[object Map]", AL = "[object Set]", EL = Object.prototype, bL = EL.hasOwnProperty;
function aA(e) { if (e == null)
    return !0; if (Qt(e) && (te(e) || typeof e == "string" || typeof e.splice == "function" || hs(e) || bd(e) || Ql(e)))
    return !e.length; var t = Ka(e); if (t == RL || t == AL)
    return !e.size; if (Us(e))
    return !NT(e).length; for (var r in e)
    if (bL.call(e, r))
        return !1; return !0; }
s(aA, "isEmpty");
var he = aA, CL = "[object RegExp]";
function iA(e) { return xt(e) && Ur(e) == CL; }
s(iA, "baseIsRegExp");
var _L = iA, Mh = xr && xr.isRegExp, SL = Mh ? Bs(Mh) : _L, gr = SL;
function sA(e) { return e === void 0; }
s(sA, "isUndefined");
var vr = sA, wL = "Expected a function";
function oA(e) { if (typeof e != "function")
    throw new TypeError(wL); return function () { var t = arguments; switch (t.length) {
    case 0: return !e.call(this);
    case 1: return !e.call(this, t[0]);
    case 2: return !e.call(this, t[0], t[1]);
    case 3: return !e.call(this, t[0], t[1], t[2]);
} return !e.apply(this, t); }; }
s(oA, "negate");
var IL = oA;
function lA(e, t, r, n) { if (!Et(e))
    return e; t = su(t, e); for (var a = -1, i = t.length, o = i - 1, l = e; l != null && ++a < i;) {
    var u = Ks(t[a]), c = r;
    if (u === "__proto__" || u === "constructor" || u === "prototype")
        return e;
    if (a != o) {
        var f = l[u];
        c = n ? n(f, u, l) : void 0, c === void 0 && (c = Et(f) ? f : Xl(t[a + 1]) ? [] : {});
    }
    Jl(l, u, c), l = l[u];
} return e; }
s(lA, "baseSet");
var NL = lA;
function uA(e, t, r) { for (var n = -1, a = t.length, i = {}; ++n < a;) {
    var o = t[n], l = _d(e, o);
    r(l, o) && NL(i, su(o, e), l);
} return i; }
s(uA, "basePickBy");
var PL = uA;
function cA(e, t) { if (e == null)
    return {}; var r = Ms(k$(e), function (n) { return [n]; }); return t = er(t), PL(e, r, function (n, a) { return t(n, a[0]); }); }
s(cA, "pickBy");
var Gt = cA;
function fA(e, t, r, n, a) { return a(e, function (i, o, l) { r = n ? (n = !1, i) : t(r, i, o, l); }), r; }
s(fA, "baseReduce");
var kL = fA;
function pA(e, t, r) { var n = te(e) ? gk : kL, a = arguments.length < 3; return n(e, er(t, 4), r, a, jn); }
s(pA, "reduce");
var gt = pA;
function dA(e, t) { var r = te(e) ? Nd : BR; return r(e, IL(er(t, 3))); }
s(dA, "reject");
var lu = dA;
function mA(e, t) { var r; return jn(e, function (n, a, i) { return r = t(n, a, i), !r; }), !!r; }
s(mA, "baseSome");
var OL = mA;
function hA(e, t, r) { var n = te(e) ? J$ : OL; return r && Zl(e, t, r) && (t = void 0), n(e, er(t, 3)); }
s(hA, "some");
var yA = hA, LL = 1 / 0, DL = La && 1 / Dd(new La([, -0]))[1] == LL ? function (e) { return new La(e); } : ze, xL = DL, ML = 200;
function gA(e, t, r) { var n = -1, a = aT, i = e.length, o = !0, l = [], u = l; if (r)
    o = !1, a = kR;
else if (i >= ML) {
    var c = t ? null : xL(e);
    if (c)
        return Dd(c);
    o = !1, a = Ld, u = new Od;
}
else
    u = t ? [] : l; e: for (; ++n < i;) {
    var f = e[n], p = t ? t(f) : f;
    if (f = r || f !== 0 ? f : 0, o && p === p) {
        for (var m = u.length; m--;)
            if (u[m] === p)
                continue e;
        t && u.push(p), l.push(f);
    }
    else
        a(u, p, r) || (u !== l && u.push(p), l.push(f));
} return l; }
s(gA, "baseUniq");
var GL = gA;
function vA(e) { return e && e.length ? GL(e) : []; }
s(vA, "uniq");
var Gd = vA;
function cl(e) { console && console.error && console.error(`Error: ${e}`); }
s(cl, "PRINT_ERROR");
function Fd(e) { console && console.warn && console.warn(`Warning: ${e}`); }
s(Fd, "PRINT_WARNING");
function zd(e) { let t = new Date().getTime(), r = e(); return { time: new Date().getTime() - t, value: r }; }
s(zd, "timer");
function jd(e) { function t() { } s(t, "FakeConstructor"), t.prototype = e; let r = new t; function n() { return typeof r.bar; } return s(n, "fakeAccess"), n(), n(), e; (0, eval)(e); }
s(jd, "toFastProperties");
function TA(e) { return $A(e) ? e.LABEL : e.name; }
s(TA, "tokenLabel");
function $A(e) { return st(e.LABEL) && e.LABEL !== ""; }
s($A, "hasTokenLabel");
var tr = class {
    static { s(this, "AbstractProduction"); }
    get definition() { return this._definition; }
    set definition(e) { this._definition = e; }
    constructor(e) { this._definition = e; }
    accept(e) { e.visit(this), V(this.definition, t => { t.accept(e); }); }
}, tt = class extends tr {
    static { s(this, "NonTerminal"); }
    constructor(e) { super([]), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
    set definition(e) { }
    get definition() { return this.referencedRule !== void 0 ? this.referencedRule.definition : []; }
    accept(e) { e.visit(this); }
}, Ja = class extends tr {
    static { s(this, "Rule"); }
    constructor(e) { super(e.definition), this.orgText = "", yt(this, Gt(e, t => t !== void 0)); }
}, ot = class extends tr {
    static { s(this, "Alternative"); }
    constructor(e) { super(e.definition), this.ignoreAmbiguities = !1, yt(this, Gt(e, t => t !== void 0)); }
}, He = class extends tr {
    static { s(this, "Option"); }
    constructor(e) { super(e.definition), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
}, vt = class extends tr {
    static { s(this, "RepetitionMandatory"); }
    constructor(e) { super(e.definition), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
}, Tt = class extends tr {
    static { s(this, "RepetitionMandatoryWithSeparator"); }
    constructor(e) { super(e.definition), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
}, Ie = class extends tr {
    static { s(this, "Repetition"); }
    constructor(e) { super(e.definition), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
}, lt = class extends tr {
    static { s(this, "RepetitionWithSeparator"); }
    constructor(e) { super(e.definition), this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
}, ut = class extends tr {
    static { s(this, "Alternation"); }
    get definition() { return this._definition; }
    set definition(e) { this._definition = e; }
    constructor(e) { super(e.definition), this.idx = 1, this.ignoreAmbiguities = !1, this.hasPredicates = !1, yt(this, Gt(e, t => t !== void 0)); }
}, $e = class {
    static { s(this, "Terminal"); }
    constructor(e) { this.idx = 1, yt(this, Gt(e, t => t !== void 0)); }
    accept(e) { e.visit(this); }
};
function RA(e) { return F(e, ls); }
s(RA, "serializeGrammar");
function ls(e) { function t(r) { return F(r, ls); } if (s(t, "convertDefinition"), e instanceof tt) {
    let r = { type: "NonTerminal", name: e.nonTerminalName, idx: e.idx };
    return st(e.label) && (r.label = e.label), r;
}
else {
    if (e instanceof ot)
        return { type: "Alternative", definition: t(e.definition) };
    if (e instanceof He)
        return { type: "Option", idx: e.idx, definition: t(e.definition) };
    if (e instanceof vt)
        return { type: "RepetitionMandatory", idx: e.idx, definition: t(e.definition) };
    if (e instanceof Tt)
        return { type: "RepetitionMandatoryWithSeparator", idx: e.idx, separator: ls(new $e({ terminalType: e.separator })), definition: t(e.definition) };
    if (e instanceof lt)
        return { type: "RepetitionWithSeparator", idx: e.idx, separator: ls(new $e({ terminalType: e.separator })), definition: t(e.definition) };
    if (e instanceof Ie)
        return { type: "Repetition", idx: e.idx, definition: t(e.definition) };
    if (e instanceof ut)
        return { type: "Alternation", idx: e.idx, definition: t(e.definition) };
    if (e instanceof $e) {
        let r = { type: "Terminal", name: e.terminalType.name, label: TA(e.terminalType), idx: e.idx };
        st(e.label) && (r.terminalLabel = e.label);
        let n = e.terminalType.PATTERN;
        return e.terminalType.PATTERN && (r.pattern = gr(n) ? n.source : n), r;
    }
    else {
        if (e instanceof Ja)
            return { type: "Rule", name: e.name, orgText: e.orgText, definition: t(e.definition) };
        throw Error("non exhaustive match");
    }
} }
s(ls, "serializeProduction");
var Za = class {
    static { s(this, "GAstVisitor"); }
    visit(e) { let t = e; switch (t.constructor) {
        case tt: return this.visitNonTerminal(t);
        case ot: return this.visitAlternative(t);
        case He: return this.visitOption(t);
        case vt: return this.visitRepetitionMandatory(t);
        case Tt: return this.visitRepetitionMandatoryWithSeparator(t);
        case lt: return this.visitRepetitionWithSeparator(t);
        case Ie: return this.visitRepetition(t);
        case ut: return this.visitAlternation(t);
        case $e: return this.visitTerminal(t);
        case Ja: return this.visitRule(t);
        default: throw Error("non exhaustive match");
    } }
    visitNonTerminal(e) { }
    visitAlternative(e) { }
    visitOption(e) { }
    visitRepetition(e) { }
    visitRepetitionMandatory(e) { }
    visitRepetitionMandatoryWithSeparator(e) { }
    visitRepetitionWithSeparator(e) { }
    visitAlternation(e) { }
    visitTerminal(e) { }
    visitRule(e) { }
};
function AA(e) { return e instanceof ot || e instanceof He || e instanceof Ie || e instanceof vt || e instanceof Tt || e instanceof lt || e instanceof $e || e instanceof Ja; }
s(AA, "isSequenceProd");
function $s(e, t = []) { return e instanceof He || e instanceof Ie || e instanceof lt ? !0 : e instanceof ut ? yA(e.definition, n => $s(n, t)) : e instanceof tt && nt(t, e) ? !1 : e instanceof tr ? (e instanceof tt && t.push(e), Dt(e.definition, n => $s(n, t))) : !1; }
s($s, "isOptionalProd");
function EA(e) { return e instanceof ut; }
s(EA, "isBranchingProd");
function It(e) { if (e instanceof tt)
    return "SUBRULE"; if (e instanceof He)
    return "OPTION"; if (e instanceof ut)
    return "OR"; if (e instanceof vt)
    return "AT_LEAST_ONE"; if (e instanceof Tt)
    return "AT_LEAST_ONE_SEP"; if (e instanceof lt)
    return "MANY_SEP"; if (e instanceof Ie)
    return "MANY"; if (e instanceof $e)
    return "CONSUME"; throw Error("non exhaustive match"); }
s(It, "getProductionDslName");
var uu = class {
    static { s(this, "RestWalker"); }
    walk(e, t = []) { V(e.definition, (r, n) => { let a = Ve(e.definition, n + 1); if (r instanceof tt)
        this.walkProdRef(r, a, t);
    else if (r instanceof $e)
        this.walkTerminal(r, a, t);
    else if (r instanceof ot)
        this.walkFlat(r, a, t);
    else if (r instanceof He)
        this.walkOption(r, a, t);
    else if (r instanceof vt)
        this.walkAtLeastOne(r, a, t);
    else if (r instanceof Tt)
        this.walkAtLeastOneSep(r, a, t);
    else if (r instanceof lt)
        this.walkManySep(r, a, t);
    else if (r instanceof Ie)
        this.walkMany(r, a, t);
    else if (r instanceof ut)
        this.walkOr(r, a, t);
    else
        throw Error("non exhaustive match"); }); }
    walkTerminal(e, t, r) { }
    walkProdRef(e, t, r) { }
    walkFlat(e, t, r) { let n = t.concat(r); this.walk(e, n); }
    walkOption(e, t, r) { let n = t.concat(r); this.walk(e, n); }
    walkAtLeastOne(e, t, r) { let n = [new He({ definition: e.definition })].concat(t, r); this.walk(e, n); }
    walkAtLeastOneSep(e, t, r) { let n = bf(e, t, r); this.walk(e, n); }
    walkMany(e, t, r) { let n = [new He({ definition: e.definition })].concat(t, r); this.walk(e, n); }
    walkManySep(e, t, r) { let n = bf(e, t, r); this.walk(e, n); }
    walkOr(e, t, r) { let n = t.concat(r); V(e.definition, a => { let i = new ot({ definition: [a] }); this.walk(i, n); }); }
};
function bf(e, t, r) { return [new He({ definition: [new $e({ terminalType: e.separator })].concat(e.definition) })].concat(t, r); }
s(bf, "restForRepetitionWithSeparator");
function Qa(e) { if (e instanceof tt)
    return Qa(e.referencedRule); if (e instanceof $e)
    return _A(e); if (AA(e))
    return bA(e); if (EA(e))
    return CA(e); throw Error("non exhaustive match"); }
s(Qa, "first");
function bA(e) { let t = [], r = e.definition, n = 0, a = r.length > n, i, o = !0; for (; a && o;)
    i = r[n], o = $s(i), t = t.concat(Qa(i)), n = n + 1, a = r.length > n; return Gd(t); }
s(bA, "firstForSequence");
function CA(e) { let t = F(e.definition, r => Qa(r)); return Gd(Lt(t)); }
s(CA, "firstForBranching");
function _A(e) { return [e.terminalType]; }
s(_A, "firstForTerminal");
var SA = "_~IN~_", FL = class extends uu {
    static { s(this, "ResyncFollowsWalker"); }
    constructor(e) { super(), this.topProd = e, this.follows = {}; }
    startWalking() { return this.walk(this.topProd), this.follows; }
    walkTerminal(e, t, r) { }
    walkProdRef(e, t, r) { let n = IA(e.referencedRule, e.idx) + this.topProd.name, a = t.concat(r), i = new ot({ definition: a }), o = Qa(i); this.follows[n] = o; }
};
function wA(e) { let t = {}; return V(e, r => { let n = new FL(r).startWalking(); yt(t, n); }), t; }
s(wA, "computeAllProdsFollows");
function IA(e, t) { return e.name + t + SA; }
s(IA, "buildBetweenProdsFollowPrefix");
var So = {}, zL = new ov;
function Ws(e) { let t = e.toString(); if (So.hasOwnProperty(t))
    return So[t]; {
    let r = zL.pattern(t);
    return So[t] = r, r;
} }
s(Ws, "getRegExpAst");
function NA() { So = {}; }
s(NA, "clearRegExpParserCache");
var PA = "Complement Sets are not supported for first char optimization", fl = `Unable to use "first char" lexer optimizations:
`;
function kA(e, t = !1) {
    try {
        let r = Ws(e);
        return pl(r.value, {}, r.flags.ignoreCase);
    }
    catch (r) {
        if (r.message === PA)
            t && Fd(`${fl}	Unable to optimize: < ${e.toString()} >
	Complement Sets cannot be automatically optimized.
	This will disable the lexer's first char optimizations.
	See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#COMPLEMENT for details.`);
        else {
            let n = "";
            t && (n = `
	This will disable the lexer's first char optimizations.
	See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#REGEXP_PARSING for details.`), cl(`${fl}
	Failed parsing: < ${e.toString()} >
	Using the @chevrotain/regexp-to-ast library
	Please open an issue at: https://github.com/chevrotain/chevrotain/issues` + n);
        }
    }
    return [];
}
s(kA, "getOptimizedStartCodesIndices");
function pl(e, t, r) { switch (e.type) {
    case "Disjunction":
        for (let a = 0; a < e.value.length; a++)
            pl(e.value[a], t, r);
        break;
    case "Alternative":
        let n = e.value;
        for (let a = 0; a < n.length; a++) {
            let i = n[a];
            switch (i.type) {
                case "EndAnchor":
                case "GroupBackReference":
                case "Lookahead":
                case "NegativeLookahead":
                case "Lookbehind":
                case "NegativeLookbehind":
                case "StartAnchor":
                case "WordBoundary":
                case "NonWordBoundary": continue;
            }
            let o = i;
            switch (o.type) {
                case "Character":
                    qi(o.value, t, r);
                    break;
                case "Set":
                    if (o.complement === !0)
                        throw Error(PA);
                    V(o.value, u => { if (typeof u == "number")
                        qi(u, t, r);
                    else {
                        let c = u;
                        if (r === !0)
                            for (let f = c.from; f <= c.to; f++)
                                qi(f, t, r);
                        else {
                            for (let f = c.from; f <= c.to && f < Vi; f++)
                                qi(f, t, r);
                            if (c.to >= Vi) {
                                let f = c.from >= Vi ? c.from : Vi, p = c.to, m = Tr(f), g = Tr(p);
                                for (let v = m; v <= g; v++)
                                    t[v] = v;
                            }
                        }
                    } });
                    break;
                case "Group":
                    pl(o.value, t, r);
                    break;
                default: throw Error("Non Exhaustive Match");
            }
            let l = o.quantifier !== void 0 && o.quantifier.atLeast === 0;
            if (o.type === "Group" && dl(o) === !1 || o.type !== "Group" && l === !1)
                break;
        }
        break;
    default: throw Error("non exhaustive match!");
} return Ge(t); }
s(pl, "firstCharOptimizedIndices");
function qi(e, t, r) { let n = Tr(e); t[n] = n, r === !0 && OA(e, t); }
s(qi, "addOptimizedIdxToResult");
function OA(e, t) { let r = String.fromCharCode(e), n = r.toUpperCase(); if (n !== r) {
    let a = Tr(n.charCodeAt(0));
    t[a] = a;
}
else {
    let a = r.toLowerCase();
    if (a !== r) {
        let i = Tr(a.charCodeAt(0));
        t[i] = i;
    }
} }
s(OA, "handleIgnoreCase");
function Cf(e, t) { return qa(e.value, r => { if (typeof r == "number")
    return nt(t, r); {
    let n = r;
    return qa(t, a => n.from <= a && a <= n.to) !== void 0;
} }); }
s(Cf, "findCode");
function dl(e) { let t = e.quantifier; return t && t.atLeast === 0 ? !0 : e.value ? te(e.value) ? Dt(e.value, dl) : dl(e.value) : !1; }
s(dl, "isWholeOptional");
var jL = class extends Ul {
    static { s(this, "CharCodeFinder"); }
    constructor(e) { super(), this.targetCharCodes = e, this.found = !1; }
    visitChildren(e) { if (this.found !== !0) {
        switch (e.type) {
            case "Lookahead":
                this.visitLookahead(e);
                return;
            case "NegativeLookahead":
                this.visitNegativeLookahead(e);
                return;
            case "Lookbehind":
                this.visitLookbehind(e);
                return;
            case "NegativeLookbehind":
                this.visitNegativeLookbehind(e);
                return;
        }
        super.visitChildren(e);
    } }
    visitCharacter(e) { nt(this.targetCharCodes, e.value) && (this.found = !0); }
    visitSet(e) { e.complement ? Cf(e, this.targetCharCodes) === void 0 && (this.found = !0) : Cf(e, this.targetCharCodes) !== void 0 && (this.found = !0); }
};
function cu(e, t) { if (t instanceof RegExp) {
    let r = Ws(t), n = new jL(e);
    return n.visit(r), n.found;
}
else
    return qa(t, r => nt(e, r.charCodeAt(0))) !== void 0; }
s(cu, "canMatchCharCode");
var _n = "PATTERN", Wi = "defaultMode", eo = "modes";
function LA(e, t) {
    t = Md(t, { debug: !1, safeMode: !1, positionTracking: "full", lineTerminatorCharacters: ["\r", `
`], tracer: s((S, E) => E(), "tracer") });
    let r = t.tracer;
    r("initCharCodeToOptimizedIndexMap", () => { tE(); });
    let n;
    r("Reject Lexer.NA", () => { n = lu(e, S => S[_n] === dt.NA); });
    let a = !1, i;
    r("Transform Patterns", () => { a = !1, i = F(n, S => { let E = S[_n]; if (gr(E)) {
        let I = E.source;
        return I.length === 1 && I !== "^" && I !== "$" && I !== "." && !E.ignoreCase ? I : I.length === 2 && I[0] === "\\" && !nt(["d", "D", "s", "S", "t", "r", "n", "t", "0", "c", "b", "B", "f", "v", "w", "W"], I[1]) ? I[1] : _f(E);
    }
    else {
        if (br(E))
            return a = !0, { exec: E };
        if (typeof E == "object")
            return a = !0, E;
        if (typeof E == "string") {
            if (E.length === 1)
                return E;
            {
                let I = E.replace(/[\\^$.*+?()[\]{}|]/g, "\\$&"), j = new RegExp(I);
                return _f(j);
            }
        }
        else
            throw Error("non exhaustive match");
    } }); });
    let o, l, u, c, f;
    r("misc mapping", () => { o = F(n, S => S.tokenTypeIdx), l = F(n, S => { let E = S.GROUP; if (E !== dt.SKIPPED) {
        if (st(E))
            return E;
        if (vr(E))
            return !1;
        throw Error("non exhaustive match");
    } }), u = F(n, S => { let E = S.LONGER_ALT; if (E)
        return te(E) ? F(E, j => xh(n, j)) : [xh(n, E)]; }), c = F(n, S => S.PUSH_MODE), f = F(n, S => K(S, "POP_MODE")); });
    let p;
    r("Line Terminator Handling", () => { let S = Kd(t.lineTerminatorCharacters); p = F(n, E => !1), t.positionTracking !== "onlyOffset" && (p = F(n, E => K(E, "LINE_BREAKS") ? !!E.LINE_BREAKS : Bd(E, S) === !1 && cu(S, E.PATTERN))); });
    let m, g, v, _;
    r("Misc Mapping #2", () => { m = F(n, Ud), g = F(i, QA), v = gt(n, (S, E) => { let I = E.GROUP; return st(I) && I !== dt.SKIPPED && (S[I] = []), S; }, {}), _ = F(i, (S, E) => ({ pattern: i[E], longerAlt: u[E], canLineTerminator: p[E], isCustom: m[E], short: g[E], group: l[E], push: c[E], pop: f[E], tokenTypeIdx: o[E], tokenType: n[E] })); });
    let N = !0, w = [];
    return t.safeMode || r("First Char Optimization", () => {
        w = gt(n, (S, E, I) => {
            if (typeof E.PATTERN == "string") {
                let j = E.PATTERN.charCodeAt(0), Q = Tr(j);
                wo(S, Q, _[I]);
            }
            else if (te(E.START_CHARS_HINT)) {
                let j;
                V(E.START_CHARS_HINT, Q => { let X = typeof Q == "string" ? Q.charCodeAt(0) : Q, fe = Tr(X); j !== fe && (j = fe, wo(S, fe, _[I])); });
            }
            else if (gr(E.PATTERN))
                if (E.PATTERN.unicode)
                    N = !1, t.ensureOptimizations && cl(`${fl}	Unable to analyze < ${E.PATTERN.toString()} > pattern.
	The regexp unicode flag is not currently supported by the regexp-to-ast library.
	This will disable the lexer's first char optimizations.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#UNICODE_OPTIMIZE`);
                else {
                    let j = kA(E.PATTERN, t.ensureOptimizations);
                    he(j) && (N = !1), V(j, Q => { wo(S, Q, _[I]); });
                }
            else
                t.ensureOptimizations && cl(`${fl}	TokenType: <${E.name}> is using a custom token pattern without providing <start_chars_hint> parameter.
	This will disable the lexer's first char optimizations.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#CUSTOM_OPTIMIZE`), N = !1;
            return S;
        }, []);
    }), { emptyGroups: v, patternIdxToConfig: _, charCodeToPatternIdxToConfig: w, hasCustom: a, canBeOptimized: N };
}
s(LA, "analyzeTokenTypes");
function DA(e, t) { let r = [], n = MA(e); r = r.concat(n.errors); let a = GA(n.valid), i = a.valid; return r = r.concat(a.errors), r = r.concat(xA(i)), r = r.concat(KA(i)), r = r.concat(qA(i, t)), r = r.concat(WA(i)), r; }
s(DA, "validatePatterns");
function xA(e) { let t = [], r = Ct(e, n => gr(n[_n])); return t = t.concat(FA(r)), t = t.concat(jA(r)), t = t.concat(UA(r)), t = t.concat(BA(r)), t = t.concat(zA(r)), t; }
s(xA, "validateRegExpPattern");
function MA(e) { let t = Ct(e, a => !K(a, _n)), r = F(t, a => ({ message: "Token Type: ->" + a.name + "<- missing static 'PATTERN' property", type: ke.MISSING_PATTERN, tokenTypes: [a] })), n = ou(e, t); return { errors: r, valid: n }; }
s(MA, "findMissingPatterns");
function GA(e) { let t = Ct(e, a => { let i = a[_n]; return !gr(i) && !br(i) && !K(i, "exec") && !st(i); }), r = F(t, a => ({ message: "Token Type: ->" + a.name + "<- static 'PATTERN' can only be a RegExp, a Function matching the {CustomPatternMatcherFunc} type or an Object matching the {ICustomPattern} interface.", type: ke.INVALID_PATTERN, tokenTypes: [a] })), n = ou(e, t); return { errors: r, valid: n }; }
s(GA, "findInvalidPatterns");
var UL = /[^\\][$]/;
function FA(e) {
    class t extends Ul {
        static { s(this, "EndAnchorFinder"); }
        constructor() { super(...arguments), this.found = !1; }
        visitEndAnchor(i) { this.found = !0; }
    }
    let r = Ct(e, a => { let i = a.PATTERN; try {
        let o = Ws(i), l = new t;
        return l.visit(o), l.found;
    }
    catch {
        return UL.test(i.source);
    } });
    return F(r, a => ({ message: `Unexpected RegExp Anchor Error:
	Token Type: ->` + a.name + `<- static 'PATTERN' cannot contain end of input anchor '$'
	See chevrotain.io/docs/guide/resolving_lexer_errors.html#ANCHORS	for details.`, type: ke.EOI_ANCHOR_FOUND, tokenTypes: [a] }));
}
s(FA, "findEndOfInputAnchor");
function zA(e) { let t = Ct(e, n => n.PATTERN.test("")); return F(t, n => ({ message: "Token Type: ->" + n.name + "<- static 'PATTERN' must not match an empty string", type: ke.EMPTY_MATCH_PATTERN, tokenTypes: [n] })); }
s(zA, "findEmptyMatchRegExps");
var BL = /[^\\[][\^]|^\^/;
function jA(e) {
    class t extends Ul {
        static { s(this, "StartAnchorFinder"); }
        constructor() { super(...arguments), this.found = !1; }
        visitStartAnchor(i) { this.found = !0; }
    }
    let r = Ct(e, a => { let i = a.PATTERN; try {
        let o = Ws(i), l = new t;
        return l.visit(o), l.found;
    }
    catch {
        return BL.test(i.source);
    } });
    return F(r, a => ({ message: `Unexpected RegExp Anchor Error:
	Token Type: ->` + a.name + `<- static 'PATTERN' cannot contain start of input anchor '^'
	See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#ANCHORS	for details.`, type: ke.SOI_ANCHOR_FOUND, tokenTypes: [a] }));
}
s(jA, "findStartOfInputAnchor");
function UA(e) { let t = Ct(e, n => { let a = n[_n]; return a instanceof RegExp && (a.multiline || a.global); }); return F(t, n => ({ message: "Token Type: ->" + n.name + "<- static 'PATTERN' may NOT contain global('g') or multiline('m')", type: ke.UNSUPPORTED_FLAGS_FOUND, tokenTypes: [n] })); }
s(UA, "findUnsupportedFlags");
function BA(e) { let t = [], r = F(e, i => gt(e, (o, l) => (i.PATTERN.source === l.PATTERN.source && !nt(t, l) && l.PATTERN !== dt.NA && (t.push(l), o.push(l)), o), [])); r = qs(r); let n = Ct(r, i => i.length > 1); return F(n, i => { let o = F(i, u => u.name); return { message: `The same RegExp pattern ->${Mt(i).PATTERN}<-has been used in all of the following Token Types: ${o.join(", ")} <-`, type: ke.DUPLICATE_PATTERNS_FOUND, tokenTypes: i }; }); }
s(BA, "findDuplicatePatterns");
function KA(e) { let t = Ct(e, n => { if (!K(n, "GROUP"))
    return !1; let a = n.GROUP; return a !== dt.SKIPPED && a !== dt.NA && !st(a); }); return F(t, n => ({ message: "Token Type: ->" + n.name + "<- static 'GROUP' can only be Lexer.SKIPPED/Lexer.NA/A String", type: ke.INVALID_GROUP_TYPE_FOUND, tokenTypes: [n] })); }
s(KA, "findInvalidGroupType");
function qA(e, t) { let r = Ct(e, a => a.PUSH_MODE !== void 0 && !nt(t, a.PUSH_MODE)); return F(r, a => ({ message: `Token Type: ->${a.name}<- static 'PUSH_MODE' value cannot refer to a Lexer Mode ->${a.PUSH_MODE}<-which does not exist`, type: ke.PUSH_MODE_DOES_NOT_EXIST, tokenTypes: [a] })); }
s(qA, "findModesThatDoNotExist");
function WA(e) {
    let t = [], r = gt(e, (n, a, i) => { let o = a.PATTERN; return o === dt.NA || (st(o) ? n.push({ str: o, idx: i, tokenType: a }) : gr(o) && HA(o) && n.push({ str: o.source, idx: i, tokenType: a })), n; }, []);
    return V(e, (n, a) => {
        V(r, ({ str: i, idx: o, tokenType: l }) => {
            if (a < o && VA(i, n.PATTERN)) {
                let u = `Token: ->${l.name}<- can never be matched.
Because it appears AFTER the Token Type ->${n.name}<-in the lexer's definition.
See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#UNREACHABLE`;
                t.push({ message: u, type: ke.UNREACHABLE_PATTERN, tokenTypes: [n, l] });
            }
        });
    }), t;
}
s(WA, "findUnreachablePatterns");
function VA(e, t) { if (gr(t)) {
    if (YA(t))
        return !1;
    let r = t.exec(e);
    return r !== null && r.index === 0;
}
else {
    if (br(t))
        return t(e, 0, [], {});
    if (K(t, "exec"))
        return t.exec(e, 0, [], {});
    if (typeof t == "string")
        return t === e;
    throw Error("non exhaustive match");
} }
s(VA, "tryToMatchStrToPattern");
function HA(e) { return qa([".", "\\", "[", "]", "|", "^", "$", "(", ")", "?", "*", "+", "{"], r => e.source.indexOf(r) !== -1) === void 0; }
s(HA, "noMetaChar");
function YA(e) { return /(\(\?=)|(\(\?!)|(\(\?<=)|(\(\?<!)/.test(e.source); }
s(YA, "usesLookAheadOrBehind");
function _f(e) { let t = e.ignoreCase ? "iy" : "y"; return new RegExp(`${e.source}`, t); }
s(_f, "addStickyFlag");
function XA(e, t, r) {
    let n = [];
    return K(e, Wi) || n.push({ message: "A MultiMode Lexer cannot be initialized without a <" + Wi + `> property in its definition
`, type: ke.MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE }), K(e, eo) || n.push({ message: "A MultiMode Lexer cannot be initialized without a <" + eo + `> property in its definition
`, type: ke.MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY }), K(e, eo) && K(e, Wi) && !K(e.modes, e.defaultMode) && n.push({ message: `A MultiMode Lexer cannot be initialized with a ${Wi}: <${e.defaultMode}>which does not exist
`, type: ke.MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST }), K(e, eo) && V(e.modes, (a, i) => {
        V(a, (o, l) => {
            if (vr(o))
                n.push({ message: `A Lexer cannot be initialized using an undefined Token Type. Mode:<${i}> at index: <${l}>
`, type: ke.LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED });
            else if (K(o, "LONGER_ALT")) {
                let u = te(o.LONGER_ALT) ? o.LONGER_ALT : [o.LONGER_ALT];
                V(u, c => {
                    !vr(c) && !nt(a, c) && n.push({ message: `A MultiMode Lexer cannot be initialized with a longer_alt <${c.name}> on token <${o.name}> outside of mode <${i}>
`, type: ke.MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE });
                });
            }
        });
    }), n;
}
s(XA, "performRuntimeChecks");
function JA(e, t, r) {
    let n = [], a = !1, i = qs(Lt(Ge(e.modes))), o = lu(i, u => u[_n] === dt.NA), l = Kd(r);
    return t && V(o, u => { let c = Bd(u, l); if (c !== !1) {
        let p = { message: eE(u, c), type: c.issue, tokenType: u };
        n.push(p);
    }
    else
        K(u, "LINE_BREAKS") ? u.LINE_BREAKS === !0 && (a = !0) : cu(l, u.PATTERN) && (a = !0); }), t && !a && n.push({ message: `Warning: No LINE_BREAKS Found.
	This Lexer has been defined to track line and column information,
	But none of the Token Types can be identified as matching a line terminator.
	See https://chevrotain.io/docs/guide/resolving_lexer_errors.html#LINE_BREAKS 
	for details.`, type: ke.NO_LINE_BREAKS_FLAGS }), n;
}
s(JA, "performWarningRuntimeChecks");
function ZA(e) { let t = {}, r = ht(e); return V(r, n => { let a = e[n]; if (te(a))
    t[n] = [];
else
    throw Error("non exhaustive match"); }), t; }
s(ZA, "cloneEmptyGroups");
function Ud(e) { let t = e.PATTERN; if (gr(t))
    return !1; if (br(t))
    return !0; if (K(t, "exec"))
    return !0; if (st(t))
    return !1; throw Error("non exhaustive match"); }
s(Ud, "isCustomPattern");
function QA(e) { return st(e) && e.length === 1 ? e.charCodeAt(0) : !1; }
s(QA, "isShortPattern");
var KL = { test: s(function (e) { let t = e.length; for (let r = this.lastIndex; r < t; r++) {
        let n = e.charCodeAt(r);
        if (n === 10)
            return this.lastIndex = r + 1, !0;
        if (n === 13)
            return e.charCodeAt(r + 1) === 10 ? this.lastIndex = r + 2 : this.lastIndex = r + 1, !0;
    } return !1; }, "test"), lastIndex: 0 };
function Bd(e, t) { if (K(e, "LINE_BREAKS"))
    return !1; if (gr(e.PATTERN)) {
    try {
        cu(t, e.PATTERN);
    }
    catch (r) {
        return { issue: ke.IDENTIFY_TERMINATOR, errMsg: r.message };
    }
    return !1;
}
else {
    if (st(e.PATTERN))
        return !1;
    if (Ud(e))
        return { issue: ke.CUSTOM_LINE_BREAK };
    throw Error("non exhaustive match");
} }
s(Bd, "checkLineBreaksIssues");
function eE(e, t) {
    if (t.issue === ke.IDENTIFY_TERMINATOR)
        return `Warning: unable to identify line terminator usage in pattern.
	The problem is in the <${e.name}> Token Type
	 Root cause: ${t.errMsg}.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#IDENTIFY_TERMINATOR`;
    if (t.issue === ke.CUSTOM_LINE_BREAK)
        return `Warning: A Custom Token Pattern should specify the <line_breaks> option.
	The problem is in the <${e.name}> Token Type
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#CUSTOM_LINE_BREAK`;
    throw Error("non exhaustive match");
}
s(eE, "buildLineBreakIssueMessage");
function Kd(e) { return F(e, r => st(r) ? r.charCodeAt(0) : r); }
s(Kd, "getCharCodes");
function wo(e, t, r) { e[t] === void 0 ? e[t] = [r] : e[t].push(r); }
s(wo, "addToMapOfArrays");
var Vi = 256, Io = [];
function Tr(e) { return e < Vi ? e : Io[e]; }
s(Tr, "charCodeToOptimizedIndex");
function tE() { if (he(Io)) {
    Io = new Array(65536);
    for (let e = 0; e < 65536; e++)
        Io[e] = e > 255 ? 255 + ~~(e / 255) : e;
} }
s(tE, "initCharCodeToOptimizedIndexMap");
function ei(e, t) { let r = e.tokenTypeIdx; return r === t.tokenTypeIdx ? !0 : t.isParent === !0 && t.categoryMatchesMap[r] === !0; }
s(ei, "tokenStructuredMatcher");
function Rs(e, t) { return e.tokenTypeIdx === t.tokenTypeIdx; }
s(Rs, "tokenStructuredMatcherNoCategories");
var Gh = 1, rE = {};
function ti(e) { let t = nE(e); aE(t), sE(t), iE(t), V(t, r => { r.isParent = r.categoryMatches.length > 0; }); }
s(ti, "augmentTokenTypes");
function nE(e) { let t = Ye(e), r = e, n = !0; for (; n;) {
    r = qs(Lt(F(r, i => i.CATEGORIES)));
    let a = ou(r, t);
    t = t.concat(a), he(a) ? n = !1 : r = a;
} return t; }
s(nE, "expandCategories");
function aE(e) { V(e, t => { Wd(t) || (rE[Gh] = t, t.tokenTypeIdx = Gh++), Sf(t) && !te(t.CATEGORIES) && (t.CATEGORIES = [t.CATEGORIES]), Sf(t) || (t.CATEGORIES = []), oE(t) || (t.categoryMatches = []), lE(t) || (t.categoryMatchesMap = {}); }); }
s(aE, "assignTokenDefaultProps");
function iE(e) { V(e, t => { t.categoryMatches = [], V(t.categoryMatchesMap, (r, n) => { t.categoryMatches.push(rE[n].tokenTypeIdx); }); }); }
s(iE, "assignCategoriesTokensProp");
function sE(e) { V(e, t => { qd([], t); }); }
s(sE, "assignCategoriesMapProp");
function qd(e, t) { V(e, r => { t.categoryMatchesMap[r.tokenTypeIdx] = !0; }), V(t.CATEGORIES, r => { let n = e.concat(t); nt(n, r) || qd(n, r); }); }
s(qd, "singleAssignCategoriesToksMap");
function Wd(e) { return K(e, "tokenTypeIdx"); }
s(Wd, "hasShortKeyProperty");
function Sf(e) { return K(e, "CATEGORIES"); }
s(Sf, "hasCategoriesProperty");
function oE(e) { return K(e, "categoryMatches"); }
s(oE, "hasExtendingTokensTypesProperty");
function lE(e) { return K(e, "categoryMatchesMap"); }
s(lE, "hasExtendingTokensTypesMapProperty");
function uE(e) { return K(e, "tokenTypeIdx"); }
s(uE, "isTokenType");
var wf = { buildUnableToPopLexerModeMessage(e) { return `Unable to pop Lexer Mode after encountering Token ->${e.image}<- The Mode Stack is empty`; }, buildUnexpectedCharactersMessage(e, t, r, n, a, i) { return `unexpected character: ->${e.charAt(t)}<- at offset: ${t}, skipped ${r} characters.`; } }, ke = (function (e) { return e[e.MISSING_PATTERN = 0] = "MISSING_PATTERN", e[e.INVALID_PATTERN = 1] = "INVALID_PATTERN", e[e.EOI_ANCHOR_FOUND = 2] = "EOI_ANCHOR_FOUND", e[e.UNSUPPORTED_FLAGS_FOUND = 3] = "UNSUPPORTED_FLAGS_FOUND", e[e.DUPLICATE_PATTERNS_FOUND = 4] = "DUPLICATE_PATTERNS_FOUND", e[e.INVALID_GROUP_TYPE_FOUND = 5] = "INVALID_GROUP_TYPE_FOUND", e[e.PUSH_MODE_DOES_NOT_EXIST = 6] = "PUSH_MODE_DOES_NOT_EXIST", e[e.MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE = 7] = "MULTI_MODE_LEXER_WITHOUT_DEFAULT_MODE", e[e.MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY = 8] = "MULTI_MODE_LEXER_WITHOUT_MODES_PROPERTY", e[e.MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST = 9] = "MULTI_MODE_LEXER_DEFAULT_MODE_VALUE_DOES_NOT_EXIST", e[e.LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED = 10] = "LEXER_DEFINITION_CANNOT_CONTAIN_UNDEFINED", e[e.SOI_ANCHOR_FOUND = 11] = "SOI_ANCHOR_FOUND", e[e.EMPTY_MATCH_PATTERN = 12] = "EMPTY_MATCH_PATTERN", e[e.NO_LINE_BREAKS_FLAGS = 13] = "NO_LINE_BREAKS_FLAGS", e[e.UNREACHABLE_PATTERN = 14] = "UNREACHABLE_PATTERN", e[e.IDENTIFY_TERMINATOR = 15] = "IDENTIFY_TERMINATOR", e[e.CUSTOM_LINE_BREAK = 16] = "CUSTOM_LINE_BREAK", e[e.MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE = 17] = "MULTI_MODE_LEXER_LONGER_ALT_NOT_IN_CURRENT_MODE", e; })(ke || {}), Hi = { deferDefinitionErrorsHandling: !1, positionTracking: "full", lineTerminatorsPattern: /\n|\r\n?/g, lineTerminatorCharacters: [`
`, "\r"], ensureOptimizations: !1, safeMode: !1, errorMessageProvider: wf, traceInitPerf: !1, skipValidations: !1, recoveryEnabled: !0 };
Object.freeze(Hi);
var dt = (() => {
    let e = class {
        static { s(this, "Lexer"); }
        constructor(t, r = Hi) {
            if (this.lexerDefinition = t, this.lexerDefinitionErrors = [], this.lexerDefinitionWarning = [], this.patternIdxToConfig = {}, this.charCodeToPatternIdxToConfig = {}, this.modes = [], this.emptyGroups = {}, this.trackStartLines = !0, this.trackEndLines = !0, this.hasCustom = !1, this.canModeBeOptimized = {}, this.TRACE_INIT = (a, i) => { if (this.traceInitPerf === !0) {
                this.traceInitIndent++;
                let o = new Array(this.traceInitIndent + 1).join("	");
                this.traceInitIndent < this.traceInitMaxIdent && console.log(`${o}--> <${a}>`);
                let { time: l, value: u } = zd(i), c = l > 10 ? console.warn : console.log;
                return this.traceInitIndent < this.traceInitMaxIdent && c(`${o}<-- <${a}> time: ${l}ms`), this.traceInitIndent--, u;
            }
            else
                return i(); }, typeof r == "boolean")
                throw Error(`The second argument to the Lexer constructor is now an ILexerConfig Object.
a boolean 2nd argument is no longer supported`);
            this.config = yt({}, Hi, r);
            let n = this.config.traceInitPerf;
            n === !0 ? (this.traceInitMaxIdent = 1 / 0, this.traceInitPerf = !0) : typeof n == "number" && (this.traceInitMaxIdent = n, this.traceInitPerf = !0), this.traceInitIndent = -1, this.TRACE_INIT("Lexer Constructor", () => {
                let a, i = !0;
                this.TRACE_INIT("Lexer Config handling", () => {
                    if (this.config.lineTerminatorsPattern === Hi.lineTerminatorsPattern)
                        this.config.lineTerminatorsPattern = KL;
                    else if (this.config.lineTerminatorCharacters === Hi.lineTerminatorCharacters)
                        throw Error(`Error: Missing <lineTerminatorCharacters> property on the Lexer config.
	For details See: https://chevrotain.io/docs/guide/resolving_lexer_errors.html#MISSING_LINE_TERM_CHARS`);
                    if (r.safeMode && r.ensureOptimizations)
                        throw Error('"safeMode" and "ensureOptimizations" flags are mutually exclusive.');
                    this.trackStartLines = /full|onlyStart/i.test(this.config.positionTracking), this.trackEndLines = /full/i.test(this.config.positionTracking), te(t) ? a = { modes: { defaultMode: Ye(t) }, defaultMode: Wi } : (i = !1, a = Ye(t));
                }), this.config.skipValidations === !1 && (this.TRACE_INIT("performRuntimeChecks", () => { this.lexerDefinitionErrors = this.lexerDefinitionErrors.concat(XA(a, this.trackStartLines, this.config.lineTerminatorCharacters)); }), this.TRACE_INIT("performWarningRuntimeChecks", () => { this.lexerDefinitionWarning = this.lexerDefinitionWarning.concat(JA(a, this.trackStartLines, this.config.lineTerminatorCharacters)); })), a.modes = a.modes ? a.modes : {}, V(a.modes, (l, u) => { a.modes[u] = lu(l, c => vr(c)); });
                let o = ht(a.modes);
                if (V(a.modes, (l, u) => { this.TRACE_INIT(`Mode: <${u}> processing`, () => { if (this.modes.push(u), this.config.skipValidations === !1 && this.TRACE_INIT("validatePatterns", () => { this.lexerDefinitionErrors = this.lexerDefinitionErrors.concat(DA(l, o)); }), he(this.lexerDefinitionErrors)) {
                    ti(l);
                    let c;
                    this.TRACE_INIT("analyzeTokenTypes", () => { c = LA(l, { lineTerminatorCharacters: this.config.lineTerminatorCharacters, positionTracking: r.positionTracking, ensureOptimizations: r.ensureOptimizations, safeMode: r.safeMode, tracer: this.TRACE_INIT }); }), this.patternIdxToConfig[u] = c.patternIdxToConfig, this.charCodeToPatternIdxToConfig[u] = c.charCodeToPatternIdxToConfig, this.emptyGroups = yt({}, this.emptyGroups, c.emptyGroups), this.hasCustom = c.hasCustom || this.hasCustom, this.canModeBeOptimized[u] = c.canBeOptimized;
                } }); }), this.defaultMode = a.defaultMode, !he(this.lexerDefinitionErrors) && !this.config.deferDefinitionErrorsHandling) {
                    let u = F(this.lexerDefinitionErrors, c => c.message).join(`-----------------------
`);
                    throw new Error(`Errors detected in definition of Lexer:
` + u);
                }
                V(this.lexerDefinitionWarning, l => { Fd(l.message); }), this.TRACE_INIT("Choosing sub-methods implementations", () => { if (i && (this.handleModes = ze), this.trackStartLines === !1 && (this.computeNewColumn = Fs), this.trackEndLines === !1 && (this.updateTokenEndLineColumnLocation = ze), /full/i.test(this.config.positionTracking))
                    this.createTokenInstance = this.createFullToken;
                else if (/onlyStart/i.test(this.config.positionTracking))
                    this.createTokenInstance = this.createStartOnlyToken;
                else if (/onlyOffset/i.test(this.config.positionTracking))
                    this.createTokenInstance = this.createOffsetOnlyToken;
                else
                    throw Error(`Invalid <positionTracking> config option: "${this.config.positionTracking}"`); this.hasCustom ? (this.addToken = this.addTokenUsingPush, this.handlePayload = this.handlePayloadWithCustom) : (this.addToken = this.addTokenUsingMemberAccess, this.handlePayload = this.handlePayloadNoCustom); }), this.TRACE_INIT("Failed Optimization Warnings", () => {
                    let l = gt(this.canModeBeOptimized, (u, c, f) => (c === !1 && u.push(f), u), []);
                    if (r.ensureOptimizations && !he(l))
                        throw Error(`Lexer Modes: < ${l.join(", ")} > cannot be optimized.
	 Disable the "ensureOptimizations" lexer config flag to silently ignore this and run the lexer in an un-optimized mode.
	 Or inspect the console log for details on how to resolve these issues.`);
                }), this.TRACE_INIT("clearRegExpParserCache", () => { NA(); }), this.TRACE_INIT("toFastProperties", () => { jd(this); });
            });
        }
        tokenize(t, r = this.defaultMode) {
            if (!he(this.lexerDefinitionErrors)) {
                let a = F(this.lexerDefinitionErrors, i => i.message).join(`-----------------------
`);
                throw new Error(`Unable to Tokenize because Errors detected in definition of Lexer:
` + a);
            }
            return this.tokenizeInternal(t, r);
        }
        tokenizeInternal(t, r) { let n, a, i, o, l, u, c, f, p, m, g, v, _, N, w, S = t, E = S.length, I = 0, j = 0, Q = this.hasCustom ? 0 : Math.floor(t.length / 10), X = new Array(Q), fe = [], ye = this.trackStartLines ? 1 : void 0, pe = this.trackStartLines ? 1 : void 0, k = ZA(this.emptyGroups), b = this.trackStartLines, y = this.config.lineTerminatorsPattern, A = 0, T = [], $ = [], C = [], O = []; Object.freeze(O); let x = !1, D = s(q => { if (C.length === 1 && q.tokenType.PUSH_MODE === void 0) {
            let se = this.config.errorMessageProvider.buildUnableToPopLexerModeMessage(q);
            fe.push({ offset: q.startOffset, line: q.startLine, column: q.startColumn, length: q.image.length, message: se });
        }
        else {
            C.pop();
            let se = Cn(C);
            T = this.patternIdxToConfig[se], $ = this.charCodeToPatternIdxToConfig[se], A = T.length;
            let Be = this.canModeBeOptimized[se] && this.config.safeMode === !1;
            $ && Be ? x = !0 : x = !1;
        } }, "pop_mode"); function U(q) { C.push(q), $ = this.charCodeToPatternIdxToConfig[q], T = this.patternIdxToConfig[q], A = T.length, A = T.length; let se = this.canModeBeOptimized[q] && this.config.safeMode === !1; $ && se ? x = !0 : x = !1; } s(U, "push_mode"), U.call(this, r); let G, ue = this.config.recoveryEnabled; for (; I < E;) {
            u = null, p = -1;
            let q = S.charCodeAt(I), se;
            if (x) {
                let Ce = Tr(q), Ae = $[Ce];
                se = Ae !== void 0 ? Ae : O;
            }
            else
                se = T;
            let Be = se.length;
            for (n = 0; n < Be; n++) {
                G = se[n];
                let Ce = G.pattern;
                c = null;
                let Ae = G.short;
                if (Ae !== !1 ? q === Ae && (p = 1, u = Ce) : G.isCustom === !0 ? (w = Ce.exec(S, I, X, k), w !== null ? (u = w[0], p = u.length, w.payload !== void 0 && (c = w.payload)) : u = null) : (Ce.lastIndex = I, p = this.matchLength(Ce, t, I)), p !== -1) {
                    if (l = G.longerAlt, l !== void 0) {
                        u = t.substring(I, I + p);
                        let xe = l.length;
                        for (i = 0; i < xe; i++) {
                            let Ke = T[l[i]], Le = Ke.pattern;
                            if (f = null, Ke.isCustom === !0 ? (w = Le.exec(S, I, X, k), w !== null ? (o = w[0], w.payload !== void 0 && (f = w.payload)) : o = null) : (Le.lastIndex = I, o = this.match(Le, t, I)), o && o.length > u.length) {
                                u = o, p = o.length, c = f, G = Ke;
                                break;
                            }
                        }
                    }
                    break;
                }
            }
            if (p !== -1) {
                if (m = G.group, m !== void 0 && (u = u !== null ? u : t.substring(I, I + p), g = G.tokenTypeIdx, v = this.createTokenInstance(u, I, g, G.tokenType, ye, pe, p), this.handlePayload(v, c), m === !1 ? j = this.addToken(X, j, v) : k[m].push(v)), b === !0 && G.canLineTerminator === !0) {
                    let Ce = 0, Ae, xe;
                    y.lastIndex = 0;
                    do
                        u = u !== null ? u : t.substring(I, I + p), Ae = y.test(u), Ae === !0 && (xe = y.lastIndex - 1, Ce++);
                    while (Ae === !0);
                    Ce !== 0 ? (ye = ye + Ce, pe = p - xe, this.updateTokenEndLineColumnLocation(v, m, xe, Ce, ye, pe, p)) : pe = this.computeNewColumn(pe, p);
                }
                else
                    pe = this.computeNewColumn(pe, p);
                I = I + p, this.handleModes(G, D, U, v);
            }
            else {
                let Ce = I, Ae = ye, xe = pe, Ke = ue === !1;
                for (; Ke === !1 && I < E;)
                    for (I++, a = 0; a < A; a++) {
                        let Le = T[a], re = Le.pattern, ft = Le.short;
                        if (ft !== !1 ? S.charCodeAt(I) === ft && (Ke = !0) : Le.isCustom === !0 ? Ke = re.exec(S, I, X, k) !== null : (re.lastIndex = I, Ke = re.exec(t) !== null), Ke === !0)
                            break;
                    }
                if (_ = I - Ce, pe = this.computeNewColumn(pe, _), N = this.config.errorMessageProvider.buildUnexpectedCharactersMessage(S, Ce, _, Ae, xe, Cn(C)), fe.push({ offset: Ce, line: Ae, column: xe, length: _, message: N }), ue === !1)
                    break;
            }
        } return this.hasCustom || (X.length = j), { tokens: X, groups: k, errors: fe }; }
        handleModes(t, r, n, a) { if (t.pop === !0) {
            let i = t.push;
            r(a), i !== void 0 && n.call(this, i);
        }
        else
            t.push !== void 0 && n.call(this, t.push); }
        updateTokenEndLineColumnLocation(t, r, n, a, i, o, l) { let u, c; r !== void 0 && (u = n === l - 1, c = u ? -1 : 0, a === 1 && u === !0 || (t.endLine = i + c, t.endColumn = o - 1 + -c)); }
        computeNewColumn(t, r) { return t + r; }
        createOffsetOnlyToken(t, r, n, a) { return { image: t, startOffset: r, tokenTypeIdx: n, tokenType: a }; }
        createStartOnlyToken(t, r, n, a, i, o) { return { image: t, startOffset: r, startLine: i, startColumn: o, tokenTypeIdx: n, tokenType: a }; }
        createFullToken(t, r, n, a, i, o, l) { return { image: t, startOffset: r, endOffset: r + l - 1, startLine: i, endLine: i, startColumn: o, endColumn: o + l - 1, tokenTypeIdx: n, tokenType: a }; }
        addTokenUsingPush(t, r, n) { return t.push(n), r; }
        addTokenUsingMemberAccess(t, r, n) { return t[r] = n, r++, r; }
        handlePayloadNoCustom(t, r) { }
        handlePayloadWithCustom(t, r) { r !== null && (t.payload = r); }
        match(t, r, n) { return t.test(r) === !0 ? r.substring(n, t.lastIndex) : null; }
        matchLength(t, r, n) { return t.test(r) === !0 ? t.lastIndex - n : -1; }
    };
    return e.SKIPPED = "This marks a skipped Token pattern, this means each token identified by it will be consumed and then thrown into oblivion, this can be used to for example to completely ignore whitespace.", e.NA = /NOT_APPLICABLE/, e;
})();
function An(e) { return Vd(e) ? e.LABEL : e.name; }
s(An, "tokenLabel");
function Vd(e) { return st(e.LABEL) && e.LABEL !== ""; }
s(Vd, "hasTokenLabel");
var qL = "parent", Fh = "categories", zh = "label", jh = "group", Uh = "push_mode", Bh = "pop_mode", Kh = "longer_alt", qh = "line_breaks", Wh = "start_chars_hint";
function Da(e) { return cE(e); }
s(Da, "createToken");
function cE(e) {
    let t = e.pattern, r = {};
    if (r.name = e.name, vr(t) || (r.PATTERN = t), K(e, qL))
        throw `The parent property is no longer supported.
See: https://github.com/chevrotain/chevrotain/issues/564#issuecomment-349062346 for details.`;
    return K(e, Fh) && (r.CATEGORIES = e[Fh]), ti([r]), K(e, zh) && (r.LABEL = e[zh]), K(e, jh) && (r.GROUP = e[jh]), K(e, Bh) && (r.POP_MODE = e[Bh]), K(e, Uh) && (r.PUSH_MODE = e[Uh]), K(e, Kh) && (r.LONGER_ALT = e[Kh]), K(e, qh) && (r.LINE_BREAKS = e[qh]), K(e, Wh) && (r.START_CHARS_HINT = e[Wh]), r;
}
s(cE, "createTokenInternal");
var Mr = Da({ name: "EOF", pattern: dt.NA });
ti([Mr]);
function Vs(e, t, r, n, a, i, o, l) { return { image: t, startOffset: r, endOffset: n, startLine: a, endLine: i, startColumn: o, endColumn: l, tokenTypeIdx: e.tokenTypeIdx, tokenType: e }; }
s(Vs, "createTokenInstance");
function Hd(e, t) { return ei(e, t); }
s(Hd, "tokenMatcher");
var Pa = { buildMismatchTokenMessage({ expected: e, actual: t, previous: r, ruleName: n }) { return `Expecting ${Vd(e) ? `--> ${An(e)} <--` : `token of type --> ${e.name} <--`} but found --> '${t.image}' <--`; }, buildNotAllInputParsedMessage({ firstRedundant: e, ruleName: t }) { return "Redundant input, expecting EOF but found: " + e.image; }, buildNoViableAltMessage({ expectedPathsPerAlt: e, actual: t, previous: r, customUserDescription: n, ruleName: a }) {
        let i = "Expecting: ", l = `
but found: '` + Mt(t).image + "'";
        if (n)
            return i + n + l;
        {
            let u = gt(e, (m, g) => m.concat(g), []), c = F(u, m => `[${F(m, g => An(g)).join(", ")}]`), p = `one of these possible Token sequences:
${F(c, (m, g) => `  ${g + 1}. ${m}`).join(`
`)}`;
            return i + p + l;
        }
    }, buildEarlyExitMessage({ expectedIterationPaths: e, actual: t, customUserDescription: r, ruleName: n }) {
        let a = "Expecting: ", o = `
but found: '` + Mt(t).image + "'";
        if (r)
            return a + r + o;
        {
            let u = `expecting at least one iteration which starts with one of these possible Token sequences::
  <${F(e, c => `[${F(c, f => An(f)).join(",")}]`).join(" ,")}>`;
            return a + u + o;
        }
    } };
Object.freeze(Pa);
var WL = { buildRuleNotFoundError(e, t) {
        return "Invalid grammar, reference to a rule which is not defined: ->" + t.nonTerminalName + `<-
inside top level rule: ->` + e.name + "<-";
    } }, $n = { buildDuplicateFoundError(e, t) {
        function r(f) { return f instanceof $e ? f.terminalType.name : f instanceof tt ? f.nonTerminalName : ""; }
        s(r, "getExtraProductionArgument");
        let n = e.name, a = Mt(t), i = a.idx, o = It(a), l = r(a), u = i > 0, c = `->${o}${u ? i : ""}<- ${l ? `with argument: ->${l}<-` : ""}
                  appears more than once (${t.length} times) in the top level rule: ->${n}<-.                  
                  For further details see: https://chevrotain.io/docs/FAQ.html#NUMERICAL_SUFFIXES 
                  `;
        return c = c.replace(/[ \t]+/g, " "), c = c.replace(/\s\s+/g, `
`), c;
    }, buildNamespaceConflictError(e) {
        return `Namespace conflict found in grammar.
The grammar has both a Terminal(Token) and a Non-Terminal(Rule) named: <${e.name}>.
To resolve this make sure each Terminal and Non-Terminal names are unique
This is easy to accomplish by using the convention that Terminal names start with an uppercase letter
and Non-Terminal names start with a lower case letter.`;
    }, buildAlternationPrefixAmbiguityError(e) {
        let t = F(e.prefixPath, a => An(a)).join(", "), r = e.alternation.idx === 0 ? "" : e.alternation.idx;
        return `Ambiguous alternatives: <${e.ambiguityIndices.join(" ,")}> due to common lookahead prefix
in <OR${r}> inside <${e.topLevelRule.name}> Rule,
<${t}> may appears as a prefix path in all these alternatives.
See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#COMMON_PREFIX
For Further details.`;
    }, buildAlternationAmbiguityError(e) {
        let t = e.alternation.idx === 0 ? "" : e.alternation.idx, r = e.prefixPath.length === 0, n = `Ambiguous Alternatives Detected: <${e.ambiguityIndices.join(" ,")}> in <OR${t}> inside <${e.topLevelRule.name}> Rule,
`;
        if (r)
            n += `These alternatives are all empty (match no tokens), making them indistinguishable.
Only the last alternative may be empty.
`;
        else {
            let a = F(e.prefixPath, i => An(i)).join(", ");
            n += `<${a}> may appears as a prefix path in all these alternatives.
`;
        }
        return n += `See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#AMBIGUOUS_ALTERNATIVES
For Further details.`, n;
    }, buildEmptyRepetitionError(e) {
        let t = It(e.repetition);
        return e.repetition.idx !== 0 && (t += e.repetition.idx), `The repetition <${t}> within Rule <${e.topLevelRule.name}> can never consume any tokens.
This could lead to an infinite loop.`;
    }, buildTokenNameError(e) { return "deprecated"; }, buildEmptyAlternationError(e) {
        return `Ambiguous empty alternative: <${e.emptyChoiceIdx + 1}> in <OR${e.alternation.idx}> inside <${e.topLevelRule.name}> Rule.
Only the last alternative may be an empty alternative.`;
    }, buildTooManyAlternativesError(e) {
        return `An Alternation cannot have more than 256 alternatives:
<OR${e.alternation.idx}> inside <${e.topLevelRule.name}> Rule.
 has ${e.alternation.definition.length + 1} alternatives.`;
    }, buildLeftRecursionError(e) {
        let t = e.topLevelRule.name, r = F(e.leftRecursionPath, i => i.name), n = `${t} --> ${r.concat([t]).join(" --> ")}`;
        return `Left Recursion found in grammar.
rule: <${t}> can be invoked from itself (directly or indirectly)
without consuming any Tokens. The grammar path that causes this is: 
 ${n}
 To fix this refactor your grammar to remove the left recursion.
see: https://en.wikipedia.org/wiki/LL_parser#Left_factoring.`;
    }, buildInvalidRuleNameError(e) { return "deprecated"; }, buildDuplicateRuleNameError(e) { let t; return e.topLevelRule instanceof Ja ? t = e.topLevelRule.name : t = e.topLevelRule, `Duplicate definition, rule: ->${t}<- is already defined in the grammar: ->${e.grammarName}<-`; } };
function fE(e, t) { let r = new VL(e, t); return r.resolveRefs(), r.errors; }
s(fE, "resolveGrammar");
var VL = class extends Za {
    static { s(this, "GastRefResolverVisitor"); }
    constructor(e, t) { super(), this.nameToTopRule = e, this.errMsgProvider = t, this.errors = []; }
    resolveRefs() { V(Ge(this.nameToTopRule), e => { this.currTopLevel = e, e.accept(this); }); }
    visitNonTerminal(e) { let t = this.nameToTopRule[e.nonTerminalName]; if (t)
        e.referencedRule = t;
    else {
        let r = this.errMsgProvider.buildRuleNotFoundError(this.currTopLevel, e);
        this.errors.push({ message: r, type: ct.UNRESOLVED_SUBRULE_REF, ruleName: this.currTopLevel.name, unresolvedRefName: e.nonTerminalName });
    } }
}, HL = class extends uu {
    static { s(this, "AbstractNextPossibleTokensWalker"); }
    constructor(e, t) { super(), this.topProd = e, this.path = t, this.possibleTokTypes = [], this.nextProductionName = "", this.nextProductionOccurrence = 0, this.found = !1, this.isAtEndOfPath = !1; }
    startWalking() { if (this.found = !1, this.path.ruleStack[0] !== this.topProd.name)
        throw Error("The path does not start with the walker's top Rule!"); return this.ruleStack = Ye(this.path.ruleStack).reverse(), this.occurrenceStack = Ye(this.path.occurrenceStack).reverse(), this.ruleStack.pop(), this.occurrenceStack.pop(), this.updateExpectedNext(), this.walk(this.topProd), this.possibleTokTypes; }
    walk(e, t = []) { this.found || super.walk(e, t); }
    walkProdRef(e, t, r) { if (e.referencedRule.name === this.nextProductionName && e.idx === this.nextProductionOccurrence) {
        let n = t.concat(r);
        this.updateExpectedNext(), this.walk(e.referencedRule, n);
    } }
    updateExpectedNext() { he(this.ruleStack) ? (this.nextProductionName = "", this.nextProductionOccurrence = 0, this.isAtEndOfPath = !0) : (this.nextProductionName = this.ruleStack.pop(), this.nextProductionOccurrence = this.occurrenceStack.pop()); }
}, YL = class extends HL {
    static { s(this, "NextAfterTokenWalker"); }
    constructor(e, t) { super(e, t), this.path = t, this.nextTerminalName = "", this.nextTerminalOccurrence = 0, this.nextTerminalName = this.path.lastTok.name, this.nextTerminalOccurrence = this.path.lastTokOccurrence; }
    walkTerminal(e, t, r) { if (this.isAtEndOfPath && e.terminalType.name === this.nextTerminalName && e.idx === this.nextTerminalOccurrence && !this.found) {
        let n = t.concat(r), a = new ot({ definition: n });
        this.possibleTokTypes = Qa(a), this.found = !0;
    } }
}, fu = class extends uu {
    static { s(this, "AbstractNextTerminalAfterProductionWalker"); }
    constructor(e, t) { super(), this.topRule = e, this.occurrence = t, this.result = { token: void 0, occurrence: void 0, isEndOfRule: void 0 }; }
    startWalking() { return this.walk(this.topRule), this.result; }
}, XL = class extends fu {
    static { s(this, "NextTerminalAfterManyWalker"); }
    walkMany(e, t, r) { if (e.idx === this.occurrence) {
        let n = Mt(t.concat(r));
        this.result.isEndOfRule = n === void 0, n instanceof $e && (this.result.token = n.terminalType, this.result.occurrence = n.idx);
    }
    else
        super.walkMany(e, t, r); }
}, Vh = class extends fu {
    static { s(this, "NextTerminalAfterManySepWalker"); }
    walkManySep(e, t, r) { if (e.idx === this.occurrence) {
        let n = Mt(t.concat(r));
        this.result.isEndOfRule = n === void 0, n instanceof $e && (this.result.token = n.terminalType, this.result.occurrence = n.idx);
    }
    else
        super.walkManySep(e, t, r); }
}, JL = class extends fu {
    static { s(this, "NextTerminalAfterAtLeastOneWalker"); }
    walkAtLeastOne(e, t, r) { if (e.idx === this.occurrence) {
        let n = Mt(t.concat(r));
        this.result.isEndOfRule = n === void 0, n instanceof $e && (this.result.token = n.terminalType, this.result.occurrence = n.idx);
    }
    else
        super.walkAtLeastOne(e, t, r); }
}, Hh = class extends fu {
    static { s(this, "NextTerminalAfterAtLeastOneSepWalker"); }
    walkAtLeastOneSep(e, t, r) { if (e.idx === this.occurrence) {
        let n = Mt(t.concat(r));
        this.result.isEndOfRule = n === void 0, n instanceof $e && (this.result.token = n.terminalType, this.result.occurrence = n.idx);
    }
    else
        super.walkAtLeastOneSep(e, t, r); }
};
function ml(e, t, r = []) { r = Ye(r); let n = [], a = 0; function i(l) { return l.concat(Ve(e, a + 1)); } s(i, "remainingPathWith"); function o(l) { let u = ml(i(l), t, r); return n.concat(u); } for (s(o, "getAlternativesForProd"); r.length < t && a < e.length;) {
    let l = e[a];
    if (l instanceof ot)
        return o(l.definition);
    if (l instanceof tt)
        return o(l.definition);
    if (l instanceof He)
        n = o(l.definition);
    else if (l instanceof vt) {
        let u = l.definition.concat([new Ie({ definition: l.definition })]);
        return o(u);
    }
    else if (l instanceof Tt) {
        let u = [new ot({ definition: l.definition }), new Ie({ definition: [new $e({ terminalType: l.separator })].concat(l.definition) })];
        return o(u);
    }
    else if (l instanceof lt) {
        let u = l.definition.concat([new Ie({ definition: [new $e({ terminalType: l.separator })].concat(l.definition) })]);
        n = o(u);
    }
    else if (l instanceof Ie) {
        let u = l.definition.concat([new Ie({ definition: l.definition })]);
        n = o(u);
    }
    else {
        if (l instanceof ut)
            return V(l.definition, u => { he(u.definition) === !1 && (n = o(u.definition)); }), n;
        if (l instanceof $e)
            r.push(l.terminalType);
        else
            throw Error("non exhaustive match");
    }
    a++;
} return n.push({ partialPath: r, suffixDef: Ve(e, a) }), n; }
s(ml, "possiblePathsFrom");
function Yd(e, t, r, n) { let a = "EXIT_NONE_TERMINAL", i = [a], o = "EXIT_ALTERNATIVE", l = !1, u = t.length, c = u - n - 1, f = [], p = []; for (p.push({ idx: -1, def: e, ruleStack: [], occurrenceStack: [] }); !he(p);) {
    let m = p.pop();
    if (m === o) {
        l && Cn(p).idx <= c && p.pop();
        continue;
    }
    let g = m.def, v = m.idx, _ = m.ruleStack, N = m.occurrenceStack;
    if (he(g))
        continue;
    let w = g[0];
    if (w === a) {
        let S = { idx: v, def: Ve(g), ruleStack: Ts(_), occurrenceStack: Ts(N) };
        p.push(S);
    }
    else if (w instanceof $e)
        if (v < u - 1) {
            let S = v + 1, E = t[S];
            if (r(E, w.terminalType)) {
                let I = { idx: S, def: Ve(g), ruleStack: _, occurrenceStack: N };
                p.push(I);
            }
        }
        else if (v === u - 1)
            f.push({ nextTokenType: w.terminalType, nextTokenOccurrence: w.idx, ruleStack: _, occurrenceStack: N }), l = !0;
        else
            throw Error("non exhaustive match");
    else if (w instanceof tt) {
        let S = Ye(_);
        S.push(w.nonTerminalName);
        let E = Ye(N);
        E.push(w.idx);
        let I = { idx: v, def: w.definition.concat(i, Ve(g)), ruleStack: S, occurrenceStack: E };
        p.push(I);
    }
    else if (w instanceof He) {
        let S = { idx: v, def: Ve(g), ruleStack: _, occurrenceStack: N };
        p.push(S), p.push(o);
        let E = { idx: v, def: w.definition.concat(Ve(g)), ruleStack: _, occurrenceStack: N };
        p.push(E);
    }
    else if (w instanceof vt) {
        let S = new Ie({ definition: w.definition, idx: w.idx }), E = w.definition.concat([S], Ve(g)), I = { idx: v, def: E, ruleStack: _, occurrenceStack: N };
        p.push(I);
    }
    else if (w instanceof Tt) {
        let S = new $e({ terminalType: w.separator }), E = new Ie({ definition: [S].concat(w.definition), idx: w.idx }), I = w.definition.concat([E], Ve(g)), j = { idx: v, def: I, ruleStack: _, occurrenceStack: N };
        p.push(j);
    }
    else if (w instanceof lt) {
        let S = { idx: v, def: Ve(g), ruleStack: _, occurrenceStack: N };
        p.push(S), p.push(o);
        let E = new $e({ terminalType: w.separator }), I = new Ie({ definition: [E].concat(w.definition), idx: w.idx }), j = w.definition.concat([I], Ve(g)), Q = { idx: v, def: j, ruleStack: _, occurrenceStack: N };
        p.push(Q);
    }
    else if (w instanceof Ie) {
        let S = { idx: v, def: Ve(g), ruleStack: _, occurrenceStack: N };
        p.push(S), p.push(o);
        let E = new Ie({ definition: w.definition, idx: w.idx }), I = w.definition.concat([E], Ve(g)), j = { idx: v, def: I, ruleStack: _, occurrenceStack: N };
        p.push(j);
    }
    else if (w instanceof ut)
        for (let S = w.definition.length - 1; S >= 0; S--) {
            let E = w.definition[S], I = { idx: v, def: E.definition.concat(Ve(g)), ruleStack: _, occurrenceStack: N };
            p.push(I), p.push(o);
        }
    else if (w instanceof ot)
        p.push({ idx: v, def: w.definition.concat(Ve(g)), ruleStack: _, occurrenceStack: N });
    else if (w instanceof Ja)
        p.push(pE(w, v, _, N));
    else
        throw Error("non exhaustive match");
} return f; }
s(Yd, "nextPossibleTokensAfter");
function pE(e, t, r, n) { let a = Ye(r); a.push(e.name); let i = Ye(n); return i.push(1), { idx: t, def: e.definition, ruleStack: a, occurrenceStack: i }; }
s(pE, "expandTopLevelRule");
var we = (function (e) { return e[e.OPTION = 0] = "OPTION", e[e.REPETITION = 1] = "REPETITION", e[e.REPETITION_MANDATORY = 2] = "REPETITION_MANDATORY", e[e.REPETITION_MANDATORY_WITH_SEPARATOR = 3] = "REPETITION_MANDATORY_WITH_SEPARATOR", e[e.REPETITION_WITH_SEPARATOR = 4] = "REPETITION_WITH_SEPARATOR", e[e.ALTERNATION = 5] = "ALTERNATION", e; })(we || {});
function pu(e) { if (e instanceof He || e === "Option")
    return we.OPTION; if (e instanceof Ie || e === "Repetition")
    return we.REPETITION; if (e instanceof vt || e === "RepetitionMandatory")
    return we.REPETITION_MANDATORY; if (e instanceof Tt || e === "RepetitionMandatoryWithSeparator")
    return we.REPETITION_MANDATORY_WITH_SEPARATOR; if (e instanceof lt || e === "RepetitionWithSeparator")
    return we.REPETITION_WITH_SEPARATOR; if (e instanceof ut || e === "Alternation")
    return we.ALTERNATION; throw Error("non exhaustive match"); }
s(pu, "getProdType");
function If(e) { let { occurrence: t, rule: r, prodType: n, maxLookahead: a } = e, i = pu(n); return i === we.ALTERNATION ? Hs(t, r, a) : Ys(t, r, i, a); }
s(If, "getLookaheadPaths");
function dE(e, t, r, n, a, i) { let o = Hs(e, t, r), l = Jd(o) ? Rs : ei; return i(o, n, l, a); }
s(dE, "buildLookaheadFuncForOr");
function mE(e, t, r, n, a, i) { let o = Ys(e, t, a, r), l = Jd(o) ? Rs : ei; return i(o[0], l, n); }
s(mE, "buildLookaheadFuncForOptionalProd");
function hE(e, t, r, n) { let a = e.length, i = Dt(e, o => Dt(o, l => l.length === 1)); if (t)
    return function (o) { let l = F(o, u => u.GATE); for (let u = 0; u < a; u++) {
        let c = e[u], f = c.length, p = l[u];
        if (!(p !== void 0 && p.call(this) === !1))
            e: for (let m = 0; m < f; m++) {
                let g = c[m], v = g.length;
                for (let _ = 0; _ < v; _++) {
                    let N = this.LA(_ + 1);
                    if (r(N, g[_]) === !1)
                        continue e;
                }
                return u;
            }
    } }; if (i && !n) {
    let o = F(e, u => Lt(u)), l = gt(o, (u, c, f) => (V(c, p => { K(u, p.tokenTypeIdx) || (u[p.tokenTypeIdx] = f), V(p.categoryMatches, m => { K(u, m) || (u[m] = f); }); }), u), {});
    return function () { let u = this.LA(1); return l[u.tokenTypeIdx]; };
}
else
    return function () { for (let o = 0; o < a; o++) {
        let l = e[o], u = l.length;
        e: for (let c = 0; c < u; c++) {
            let f = l[c], p = f.length;
            for (let m = 0; m < p; m++) {
                let g = this.LA(m + 1);
                if (r(g, f[m]) === !1)
                    continue e;
            }
            return o;
        }
    } }; }
s(hE, "buildAlternativesLookAheadFunc");
function yE(e, t, r) { let n = Dt(e, i => i.length === 1), a = e.length; if (n && !r) {
    let i = Lt(e);
    if (i.length === 1 && he(i[0].categoryMatches)) {
        let l = i[0].tokenTypeIdx;
        return function () { return this.LA(1).tokenTypeIdx === l; };
    }
    else {
        let o = gt(i, (l, u, c) => (l[u.tokenTypeIdx] = !0, V(u.categoryMatches, f => { l[f] = !0; }), l), []);
        return function () { let l = this.LA(1); return o[l.tokenTypeIdx] === !0; };
    }
}
else
    return function () { e: for (let i = 0; i < a; i++) {
        let o = e[i], l = o.length;
        for (let u = 0; u < l; u++) {
            let c = this.LA(u + 1);
            if (t(c, o[u]) === !1)
                continue e;
        }
        return !0;
    } return !1; }; }
s(yE, "buildSingleAlternativeLookaheadFunction");
var ZL = class extends uu {
    static { s(this, "RestDefinitionFinderWalker"); }
    constructor(e, t, r) { super(), this.topProd = e, this.targetOccurrence = t, this.targetProdType = r; }
    startWalking() { return this.walk(this.topProd), this.restDef; }
    checkIsTarget(e, t, r, n) { return e.idx === this.targetOccurrence && this.targetProdType === t ? (this.restDef = r.concat(n), !0) : !1; }
    walkOption(e, t, r) { this.checkIsTarget(e, we.OPTION, t, r) || super.walkOption(e, t, r); }
    walkAtLeastOne(e, t, r) { this.checkIsTarget(e, we.REPETITION_MANDATORY, t, r) || super.walkOption(e, t, r); }
    walkAtLeastOneSep(e, t, r) { this.checkIsTarget(e, we.REPETITION_MANDATORY_WITH_SEPARATOR, t, r) || super.walkOption(e, t, r); }
    walkMany(e, t, r) { this.checkIsTarget(e, we.REPETITION, t, r) || super.walkOption(e, t, r); }
    walkManySep(e, t, r) { this.checkIsTarget(e, we.REPETITION_WITH_SEPARATOR, t, r) || super.walkOption(e, t, r); }
}, gE = class extends Za {
    static { s(this, "InsideDefinitionFinderVisitor"); }
    constructor(e, t, r) { super(), this.targetOccurrence = e, this.targetProdType = t, this.targetRef = r, this.result = []; }
    checkIsTarget(e, t) { e.idx === this.targetOccurrence && this.targetProdType === t && (this.targetRef === void 0 || e === this.targetRef) && (this.result = e.definition); }
    visitOption(e) { this.checkIsTarget(e, we.OPTION); }
    visitRepetition(e) { this.checkIsTarget(e, we.REPETITION); }
    visitRepetitionMandatory(e) { this.checkIsTarget(e, we.REPETITION_MANDATORY); }
    visitRepetitionMandatoryWithSeparator(e) { this.checkIsTarget(e, we.REPETITION_MANDATORY_WITH_SEPARATOR); }
    visitRepetitionWithSeparator(e) { this.checkIsTarget(e, we.REPETITION_WITH_SEPARATOR); }
    visitAlternation(e) { this.checkIsTarget(e, we.ALTERNATION); }
};
function Nf(e) { let t = new Array(e); for (let r = 0; r < e; r++)
    t[r] = []; return t; }
s(Nf, "initializeArrayOfArrays");
function No(e) { let t = [""]; for (let r = 0; r < e.length; r++) {
    let n = e[r], a = [];
    for (let i = 0; i < t.length; i++) {
        let o = t[i];
        a.push(o + "_" + n.tokenTypeIdx);
        for (let l = 0; l < n.categoryMatches.length; l++) {
            let u = "_" + n.categoryMatches[l];
            a.push(o + u);
        }
    }
    t = a;
} return t; }
s(No, "pathToHashKeys");
function vE(e, t, r) { for (let n = 0; n < e.length; n++) {
    if (n === r)
        continue;
    let a = e[n];
    for (let i = 0; i < t.length; i++) {
        let o = t[i];
        if (a[o] === !0)
            return !1;
    }
} return !0; }
s(vE, "isUniquePrefixHash");
function Xd(e, t) { let r = F(e, o => ml([o], 1)), n = Nf(r.length), a = F(r, o => { let l = {}; return V(o, u => { let c = No(u.partialPath); V(c, f => { l[f] = !0; }); }), l; }), i = r; for (let o = 1; o <= t; o++) {
    let l = i;
    i = Nf(l.length);
    for (let u = 0; u < l.length; u++) {
        let c = l[u];
        for (let f = 0; f < c.length; f++) {
            let p = c[f].partialPath, m = c[f].suffixDef, g = No(p);
            if (vE(a, g, u) || he(m) || p.length === t) {
                let _ = n[u];
                if (hl(_, p) === !1) {
                    _.push(p);
                    for (let N = 0; N < g.length; N++) {
                        let w = g[N];
                        a[u][w] = !0;
                    }
                }
            }
            else {
                let _ = ml(m, o + 1, p);
                i[u] = i[u].concat(_), V(_, N => { let w = No(N.partialPath); V(w, S => { a[u][S] = !0; }); });
            }
        }
    }
} return n; }
s(Xd, "lookAheadSequenceFromAlternatives");
function Hs(e, t, r, n) { let a = new gE(e, we.ALTERNATION, n); return t.accept(a), Xd(a.result, r); }
s(Hs, "getLookaheadPathsForOr");
function Ys(e, t, r, n) { let a = new gE(e, r); t.accept(a); let i = a.result, l = new ZL(t, e, r).startWalking(), u = new ot({ definition: i }), c = new ot({ definition: l }); return Xd([u, c], n); }
s(Ys, "getLookaheadPathsForOptionalProd");
function hl(e, t) { e: for (let r = 0; r < e.length; r++) {
    let n = e[r];
    if (n.length === t.length) {
        for (let a = 0; a < n.length; a++) {
            let i = t[a], o = n[a];
            if ((i === o || o.categoryMatchesMap[i.tokenTypeIdx] !== void 0) === !1)
                continue e;
        }
        return !0;
    }
} return !1; }
s(hl, "containsPath");
function TE(e, t) { return e.length < t.length && Dt(e, (r, n) => { let a = t[n]; return r === a || a.categoryMatchesMap[r.tokenTypeIdx]; }); }
s(TE, "isStrictPrefixOfPath");
function Jd(e) { return Dt(e, t => Dt(t, r => Dt(r, n => he(n.categoryMatches)))); }
s(Jd, "areTokenCategoriesNotUsed");
function $E(e) { let t = e.lookaheadStrategy.validate({ rules: e.rules, tokenTypes: e.tokenTypes, grammarName: e.grammarName }); return F(t, r => Object.assign({ type: ct.CUSTOM_LOOKAHEAD_VALIDATION }, r)); }
s($E, "validateLookahead");
function RE(e, t, r, n) { let a = Rt(e, u => AE(u, r)), i = kE(e, t, r), o = Rt(e, u => wE(u, r)), l = Rt(e, u => bE(u, e, n, r)); return a.concat(i, o, l); }
s(RE, "validateGrammar");
function AE(e, t) { let r = new QL; e.accept(r); let n = r.allProductions, a = dL(n, EE), i = Gt(a, l => l.length > 1); return F(Ge(i), l => { let u = Mt(l), c = t.buildDuplicateFoundError(e, l), f = It(u), p = { message: c, type: ct.DUPLICATE_PRODUCTIONS, ruleName: e.name, dslName: f, occurrence: u.idx }, m = Zd(u); return m && (p.parameter = m), p; }); }
s(AE, "validateDuplicateProductions");
function EE(e) { return `${It(e)}_#_${e.idx}_#_${Zd(e)}`; }
s(EE, "identifyProductionForDuplicates");
function Zd(e) { return e instanceof $e ? e.terminalType.name : e instanceof tt ? e.nonTerminalName : ""; }
s(Zd, "getExtraProductionArgument");
var QL = class extends Za {
    static { s(this, "OccurrenceValidationCollector"); }
    constructor() { super(...arguments), this.allProductions = []; }
    visitNonTerminal(e) { this.allProductions.push(e); }
    visitOption(e) { this.allProductions.push(e); }
    visitRepetitionWithSeparator(e) { this.allProductions.push(e); }
    visitRepetitionMandatory(e) { this.allProductions.push(e); }
    visitRepetitionMandatoryWithSeparator(e) { this.allProductions.push(e); }
    visitRepetition(e) { this.allProductions.push(e); }
    visitAlternation(e) { this.allProductions.push(e); }
    visitTerminal(e) { this.allProductions.push(e); }
};
function bE(e, t, r, n) { let a = []; if (gt(t, (o, l) => l.name === e.name ? o + 1 : o, 0) > 1) {
    let o = n.buildDuplicateRuleNameError({ topLevelRule: e, grammarName: r });
    a.push({ message: o, type: ct.DUPLICATE_RULE_NAME, ruleName: e.name });
} return a; }
s(bE, "validateRuleDoesNotAlreadyExist");
function CE(e, t, r) { let n = [], a; return nt(t, e) || (a = `Invalid rule override, rule: ->${e}<- cannot be overridden in the grammar: ->${r}<-as it is not defined in any of the super grammars `, n.push({ message: a, type: ct.INVALID_RULE_OVERRIDE, ruleName: e })), n; }
s(CE, "validateRuleIsOverridden");
function Qd(e, t, r, n = []) { let a = [], i = us(t.definition); if (he(i))
    return []; {
    let o = e.name;
    nt(i, e) && a.push({ message: r.buildLeftRecursionError({ topLevelRule: e, leftRecursionPath: n }), type: ct.LEFT_RECURSION, ruleName: o });
    let u = ou(i, n.concat([e])), c = Rt(u, f => { let p = Ye(n); return p.push(f), Qd(e, f, r, p); });
    return a.concat(c);
} }
s(Qd, "validateNoLeftRecursion");
function us(e) { let t = []; if (he(e))
    return t; let r = Mt(e); if (r instanceof tt)
    t.push(r.referencedRule);
else if (r instanceof ot || r instanceof He || r instanceof vt || r instanceof Tt || r instanceof lt || r instanceof Ie)
    t = t.concat(us(r.definition));
else if (r instanceof ut)
    t = Lt(F(r.definition, i => us(i.definition)));
else if (!(r instanceof $e))
    throw Error("non exhaustive match"); let n = $s(r), a = e.length > 1; if (n && a) {
    let i = Ve(e);
    return t.concat(us(i));
}
else
    return t; }
s(us, "getFirstNoneTerminal");
var em = class extends Za {
    static { s(this, "OrCollector"); }
    constructor() { super(...arguments), this.alternations = []; }
    visitAlternation(e) { this.alternations.push(e); }
};
function _E(e, t) { let r = new em; e.accept(r); let n = r.alternations; return Rt(n, i => { let o = Ts(i.definition); return Rt(o, (l, u) => { let c = Yd([l], [], ei, 1); return he(c) ? [{ message: t.buildEmptyAlternationError({ topLevelRule: e, alternation: i, emptyChoiceIdx: u }), type: ct.NONE_LAST_EMPTY_ALT, ruleName: e.name, occurrence: i.idx, alternative: u + 1 }] : []; }); }); }
s(_E, "validateEmptyOrAlternative");
function SE(e, t, r) { let n = new em; e.accept(n); let a = n.alternations; return a = lu(a, o => o.ignoreAmbiguities === !0), Rt(a, o => { let l = o.idx, u = o.maxLookahead || t, c = Hs(l, e, u, o), f = NE(c, o, e, r), p = PE(c, o, e, r); return f.concat(p); }); }
s(SE, "validateAmbiguousAlternationAlternatives");
var eD = class extends Za {
    static { s(this, "RepetitionCollector"); }
    constructor() { super(...arguments), this.allProductions = []; }
    visitRepetitionWithSeparator(e) { this.allProductions.push(e); }
    visitRepetitionMandatory(e) { this.allProductions.push(e); }
    visitRepetitionMandatoryWithSeparator(e) { this.allProductions.push(e); }
    visitRepetition(e) { this.allProductions.push(e); }
};
function wE(e, t) { let r = new em; e.accept(r); let n = r.alternations; return Rt(n, i => i.definition.length > 255 ? [{ message: t.buildTooManyAlternativesError({ topLevelRule: e, alternation: i }), type: ct.TOO_MANY_ALTS, ruleName: e.name, occurrence: i.idx }] : []); }
s(wE, "validateTooManyAlts");
function IE(e, t, r) { let n = []; return V(e, a => { let i = new eD; a.accept(i); let o = i.allProductions; V(o, l => { let u = pu(l), c = l.maxLookahead || t, f = l.idx, m = Ys(f, a, u, c)[0]; if (he(Lt(m))) {
    let g = r.buildEmptyRepetitionError({ topLevelRule: a, repetition: l });
    n.push({ message: g, type: ct.NO_NON_EMPTY_LOOKAHEAD, ruleName: a.name });
} }); }), n; }
s(IE, "validateSomeNonEmptyLookaheadPath");
function NE(e, t, r, n) { let a = [], i = gt(e, (l, u, c) => (t.definition[c].ignoreAmbiguities === !0 || V(u, f => { let p = [c]; V(e, (m, g) => { c !== g && hl(m, f) && t.definition[g].ignoreAmbiguities !== !0 && p.push(g); }), p.length > 1 && !hl(a, f) && (a.push(f), l.push({ alts: p, path: f })); }), l), []); return F(i, l => { let u = F(l.alts, f => f + 1); return { message: n.buildAlternationAmbiguityError({ topLevelRule: r, alternation: t, ambiguityIndices: u, prefixPath: l.path }), type: ct.AMBIGUOUS_ALTS, ruleName: r.name, occurrence: t.idx, alternatives: l.alts }; }); }
s(NE, "checkAlternativesAmbiguities");
function PE(e, t, r, n) { let a = gt(e, (o, l, u) => { let c = F(l, f => ({ idx: u, path: f })); return o.concat(c); }, []); return qs(Rt(a, o => { if (t.definition[o.idx].ignoreAmbiguities === !0)
    return []; let u = o.idx, c = o.path, f = Ct(a, m => t.definition[m.idx].ignoreAmbiguities !== !0 && m.idx < u && TE(m.path, c)); return F(f, m => { let g = [m.idx + 1, u + 1], v = t.idx === 0 ? "" : t.idx; return { message: n.buildAlternationPrefixAmbiguityError({ topLevelRule: r, alternation: t, ambiguityIndices: g, prefixPath: m.path }), type: ct.AMBIGUOUS_PREFIX_ALTS, ruleName: r.name, occurrence: v, alternatives: g }; }); })); }
s(PE, "checkPrefixAlternativesAmbiguities");
function kE(e, t, r) { let n = [], a = F(t, i => i.name); return V(e, i => { let o = i.name; if (nt(a, o)) {
    let l = r.buildNamespaceConflictError(i);
    n.push({ message: l, type: ct.CONFLICT_TOKENS_RULES_NAMESPACE, ruleName: o });
} }), n; }
s(kE, "checkTerminalAndNoneTerminalsNameSpace");
function OE(e) { let t = Md(e, { errMsgProvider: WL }), r = {}; return V(e.rules, n => { r[n.name] = n; }), fE(r, t.errMsgProvider); }
s(OE, "resolveGrammar");
function LE(e) { return e = Md(e, { errMsgProvider: $n }), RE(e.rules, e.tokenTypes, e.errMsgProvider, e.grammarName); }
s(LE, "validateGrammar");
var DE = "MismatchedTokenException", xE = "NoViableAltException", ME = "EarlyExitException", GE = "NotAllInputParsedException", FE = [DE, xE, ME, GE];
Object.freeze(FE);
function As(e) { return nt(FE, e.name); }
s(As, "isRecognitionException");
var du = class extends Error {
    static { s(this, "RecognitionException"); }
    constructor(e, t) { super(e), this.token = t, this.resyncedTokens = [], Object.setPrototypeOf(this, new.target.prototype), Error.captureStackTrace && Error.captureStackTrace(this, this.constructor); }
}, zE = class extends du {
    static { s(this, "MismatchedTokenException"); }
    constructor(e, t, r) { super(e, t), this.previousToken = r, this.name = DE; }
}, tD = class extends du {
    static { s(this, "NoViableAltException"); }
    constructor(e, t, r) { super(e, t), this.previousToken = r, this.name = xE; }
}, rD = class extends du {
    static { s(this, "NotAllInputParsedException"); }
    constructor(e, t) { super(e, t), this.name = GE; }
}, nD = class extends du {
    static { s(this, "EarlyExitException"); }
    constructor(e, t, r) { super(e, t), this.previousToken = r, this.name = ME; }
}, Ku = {}, jE = "InRuleRecoveryException", aD = class extends Error {
    static { s(this, "InRuleRecoveryException"); }
    constructor(e) { super(e), this.name = jE; }
}, iD = class {
    static { s(this, "Recoverable"); }
    initRecoverable(e) { this.firstAfterRepMap = {}, this.resyncFollows = {}, this.recoveryEnabled = K(e, "recoveryEnabled") ? e.recoveryEnabled : $r.recoveryEnabled, this.recoveryEnabled && (this.attemptInRepetitionRecovery = UE); }
    getTokenToInsert(e) { let t = Vs(e, "", NaN, NaN, NaN, NaN, NaN, NaN); return t.isInsertedInRecovery = !0, t; }
    canTokenTypeBeInsertedInRecovery(e) { return !0; }
    canTokenTypeBeDeletedInRecovery(e) { return !0; }
    tryInRepetitionRecovery(e, t, r, n) { let a = this.findReSyncTokenType(), i = this.exportLexerState(), o = [], l = !1, u = this.LA(1), c = this.LA(1), f = s(() => { let p = this.LA(0), m = this.errorMessageProvider.buildMismatchTokenMessage({ expected: n, actual: u, previous: p, ruleName: this.getCurrRuleFullName() }), g = new zE(m, u, this.LA(0)); g.resyncedTokens = Ts(o), this.SAVE_ERROR(g); }, "generateErrorMessage"); for (; !l;)
        if (this.tokenMatcher(c, n)) {
            f();
            return;
        }
        else if (r.call(this)) {
            f(), e.apply(this, t);
            return;
        }
        else
            this.tokenMatcher(c, a) ? l = !0 : (c = this.SKIP_TOKEN(), this.addToResyncTokens(c, o)); this.importLexerState(i); }
    shouldInRepetitionRecoveryBeTried(e, t, r) { return !(r === !1 || this.tokenMatcher(this.LA(1), e) || this.isBackTracking() || this.canPerformInRuleRecovery(e, this.getFollowsForInRuleRecovery(e, t))); }
    getFollowsForInRuleRecovery(e, t) { let r = this.getCurrentGrammarPath(e, t); return this.getNextPossibleTokenTypes(r); }
    tryInRuleRecovery(e, t) { if (this.canRecoverWithSingleTokenInsertion(e, t))
        return this.getTokenToInsert(e); if (this.canRecoverWithSingleTokenDeletion(e)) {
        let r = this.SKIP_TOKEN();
        return this.consumeToken(), r;
    } throw new aD("sad sad panda"); }
    canPerformInRuleRecovery(e, t) { return this.canRecoverWithSingleTokenInsertion(e, t) || this.canRecoverWithSingleTokenDeletion(e); }
    canRecoverWithSingleTokenInsertion(e, t) { if (!this.canTokenTypeBeInsertedInRecovery(e) || he(t))
        return !1; let r = this.LA(1); return qa(t, a => this.tokenMatcher(r, a)) !== void 0; }
    canRecoverWithSingleTokenDeletion(e) { return this.canTokenTypeBeDeletedInRecovery(e) ? this.tokenMatcher(this.LA(2), e) : !1; }
    isInCurrentRuleReSyncSet(e) { let t = this.getCurrFollowKey(), r = this.getFollowSetFromFollowKey(t); return nt(r, e); }
    findReSyncTokenType() { let e = this.flattenFollowSet(), t = this.LA(1), r = 2; for (;;) {
        let n = qa(e, a => Hd(t, a));
        if (n !== void 0)
            return n;
        t = this.LA(r), r++;
    } }
    getCurrFollowKey() { if (this.RULE_STACK.length === 1)
        return Ku; let e = this.getLastExplicitRuleShortName(), t = this.getLastExplicitRuleOccurrenceIndex(), r = this.getPreviousExplicitRuleShortName(); return { ruleName: this.shortRuleNameToFullName(e), idxInCallingRule: t, inRule: this.shortRuleNameToFullName(r) }; }
    buildFullFollowKeyStack() { let e = this.RULE_STACK, t = this.RULE_OCCURRENCE_STACK; return F(e, (r, n) => n === 0 ? Ku : { ruleName: this.shortRuleNameToFullName(r), idxInCallingRule: t[n], inRule: this.shortRuleNameToFullName(e[n - 1]) }); }
    flattenFollowSet() { let e = F(this.buildFullFollowKeyStack(), t => this.getFollowSetFromFollowKey(t)); return Lt(e); }
    getFollowSetFromFollowKey(e) { if (e === Ku)
        return [Mr]; let t = e.ruleName + e.idxInCallingRule + SA + e.inRule; return this.resyncFollows[t]; }
    addToResyncTokens(e, t) { return this.tokenMatcher(e, Mr) || t.push(e), t; }
    reSyncTo(e) { let t = [], r = this.LA(1); for (; this.tokenMatcher(r, e) === !1;)
        r = this.SKIP_TOKEN(), this.addToResyncTokens(r, t); return Ts(t); }
    attemptInRepetitionRecovery(e, t, r, n, a, i, o) { }
    getCurrentGrammarPath(e, t) { let r = this.getHumanReadableRuleStack(), n = Ye(this.RULE_OCCURRENCE_STACK); return { ruleStack: r, occurrenceStack: n, lastTok: e, lastTokOccurrence: t }; }
    getHumanReadableRuleStack() { return F(this.RULE_STACK, e => this.shortRuleNameToFullName(e)); }
};
function UE(e, t, r, n, a, i, o) { let l = this.getKeyForAutomaticLookahead(n, a), u = this.firstAfterRepMap[l]; if (u === void 0) {
    let m = this.getCurrRuleFullName(), g = this.getGAstProductions()[m];
    u = new i(g, a).startWalking(), this.firstAfterRepMap[l] = u;
} let c = u.token, f = u.occurrence, p = u.isEndOfRule; this.RULE_STACK.length === 1 && p && c === void 0 && (c = Mr, f = 1), !(c === void 0 || f === void 0) && this.shouldInRepetitionRecoveryBeTried(c, f, o) && this.tryInRepetitionRecovery(e, t, r, c); }
s(UE, "attemptInRepetitionRecovery");
var sD = 4, Br = 8, oD = 8, BE = 1 << Br, KE = 2 << Br, Pf = 3 << Br, kf = 4 << Br, Of = 5 << Br, Po = 6 << Br;
function ko(e, t, r) { return r | t | e; }
s(ko, "getKeyForAutomaticLookahead");
var QF = 32 - oD, tm = class {
    static { s(this, "LLkLookaheadStrategy"); }
    constructor(e) { var t; this.maxLookahead = (t = e?.maxLookahead) !== null && t !== void 0 ? t : $r.maxLookahead; }
    validate(e) { let t = this.validateNoLeftRecursion(e.rules); if (he(t)) {
        let r = this.validateEmptyOrAlternatives(e.rules), n = this.validateAmbiguousAlternationAlternatives(e.rules, this.maxLookahead), a = this.validateSomeNonEmptyLookaheadPath(e.rules, this.maxLookahead);
        return [...t, ...r, ...n, ...a];
    } return t; }
    validateNoLeftRecursion(e) { return Rt(e, t => Qd(t, t, $n)); }
    validateEmptyOrAlternatives(e) { return Rt(e, t => _E(t, $n)); }
    validateAmbiguousAlternationAlternatives(e, t) { return Rt(e, r => SE(r, t, $n)); }
    validateSomeNonEmptyLookaheadPath(e, t) { return IE(e, t, $n); }
    buildLookaheadForAlternation(e) { return dE(e.prodOccurrence, e.rule, e.maxLookahead, e.hasPredicates, e.dynamicTokensEnabled, hE); }
    buildLookaheadForOptional(e) { return mE(e.prodOccurrence, e.rule, e.maxLookahead, e.dynamicTokensEnabled, pu(e.prodType), yE); }
}, lD = class {
    static { s(this, "LooksAhead"); }
    initLooksAhead(e) { this.dynamicTokensEnabled = K(e, "dynamicTokensEnabled") ? e.dynamicTokensEnabled : $r.dynamicTokensEnabled, this.maxLookahead = K(e, "maxLookahead") ? e.maxLookahead : $r.maxLookahead, this.lookaheadStrategy = K(e, "lookaheadStrategy") ? e.lookaheadStrategy : new tm({ maxLookahead: this.maxLookahead }), this.lookAheadFuncsCache = new Map; }
    preComputeLookaheadFunctions(e) { V(e, t => { this.TRACE_INIT(`${t.name} Rule Lookahead`, () => { let { alternation: r, repetition: n, option: a, repetitionMandatory: i, repetitionMandatoryWithSeparator: o, repetitionWithSeparator: l } = qE(t); V(r, u => { let c = u.idx === 0 ? "" : u.idx; this.TRACE_INIT(`${It(u)}${c}`, () => { let f = this.lookaheadStrategy.buildLookaheadForAlternation({ prodOccurrence: u.idx, rule: t, maxLookahead: u.maxLookahead || this.maxLookahead, hasPredicates: u.hasPredicates, dynamicTokensEnabled: this.dynamicTokensEnabled }), p = ko(this.fullRuleNameToShort[t.name], BE, u.idx); this.setLaFuncCache(p, f); }); }), V(n, u => { this.computeLookaheadFunc(t, u.idx, Pf, "Repetition", u.maxLookahead, It(u)); }), V(a, u => { this.computeLookaheadFunc(t, u.idx, KE, "Option", u.maxLookahead, It(u)); }), V(i, u => { this.computeLookaheadFunc(t, u.idx, kf, "RepetitionMandatory", u.maxLookahead, It(u)); }), V(o, u => { this.computeLookaheadFunc(t, u.idx, Po, "RepetitionMandatoryWithSeparator", u.maxLookahead, It(u)); }), V(l, u => { this.computeLookaheadFunc(t, u.idx, Of, "RepetitionWithSeparator", u.maxLookahead, It(u)); }); }); }); }
    computeLookaheadFunc(e, t, r, n, a, i) { this.TRACE_INIT(`${i}${t === 0 ? "" : t}`, () => { let o = this.lookaheadStrategy.buildLookaheadForOptional({ prodOccurrence: t, rule: e, maxLookahead: a || this.maxLookahead, dynamicTokensEnabled: this.dynamicTokensEnabled, prodType: n }), l = ko(this.fullRuleNameToShort[e.name], r, t); this.setLaFuncCache(l, o); }); }
    getKeyForAutomaticLookahead(e, t) { let r = this.getLastExplicitRuleShortName(); return ko(r, e, t); }
    getLaFuncFromCache(e) { return this.lookAheadFuncsCache.get(e); }
    setLaFuncCache(e, t) { this.lookAheadFuncsCache.set(e, t); }
}, uD = class extends Za {
    static { s(this, "DslMethodsCollectorVisitor"); }
    constructor() { super(...arguments), this.dslMethods = { option: [], alternation: [], repetition: [], repetitionWithSeparator: [], repetitionMandatory: [], repetitionMandatoryWithSeparator: [] }; }
    reset() { this.dslMethods = { option: [], alternation: [], repetition: [], repetitionWithSeparator: [], repetitionMandatory: [], repetitionMandatoryWithSeparator: [] }; }
    visitOption(e) { this.dslMethods.option.push(e); }
    visitRepetitionWithSeparator(e) { this.dslMethods.repetitionWithSeparator.push(e); }
    visitRepetitionMandatory(e) { this.dslMethods.repetitionMandatory.push(e); }
    visitRepetitionMandatoryWithSeparator(e) { this.dslMethods.repetitionMandatoryWithSeparator.push(e); }
    visitRepetition(e) { this.dslMethods.repetition.push(e); }
    visitAlternation(e) { this.dslMethods.alternation.push(e); }
}, to = new uD;
function qE(e) { to.reset(), e.accept(to); let t = to.dslMethods; return to.reset(), t; }
s(qE, "collectMethods");
function Lf(e, t) { isNaN(e.startOffset) === !0 ? (e.startOffset = t.startOffset, e.endOffset = t.endOffset) : e.endOffset < t.endOffset && (e.endOffset = t.endOffset); }
s(Lf, "setNodeLocationOnlyOffset");
function Df(e, t) { isNaN(e.startOffset) === !0 ? (e.startOffset = t.startOffset, e.startColumn = t.startColumn, e.startLine = t.startLine, e.endOffset = t.endOffset, e.endColumn = t.endColumn, e.endLine = t.endLine) : e.endOffset < t.endOffset && (e.endOffset = t.endOffset, e.endColumn = t.endColumn, e.endLine = t.endLine); }
s(Df, "setNodeLocationFull");
function WE(e, t, r) { e.children[r] === void 0 ? e.children[r] = [t] : e.children[r].push(t); }
s(WE, "addTerminalToCst");
function VE(e, t, r) { e.children[t] === void 0 ? e.children[t] = [r] : e.children[t].push(r); }
s(VE, "addNoneTerminalToCst");
var cD = "name";
function rm(e, t) { Object.defineProperty(e, cD, { enumerable: !1, configurable: !0, writable: !1, value: t }); }
s(rm, "defineNameProp");
function HE(e, t) { let r = ht(e), n = r.length; for (let a = 0; a < n; a++) {
    let i = r[a], o = e[i], l = o.length;
    for (let u = 0; u < l; u++) {
        let c = o[u];
        c.tokenTypeIdx === void 0 && this[c.name](c.children, t);
    }
} }
s(HE, "defaultVisit");
function YE(e, t) {
    let r = s(function () { }, "derivedConstructor");
    rm(r, e + "BaseSemantics");
    let n = { visit: s(function (a, i) { if (te(a) && (a = a[0]), !vr(a))
            return this[a.name](a.children, i); }, "visit"), validateVisitor: s(function () {
            let a = ZE(this, t);
            if (!he(a)) {
                let i = F(a, o => o.msg);
                throw Error(`Errors Detected in CST Visitor <${this.constructor.name}>:
	${i.join(`

`).replace(/\n/g, `
	`)}`);
            }
        }, "validateVisitor") };
    return r.prototype = n, r.prototype.constructor = r, r._RULE_NAMES = t, r;
}
s(YE, "createBaseSemanticVisitorConstructor");
function XE(e, t, r) { let n = s(function () { }, "derivedConstructor"); rm(n, e + "BaseSemanticsWithDefaults"); let a = Object.create(r.prototype); return V(t, i => { a[i] = HE; }), n.prototype = a, n.prototype.constructor = n, n; }
s(XE, "createBaseVisitorConstructorWithDefaults");
var JE = (function (e) { return e[e.REDUNDANT_METHOD = 0] = "REDUNDANT_METHOD", e[e.MISSING_METHOD = 1] = "MISSING_METHOD", e; })(JE || {});
function ZE(e, t) { return QE(e, t); }
s(ZE, "validateVisitor");
function QE(e, t) { let r = Ct(t, a => br(e[a]) === !1), n = F(r, a => ({ msg: `Missing visitor method: <${a}> on ${e.constructor.name} CST Visitor.`, type: JE.MISSING_METHOD, methodName: a })); return qs(n); }
s(QE, "validateMissingCstMethods");
var fD = class {
    static { s(this, "TreeBuilder"); }
    initTreeBuilder(e) { if (this.CST_STACK = [], this.outputCst = e.outputCst, this.nodeLocationTracking = K(e, "nodeLocationTracking") ? e.nodeLocationTracking : $r.nodeLocationTracking, !this.outputCst)
        this.cstInvocationStateUpdate = ze, this.cstFinallyStateUpdate = ze, this.cstPostTerminal = ze, this.cstPostNonTerminal = ze, this.cstPostRule = ze;
    else if (/full/i.test(this.nodeLocationTracking))
        this.recoveryEnabled ? (this.setNodeLocationFromToken = Df, this.setNodeLocationFromNode = Df, this.cstPostRule = ze, this.setInitialNodeLocation = this.setInitialNodeLocationFullRecovery) : (this.setNodeLocationFromToken = ze, this.setNodeLocationFromNode = ze, this.cstPostRule = this.cstPostRuleFull, this.setInitialNodeLocation = this.setInitialNodeLocationFullRegular);
    else if (/onlyOffset/i.test(this.nodeLocationTracking))
        this.recoveryEnabled ? (this.setNodeLocationFromToken = Lf, this.setNodeLocationFromNode = Lf, this.cstPostRule = ze, this.setInitialNodeLocation = this.setInitialNodeLocationOnlyOffsetRecovery) : (this.setNodeLocationFromToken = ze, this.setNodeLocationFromNode = ze, this.cstPostRule = this.cstPostRuleOnlyOffset, this.setInitialNodeLocation = this.setInitialNodeLocationOnlyOffsetRegular);
    else if (/none/i.test(this.nodeLocationTracking))
        this.setNodeLocationFromToken = ze, this.setNodeLocationFromNode = ze, this.cstPostRule = ze, this.setInitialNodeLocation = ze;
    else
        throw Error(`Invalid <nodeLocationTracking> config option: "${e.nodeLocationTracking}"`); }
    setInitialNodeLocationOnlyOffsetRecovery(e) { e.location = { startOffset: NaN, endOffset: NaN }; }
    setInitialNodeLocationOnlyOffsetRegular(e) { e.location = { startOffset: this.LA(1).startOffset, endOffset: NaN }; }
    setInitialNodeLocationFullRecovery(e) { e.location = { startOffset: NaN, startLine: NaN, startColumn: NaN, endOffset: NaN, endLine: NaN, endColumn: NaN }; }
    setInitialNodeLocationFullRegular(e) { let t = this.LA(1); e.location = { startOffset: t.startOffset, startLine: t.startLine, startColumn: t.startColumn, endOffset: NaN, endLine: NaN, endColumn: NaN }; }
    cstInvocationStateUpdate(e) { let t = { name: e, children: Object.create(null) }; this.setInitialNodeLocation(t), this.CST_STACK.push(t); }
    cstFinallyStateUpdate() { this.CST_STACK.pop(); }
    cstPostRuleFull(e) { let t = this.LA(0), r = e.location; r.startOffset <= t.startOffset ? (r.endOffset = t.endOffset, r.endLine = t.endLine, r.endColumn = t.endColumn) : (r.startOffset = NaN, r.startLine = NaN, r.startColumn = NaN); }
    cstPostRuleOnlyOffset(e) { let t = this.LA(0), r = e.location; r.startOffset <= t.startOffset ? r.endOffset = t.endOffset : r.startOffset = NaN; }
    cstPostTerminal(e, t) { let r = this.CST_STACK[this.CST_STACK.length - 1]; WE(r, t, e), this.setNodeLocationFromToken(r.location, t); }
    cstPostNonTerminal(e, t) { let r = this.CST_STACK[this.CST_STACK.length - 1]; VE(r, t, e), this.setNodeLocationFromNode(r.location, e.location); }
    getBaseCstVisitorConstructor() { if (vr(this.baseCstVisitorConstructor)) {
        let e = YE(this.className, ht(this.gastProductionsCache));
        return this.baseCstVisitorConstructor = e, e;
    } return this.baseCstVisitorConstructor; }
    getBaseCstVisitorConstructorWithDefaults() { if (vr(this.baseCstVisitorWithDefaultsConstructor)) {
        let e = XE(this.className, ht(this.gastProductionsCache), this.getBaseCstVisitorConstructor());
        return this.baseCstVisitorWithDefaultsConstructor = e, e;
    } return this.baseCstVisitorWithDefaultsConstructor; }
    getLastExplicitRuleShortName() { let e = this.RULE_STACK; return e[e.length - 1]; }
    getPreviousExplicitRuleShortName() { let e = this.RULE_STACK; return e[e.length - 2]; }
    getLastExplicitRuleOccurrenceIndex() { let e = this.RULE_OCCURRENCE_STACK; return e[e.length - 1]; }
}, pD = class {
    static { s(this, "LexerAdapter"); }
    initLexerAdapter() { this.tokVector = [], this.tokVectorLength = 0, this.currIdx = -1; }
    set input(e) { if (this.selfAnalysisDone !== !0)
        throw Error("Missing <performSelfAnalysis> invocation at the end of the Parser's constructor."); this.reset(), this.tokVector = e, this.tokVectorLength = e.length; }
    get input() { return this.tokVector; }
    SKIP_TOKEN() { return this.currIdx <= this.tokVector.length - 2 ? (this.consumeToken(), this.LA(1)) : yl; }
    LA(e) { let t = this.currIdx + e; return t < 0 || this.tokVectorLength <= t ? yl : this.tokVector[t]; }
    consumeToken() { this.currIdx++; }
    exportLexerState() { return this.currIdx; }
    importLexerState(e) { this.currIdx = e; }
    resetLexerState() { this.currIdx = -1; }
    moveToTerminatedState() { this.currIdx = this.tokVector.length - 1; }
    getLexerPosition() { return this.exportLexerState(); }
}, dD = class {
    static { s(this, "RecognizerApi"); }
    ACTION(e) { return e.call(this); }
    consume(e, t, r) { return this.consumeInternal(t, e, r); }
    subrule(e, t, r) { return this.subruleInternal(t, e, r); }
    option(e, t) { return this.optionInternal(t, e); }
    or(e, t) { return this.orInternal(t, e); }
    many(e, t) { return this.manyInternal(e, t); }
    atLeastOne(e, t) { return this.atLeastOneInternal(e, t); }
    CONSUME(e, t) { return this.consumeInternal(e, 0, t); }
    CONSUME1(e, t) { return this.consumeInternal(e, 1, t); }
    CONSUME2(e, t) { return this.consumeInternal(e, 2, t); }
    CONSUME3(e, t) { return this.consumeInternal(e, 3, t); }
    CONSUME4(e, t) { return this.consumeInternal(e, 4, t); }
    CONSUME5(e, t) { return this.consumeInternal(e, 5, t); }
    CONSUME6(e, t) { return this.consumeInternal(e, 6, t); }
    CONSUME7(e, t) { return this.consumeInternal(e, 7, t); }
    CONSUME8(e, t) { return this.consumeInternal(e, 8, t); }
    CONSUME9(e, t) { return this.consumeInternal(e, 9, t); }
    SUBRULE(e, t) { return this.subruleInternal(e, 0, t); }
    SUBRULE1(e, t) { return this.subruleInternal(e, 1, t); }
    SUBRULE2(e, t) { return this.subruleInternal(e, 2, t); }
    SUBRULE3(e, t) { return this.subruleInternal(e, 3, t); }
    SUBRULE4(e, t) { return this.subruleInternal(e, 4, t); }
    SUBRULE5(e, t) { return this.subruleInternal(e, 5, t); }
    SUBRULE6(e, t) { return this.subruleInternal(e, 6, t); }
    SUBRULE7(e, t) { return this.subruleInternal(e, 7, t); }
    SUBRULE8(e, t) { return this.subruleInternal(e, 8, t); }
    SUBRULE9(e, t) { return this.subruleInternal(e, 9, t); }
    OPTION(e) { return this.optionInternal(e, 0); }
    OPTION1(e) { return this.optionInternal(e, 1); }
    OPTION2(e) { return this.optionInternal(e, 2); }
    OPTION3(e) { return this.optionInternal(e, 3); }
    OPTION4(e) { return this.optionInternal(e, 4); }
    OPTION5(e) { return this.optionInternal(e, 5); }
    OPTION6(e) { return this.optionInternal(e, 6); }
    OPTION7(e) { return this.optionInternal(e, 7); }
    OPTION8(e) { return this.optionInternal(e, 8); }
    OPTION9(e) { return this.optionInternal(e, 9); }
    OR(e) { return this.orInternal(e, 0); }
    OR1(e) { return this.orInternal(e, 1); }
    OR2(e) { return this.orInternal(e, 2); }
    OR3(e) { return this.orInternal(e, 3); }
    OR4(e) { return this.orInternal(e, 4); }
    OR5(e) { return this.orInternal(e, 5); }
    OR6(e) { return this.orInternal(e, 6); }
    OR7(e) { return this.orInternal(e, 7); }
    OR8(e) { return this.orInternal(e, 8); }
    OR9(e) { return this.orInternal(e, 9); }
    MANY(e) { this.manyInternal(0, e); }
    MANY1(e) { this.manyInternal(1, e); }
    MANY2(e) { this.manyInternal(2, e); }
    MANY3(e) { this.manyInternal(3, e); }
    MANY4(e) { this.manyInternal(4, e); }
    MANY5(e) { this.manyInternal(5, e); }
    MANY6(e) { this.manyInternal(6, e); }
    MANY7(e) { this.manyInternal(7, e); }
    MANY8(e) { this.manyInternal(8, e); }
    MANY9(e) { this.manyInternal(9, e); }
    MANY_SEP(e) { this.manySepFirstInternal(0, e); }
    MANY_SEP1(e) { this.manySepFirstInternal(1, e); }
    MANY_SEP2(e) { this.manySepFirstInternal(2, e); }
    MANY_SEP3(e) { this.manySepFirstInternal(3, e); }
    MANY_SEP4(e) { this.manySepFirstInternal(4, e); }
    MANY_SEP5(e) { this.manySepFirstInternal(5, e); }
    MANY_SEP6(e) { this.manySepFirstInternal(6, e); }
    MANY_SEP7(e) { this.manySepFirstInternal(7, e); }
    MANY_SEP8(e) { this.manySepFirstInternal(8, e); }
    MANY_SEP9(e) { this.manySepFirstInternal(9, e); }
    AT_LEAST_ONE(e) { this.atLeastOneInternal(0, e); }
    AT_LEAST_ONE1(e) { return this.atLeastOneInternal(1, e); }
    AT_LEAST_ONE2(e) { this.atLeastOneInternal(2, e); }
    AT_LEAST_ONE3(e) { this.atLeastOneInternal(3, e); }
    AT_LEAST_ONE4(e) { this.atLeastOneInternal(4, e); }
    AT_LEAST_ONE5(e) { this.atLeastOneInternal(5, e); }
    AT_LEAST_ONE6(e) { this.atLeastOneInternal(6, e); }
    AT_LEAST_ONE7(e) { this.atLeastOneInternal(7, e); }
    AT_LEAST_ONE8(e) { this.atLeastOneInternal(8, e); }
    AT_LEAST_ONE9(e) { this.atLeastOneInternal(9, e); }
    AT_LEAST_ONE_SEP(e) { this.atLeastOneSepFirstInternal(0, e); }
    AT_LEAST_ONE_SEP1(e) { this.atLeastOneSepFirstInternal(1, e); }
    AT_LEAST_ONE_SEP2(e) { this.atLeastOneSepFirstInternal(2, e); }
    AT_LEAST_ONE_SEP3(e) { this.atLeastOneSepFirstInternal(3, e); }
    AT_LEAST_ONE_SEP4(e) { this.atLeastOneSepFirstInternal(4, e); }
    AT_LEAST_ONE_SEP5(e) { this.atLeastOneSepFirstInternal(5, e); }
    AT_LEAST_ONE_SEP6(e) { this.atLeastOneSepFirstInternal(6, e); }
    AT_LEAST_ONE_SEP7(e) { this.atLeastOneSepFirstInternal(7, e); }
    AT_LEAST_ONE_SEP8(e) { this.atLeastOneSepFirstInternal(8, e); }
    AT_LEAST_ONE_SEP9(e) { this.atLeastOneSepFirstInternal(9, e); }
    RULE(e, t, r = gl) { if (nt(this.definedRulesNames, e)) {
        let i = { message: $n.buildDuplicateRuleNameError({ topLevelRule: e, grammarName: this.className }), type: ct.DUPLICATE_RULE_NAME, ruleName: e };
        this.definitionErrors.push(i);
    } this.definedRulesNames.push(e); let n = this.defineRule(e, t, r); return this[e] = n, n; }
    OVERRIDE_RULE(e, t, r = gl) { let n = CE(e, this.definedRulesNames, this.className); this.definitionErrors = this.definitionErrors.concat(n); let a = this.defineRule(e, t, r); return this[e] = a, a; }
    BACKTRACK(e, t) { return function () { this.isBackTrackingStack.push(1); let r = this.saveRecogState(); try {
        return e.apply(this, t), !0;
    }
    catch (n) {
        if (As(n))
            return !1;
        throw n;
    }
    finally {
        this.reloadRecogState(r), this.isBackTrackingStack.pop();
    } }; }
    getGAstProductions() { return this.gastProductionsCache; }
    getSerializedGastProductions() { return RA(Ge(this.gastProductionsCache)); }
}, mD = class {
    static { s(this, "RecognizerEngine"); }
    initRecognizerEngine(e, t) {
        if (this.className = this.constructor.name, this.shortRuleNameToFull = {}, this.fullRuleNameToShort = {}, this.ruleShortNameIdx = 256, this.tokenMatcher = Rs, this.subruleIdx = 0, this.definedRulesNames = [], this.tokensMap = {}, this.isBackTrackingStack = [], this.RULE_STACK = [], this.RULE_OCCURRENCE_STACK = [], this.gastProductionsCache = {}, K(t, "serializedGrammar"))
            throw Error(`The Parser's configuration can no longer contain a <serializedGrammar> property.
	See: https://chevrotain.io/docs/changes/BREAKING_CHANGES.html#_6-0-0
	For Further details.`);
        if (te(e)) {
            if (he(e))
                throw Error(`A Token Vocabulary cannot be empty.
	Note that the first argument for the parser constructor
	is no longer a Token vector (since v4.0).`);
            if (typeof e[0].startOffset == "number")
                throw Error(`The Parser constructor no longer accepts a token vector as the first argument.
	See: https://chevrotain.io/docs/changes/BREAKING_CHANGES.html#_4-0-0
	For Further details.`);
        }
        if (te(e))
            this.tokensMap = gt(e, (a, i) => (a[i.name] = i, a), {});
        else if (K(e, "modes") && Dt(Lt(Ge(e.modes)), uE)) {
            let a = Lt(Ge(e.modes)), i = Gd(a);
            this.tokensMap = gt(i, (o, l) => (o[l.name] = l, o), {});
        }
        else if (Et(e))
            this.tokensMap = Ye(e);
        else
            throw new Error("<tokensDictionary> argument must be An Array of Token constructors, A dictionary of Token constructors or an IMultiModeLexerDefinition");
        this.tokensMap.EOF = Mr;
        let r = K(e, "modes") ? Lt(Ge(e.modes)) : Ge(e), n = Dt(r, a => he(a.categoryMatches));
        this.tokenMatcher = n ? Rs : ei, ti(Ge(this.tokensMap));
    }
    defineRule(e, t, r) {
        if (this.selfAnalysisDone)
            throw Error(`Grammar rule <${e}> may not be defined after the 'performSelfAnalysis' method has been called'
Make sure that all grammar rule definitions are done before 'performSelfAnalysis' is called.`);
        let n = K(r, "resyncEnabled") ? r.resyncEnabled : gl.resyncEnabled, a = K(r, "recoveryValueFunc") ? r.recoveryValueFunc : gl.recoveryValueFunc, i = this.ruleShortNameIdx << sD + Br;
        this.ruleShortNameIdx++, this.shortRuleNameToFull[i] = e, this.fullRuleNameToShort[e] = i;
        let o;
        return this.outputCst === !0 ? o = s(function (...c) { try {
            this.ruleInvocationStateUpdate(i, e, this.subruleIdx), t.apply(this, c);
            let f = this.CST_STACK[this.CST_STACK.length - 1];
            return this.cstPostRule(f), f;
        }
        catch (f) {
            return this.invokeRuleCatch(f, n, a);
        }
        finally {
            this.ruleFinallyStateUpdate();
        } }, "invokeRuleWithTry") : o = s(function (...c) { try {
            return this.ruleInvocationStateUpdate(i, e, this.subruleIdx), t.apply(this, c);
        }
        catch (f) {
            return this.invokeRuleCatch(f, n, a);
        }
        finally {
            this.ruleFinallyStateUpdate();
        } }, "invokeRuleWithTryCst"), Object.assign(o, { ruleName: e, originalGrammarAction: t });
    }
    invokeRuleCatch(e, t, r) { let n = this.RULE_STACK.length === 1, a = t && !this.isBackTracking() && this.recoveryEnabled; if (As(e)) {
        let i = e;
        if (a) {
            let o = this.findReSyncTokenType();
            if (this.isInCurrentRuleReSyncSet(o))
                if (i.resyncedTokens = this.reSyncTo(o), this.outputCst) {
                    let l = this.CST_STACK[this.CST_STACK.length - 1];
                    return l.recoveredNode = !0, l;
                }
                else
                    return r(e);
            else {
                if (this.outputCst) {
                    let l = this.CST_STACK[this.CST_STACK.length - 1];
                    l.recoveredNode = !0, i.partialCstResult = l;
                }
                throw i;
            }
        }
        else {
            if (n)
                return this.moveToTerminatedState(), r(e);
            throw i;
        }
    }
    else
        throw e; }
    optionInternal(e, t) { let r = this.getKeyForAutomaticLookahead(KE, t); return this.optionInternalLogic(e, t, r); }
    optionInternalLogic(e, t, r) { let n = this.getLaFuncFromCache(r), a; if (typeof e != "function") {
        a = e.DEF;
        let i = e.GATE;
        if (i !== void 0) {
            let o = n;
            n = s(() => i.call(this) && o.call(this), "lookAheadFunc");
        }
    }
    else
        a = e; if (n.call(this) === !0)
        return a.call(this); }
    atLeastOneInternal(e, t) { let r = this.getKeyForAutomaticLookahead(kf, e); return this.atLeastOneInternalLogic(e, t, r); }
    atLeastOneInternalLogic(e, t, r) { let n = this.getLaFuncFromCache(r), a; if (typeof t != "function") {
        a = t.DEF;
        let i = t.GATE;
        if (i !== void 0) {
            let o = n;
            n = s(() => i.call(this) && o.call(this), "lookAheadFunc");
        }
    }
    else
        a = t; if (n.call(this) === !0) {
        let i = this.doSingleRepetition(a);
        for (; n.call(this) === !0 && i === !0;)
            i = this.doSingleRepetition(a);
    }
    else
        throw this.raiseEarlyExitException(e, we.REPETITION_MANDATORY, t.ERR_MSG); this.attemptInRepetitionRecovery(this.atLeastOneInternal, [e, t], n, kf, e, JL); }
    atLeastOneSepFirstInternal(e, t) { let r = this.getKeyForAutomaticLookahead(Po, e); this.atLeastOneSepFirstInternalLogic(e, t, r); }
    atLeastOneSepFirstInternalLogic(e, t, r) { let n = t.DEF, a = t.SEP; if (this.getLaFuncFromCache(r).call(this) === !0) {
        n.call(this);
        let o = s(() => this.tokenMatcher(this.LA(1), a), "separatorLookAheadFunc");
        for (; this.tokenMatcher(this.LA(1), a) === !0;)
            this.CONSUME(a), n.call(this);
        this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [e, a, o, n, Hh], o, Po, e, Hh);
    }
    else
        throw this.raiseEarlyExitException(e, we.REPETITION_MANDATORY_WITH_SEPARATOR, t.ERR_MSG); }
    manyInternal(e, t) { let r = this.getKeyForAutomaticLookahead(Pf, e); return this.manyInternalLogic(e, t, r); }
    manyInternalLogic(e, t, r) { let n = this.getLaFuncFromCache(r), a; if (typeof t != "function") {
        a = t.DEF;
        let o = t.GATE;
        if (o !== void 0) {
            let l = n;
            n = s(() => o.call(this) && l.call(this), "lookaheadFunction");
        }
    }
    else
        a = t; let i = !0; for (; n.call(this) === !0 && i === !0;)
        i = this.doSingleRepetition(a); this.attemptInRepetitionRecovery(this.manyInternal, [e, t], n, Pf, e, XL, i); }
    manySepFirstInternal(e, t) { let r = this.getKeyForAutomaticLookahead(Of, e); this.manySepFirstInternalLogic(e, t, r); }
    manySepFirstInternalLogic(e, t, r) { let n = t.DEF, a = t.SEP; if (this.getLaFuncFromCache(r).call(this) === !0) {
        n.call(this);
        let o = s(() => this.tokenMatcher(this.LA(1), a), "separatorLookAheadFunc");
        for (; this.tokenMatcher(this.LA(1), a) === !0;)
            this.CONSUME(a), n.call(this);
        this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [e, a, o, n, Vh], o, Of, e, Vh);
    } }
    repetitionSepSecondInternal(e, t, r, n, a) { for (; r();)
        this.CONSUME(t), n.call(this); this.attemptInRepetitionRecovery(this.repetitionSepSecondInternal, [e, t, r, n, a], r, Po, e, a); }
    doSingleRepetition(e) { let t = this.getLexerPosition(); return e.call(this), this.getLexerPosition() > t; }
    orInternal(e, t) { let r = this.getKeyForAutomaticLookahead(BE, t), n = te(e) ? e : e.DEF, i = this.getLaFuncFromCache(r).call(this, n); if (i !== void 0)
        return n[i].ALT.call(this); this.raiseNoAltException(t, e.ERR_MSG); }
    ruleFinallyStateUpdate() { if (this.RULE_STACK.pop(), this.RULE_OCCURRENCE_STACK.pop(), this.cstFinallyStateUpdate(), this.RULE_STACK.length === 0 && this.isAtEndOfInput() === !1) {
        let e = this.LA(1), t = this.errorMessageProvider.buildNotAllInputParsedMessage({ firstRedundant: e, ruleName: this.getCurrRuleFullName() });
        this.SAVE_ERROR(new rD(t, e));
    } }
    subruleInternal(e, t, r) { let n; try {
        let a = r !== void 0 ? r.ARGS : void 0;
        return this.subruleIdx = t, n = e.apply(this, a), this.cstPostNonTerminal(n, r !== void 0 && r.LABEL !== void 0 ? r.LABEL : e.ruleName), n;
    }
    catch (a) {
        throw this.subruleInternalError(a, r, e.ruleName);
    } }
    subruleInternalError(e, t, r) { throw As(e) && e.partialCstResult !== void 0 && (this.cstPostNonTerminal(e.partialCstResult, t !== void 0 && t.LABEL !== void 0 ? t.LABEL : r), delete e.partialCstResult), e; }
    consumeInternal(e, t, r) { let n; try {
        let a = this.LA(1);
        this.tokenMatcher(a, e) === !0 ? (this.consumeToken(), n = a) : this.consumeInternalError(e, a, r);
    }
    catch (a) {
        n = this.consumeInternalRecovery(e, t, a);
    } return this.cstPostTerminal(r !== void 0 && r.LABEL !== void 0 ? r.LABEL : e.name, n), n; }
    consumeInternalError(e, t, r) { let n, a = this.LA(0); throw r !== void 0 && r.ERR_MSG ? n = r.ERR_MSG : n = this.errorMessageProvider.buildMismatchTokenMessage({ expected: e, actual: t, previous: a, ruleName: this.getCurrRuleFullName() }), this.SAVE_ERROR(new zE(n, t, a)); }
    consumeInternalRecovery(e, t, r) { if (this.recoveryEnabled && r.name === "MismatchedTokenException" && !this.isBackTracking()) {
        let n = this.getFollowsForInRuleRecovery(e, t);
        try {
            return this.tryInRuleRecovery(e, n);
        }
        catch (a) {
            throw a.name === jE ? r : a;
        }
    }
    else
        throw r; }
    saveRecogState() { let e = this.errors, t = Ye(this.RULE_STACK); return { errors: e, lexerState: this.exportLexerState(), RULE_STACK: t, CST_STACK: this.CST_STACK }; }
    reloadRecogState(e) { this.errors = e.errors, this.importLexerState(e.lexerState), this.RULE_STACK = e.RULE_STACK; }
    ruleInvocationStateUpdate(e, t, r) { this.RULE_OCCURRENCE_STACK.push(r), this.RULE_STACK.push(e), this.cstInvocationStateUpdate(t); }
    isBackTracking() { return this.isBackTrackingStack.length !== 0; }
    getCurrRuleFullName() { let e = this.getLastExplicitRuleShortName(); return this.shortRuleNameToFull[e]; }
    shortRuleNameToFullName(e) { return this.shortRuleNameToFull[e]; }
    isAtEndOfInput() { return this.tokenMatcher(this.LA(1), Mr); }
    reset() { this.resetLexerState(), this.subruleIdx = 0, this.isBackTrackingStack = [], this.errors = [], this.RULE_STACK = [], this.CST_STACK = [], this.RULE_OCCURRENCE_STACK = []; }
}, hD = class {
    static { s(this, "ErrorHandler"); }
    initErrorHandler(e) { this._errors = [], this.errorMessageProvider = K(e, "errorMessageProvider") ? e.errorMessageProvider : $r.errorMessageProvider; }
    SAVE_ERROR(e) { if (As(e))
        return e.context = { ruleStack: this.getHumanReadableRuleStack(), ruleOccurrenceStack: Ye(this.RULE_OCCURRENCE_STACK) }, this._errors.push(e), e; throw Error("Trying to save an Error which is not a RecognitionException"); }
    get errors() { return Ye(this._errors); }
    set errors(e) { this._errors = e; }
    raiseEarlyExitException(e, t, r) { let n = this.getCurrRuleFullName(), a = this.getGAstProductions()[n], o = Ys(e, a, t, this.maxLookahead)[0], l = []; for (let c = 1; c <= this.maxLookahead; c++)
        l.push(this.LA(c)); let u = this.errorMessageProvider.buildEarlyExitMessage({ expectedIterationPaths: o, actual: l, previous: this.LA(0), customUserDescription: r, ruleName: n }); throw this.SAVE_ERROR(new nD(u, this.LA(1), this.LA(0))); }
    raiseNoAltException(e, t) { let r = this.getCurrRuleFullName(), n = this.getGAstProductions()[r], a = Hs(e, n, this.maxLookahead), i = []; for (let u = 1; u <= this.maxLookahead; u++)
        i.push(this.LA(u)); let o = this.LA(0), l = this.errorMessageProvider.buildNoViableAltMessage({ expectedPathsPerAlt: a, actual: i, previous: o, customUserDescription: t, ruleName: this.getCurrRuleFullName() }); throw this.SAVE_ERROR(new tD(l, this.LA(1), o)); }
}, yD = class {
    static { s(this, "ContentAssist"); }
    initContentAssist() { }
    computeContentAssist(e, t) { let r = this.gastProductionsCache[e]; if (vr(r))
        throw Error(`Rule ->${e}<- does not exist in this grammar.`); return Yd([r], t, this.tokenMatcher, this.maxLookahead); }
    getNextPossibleTokenTypes(e) { let t = Mt(e.ruleStack), n = this.getGAstProductions()[t]; return new YL(n, e).startWalking(); }
}, mu = { description: "This Object indicates the Parser is during Recording Phase" };
Object.freeze(mu);
var Yh = !0, Xh = Math.pow(2, Br) - 1, eb = Da({ name: "RECORDING_PHASE_TOKEN", pattern: dt.NA });
ti([eb]);
var tb = Vs(eb, `This IToken indicates the Parser is in Recording Phase
	See: https://chevrotain.io/docs/guide/internals.html#grammar-recording for details`, -1, -1, -1, -1, -1, -1);
Object.freeze(tb);
var gD = { name: `This CSTNode indicates the Parser is in Recording Phase
	See: https://chevrotain.io/docs/guide/internals.html#grammar-recording for details`, children: {} }, vD = class {
    static { s(this, "GastRecorder"); }
    initGastRecorder(e) { this.recordingProdStack = [], this.RECORDING_PHASE = !1; }
    enableRecording() { this.RECORDING_PHASE = !0, this.TRACE_INIT("Enable Recording", () => { for (let e = 0; e < 10; e++) {
        let t = e > 0 ? e : "";
        this[`CONSUME${t}`] = function (r, n) { return this.consumeInternalRecord(r, e, n); }, this[`SUBRULE${t}`] = function (r, n) { return this.subruleInternalRecord(r, e, n); }, this[`OPTION${t}`] = function (r) { return this.optionInternalRecord(r, e); }, this[`OR${t}`] = function (r) { return this.orInternalRecord(r, e); }, this[`MANY${t}`] = function (r) { this.manyInternalRecord(e, r); }, this[`MANY_SEP${t}`] = function (r) { this.manySepFirstInternalRecord(e, r); }, this[`AT_LEAST_ONE${t}`] = function (r) { this.atLeastOneInternalRecord(e, r); }, this[`AT_LEAST_ONE_SEP${t}`] = function (r) { this.atLeastOneSepFirstInternalRecord(e, r); };
    } this.consume = function (e, t, r) { return this.consumeInternalRecord(t, e, r); }, this.subrule = function (e, t, r) { return this.subruleInternalRecord(t, e, r); }, this.option = function (e, t) { return this.optionInternalRecord(t, e); }, this.or = function (e, t) { return this.orInternalRecord(t, e); }, this.many = function (e, t) { this.manyInternalRecord(e, t); }, this.atLeastOne = function (e, t) { this.atLeastOneInternalRecord(e, t); }, this.ACTION = this.ACTION_RECORD, this.BACKTRACK = this.BACKTRACK_RECORD, this.LA = this.LA_RECORD; }); }
    disableRecording() { this.RECORDING_PHASE = !1, this.TRACE_INIT("Deleting Recording methods", () => { let e = this; for (let t = 0; t < 10; t++) {
        let r = t > 0 ? t : "";
        delete e[`CONSUME${r}`], delete e[`SUBRULE${r}`], delete e[`OPTION${r}`], delete e[`OR${r}`], delete e[`MANY${r}`], delete e[`MANY_SEP${r}`], delete e[`AT_LEAST_ONE${r}`], delete e[`AT_LEAST_ONE_SEP${r}`];
    } delete e.consume, delete e.subrule, delete e.option, delete e.or, delete e.many, delete e.atLeastOne, delete e.ACTION, delete e.BACKTRACK, delete e.LA; }); }
    ACTION_RECORD(e) { }
    BACKTRACK_RECORD(e, t) { return () => !0; }
    LA_RECORD(e) { return yl; }
    topLevelRuleRecord(e, t) {
        try {
            let r = new Ja({ definition: [], name: e });
            return r.name = e, this.recordingProdStack.push(r), t.call(this), this.recordingProdStack.pop(), r;
        }
        catch (r) {
            if (r.KNOWN_RECORDER_ERROR !== !0)
                try {
                    r.message = r.message + `
	 This error was thrown during the "grammar recording phase" For more info see:
	https://chevrotain.io/docs/guide/internals.html#grammar-recording`;
                }
                catch {
                    throw r;
                }
            throw r;
        }
    }
    optionInternalRecord(e, t) { return ma.call(this, He, e, t); }
    atLeastOneInternalRecord(e, t) { ma.call(this, vt, t, e); }
    atLeastOneSepFirstInternalRecord(e, t) { ma.call(this, Tt, t, e, Yh); }
    manyInternalRecord(e, t) { ma.call(this, Ie, t, e); }
    manySepFirstInternalRecord(e, t) { ma.call(this, lt, t, e, Yh); }
    orInternalRecord(e, t) { return rb.call(this, e, t); }
    subruleInternalRecord(e, t, r) {
        if (Es(t), !e || K(e, "ruleName") === !1) {
            let o = new Error(`<SUBRULE${xf(t)}> argument is invalid expecting a Parser method reference but got: <${JSON.stringify(e)}>
 inside top level rule: <${this.recordingProdStack[0].name}>`);
            throw o.KNOWN_RECORDER_ERROR = !0, o;
        }
        let n = Cn(this.recordingProdStack), a = e.ruleName, i = new tt({ idx: t, nonTerminalName: a, label: r?.LABEL, referencedRule: void 0 });
        return n.definition.push(i), this.outputCst ? gD : mu;
    }
    consumeInternalRecord(e, t, r) {
        if (Es(t), !Wd(e)) {
            let i = new Error(`<CONSUME${xf(t)}> argument is invalid expecting a TokenType reference but got: <${JSON.stringify(e)}>
 inside top level rule: <${this.recordingProdStack[0].name}>`);
            throw i.KNOWN_RECORDER_ERROR = !0, i;
        }
        let n = Cn(this.recordingProdStack), a = new $e({ idx: t, terminalType: e, label: r?.LABEL });
        return n.definition.push(a), tb;
    }
};
function ma(e, t, r, n = !1) { Es(r); let a = Cn(this.recordingProdStack), i = br(t) ? t : t.DEF, o = new e({ definition: [], idx: r }); return n && (o.separator = t.SEP), K(t, "MAX_LOOKAHEAD") && (o.maxLookahead = t.MAX_LOOKAHEAD), this.recordingProdStack.push(o), i.call(this), a.definition.push(o), this.recordingProdStack.pop(), mu; }
s(ma, "recordProd");
function rb(e, t) { Es(t); let r = Cn(this.recordingProdStack), n = te(e) === !1, a = n === !1 ? e : e.DEF, i = new ut({ definition: [], idx: t, ignoreAmbiguities: n && e.IGNORE_AMBIGUITIES === !0 }); K(e, "MAX_LOOKAHEAD") && (i.maxLookahead = e.MAX_LOOKAHEAD); let o = yA(a, l => br(l.GATE)); return i.hasPredicates = o, r.definition.push(i), V(a, l => { let u = new ot({ definition: [] }); i.definition.push(u), K(l, "IGNORE_AMBIGUITIES") ? u.ignoreAmbiguities = l.IGNORE_AMBIGUITIES : K(l, "GATE") && (u.ignoreAmbiguities = !0), this.recordingProdStack.push(u), l.ALT.call(this), this.recordingProdStack.pop(); }), mu; }
s(rb, "recordOrProd");
function xf(e) { return e === 0 ? "" : `${e}`; }
s(xf, "getIdxSuffix");
function Es(e) {
    if (e < 0 || e > Xh) {
        let t = new Error(`Invalid DSL Method idx value: <${e}>
	Idx value must be a none negative value smaller than ${Xh + 1}`);
        throw t.KNOWN_RECORDER_ERROR = !0, t;
    }
}
s(Es, "assertMethodIdxIsValid");
var TD = class {
    static { s(this, "PerformanceTracer"); }
    initPerformanceTracer(e) { if (K(e, "traceInitPerf")) {
        let t = e.traceInitPerf, r = typeof t == "number";
        this.traceInitMaxIdent = r ? t : 1 / 0, this.traceInitPerf = r ? t > 0 : t;
    }
    else
        this.traceInitMaxIdent = 0, this.traceInitPerf = $r.traceInitPerf; this.traceInitIndent = -1; }
    TRACE_INIT(e, t) { if (this.traceInitPerf === !0) {
        this.traceInitIndent++;
        let r = new Array(this.traceInitIndent + 1).join("	");
        this.traceInitIndent < this.traceInitMaxIdent && console.log(`${r}--> <${e}>`);
        let { time: n, value: a } = zd(t), i = n > 10 ? console.warn : console.log;
        return this.traceInitIndent < this.traceInitMaxIdent && i(`${r}<-- <${e}> time: ${n}ms`), this.traceInitIndent--, a;
    }
    else
        return t(); }
};
function nb(e, t) { t.forEach(r => { let n = r.prototype; Object.getOwnPropertyNames(n).forEach(a => { if (a === "constructor")
    return; let i = Object.getOwnPropertyDescriptor(n, a); i && (i.get || i.set) ? Object.defineProperty(e.prototype, a, i) : e.prototype[a] = r.prototype[a]; }); }); }
s(nb, "applyMixins");
var yl = Vs(Mr, "", NaN, NaN, NaN, NaN, NaN, NaN);
Object.freeze(yl);
var $r = Object.freeze({ recoveryEnabled: !1, maxLookahead: 3, dynamicTokensEnabled: !1, outputCst: !0, errorMessageProvider: Pa, nodeLocationTracking: "none", traceInitPerf: !1, skipValidations: !1 }), gl = Object.freeze({ recoveryValueFunc: s(() => { }, "recoveryValueFunc"), resyncEnabled: !0 }), ct = (function (e) { return e[e.INVALID_RULE_NAME = 0] = "INVALID_RULE_NAME", e[e.DUPLICATE_RULE_NAME = 1] = "DUPLICATE_RULE_NAME", e[e.INVALID_RULE_OVERRIDE = 2] = "INVALID_RULE_OVERRIDE", e[e.DUPLICATE_PRODUCTIONS = 3] = "DUPLICATE_PRODUCTIONS", e[e.UNRESOLVED_SUBRULE_REF = 4] = "UNRESOLVED_SUBRULE_REF", e[e.LEFT_RECURSION = 5] = "LEFT_RECURSION", e[e.NONE_LAST_EMPTY_ALT = 6] = "NONE_LAST_EMPTY_ALT", e[e.AMBIGUOUS_ALTS = 7] = "AMBIGUOUS_ALTS", e[e.CONFLICT_TOKENS_RULES_NAMESPACE = 8] = "CONFLICT_TOKENS_RULES_NAMESPACE", e[e.INVALID_TOKEN_NAME = 9] = "INVALID_TOKEN_NAME", e[e.NO_NON_EMPTY_LOOKAHEAD = 10] = "NO_NON_EMPTY_LOOKAHEAD", e[e.AMBIGUOUS_PREFIX_ALTS = 11] = "AMBIGUOUS_PREFIX_ALTS", e[e.TOO_MANY_ALTS = 12] = "TOO_MANY_ALTS", e[e.CUSTOM_LOOKAHEAD_VALIDATION = 13] = "CUSTOM_LOOKAHEAD_VALIDATION", e; })(ct || {});
function Mf(e = void 0) { return function () { return e; }; }
s(Mf, "EMPTY_ALT");
var ab = (() => {
    let e = class ib {
        static { s(this, "Parser"); }
        static performSelfAnalysis(r) { throw Error("The **static** `performSelfAnalysis` method has been deprecated.	\nUse the **instance** method with the same name instead."); }
        performSelfAnalysis() {
            this.TRACE_INIT("performSelfAnalysis", () => {
                let r;
                this.selfAnalysisDone = !0;
                let n = this.className;
                this.TRACE_INIT("toFastProps", () => { jd(this); }), this.TRACE_INIT("Grammar Recording", () => { try {
                    this.enableRecording(), V(this.definedRulesNames, i => { let l = this[i].originalGrammarAction, u; this.TRACE_INIT(`${i} Rule`, () => { u = this.topLevelRuleRecord(i, l); }), this.gastProductionsCache[i] = u; });
                }
                finally {
                    this.disableRecording();
                } });
                let a = [];
                if (this.TRACE_INIT("Grammar Resolving", () => { a = OE({ rules: Ge(this.gastProductionsCache) }), this.definitionErrors = this.definitionErrors.concat(a); }), this.TRACE_INIT("Grammar Validations", () => { if (he(a) && this.skipValidations === !1) {
                    let i = LE({ rules: Ge(this.gastProductionsCache), tokenTypes: Ge(this.tokensMap), errMsgProvider: $n, grammarName: n }), o = $E({ lookaheadStrategy: this.lookaheadStrategy, rules: Ge(this.gastProductionsCache), tokenTypes: Ge(this.tokensMap), grammarName: n });
                    this.definitionErrors = this.definitionErrors.concat(i, o);
                } }), he(this.definitionErrors) && (this.recoveryEnabled && this.TRACE_INIT("computeAllProdsFollows", () => { let i = wA(Ge(this.gastProductionsCache)); this.resyncFollows = i; }), this.TRACE_INIT("ComputeLookaheadFunctions", () => { var i, o; (o = (i = this.lookaheadStrategy).initialize) === null || o === void 0 || o.call(i, { rules: Ge(this.gastProductionsCache) }), this.preComputeLookaheadFunctions(Ge(this.gastProductionsCache)); })), !ib.DEFER_DEFINITION_ERRORS_HANDLING && !he(this.definitionErrors))
                    throw r = F(this.definitionErrors, i => i.message), new Error(`Parser Definition Errors detected:
 ${r.join(`
-------------------------------
`)}`);
            });
        }
        constructor(r, n) {
            this.definitionErrors = [], this.selfAnalysisDone = !1;
            let a = this;
            if (a.initErrorHandler(n), a.initLexerAdapter(), a.initLooksAhead(n), a.initRecognizerEngine(r, n), a.initRecoverable(n), a.initTreeBuilder(n), a.initContentAssist(), a.initGastRecorder(n), a.initPerformanceTracer(n), K(n, "ignoredIssues"))
                throw new Error(`The <ignoredIssues> IParserConfig property has been deprecated.
	Please use the <IGNORE_AMBIGUITIES> flag on the relevant DSL method instead.
	See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#IGNORING_AMBIGUITIES
	For further details.`);
            this.skipValidations = K(n, "skipValidations") ? n.skipValidations : $r.skipValidations;
        }
    };
    return e.DEFER_DEFINITION_ERRORS_HANDLING = !1, e;
})();
nb(ab, [iD, lD, fD, pD, mD, dD, hD, yD, vD, TD]);
var $D = class extends ab {
    static { s(this, "EmbeddedActionsParser"); }
    constructor(e, t = $r) { let r = Ye(t); r.outputCst = !1, super(e, r); }
};
function sb(e, t) { for (var r = -1, n = e == null ? 0 : e.length, a = Array(n); ++r < n;)
    a[r] = t(e[r], r, e); return a; }
s(sb, "arrayMap");
var ob = sb;
function lb() { this.__data__ = [], this.size = 0; }
s(lb, "listCacheClear");
var RD = lb;
function ub(e, t) { return e === t || e !== e && t !== t; }
s(ub, "eq");
var cb = ub;
function fb(e, t) { for (var r = e.length; r--;)
    if (cb(e[r][0], t))
        return r; return -1; }
s(fb, "assocIndexOf");
var hu = fb, AD = Array.prototype, ED = AD.splice;
function pb(e) { var t = this.__data__, r = hu(t, e); if (r < 0)
    return !1; var n = t.length - 1; return r == n ? t.pop() : ED.call(t, r, 1), --this.size, !0; }
s(pb, "listCacheDelete");
var bD = pb;
function db(e) { var t = this.__data__, r = hu(t, e); return r < 0 ? void 0 : t[r][1]; }
s(db, "listCacheGet");
var CD = db;
function mb(e) { return hu(this.__data__, e) > -1; }
s(mb, "listCacheHas");
var _D = mb;
function hb(e, t) { var r = this.__data__, n = hu(r, e); return n < 0 ? (++this.size, r.push([e, t])) : r[n][1] = t, this; }
s(hb, "listCacheSet");
var SD = hb;
function Un(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(Un, "ListCache");
Un.prototype.clear = RD;
Un.prototype.delete = bD;
Un.prototype.get = CD;
Un.prototype.has = _D;
Un.prototype.set = SD;
var yu = Un;
function yb() { this.__data__ = new yu, this.size = 0; }
s(yb, "stackClear");
var wD = yb;
function gb(e) { var t = this.__data__, r = t.delete(e); return this.size = t.size, r; }
s(gb, "stackDelete");
var ID = gb;
function vb(e) { return this.__data__.get(e); }
s(vb, "stackGet");
var ND = vb;
function Tb(e) { return this.__data__.has(e); }
s(Tb, "stackHas");
var PD = Tb, kD = typeof global == "object" && global && global.Object === Object && global, $b = kD, OD = typeof self == "object" && self && self.Object === Object && self, LD = $b || OD || Function("return this")(), Cr = LD, DD = Cr.Symbol, Jt = DD, Rb = Object.prototype, xD = Rb.hasOwnProperty, MD = Rb.toString, Si = Jt ? Jt.toStringTag : void 0;
function Ab(e) { var t = xD.call(e, Si), r = e[Si]; try {
    e[Si] = void 0;
    var n = !0;
}
catch { } var a = MD.call(e); return n && (t ? e[Si] = r : delete e[Si]), a; }
s(Ab, "getRawTag");
var GD = Ab, FD = Object.prototype, zD = FD.toString;
function Eb(e) { return zD.call(e); }
s(Eb, "objectToString");
var jD = Eb, UD = "[object Null]", BD = "[object Undefined]", Jh = Jt ? Jt.toStringTag : void 0;
function bb(e) { return e == null ? e === void 0 ? BD : UD : Jh && Jh in Object(e) ? GD(e) : jD(e); }
s(bb, "baseGetTag");
var ri = bb;
function Cb(e) { var t = typeof e; return e != null && (t == "object" || t == "function"); }
s(Cb, "isObject");
var nm = Cb, KD = "[object AsyncFunction]", qD = "[object Function]", WD = "[object GeneratorFunction]", VD = "[object Proxy]";
function _b(e) { if (!nm(e))
    return !1; var t = ri(e); return t == qD || t == WD || t == KD || t == VD; }
s(_b, "isFunction");
var Sb = _b, HD = Cr["__core-js_shared__"], qu = HD, Zh = (function () { var e = /[^.]+$/.exec(qu && qu.keys && qu.keys.IE_PROTO || ""); return e ? "Symbol(src)_1." + e : ""; })();
function wb(e) { return !!Zh && Zh in e; }
s(wb, "isMasked");
var YD = wb, XD = Function.prototype, JD = XD.toString;
function Ib(e) { if (e != null) {
    try {
        return JD.call(e);
    }
    catch { }
    try {
        return e + "";
    }
    catch { }
} return ""; }
s(Ib, "toSource");
var Bn = Ib, ZD = /[\\^$.*+?()[\]{}|]/g, QD = /^\[object .+?Constructor\]$/, ex = Function.prototype, tx = Object.prototype, rx = ex.toString, nx = tx.hasOwnProperty, ax = RegExp("^" + rx.call(nx).replace(ZD, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
function Nb(e) { if (!nm(e) || YD(e))
    return !1; var t = Sb(e) ? ax : QD; return t.test(Bn(e)); }
s(Nb, "baseIsNative");
var ix = Nb;
function Pb(e, t) { return e?.[t]; }
s(Pb, "getValue");
var sx = Pb;
function kb(e, t) { var r = sx(e, t); return ix(r) ? r : void 0; }
s(kb, "getNative");
var ni = kb, ox = ni(Cr, "Map"), bs = ox, lx = ni(Object, "create"), Cs = lx;
function Ob() { this.__data__ = Cs ? Cs(null) : {}, this.size = 0; }
s(Ob, "hashClear");
var ux = Ob;
function Lb(e) { var t = this.has(e) && delete this.__data__[e]; return this.size -= t ? 1 : 0, t; }
s(Lb, "hashDelete");
var cx = Lb, fx = "__lodash_hash_undefined__", px = Object.prototype, dx = px.hasOwnProperty;
function Db(e) { var t = this.__data__; if (Cs) {
    var r = t[e];
    return r === fx ? void 0 : r;
} return dx.call(t, e) ? t[e] : void 0; }
s(Db, "hashGet");
var mx = Db, hx = Object.prototype, yx = hx.hasOwnProperty;
function xb(e) { var t = this.__data__; return Cs ? t[e] !== void 0 : yx.call(t, e); }
s(xb, "hashHas");
var gx = xb, vx = "__lodash_hash_undefined__";
function Mb(e, t) { var r = this.__data__; return this.size += this.has(e) ? 0 : 1, r[e] = Cs && t === void 0 ? vx : t, this; }
s(Mb, "hashSet");
var Tx = Mb;
function Kn(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(Kn, "Hash");
Kn.prototype.clear = ux;
Kn.prototype.delete = cx;
Kn.prototype.get = mx;
Kn.prototype.has = gx;
Kn.prototype.set = Tx;
var Qh = Kn;
function Gb() { this.size = 0, this.__data__ = { hash: new Qh, map: new (bs || yu), string: new Qh }; }
s(Gb, "mapCacheClear");
var $x = Gb;
function Fb(e) { var t = typeof e; return t == "string" || t == "number" || t == "symbol" || t == "boolean" ? e !== "__proto__" : e === null; }
s(Fb, "isKeyable");
var Rx = Fb;
function zb(e, t) { var r = e.__data__; return Rx(t) ? r[typeof t == "string" ? "string" : "hash"] : r.map; }
s(zb, "getMapData");
var gu = zb;
function jb(e) { var t = gu(this, e).delete(e); return this.size -= t ? 1 : 0, t; }
s(jb, "mapCacheDelete");
var Ax = jb;
function Ub(e) { return gu(this, e).get(e); }
s(Ub, "mapCacheGet");
var Ex = Ub;
function Bb(e) { return gu(this, e).has(e); }
s(Bb, "mapCacheHas");
var bx = Bb;
function Kb(e, t) { var r = gu(this, e), n = r.size; return r.set(e, t), this.size += r.size == n ? 0 : 1, this; }
s(Kb, "mapCacheSet");
var Cx = Kb;
function qn(e) { var t = -1, r = e == null ? 0 : e.length; for (this.clear(); ++t < r;) {
    var n = e[t];
    this.set(n[0], n[1]);
} }
s(qn, "MapCache");
qn.prototype.clear = $x;
qn.prototype.delete = Ax;
qn.prototype.get = Ex;
qn.prototype.has = bx;
qn.prototype.set = Cx;
var vu = qn, _x = 200;
function qb(e, t) { var r = this.__data__; if (r instanceof yu) {
    var n = r.__data__;
    if (!bs || n.length < _x - 1)
        return n.push([e, t]), this.size = ++r.size, this;
    r = this.__data__ = new vu(n);
} return r.set(e, t), this.size = r.size, this; }
s(qb, "stackSet");
var Sx = qb;
function Wn(e) { var t = this.__data__ = new yu(e); this.size = t.size; }
s(Wn, "Stack");
Wn.prototype.clear = wD;
Wn.prototype.delete = ID;
Wn.prototype.get = ND;
Wn.prototype.has = PD;
Wn.prototype.set = Sx;
var Oo = Wn, wx = "__lodash_hash_undefined__";
function Wb(e) { return this.__data__.set(e, wx), this; }
s(Wb, "setCacheAdd");
var Ix = Wb;
function Vb(e) { return this.__data__.has(e); }
s(Vb, "setCacheHas");
var Nx = Vb;
function _s(e) { var t = -1, r = e == null ? 0 : e.length; for (this.__data__ = new vu; ++t < r;)
    this.add(e[t]); }
s(_s, "SetCache");
_s.prototype.add = _s.prototype.push = Ix;
_s.prototype.has = Nx;
var Hb = _s;
function Yb(e, t) { for (var r = -1, n = e == null ? 0 : e.length; ++r < n;)
    if (t(e[r], r, e))
        return !0; return !1; }
s(Yb, "arraySome");
var Px = Yb;
function Xb(e, t) { return e.has(t); }
s(Xb, "cacheHas");
var Jb = Xb, kx = 1, Ox = 2;
function Zb(e, t, r, n, a, i) { var o = r & kx, l = e.length, u = t.length; if (l != u && !(o && u > l))
    return !1; var c = i.get(e), f = i.get(t); if (c && f)
    return c == t && f == e; var p = -1, m = !0, g = r & Ox ? new Hb : void 0; for (i.set(e, t), i.set(t, e); ++p < l;) {
    var v = e[p], _ = t[p];
    if (n)
        var N = o ? n(_, v, p, t, e, i) : n(v, _, p, e, t, i);
    if (N !== void 0) {
        if (N)
            continue;
        m = !1;
        break;
    }
    if (g) {
        if (!Px(t, function (w, S) { if (!Jb(g, S) && (v === w || a(v, w, r, n, i)))
            return g.push(S); })) {
            m = !1;
            break;
        }
    }
    else if (!(v === _ || a(v, _, r, n, i))) {
        m = !1;
        break;
    }
} return i.delete(e), i.delete(t), m; }
s(Zb, "equalArrays");
var Qb = Zb, Lx = Cr.Uint8Array, ey = Lx;
function eC(e) { var t = -1, r = Array(e.size); return e.forEach(function (n, a) { r[++t] = [a, n]; }), r; }
s(eC, "mapToArray");
var Dx = eC;
function tC(e) { var t = -1, r = Array(e.size); return e.forEach(function (n) { r[++t] = n; }), r; }
s(tC, "setToArray");
var am = tC, xx = 1, Mx = 2, Gx = "[object Boolean]", Fx = "[object Date]", zx = "[object Error]", jx = "[object Map]", Ux = "[object Number]", Bx = "[object RegExp]", Kx = "[object Set]", qx = "[object String]", Wx = "[object Symbol]", Vx = "[object ArrayBuffer]", Hx = "[object DataView]", ty = Jt ? Jt.prototype : void 0, Wu = ty ? ty.valueOf : void 0;
function rC(e, t, r, n, a, i, o) { switch (r) {
    case Hx:
        if (e.byteLength != t.byteLength || e.byteOffset != t.byteOffset)
            return !1;
        e = e.buffer, t = t.buffer;
    case Vx: return !(e.byteLength != t.byteLength || !i(new ey(e), new ey(t)));
    case Gx:
    case Fx:
    case Ux: return cb(+e, +t);
    case zx: return e.name == t.name && e.message == t.message;
    case Bx:
    case qx: return e == t + "";
    case jx: var l = Dx;
    case Kx:
        var u = n & xx;
        if (l || (l = am), e.size != t.size && !u)
            return !1;
        var c = o.get(e);
        if (c)
            return c == t;
        n |= Mx, o.set(e, t);
        var f = Qb(l(e), l(t), n, a, i, o);
        return o.delete(e), f;
    case Wx: if (Wu)
        return Wu.call(e) == Wu.call(t);
} return !1; }
s(rC, "equalByTag");
var Yx = rC;
function nC(e, t) { for (var r = -1, n = t.length, a = e.length; ++r < n;)
    e[a + r] = t[r]; return e; }
s(nC, "arrayPush");
var aC = nC, Xx = Array.isArray, rt = Xx;
function iC(e, t, r) { var n = t(e); return rt(e) ? n : aC(n, r(e)); }
s(iC, "baseGetAllKeys");
var Jx = iC;
function sC(e, t) { for (var r = -1, n = e == null ? 0 : e.length, a = 0, i = []; ++r < n;) {
    var o = e[r];
    t(o, r, e) && (i[a++] = o);
} return i; }
s(sC, "arrayFilter");
var oC = sC;
function lC() { return []; }
s(lC, "stubArray");
var Zx = lC, Qx = Object.prototype, eM = Qx.propertyIsEnumerable, ry = Object.getOwnPropertySymbols, tM = ry ? function (e) { return e == null ? [] : (e = Object(e), oC(ry(e), function (t) { return eM.call(e, t); })); } : Zx, rM = tM;
function uC(e, t) { for (var r = -1, n = Array(e); ++r < e;)
    n[r] = t(r); return n; }
s(uC, "baseTimes");
var nM = uC;
function cC(e) { return e != null && typeof e == "object"; }
s(cC, "isObjectLike");
var Wa = cC, aM = "[object Arguments]";
function fC(e) { return Wa(e) && ri(e) == aM; }
s(fC, "baseIsArguments");
var ny = fC, pC = Object.prototype, iM = pC.hasOwnProperty, sM = pC.propertyIsEnumerable, oM = ny((function () { return arguments; })()) ? ny : function (e) { return Wa(e) && iM.call(e, "callee") && !sM.call(e, "callee"); }, Tu = oM;
function dC() { return !1; }
s(dC, "stubFalse");
var lM = dC, mC = typeof exports == "object" && exports && !exports.nodeType && exports, ay = mC && typeof module == "object" && module && !module.nodeType && module, uM = ay && ay.exports === mC, iy = uM ? Cr.Buffer : void 0, cM = iy ? iy.isBuffer : void 0, fM = cM || lM, vl = fM, pM = 9007199254740991, dM = /^(?:0|[1-9]\d*)$/;
function hC(e, t) { var r = typeof e; return t = t ?? pM, !!t && (r == "number" || r != "symbol" && dM.test(e)) && e > -1 && e % 1 == 0 && e < t; }
s(hC, "isIndex");
var yC = hC, mM = 9007199254740991;
function gC(e) { return typeof e == "number" && e > -1 && e % 1 == 0 && e <= mM; }
s(gC, "isLength");
var im = gC, hM = "[object Arguments]", yM = "[object Array]", gM = "[object Boolean]", vM = "[object Date]", TM = "[object Error]", $M = "[object Function]", RM = "[object Map]", AM = "[object Number]", EM = "[object Object]", bM = "[object RegExp]", CM = "[object Set]", _M = "[object String]", SM = "[object WeakMap]", wM = "[object ArrayBuffer]", IM = "[object DataView]", NM = "[object Float32Array]", PM = "[object Float64Array]", kM = "[object Int8Array]", OM = "[object Int16Array]", LM = "[object Int32Array]", DM = "[object Uint8Array]", xM = "[object Uint8ClampedArray]", MM = "[object Uint16Array]", GM = "[object Uint32Array]", Te = {};
Te[NM] = Te[PM] = Te[kM] = Te[OM] = Te[LM] = Te[DM] = Te[xM] = Te[MM] = Te[GM] = !0;
Te[hM] = Te[yM] = Te[wM] = Te[gM] = Te[IM] = Te[vM] = Te[TM] = Te[$M] = Te[RM] = Te[AM] = Te[EM] = Te[bM] = Te[CM] = Te[_M] = Te[SM] = !1;
function vC(e) { return Wa(e) && im(e.length) && !!Te[ri(e)]; }
s(vC, "baseIsTypedArray");
var FM = vC;
function TC(e) { return function (t) { return e(t); }; }
s(TC, "baseUnary");
var zM = TC, $C = typeof exports == "object" && exports && !exports.nodeType && exports, cs = $C && typeof module == "object" && module && !module.nodeType && module, jM = cs && cs.exports === $C, Vu = jM && $b.process, UM = (function () { try {
    var e = cs && cs.require && cs.require("util").types;
    return e || Vu && Vu.binding && Vu.binding("util");
}
catch { } })(), sy = UM, oy = sy && sy.isTypedArray, BM = oy ? zM(oy) : FM, sm = BM, KM = Object.prototype, qM = KM.hasOwnProperty;
function RC(e, t) { var r = rt(e), n = !r && Tu(e), a = !r && !n && vl(e), i = !r && !n && !a && sm(e), o = r || n || a || i, l = o ? nM(e.length, String) : [], u = l.length; for (var c in e)
    (t || qM.call(e, c)) && !(o && (c == "length" || a && (c == "offset" || c == "parent") || i && (c == "buffer" || c == "byteLength" || c == "byteOffset") || yC(c, u))) && l.push(c); return l; }
s(RC, "arrayLikeKeys");
var WM = RC, VM = Object.prototype;
function AC(e) { var t = e && e.constructor, r = typeof t == "function" && t.prototype || VM; return e === r; }
s(AC, "isPrototype");
var EC = AC;
function bC(e, t) { return function (r) { return e(t(r)); }; }
s(bC, "overArg");
var HM = bC, YM = HM(Object.keys, Object), XM = YM, JM = Object.prototype, ZM = JM.hasOwnProperty;
function CC(e) { if (!EC(e))
    return XM(e); var t = []; for (var r in Object(e))
    ZM.call(e, r) && r != "constructor" && t.push(r); return t; }
s(CC, "baseKeys");
var _C = CC;
function SC(e) { return e != null && im(e.length) && !Sb(e); }
s(SC, "isArrayLike");
var $u = SC;
function wC(e) { return $u(e) ? WM(e) : _C(e); }
s(wC, "keys");
var om = wC;
function IC(e) { return Jx(e, om, rM); }
s(IC, "getAllKeys");
var ly = IC, QM = 1, e1 = Object.prototype, t1 = e1.hasOwnProperty;
function NC(e, t, r, n, a, i) { var o = r & QM, l = ly(e), u = l.length, c = ly(t), f = c.length; if (u != f && !o)
    return !1; for (var p = u; p--;) {
    var m = l[p];
    if (!(o ? m in t : t1.call(t, m)))
        return !1;
} var g = i.get(e), v = i.get(t); if (g && v)
    return g == t && v == e; var _ = !0; i.set(e, t), i.set(t, e); for (var N = o; ++p < u;) {
    m = l[p];
    var w = e[m], S = t[m];
    if (n)
        var E = o ? n(S, w, m, t, e, i) : n(w, S, m, e, t, i);
    if (!(E === void 0 ? w === S || a(w, S, r, n, i) : E)) {
        _ = !1;
        break;
    }
    N || (N = m == "constructor");
} if (_ && !N) {
    var I = e.constructor, j = t.constructor;
    I != j && "constructor" in e && "constructor" in t && !(typeof I == "function" && I instanceof I && typeof j == "function" && j instanceof j) && (_ = !1);
} return i.delete(e), i.delete(t), _; }
s(NC, "equalObjects");
var r1 = NC, n1 = ni(Cr, "DataView"), Gf = n1, a1 = ni(Cr, "Promise"), Ff = a1, i1 = ni(Cr, "Set"), xa = i1, s1 = ni(Cr, "WeakMap"), zf = s1, uy = "[object Map]", o1 = "[object Object]", cy = "[object Promise]", fy = "[object Set]", py = "[object WeakMap]", dy = "[object DataView]", l1 = Bn(Gf), u1 = Bn(bs), c1 = Bn(Ff), f1 = Bn(xa), p1 = Bn(zf), tn = ri;
(Gf && tn(new Gf(new ArrayBuffer(1))) != dy || bs && tn(new bs) != uy || Ff && tn(Ff.resolve()) != cy || xa && tn(new xa) != fy || zf && tn(new zf) != py) && (tn = s(function (e) { var t = ri(e), r = t == o1 ? e.constructor : void 0, n = r ? Bn(r) : ""; if (n)
    switch (n) {
        case l1: return dy;
        case u1: return uy;
        case c1: return cy;
        case f1: return fy;
        case p1: return py;
    } return t; }, "getTag"));
var jf = tn, d1 = 1, my = "[object Arguments]", hy = "[object Array]", ro = "[object Object]", m1 = Object.prototype, yy = m1.hasOwnProperty;
function PC(e, t, r, n, a, i) { var o = rt(e), l = rt(t), u = o ? hy : jf(e), c = l ? hy : jf(t); u = u == my ? ro : u, c = c == my ? ro : c; var f = u == ro, p = c == ro, m = u == c; if (m && vl(e)) {
    if (!vl(t))
        return !1;
    o = !0, f = !1;
} if (m && !f)
    return i || (i = new Oo), o || sm(e) ? Qb(e, t, r, n, a, i) : Yx(e, t, u, r, n, a, i); if (!(r & d1)) {
    var g = f && yy.call(e, "__wrapped__"), v = p && yy.call(t, "__wrapped__");
    if (g || v) {
        var _ = g ? e.value() : e, N = v ? t.value() : t;
        return i || (i = new Oo), a(_, N, r, n, i);
    }
} return m ? (i || (i = new Oo), r1(e, t, r, n, a, i)) : !1; }
s(PC, "baseIsEqualDeep");
var h1 = PC;
function lm(e, t, r, n, a) { return e === t ? !0 : e == null || t == null || !Wa(e) && !Wa(t) ? e !== e && t !== t : h1(e, t, r, n, lm, a); }
s(lm, "baseIsEqual");
var kC = lm, y1 = 1, g1 = 2;
function OC(e, t, r, n) { var a = r.length, i = a, o = !n; if (e == null)
    return !i; for (e = Object(e); a--;) {
    var l = r[a];
    if (o && l[2] ? l[1] !== e[l[0]] : !(l[0] in e))
        return !1;
} for (; ++a < i;) {
    l = r[a];
    var u = l[0], c = e[u], f = l[1];
    if (o && l[2]) {
        if (c === void 0 && !(u in e))
            return !1;
    }
    else {
        var p = new Oo;
        if (n)
            var m = n(c, f, u, e, t, p);
        if (!(m === void 0 ? kC(f, c, y1 | g1, n, p) : m))
            return !1;
    }
} return !0; }
s(OC, "baseIsMatch");
var v1 = OC;
function LC(e) { return e === e && !nm(e); }
s(LC, "isStrictComparable");
var DC = LC;
function xC(e) { for (var t = om(e), r = t.length; r--;) {
    var n = t[r], a = e[n];
    t[r] = [n, a, DC(a)];
} return t; }
s(xC, "getMatchData");
var T1 = xC;
function MC(e, t) { return function (r) { return r == null ? !1 : r[e] === t && (t !== void 0 || e in Object(r)); }; }
s(MC, "matchesStrictComparable");
var GC = MC;
function FC(e) { var t = T1(e); return t.length == 1 && t[0][2] ? GC(t[0][0], t[0][1]) : function (r) { return r === e || v1(r, e, t); }; }
s(FC, "baseMatches");
var $1 = FC, R1 = "[object Symbol]";
function zC(e) { return typeof e == "symbol" || Wa(e) && ri(e) == R1; }
s(zC, "isSymbol");
var Ru = zC, A1 = /\.|\[(?:[^[\]]*|(["'])(?:(?!\1)[^\\]|\\.)*?\1)\]/, E1 = /^\w*$/;
function jC(e, t) { if (rt(e))
    return !1; var r = typeof e; return r == "number" || r == "symbol" || r == "boolean" || e == null || Ru(e) ? !0 : E1.test(e) || !A1.test(e) || t != null && e in Object(t); }
s(jC, "isKey");
var um = jC, b1 = "Expected a function";
function Au(e, t) { if (typeof e != "function" || t != null && typeof t != "function")
    throw new TypeError(b1); var r = s(function () { var n = arguments, a = t ? t.apply(this, n) : n[0], i = r.cache; if (i.has(a))
    return i.get(a); var o = e.apply(this, n); return r.cache = i.set(a, o) || i, o; }, "memoized"); return r.cache = new (Au.Cache || vu), r; }
s(Au, "memoize");
Au.Cache = vu;
var C1 = Au, _1 = 500;
function UC(e) { var t = C1(e, function (n) { return r.size === _1 && r.clear(), n; }), r = t.cache; return t; }
s(UC, "memoizeCapped");
var S1 = UC, w1 = /[^.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|$))/g, I1 = /\\(\\)?/g, N1 = S1(function (e) { var t = []; return e.charCodeAt(0) === 46 && t.push(""), e.replace(w1, function (r, n, a, i) { t.push(a ? i.replace(I1, "$1") : n || r); }), t; }), P1 = N1, k1 = 1 / 0, gy = Jt ? Jt.prototype : void 0, vy = gy ? gy.toString : void 0;
function cm(e) { if (typeof e == "string")
    return e; if (rt(e))
    return ob(e, cm) + ""; if (Ru(e))
    return vy ? vy.call(e) : ""; var t = e + ""; return t == "0" && 1 / e == -k1 ? "-0" : t; }
s(cm, "baseToString");
var O1 = cm;
function BC(e) { return e == null ? "" : O1(e); }
s(BC, "toString");
var L1 = BC;
function KC(e, t) { return rt(e) ? e : um(e, t) ? [e] : P1(L1(e)); }
s(KC, "castPath");
var qC = KC, D1 = 1 / 0;
function WC(e) { if (typeof e == "string" || Ru(e))
    return e; var t = e + ""; return t == "0" && 1 / e == -D1 ? "-0" : t; }
s(WC, "toKey");
var Eu = WC;
function VC(e, t) { t = qC(t, e); for (var r = 0, n = t.length; e != null && r < n;)
    e = e[Eu(t[r++])]; return r && r == n ? e : void 0; }
s(VC, "baseGet");
var HC = VC;
function YC(e, t, r) { var n = e == null ? void 0 : HC(e, t); return n === void 0 ? r : n; }
s(YC, "get");
var x1 = YC;
function XC(e, t) { return e != null && t in Object(e); }
s(XC, "baseHasIn");
var M1 = XC;
function JC(e, t, r) { t = qC(t, e); for (var n = -1, a = t.length, i = !1; ++n < a;) {
    var o = Eu(t[n]);
    if (!(i = e != null && r(e, o)))
        break;
    e = e[o];
} return i || ++n != a ? i : (a = e == null ? 0 : e.length, !!a && im(a) && yC(o, a) && (rt(e) || Tu(e))); }
s(JC, "hasPath");
var G1 = JC;
function ZC(e, t) { return e != null && G1(e, t, M1); }
s(ZC, "hasIn");
var F1 = ZC, z1 = 1, j1 = 2;
function QC(e, t) { return um(e) && DC(t) ? GC(Eu(e), t) : function (r) { var n = x1(r, e); return n === void 0 && n === t ? F1(r, e) : kC(t, n, z1 | j1); }; }
s(QC, "baseMatchesProperty");
var U1 = QC;
function e_(e) { return e; }
s(e_, "identity");
var fm = e_;
function t_(e) { return function (t) { return t?.[e]; }; }
s(t_, "baseProperty");
var B1 = t_;
function r_(e) { return function (t) { return HC(t, e); }; }
s(r_, "basePropertyDeep");
var K1 = r_;
function n_(e) { return um(e) ? B1(Eu(e)) : K1(e); }
s(n_, "property");
var q1 = n_;
function a_(e) { return typeof e == "function" ? e : e == null ? fm : typeof e == "object" ? rt(e) ? U1(e[0], e[1]) : $1(e) : q1(e); }
s(a_, "baseIteratee");
var bu = a_;
function i_(e) { return function (t, r, n) { for (var a = -1, i = Object(t), o = n(t), l = o.length; l--;) {
    var u = o[e ? l : ++a];
    if (r(i[u], u, i) === !1)
        break;
} return t; }; }
s(i_, "createBaseFor");
var W1 = i_, V1 = W1(), H1 = V1;
function s_(e, t) { return e && H1(e, t, om); }
s(s_, "baseForOwn");
var Y1 = s_;
function o_(e, t) { return function (r, n) { if (r == null)
    return r; if (!$u(r))
    return e(r, n); for (var a = r.length, i = t ? a : -1, o = Object(r); (t ? i-- : ++i < a) && n(o[i], i, o) !== !1;)
    ; return r; }; }
s(o_, "createBaseEach");
var X1 = o_, J1 = X1(Y1), Cu = J1;
function l_(e, t) { var r = -1, n = $u(e) ? Array(e.length) : []; return Cu(e, function (a, i, o) { n[++r] = t(a, i, o); }), n; }
s(l_, "baseMap");
var Z1 = l_;
function u_(e, t) { var r = rt(e) ? ob : Z1; return r(e, bu(t, 3)); }
s(u_, "map");
var pr = u_;
function c_(e, t) { var r = []; return Cu(e, function (n, a, i) { t(n, a, i) && r.push(n); }), r; }
s(c_, "baseFilter");
var Q1 = c_;
function f_(e, t) { var r = rt(e) ? oC : Q1; return r(e, bu(t, 3)); }
s(f_, "filter");
var eG = f_;
function Sn(e, t, r) { return `${e.name}_${t}_${r}`; }
s(Sn, "buildATNKey");
var Gr = 1, tG = 2, p_ = 4, d_ = 5, Xs = 7, rG = 8, nG = 9, aG = 10, iG = 11, m_ = 12, pm = class {
    static { s(this, "AbstractTransition"); }
    constructor(e) { this.target = e; }
    isEpsilon() { return !1; }
}, dm = class extends pm {
    static { s(this, "AtomTransition"); }
    constructor(e, t) { super(e), this.tokenType = t; }
}, h_ = class extends pm {
    static { s(this, "EpsilonTransition"); }
    constructor(e) { super(e); }
    isEpsilon() { return !0; }
}, mm = class extends pm {
    static { s(this, "RuleTransition"); }
    constructor(e, t, r) { super(e), this.rule = t, this.followState = r; }
    isEpsilon() { return !0; }
};
function y_(e) { let t = { decisionMap: {}, decisionStates: [], ruleToStartState: new Map, ruleToStopState: new Map, states: [] }; g_(t, e); let r = e.length; for (let n = 0; n < r; n++) {
    let a = e[n], i = Kr(t, a, a);
    i !== void 0 && w_(t, a, i);
} return t; }
s(y_, "createATN");
function g_(e, t) { let r = t.length; for (let n = 0; n < r; n++) {
    let a = t[n], i = Fe(e, a, void 0, { type: tG }), o = Fe(e, a, void 0, { type: Xs });
    i.stop = o, e.ruleToStartState.set(a, i), e.ruleToStopState.set(a, o);
} }
s(g_, "createRuleStartAndStopATNStates");
function hm(e, t, r) { return r instanceof $e ? _u(e, t, r.terminalType, r) : r instanceof tt ? S_(e, t, r) : r instanceof ut ? A_(e, t, r) : r instanceof He ? E_(e, t, r) : r instanceof Ie ? v_(e, t, r) : r instanceof lt ? T_(e, t, r) : r instanceof vt ? $_(e, t, r) : r instanceof Tt ? R_(e, t, r) : Kr(e, t, r); }
s(hm, "atom");
function v_(e, t, r) { let n = Fe(e, t, r, { type: d_ }); _r(e, n); let a = Vn(e, t, n, r, Kr(e, t, r)); return gm(e, t, r, a); }
s(v_, "repetition");
function T_(e, t, r) { let n = Fe(e, t, r, { type: d_ }); _r(e, n); let a = Vn(e, t, n, r, Kr(e, t, r)), i = _u(e, t, r.separator, r); return gm(e, t, r, a, i); }
s(T_, "repetitionSep");
function $_(e, t, r) { let n = Fe(e, t, r, { type: p_ }); _r(e, n); let a = Vn(e, t, n, r, Kr(e, t, r)); return ym(e, t, r, a); }
s($_, "repetitionMandatory");
function R_(e, t, r) { let n = Fe(e, t, r, { type: p_ }); _r(e, n); let a = Vn(e, t, n, r, Kr(e, t, r)), i = _u(e, t, r.separator, r); return ym(e, t, r, a, i); }
s(R_, "repetitionMandatorySep");
function A_(e, t, r) { let n = Fe(e, t, r, { type: Gr }); _r(e, n); let a = pr(r.definition, o => hm(e, t, o)); return Vn(e, t, n, r, ...a); }
s(A_, "alternation");
function E_(e, t, r) { let n = Fe(e, t, r, { type: Gr }); _r(e, n); let a = Vn(e, t, n, r, Kr(e, t, r)); return b_(e, t, r, a); }
s(E_, "option");
function Kr(e, t, r) { let n = eG(pr(r.definition, a => hm(e, t, a)), a => a !== void 0); return n.length === 1 ? n[0] : n.length === 0 ? void 0 : __(e, n); }
s(Kr, "block");
function ym(e, t, r, n, a) { let i = n.left, o = n.right, l = Fe(e, t, r, { type: iG }); _r(e, l); let u = Fe(e, t, r, { type: m_ }); return i.loopback = l, u.loopback = l, e.decisionMap[Sn(t, a ? "RepetitionMandatoryWithSeparator" : "RepetitionMandatory", r.idx)] = l, Pe(o, l), a === void 0 ? (Pe(l, i), Pe(l, u)) : (Pe(l, u), Pe(l, a.left), Pe(a.right, i)), { left: i, right: u }; }
s(ym, "plus");
function gm(e, t, r, n, a) { let i = n.left, o = n.right, l = Fe(e, t, r, { type: aG }); _r(e, l); let u = Fe(e, t, r, { type: m_ }), c = Fe(e, t, r, { type: nG }); return l.loopback = c, u.loopback = c, Pe(l, i), Pe(l, u), Pe(o, c), a !== void 0 ? (Pe(c, u), Pe(c, a.left), Pe(a.right, i)) : Pe(c, l), e.decisionMap[Sn(t, a ? "RepetitionWithSeparator" : "Repetition", r.idx)] = l, { left: l, right: u }; }
s(gm, "star");
function b_(e, t, r, n) { let a = n.left, i = n.right; return Pe(a, i), e.decisionMap[Sn(t, "Option", r.idx)] = a, n; }
s(b_, "optional");
function _r(e, t) { return e.decisionStates.push(t), t.decision = e.decisionStates.length - 1, t.decision; }
s(_r, "defineDecisionState");
function Vn(e, t, r, n, ...a) { let i = Fe(e, t, n, { type: rG, start: r }); r.end = i; for (let l of a)
    l !== void 0 ? (Pe(r, l.left), Pe(l.right, i)) : Pe(r, i); let o = { left: r, right: i }; return e.decisionMap[Sn(t, C_(n), n.idx)] = r, o; }
s(Vn, "makeAlts");
function C_(e) { if (e instanceof ut)
    return "Alternation"; if (e instanceof He)
    return "Option"; if (e instanceof Ie)
    return "Repetition"; if (e instanceof lt)
    return "RepetitionWithSeparator"; if (e instanceof vt)
    return "RepetitionMandatory"; if (e instanceof Tt)
    return "RepetitionMandatoryWithSeparator"; throw new Error("Invalid production type encountered"); }
s(C_, "getProdType");
function __(e, t) { let r = t.length; for (let i = 0; i < r - 1; i++) {
    let o = t[i], l;
    o.left.transitions.length === 1 && (l = o.left.transitions[0]);
    let u = l instanceof mm, c = l, f = t[i + 1].left;
    o.left.type === Gr && o.right.type === Gr && l !== void 0 && (u && c.followState === o.right || l.target === o.right) ? (u ? c.followState = f : l.target = f, I_(e, o.right)) : Pe(o.right, f);
} let n = t[0], a = t[r - 1]; return { left: n.left, right: a.right }; }
s(__, "makeBlock");
function _u(e, t, r, n) { let a = Fe(e, t, n, { type: Gr }), i = Fe(e, t, n, { type: Gr }); return Su(a, new dm(i, r)), { left: a, right: i }; }
s(_u, "tokenRef");
function S_(e, t, r) { let n = r.referencedRule, a = e.ruleToStartState.get(n), i = Fe(e, t, r, { type: Gr }), o = Fe(e, t, r, { type: Gr }), l = new mm(a, n, o); return Su(i, l), { left: i, right: o }; }
s(S_, "ruleRef");
function w_(e, t, r) { let n = e.ruleToStartState.get(t); Pe(n, r.left); let a = e.ruleToStopState.get(t); return Pe(r.right, a), { left: n, right: a }; }
s(w_, "buildRuleHandle");
function Pe(e, t) { let r = new h_(t); Su(e, r); }
s(Pe, "epsilon");
function Fe(e, t, r, n) { let a = Object.assign({ atn: e, production: r, epsilonOnlyTransitions: !1, rule: t, transitions: [], nextTokenWithinRule: [], stateNumber: e.states.length }, n); return e.states.push(a), a; }
s(Fe, "newState");
function Su(e, t) { e.transitions.length === 0 && (e.epsilonOnlyTransitions = t.isEpsilon()), e.transitions.push(t); }
s(Su, "addTransition");
function I_(e, t) { e.states.splice(e.states.indexOf(t), 1); }
s(I_, "removeState");
var Tl = {}, Uf = class {
    static { s(this, "ATNConfigSet"); }
    constructor() { this.map = {}, this.configs = []; }
    get size() { return this.configs.length; }
    finalize() { this.map = {}; }
    add(e) { let t = vm(e); t in this.map || (this.map[t] = this.configs.length, this.configs.push(e)); }
    get elements() { return this.configs; }
    get alts() { return pr(this.configs, e => e.alt); }
    get key() { let e = ""; for (let t in this.map)
        e += t + ":"; return e; }
};
function vm(e, t = !0) { return `${t ? `a${e.alt}` : ""}s${e.state.stateNumber}:${e.stack.map(r => r.stateNumber.toString()).join("_")}`; }
s(vm, "getATNConfigKey");
function N_(e, t, r) { for (var n = -1, a = e.length; ++n < a;) {
    var i = e[n], o = t(i);
    if (o != null && (l === void 0 ? o === o && !Ru(o) : r(o, l)))
        var l = o, u = i;
} return u; }
s(N_, "baseExtremum");
var sG = N_;
function P_(e, t) { return e < t; }
s(P_, "baseLt");
var oG = P_;
function k_(e) { return e && e.length ? sG(e, fm, oG) : void 0; }
s(k_, "min");
var lG = k_, Ty = Jt ? Jt.isConcatSpreadable : void 0;
function O_(e) { return rt(e) || Tu(e) || !!(Ty && e && e[Ty]); }
s(O_, "isFlattenable");
var uG = O_;
function Tm(e, t, r, n, a) { var i = -1, o = e.length; for (r || (r = uG), a || (a = []); ++i < o;) {
    var l = e[i];
    t > 0 && r(l) ? t > 1 ? Tm(l, t - 1, r, n, a) : aC(a, l) : n || (a[a.length] = l);
} return a; }
s(Tm, "baseFlatten");
var L_ = Tm;
function D_(e, t) { return L_(pr(e, t), 1); }
s(D_, "flatMap");
var cG = D_;
function x_(e, t, r, n) { for (var a = e.length, i = r + (n ? 1 : -1); n ? i-- : ++i < a;)
    if (t(e[i], i, e))
        return i; return -1; }
s(x_, "baseFindIndex");
var fG = x_;
function M_(e) { return e !== e; }
s(M_, "baseIsNaN");
var pG = M_;
function G_(e, t, r) { for (var n = r - 1, a = e.length; ++n < a;)
    if (e[n] === t)
        return n; return -1; }
s(G_, "strictIndexOf");
var dG = G_;
function F_(e, t, r) { return t === t ? dG(e, t, r) : fG(e, pG, r); }
s(F_, "baseIndexOf");
var mG = F_;
function z_(e, t) { var r = e == null ? 0 : e.length; return !!r && mG(e, t, 0) > -1; }
s(z_, "arrayIncludes");
var hG = z_;
function j_(e, t, r) { for (var n = -1, a = e == null ? 0 : e.length; ++n < a;)
    if (r(t, e[n]))
        return !0; return !1; }
s(j_, "arrayIncludesWith");
var yG = j_;
function U_() { }
s(U_, "noop");
var gG = U_, vG = 1 / 0, TG = xa && 1 / am(new xa([, -0]))[1] == vG ? function (e) { return new xa(e); } : gG, $G = TG, RG = 200;
function B_(e, t, r) { var n = -1, a = hG, i = e.length, o = !0, l = [], u = l; if (r)
    o = !1, a = yG;
else if (i >= RG) {
    var c = t ? null : $G(e);
    if (c)
        return am(c);
    o = !1, a = Jb, u = new Hb;
}
else
    u = t ? [] : l; e: for (; ++n < i;) {
    var f = e[n], p = t ? t(f) : f;
    if (f = r || f !== 0 ? f : 0, o && p === p) {
        for (var m = u.length; m--;)
            if (u[m] === p)
                continue e;
        t && u.push(p), l.push(f);
    }
    else
        a(u, p, r) || (u !== l && u.push(p), l.push(f));
} return l; }
s(B_, "baseUniq");
var AG = B_;
function K_(e, t) { return e && e.length ? AG(e, bu(t, 2)) : []; }
s(K_, "uniqBy");
var EG = K_;
function q_(e) { var t = e == null ? 0 : e.length; return t ? L_(e, 1) : []; }
s(q_, "flatten");
var bG = q_;
function W_(e, t) { for (var r = -1, n = e == null ? 0 : e.length; ++r < n && t(e[r], r, e) !== !1;)
    ; return e; }
s(W_, "arrayEach");
var CG = W_;
function V_(e) { return typeof e == "function" ? e : fm; }
s(V_, "castFunction");
var _G = V_;
function H_(e, t) { var r = rt(e) ? CG : Cu; return r(e, _G(t)); }
s(H_, "forEach");
var Hu = H_, SG = "[object Map]", wG = "[object Set]", IG = Object.prototype, NG = IG.hasOwnProperty;
function Y_(e) { if (e == null)
    return !0; if ($u(e) && (rt(e) || typeof e == "string" || typeof e.splice == "function" || vl(e) || sm(e) || Tu(e)))
    return !e.length; var t = jf(e); if (t == SG || t == wG)
    return !e.size; if (EC(e))
    return !_C(e).length; for (var r in e)
    if (NG.call(e, r))
        return !1; return !0; }
s(Y_, "isEmpty");
var PG = Y_;
function X_(e, t, r, n) { var a = -1, i = e == null ? 0 : e.length; for (n && i && (r = e[++a]); ++a < i;)
    r = t(r, e[a], a, e); return r; }
s(X_, "arrayReduce");
var kG = X_;
function J_(e, t, r, n, a) { return a(e, function (i, o, l) { r = n ? (n = !1, i) : t(r, i, o, l); }), r; }
s(J_, "baseReduce");
var OG = J_;
function Z_(e, t, r) { var n = rt(e) ? kG : OG, a = arguments.length < 3; return n(e, bu(t, 4), r, a, Cu); }
s(Z_, "reduce");
var $y = Z_;
function Q_(e, t) { let r = {}; return n => { let a = n.toString(), i = r[a]; return i !== void 0 || (i = { atnStartState: e, decision: t, states: {} }, r[a] = i), i; }; }
s(Q_, "createDFACache");
var eS = class {
    static { s(this, "PredicateSet"); }
    constructor() { this.predicates = []; }
    is(e) { return e >= this.predicates.length || this.predicates[e]; }
    set(e, t) { this.predicates[e] = t; }
    toString() { let e = "", t = this.predicates.length; for (let r = 0; r < t; r++)
        e += this.predicates[r] === !0 ? "1" : "0"; return e; }
}, Ry = new eS, LG = class extends tm {
    static { s(this, "LLStarLookaheadStrategy"); }
    constructor(e) { var t; super(), this.logging = (t = e?.logging) !== null && t !== void 0 ? t : r => console.log(r); }
    initialize(e) { this.atn = y_(e.rules), this.dfas = tS(this.atn); }
    validateAmbiguousAlternationAlternatives() { return []; }
    validateEmptyOrAlternatives() { return []; }
    buildLookaheadForAlternation(e) { let { prodOccurrence: t, rule: r, hasPredicates: n, dynamicTokensEnabled: a } = e, i = this.dfas, o = this.logging, l = Sn(r, "Alternation", t), c = this.atn.decisionMap[l].decision, f = pr(If({ maxLookahead: 1, occurrence: t, prodType: "Alternation", rule: r }), p => pr(p, m => m[0])); if (Bf(f, !1) && !a) {
        let p = $y(f, (m, g, v) => (Hu(g, _ => { _ && (m[_.tokenTypeIdx] = v, Hu(_.categoryMatches, N => { m[N] = v; })); }), m), {});
        return n ? function (m) { var g; let v = this.LA(1), _ = p[v.tokenTypeIdx]; if (m !== void 0 && _ !== void 0) {
            let N = (g = m[_]) === null || g === void 0 ? void 0 : g.GATE;
            if (N !== void 0 && N.call(this) === !1)
                return;
        } return _; } : function () { let m = this.LA(1); return p[m.tokenTypeIdx]; };
    }
    else
        return n ? function (p) { let m = new eS, g = p === void 0 ? 0 : p.length; for (let _ = 0; _ < g; _++) {
            let N = p?.[_].GATE;
            m.set(_, N === void 0 || N.call(this));
        } let v = Lo.call(this, i, c, m, o); return typeof v == "number" ? v : void 0; } : function () { let p = Lo.call(this, i, c, Ry, o); return typeof p == "number" ? p : void 0; }; }
    buildLookaheadForOptional(e) { let { prodOccurrence: t, rule: r, prodType: n, dynamicTokensEnabled: a } = e, i = this.dfas, o = this.logging, l = Sn(r, n, t), c = this.atn.decisionMap[l].decision, f = pr(If({ maxLookahead: 1, occurrence: t, prodType: n, rule: r }), p => pr(p, m => m[0])); if (Bf(f) && f[0][0] && !a) {
        let p = f[0], m = bG(p);
        if (m.length === 1 && PG(m[0].categoryMatches)) {
            let v = m[0].tokenTypeIdx;
            return function () { return this.LA(1).tokenTypeIdx === v; };
        }
        else {
            let g = $y(m, (v, _) => (_ !== void 0 && (v[_.tokenTypeIdx] = !0, Hu(_.categoryMatches, N => { v[N] = !0; })), v), {});
            return function () { let v = this.LA(1); return g[v.tokenTypeIdx] === !0; };
        }
    } return function () { let p = Lo.call(this, i, c, Ry, o); return typeof p == "object" ? !1 : p === 0; }; }
};
function Bf(e, t = !0) { let r = new Set; for (let n of e) {
    let a = new Set;
    for (let i of n) {
        if (i === void 0) {
            if (t)
                break;
            return !1;
        }
        let o = [i.tokenTypeIdx].concat(i.categoryMatches);
        for (let l of o)
            if (r.has(l)) {
                if (!a.has(l))
                    return !1;
            }
            else
                r.add(l), a.add(l);
    }
} return !0; }
s(Bf, "isLL1Sequence");
function tS(e) { let t = e.decisionStates.length, r = Array(t); for (let n = 0; n < t; n++)
    r[n] = Q_(e.decisionStates[n], n); return r; }
s(tS, "initATNSimulator");
function Lo(e, t, r, n) { let a = e[t](r), i = a.start; if (i === void 0) {
    let l = pS(a.atnStartState);
    i = Rm(a, $m(l)), a.start = i;
} return rS.apply(this, [a, i, r, n]); }
s(Lo, "adaptivePredict");
function rS(e, t, r, n) { let a = t, i = 1, o = [], l = this.LA(i++); for (;;) {
    let u = lS(a, l);
    if (u === void 0 && (u = nS.apply(this, [e, a, l, i, r, n])), u === Tl)
        return oS(o, a, l);
    if (u.isAcceptState === !0)
        return u.prediction;
    a = u, o.push(l), l = this.LA(i++);
} }
s(rS, "performLookahead");
function nS(e, t, r, n, a, i) { let o = uS(t.configs, r, a); if (o.size === 0)
    return Kf(e, t, r, Tl), Tl; let l = $m(o), u = fS(o, a); if (u !== void 0)
    l.isAcceptState = !0, l.prediction = u, l.configs.uniqueAlt = u;
else if (yS(o)) {
    let c = lG(o.alts);
    l.isAcceptState = !0, l.prediction = c, l.configs.uniqueAlt = c, aS.apply(this, [e, n, o.alts, i]);
} return l = Kf(e, t, r, l), l; }
s(nS, "computeLookaheadTarget");
function aS(e, t, r, n) { let a = []; for (let c = 1; c <= t; c++)
    a.push(this.LA(c).tokenType); let i = e.atnStartState, o = i.rule, l = i.production, u = iS({ topLevelRule: o, ambiguityIndices: r, production: l, prefixPath: a }); n(u); }
s(aS, "reportLookaheadAmbiguity");
function iS(e) {
    let t = pr(e.prefixPath, a => An(a)).join(", "), r = e.production.idx === 0 ? "" : e.production.idx, n = `Ambiguous Alternatives Detected: <${e.ambiguityIndices.join(", ")}> in <${sS(e.production)}${r}> inside <${e.topLevelRule.name}> Rule,
<${t}> may appears as a prefix path in all these alternatives.
`;
    return n = n + `See: https://chevrotain.io/docs/guide/resolving_grammar_errors.html#AMBIGUOUS_ALTERNATIVES
For Further details.`, n;
}
s(iS, "buildAmbiguityError");
function sS(e) { if (e instanceof tt)
    return "SUBRULE"; if (e instanceof He)
    return "OPTION"; if (e instanceof ut)
    return "OR"; if (e instanceof vt)
    return "AT_LEAST_ONE"; if (e instanceof Tt)
    return "AT_LEAST_ONE_SEP"; if (e instanceof lt)
    return "MANY_SEP"; if (e instanceof Ie)
    return "MANY"; if (e instanceof $e)
    return "CONSUME"; throw Error("non exhaustive match"); }
s(sS, "getProductionDslName");
function oS(e, t, r) { let n = cG(t.configs.elements, i => i.state.transitions), a = EG(n.filter(i => i instanceof dm).map(i => i.tokenType), i => i.tokenTypeIdx); return { actualToken: r, possibleTokenTypes: a, tokenPath: e }; }
s(oS, "buildAdaptivePredictError");
function lS(e, t) { return e.edges[t.tokenTypeIdx]; }
s(lS, "getExistingTargetState");
function uS(e, t, r) { let n = new Uf, a = []; for (let o of e.elements) {
    if (r.is(o.alt) === !1)
        continue;
    if (o.state.type === Xs) {
        a.push(o);
        continue;
    }
    let l = o.state.transitions.length;
    for (let u = 0; u < l; u++) {
        let c = o.state.transitions[u], f = cS(c, t);
        f !== void 0 && n.add({ state: f, alt: o.alt, stack: o.stack });
    }
} let i; if (a.length === 0 && n.size === 1 && (i = n), i === void 0) {
    i = new Uf;
    for (let o of n.elements)
        Ss(o, i);
} if (a.length > 0 && !mS(i))
    for (let o of a)
        i.add(o); return i; }
s(uS, "computeReachSet");
function cS(e, t) { if (e instanceof dm && Hd(t, e.tokenType))
    return e.target; }
s(cS, "getReachableTarget");
function fS(e, t) { let r; for (let n of e.elements)
    if (t.is(n.alt) === !0) {
        if (r === void 0)
            r = n.alt;
        else if (r !== n.alt)
            return;
    } return r; }
s(fS, "getUniqueAlt");
function $m(e) { return { configs: e, edges: {}, isAcceptState: !1, prediction: -1 }; }
s($m, "newDFAState");
function Kf(e, t, r, n) { return n = Rm(e, n), t.edges[r.tokenTypeIdx] = n, n; }
s(Kf, "addDFAEdge");
function Rm(e, t) { if (t === Tl)
    return t; let r = t.configs.key, n = e.states[r]; return n !== void 0 ? n : (t.configs.finalize(), e.states[r] = t, t); }
s(Rm, "addDFAState");
function pS(e) { let t = new Uf, r = e.transitions.length; for (let n = 0; n < r; n++) {
    let i = { state: e.transitions[n].target, alt: n, stack: [] };
    Ss(i, t);
} return t; }
s(pS, "computeStartState");
function Ss(e, t) { let r = e.state; if (r.type === Xs) {
    if (e.stack.length > 0) {
        let a = [...e.stack], o = { state: a.pop(), alt: e.alt, stack: a };
        Ss(o, t);
    }
    else
        t.add(e);
    return;
} r.epsilonOnlyTransitions || t.add(e); let n = r.transitions.length; for (let a = 0; a < n; a++) {
    let i = r.transitions[a], o = dS(e, i);
    o !== void 0 && Ss(o, t);
} }
s(Ss, "closure");
function dS(e, t) { if (t instanceof h_)
    return { state: t.target, alt: e.alt, stack: e.stack }; if (t instanceof mm) {
    let r = [...e.stack, t.followState];
    return { state: t.target, alt: e.alt, stack: r };
} }
s(dS, "getEpsilonTarget");
function mS(e) { for (let t of e.elements)
    if (t.state.type === Xs)
        return !0; return !1; }
s(mS, "hasConfigInRuleStopState");
function hS(e) { for (let t of e.elements)
    if (t.state.type !== Xs)
        return !1; return !0; }
s(hS, "allConfigsInRuleStopStates");
function yS(e) { if (hS(e))
    return !0; let t = gS(e.elements); return vS(t) && !TS(t); }
s(yS, "hasConflictTerminatingPrediction");
function gS(e) { let t = new Map; for (let r of e) {
    let n = vm(r, !1), a = t.get(n);
    a === void 0 && (a = {}, t.set(n, a)), a[r.alt] = !0;
} return t; }
s(gS, "getConflictingAltSets");
function vS(e) { for (let t of Array.from(e.values()))
    if (Object.keys(t).length > 1)
        return !0; return !1; }
s(vS, "hasConflictingAltSet");
function TS(e) { for (let t of Array.from(e.values()))
    if (Object.keys(t).length === 1)
        return !0; return !1; }
s(TS, "hasStateAssociatedWithOneAlt");
Ns();
var $S = class {
    static { s(this, "CstNodeBuilder"); }
    constructor() { this.nodeStack = []; }
    get current() { return this.nodeStack[this.nodeStack.length - 1] ?? this.rootNode; }
    buildRootNode(e) { return this.rootNode = new Em(e), this.rootNode.root = this.rootNode, this.nodeStack = [this.rootNode], this.rootNode; }
    buildCompositeNode(e) { let t = new wu; return t.grammarSource = e, t.root = this.rootNode, this.current.content.push(t), this.nodeStack.push(t), t; }
    buildLeafNode(e, t) { let r = new $l(e.startOffset, e.image.length, ms(e), e.tokenType, !t); return r.grammarSource = t, r.root = this.rootNode, this.current.content.push(r), r; }
    removeNode(e) { let t = e.container; if (t) {
        let r = t.content.indexOf(e);
        r >= 0 && t.content.splice(r, 1);
    } }
    addHiddenNodes(e) { let t = []; for (let a of e) {
        let i = new $l(a.startOffset, a.image.length, ms(a), a.tokenType, !0);
        i.root = this.rootNode, t.push(i);
    } let r = this.current, n = !1; if (r.content.length > 0) {
        r.content.push(...t);
        return;
    } for (; r.container;) {
        let a = r.container.content.indexOf(r);
        if (a > 0) {
            r.container.content.splice(a, 0, ...t), n = !0;
            break;
        }
        r = r.container;
    } n || this.rootNode.content.unshift(...t); }
    construct(e) { let t = this.current; typeof e.$type == "string" && !e.$infixName && (this.current.astNode = e), e.$cstNode = t; let r = this.nodeStack.pop(); r?.content.length === 0 && this.removeNode(r); }
}, Am = class {
    static { s(this, "AbstractCstNode"); }
    get hidden() { return !1; }
    get astNode() { let e = typeof this._astNode?.$type == "string" ? this._astNode : this.container?.astNode; if (!e)
        throw new Error("This node has no associated AST element"); return e; }
    set astNode(e) { this._astNode = e; }
    get text() { return this.root.fullText.substring(this.offset, this.end); }
}, $l = class extends Am {
    static { s(this, "LeafCstNodeImpl"); }
    get offset() { return this._offset; }
    get length() { return this._length; }
    get end() { return this._offset + this._length; }
    get hidden() { return this._hidden; }
    get tokenType() { return this._tokenType; }
    get range() { return this._range; }
    constructor(e, t, r, n, a = !1) { super(), this._hidden = a, this._offset = e, this._tokenType = n, this._length = t, this._range = r; }
}, wu = class extends Am {
    static { s(this, "CompositeCstNodeImpl"); }
    constructor() { super(...arguments), this.content = new DG(this); }
    get offset() { return this.firstNonHiddenNode?.offset ?? 0; }
    get length() { return this.end - this.offset; }
    get end() { return this.lastNonHiddenNode?.end ?? 0; }
    get range() { let e = this.firstNonHiddenNode, t = this.lastNonHiddenNode; if (e && t) {
        if (this._rangeCache === void 0) {
            let { range: r } = e, { range: n } = t;
            this._rangeCache = { start: r.start, end: n.end.line < r.start.line ? r.start : n.end };
        }
        return this._rangeCache;
    }
    else
        return { start: ae.create(0, 0), end: ae.create(0, 0) }; }
    get firstNonHiddenNode() { for (let e of this.content)
        if (!e.hidden)
            return e; return this.content[0]; }
    get lastNonHiddenNode() { for (let e = this.content.length - 1; e >= 0; e--) {
        let t = this.content[e];
        if (!t.hidden)
            return t;
    } return this.content[this.content.length - 1]; }
}, DG = class RS extends Array {
    static { s(this, "CstNodeContainer"); }
    constructor(t) { super(), this.parent = t, Object.setPrototypeOf(this, RS.prototype); }
    push(...t) { return this.addParents(t), super.push(...t); }
    unshift(...t) { return this.addParents(t), super.unshift(...t); }
    splice(t, r, ...n) { return this.addParents(n), super.splice(t, r, ...n); }
    addParents(t) { for (let r of t)
        r.container = this.parent; }
}, Em = class extends wu {
    static { s(this, "RootCstNodeImpl"); }
    get text() { return this._text.substring(this.offset, this.end); }
    get fullText() { return this._text; }
    constructor(e) { super(), this._text = "", this._text = e ?? ""; }
}, Rl = Symbol("Datatype");
function Do(e) { return e.$type === Rl; }
s(Do, "isDataTypeNode");
var Ay = "\u200B", AS = s(e => e.endsWith(Ay) ? e : e + Ay, "withRuleSuffix"), bm = class {
    static { s(this, "AbstractLangiumParser"); }
    constructor(e) { this._unorderedGroups = new Map, this.allRules = new Map, this.lexer = e.parser.Lexer; let t = this.lexer.definition, r = e.LanguageMetaData.mode === "production"; e.shared.profilers.LangiumProfiler?.isActive("parsing") ? this.wrapper = new MG(t, wr(ie({}, e.parser.ParserConfig), { skipValidations: r, errorMessageProvider: e.parser.ParserErrorMessageProvider }), e.shared.profilers.LangiumProfiler.createTask("parsing", e.LanguageMetaData.languageId)) : this.wrapper = new _S(t, wr(ie({}, e.parser.ParserConfig), { skipValidations: r, errorMessageProvider: e.parser.ParserErrorMessageProvider })); }
    alternatives(e, t) { this.wrapper.wrapOr(e, t); }
    optional(e, t) { this.wrapper.wrapOption(e, t); }
    many(e, t) { this.wrapper.wrapMany(e, t); }
    atLeastOne(e, t) { this.wrapper.wrapAtLeastOne(e, t); }
    getRule(e) { return this.allRules.get(e); }
    isRecording() { return this.wrapper.IS_RECORDING; }
    get unorderedGroups() { return this._unorderedGroups; }
    getRuleStack() { return this.wrapper.RULE_STACK; }
    finalize() { this.wrapper.wrapSelfAnalysis(); }
}, ES = class extends bm {
    static { s(this, "LangiumParser"); }
    get current() { return this.stack[this.stack.length - 1]; }
    constructor(e) { super(e), this.nodeBuilder = new $S, this.stack = [], this.assignmentMap = new Map, this.operatorPrecedence = new Map, this.linker = e.references.Linker, this.converter = e.parser.ValueConverter, this.astReflection = e.shared.AstReflection; }
    rule(e, t) { let r = this.computeRuleType(e), n; ja(e) && (n = e.name, this.registerPrecedenceMap(e)); let a = this.wrapper.DEFINE_RULE(AS(e.name), this.startImplementation(r, n, t).bind(this)); return this.allRules.set(e.name, a), et(e) && e.entry && (this.mainRule = a), a; }
    registerPrecedenceMap(e) { let t = e.name, r = new Map; for (let n = 0; n < e.operators.precedences.length; n++) {
        let a = e.operators.precedences[n];
        for (let i of a.operators)
            r.set(i.value, { precedence: n, rightAssoc: a.associativity === "right" });
    } this.operatorPrecedence.set(t, r); }
    computeRuleType(e) { return ja(e) ? bn(e) : e.fragment ? void 0 : Ls(e) ? Rl : bn(e); }
    parse(e, t = {}) { this.nodeBuilder.buildRootNode(e); let r = this.lexerResult = this.lexer.tokenize(e); this.wrapper.input = r.tokens; let n = t.rule ? this.allRules.get(t.rule) : this.mainRule; if (!n)
        throw new Error(t.rule ? `No rule found with name '${t.rule}'` : "No main rule available."); let a = this.doParse(n); return this.nodeBuilder.addHiddenNodes(r.hidden), this.unorderedGroups.clear(), this.lexerResult = void 0, Fa(a, { deep: !0 }), { value: a, lexerErrors: r.errors, lexerReport: r.report, parserErrors: this.wrapper.errors }; }
    doParse(e) { let t = this.wrapper.rule(e); if (this.stack.length > 0 && (t = this.construct()), t === void 0)
        throw new Error("No result from parser"); if (this.stack.length > 0)
        throw new Error("Parser stack is not empty after parsing"); return t; }
    startImplementation(e, t, r) { return n => { let a = !this.isRecording() && e !== void 0; if (a) {
        let i = { $type: e };
        this.stack.push(i), e === Rl ? i.value = "" : t !== void 0 && (i.$infixName = t);
    } return r(n), a ? this.construct() : void 0; }; }
    extractHiddenTokens(e) { let t = this.lexerResult.hidden; if (!t.length)
        return []; let r = e.startOffset; for (let n = 0; n < t.length; n++)
        if (t[n].startOffset > r)
            return t.splice(0, n); return t.splice(0, t.length); }
    consume(e, t, r) { let n = this.wrapper.wrapConsume(e, t); if (!this.isRecording() && this.isValidToken(n)) {
        let a = this.extractHiddenTokens(n);
        this.nodeBuilder.addHiddenNodes(a);
        let i = this.nodeBuilder.buildLeafNode(n, r), { assignment: o, crossRef: l } = this.getAssignment(r), u = this.current;
        if (o) {
            let c = hr(r) ? n.image : this.converter.convert(n.image, i);
            this.assign(o.operator, o.feature, c, i, l);
        }
        else if (Do(u)) {
            let c = n.image;
            hr(r) || (c = this.converter.convert(c, i).toString()), u.value += c;
        }
    } }
    isValidToken(e) { return !e.isInsertedInRecovery && !isNaN(e.startOffset) && typeof e.endOffset == "number" && !isNaN(e.endOffset); }
    subrule(e, t, r, n, a) { let i; !this.isRecording() && !r && (i = this.nodeBuilder.buildCompositeNode(n)); let o; try {
        o = this.wrapper.wrapSubrule(e, t, a);
    }
    finally {
        this.isRecording() || (o === void 0 && !r && (o = this.construct()), o !== void 0 && i && i.length > 0 && this.performSubruleAssignment(o, n, i));
    } }
    performSubruleAssignment(e, t, r) { let { assignment: n, crossRef: a } = this.getAssignment(t); if (n)
        this.assign(n.operator, n.feature, e, r, a);
    else if (!n) {
        let i = this.current;
        if (Do(i))
            i.value += e.toString();
        else if (typeof e == "object" && e) {
            let l = this.assignWithoutOverride(e, i);
            this.stack.pop(), this.stack.push(l);
        }
    } }
    action(e, t) { if (!this.isRecording()) {
        let r = this.current;
        if (t.feature && t.operator) {
            r = this.construct(), this.nodeBuilder.removeNode(r.$cstNode), this.nodeBuilder.buildCompositeNode(t).content.push(r.$cstNode);
            let a = { $type: e };
            this.stack.push(a), this.assign(t.operator, t.feature, r, r.$cstNode);
        }
        else
            r.$type = e;
    } }
    construct() { if (this.isRecording())
        return; let e = this.stack.pop(); return this.nodeBuilder.construct(e), "$infixName" in e ? this.constructInfix(e, this.operatorPrecedence.get(e.$infixName)) : Do(e) ? this.converter.convert(e.value, e.$cstNode) : (Ep(this.astReflection, e), e); }
    constructInfix(e, t) { let r = e.parts; if (!Array.isArray(r) || r.length === 0)
        return; let n = e.operators; if (!Array.isArray(n) || r.length < 2)
        return r[0]; let a = 0, i = -1; for (let v = 0; v < n.length; v++) {
        let _ = n[v], N = t.get(_) ?? { precedence: 1 / 0, rightAssoc: !1 };
        N.precedence > i ? (i = N.precedence, a = v) : N.precedence === i && (N.rightAssoc || (a = v));
    } let o = n.slice(0, a), l = n.slice(a + 1), u = r.slice(0, a + 1), c = r.slice(a + 1), f = { $infixName: e.$infixName, $type: e.$type, $cstNode: e.$cstNode, parts: u, operators: o }, p = { $infixName: e.$infixName, $type: e.$type, $cstNode: e.$cstNode, parts: c, operators: l }, m = this.constructInfix(f, t), g = this.constructInfix(p, t); return { $type: e.$type, $cstNode: e.$cstNode, left: m, operator: n[a], right: g }; }
    getAssignment(e) { if (!this.assignmentMap.has(e)) {
        let t = Nn(e, mr);
        this.assignmentMap.set(e, { assignment: t, crossRef: t && kn(t.terminal) ? t.terminal.isMulti ? "multi" : "single" : void 0 });
    } return this.assignmentMap.get(e); }
    assign(e, t, r, n, a) { let i = this.current, o; switch (a === "single" && typeof r == "string" ? o = this.linker.buildReference(i, t, n, r) : a === "multi" && typeof r == "string" ? o = this.linker.buildMultiReference(i, t, n, r) : o = r, e) {
        case "=": {
            i[t] = o;
            break;
        }
        case "?=": {
            i[t] = !0;
            break;
        }
        case "+=": Array.isArray(i[t]) || (i[t] = []), i[t].push(o);
    } }
    assignWithoutOverride(e, t) { for (let [n, a] of Object.entries(t)) {
        let i = e[n];
        i === void 0 ? e[n] = a : Array.isArray(i) && Array.isArray(a) && (a.push(...i), e[n] = a);
    } let r = e.$cstNode; return r && (r.astNode = void 0, e.$cstNode = void 0), e; }
    get definitionErrors() { return this.wrapper.definitionErrors; }
}, bS = class {
    static { s(this, "AbstractParserErrorMessageProvider"); }
    buildMismatchTokenMessage(e) { return Pa.buildMismatchTokenMessage(e); }
    buildNotAllInputParsedMessage(e) { return Pa.buildNotAllInputParsedMessage(e); }
    buildNoViableAltMessage(e) { return Pa.buildNoViableAltMessage(e); }
    buildEarlyExitMessage(e) { return Pa.buildEarlyExitMessage(e); }
}, Cm = class extends bS {
    static { s(this, "LangiumParserErrorMessageProvider"); }
    buildMismatchTokenMessage({ expected: e, actual: t }) { return `Expecting ${e.LABEL ? "`" + e.LABEL + "`" : e.name.endsWith(":KW") ? `keyword '${e.name.substring(0, e.name.length - 3)}'` : `token of type '${e.name}'`} but found \`${t.image}\`.`; }
    buildNotAllInputParsedMessage({ firstRedundant: e }) { return `Expecting end of file but found \`${e.image}\`.`; }
}, CS = class extends bm {
    static { s(this, "LangiumCompletionParser"); }
    constructor() { super(...arguments), this.tokens = [], this.elementStack = [], this.lastElementStack = [], this.nextTokenIndex = 0, this.stackSize = 0; }
    action() { }
    construct() { }
    parse(e) { this.resetState(); let t = this.lexer.tokenize(e, { mode: "partial" }); return this.tokens = t.tokens, this.wrapper.input = [...this.tokens], this.mainRule.call(this.wrapper, {}), this.unorderedGroups.clear(), { tokens: this.tokens, elementStack: [...this.lastElementStack], tokenIndex: this.nextTokenIndex }; }
    rule(e, t) { let r = this.wrapper.DEFINE_RULE(AS(e.name), this.startImplementation(t).bind(this)); return this.allRules.set(e.name, r), e.entry && (this.mainRule = r), r; }
    resetState() { this.elementStack = [], this.lastElementStack = [], this.nextTokenIndex = 0, this.stackSize = 0; }
    startImplementation(e) { return t => { let r = this.keepStackSize(); try {
        e(t);
    }
    finally {
        this.resetStackSize(r);
    } }; }
    removeUnexpectedElements() { this.elementStack.splice(this.stackSize); }
    keepStackSize() { let e = this.elementStack.length; return this.stackSize = e, e; }
    resetStackSize(e) { this.removeUnexpectedElements(), this.stackSize = e; }
    consume(e, t, r) { this.wrapper.wrapConsume(e, t), this.isRecording() || (this.lastElementStack = [...this.elementStack, r], this.nextTokenIndex = this.currIdx + 1); }
    subrule(e, t, r, n, a) { this.before(n), this.wrapper.wrapSubrule(e, t, a), this.after(n); }
    before(e) { this.isRecording() || this.elementStack.push(e); }
    after(e) { if (!this.isRecording()) {
        let t = this.elementStack.lastIndexOf(e);
        t >= 0 && this.elementStack.splice(t);
    } }
    get currIdx() { return this.wrapper.currIdx; }
}, xG = { recoveryEnabled: !0, nodeLocationTracking: "full", skipValidations: !0, errorMessageProvider: new Cm }, _S = class extends $D {
    static { s(this, "ChevrotainWrapper"); }
    constructor(e, t) { let r = t && "maxLookahead" in t; super(e, ie(wr(ie({}, xG), { lookaheadStrategy: r ? new tm({ maxLookahead: t.maxLookahead }) : new LG({ logging: t.skipValidations ? () => { } : void 0 }) }), t)); }
    get IS_RECORDING() { return this.RECORDING_PHASE; }
    DEFINE_RULE(e, t, r) { return this.RULE(e, t, r); }
    wrapSelfAnalysis() { this.performSelfAnalysis(); }
    wrapConsume(e, t) { return this.consume(e, t, void 0); }
    wrapSubrule(e, t, r) { return this.subrule(e, t, { ARGS: [r] }); }
    wrapOr(e, t) { this.or(e, t); }
    wrapOption(e, t) { this.option(e, t); }
    wrapMany(e, t) { this.many(e, t); }
    wrapAtLeastOne(e, t) { this.atLeastOne(e, t); }
    rule(e) { return e.call(this, {}); }
}, MG = class extends _S {
    static { s(this, "ProfilerWrapper"); }
    constructor(e, t, r) { super(e, t), this.task = r; }
    rule(e) { this.task.start(), this.task.startSubTask(this.ruleName(e)); try {
        return super.rule(e);
    }
    finally {
        this.task.stopSubTask(this.ruleName(e)), this.task.stop();
    } }
    ruleName(e) { return e.ruleName; }
    subrule(e, t, r) { this.task.startSubTask(this.ruleName(t)); try {
        return super.subrule(e, t, r);
    }
    finally {
        this.task.stopSubTask(this.ruleName(t));
    } }
};
function Iu(e, t, r) { return SS({ parser: t, tokens: r, ruleNames: new Map }, e), t; }
s(Iu, "createParser");
function SS(e, t) { let r = Kl(t, !1), n = le(t.rules).filter(et).filter(i => r.has(i)); for (let i of n) {
    let o = wr(ie({}, e), { consume: 1, optional: 1, subrule: 1, many: 1, or: 1 });
    e.parser.rule(i, Fr(o, i.definition));
} let a = le(t.rules).filter(ja).filter(i => r.has(i)); for (let i of a)
    e.parser.rule(i, wS(e, i)); }
s(SS, "buildRules");
function wS(e, t) { let r = t.call.rule.ref; if (!r)
    throw new Error("Could not resolve reference to infix operator rule: " + t.call.rule.$refText); if (bt(r))
    throw new Error("Cannot use terminal rule in infix expression"); let n = t.operators.precedences.flatMap(g => g.operators), a = { $type: "Group", elements: [] }, i = { $container: a, $type: "Assignment", feature: "parts", operator: "+=", terminal: t.call }, o = { $container: a, $type: "Group", elements: [], cardinality: "*" }; a.elements.push(i, o); let u = { $container: o, $type: "Assignment", feature: "operators", operator: "+=", terminal: { $type: "Alternatives", elements: n } }, c = wr(ie({}, i), { $container: o }); o.elements.push(u, c); let p = n.map(g => e.tokens[g.value]).map((g, v) => ({ ALT: s(() => e.parser.consume(v, g, u), "ALT") })), m; return g => { m ?? (m = Nu(e, r)), e.parser.subrule(0, m, !1, i, g), e.parser.many(0, { DEF: s(() => { e.parser.alternatives(0, p), e.parser.subrule(1, m, !1, c, g); }, "DEF") }); }; }
s(wS, "buildInfixRule");
function Fr(e, t, r = !1) { let n; if (hr(t))
    n = DS(e, t);
else if (Dr(t))
    n = IS(e, t);
else if (mr(t))
    n = Fr(e, t.terminal);
else if (kn(t))
    n = _m(e, t);
else if (yr(t))
    n = NS(e, t);
else if (Dl(t))
    n = kS(e, t);
else if (Fl(t))
    n = OS(e, t);
else if (On(t))
    n = LS(e, t);
else if (Np(t)) {
    let a = e.consume++;
    n = s(() => e.parser.consume(a, Mr, t), "method");
}
else
    throw new jl(t.$cstNode, `Unexpected element type: ${t.$type}`); return Sm(e, r ? void 0 : ws(t), n, t.cardinality); }
s(Fr, "buildElement");
function IS(e, t) { let r = bn(t); return () => e.parser.action(r, t); }
s(IS, "buildAction");
function NS(e, t) { let r = t.rule.ref; if (Pn(r)) {
    let n = e.subrule++, a = et(r) && r.fragment, i = t.arguments.length > 0 ? PS(r, t.arguments) : () => ({}), o;
    return l => { o ?? (o = Nu(e, r)), e.parser.subrule(n, o, a, t, i(l)); };
}
else if (bt(r)) {
    let n = e.consume++, a = Al(e, r.name);
    return () => e.parser.consume(n, a, t);
}
else if (r)
    jr(r);
else
    throw new jl(t.$cstNode, `Undefined rule: ${t.rule.$refText}`); }
s(NS, "buildRuleCall");
function PS(e, t) { if (t.some(n => n.calledByName)) {
    let n = t.map(a => ({ parameterName: a.parameter?.ref?.name, predicate: Nt(a.value) }));
    return a => { let i = {}; for (let { parameterName: o, predicate: l } of n)
        o && (i[o] = l(a)); return i; };
}
else {
    let n = t.map(a => Nt(a.value));
    return a => { let i = {}; for (let o = 0; o < n.length; o++)
        if (o < e.parameters.length) {
            let l = e.parameters[o].name, u = n[o];
            i[l] = u(a);
        } return i; };
} }
s(PS, "buildRuleCallPredicate");
function Nt(e) { if (Ip(e)) {
    let t = Nt(e.left), r = Nt(e.right);
    return n => t(n) || r(n);
}
else if (wp(e)) {
    let t = Nt(e.left), r = Nt(e.right);
    return n => t(n) && r(n);
}
else if (Op(e)) {
    let t = Nt(e.value);
    return r => !t(r);
}
else if (Lp(e)) {
    let t = e.parameter.ref.name;
    return r => r !== void 0 && r[t] === !0;
}
else if (_p(e)) {
    let t = !!e.true;
    return () => t;
} jr(e); }
s(Nt, "buildPredicate");
function kS(e, t) { if (t.elements.length === 1)
    return Fr(e, t.elements[0]); {
    let r = [];
    for (let a of t.elements) {
        let i = { ALT: Fr(e, a, !0) }, o = ws(a);
        o && (i.GATE = Nt(o)), r.push(i);
    }
    let n = e.or++;
    return a => e.parser.alternatives(n, r.map(i => { let o = { ALT: s(() => i.ALT(a), "ALT") }, l = i.GATE; return l && (o.GATE = () => l(a)), o; }));
} }
s(kS, "buildAlternatives");
function OS(e, t) { if (t.elements.length === 1)
    return Fr(e, t.elements[0]); let r = []; for (let l of t.elements) {
    let u = { ALT: Fr(e, l, !0) }, c = ws(l);
    c && (u.GATE = Nt(c)), r.push(u);
} let n = e.or++, a = s((l, u) => { let c = u.getRuleStack().join("-"); return `uGroup_${l}_${c}`; }, "idFunc"), i = s(l => e.parser.alternatives(n, r.map((u, c) => { let f = { ALT: s(() => !0, "ALT") }, p = e.parser; f.ALT = () => { if (u.ALT(l), !p.isRecording()) {
    let g = a(n, p);
    p.unorderedGroups.get(g) || p.unorderedGroups.set(g, []);
    let v = p.unorderedGroups.get(g);
    typeof v?.[c] > "u" && (v[c] = !0);
} }; let m = u.GATE; return m ? f.GATE = () => m(l) : f.GATE = () => !p.unorderedGroups.get(a(n, p))?.[c], f; })), "alternatives"), o = Sm(e, ws(t), i, "*"); return l => { o(l), e.parser.isRecording() || e.parser.unorderedGroups.delete(a(n, e.parser)); }; }
s(OS, "buildUnorderedGroup");
function LS(e, t) { let r = t.elements.map(n => Fr(e, n)); return n => r.forEach(a => a(n)); }
s(LS, "buildGroup");
function ws(e) { if (On(e))
    return e.guardCondition; }
s(ws, "getGuardCondition");
function _m(e, t, r = t.terminal) { if (r)
    if (yr(r) && et(r.rule.ref)) {
        let n = r.rule.ref, a = e.subrule++, i;
        return o => { i ?? (i = Nu(e, n)), e.parser.subrule(a, i, !1, t, o); };
    }
    else if (yr(r) && bt(r.rule.ref)) {
        let n = e.consume++, a = Al(e, r.rule.ref.name);
        return () => e.parser.consume(n, a, t);
    }
    else if (hr(r)) {
        let n = e.consume++, a = Al(e, r.value);
        return () => e.parser.consume(n, a, t);
    }
    else
        throw new Error("Could not build cross reference parser");
else {
    if (!t.type.ref)
        throw new Error("Could not resolve reference to type: " + t.type.$refText);
    let a = Hl(t.type.ref)?.terminal;
    if (!a)
        throw new Error("Could not find name assignment for type: " + bn(t.type.ref));
    return _m(e, t, a);
} }
s(_m, "buildCrossReference");
function DS(e, t) { let r = e.consume++, n = e.tokens[t.value]; if (!n)
    throw new Error("Could not find token for keyword: " + t.value); return () => e.parser.consume(r, n, t); }
s(DS, "buildKeyword");
function Sm(e, t, r, n) { let a = t && Nt(t); if (!n)
    if (a) {
        let i = e.or++;
        return o => e.parser.alternatives(i, [{ ALT: s(() => r(o), "ALT"), GATE: s(() => a(o), "GATE") }, { ALT: Mf(), GATE: s(() => !a(o), "GATE") }]);
    }
    else
        return r; if (n === "*") {
    let i = e.many++;
    return o => e.parser.many(i, { DEF: s(() => r(o), "DEF"), GATE: a ? () => a(o) : void 0 });
}
else if (n === "+") {
    let i = e.many++;
    if (a) {
        let o = e.or++;
        return l => e.parser.alternatives(o, [{ ALT: s(() => e.parser.atLeastOne(i, { DEF: s(() => r(l), "DEF") }), "ALT"), GATE: s(() => a(l), "GATE") }, { ALT: Mf(), GATE: s(() => !a(l), "GATE") }]);
    }
    else
        return o => e.parser.atLeastOne(i, { DEF: s(() => r(o), "DEF") });
}
else if (n === "?") {
    let i = e.optional++;
    return o => e.parser.optional(i, { DEF: s(() => r(o), "DEF"), GATE: a ? () => a(o) : void 0 });
}
else
    jr(n); }
s(Sm, "wrap");
function Nu(e, t) { let r = xS(e, t), n = e.parser.getRule(r); if (!n)
    throw new Error(`Rule "${r}" not found."`); return n; }
s(Nu, "getRule");
function xS(e, t) { if (Pn(t))
    return t.name; if (e.ruleNames.has(t))
    return e.ruleNames.get(t); {
    let r = t, n = r.$container, a = t.$type;
    for (; !et(n);)
        (On(n) || Dl(n) || Fl(n)) && (a = n.elements.indexOf(r).toString() + ":" + a), r = n, n = n.$container;
    return a = n.name + ":" + a, e.ruleNames.set(t, a), a;
} }
s(xS, "getRuleName");
function Al(e, t) { let r = e.tokens[t]; if (!r)
    throw new Error(`Token "${t}" not found."`); return r; }
s(Al, "getToken");
function wm(e) { let t = e.Grammar, r = e.parser.Lexer, n = new CS(e); return Iu(t, n, r.definition), n.finalize(), n; }
s(wm, "createCompletionParser");
function Im(e) { let t = Nm(e); return t.finalize(), t; }
s(Im, "createLangiumParser");
function Nm(e) { let t = e.Grammar, r = e.parser.Lexer, n = new ES(e); return Iu(t, n, r.definition); }
s(Nm, "prepareLangiumParser");
var Pu = class {
    static { s(this, "DefaultTokenBuilder"); }
    constructor() { this.diagnostics = []; }
    buildTokens(e, t) { let r = le(Kl(e, !1)), n = this.buildTerminalTokens(r), a = this.buildKeywordTokens(r, n, t); return a.push(...n), a; }
    flushLexingReport(e) { return { diagnostics: this.popDiagnostics() }; }
    popDiagnostics() { let e = [...this.diagnostics]; return this.diagnostics = [], e; }
    buildTerminalTokens(e) { return e.filter(bt).filter(t => !t.fragment).map(t => this.buildTerminalToken(t)).toArray(); }
    buildTerminalToken(e) { let t = xs(e), r = this.requiresCustomPattern(t) ? this.regexPatternFunction(t) : t, n = { name: e.name, PATTERN: r }; return typeof r == "function" && (n.LINE_BREAKS = !0), e.hidden && (n.GROUP = Bl(t) ? dt.SKIPPED : "hidden"), n; }
    requiresCustomPattern(e) { return !!(e.flags.includes("u") || e.flags.includes("s")); }
    regexPatternFunction(e) { let t = new RegExp(e, e.flags + "y"); return (r, n) => (t.lastIndex = n, t.exec(r)); }
    buildKeywordTokens(e, t, r) { return e.filter(Pn).flatMap(n => Er(n).filter(hr)).distinct(n => n.value).toArray().sort((n, a) => a.value.length - n.value.length).map(n => this.buildKeywordToken(n, t, !!r?.caseInsensitive)); }
    buildKeywordToken(e, t, r) { let n = this.buildKeywordPattern(e, r), a = { name: e.value, PATTERN: n, LONGER_ALT: this.findLongerAlt(e, t) }; return typeof n == "function" && (a.LINE_BREAKS = !0), a; }
    buildKeywordPattern(e, t) { return t ? new RegExp(Xa(e.value), "i") : e.value; }
    findLongerAlt(e, t) { return t.reduce((r, n) => { let a = n?.PATTERN; return a?.source && rd("^" + a.source + "$", e.value) && r.push(n), r; }, []); }
}, Pm = class {
    static { s(this, "DefaultValueConverter"); }
    convert(e, t) { let r = t.grammarSource; if (kn(r) && (r = od(r)), yr(r)) {
        let n = r.rule.ref;
        if (!n)
            throw new Error("This cst node was not parsed by a rule.");
        return this.runConverter(n, e, t);
    } return e; }
    runConverter(e, t, r) { switch (e.name.toUpperCase()) {
        case "INT": return Wt.convertInt(t);
        case "STRING": return Wt.convertString(t);
        case "ID": return Wt.convertID(t);
    } switch (yd(e)?.toLowerCase()) {
        case "number": return Wt.convertNumber(t);
        case "boolean": return Wt.convertBoolean(t);
        case "bigint": return Wt.convertBigint(t);
        case "date": return Wt.convertDate(t);
        default: return t;
    } }
}, Wt;
(function (e) {
    function t(c) { let f = ""; for (let p = 1; p < c.length - 1; p++) {
        let m = c.charAt(p);
        if (m === "\\") {
            let g = c.charAt(++p);
            f += r(g);
        }
        else
            f += m;
    } return f; }
    s(t, "convertString"), e.convertString = t;
    function r(c) {
        switch (c) {
            case "b": return "\b";
            case "f": return "\f";
            case "n": return `
`;
            case "r": return "\r";
            case "t": return "	";
            case "v": return "\v";
            case "0": return "\0";
            default: return c;
        }
    }
    s(r, "convertEscapeCharacter");
    function n(c) { return c.charAt(0) === "^" ? c.substring(1) : c; }
    s(n, "convertID"), e.convertID = n;
    function a(c) { return parseInt(c); }
    s(a, "convertInt"), e.convertInt = a;
    function i(c) { return BigInt(c); }
    s(i, "convertBigint"), e.convertBigint = i;
    function o(c) { return new Date(c); }
    s(o, "convertDate"), e.convertDate = o;
    function l(c) { return Number(c); }
    s(l, "convertNumber"), e.convertNumber = l;
    function u(c) { return c.toLowerCase() === "true"; }
    s(u, "convertBoolean"), e.convertBoolean = u;
})(Wt || (Wt = {}));
var me = {};
Nl(me, yp(kl(), 1));
function ku() { return new Promise(e => { typeof setImmediate > "u" ? setTimeout(e, 0) : setImmediate(e); }); }
s(ku, "delayNextTick");
var xo = 0, MS = 10;
function Ou() { return xo = performance.now(), new me.CancellationTokenSource; }
s(Ou, "startCancelableOperation");
function km(e) { MS = e; }
s(km, "setInterruptionPeriod");
var Ht = Symbol("OperationCancelled");
function Hn(e) { return e === Ht; }
s(Hn, "isOperationCancelled");
function je(e) { return z(this, null, function* () { if (e === me.CancellationToken.None)
    return; let t = performance.now(); if (t - xo >= MS && (xo = t, yield ku(), xo = performance.now()), e.isCancellationRequested)
    throw Ht; }); }
s(je, "interruptAndCheck");
var Rr = class {
    static { s(this, "Deferred"); }
    constructor() { this.promise = new Promise((e, t) => { this.resolve = r => (e(r), this), this.reject = r => (t(r), this); }); }
}, Ey = class qf {
    static { s(this, "FullTextDocument"); }
    constructor(t, r, n, a) { this._uri = t, this._languageId = r, this._version = n, this._content = a, this._lineOffsets = void 0; }
    get uri() { return this._uri; }
    get languageId() { return this._languageId; }
    get version() { return this._version; }
    getText(t) { if (t) {
        let r = this.offsetAt(t.start), n = this.offsetAt(t.end);
        return this._content.substring(r, n);
    } return this._content; }
    update(t, r) { for (let n of t)
        if (qf.isIncremental(n)) {
            let a = Lm(n.range), i = this.offsetAt(a.start), o = this.offsetAt(a.end);
            this._content = this._content.substring(0, i) + n.text + this._content.substring(o, this._content.length);
            let l = Math.max(a.start.line, 0), u = Math.max(a.end.line, 0), c = this._lineOffsets, f = Wf(n.text, !1, i);
            if (u - l === f.length)
                for (let m = 0, g = f.length; m < g; m++)
                    c[m + l + 1] = f[m];
            else
                f.length < 1e4 ? c.splice(l + 1, u - l, ...f) : this._lineOffsets = c = c.slice(0, l + 1).concat(f, c.slice(u + 1));
            let p = n.text.length - (o - i);
            if (p !== 0)
                for (let m = l + 1 + f.length, g = c.length; m < g; m++)
                    c[m] = c[m] + p;
        }
        else if (qf.isFull(n))
            this._content = n.text, this._lineOffsets = void 0;
        else
            throw new Error("Unknown change event received"); this._version = r; }
    getLineOffsets() { return this._lineOffsets === void 0 && (this._lineOffsets = Wf(this._content, !0)), this._lineOffsets; }
    positionAt(t) { t = Math.max(Math.min(t, this._content.length), 0); let r = this.getLineOffsets(), n = 0, a = r.length; if (a === 0)
        return { line: 0, character: t }; for (; n < a;) {
        let o = Math.floor((n + a) / 2);
        r[o] > t ? a = o : n = o + 1;
    } let i = n - 1; return t = this.ensureBeforeEOL(t, r[i]), { line: i, character: t - r[i] }; }
    offsetAt(t) { let r = this.getLineOffsets(); if (t.line >= r.length)
        return this._content.length; if (t.line < 0)
        return 0; let n = r[t.line]; if (t.character <= 0)
        return n; let a = t.line + 1 < r.length ? r[t.line + 1] : this._content.length, i = Math.min(n + t.character, a); return this.ensureBeforeEOL(i, n); }
    ensureBeforeEOL(t, r) { for (; t > r && Om(this._content.charCodeAt(t - 1));)
        t--; return t; }
    get lineCount() { return this.getLineOffsets().length; }
    static isIncremental(t) { let r = t; return r != null && typeof r.text == "string" && r.range !== void 0 && (r.rangeLength === void 0 || typeof r.rangeLength == "number"); }
    static isFull(t) { let r = t; return r != null && typeof r.text == "string" && r.range === void 0 && r.rangeLength === void 0; }
}, El;
(function (e) { function t(a, i, o, l) { return new Ey(a, i, o, l); } s(t, "create"), e.create = t; function r(a, i, o) { if (a instanceof Ey)
    return a.update(i, o), a; throw new Error("TextDocument.update: document must be created by TextDocument.create"); } s(r, "update"), e.update = r; function n(a, i) { let o = a.getText(), l = bl(i.map(GS), (f, p) => { let m = f.range.start.line - p.range.start.line; return m === 0 ? f.range.start.character - p.range.start.character : m; }), u = 0, c = []; for (let f of l) {
    let p = a.offsetAt(f.range.start);
    if (p < u)
        throw new Error("Overlapping edit");
    p > u && c.push(o.substring(u, p)), f.newText.length && c.push(f.newText), u = a.offsetAt(f.range.end);
} return c.push(o.substr(u)), c.join(""); } s(n, "applyEdits"), e.applyEdits = n; })(El || (El = {}));
function bl(e, t) { if (e.length <= 1)
    return e; let r = e.length / 2 | 0, n = e.slice(0, r), a = e.slice(r); bl(n, t), bl(a, t); let i = 0, o = 0, l = 0; for (; i < n.length && o < a.length;)
    t(n[i], a[o]) <= 0 ? e[l++] = n[i++] : e[l++] = a[o++]; for (; i < n.length;)
    e[l++] = n[i++]; for (; o < a.length;)
    e[l++] = a[o++]; return e; }
s(bl, "mergeSort");
function Wf(e, t, r = 0) { let n = t ? [r] : []; for (let a = 0; a < e.length; a++) {
    let i = e.charCodeAt(a);
    Om(i) && (i === 13 && a + 1 < e.length && e.charCodeAt(a + 1) === 10 && a++, n.push(r + a + 1));
} return n; }
s(Wf, "computeLineOffsets");
function Om(e) { return e === 13 || e === 10; }
s(Om, "isEOL");
function Lm(e) { let t = e.start, r = e.end; return t.line > r.line || t.line === r.line && t.character > r.character ? { start: r, end: t } : e; }
s(Lm, "getWellformedRange");
function GS(e) { let t = Lm(e.range); return t !== e.range ? { newText: e.newText, range: t } : e; }
s(GS, "getWellformedEdit");
var FS;
(() => {
    "use strict";
    var e = { 975: k => { function b(T) { if (typeof T != "string")
            throw new TypeError("Path must be a string. Received " + JSON.stringify(T)); } s(b, "e"); function y(T, $) { for (var C, O = "", x = 0, D = -1, U = 0, G = 0; G <= T.length; ++G) {
            if (G < T.length)
                C = T.charCodeAt(G);
            else {
                if (C === 47)
                    break;
                C = 47;
            }
            if (C === 47) {
                if (!(D === G - 1 || U === 1))
                    if (D !== G - 1 && U === 2) {
                        if (O.length < 2 || x !== 2 || O.charCodeAt(O.length - 1) !== 46 || O.charCodeAt(O.length - 2) !== 46) {
                            if (O.length > 2) {
                                var ue = O.lastIndexOf("/");
                                if (ue !== O.length - 1) {
                                    ue === -1 ? (O = "", x = 0) : x = (O = O.slice(0, ue)).length - 1 - O.lastIndexOf("/"), D = G, U = 0;
                                    continue;
                                }
                            }
                            else if (O.length === 2 || O.length === 1) {
                                O = "", x = 0, D = G, U = 0;
                                continue;
                            }
                        }
                        $ && (O.length > 0 ? O += "/.." : O = "..", x = 2);
                    }
                    else
                        O.length > 0 ? O += "/" + T.slice(D + 1, G) : O = T.slice(D + 1, G), x = G - D - 1;
                D = G, U = 0;
            }
            else
                C === 46 && U !== -1 ? ++U : U = -1;
        } return O; } s(y, "r"); var A = { resolve: s(function () { for (var T, $ = "", C = !1, O = arguments.length - 1; O >= -1 && !C; O--) {
                var x;
                O >= 0 ? x = arguments[O] : (T === void 0 && (T = process.cwd()), x = T), b(x), x.length !== 0 && ($ = x + "/" + $, C = x.charCodeAt(0) === 47);
            } return $ = y($, !C), C ? $.length > 0 ? "/" + $ : "/" : $.length > 0 ? $ : "."; }, "resolve"), normalize: s(function (T) { if (b(T), T.length === 0)
                return "."; var $ = T.charCodeAt(0) === 47, C = T.charCodeAt(T.length - 1) === 47; return (T = y(T, !$)).length !== 0 || $ || (T = "."), T.length > 0 && C && (T += "/"), $ ? "/" + T : T; }, "normalize"), isAbsolute: s(function (T) { return b(T), T.length > 0 && T.charCodeAt(0) === 47; }, "isAbsolute"), join: s(function () { if (arguments.length === 0)
                return "."; for (var T, $ = 0; $ < arguments.length; ++$) {
                var C = arguments[$];
                b(C), C.length > 0 && (T === void 0 ? T = C : T += "/" + C);
            } return T === void 0 ? "." : A.normalize(T); }, "join"), relative: s(function (T, $) { if (b(T), b($), T === $ || (T = A.resolve(T)) === ($ = A.resolve($)))
                return ""; for (var C = 1; C < T.length && T.charCodeAt(C) === 47; ++C)
                ; for (var O = T.length, x = O - C, D = 1; D < $.length && $.charCodeAt(D) === 47; ++D)
                ; for (var U = $.length - D, G = x < U ? x : U, ue = -1, q = 0; q <= G; ++q) {
                if (q === G) {
                    if (U > G) {
                        if ($.charCodeAt(D + q) === 47)
                            return $.slice(D + q + 1);
                        if (q === 0)
                            return $.slice(D + q);
                    }
                    else
                        x > G && (T.charCodeAt(C + q) === 47 ? ue = q : q === 0 && (ue = 0));
                    break;
                }
                var se = T.charCodeAt(C + q);
                if (se !== $.charCodeAt(D + q))
                    break;
                se === 47 && (ue = q);
            } var Be = ""; for (q = C + ue + 1; q <= O; ++q)
                q !== O && T.charCodeAt(q) !== 47 || (Be.length === 0 ? Be += ".." : Be += "/.."); return Be.length > 0 ? Be + $.slice(D + ue) : (D += ue, $.charCodeAt(D) === 47 && ++D, $.slice(D)); }, "relative"), _makeLong: s(function (T) { return T; }, "_makeLong"), dirname: s(function (T) { if (b(T), T.length === 0)
                return "."; for (var $ = T.charCodeAt(0), C = $ === 47, O = -1, x = !0, D = T.length - 1; D >= 1; --D)
                if (($ = T.charCodeAt(D)) === 47) {
                    if (!x) {
                        O = D;
                        break;
                    }
                }
                else
                    x = !1; return O === -1 ? C ? "/" : "." : C && O === 1 ? "//" : T.slice(0, O); }, "dirname"), basename: s(function (T, $) { if ($ !== void 0 && typeof $ != "string")
                throw new TypeError('"ext" argument must be a string'); b(T); var C, O = 0, x = -1, D = !0; if ($ !== void 0 && $.length > 0 && $.length <= T.length) {
                if ($.length === T.length && $ === T)
                    return "";
                var U = $.length - 1, G = -1;
                for (C = T.length - 1; C >= 0; --C) {
                    var ue = T.charCodeAt(C);
                    if (ue === 47) {
                        if (!D) {
                            O = C + 1;
                            break;
                        }
                    }
                    else
                        G === -1 && (D = !1, G = C + 1), U >= 0 && (ue === $.charCodeAt(U) ? --U == -1 && (x = C) : (U = -1, x = G));
                }
                return O === x ? x = G : x === -1 && (x = T.length), T.slice(O, x);
            } for (C = T.length - 1; C >= 0; --C)
                if (T.charCodeAt(C) === 47) {
                    if (!D) {
                        O = C + 1;
                        break;
                    }
                }
                else
                    x === -1 && (D = !1, x = C + 1); return x === -1 ? "" : T.slice(O, x); }, "basename"), extname: s(function (T) { b(T); for (var $ = -1, C = 0, O = -1, x = !0, D = 0, U = T.length - 1; U >= 0; --U) {
                var G = T.charCodeAt(U);
                if (G !== 47)
                    O === -1 && (x = !1, O = U + 1), G === 46 ? $ === -1 ? $ = U : D !== 1 && (D = 1) : $ !== -1 && (D = -1);
                else if (!x) {
                    C = U + 1;
                    break;
                }
            } return $ === -1 || O === -1 || D === 0 || D === 1 && $ === O - 1 && $ === C + 1 ? "" : T.slice($, O); }, "extname"), format: s(function (T) { if (T === null || typeof T != "object")
                throw new TypeError('The "pathObject" argument must be of type Object. Received type ' + typeof T); return (function ($, C) { var O = C.dir || C.root, x = C.base || (C.name || "") + (C.ext || ""); return O ? O === C.root ? O + x : O + "/" + x : x; })(0, T); }, "format"), parse: s(function (T) { b(T); var $ = { root: "", dir: "", base: "", ext: "", name: "" }; if (T.length === 0)
                return $; var C, O = T.charCodeAt(0), x = O === 47; x ? ($.root = "/", C = 1) : C = 0; for (var D = -1, U = 0, G = -1, ue = !0, q = T.length - 1, se = 0; q >= C; --q)
                if ((O = T.charCodeAt(q)) !== 47)
                    G === -1 && (ue = !1, G = q + 1), O === 46 ? D === -1 ? D = q : se !== 1 && (se = 1) : D !== -1 && (se = -1);
                else if (!ue) {
                    U = q + 1;
                    break;
                } return D === -1 || G === -1 || se === 0 || se === 1 && D === G - 1 && D === U + 1 ? G !== -1 && ($.base = $.name = U === 0 && x ? T.slice(1, G) : T.slice(U, G)) : (U === 0 && x ? ($.name = T.slice(1, D), $.base = T.slice(1, G)) : ($.name = T.slice(U, D), $.base = T.slice(U, G)), $.ext = T.slice(D, G)), U > 0 ? $.dir = T.slice(0, U - 1) : x && ($.dir = "/"), $; }, "parse"), sep: "/", delimiter: ":", win32: null, posix: null }; A.posix = A, k.exports = A; } }, t = {};
    function r(k) { var b = t[k]; if (b !== void 0)
        return b.exports; var y = t[k] = { exports: {} }; return e[k](y, y.exports, r), y.exports; }
    s(r, "r"), r.d = (k, b) => { for (var y in b)
        r.o(b, y) && !r.o(k, y) && Object.defineProperty(k, y, { enumerable: !0, get: b[y] }); }, r.o = (k, b) => Object.prototype.hasOwnProperty.call(k, b), r.r = k => { typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(k, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(k, "__esModule", { value: !0 }); };
    var n = {};
    let a;
    r.r(n), r.d(n, { URI: s(() => m, "URI"), Utils: s(() => pe, "Utils") }), typeof process == "object" ? a = process.platform === "win32" : typeof navigator == "object" && (a = navigator.userAgent.indexOf("Windows") >= 0);
    let i = /^\w[\w\d+.-]*$/, o = /^\//, l = /^\/\//;
    function u(k, b) { if (!k.scheme && b)
        throw new Error(`[UriError]: Scheme is missing: {scheme: "", authority: "${k.authority}", path: "${k.path}", query: "${k.query}", fragment: "${k.fragment}"}`); if (k.scheme && !i.test(k.scheme))
        throw new Error("[UriError]: Scheme contains illegal characters."); if (k.path) {
        if (k.authority) {
            if (!o.test(k.path))
                throw new Error('[UriError]: If a URI contains an authority component, then the path component must either be empty or begin with a slash ("/") character');
        }
        else if (l.test(k.path))
            throw new Error('[UriError]: If a URI does not contain an authority component, then the path cannot begin with two slash characters ("//")');
    } }
    s(u, "a");
    let c = "", f = "/", p = /^(([^:/?#]+?):)?(\/\/([^/?#]*))?([^?#]*)(\?([^#]*))?(#(.*))?/;
    class m {
        static { s(this, "l"); }
        static isUri(b) { return b instanceof m || !!b && typeof b.authority == "string" && typeof b.fragment == "string" && typeof b.path == "string" && typeof b.query == "string" && typeof b.scheme == "string" && typeof b.fsPath == "string" && typeof b.with == "function" && typeof b.toString == "function"; }
        scheme;
        authority;
        path;
        query;
        fragment;
        constructor(b, y, A, T, $, C = !1) { typeof b == "object" ? (this.scheme = b.scheme || c, this.authority = b.authority || c, this.path = b.path || c, this.query = b.query || c, this.fragment = b.fragment || c) : (this.scheme = (function (O, x) { return O || x ? O : "file"; })(b, C), this.authority = y || c, this.path = (function (O, x) { switch (O) {
            case "https":
            case "http":
            case "file": x ? x[0] !== f && (x = f + x) : x = f;
        } return x; })(this.scheme, A || c), this.query = T || c, this.fragment = $ || c, u(this, C)); }
        get fsPath() { return S(this, !1); }
        with(b) { if (!b)
            return this; let { scheme: y, authority: A, path: T, query: $, fragment: C } = b; return y === void 0 ? y = this.scheme : y === null && (y = c), A === void 0 ? A = this.authority : A === null && (A = c), T === void 0 ? T = this.path : T === null && (T = c), $ === void 0 ? $ = this.query : $ === null && ($ = c), C === void 0 ? C = this.fragment : C === null && (C = c), y === this.scheme && A === this.authority && T === this.path && $ === this.query && C === this.fragment ? this : new v(y, A, T, $, C); }
        static parse(b, y = !1) { let A = p.exec(b); return A ? new v(A[2] || c, Q(A[4] || c), Q(A[5] || c), Q(A[7] || c), Q(A[9] || c), y) : new v(c, c, c, c, c); }
        static file(b) { let y = c; if (a && (b = b.replace(/\\/g, f)), b[0] === f && b[1] === f) {
            let A = b.indexOf(f, 2);
            A === -1 ? (y = b.substring(2), b = f) : (y = b.substring(2, A), b = b.substring(A) || f);
        } return new v("file", y, b, c, c); }
        static from(b) { let y = new v(b.scheme, b.authority, b.path, b.query, b.fragment); return u(y, !0), y; }
        toString(b = !1) { return E(this, b); }
        toJSON() { return this; }
        static revive(b) { if (b) {
            if (b instanceof m)
                return b;
            {
                let y = new v(b);
                return y._formatted = b.external, y._fsPath = b._sep === g ? b.fsPath : null, y;
            }
        } return b; }
    }
    let g = a ? 1 : void 0;
    class v extends m {
        static { s(this, "d"); }
        _formatted = null;
        _fsPath = null;
        get fsPath() { return this._fsPath || (this._fsPath = S(this, !1)), this._fsPath; }
        toString(b = !1) { return b ? E(this, !0) : (this._formatted || (this._formatted = E(this, !1)), this._formatted); }
        toJSON() { let b = { $mid: 1 }; return this._fsPath && (b.fsPath = this._fsPath, b._sep = g), this._formatted && (b.external = this._formatted), this.path && (b.path = this.path), this.scheme && (b.scheme = this.scheme), this.authority && (b.authority = this.authority), this.query && (b.query = this.query), this.fragment && (b.fragment = this.fragment), b; }
    }
    let _ = { 58: "%3A", 47: "%2F", 63: "%3F", 35: "%23", 91: "%5B", 93: "%5D", 64: "%40", 33: "%21", 36: "%24", 38: "%26", 39: "%27", 40: "%28", 41: "%29", 42: "%2A", 43: "%2B", 44: "%2C", 59: "%3B", 61: "%3D", 32: "%20" };
    function N(k, b, y) { let A, T = -1; for (let $ = 0; $ < k.length; $++) {
        let C = k.charCodeAt($);
        if (C >= 97 && C <= 122 || C >= 65 && C <= 90 || C >= 48 && C <= 57 || C === 45 || C === 46 || C === 95 || C === 126 || b && C === 47 || y && C === 91 || y && C === 93 || y && C === 58)
            T !== -1 && (A += encodeURIComponent(k.substring(T, $)), T = -1), A !== void 0 && (A += k.charAt($));
        else {
            A === void 0 && (A = k.substr(0, $));
            let O = _[C];
            O !== void 0 ? (T !== -1 && (A += encodeURIComponent(k.substring(T, $)), T = -1), A += O) : T === -1 && (T = $);
        }
    } return T !== -1 && (A += encodeURIComponent(k.substring(T))), A !== void 0 ? A : k; }
    s(N, "m");
    function w(k) { let b; for (let y = 0; y < k.length; y++) {
        let A = k.charCodeAt(y);
        A === 35 || A === 63 ? (b === void 0 && (b = k.substr(0, y)), b += _[A]) : b !== void 0 && (b += k[y]);
    } return b !== void 0 ? b : k; }
    s(w, "y");
    function S(k, b) { let y; return y = k.authority && k.path.length > 1 && k.scheme === "file" ? `//${k.authority}${k.path}` : k.path.charCodeAt(0) === 47 && (k.path.charCodeAt(1) >= 65 && k.path.charCodeAt(1) <= 90 || k.path.charCodeAt(1) >= 97 && k.path.charCodeAt(1) <= 122) && k.path.charCodeAt(2) === 58 ? b ? k.path.substr(1) : k.path[1].toLowerCase() + k.path.substr(2) : k.path, a && (y = y.replace(/\//g, "\\")), y; }
    s(S, "v");
    function E(k, b) { let y = b ? w : N, A = "", { scheme: T, authority: $, path: C, query: O, fragment: x } = k; if (T && (A += T, A += ":"), ($ || T === "file") && (A += f, A += f), $) {
        let D = $.indexOf("@");
        if (D !== -1) {
            let U = $.substr(0, D);
            $ = $.substr(D + 1), D = U.lastIndexOf(":"), D === -1 ? A += y(U, !1, !1) : (A += y(U.substr(0, D), !1, !1), A += ":", A += y(U.substr(D + 1), !1, !0)), A += "@";
        }
        $ = $.toLowerCase(), D = $.lastIndexOf(":"), D === -1 ? A += y($, !1, !0) : (A += y($.substr(0, D), !1, !0), A += $.substr(D));
    } if (C) {
        if (C.length >= 3 && C.charCodeAt(0) === 47 && C.charCodeAt(2) === 58) {
            let D = C.charCodeAt(1);
            D >= 65 && D <= 90 && (C = `/${String.fromCharCode(D + 32)}:${C.substr(3)}`);
        }
        else if (C.length >= 2 && C.charCodeAt(1) === 58) {
            let D = C.charCodeAt(0);
            D >= 65 && D <= 90 && (C = `${String.fromCharCode(D + 32)}:${C.substr(2)}`);
        }
        A += y(C, !0, !1);
    } return O && (A += "?", A += y(O, !1, !1)), x && (A += "#", A += b ? x : N(x, !1, !1)), A; }
    s(E, "b");
    function I(k) { try {
        return decodeURIComponent(k);
    }
    catch {
        return k.length > 3 ? k.substr(0, 3) + I(k.substr(3)) : k;
    } }
    s(I, "C");
    let j = /(%[0-9A-Za-z][0-9A-Za-z])+/g;
    function Q(k) { return k.match(j) ? k.replace(j, b => I(b)) : k; }
    s(Q, "w");
    var X = r(975);
    let fe = X.posix || X, ye = "/";
    var pe;
    (function (k) { k.joinPath = function (b, ...y) { return b.with({ path: fe.join(b.path, ...y) }); }, k.resolvePath = function (b, ...y) { let A = b.path, T = !1; A[0] !== ye && (A = ye + A, T = !0); let $ = fe.resolve(A, ...y); return T && $[0] === ye && !b.authority && ($ = $.substring(1)), b.with({ path: $ }); }, k.dirname = function (b) { if (b.path.length === 0 || b.path === ye)
        return b; let y = fe.dirname(b.path); return y.length === 1 && y.charCodeAt(0) === 46 && (y = ""), b.with({ path: y }); }, k.basename = function (b) { return fe.basename(b.path); }, k.extname = function (b) { return fe.extname(b.path); }; })(pe || (pe = {})), FS = n;
})();
var { URI: mt, Utils: wi } = FS, Qe;
(function (e) { e.basename = wi.basename, e.dirname = wi.dirname, e.extname = wi.extname, e.joinPath = wi.joinPath, e.resolvePath = wi.resolvePath; let t = typeof process == "object" && process?.platform === "win32"; function r(o, l) { return o?.toString() === l?.toString(); } s(r, "equals"), e.equals = r; function n(o, l) { let u = typeof o == "string" ? mt.parse(o).path : o.path, c = typeof l == "string" ? mt.parse(l).path : l.path, f = u.split("/").filter(_ => _.length > 0), p = c.split("/").filter(_ => _.length > 0); if (t) {
    let _ = /^[A-Z]:$/;
    if (f[0] && _.test(f[0]) && (f[0] = f[0].toLowerCase()), p[0] && _.test(p[0]) && (p[0] = p[0].toLowerCase()), f[0] !== p[0])
        return c.substring(1);
} let m = 0; for (; m < f.length && f[m] === p[m]; m++)
    ; let g = "../".repeat(f.length - m), v = p.slice(m).join("/"); return g + v; } s(n, "relative"), e.relative = n; function a(o) { return mt.parse(o.toString()).toString(); } s(a, "normalize"), e.normalize = a; function i(o, l) { let u = typeof o == "string" ? o : o.path, c = typeof l == "string" ? l : l.path; return c.charAt(c.length - 1) === "/" && (c = c.slice(0, -1)), u.charAt(u.length - 1) === "/" && (u = u.slice(0, -1)), c === u ? !0 : c.length < u.length || c.charAt(u.length) !== "/" ? !1 : c.startsWith(u); } s(i, "contains"), e.contains = i; })(Qe || (Qe = {}));
var Dm = class {
    static { s(this, "UriTrie"); }
    constructor() { this.root = { name: "", children: new Map }; }
    normalizeUri(e) { return Qe.normalize(e); }
    clear() { this.root.children.clear(); }
    insert(e, t) { let r = this.getNode(this.normalizeUri(e), !0); r.element = t; }
    delete(e) { let t = this.getNode(this.normalizeUri(e), !1); t?.parent && t.parent.children.delete(t.name); }
    has(e) { return this.getNode(this.normalizeUri(e), !1)?.element !== void 0; }
    hasNode(e) { return this.getNode(this.normalizeUri(e), !1) !== void 0; }
    find(e) { return this.getNode(this.normalizeUri(e), !1)?.element; }
    findNode(e) { let t = this.normalizeUri(e), r = this.getNode(t, !1); if (r)
        return { name: r.name, uri: Qe.joinPath(mt.parse(t), r.name).toString(), element: r.element }; }
    findChildren(e) { let t = this.normalizeUri(e), r = this.getNode(t, !1); return r ? Array.from(r.children.values()).map(n => ({ name: n.name, uri: Qe.joinPath(mt.parse(t), n.name).toString(), element: n.element })) : []; }
    all() { return this.collectValues(this.root); }
    findAll(e) { let t = this.getNode(Qe.normalize(e), !1); return t ? this.collectValues(t) : []; }
    getNode(e, t) { let r = e.split("/"); e.charAt(e.length - 1) === "/" && r.pop(); let n = this.root; for (let a of r) {
        let i = n.children.get(a);
        if (!i)
            if (t)
                i = { name: a, children: new Map, parent: n }, n.children.set(a, i);
            else
                return;
        n = i;
    } return n; }
    collectValues(e) { let t = []; e.element && t.push(e.element); for (let r of e.children.values())
        t.push(...this.collectValues(r)); return t; }
}, J = (function (e) { return e[e.Changed = 0] = "Changed", e[e.Parsed = 1] = "Parsed", e[e.IndexedContent = 2] = "IndexedContent", e[e.ComputedScopes = 3] = "ComputedScopes", e[e.Linked = 4] = "Linked", e[e.IndexedReferences = 5] = "IndexedReferences", e[e.Validated = 6] = "Validated", e; })(J || {}), zS = class {
    static { s(this, "DefaultLangiumDocumentFactory"); }
    constructor(e) { this.serviceRegistry = e.ServiceRegistry, this.textDocuments = e.workspace.TextDocuments, this.fileSystemProvider = e.workspace.FileSystemProvider; }
    fromUri(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let n = yield this.fileSystemProvider.readFile(e); return this.createAsync(e, n, t); }); }
    fromTextDocument(e, t, r) { return t = t ?? mt.parse(e.uri), me.CancellationToken.is(r) ? this.createAsync(t, e, r) : this.create(t, e, r); }
    fromString(e, t, r) { return me.CancellationToken.is(r) ? this.createAsync(t, e, r) : this.create(t, e, r); }
    fromModel(e, t) { return this.create(t, { $model: e }); }
    create(e, t, r) { if (typeof t == "string") {
        let n = this.parse(e, t, r);
        return this.createLangiumDocument(n, e, void 0, t);
    }
    else if ("$model" in t) {
        let n = { value: t.$model, parserErrors: [], lexerErrors: [] };
        return this.createLangiumDocument(n, e);
    }
    else {
        let n = this.parse(e, t.getText(), r);
        return this.createLangiumDocument(n, e, t);
    } }
    createAsync(e, t, r) { return z(this, null, function* () { if (typeof t == "string") {
        let n = yield this.parseAsync(e, t, r);
        return this.createLangiumDocument(n, e, void 0, t);
    }
    else {
        let n = yield this.parseAsync(e, t.getText(), r);
        return this.createLangiumDocument(n, e, t);
    } }); }
    createLangiumDocument(e, t, r, n) { let a; if (r)
        a = { parseResult: e, uri: t, state: J.Parsed, references: [], textDocument: r };
    else {
        let i = this.createTextDocumentGetter(t, n);
        a = { parseResult: e, uri: t, state: J.Parsed, references: [], get textDocument() { return i(); } };
    } return e.value.$document = a, a; }
    update(e, t) { return z(this, null, function* () { let r = e.parseResult.value.$cstNode?.root.fullText, n = this.textDocuments?.get(e.uri.toString()), a = n ? n.getText() : yield this.fileSystemProvider.readFile(e.uri); if (n)
        Object.defineProperty(e, "textDocument", { value: n });
    else {
        let i = this.createTextDocumentGetter(e.uri, a);
        Object.defineProperty(e, "textDocument", { get: i });
    } return r !== a && (e.parseResult = yield this.parseAsync(e.uri, a, t), e.parseResult.value.$document = e), e.state = J.Parsed, e; }); }
    parse(e, t, r) { return this.serviceRegistry.getServices(e).parser.LangiumParser.parse(t, r); }
    parseAsync(e, t, r) { return this.serviceRegistry.getServices(e).parser.AsyncParser.parse(t, r); }
    createTextDocumentGetter(e, t) { let r = this.serviceRegistry, n; return () => n ?? (n = El.create(e.toString(), r.getServices(e).LanguageMetaData.languageId, 0, t ?? "")); }
}, jS = class {
    static { s(this, "DefaultLangiumDocuments"); }
    constructor(e) { this.documentTrie = new Dm, this.services = e, this.langiumDocumentFactory = e.workspace.LangiumDocumentFactory, this.documentBuilder = () => e.workspace.DocumentBuilder; }
    get all() { return le(this.documentTrie.all()); }
    addDocument(e) { let t = e.uri.toString(); if (this.documentTrie.has(t))
        throw new Error(`A document with the URI '${t}' is already present.`); this.documentTrie.insert(t, e); }
    getDocument(e) { let t = e.toString(); return this.documentTrie.find(t); }
    getDocuments(e) { let t = e.toString(); return this.documentTrie.findAll(t); }
    getOrCreateDocument(e, t) { return z(this, null, function* () { let r = this.getDocument(e); return r || (r = yield this.langiumDocumentFactory.fromUri(e, t), this.addDocument(r), r); }); }
    createDocument(e, t, r) { if (r)
        return this.langiumDocumentFactory.fromString(t, e, r).then(n => (this.addDocument(n), n)); {
        let n = this.langiumDocumentFactory.fromString(t, e);
        return this.addDocument(n), n;
    } }
    hasDocument(e) { return this.documentTrie.has(e.toString()); }
    invalidateDocument(e) { let t = e.toString(), r = this.documentTrie.find(t); return r && this.documentBuilder().resetToState(r, J.Changed), r; }
    deleteDocument(e) { let t = e.toString(), r = this.documentTrie.find(t); return r && (r.state = J.Changed, this.documentTrie.delete(t)), r; }
    deleteDocuments(e) { let t = e.toString(), r = this.documentTrie.findAll(t); for (let n of r)
        n.state = J.Changed; return this.documentTrie.delete(t), r; }
}, rn = Symbol("RefResolving"), US = class {
    static { s(this, "DefaultLinker"); }
    constructor(e) { this.reflection = e.shared.AstReflection, this.langiumDocuments = () => e.shared.workspace.LangiumDocuments, this.scopeProvider = e.references.ScopeProvider, this.astNodeLocator = e.workspace.AstNodeLocator, this.profiler = e.shared.profilers.LangiumProfiler, this.languageId = e.LanguageMetaData.languageId; }
    link(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { if (this.profiler?.isActive("linking")) {
        let n = this.profiler.createTask("linking", this.languageId);
        n.start();
        try {
            for (let a of Ot(e.parseResult.value))
                yield je(t), za(a).forEach(i => { let o = `${a.$type}:${i.property}`; n.startSubTask(o); try {
                    this.doLink(i, e);
                }
                finally {
                    n.stopSubTask(o);
                } });
        }
        finally {
            n.stop();
        }
    }
    else
        for (let n of Ot(e.parseResult.value))
            yield je(t), za(n).forEach(a => this.doLink(a, e)); }); }
    doLink(e, t) { let r = e.reference; if ("_ref" in r && r._ref === void 0) {
        r._ref = rn;
        try {
            let n = this.getCandidate(e);
            if (on(n))
                r._ref = n;
            else {
                r._nodeDescription = n;
                let a = this.loadAstNode(n);
                r._ref = a ?? this.createLinkingError(e, n);
            }
        }
        catch (n) {
            console.error(`An error occurred while resolving reference to '${r.$refText}':`, n);
            let a = n.message ?? String(n);
            r._ref = { info: e, message: `An error occurred while resolving reference to '${r.$refText}': ${a}` };
        }
        t.references.push(r);
    }
    else if ("_items" in r && r._items === void 0) {
        r._items = rn;
        try {
            let n = this.getCandidates(e), a = [];
            if (on(n))
                r._linkingError = n;
            else
                for (let i of n) {
                    let o = this.loadAstNode(i);
                    o && a.push({ ref: o, $nodeDescription: i });
                }
            r._items = a;
        }
        catch (n) {
            r._linkingError = { info: e, message: `An error occurred while resolving reference to '${r.$refText}': ${n}` }, r._items = [];
        }
        t.references.push(r);
    } }
    unlink(e) { for (let t of e.references)
        "_ref" in t ? (t._ref = void 0, delete t._nodeDescription) : "_items" in t && (t._items = void 0, delete t._linkingError); e.references = []; }
    getCandidate(e) { return this.scopeProvider.getScope(e).getElement(e.reference.$refText) ?? this.createLinkingError(e); }
    getCandidates(e) { let r = this.scopeProvider.getScope(e).getElements(e.reference.$refText).distinct(n => `${n.documentUri}#${n.path}`).toArray(); return r.length > 0 ? r : this.createLinkingError(e); }
    buildReference(e, t, r, n) { let a = this, i = { $refNode: r, $refText: n, _ref: void 0, get ref() { if (De(this._ref))
            return this._ref; if ($p(this._nodeDescription)) {
            let o = a.loadAstNode(this._nodeDescription);
            this._ref = o ?? a.createLinkingError({ reference: i, container: e, property: t }, this._nodeDescription);
        }
        else if (this._ref === void 0) {
            this._ref = rn;
            let o = Oa(e).$document, l = a.getLinkedNode({ reference: i, container: e, property: t });
            if (l.error && o && o.state < J.ComputedScopes)
                return this._ref = void 0;
            this._ref = l.node ?? l.error, this._nodeDescription = l.descr, o?.references.push(this);
        }
        else
            this._ref === rn && a.throwCyclicReferenceError(e, t, n); return De(this._ref) ? this._ref : void 0; }, get $nodeDescription() { return this._nodeDescription; }, get error() { return on(this._ref) ? this._ref : void 0; } }; return i; }
    buildMultiReference(e, t, r, n) { let a = this, i = { $refNode: r, $refText: n, _items: void 0, get items() { if (Array.isArray(this._items))
            return this._items; if (this._items === void 0) {
            this._items = rn;
            let o = Oa(e).$document, l = a.getCandidates({ reference: i, container: e, property: t }), u = [];
            if (on(l))
                this._linkingError = l;
            else
                for (let c of l) {
                    let f = a.loadAstNode(c);
                    f && u.push({ ref: f, $nodeDescription: c });
                }
            this._items = u, o?.references.push(this);
        }
        else
            this._items === rn && a.throwCyclicReferenceError(e, t, n); return Array.isArray(this._items) ? this._items : []; }, get error() { if (this._linkingError)
            return this._linkingError; if (!(this.items.length > 0))
            return this._linkingError = a.createLinkingError({ reference: i, container: e, property: t }); } }; return i; }
    throwCyclicReferenceError(e, t, r) { throw new Error(`Cyclic reference resolution detected: ${this.astNodeLocator.getAstNodePath(e)}/${t} (symbol '${r}')`); }
    getLinkedNode(e) { try {
        let t = this.getCandidate(e);
        if (on(t))
            return { error: t };
        let r = this.loadAstNode(t);
        return r ? { node: r, descr: t } : { descr: t, error: this.createLinkingError(e, t) };
    }
    catch (t) {
        console.error(`An error occurred while resolving reference to '${e.reference.$refText}':`, t);
        let r = t.message ?? String(t);
        return { error: { info: e, message: `An error occurred while resolving reference to '${e.reference.$refText}': ${r}` } };
    } }
    loadAstNode(e) { if (e.node)
        return e.node; let t = this.langiumDocuments().getDocument(e.documentUri); if (t)
        return this.astNodeLocator.getAstNode(t.parseResult.value, e.path); }
    createLinkingError(e, t) { let r = Oa(e.container).$document; r && r.state < J.ComputedScopes && console.warn(`Attempted reference resolution before document reached ComputedScopes state (${r.uri}).`); let n = this.reflection.getReferenceType(e); return { info: e, message: `Could not resolve reference to ${n} named '${e.reference.$refText}'.`, targetDescription: t }; }
};
function xm(e) { return typeof e.name == "string"; }
s(xm, "isNamed");
var BS = class {
    static { s(this, "DefaultNameProvider"); }
    getName(e) { if (xm(e))
        return e.name; }
    getNameNode(e) { return ql(e.$cstNode, "name"); }
}, KS = class {
    static { s(this, "DefaultReferences"); }
    constructor(e) { this.nameProvider = e.references.NameProvider, this.index = e.shared.workspace.IndexManager, this.nodeLocator = e.workspace.AstNodeLocator, this.documents = e.shared.workspace.LangiumDocuments, this.hasMultiReference = Ot(e.Grammar).some(t => kn(t) && t.isMulti); }
    findDeclarations(e) { if (e) {
        let t = fd(e), r = e.astNode;
        if (t && r) {
            let n = r[t.feature];
            if (Ze(n) || Yt(n))
                return Uo(n);
            if (Array.isArray(n)) {
                for (let a of n)
                    if ((Ze(a) || Yt(a)) && a.$refNode && a.$refNode.offset <= e.offset && a.$refNode.end >= e.end)
                        return Uo(a);
            }
        }
        if (r) {
            let n = this.nameProvider.getNameNode(r);
            if (n && (n === e || Kp(e, n)))
                return this.getSelfNodes(r);
        }
    } return []; }
    getSelfNodes(e) { if (this.hasMultiReference) {
        let t = this.index.findAllReferences(e, this.nodeLocator.getAstNodePath(e)), r = this.getNodeFromReferenceDescription(t.head());
        if (r) {
            for (let n of za(r))
                if (Yt(n.reference) && n.reference.items.some(a => a.ref === e))
                    return n.reference.items.map(a => a.ref);
        }
        return [e];
    }
    else
        return [e]; }
    getNodeFromReferenceDescription(e) { if (!e)
        return; let t = this.documents.getDocument(e.sourceUri); if (t)
        return this.nodeLocator.getAstNode(t.parseResult.value, e.sourcePath); }
    findDeclarationNodes(e) { let t = this.findDeclarations(e), r = []; for (let n of t) {
        let a = this.nameProvider.getNameNode(n) ?? n.$cstNode;
        a && r.push(a);
    } return r; }
    findReferences(e, t) { let r = []; t.includeDeclaration && r.push(...this.getSelfReferences(e)); let n = this.index.findAllReferences(e, this.nodeLocator.getAstNodePath(e)); return t.documentUri && (n = n.filter(a => Qe.equals(a.sourceUri, t.documentUri))), r.push(...n), le(r); }
    getSelfReferences(e) { let t = this.getSelfNodes(e), r = []; for (let n of t) {
        let a = this.nameProvider.getNameNode(n);
        if (a) {
            let i = kt(n), o = this.nodeLocator.getAstNodePath(n);
            r.push({ sourceUri: i.uri, sourcePath: o, targetUri: i.uri, targetPath: o, segment: Ba(a), local: !0 });
        }
    } return r; }
}, Ar = class {
    static { s(this, "MultiMap"); }
    constructor(e) { if (this.map = new Map, e)
        for (let [t, r] of e)
            this.add(t, r); }
    get size() { return ds.sum(le(this.map.values()).map(e => e.length)); }
    clear() { this.map.clear(); }
    delete(e, t) { if (t === void 0)
        return this.map.delete(e); {
        let r = this.map.get(e);
        if (r) {
            let n = r.indexOf(t);
            if (n >= 0)
                return r.length === 1 ? this.map.delete(e) : r.splice(n, 1), !0;
        }
        return !1;
    } }
    get(e) { return this.map.get(e) ?? []; }
    getStream(e) { let t = this.map.get(e); return t ? le(t) : Ma; }
    has(e, t) { if (t === void 0)
        return this.map.has(e); {
        let r = this.map.get(e);
        return r ? r.indexOf(t) >= 0 : !1;
    } }
    add(e, t) { return this.map.has(e) ? this.map.get(e).push(t) : this.map.set(e, [t]), this; }
    addAll(e, t) { return this.map.has(e) ? this.map.get(e).push(...t) : this.map.set(e, Array.from(t)), this; }
    forEach(e) { this.map.forEach((t, r) => t.forEach(n => e(n, r, this))); }
    [Symbol.iterator]() { return this.entries().iterator(); }
    entries() { return le(this.map.entries()).flatMap(([e, t]) => t.map(r => [e, r])); }
    keys() { return le(this.map.keys()); }
    values() { return le(this.map.values()).flat(); }
    entriesGroupedByKey() { return le(this.map.entries()); }
}, Cl = class {
    static { s(this, "BiMap"); }
    get size() { return this.map.size; }
    constructor(e) { if (this.map = new Map, this.inverse = new Map, e)
        for (let [t, r] of e)
            this.set(t, r); }
    clear() { this.map.clear(), this.inverse.clear(); }
    set(e, t) { return this.map.set(e, t), this.inverse.set(t, e), this; }
    get(e) { return this.map.get(e); }
    getKey(e) { return this.inverse.get(e); }
    delete(e) { let t = this.map.get(e); return t !== void 0 ? (this.map.delete(e), this.inverse.delete(t), !0) : !1; }
}, qS = class {
    static { s(this, "DefaultScopeComputation"); }
    constructor(e) { this.nameProvider = e.references.NameProvider, this.descriptions = e.workspace.AstNodeDescriptionProvider; }
    collectExportedSymbols(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { return this.collectExportedSymbolsForNode(e.parseResult.value, e, void 0, t); }); }
    collectExportedSymbolsForNode(a, i) { return z(this, arguments, function* (e, t, r = ks, n = me.CancellationToken.None) { let o = []; this.addExportedSymbol(e, o, t); for (let l of r(e))
        yield je(n), this.addExportedSymbol(l, o, t); return o; }); }
    addExportedSymbol(e, t, r) { let n = this.nameProvider.getName(e); n && t.push(this.descriptions.createDescription(e, n, r)); }
    collectLocalSymbols(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let n = e.parseResult.value, a = new Ar; for (let i of Er(n))
        yield je(t), this.addLocalSymbol(i, e, a); return a; }); }
    addLocalSymbol(e, t, r) { let n = e.$container; if (n) {
        let a = this.nameProvider.getName(e);
        a && r.add(n, this.descriptions.createDescription(e, a, t));
    } }
}, Vf = class {
    static { s(this, "StreamScope"); }
    constructor(e, t, r) { this.elements = e, this.outerScope = t, this.caseInsensitive = r?.caseInsensitive ?? !1, this.concatOuterScope = r?.concatOuterScope ?? !0; }
    getAllElements() { return this.outerScope ? this.elements.concat(this.outerScope.getAllElements()) : this.elements; }
    getElement(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.caseInsensitive ? this.elements.find(n => n.name.toLowerCase() === t) : this.elements.find(n => n.name === e); if (r)
        return r; if (this.outerScope)
        return this.outerScope.getElement(e); }
    getElements(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.caseInsensitive ? this.elements.filter(n => n.name.toLowerCase() === t) : this.elements.filter(n => n.name === e); return (this.concatOuterScope || r.isEmpty()) && this.outerScope ? r.concat(this.outerScope.getElements(e)) : r; }
}, GG = class {
    static { s(this, "MapScope"); }
    constructor(e, t, r) { this.elements = new Map, this.caseInsensitive = r?.caseInsensitive ?? !1, this.concatOuterScope = r?.concatOuterScope ?? !0; for (let n of e) {
        let a = this.caseInsensitive ? n.name.toLowerCase() : n.name;
        this.elements.set(a, n);
    } this.outerScope = t; }
    getElement(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(t); if (r)
        return r; if (this.outerScope)
        return this.outerScope.getElement(e); }
    getElements(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(t), n = r ? [r] : []; return (this.concatOuterScope || n.length > 0) && this.outerScope ? le(n).concat(this.outerScope.getElements(e)) : le(n); }
    getAllElements() { let e = le(this.elements.values()); return this.outerScope && (e = e.concat(this.outerScope.getAllElements())), e; }
}, WS = class {
    static { s(this, "MultiMapScope"); }
    constructor(e, t, r) { this.elements = new Ar, this.caseInsensitive = r?.caseInsensitive ?? !1, this.concatOuterScope = r?.concatOuterScope ?? !0; for (let n of e) {
        let a = this.caseInsensitive ? n.name.toLowerCase() : n.name;
        this.elements.add(a, n);
    } this.outerScope = t; }
    getElement(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(t)[0]; if (r)
        return r; if (this.outerScope)
        return this.outerScope.getElement(e); }
    getElements(e) { let t = this.caseInsensitive ? e.toLowerCase() : e, r = this.elements.get(t); return (this.concatOuterScope || r.length === 0) && this.outerScope ? le(r).concat(this.outerScope.getElements(e)) : le(r); }
    getAllElements() { let e = le(this.elements.values()); return this.outerScope && (e = e.concat(this.outerScope.getAllElements())), e; }
}, FG = { getElement() { }, getElements() { return Ma; }, getAllElements() { return Ma; } }, Lu = class {
    static { s(this, "DisposableCache"); }
    constructor() { this.toDispose = [], this.isDisposed = !1; }
    onDispose(e) { this.toDispose.push(e); }
    dispose() { this.throwIfDisposed(), this.clear(), this.isDisposed = !0, this.toDispose.forEach(e => e.dispose()); }
    throwIfDisposed() { if (this.isDisposed)
        throw new Error("This cache has already been disposed"); }
}, Mm = class extends Lu {
    static { s(this, "SimpleCache"); }
    constructor() { super(...arguments), this.cache = new Map; }
    has(e) { return this.throwIfDisposed(), this.cache.has(e); }
    set(e, t) { this.throwIfDisposed(), this.cache.set(e, t); }
    get(e, t) { if (this.throwIfDisposed(), this.cache.has(e))
        return this.cache.get(e); if (t) {
        let r = t();
        return this.cache.set(e, r), r;
    }
    else
        return; }
    delete(e) { return this.throwIfDisposed(), this.cache.delete(e); }
    clear() { this.throwIfDisposed(), this.cache.clear(); }
}, Du = class extends Lu {
    static { s(this, "ContextCache"); }
    constructor(e) { super(), this.cache = new Map, this.converter = e ?? (t => t); }
    has(e, t) { return this.throwIfDisposed(), this.cacheForContext(e).has(t); }
    set(e, t, r) { this.throwIfDisposed(), this.cacheForContext(e).set(t, r); }
    get(e, t, r) { this.throwIfDisposed(); let n = this.cacheForContext(e); if (n.has(t))
        return n.get(t); if (r) {
        let a = r();
        return n.set(t, a), a;
    }
    else
        return; }
    delete(e, t) { return this.throwIfDisposed(), this.cacheForContext(e).delete(t); }
    clear(e) { if (this.throwIfDisposed(), e) {
        let t = this.converter(e);
        this.cache.delete(t);
    }
    else
        this.cache.clear(); }
    cacheForContext(e) { let t = this.converter(e), r = this.cache.get(t); return r || (r = new Map, this.cache.set(t, r)), r; }
}, VS = class extends Du {
    static { s(this, "DocumentCache"); }
    constructor(e, t) { super(r => r.toString()), t ? (this.toDispose.push(e.workspace.DocumentBuilder.onDocumentPhase(t, r => { this.clear(r.uri.toString()); })), this.toDispose.push(e.workspace.DocumentBuilder.onUpdate((r, n) => { for (let a of n)
        this.clear(a); }))) : this.toDispose.push(e.workspace.DocumentBuilder.onUpdate((r, n) => { let a = r.concat(n); for (let i of a)
        this.clear(i); })); }
}, Gm = class extends Mm {
    static { s(this, "WorkspaceCache"); }
    constructor(e, t) { super(), t ? (this.toDispose.push(e.workspace.DocumentBuilder.onBuildPhase(t, () => { this.clear(); })), this.toDispose.push(e.workspace.DocumentBuilder.onUpdate((r, n) => { n.length > 0 && this.clear(); }))) : this.toDispose.push(e.workspace.DocumentBuilder.onUpdate(() => { this.clear(); })); }
}, HS = class {
    static { s(this, "DefaultScopeProvider"); }
    constructor(e) { this.reflection = e.shared.AstReflection, this.nameProvider = e.references.NameProvider, this.descriptions = e.workspace.AstNodeDescriptionProvider, this.indexManager = e.shared.workspace.IndexManager, this.globalScopeCache = new Gm(e.shared); }
    getScope(e) { let t = [], r = this.reflection.getReferenceType(e), n = kt(e.container).localSymbols; if (n) {
        let i = e.container;
        do
            n.has(i) && t.push(n.getStream(i).filter(o => this.reflection.isSubtype(o.type, r))), i = i.$container;
        while (i);
    } let a = this.getGlobalScope(r, e); for (let i = t.length - 1; i >= 0; i--)
        a = this.createScope(t[i], a); return a; }
    createScope(e, t, r) { return new Vf(le(e), t, r); }
    createScopeForNodes(e, t, r) { let n = le(e).map(a => { let i = this.nameProvider.getName(a); if (i)
        return this.descriptions.createDescription(a, i); }).nonNullable(); return new Vf(n, t, r); }
    getGlobalScope(e, t) { return this.globalScopeCache.get(e, () => new WS(this.indexManager.allElements(e))); }
};
function Fm(e) { return typeof e.$comment == "string"; }
s(Fm, "isAstNodeWithComment");
function Hf(e) { return typeof e == "object" && !!e && ("$ref" in e || "$error" in e); }
s(Hf, "isIntermediateReference");
var YS = class {
    static { s(this, "DefaultJsonSerializer"); }
    constructor(e) { this.ignoreProperties = new Set(["$container", "$containerProperty", "$containerIndex", "$document", "$cstNode"]), this.langiumDocuments = e.shared.workspace.LangiumDocuments, this.astNodeLocator = e.workspace.AstNodeLocator, this.nameProvider = e.references.NameProvider, this.commentProvider = e.documentation.CommentProvider; }
    serialize(e, t) { let r = t ?? {}, n = t?.replacer, a = s((o, l) => this.replacer(o, l, r), "defaultReplacer"), i = n ? (o, l) => n(o, l, a) : a; try {
        return this.currentDocument = kt(e), JSON.stringify(e, i, t?.space);
    }
    finally {
        this.currentDocument = void 0;
    } }
    deserialize(e, t) { let r = t ?? {}, n = JSON.parse(e); return this.linkNode(n, n, r), n; }
    replacer(e, t, { refText: r, sourceText: n, textRegions: a, comments: i, uriConverter: o }) { if (!this.ignoreProperties.has(e))
        if (Ze(t)) {
            let l = t.ref, u = r ? t.$refText : void 0;
            if (l) {
                let c = kt(l), f = "";
                this.currentDocument && this.currentDocument !== c && (o ? f = o(c.uri, l) : f = c.uri.toString());
                let p = this.astNodeLocator.getAstNodePath(l);
                return { $ref: `${f}#${p}`, $refText: u };
            }
            else
                return { $error: t.error?.message ?? "Could not resolve reference", $refText: u };
        }
        else if (Yt(t)) {
            let l = r ? t.$refText : void 0, u = [];
            for (let c of t.items) {
                let f = c.ref, p = kt(c.ref), m = "";
                this.currentDocument && this.currentDocument !== p && (o ? m = o(p.uri, f) : m = p.uri.toString());
                let g = this.astNodeLocator.getAstNodePath(f);
                u.push(`${m}#${g}`);
            }
            return { $refs: u, $refText: l };
        }
        else if (De(t)) {
            let l;
            if (a && (l = this.addAstNodeRegionWithAssignmentsTo(ie({}, t)), (!e || t.$document) && l?.$textRegion && (l.$textRegion.documentURI = this.currentDocument?.uri.toString())), n && !e && (l ?? (l = ie({}, t)), l.$sourceText = t.$cstNode?.text), i) {
                l ?? (l = ie({}, t));
                let u = this.commentProvider.getComment(t);
                u && (l.$comment = u.replace(/\r/g, ""));
            }
            return l ?? t;
        }
        else
            return t; }
    addAstNodeRegionWithAssignmentsTo(e) { let t = s(r => ({ offset: r.offset, end: r.end, length: r.length, range: r.range }), "createDocumentSegment"); if (e.$cstNode) {
        let r = e.$textRegion = t(e.$cstNode), n = r.assignments = {};
        return Object.keys(e).filter(a => !a.startsWith("$")).forEach(a => { let i = ud(e.$cstNode, a).map(t); i.length !== 0 && (n[a] = i); }), e;
    } }
    linkNode(e, t, r, n, a, i) { for (let [l, u] of Object.entries(e))
        if (Array.isArray(u))
            for (let c = 0; c < u.length; c++) {
                let f = u[c];
                Hf(f) ? u[c] = this.reviveReference(e, l, t, f, r) : De(f) && this.linkNode(f, t, r, e, l, c);
            }
        else
            Hf(u) ? e[l] = this.reviveReference(e, l, t, u, r) : De(u) && this.linkNode(u, t, r, e, l); let o = e; o.$container = n, o.$containerProperty = a, o.$containerIndex = i; }
    reviveReference(e, t, r, n, a) { let i = n.$refText, o = n.$error, l; if (n.$ref) {
        let u = this.getRefNode(r, n.$ref, a.uriConverter);
        if (De(u))
            return i || (i = this.nameProvider.getName(u)), { $refText: i ?? "", ref: u };
        o = u;
    }
    else if (n.$refs) {
        let u = [];
        for (let c of n.$refs) {
            let f = this.getRefNode(r, c, a.uriConverter);
            De(f) && u.push({ ref: f });
        }
        if (u.length === 0)
            l = { $refText: i ?? "", items: u }, o ?? (o = "Could not resolve multi-reference");
        else
            return { $refText: i ?? "", items: u };
    } if (o)
        return l ?? (l = { $refText: i ?? "", ref: void 0 }), l.error = { info: { container: e, property: t, reference: l }, message: o }, l; }
    getRefNode(e, t, r) { try {
        let n = t.indexOf("#");
        if (n === 0) {
            let l = this.astNodeLocator.getAstNode(e, t.substring(1));
            return l || "Could not resolve path: " + t;
        }
        if (n < 0) {
            let l = r ? r(t) : mt.parse(t), u = this.langiumDocuments.getDocument(l);
            return u ? u.parseResult.value : "Could not find document for URI: " + t;
        }
        let a = r ? r(t.substring(0, n)) : mt.parse(t.substring(0, n)), i = this.langiumDocuments.getDocument(a);
        if (!i)
            return "Could not find document for URI: " + t;
        if (n === t.length - 1)
            return i.parseResult.value;
        let o = this.astNodeLocator.getAstNode(i.parseResult.value, t.substring(n + 1));
        return o || "Could not resolve URI: " + t;
    }
    catch (n) {
        return String(n);
    } }
}, XS = class {
    static { s(this, "DefaultServiceRegistry"); }
    get map() { return this.fileExtensionMap; }
    constructor(e) { this.languageIdMap = new Map, this.fileExtensionMap = new Map, this.fileNameMap = new Map, this.textDocuments = e?.workspace.TextDocuments; }
    register(e) { let t = e.LanguageMetaData; for (let r of t.fileExtensions)
        this.fileExtensionMap.has(r) && console.warn(`The file extension ${r} is used by multiple languages. It is now assigned to '${t.languageId}'.`), this.fileExtensionMap.set(r, e); if (t.fileNames)
        for (let r of t.fileNames)
            this.fileNameMap.has(r) && console.warn(`The file name ${r} is used by multiple languages. It is now assigned to '${t.languageId}'.`), this.fileNameMap.set(r, e); this.languageIdMap.set(t.languageId, e); }
    getServices(e) { if (this.languageIdMap.size === 0)
        throw new Error("The service registry is empty. Use `register` to register the services of a language."); let t = this.textDocuments?.get(e)?.languageId; if (t !== void 0) {
        let i = this.languageIdMap.get(t);
        if (i)
            return i;
    } let r = Qe.extname(e), n = Qe.basename(e), a = this.fileNameMap.get(n) ?? this.fileExtensionMap.get(r); if (!a)
        throw t ? new Error(`The service registry contains no services for the extension '${r}' for language '${t}'.`) : new Error(`The service registry contains no services for the extension '${r}'.`); return a; }
    hasServices(e) { try {
        return this.getServices(e), !0;
    }
    catch {
        return !1;
    } }
    get all() { return Array.from(this.languageIdMap.values()); }
};
function Rn(e) { return { code: e }; }
s(Rn, "diagnosticData");
var _l;
(function (e) { e.defaults = ["fast", "slow", "built-in"], e.all = e.defaults; })(_l || (_l = {}));
var JS = class {
    static { s(this, "ValidationRegistry"); }
    constructor(e) { this.entries = new Ar, this.knownCategories = new Set(_l.defaults), this.entriesBefore = [], this.entriesAfter = [], this.reflection = e.shared.AstReflection; }
    register(e, t = this, r = "fast") { if (r === "built-in")
        throw new Error("The 'built-in' category is reserved for lexer, parser, and linker errors."); this.knownCategories.add(r); for (let [n, a] of Object.entries(e)) {
        let i = a;
        if (Array.isArray(i))
            for (let o of i) {
                let l = { check: this.wrapValidationException(o, t), category: r };
                this.addEntry(n, l);
            }
        else if (typeof i == "function") {
            let o = { check: this.wrapValidationException(i, t), category: r };
            this.addEntry(n, o);
        }
        else
            jr(i);
    } }
    wrapValidationException(e, t) { return (r, n, a) => z(this, null, function* () { yield this.handleException(() => e.call(t, r, n, a), "An error occurred during validation", n, r); }); }
    handleException(e, t, r, n) { return z(this, null, function* () { try {
        yield e();
    }
    catch (a) {
        if (Hn(a))
            throw a;
        console.error(`${t}:`, a), a instanceof Error && a.stack && console.error(a.stack);
        let i = a instanceof Error ? a.message : String(a);
        r("error", `${t}: ${i}`, { node: n });
    } }); }
    addEntry(e, t) { if (e === "AstNode") {
        this.entries.add("AstNode", t);
        return;
    } for (let r of this.reflection.getAllSubTypes(e))
        this.entries.add(r, t); }
    getChecks(e, t) { let r = le(this.entries.get(e)).concat(this.entries.get("AstNode")); return t && (r = r.filter(n => t.includes(n.category))), r.map(n => n.check); }
    registerBeforeDocument(e, t = this) { this.entriesBefore.push(this.wrapPreparationException(e, "An error occurred during set-up of the validation", t)); }
    registerAfterDocument(e, t = this) { this.entriesAfter.push(this.wrapPreparationException(e, "An error occurred during tear-down of the validation", t)); }
    wrapPreparationException(e, t, r) { return (n, a, i, o) => z(this, null, function* () { yield this.handleException(() => e.call(r, n, a, i, o), t, a, n); }); }
    get checksBefore() { return this.entriesBefore; }
    get checksAfter() { return this.entriesAfter; }
    getAllValidationCategories(e) { return this.knownCategories; }
}, ZS = Object.freeze({ validateNode: !0, validateChildren: !0 }), QS = class {
    static { s(this, "DefaultDocumentValidator"); }
    constructor(e) { this.validationRegistry = e.validation.ValidationRegistry, this.metadata = e.LanguageMetaData, this.profiler = e.shared.profilers.LangiumProfiler, this.languageId = e.LanguageMetaData.languageId; }
    validateDocument(n) { return z(this, arguments, function* (e, t = {}, r = me.CancellationToken.None) { let a = e.parseResult, i = []; if (yield je(r), (!t.categories || t.categories.includes("built-in")) && (this.processLexingErrors(a, i, t), t.stopAfterLexingErrors && i.some(o => o.data?.code === Pt.LexingError) || (this.processParsingErrors(a, i, t), t.stopAfterParsingErrors && i.some(o => o.data?.code === Pt.ParsingError)) || (this.processLinkingErrors(e, i, t), t.stopAfterLinkingErrors && i.some(o => o.data?.code === Pt.LinkingError))))
        return i; try {
        i.push(...yield this.validateAst(a.value, t, r));
    }
    catch (o) {
        if (Hn(o))
            throw o;
        console.error("An error occurred during validation:", o);
    } return yield je(r), i; }); }
    processLexingErrors(e, t, r) { let n = [...e.lexerErrors, ...e.lexerReport?.diagnostics ?? []]; for (let a of n) {
        let i = a.severity ?? "error", o = { severity: fs(i), range: { start: { line: a.line - 1, character: a.column - 1 }, end: { line: a.line - 1, character: a.column + a.length - 1 } }, message: a.message, data: jm(i), source: this.getSource() };
        t.push(o);
    } }
    processParsingErrors(e, t, r) { for (let n of e.parserErrors) {
        let a;
        if (isNaN(n.token.startOffset)) {
            if ("previousToken" in n) {
                let i = n.previousToken;
                if (isNaN(i.startOffset)) {
                    let o = { line: 0, character: 0 };
                    a = { start: o, end: o };
                }
                else {
                    let o = { line: i.endLine - 1, character: i.endColumn };
                    a = { start: o, end: o };
                }
            }
        }
        else
            a = ms(n.token);
        if (a) {
            let i = { severity: fs("error"), range: a, message: n.message, data: Rn(Pt.ParsingError), source: this.getSource() };
            t.push(i);
        }
    } }
    processLinkingErrors(e, t, r) { for (let n of e.references) {
        let a = n.error;
        if (a) {
            let i = { node: a.info.container, range: n.$refNode?.range, property: a.info.property, index: a.info.index, data: { code: Pt.LinkingError, containerType: a.info.container.$type, property: a.info.property, refText: a.info.reference.$refText } };
            t.push(this.toDiagnostic("error", a.message, i));
        }
    } }
    validateAst(n, a) { return z(this, arguments, function* (e, t, r = me.CancellationToken.None) { let i = [], o = s((l, u, c) => { i.push(this.toDiagnostic(l, u, c)); }, "acceptor"); return yield this.validateAstBefore(e, t, o, r), yield this.validateAstNodes(e, t, o, r), yield this.validateAstAfter(e, t, o, r), i; }); }
    validateAstBefore(a, i, o) { return z(this, arguments, function* (e, t, r, n = me.CancellationToken.None) { let l = this.validationRegistry.checksBefore; for (let u of l)
        yield je(n), yield u(e, r, t.categories ?? [], n); }); }
    validateAstNodes(a, i, o) { return z(this, arguments, function* (e, t, r, n = me.CancellationToken.None) { if (this.profiler?.isActive("validating")) {
        let l = this.profiler.createTask("validating", this.languageId);
        l.start();
        try {
            let u = Ot(e).iterator();
            for (let c of u) {
                l.startSubTask(c.$type);
                let f = this.validateSingleNodeOptions(c, t);
                if (f.validateNode)
                    try {
                        let p = this.validationRegistry.getChecks(c.$type, t.categories);
                        for (let m of p)
                            yield m(c, r, n);
                    }
                    finally {
                        l.stopSubTask(c.$type);
                    }
                f.validateChildren || u.prune();
            }
        }
        finally {
            l.stop();
        }
    }
    else {
        let l = Ot(e).iterator();
        for (let u of l) {
            yield je(n);
            let c = this.validateSingleNodeOptions(u, t);
            if (c.validateNode) {
                let f = this.validationRegistry.getChecks(u.$type, t.categories);
                for (let p of f)
                    yield p(u, r, n);
            }
            c.validateChildren || l.prune();
        }
    } }); }
    validateSingleNodeOptions(e, t) { return ZS; }
    validateAstAfter(a, i, o) { return z(this, arguments, function* (e, t, r, n = me.CancellationToken.None) { let l = this.validationRegistry.checksAfter; for (let u of l)
        yield je(n), yield u(e, r, t.categories ?? [], n); }); }
    toDiagnostic(e, t, r) { return { message: t, range: zm(r), severity: fs(e), code: r.code, codeDescription: r.codeDescription, tags: r.tags, relatedInformation: r.relatedInformation, data: r.data, source: this.getSource() }; }
    getSource() { return this.metadata.languageId; }
};
function zm(e) { if (e.range)
    return e.range; let t; return typeof e.property == "string" ? t = ql(e.node.$cstNode, e.property, e.index) : typeof e.keyword == "string" && (t = cd(e.node.$cstNode, e.keyword, e.index)), t ?? (t = e.node.$cstNode), t ? t.range : { start: { line: 0, character: 0 }, end: { line: 0, character: 0 } }; }
s(zm, "getDiagnosticRange");
function fs(e) { switch (e) {
    case "error": return 1;
    case "warning": return 2;
    case "info": return 3;
    case "hint": return 4;
    default: throw new Error("Invalid diagnostic severity: " + e);
} }
s(fs, "toDiagnosticSeverity");
function jm(e) { switch (e) {
    case "error": return Rn(Pt.LexingError);
    case "warning": return Rn(Pt.LexingWarning);
    case "info": return Rn(Pt.LexingInfo);
    case "hint": return Rn(Pt.LexingHint);
    default: throw new Error("Invalid diagnostic severity: " + e);
} }
s(jm, "toDiagnosticData");
var Pt = (function (e) { return e.LexingError = "lexing-error", e.LexingWarning = "lexing-warning", e.LexingInfo = "lexing-info", e.LexingHint = "lexing-hint", e.ParsingError = "parsing-error", e.LinkingError = "linking-error", e; })(Pt || {}), ew = class {
    static { s(this, "DefaultAstNodeDescriptionProvider"); }
    constructor(e) { this.astNodeLocator = e.workspace.AstNodeLocator, this.nameProvider = e.references.NameProvider; }
    createDescription(e, t, r) { let n = r ?? kt(e); t ?? (t = this.nameProvider.getName(e)); let a = this.astNodeLocator.getAstNodePath(e); if (!t)
        throw new Error(`Node at path ${a} has no name.`); let i, o = s(() => i ?? (i = Ba(this.nameProvider.getNameNode(e) ?? e.$cstNode)), "nameSegmentGetter"); return { node: e, name: t, get nameSegment() { return o(); }, selectionSegment: Ba(e.$cstNode), type: e.$type, documentUri: n.uri, path: a }; }
}, tw = class {
    static { s(this, "DefaultReferenceDescriptionProvider"); }
    constructor(e) { this.nodeLocator = e.workspace.AstNodeLocator; }
    createDescriptions(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let n = [], a = e.parseResult.value; for (let i of Ot(a))
        yield je(t), za(i).forEach(o => { o.reference.error || n.push(...this.createInfoDescriptions(o)); }); return n; }); }
    createInfoDescriptions(e) { let t = e.reference; if (t.error || !t.$refNode)
        return []; let r = []; Ze(t) && t.$nodeDescription ? r = [t.$nodeDescription] : Yt(t) && (r = t.items.map(l => l.$nodeDescription).filter(l => l !== void 0)); let n = kt(e.container).uri, a = this.nodeLocator.getAstNodePath(e.container), i = [], o = Ba(t.$refNode); for (let l of r)
        i.push({ sourceUri: n, sourcePath: a, targetUri: l.documentUri, targetPath: l.path, segment: o, local: Qe.equals(l.documentUri, n) }); return i; }
}, rw = class {
    static { s(this, "DefaultAstNodeLocator"); }
    constructor() { this.segmentSeparator = "/", this.indexSeparator = "@"; }
    getAstNodePath(e) { if (e.$container) {
        let t = this.getAstNodePath(e.$container), r = this.getPathSegment(e);
        return t + this.segmentSeparator + r;
    } return ""; }
    getPathSegment({ $containerProperty: e, $containerIndex: t }) { if (!e)
        throw new Error("Missing '$containerProperty' in AST node."); return t !== void 0 ? e + this.indexSeparator + t : e; }
    getAstNode(e, t) { return t.split(this.segmentSeparator).reduce((n, a) => { if (!n || a.length === 0)
        return n; let i = a.indexOf(this.indexSeparator); if (i > 0) {
        let o = a.substring(0, i), l = parseInt(a.substring(i + 1));
        return n[o]?.[l];
    } return n[a]; }, e); }
}, xu = {};
Nl(xu, yp(Ha(), 1));
var nw = class {
    static { s(this, "DefaultConfigurationProvider"); }
    constructor(e) { this._ready = new Rr, this.onConfigurationSectionUpdateEmitter = new xu.Emitter, this.settings = {}, this.workspaceConfig = !1, this.serviceRegistry = e.ServiceRegistry; }
    get ready() { return this._ready.promise; }
    initialize(e) { this.workspaceConfig = e.capabilities.workspace?.configuration ?? !1; }
    initialized(e) { return z(this, null, function* () { if (this.workspaceConfig) {
        if (e.register) {
            let t = this.serviceRegistry.all;
            e.register({ section: t.map(r => this.toSectionName(r.LanguageMetaData.languageId)) });
        }
        if (e.fetchConfiguration) {
            let t = this.serviceRegistry.all.map(n => ({ section: this.toSectionName(n.LanguageMetaData.languageId) })), r = yield e.fetchConfiguration(t);
            t.forEach((n, a) => { this.updateSectionConfiguration(n.section, r[a]); });
        }
    } this._ready.resolve(); }); }
    updateConfiguration(e) { typeof e.settings != "object" || e.settings === null || Object.entries(e.settings).forEach(([t, r]) => { this.updateSectionConfiguration(t, r), this.onConfigurationSectionUpdateEmitter.fire({ section: t, configuration: r }); }); }
    updateSectionConfiguration(e, t) { this.settings[e] = t; }
    getConfiguration(e, t) { return z(this, null, function* () { yield this.ready; let r = this.toSectionName(e); if (this.settings[r])
        return this.settings[r][t]; }); }
    toSectionName(e) { return `${e}`; }
    get onConfigurationSectionUpdate() { return this.onConfigurationSectionUpdateEmitter.event; }
}, no = yp(mI(), 1), En;
(function (e) { function t(r) { return { dispose: s(() => z(null, null, function* () { return yield r(); }), "dispose") }; } s(t, "create"), e.create = t; })(En || (En = {}));
var aw = class {
    static { s(this, "DefaultDocumentBuilder"); }
    constructor(e) { this.updateBuildOptions = { validation: { categories: ["built-in", "fast"] } }, this.updateListeners = [], this.buildPhaseListeners = new Ar, this.documentPhaseListeners = new Ar, this.buildState = new Map, this.documentBuildWaiters = new Map, this.currentState = J.Changed, this.langiumDocuments = e.workspace.LangiumDocuments, this.langiumDocumentFactory = e.workspace.LangiumDocumentFactory, this.textDocuments = e.workspace.TextDocuments, this.indexManager = e.workspace.IndexManager, this.fileSystemProvider = e.workspace.FileSystemProvider, this.workspaceManager = () => e.workspace.WorkspaceManager, this.serviceRegistry = e.ServiceRegistry; }
    build(n) { return z(this, arguments, function* (e, t = {}, r = me.CancellationToken.None) { for (let a of e) {
        let i = a.uri.toString();
        if (a.state === J.Validated) {
            if (typeof t.validation == "boolean" && t.validation)
                this.resetToState(a, J.IndexedReferences);
            else if (typeof t.validation == "object") {
                let o = this.findMissingValidationCategories(a, t);
                o.length > 0 && (this.buildState.set(i, { completed: !1, options: { validation: { categories: o } }, result: this.buildState.get(i)?.result }), a.state = J.IndexedReferences);
            }
        }
        else
            this.buildState.delete(i);
    } this.currentState = J.Changed, yield this.emitUpdate(e.map(a => a.uri), []), yield this.buildDocuments(e, t, r); }); }
    update(n, a) { return z(this, arguments, function* (e, t, r = me.CancellationToken.None) { this.currentState = J.Changed; let i = []; for (let c of t) {
        let f = this.langiumDocuments.deleteDocuments(c);
        for (let p of f)
            i.push(p.uri), this.cleanUpDeleted(p);
    } let o = (yield Promise.all(e.map(c => this.findChangedUris(c)))).flat(); for (let c of o) {
        let f = this.langiumDocuments.getDocument(c);
        f === void 0 && (f = this.langiumDocumentFactory.fromModel({ $type: "INVALID" }, c), f.state = J.Changed, this.langiumDocuments.addDocument(f)), this.resetToState(f, J.Changed);
    } let l = le(o).concat(i).map(c => c.toString()).toSet(); this.langiumDocuments.all.filter(c => !l.has(c.uri.toString()) && this.shouldRelink(c, l)).forEach(c => this.resetToState(c, J.ComputedScopes)), yield this.emitUpdate(o, i), yield je(r); let u = this.sortDocuments(this.langiumDocuments.all.filter(c => c.state < J.Validated || !this.buildState.get(c.uri.toString())?.completed || this.resultsAreIncomplete(c, this.updateBuildOptions)).toArray()); yield this.buildDocuments(u, this.updateBuildOptions, r); }); }
    resultsAreIncomplete(e, t) { return this.findMissingValidationCategories(e, t).length >= 1; }
    findMissingValidationCategories(e, t) { let r = this.buildState.get(e.uri.toString()), n = this.serviceRegistry.getServices(e.uri).validation.ValidationRegistry.getAllValidationCategories(e), a = r?.result?.validationChecks ? new Set(r?.result?.validationChecks) : r?.completed ? n : new Set, i = t === void 0 || t.validation === !0 ? n : typeof t.validation == "object" ? t.validation.categories ?? n : []; return le(i).filter(o => !a.has(o)).toArray(); }
    findChangedUris(e) { return z(this, null, function* () { if (this.langiumDocuments.getDocument(e) ?? this.textDocuments?.get(e))
        return [e]; try {
        let r = yield this.fileSystemProvider.stat(e);
        if (r.isDirectory)
            return yield this.workspaceManager().searchFolder(e);
        if (this.workspaceManager().shouldIncludeEntry(r))
            return [e];
    }
    catch { } return []; }); }
    emitUpdate(e, t) { return z(this, null, function* () { yield Promise.all(this.updateListeners.map(r => r(e, t))); }); }
    sortDocuments(e) { let t = 0, r = e.length - 1; for (; t < r;) {
        for (; t < e.length && this.hasTextDocument(e[t]);)
            t++;
        for (; r >= 0 && !this.hasTextDocument(e[r]);)
            r--;
        t < r && ([e[t], e[r]] = [e[r], e[t]]);
    } return e; }
    hasTextDocument(e) { return !!this.textDocuments?.get(e.uri); }
    shouldRelink(e, t) { return e.references.some(r => r.error !== void 0) ? !0 : this.indexManager.isAffected(e, t); }
    onUpdate(e) { return this.updateListeners.push(e), En.create(() => { let t = this.updateListeners.indexOf(e); t >= 0 && this.updateListeners.splice(t, 1); }); }
    resetToState(e, t) { switch (t) {
        case J.Changed:
        case J.Parsed: this.indexManager.removeContent(e.uri);
        case J.IndexedContent: e.localSymbols = void 0;
        case J.ComputedScopes: this.serviceRegistry.getServices(e.uri).references.Linker.unlink(e);
        case J.Linked: this.indexManager.removeReferences(e.uri);
        case J.IndexedReferences: e.diagnostics = void 0, this.buildState.delete(e.uri.toString());
        case J.Validated:
    } e.state > t && (e.state = t); }
    cleanUpDeleted(e) { this.buildState.delete(e.uri.toString()), this.indexManager.remove(e.uri), e.state = J.Changed; }
    buildDocuments(e, t, r) { return z(this, null, function* () { this.prepareBuild(e, t), yield this.runCancelable(e, J.Parsed, r, i => this.langiumDocumentFactory.update(i, r)), yield this.runCancelable(e, J.IndexedContent, r, i => this.indexManager.updateContent(i, r)), yield this.runCancelable(e, J.ComputedScopes, r, i => z(this, null, function* () { let o = this.serviceRegistry.getServices(i.uri).references.ScopeComputation; i.localSymbols = yield o.collectLocalSymbols(i, r); })); let n = e.filter(i => this.shouldLink(i)); yield this.runCancelable(n, J.Linked, r, i => this.serviceRegistry.getServices(i.uri).references.Linker.link(i, r)), yield this.runCancelable(n, J.IndexedReferences, r, i => this.indexManager.updateReferences(i, r)); let a = e.filter(i => this.shouldValidate(i) ? !0 : (this.markAsCompleted(i), !1)); yield this.runCancelable(a, J.Validated, r, i => z(this, null, function* () { yield this.validate(i, r), this.markAsCompleted(i); })); }); }
    markAsCompleted(e) { let t = this.buildState.get(e.uri.toString()); t && (t.completed = !0); }
    prepareBuild(e, t) { for (let r of e) {
        let n = r.uri.toString(), a = this.buildState.get(n);
        (!a || a.completed) && this.buildState.set(n, { completed: !1, options: t, result: a?.result });
    } }
    runCancelable(e, t, r, n) { return z(this, null, function* () { for (let i of e)
        i.state < t && (yield je(r), yield n(i), i.state = t, yield this.notifyDocumentPhase(i, t, r)); let a = e.filter(i => i.state === t); yield this.notifyBuildPhase(a, t, r), this.currentState = t; }); }
    onBuildPhase(e, t) { return this.buildPhaseListeners.add(e, t), En.create(() => { this.buildPhaseListeners.delete(e, t); }); }
    onDocumentPhase(e, t) { return this.documentPhaseListeners.add(e, t), En.create(() => { this.documentPhaseListeners.delete(e, t); }); }
    waitUntil(e, t, r) { let n; return t && "path" in t ? n = t : r = t, r ?? (r = me.CancellationToken.None), n ? this.awaitDocumentState(e, n, r) : this.awaitBuilderState(e, r); }
    awaitDocumentState(e, t, r) { let n = this.langiumDocuments.getDocument(t); if (n) {
        if (n.state >= e)
            return Promise.resolve(t);
        if (r.isCancellationRequested)
            return Promise.reject(Ht);
        if (this.currentState >= e && e > n.state)
            return Promise.reject(new no.ResponseError(no.LSPErrorCodes.RequestFailed, `Document state of ${t.toString()} is ${J[n.state]}, requiring ${J[e]}, but workspace state is already ${J[this.currentState]}. Returning undefined.`));
    }
    else
        return Promise.reject(new no.ResponseError(no.LSPErrorCodes.ServerCancelled, `No document found for URI: ${t.toString()}`)); return new Promise((a, i) => { let o = this.onDocumentPhase(e, u => { Qe.equals(u.uri, t) && (o.dispose(), l.dispose(), a(u.uri)); }), l = r.onCancellationRequested(() => { o.dispose(), l.dispose(), i(Ht); }); }); }
    awaitBuilderState(e, t) { return this.currentState >= e ? Promise.resolve() : t.isCancellationRequested ? Promise.reject(Ht) : new Promise((r, n) => { let a = this.onBuildPhase(e, () => { a.dispose(), i.dispose(), r(); }), i = t.onCancellationRequested(() => { a.dispose(), i.dispose(), n(Ht); }); }); }
    notifyDocumentPhase(e, t, r) { return z(this, null, function* () { let a = this.documentPhaseListeners.get(t).slice(); for (let i of a)
        try {
            yield je(r), yield i(e, r);
        }
        catch (o) {
            if (!Hn(o))
                throw o;
        } }); }
    notifyBuildPhase(e, t, r) { return z(this, null, function* () { if (e.length === 0)
        return; let a = this.buildPhaseListeners.get(t).slice(); for (let i of a)
        yield je(r), yield i(e, r); }); }
    shouldLink(e) { return this.getBuildOptions(e).eagerLinking ?? !0; }
    shouldValidate(e) { return !!this.getBuildOptions(e).validation; }
    validate(e, t) { return z(this, null, function* () { let r = this.serviceRegistry.getServices(e.uri).validation.DocumentValidator, n = this.getBuildOptions(e), a = typeof n.validation == "object" ? ie({}, n.validation) : {}; a.categories = this.findMissingValidationCategories(e, n); let i = yield r.validateDocument(e, a, t); e.diagnostics ? e.diagnostics.push(...i) : e.diagnostics = i; let o = this.buildState.get(e.uri.toString()); o && (o.result ?? (o.result = {}), o.result.validationChecks ? o.result.validationChecks = le(o.result.validationChecks).concat(a.categories).distinct().toArray() : o.result.validationChecks = [...a.categories]); }); }
    getBuildOptions(e) { return this.buildState.get(e.uri.toString())?.options ?? {}; }
}, iw = class {
    static { s(this, "DefaultIndexManager"); }
    constructor(e) { this.symbolIndex = new Map, this.symbolByTypeIndex = new Du, this.referenceIndex = new Map, this.documents = e.workspace.LangiumDocuments, this.serviceRegistry = e.ServiceRegistry, this.astReflection = e.AstReflection; }
    findAllReferences(e, t) { let r = kt(e).uri, n = []; return this.referenceIndex.forEach(a => { a.forEach(i => { Qe.equals(i.targetUri, r) && i.targetPath === t && n.push(i); }); }), le(n); }
    allElements(e, t) { let r = le(this.symbolIndex.keys()); return t && (r = r.filter(n => !t || t.has(n))), r.map(n => this.getFileDescriptions(n, e)).flat(); }
    getFileDescriptions(e, t) { return t ? this.symbolByTypeIndex.get(e, t, () => (this.symbolIndex.get(e) ?? []).filter(a => this.astReflection.isSubtype(a.type, t))) : this.symbolIndex.get(e) ?? []; }
    remove(e) { this.removeContent(e), this.removeReferences(e); }
    removeContent(e) { let t = e.toString(); this.symbolIndex.delete(t), this.symbolByTypeIndex.clear(t); }
    removeReferences(e) { let t = e.toString(); this.referenceIndex.delete(t); }
    updateContent(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let a = yield this.serviceRegistry.getServices(e.uri).references.ScopeComputation.collectExportedSymbols(e, t), i = e.uri.toString(); this.symbolIndex.set(i, a), this.symbolByTypeIndex.clear(i); }); }
    updateReferences(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let a = yield this.serviceRegistry.getServices(e.uri).workspace.ReferenceDescriptionProvider.createDescriptions(e, t); this.referenceIndex.set(e.uri.toString(), a); }); }
    isAffected(e, t) { let r = this.referenceIndex.get(e.uri.toString()); return r ? r.some(n => !n.local && t.has(n.targetUri.toString())) : !1; }
}, sw = class {
    static { s(this, "DefaultWorkspaceManager"); }
    constructor(e) { this.initialBuildOptions = {}, this._ready = new Rr, this.serviceRegistry = e.ServiceRegistry, this.langiumDocuments = e.workspace.LangiumDocuments, this.documentBuilder = e.workspace.DocumentBuilder, this.fileSystemProvider = e.workspace.FileSystemProvider, this.mutex = e.workspace.WorkspaceLock; }
    get ready() { return this._ready.promise; }
    get workspaceFolders() { return this.folders; }
    initialize(e) { this.folders = e.workspaceFolders ?? void 0; }
    initialized(e) { return this.mutex.write(t => this.initializeWorkspace(this.folders ?? [], t)); }
    initializeWorkspace(r) { return z(this, arguments, function* (e, t = me.CancellationToken.None) { let n = yield this.performStartup(e); yield je(t), yield this.documentBuilder.build(n, this.initialBuildOptions, t); }); }
    performStartup(e) { return z(this, null, function* () { let t = [], r = s(i => { t.push(i), this.langiumDocuments.hasDocument(i.uri) || this.langiumDocuments.addDocument(i); }, "collector"); yield this.loadAdditionalDocuments(e, r); let n = []; yield Promise.all(e.map(i => this.getRootFolder(i)).map(i => z(this, null, function* () { return this.traverseFolder(i, n); }))); let a = le(n).distinct(i => i.toString()).filter(i => !this.langiumDocuments.hasDocument(i)); return yield this.loadWorkspaceDocuments(a, r), this._ready.resolve(), t; }); }
    loadWorkspaceDocuments(e, t) { return z(this, null, function* () { yield Promise.all(e.map(r => z(this, null, function* () { let n = yield this.langiumDocuments.getOrCreateDocument(r); t(n); }))); }); }
    loadAdditionalDocuments(e, t) { return Promise.resolve(); }
    getRootFolder(e) { return mt.parse(e.uri); }
    traverseFolder(e, t) { return z(this, null, function* () { try {
        let r = yield this.fileSystemProvider.readDirectory(e);
        yield Promise.all(r.map(n => z(this, null, function* () { this.shouldIncludeEntry(n) && (n.isDirectory ? yield this.traverseFolder(n.uri, t) : n.isFile && t.push(n.uri)); })));
    }
    catch (r) {
        console.error("Failure to read directory content of " + e.toString(!0), r);
    } }); }
    searchFolder(e) { return z(this, null, function* () { let t = []; return yield this.traverseFolder(e, t), t; }); }
    shouldIncludeEntry(e) { let t = Qe.basename(e.uri); return t.startsWith(".") ? !1 : e.isDirectory ? t !== "node_modules" && t !== "out" : e.isFile ? this.serviceRegistry.hasServices(e.uri) : !1; }
}, ow = class {
    static { s(this, "DefaultLexerErrorMessageProvider"); }
    buildUnexpectedCharactersMessage(e, t, r, n, a) { return wf.buildUnexpectedCharactersMessage(e, t, r, n, a); }
    buildUnableToPopLexerModeMessage(e) { return wf.buildUnableToPopLexerModeMessage(e); }
}, Um = { mode: "full" }, Bm = class {
    static { s(this, "DefaultLexer"); }
    constructor(e) { this.errorMessageProvider = e.parser.LexerErrorMessageProvider, this.tokenBuilder = e.parser.TokenBuilder; let t = this.tokenBuilder.buildTokens(e.Grammar, { caseInsensitive: e.LanguageMetaData.caseInsensitive }); this.tokenTypes = this.toTokenTypeDictionary(t); let r = Sl(t) ? Object.values(t) : t, n = e.LanguageMetaData.mode === "production"; this.chevrotainLexer = new dt(r, { positionTracking: "full", skipValidations: n, errorMessageProvider: this.errorMessageProvider }); }
    get definition() { return this.tokenTypes; }
    tokenize(e, t = Um) { let r = this.chevrotainLexer.tokenize(e); return { tokens: r.tokens, errors: r.errors, hidden: r.groups.hidden ?? [], report: this.tokenBuilder.flushLexingReport?.(e) }; }
    toTokenTypeDictionary(e) { if (Sl(e))
        return e; let t = Gu(e) ? Object.values(e.modes).flat() : e, r = {}; return t.forEach(n => r[n.name] = n), r; }
};
function Mu(e) { return Array.isArray(e) && (e.length === 0 || "name" in e[0]); }
s(Mu, "isTokenTypeArray");
function Gu(e) { return e && "modes" in e && "defaultMode" in e; }
s(Gu, "isIMultiModeLexerDefinition");
function Sl(e) { return !Mu(e) && !Gu(e); }
s(Sl, "isTokenTypeDictionary");
Ns();
function Km(e, t, r) { let n, a; typeof e == "string" ? (a = t, n = r) : (a = e.range.start, n = t), a || (a = ae.create(0, 0)); let i = Wm(e), o = Fu(n), l = lw({ lines: i, position: a, options: o }); return fw({ index: 0, tokens: l, position: a }); }
s(Km, "parseJSDoc");
function qm(e, t) { let r = Fu(t), n = Wm(e); if (n.length === 0)
    return !1; let a = n[0], i = n[n.length - 1], o = r.start, l = r.end; return !!o?.exec(a) && !!l?.exec(i); }
s(qm, "isJSDoc");
function Wm(e) { let t = ""; return typeof e == "string" ? t = e : t = e.text, t.split(lv); }
s(Wm, "getLines");
var by = /\s*(@([\p{L}][\p{L}\p{N}]*)?)/uy, zG = /\{(@[\p{L}][\p{L}\p{N}]*)(\s*)([^\r\n}]+)?\}/gu;
function lw(e) { let t = [], r = e.position.line, n = e.position.character; for (let a = 0; a < e.lines.length; a++) {
    let i = a === 0, o = a === e.lines.length - 1, l = e.lines[a], u = 0;
    if (i && e.options.start) {
        let f = e.options.start?.exec(l);
        f && (u = f.index + f[0].length);
    }
    else {
        let f = e.options.line?.exec(l);
        f && (u = f.index + f[0].length);
    }
    if (o) {
        let f = e.options.end?.exec(l);
        f && (l = l.substring(0, f.index));
    }
    if (l = l.substring(0, cw(l)), wl(l, u) >= l.length) {
        if (t.length > 0) {
            let f = ae.create(r, n);
            t.push({ type: "break", content: "", range: Z.create(f, f) });
        }
    }
    else {
        by.lastIndex = u;
        let f = by.exec(l);
        if (f) {
            let p = f[0], m = f[1], g = ae.create(r, n + u), v = ae.create(r, n + u + p.length);
            t.push({ type: "tag", content: m, range: Z.create(g, v) }), u += p.length, u = wl(l, u);
        }
        if (u < l.length) {
            let p = l.substring(u), m = Array.from(p.matchAll(zG));
            t.push(...uw(m, p, r, n + u));
        }
    }
    r++, n = 0;
} return t.length > 0 && t[t.length - 1].type === "break" ? t.slice(0, -1) : t; }
s(lw, "tokenize");
function uw(e, t, r, n) { let a = []; if (e.length === 0) {
    let i = ae.create(r, n), o = ae.create(r, n + t.length);
    a.push({ type: "text", content: t, range: Z.create(i, o) });
}
else {
    let i = 0;
    for (let l of e) {
        let u = l.index, c = t.substring(i, u);
        c.length > 0 && a.push({ type: "text", content: t.substring(i, u), range: Z.create(ae.create(r, i + n), ae.create(r, u + n)) });
        let f = c.length + 1, p = l[1];
        if (a.push({ type: "inline-tag", content: p, range: Z.create(ae.create(r, i + f + n), ae.create(r, i + f + p.length + n)) }), f += p.length, l.length === 4) {
            f += l[2].length;
            let m = l[3];
            a.push({ type: "text", content: m, range: Z.create(ae.create(r, i + f + n), ae.create(r, i + f + m.length + n)) });
        }
        else
            a.push({ type: "text", content: "", range: Z.create(ae.create(r, i + f + n), ae.create(r, i + f + n)) });
        i = u + l[0].length;
    }
    let o = t.substring(i);
    o.length > 0 && a.push({ type: "text", content: o, range: Z.create(ae.create(r, i + n), ae.create(r, i + n + o.length)) });
} return a; }
s(uw, "buildInlineTokens");
var jG = /\S/, UG = /\s*$/;
function wl(e, t) { let r = e.substring(t).match(jG); return r ? t + r.index : e.length; }
s(wl, "skipWhitespace");
function cw(e) { let t = e.match(UG); if (t && typeof t.index == "number")
    return t.index; }
s(cw, "lastCharacter");
function fw(e) { let t = ae.create(e.position.line, e.position.character); if (e.tokens.length === 0)
    return new Cy([], Z.create(t, t)); let r = []; for (; e.index < e.tokens.length;) {
    let i = pw(e, r[r.length - 1]);
    i && r.push(i);
} let n = r[0]?.range.start ?? t, a = r[r.length - 1]?.range.end ?? t; return new Cy(r, Z.create(n, a)); }
s(fw, "parseJSDocComment");
function pw(e, t) { let r = e.tokens[e.index]; if (r.type === "tag")
    return Hm(e, !1); if (r.type === "text" || r.type === "inline-tag")
    return Vm(e); dw(r, t), e.index++; }
s(pw, "parseJSDocElement");
function dw(e, t) { if (t) {
    let r = new gw("", e.range);
    "inlines" in t ? t.inlines.push(r) : t.content.inlines.push(r);
} }
s(dw, "appendEmptyLine");
function Vm(e) { let t = e.tokens[e.index], r = t, n = t, a = []; for (; t && t.type !== "break" && t.type !== "tag";)
    a.push(mw(e)), n = t, t = e.tokens[e.index]; return new Yf(a, Z.create(r.range.start, n.range.end)); }
s(Vm, "parseJSDocText");
function mw(e) { return e.tokens[e.index].type === "inline-tag" ? Hm(e, !0) : Ym(e); }
s(mw, "parseJSDocInline");
function Hm(e, t) { let r = e.tokens[e.index++], n = r.content.substring(1); if (e.tokens[e.index]?.type === "text")
    if (t) {
        let i = Ym(e);
        return new Yu(n, new Yf([i], i.range), t, Z.create(r.range.start, i.range.end));
    }
    else {
        let i = Vm(e);
        return new Yu(n, i, t, Z.create(r.range.start, i.range.end));
    }
else {
    let i = r.range;
    return new Yu(n, new Yf([], i), t, i);
} }
s(Hm, "parseJSDocTag");
function Ym(e) { let t = e.tokens[e.index++]; return new gw(t.content, t.range); }
s(Ym, "parseJSDocLine");
function Fu(e) { if (!e)
    return Fu({ start: "/**", end: "*/", line: "*" }); let { start: t, end: r, line: n } = e; return { start: Mo(t, !0), end: Mo(r, !1), line: Mo(n, !0) }; }
s(Fu, "normalizeOptions");
function Mo(e, t) { if (typeof e == "string" || typeof e == "object") {
    let r = typeof e == "string" ? Xa(e) : e.source;
    return t ? new RegExp(`^\\s*${r}`) : new RegExp(`\\s*${r}\\s*$`);
}
else
    return e; }
s(Mo, "normalizeOption");
var Cy = class {
    static { s(this, "JSDocCommentImpl"); }
    constructor(e, t) { this.elements = e, this.range = t; }
    getTag(e) { return this.getAllTags().find(t => t.name === e); }
    getTags(e) { return this.getAllTags().filter(t => t.name === e); }
    getAllTags() { return this.elements.filter(e => "name" in e); }
    toString() { let e = ""; for (let t of this.elements)
        if (e.length === 0)
            e = t.toString();
        else {
            let r = t.toString();
            e += Xf(e) + r;
        } return e.trim(); }
    toMarkdown(e) { let t = ""; for (let r of this.elements)
        if (t.length === 0)
            t = r.toMarkdown(e);
        else {
            let n = r.toMarkdown(e);
            t += Xf(t) + n;
        } return t.trim(); }
}, Yu = class {
    static { s(this, "JSDocTagImpl"); }
    constructor(e, t, r, n) { this.name = e, this.content = t, this.inline = r, this.range = n; }
    toString() {
        let e = `@${this.name}`, t = this.content.toString();
        return this.content.inlines.length === 1 ? e = `${e} ${t}` : this.content.inlines.length > 1 && (e = `${e}
${t}`), this.inline ? `{${e}}` : e;
    }
    toMarkdown(e) { return e?.renderTag?.(this) ?? this.toMarkdownDefault(e); }
    toMarkdownDefault(e) {
        let t = this.content.toMarkdown(e);
        if (this.inline) {
            let a = hw(this.name, t, e ?? {});
            if (typeof a == "string")
                return a;
        }
        let r = "";
        e?.tag === "italic" || e?.tag === void 0 ? r = "*" : e?.tag === "bold" ? r = "**" : e?.tag === "bold-italic" && (r = "***");
        let n = `${r}@${this.name}${r}`;
        return this.content.inlines.length === 1 ? n = `${n} \u2014 ${t}` : this.content.inlines.length > 1 && (n = `${n}
${t}`), this.inline ? `{${n}}` : n;
    }
};
function hw(e, t, r) { if (e === "linkplain" || e === "linkcode" || e === "link") {
    let n = t.indexOf(" "), a = t;
    if (n > 0) {
        let o = wl(t, n);
        a = t.substring(o), t = t.substring(0, n);
    }
    return (e === "linkcode" || e === "link" && r.link === "code") && (a = `\`${a}\``), r.renderLink?.(t, a) ?? yw(t, a);
} }
s(hw, "renderInlineTag");
function yw(e, t) { try {
    return mt.parse(e, !0), `[${t}](${e})`;
}
catch {
    return e;
} }
s(yw, "renderLinkDefault");
var Yf = class {
    static { s(this, "JSDocTextImpl"); }
    constructor(e, t) { this.inlines = e, this.range = t; }
    toString() {
        let e = "";
        for (let t = 0; t < this.inlines.length; t++) {
            let r = this.inlines[t], n = this.inlines[t + 1];
            e += r.toString(), n && n.range.start.line > r.range.start.line && (e += `
`);
        }
        return e;
    }
    toMarkdown(e) {
        let t = "";
        for (let r = 0; r < this.inlines.length; r++) {
            let n = this.inlines[r], a = this.inlines[r + 1];
            t += n.toMarkdown(e), a && a.range.start.line > n.range.start.line && (t += `
`);
        }
        return t;
    }
}, gw = class {
    static { s(this, "JSDocLineImpl"); }
    constructor(e, t) { this.text = e, this.range = t; }
    toString() { return this.text; }
    toMarkdown() { return this.text; }
};
function Xf(e) {
    return e.endsWith(`
`) ? `
` : `

`;
}
s(Xf, "fillNewlines");
var vw = class {
    static { s(this, "JSDocDocumentationProvider"); }
    constructor(e) { this.indexManager = e.shared.workspace.IndexManager, this.commentProvider = e.documentation.CommentProvider; }
    getDocumentation(e) { let t = this.commentProvider.getComment(e); if (t && qm(t))
        return Km(t).toMarkdown({ renderLink: s((n, a) => this.documentationLinkRenderer(e, n, a), "renderLink"), renderTag: s(n => this.documentationTagRenderer(e, n), "renderTag") }); }
    documentationLinkRenderer(e, t, r) { let n = this.findNameInLocalSymbols(e, t) ?? this.findNameInGlobalScope(e, t); if (n && n.nameSegment) {
        let a = n.nameSegment.range.start.line + 1, i = n.nameSegment.range.start.character + 1, o = n.documentUri.with({ fragment: `L${a},${i}` });
        return `[${r}](${o.toString()})`;
    }
    else
        return; }
    documentationTagRenderer(e, t) { }
    findNameInLocalSymbols(e, t) { let n = kt(e).localSymbols; if (!n)
        return; let a = e; do {
        let o = n.getStream(a).find(l => l.name === t);
        if (o)
            return o;
        a = a.$container;
    } while (a); }
    findNameInGlobalScope(e, t) { return this.indexManager.allElements().find(n => n.name === t); }
}, Tw = class {
    static { s(this, "DefaultCommentProvider"); }
    constructor(e) { this.grammarConfig = () => e.parser.GrammarConfig; }
    getComment(e) { return Fm(e) ? e.$comment : Hp(e.$cstNode, this.grammarConfig().multilineCommentRules)?.text; }
}, $w = class {
    static { s(this, "DefaultAsyncParser"); }
    constructor(e) { this.syncParser = e.parser.LangiumParser; }
    parse(e, t) { return Promise.resolve(this.syncParser.parse(e)); }
}, BG = class {
    static { s(this, "AbstractThreadedAsyncParser"); }
    constructor(e) { this.threadCount = 8, this.terminationDelay = 200, this.workerPool = [], this.queue = [], this.hydrator = e.serializer.Hydrator; }
    initializeWorkers() { for (; this.workerPool.length < this.threadCount;) {
        let e = this.createWorker();
        e.onReady(() => { if (this.queue.length > 0) {
            let t = this.queue.shift();
            t && (e.lock(), t.resolve(e));
        } }), this.workerPool.push(e);
    } }
    parse(e, t) { return z(this, null, function* () { let r = yield this.acquireParserWorker(t), n = new Rr, a, i = t.onCancellationRequested(() => { a = setTimeout(() => { this.terminateWorker(r); }, this.terminationDelay); }); return r.parse(e).then(o => { let l = this.hydrator.hydrate(o); n.resolve(l); }).catch(o => { n.reject(o); }).finally(() => { i.dispose(), clearTimeout(a); }), n.promise; }); }
    terminateWorker(e) { e.terminate(); let t = this.workerPool.indexOf(e); t >= 0 && this.workerPool.splice(t, 1); }
    acquireParserWorker(e) { return z(this, null, function* () { this.initializeWorkers(); for (let r of this.workerPool)
        if (r.ready)
            return r.lock(), r; let t = new Rr; return e.onCancellationRequested(() => { let r = this.queue.indexOf(t); r >= 0 && this.queue.splice(r, 1), t.reject(Ht); }), this.queue.push(t), t.promise; }); }
}, KG = class {
    static { s(this, "ParserWorker"); }
    get ready() { return this._ready; }
    get onReady() { return this.onReadyEmitter.event; }
    constructor(e, t, r, n) { this.onReadyEmitter = new xu.Emitter, this.deferred = new Rr, this._ready = !0, this._parsing = !1, this.sendMessage = e, this._terminate = n, t(a => { let i = a; this.deferred.resolve(i), this.unlock(); }), r(a => { this.deferred.reject(a), this.unlock(); }); }
    terminate() { this.deferred.reject(Ht), this._terminate(); }
    lock() { this._ready = !1; }
    unlock() { this._parsing = !1, this._ready = !0, this.onReadyEmitter.fire(); }
    parse(e) { if (this._parsing)
        throw new Error("Parser worker is busy"); return this._parsing = !0, this.deferred = new Rr, this.sendMessage(e), this.deferred.promise; }
}, Rw = class {
    static { s(this, "DefaultWorkspaceLock"); }
    constructor() { this.previousTokenSource = new me.CancellationTokenSource, this.writeQueue = [], this.readQueue = [], this.done = !0; }
    write(e) { this.cancelWrite(); let t = Ou(); return this.previousTokenSource = t, this.enqueue(this.writeQueue, e, t.token); }
    read(e) { return this.enqueue(this.readQueue, e); }
    enqueue(e, t, r = me.CancellationToken.None) { let n = new Rr, a = { action: t, deferred: n, cancellationToken: r }; return e.push(a), this.performNextOperation(), n.promise; }
    performNextOperation() { return z(this, null, function* () { if (!this.done)
        return; let e = []; if (this.writeQueue.length > 0)
        e.push(this.writeQueue.shift());
    else if (this.readQueue.length > 0)
        e.push(...this.readQueue.splice(0, this.readQueue.length));
    else
        return; this.done = !1, yield Promise.all(e.map(a => z(this, [a], function* ({ action: t, deferred: r, cancellationToken: n }) { try {
        let i = yield Promise.resolve().then(() => t(n));
        r.resolve(i);
    }
    catch (i) {
        Hn(i) ? r.resolve(void 0) : r.reject(i);
    } }))), this.done = !0, this.performNextOperation(); }); }
    cancelWrite() { this.previousTokenSource.cancel(); }
}, Aw = class {
    static { s(this, "DefaultHydrator"); }
    constructor(e) { this.grammarElementIdMap = new Cl, this.tokenTypeIdMap = new Cl, this.grammar = e.Grammar, this.lexer = e.parser.Lexer, this.linker = e.references.Linker; }
    dehydrate(e) { return { lexerErrors: e.lexerErrors, lexerReport: e.lexerReport ? this.dehydrateLexerReport(e.lexerReport) : void 0, parserErrors: e.parserErrors.map(t => wr(ie({}, t), { message: t.message })), value: this.dehydrateAstNode(e.value, this.createDehyrationContext(e.value)) }; }
    dehydrateLexerReport(e) { return e; }
    createDehyrationContext(e) { let t = new Map, r = new Map; for (let n of Ot(e))
        t.set(n, {}); if (e.$cstNode)
        for (let n of Ua(e.$cstNode))
            r.set(n, {}); return { astNodes: t, cstNodes: r }; }
    dehydrateAstNode(e, t) { let r = t.astNodes.get(e); r.$type = e.$type, r.$containerIndex = e.$containerIndex, r.$containerProperty = e.$containerProperty, e.$cstNode !== void 0 && (r.$cstNode = this.dehydrateCstNode(e.$cstNode, t)); for (let [n, a] of Object.entries(e))
        if (!n.startsWith("$"))
            if (Array.isArray(a)) {
                let i = [];
                r[n] = i;
                for (let o of a)
                    De(o) ? i.push(this.dehydrateAstNode(o, t)) : Ze(o) ? i.push(this.dehydrateReference(o, t)) : i.push(o);
            }
            else
                De(a) ? r[n] = this.dehydrateAstNode(a, t) : Ze(a) ? r[n] = this.dehydrateReference(a, t) : a !== void 0 && (r[n] = a); return r; }
    dehydrateReference(e, t) { let r = {}; return r.$refText = e.$refText, e.$refNode && (r.$refNode = t.cstNodes.get(e.$refNode)), r; }
    dehydrateCstNode(e, t) { let r = t.cstNodes.get(e); return Ol(e) ? r.fullText = e.fullText : r.grammarSource = this.getGrammarElementId(e.grammarSource), r.hidden = e.hidden, r.astNode = t.astNodes.get(e.astNode), dr(e) ? r.content = e.content.map(n => this.dehydrateCstNode(n, t)) : In(e) && (r.tokenType = e.tokenType.name, r.offset = e.offset, r.length = e.length, r.startLine = e.range.start.line, r.startColumn = e.range.start.character, r.endLine = e.range.end.line, r.endColumn = e.range.end.character), r; }
    hydrate(e) { let t = e.value, r = this.createHydrationContext(t); return "$cstNode" in t && this.hydrateCstNode(t.$cstNode, r), { lexerErrors: e.lexerErrors, lexerReport: e.lexerReport, parserErrors: e.parserErrors, value: this.hydrateAstNode(t, r) }; }
    createHydrationContext(e) { let t = new Map, r = new Map; for (let a of Ot(e))
        t.set(a, {}); let n; if (e.$cstNode)
        for (let a of Ua(e.$cstNode)) {
            let i;
            "fullText" in a ? (i = new Em(a.fullText), n = i) : "content" in a ? i = new wu : "tokenType" in a && (i = this.hydrateCstLeafNode(a)), i && (r.set(a, i), i.root = n);
        } return { astNodes: t, cstNodes: r }; }
    hydrateAstNode(e, t) { let r = t.astNodes.get(e); r.$type = e.$type, r.$containerIndex = e.$containerIndex, r.$containerProperty = e.$containerProperty, e.$cstNode && (r.$cstNode = t.cstNodes.get(e.$cstNode)); for (let [n, a] of Object.entries(e))
        if (!n.startsWith("$"))
            if (Array.isArray(a)) {
                let i = [];
                r[n] = i;
                for (let o of a)
                    De(o) ? i.push(this.setParent(this.hydrateAstNode(o, t), r)) : Ze(o) ? i.push(this.hydrateReference(o, r, n, t)) : i.push(o);
            }
            else
                De(a) ? r[n] = this.setParent(this.hydrateAstNode(a, t), r) : Ze(a) ? r[n] = this.hydrateReference(a, r, n, t) : a !== void 0 && (r[n] = a); return r; }
    setParent(e, t) { return e.$container = t, e; }
    hydrateReference(e, t, r, n) { return this.linker.buildReference(t, r, n.cstNodes.get(e.$refNode), e.$refText); }
    hydrateCstNode(e, t, r = 0) { let n = t.cstNodes.get(e); if (typeof e.grammarSource == "number" && (n.grammarSource = this.getGrammarElement(e.grammarSource)), n.astNode = t.astNodes.get(e.astNode), dr(n))
        for (let a of e.content) {
            let i = this.hydrateCstNode(a, t, r++);
            n.content.push(i);
        } return n; }
    hydrateCstLeafNode(e) { let t = this.getTokenType(e.tokenType), r = e.offset, n = e.length, a = e.startLine, i = e.startColumn, o = e.endLine, l = e.endColumn, u = e.hidden; return new $l(r, n, { start: { line: a, character: i }, end: { line: o, character: l } }, t, u); }
    getTokenType(e) { return this.lexer.definition[e]; }
    getGrammarElementId(e) { if (e)
        return this.grammarElementIdMap.size === 0 && this.createGrammarElementIdMap(), this.grammarElementIdMap.get(e); }
    getGrammarElement(e) { return this.grammarElementIdMap.size === 0 && this.createGrammarElementIdMap(), this.grammarElementIdMap.getKey(e); }
    createGrammarElementIdMap() { let e = 0; for (let t of Ot(this.grammar))
        Ll(t) && this.grammarElementIdMap.set(t, e++); }
};
function Xm(e) { return { documentation: { CommentProvider: s(t => new Tw(t), "CommentProvider"), DocumentationProvider: s(t => new vw(t), "DocumentationProvider") }, parser: { AsyncParser: s(t => new $w(t), "AsyncParser"), GrammarConfig: s(t => vd(t), "GrammarConfig"), LangiumParser: s(t => Im(t), "LangiumParser"), CompletionParser: s(t => wm(t), "CompletionParser"), ValueConverter: s(() => new Pm, "ValueConverter"), TokenBuilder: s(() => new Pu, "TokenBuilder"), Lexer: s(t => new Bm(t), "Lexer"), ParserErrorMessageProvider: s(() => new Cm, "ParserErrorMessageProvider"), LexerErrorMessageProvider: s(() => new ow, "LexerErrorMessageProvider") }, workspace: { AstNodeLocator: s(() => new rw, "AstNodeLocator"), AstNodeDescriptionProvider: s(t => new ew(t), "AstNodeDescriptionProvider"), ReferenceDescriptionProvider: s(t => new tw(t), "ReferenceDescriptionProvider") }, references: { Linker: s(t => new US(t), "Linker"), NameProvider: s(() => new BS, "NameProvider"), ScopeProvider: s(t => new HS(t), "ScopeProvider"), ScopeComputation: s(t => new qS(t), "ScopeComputation"), References: s(t => new KS(t), "References") }, serializer: { Hydrator: s(t => new Aw(t), "Hydrator"), JsonSerializer: s(t => new YS(t), "JsonSerializer") }, validation: { DocumentValidator: s(t => new QS(t), "DocumentValidator"), ValidationRegistry: s(t => new JS(t), "ValidationRegistry") }, shared: s(() => e.shared, "shared") }; }
s(Xm, "createDefaultCoreModule");
function Jm(e) { return { ServiceRegistry: s(t => new XS(t), "ServiceRegistry"), workspace: { LangiumDocuments: s(t => new jS(t), "LangiumDocuments"), LangiumDocumentFactory: s(t => new zS(t), "LangiumDocumentFactory"), DocumentBuilder: s(t => new aw(t), "DocumentBuilder"), IndexManager: s(t => new iw(t), "IndexManager"), WorkspaceManager: s(t => new sw(t), "WorkspaceManager"), FileSystemProvider: s(t => e.fileSystemProvider(t), "FileSystemProvider"), WorkspaceLock: s(() => new Rw, "WorkspaceLock"), ConfigurationProvider: s(t => new nw(t), "ConfigurationProvider") }, profilers: {} }; }
s(Jm, "createDefaultSharedCoreModule");
var Ew = (function (e) { return e.merge = (t, r) => Va(Va({}, t), r), e; })(Ew || {});
function Il(e, t, r, n, a, i, o, l, u) { let c = [e, t, r, n, a, i, o, l, u].reduce(Va, {}); return Qm(c); }
s(Il, "inject");
var bw = Symbol("isProxy");
function Zm(e) { if (e && e[bw])
    for (let t of Object.values(e))
        Zm(t); return e; }
s(Zm, "eagerLoad");
function Qm(e, t) { let r = new Proxy({}, { deleteProperty: s(() => !1, "deleteProperty"), set: s(() => { throw new Error("Cannot set property on injected service container"); }, "set"), get: s((n, a) => a === bw ? !0 : Jf(n, a, e, t || r), "get"), getOwnPropertyDescriptor: s((n, a) => (Jf(n, a, e, t || r), Object.getOwnPropertyDescriptor(n, a)), "getOwnPropertyDescriptor"), has: s((n, a) => a in e, "has"), ownKeys: s(() => [...Object.getOwnPropertyNames(e)], "ownKeys") }); return r; }
s(Qm, "_inject");
var _y = Symbol();
function Jf(e, t, r, n) { if (t in e) {
    if (e[t] instanceof Error)
        throw new Error("Construction failure. Please make sure that your dependencies are constructable. Cause: " + e[t]);
    if (e[t] === _y)
        throw new Error('Cycle detected. Please make "' + String(t) + '" lazy. Visit https://langium.org/docs/reference/configuration-services/#resolving-cyclic-dependencies');
    return e[t];
}
else if (t in r) {
    let a = r[t];
    e[t] = _y;
    try {
        e[t] = typeof a == "function" ? a(n) : Qm(a, n);
    }
    catch (i) {
        throw e[t] = i instanceof Error ? i : void 0, i;
    }
    return e[t];
}
else
    return; }
s(Jf, "_resolve");
function Va(e, t) { if (t) {
    for (let [r, n] of Object.entries(t))
        if (n != null)
            if (typeof n == "object") {
                let a = e[r];
                typeof a == "object" && a !== null ? e[r] = Va(a, n) : e[r] = Va({}, n);
            }
            else
                e[r] = n;
} return e; }
s(Va, "_merge");
var Zf = { indentTokenName: "INDENT", dedentTokenName: "DEDENT", whitespaceTokenName: "WS", ignoreIndentationDelimiters: [] }, ka = (function (e) { return e.REGULAR = "indentation-sensitive", e.IGNORE_INDENTATION = "ignore-indentation", e; })(ka || {}), Cw = class extends Pu {
    static { s(this, "IndentationAwareTokenBuilder"); }
    constructor(e = Zf) { super(), this.indentationStack = [0], this.whitespaceRegExp = /[ \t]+/y, this.options = ie(ie({}, Zf), e), this.indentTokenType = Da({ name: this.options.indentTokenName, pattern: this.indentMatcher.bind(this), line_breaks: !1 }), this.dedentTokenType = Da({ name: this.options.dedentTokenName, pattern: this.dedentMatcher.bind(this), line_breaks: !1 }); }
    buildTokens(e, t) { let r = super.buildTokens(e, t); if (!Mu(r))
        throw new Error("Invalid tokens built by default builder"); let { indentTokenName: n, dedentTokenName: a, whitespaceTokenName: i, ignoreIndentationDelimiters: o } = this.options, l, u, c, f = []; for (let p of r) {
        for (let [m, g] of o)
            p.name === m ? p.PUSH_MODE = ka.IGNORE_INDENTATION : p.name === g && (p.POP_MODE = !0);
        p.name === a ? l = p : p.name === n ? u = p : p.name === i ? c = p : f.push(p);
    } if (!l || !u || !c)
        throw new Error("Some indentation/whitespace tokens not found!"); return o.length > 0 ? { modes: { [ka.REGULAR]: [l, u, ...f, c], [ka.IGNORE_INDENTATION]: [...f, c] }, defaultMode: ka.REGULAR } : [l, u, c, ...f]; }
    flushLexingReport(e) { let t = super.flushLexingReport(e); return wr(ie({}, t), { remainingDedents: this.flushRemainingDedents(e) }); }
    isStartOfLine(e, t) {
        return t === 0 || `\r
`.includes(e[t - 1]);
    }
    matchWhitespace(e, t, r, n) { this.whitespaceRegExp.lastIndex = t; let a = this.whitespaceRegExp.exec(e); return { currIndentLevel: a?.[0].length ?? 0, prevIndentLevel: this.indentationStack.at(-1), match: a }; }
    createIndentationTokenInstance(e, t, r, n) { let a = this.getLineNumber(t, n); return Vs(e, r, n, n + r.length, a, a, 1, r.length); }
    getLineNumber(e, t) { return e.substring(0, t).split(/\r\n|\r|\n/).length; }
    indentMatcher(e, t, r, n) { if (!this.isStartOfLine(e, t))
        return null; let { currIndentLevel: a, prevIndentLevel: i, match: o } = this.matchWhitespace(e, t, r, n); return a <= i ? null : (this.indentationStack.push(a), o); }
    dedentMatcher(e, t, r, n) { if (!this.isStartOfLine(e, t))
        return null; let { currIndentLevel: a, prevIndentLevel: i, match: o } = this.matchWhitespace(e, t, r, n); if (a >= i)
        return null; let l = this.indentationStack.lastIndexOf(a); if (l === -1)
        return this.diagnostics.push({ severity: "error", message: `Invalid dedent level ${a} at offset: ${t}. Current indentation stack: ${this.indentationStack}`, offset: t, length: o?.[0]?.length ?? 0, line: this.getLineNumber(e, t), column: 1 }), null; let u = this.indentationStack.length - l - 1, c = e.substring(0, t).match(/[\r\n]+$/)?.[0].length ?? 1; for (let f = 0; f < u; f++) {
        let p = this.createIndentationTokenInstance(this.dedentTokenType, e, "", t - (c - 1));
        r.push(p), this.indentationStack.pop();
    } return null; }
    buildTerminalToken(e) { let t = super.buildTerminalToken(e), { indentTokenName: r, dedentTokenName: n, whitespaceTokenName: a } = this.options; return t.name === r ? this.indentTokenType : t.name === n ? this.dedentTokenType : t.name === a ? Da({ name: a, pattern: this.whitespaceRegExp, group: dt.SKIPPED }) : t; }
    flushRemainingDedents(e) { let t = []; for (; this.indentationStack.length > 1;)
        t.push(this.createIndentationTokenInstance(this.dedentTokenType, e, "", e.length)), this.indentationStack.pop(); return this.indentationStack = [0], t; }
}, qG = class extends Bm {
    static { s(this, "IndentationAwareLexer"); }
    constructor(e) { if (super(e), e.parser.TokenBuilder instanceof Cw)
        this.indentationTokenBuilder = e.parser.TokenBuilder;
    else
        throw new Error("IndentationAwareLexer requires an accompanying IndentationAwareTokenBuilder"); }
    tokenize(e, t = Um) { let r = super.tokenize(e), n = r.report; t?.mode === "full" && r.tokens.push(...n.remainingDedents), n.remainingDedents = []; let { indentTokenType: a, dedentTokenType: i } = this.indentationTokenBuilder, o = a.tokenTypeIdx, l = i.tokenTypeIdx, u = [], c = r.tokens.length - 1; for (let f = 0; f < c; f++) {
        let p = r.tokens[f], m = r.tokens[f + 1];
        if (p.tokenTypeIdx === o && m.tokenTypeIdx === l) {
            f++;
            continue;
        }
        u.push(p);
    } return c >= 0 && u.push(r.tokens[c]), r.tokens = u, r; }
}, eh = {};
zr(eh, { AstUtils: () => Ap, BiMap: () => Cl, Cancellation: () => me, ContextCache: () => Du, CstUtils: () => Tp, DONE_RESULT: () => Je, Deferred: () => Rr, Disposable: () => En, DisposableCache: () => Lu, DocumentCache: () => VS, EMPTY_STREAM: () => Ma, ErrorWithLocation: () => jl, GrammarUtils: () => Zp, MultiMap: () => Ar, OperationCancelled: () => Ht, Reduction: () => ds, RegExpUtils: () => ed, SimpleCache: () => Mm, StreamImpl: () => Vt, TreeStreamImpl: () => Ga, URI: () => mt, UriTrie: () => Dm, UriUtils: () => Qe, WorkspaceCache: () => Gm, assertCondition: () => Qp, assertUnreachable: () => jr, delayNextTick: () => ku, interruptAndCheck: () => je, isOperationCancelled: () => Hn, loadGrammarFromJson: () => Ue, setInterruptionPeriod: () => km, startCancelableOperation: () => Ou, stream: () => le });
Nl(eh, xu);
var _w = class {
    static { s(this, "EmptyFileSystemProvider"); }
    stat(e) { throw new Error("No file system is available."); }
    statSync(e) { throw new Error("No file system is available."); }
    exists() { return z(this, null, function* () { return !1; }); }
    existsSync() { return !1; }
    readBinary() { throw new Error("No file system is available."); }
    readBinarySync() { throw new Error("No file system is available."); }
    readFile() { throw new Error("No file system is available."); }
    readFileSync() { throw new Error("No file system is available."); }
    readDirectory() { return z(this, null, function* () { return []; }); }
    readDirectorySync() { return []; }
}, Sw = { fileSystemProvider: s(() => new _w, "fileSystemProvider") }, WG = { Grammar: s(() => { }, "Grammar"), LanguageMetaData: s(() => ({ caseInsensitive: !1, fileExtensions: [".langium"], languageId: "langium" }), "LanguageMetaData") }, VG = { AstReflection: s(() => new Bp, "AstReflection") };
function ww() { let e = Il(Jm(Sw), VG), t = Il(Xm({ shared: e }), WG); return e.ServiceRegistry.register(t), t; }
s(ww, "createMinimalGrammarServices");
function Ue(e) { let t = ww(), r = t.serializer.JsonSerializer.deserialize(e); return t.shared.workspace.LangiumDocumentFactory.fromModel(r, mt.parse(`memory:/${r.name ?? "grammar"}.langium`)), r; }
s(Ue, "loadGrammarFromJson");
Nl(Lg, eh);
var HG = class {
    static { s(this, "DefaultLangiumProfiler"); }
    constructor(e) { this.activeCategories = new Set, this.allCategories = new Set(["validating", "parsing", "linking"]), this.activeCategories = e ?? new Set(this.allCategories), this.records = new Ar; }
    isActive(e) { return this.activeCategories.has(e); }
    start(...e) { e ? e.forEach(t => this.activeCategories.add(t)) : this.activeCategories = new Set(this.allCategories); }
    stop(...e) { e ? e.forEach(t => this.activeCategories.delete(t)) : this.activeCategories.clear(); }
    createTask(e, t) { if (!this.isActive(e))
        throw new Error(`Category "${e}" is not active.`); return console.log(`Creating profiling task for '${e}.${t}'.`), new Iw(r => this.records.add(e, this.dumpRecord(e, r)), t); }
    dumpRecord(e, t) { console.info(`Task ${e}.${t.identifier} executed in ${t.duration.toFixed(2)}ms and ended at ${t.date.toISOString()}`); let r = []; for (let i of t.entries.keys()) {
        let o = t.entries.get(i), l = o.reduce((u, c) => u + c);
        r.push({ name: `${t.identifier}.${i}`, count: o.length, duration: l });
    } let n = t.duration - r.map(i => i.duration).reduce((i, o) => i + o, 0); r.push({ name: t.identifier, count: 1, duration: n }), r.sort((i, o) => o.duration - i.duration); function a(i) { return Math.round(100 * i) / 100; } return s(a, "Round"), console.table(r.map(i => ({ Element: i.name, Count: i.count, "Self %": a(100 * i.duration / t.duration), "Time (ms)": a(i.duration) }))), t; }
    getRecords(...e) { return e.length === 0 ? this.records.values() : this.records.entries().filter(t => e.some(r => r === t[0])).flatMap(t => t[1]); }
}, Iw = class {
    static { s(this, "ProfilingTask"); }
    constructor(e, t) { this.stack = [], this.entries = new Ar, this.addRecord = e, this.identifier = t; }
    start() { if (this.startTime !== void 0)
        throw new Error(`Task "${this.identifier}" is already started.`); this.startTime = performance.now(); }
    stop() { if (this.startTime === void 0)
        throw new Error(`Task "${this.identifier}" was not started.`); if (this.stack.length !== 0)
        throw new Error(`Task "${this.identifier}" cannot be stopped before sub-task(s): ${this.stack.map(t => t.id).join(", ")}.`); let e = { identifier: this.identifier, date: new Date, duration: performance.now() - this.startTime, entries: this.entries }; this.addRecord(e), this.startTime = void 0, this.entries.clear(); }
    startSubTask(e) { this.stack.push({ id: e, start: performance.now(), content: 0 }); }
    stopSubTask(e) { let t = this.stack.pop(); if (!t)
        throw new Error(`Task "${this.identifier}.${e}" was not started.`); if (t.id !== e)
        throw new Error(`Sub-Task "${t.id}" is not already stopped.`); let r = performance.now() - t.start; this.stack.at(-1) !== void 0 && (this.stack[this.stack.length - 1].content += r); let n = r - t.content; this.entries.add(e, n); }
}, Qf;
(e => { e.Terminals = { ARROW_DIRECTION: /L|R|T|B/, ARROW_GROUP: /\{group\}/, ARROW_INTO: /<|>/, ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, ID: /[\w]([-\w]*\w)?/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, ARCH_ICON: /\([\w-:]+\)/, ARCH_TITLE: /\[(?:"([^"\\]|\\.)*"|'([^'\\]|\\.)*'|[^\[\]\r\n]+)\]/ }; })(Qf || (Qf = {}));
var ep;
(e => { e.Terminals = { DOMAIN_NAME: /complex|complicated|clear|chaotic|confusion/, ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(ep || (ep = {}));
var tp;
(e => { e.Terminals = { EM_ID: /[_a-zA-Z][\w_]*/, EM_FID: /\d{1,3}/, EM_DATA_INLINE: /\{(.*)\}|"(.*)"|'(.*)'/, EM_DATA_BLOCK: /\{[\t ]*\r?\n(?:[\S\s]*?\r?\n)?\}(?:\r?\n|(?!\S))/, EM_ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, EM_ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, EM_TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, EM_WS: /\s+/, EM_YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, EM_DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, EM_SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, EM_ML_COMMENT: /\/\*[\s\S]*?\*\//, EM_SL_COMMENT: /\/\/[^\n\r]*/ }; })(tp || (tp = {}));
var rp;
(e => { e.Terminals = { ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, INT: /0|[1-9][0-9]*(?!\.)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, REFERENCE: /\w([-\./\w]*[-\w])?/ }; })(rp || (rp = {}));
var np;
(e => { e.Terminals = { ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(np || (np = {}));
var ap;
(e => { e.Terminals = { ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, INT: /0|[1-9][0-9]*(?!\.)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(ap || (ap = {}));
var ip;
(e => { e.Terminals = { NUMBER_PIE: /(?:-?[0-9]+\.[0-9]+(?!\.))|(?:-?(0|[1-9][0-9]*)(?!\.))/, ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(ip || (ip = {}));
var sp;
(e => { e.Terminals = { GRATICULE: /circle|polygon/, BOOLEAN: /true|false/, ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, NUMBER: /(?:[0-9]+\.[0-9]+(?!\.))|(?:0|[1-9][0-9]*(?!\.))/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, ID: /[\w]([-\w]*\w)?/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(sp || (sp = {}));
var op;
(e => { e.Terminals = { TITLE: /title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, ACC_TITLE: /accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, ACC_DESCR: /accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ABNF_RULENAME: /[A-Za-z][A-Za-z0-9-]*/, ABNF_STRING: /"[^"]*"/, ABNF_NUMVAL: /%[xXdDbB][0-9A-Fa-f]+(?:-[0-9A-Fa-f]+|\.[0-9A-Fa-f]+)*/, ABNF_REPEAT: /[0-9]*\*[0-9]*/, ABNF_EXACT_REPEAT: /[0-9]+/, ABNF_WHITESPACE: /[\t \r\n]+/, ABNF_YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, ABNF_DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, ABNF_SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, ABNF_COMMENT: /;[^\n\r]*/ }; })(op || (op = {}));
var lp;
(e => { e.Terminals = { TITLE: /title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, ACC_TITLE: /accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, ACC_DESCR: /accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, EBNF_ID: /[A-Z_a-z][\w-]*/, EBNF_STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, EBNF_SPECIAL_SEQUENCE: /\?(?=[^?;]*[^?\s;][^?;]*\?)[^?;]*\?/, EBNF_WHITESPACE: /[\t \r\n]+/, EBNF_YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, EBNF_DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, EBNF_SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, EBNF_BLOCK_COMMENT: /\/\*[\s\S]*?\*\//, EBNF_ISO_COMMENT: /\(\*[\s\S]*?\*\)/ }; })(lp || (lp = {}));
var up;
(e => { e.Terminals = { TITLE: /title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, ACC_TITLE: /accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, ACC_DESCR: /accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, RR_ID: /[A-Z_a-z][\w-]*/, RR_STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, RR_WHITESPACE: /[\t \r\n]+/, RR_YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, RR_DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, RR_SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, RR_BLOCK_COMMENT: /\/\*[\s\S]*?\*\// }; })(up || (up = {}));
var cp;
(e => { e.Terminals = { TITLE: /title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, ACC_TITLE: /accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, ACC_DESCR: /accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, PEG_ID: /[A-Z_a-z][\w-]*/, PEG_STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, PEG_WHITESPACE: /[\t \r\n]+/, PEG_YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, PEG_DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, PEG_SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/, PEG_LINE_COMMENT: /#[^\n\r]*/ }; })(cp || (cp = {}));
var fp;
(e => { e.Terminals = { ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, TREEMAP_KEYWORD: /treemap-beta|treemap/, CLASS_DEF: /classDef\s+([a-zA-Z_][a-zA-Z0-9_]+)(?:\s+([^;\r\n]*))?(?:;)?/, STYLE_SEPARATOR: /:::/, SEPARATOR: /:/, COMMA: /,/, INDENTATION: /[ \t]{1,}/, WS: /[ \t]+/, ML_COMMENT: /\%\%[^\n]*/, NL: /\r?\n/, ID2: /[a-zA-Z_][a-zA-Z0-9_]*/, NUMBER2: /[0-9_\.\,]+/, STRING2: /"[^"]*"|'[^']*'/ }; })(fp || (fp = {}));
var pp;
(e => { e.Terminals = { ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, CLASS_ANNOTATION: /[ \t]+:::[ \t]*[A-Za-z_][\w-]*/, ICON_ANNOTATION: /[ \t]+icon\([\w-]*(?::[\w-]+)?\)/, DESC_ANNOTATION: /[ \t]+##[^\n\r]*/, INDENTATION: /[ \t]{1,}/, QUOTED_NAME: /"[^"]*"|'[^']*'/, WS: /[ \t]+/, ML_COMMENT: /\%\%[^\n]*/, NL: /\r?\n/, BARE_NAME: /(?!:::|icon\(|##)[^ \t\n\r"'](?:(?![ \t]+:::[ \t]*[A-Za-z_]|[ \t]+icon\(|[ \t]+##)[^\n\r])*/ }; })(pp || (pp = {}));
var dp;
(e => { e.Terminals = { WARDLEY_NUMBER: /[0-9]+\.[0-9]+/, ARROW: /->/, LINK_PORT: /\+<>|\+>|\+</, LINK_ARROW: /-->|-\.->|>|\+'[^']*'<>|\+'[^']*'<|\+'[^']*'>/, LINK_LABEL: /;[^\n\r]+/, STRATEGY: /build|buy|outsource|market/, KW_WARDLEY: /wardley-beta/, KW_SIZE: /size/, KW_EVOLUTION: /evolution/, KW_ANCHOR: /anchor/, KW_COMPONENT: /component/, KW_LABEL: /label/, KW_INERTIA: /inertia/, KW_EVOLVE: /evolve/, KW_PIPELINE: /pipeline/, KW_NOTE: /note/, KW_ANNOTATIONS: /annotations/, KW_ANNOTATION: /annotation/, KW_ACCELERATOR: /accelerator/, KW_DEACCELERATOR: /deaccelerator/, NAME_WITH_SPACES: /(?!title\s|accTitle|accDescr)[A-Za-z](?:[A-Za-z0-9_()&]|-(?!>))*(?:[ \t]+[A-Za-z(](?:[A-Za-z0-9_()&]|-(?!>))*)*/, WS: /[ \t]+/, ACC_DESCR: /[\t ]*accDescr(?:[\t ]*:([^\n\r]*?(?=%%)|[^\n\r]*)|\s*{([^}]*)})/, ACC_TITLE: /[\t ]*accTitle[\t ]*:(?:[^\n\r]*?(?=%%)|[^\n\r]*)/, TITLE: /[\t ]*title(?:[\t ][^\n\r]*?(?=%%)|[\t ][^\n\r]*|)/, INT: /0|[1-9][0-9]*(?!\.)/, STRING: /"([^"\\]|\\.)*"|'([^'\\]|\\.)*'/, ID: /[\w]([-\w]*\w)?/, NEWLINE: /\r?\n/, WHITESPACE: /[\t ]+/, YAML: /---[\t ]*\r?\n(?:[\S\s]*?\r?\n)?---(?:\r?\n|(?!\S))/, DIRECTIVE: /[\t ]*%%{[\S\s]*?}%%(?:\r?\n|(?!\S))/, SINGLE_LINE_COMMENT: /[\t ]*%%[^\n\r]*/ }; })(dp || (dp = {}));
var ez = ie(ie(ie(ie(ie(ie(ie(ie(ie(ie(ie(ie(ie(ie(ie({}, Qf.Terminals), ep.Terminals), tp.Terminals), rp.Terminals), np.Terminals), ap.Terminals), ip.Terminals), sp.Terminals), op.Terminals), lp.Terminals), up.Terminals), cp.Terminals), pp.Terminals), fp.Terminals), dp.Terminals), Sy = { $type: "AbnfAlternation", alternatives: "alternatives" }, wy = { $type: "AbnfConcatenation", elements: "elements" }, Xu = { $type: "AbnfElement", primary: "primary", repeat: "repeat" }, Iy = { $type: "AbnfGroup", element: "element" }, Ny = { $type: "AbnfNumVal", value: "value" }, Py = { $type: "AbnfOptionalGroup", element: "element" }, na = { $type: "AbnfPrimary" }, Ju = { $type: "AbnfRule", definition: "definition", name: "name" }, ky = { $type: "AbnfRuleName", name: "name" }, Oy = { $type: "AbnfStringLiteral", value: "value" }, ao = { $type: "Accelerator", name: "name", x: "x", y: "y" }, Zu = { $type: "Alignment", direction: "direction", members: "members" }, io = { $type: "Anchor", evolution: "evolution", name: "name", visibility: "visibility" }, Ii = { $type: "Annotation", number: "number", text: "text", x: "x", y: "y" }, Qu = { $type: "Annotations", x: "x", y: "y" }, Kt = { $type: "Architecture", accDescr: "accDescr", accTitle: "accTitle", alignments: "alignments", edges: "edges", groups: "groups", junctions: "junctions", services: "services", title: "title" };
function YG(e) { return Oe.isInstance(e, Kt.$type); }
s(YG, "isArchitecture");
var so = { $type: "Axis", label: "label", name: "name" }, Go = { $type: "Branch", name: "name", order: "order" };
function XG(e) { return Oe.isInstance(e, Go.$type); }
s(XG, "isBranch");
var Ly = { $type: "Checkout", branch: "branch" }, oo = { $type: "CherryPicking", id: "id", parent: "parent", tags: "tags" }, ec = { $type: "ClassDefStatement", className: "className", styleText: "styleText" }, ha = { $type: "Commit", id: "id", message: "message", tags: "tags", type: "type" };
function JG(e) { return Oe.isInstance(e, ha.$type); }
s(JG, "isCommit");
var lo = { $type: "Common", accDescr: "accDescr", accTitle: "accTitle", title: "title" }, Wr = { $type: "Component", decorator: "decorator", evolution: "evolution", inertia: "inertia", label: "label", name: "name", visibility: "visibility" }, uo = { $type: "Curve", entries: "entries", label: "label", name: "name" }, nn = { $type: "Cynefin", accDescr: "accDescr", accTitle: "accTitle", domains: "domains", title: "title", transitions: "transitions" };
function ZG(e) { return Oe.isInstance(e, nn.$type); }
s(ZG, "isCynefin");
var co = { $type: "Deaccelerator", name: "name", x: "x", y: "y" }, Dy = { $type: "Decorator", strategy: "strategy" }, aa = { $type: "Direction", accDescr: "accDescr", accTitle: "accTitle", dir: "dir", statements: "statements", title: "title" }, Fo = { $type: "DomainBlock", domain: "domain", items: "items" };
function QG(e) { return Oe.isInstance(e, Fo.$type); }
s(QG, "isDomainBlock");
var mp = { $type: "DomainItem", label: "label" };
function eF(e) { return Oe.isInstance(e, mp.$type); }
s(eF, "isDomainItem");
var xy = { $type: "EbnfChoice", alternatives: "alternatives" }, My = { $type: "EbnfExceptionPostfix", except: "except" }, Gy = { $type: "EbnfGroup", element: "element" }, Fy = { $type: "EbnfNonTerminal", name: "name" }, zy = { $type: "EbnfOneOrMorePostfix", operator: "operator" }, jy = { $type: "EbnfOptional", element: "element" }, Uy = { $type: "EbnfOptionalPostfix", operator: "operator" }, Ni = { $type: "EbnfPostfix" }, Vr = { $type: "EbnfPrimary" }, By = { $type: "EbnfRepetition", element: "element" }, tc = { $type: "EbnfRule", definition: "definition", name: "name" }, Ky = { $type: "EbnfSequence", elements: "elements" }, qy = { $type: "EbnfSpecial", text: "text" }, rc = { $type: "EbnfTerm", base: "base", postfixes: "postfixes" }, Wy = { $type: "EbnfTerminal", value: "value" }, Vy = { $type: "EbnfZeroOrMorePostfix", operator: "operator" }, Ut = { $type: "Edge", lhsDir: "lhsDir", lhsGroup: "lhsGroup", lhsId: "lhsId", lhsInto: "lhsInto", rhsDir: "rhsDir", rhsGroup: "rhsGroup", rhsId: "rhsId", rhsInto: "rhsInto", title: "title" }, ia = { $type: "EmDataEntity", dataBlockValue: "dataBlockValue", dataType: "dataType", name: "name" }, Hr = { $type: "EmFrame" }, Pi = { $type: "EmGwt", givenStatements: "givenStatements", sourceFrame: "sourceFrame", thenStatements: "thenStatements", whenStatements: "whenStatements" }, Hy = { $type: "EmGwtStatement", entityIdentifier: "entityIdentifier" }, nc = { $type: "EmModelEntity", name: "name" };
function tF(e) { return e === "rmo" || e === "readmodel" || e === "ui" || e === "cmd" || e === "command" || e === "evt" || e === "event" || e === "pcr" || e === "processor"; }
s(tF, "isEmModelEntityType");
var fo = { $type: "EmNoteEntity", dataBlockValue: "dataBlockValue", dataType: "dataType", sourceFrame: "sourceFrame" }, lr = { $type: "EmResetFrame", dataInlineValue: "dataInlineValue", dataReference: "dataReference", dataType: "dataType", entityIdentifier: "entityIdentifier", modelEntityType: "modelEntityType", name: "name", sourceFrames: "sourceFrames" };
function rF(e) { return Oe.isInstance(e, lr.$type); }
s(rF, "isEmResetFrame");
var Ir = { $type: "EmTimeFrame", dataInlineValue: "dataInlineValue", dataReference: "dataReference", dataType: "dataType", entityIdentifier: "entityIdentifier", modelEntityType: "modelEntityType", name: "name", sourceFrames: "sourceFrames" }, ac = { $type: "Entry", axis: "axis", value: "value" }, ar = { $type: "EventModel", accDescr: "accDescr", accTitle: "accTitle", dataEntities: "dataEntities", frames: "frames", gwtEntities: "gwtEntities", modelEntities: "modelEntities", noteEntities: "noteEntities", title: "title" }, Yy = { $type: "Evolution", stages: "stages" }, po = { $type: "EvolutionStage", boundary: "boundary", name: "name", secondName: "secondName" }, ic = { $type: "Evolve", component: "component", target: "target" }, an = { $type: "GitGraph", accDescr: "accDescr", accTitle: "accTitle", statements: "statements", title: "title" };
function nF(e) { return Oe.isInstance(e, an.$type); }
s(nF, "isGitGraph");
var ki = { $type: "Group", icon: "icon", id: "id", in: "in", title: "title" }, Yi = { $type: "Info", accDescr: "accDescr", accTitle: "accTitle", title: "title" };
function aF(e) { return Oe.isInstance(e, Yi.$type); }
s(aF, "isInfo");
var Oi = { $type: "Item", classSelector: "classSelector", name: "name" }, sc = { $type: "Junction", id: "id", in: "in" }, Li = { $type: "Label", negX: "negX", negY: "negY", offsetX: "offsetX", offsetY: "offsetY" }, mo = { $type: "Leaf", classSelector: "classSelector", name: "name", value: "value" }, Yr = { $type: "Link", arrow: "arrow", from: "from", fromPort: "fromPort", linkLabel: "linkLabel", to: "to", toPort: "toPort" }, ya = { $type: "Merge", branch: "branch", id: "id", tags: "tags", type: "type" };
function iF(e) { return Oe.isInstance(e, ya.$type); }
s(iF, "isMerge");
var ho = { $type: "Note", evolution: "evolution", text: "text", visibility: "visibility" }, oc = { $type: "Option", name: "name", value: "value" }, ga = { $type: "Packet", accDescr: "accDescr", accTitle: "accTitle", blocks: "blocks", title: "title" };
function sF(e) { return Oe.isInstance(e, ga.$type); }
s(sF, "isPacket");
var va = { $type: "PacketBlock", bits: "bits", end: "end", label: "label", start: "start" };
function oF(e) { return Oe.isInstance(e, va.$type); }
s(oF, "isPacketBlock");
var Xy = { $type: "PegAny", dot: "dot" }, Jy = { $type: "PegGroup", element: "element" }, Zy = { $type: "PegIdentifier", name: "name" }, Qy = { $type: "PegLiteral", value: "value" }, eg = { $type: "PegOrderedChoice", alternatives: "alternatives" }, lc = { $type: "PegPrefix", operator: "operator", suffix: "suffix" }, Di = { $type: "PegPrimary" }, uc = { $type: "PegRule", definition: "definition", name: "name" }, tg = { $type: "PegSequence", elements: "elements" }, cc = { $type: "PegSuffix", operator: "operator", primary: "primary" }, sn = { $type: "Pie", accDescr: "accDescr", accTitle: "accTitle", sections: "sections", showData: "showData", title: "title" };
function lF(e) { return Oe.isInstance(e, sn.$type); }
s(lF, "isPie");
var zo = { $type: "PieSection", label: "label", value: "value" };
function uF(e) { return Oe.isInstance(e, zo.$type); }
s(uF, "isPieSection");
var fc = { $type: "Pipeline", components: "components", parent: "parent" }, yo = { $type: "PipelineComponent", evolution: "evolution", label: "label", name: "name" }, Xr = { $type: "Radar", accDescr: "accDescr", accTitle: "accTitle", axes: "axes", curves: "curves", options: "options", title: "title" }, Ta = { $type: "Railroad", accDescr: "accDescr", accTitle: "accTitle", rules: "rules", title: "title" };
function cF(e) { return Oe.isInstance(e, Ta.$type); }
s(cF, "isRailroad");
var $a = { $type: "RailroadAbnf", accDescr: "accDescr", accTitle: "accTitle", rules: "rules", title: "title" };
function fF(e) { return Oe.isInstance(e, $a.$type); }
s(fF, "isRailroadAbnf");
var rg = { $type: "RailroadChoiceExpr", alternatives: "alternatives" }, Ra = { $type: "RailroadEbnf", accDescr: "accDescr", accTitle: "accTitle", rules: "rules", title: "title" };
function pF(e) { return Oe.isInstance(e, Ra.$type); }
s(pF, "isRailroadEbnf");
var ir = { $type: "RailroadExpression" }, ng = { $type: "RailroadNonTerminalExpr", name: "name" }, ag = { $type: "RailroadOneOrMoreExpr", element: "element" }, ig = { $type: "RailroadOptionalExpr", element: "element" }, Aa = { $type: "RailroadPeg", accDescr: "accDescr", accTitle: "accTitle", rules: "rules", title: "title" };
function dF(e) { return Oe.isInstance(e, Aa.$type); }
s(dF, "isRailroadPeg");
var pc = { $type: "RailroadRule", definition: "definition", name: "name" }, sg = { $type: "RailroadSequenceExpr", elements: "elements" }, og = { $type: "RailroadSpecialExpr", text: "text" }, lg = { $type: "RailroadTerminalExpr", value: "value" }, ug = { $type: "RailroadZeroOrMoreExpr", element: "element" }, dc = { $type: "Section", classSelector: "classSelector", name: "name" }, sa = { $type: "Service", icon: "icon", iconText: "iconText", id: "id", in: "in", title: "title" }, mc = { $type: "Size", height: "height", width: "width" }, oa = { $type: "Statement" }, Xi = { $type: "Transition", from: "from", label: "label", to: "to" };
function mF(e) { return Oe.isInstance(e, Xi.$type); }
s(mF, "isTransition");
var Ea = { $type: "Treemap", accDescr: "accDescr", accTitle: "accTitle", title: "title", TreemapRows: "TreemapRows" };
function hF(e) { return Oe.isInstance(e, Ea.$type); }
s(hF, "isTreemap");
var hc = { $type: "TreemapRow", indent: "indent", item: "item" }, la = { $type: "TreeNode", classAnnotation: "classAnnotation", descAnnotation: "descAnnotation", iconAnnotation: "iconAnnotation", indent: "indent", name: "name" }, xi = { $type: "TreeView", accDescr: "accDescr", accTitle: "accTitle", nodes: "nodes", title: "title" }, We = { $type: "Wardley", accDescr: "accDescr", accelerators: "accelerators", accTitle: "accTitle", anchors: "anchors", annotation: "annotation", annotations: "annotations", components: "components", deaccelerators: "deaccelerators", evolution: "evolution", evolves: "evolves", links: "links", notes: "notes", pipelines: "pipelines", size: "size", title: "title" };
function yF(e) { return Oe.isInstance(e, We.$type); }
s(yF, "isWardley");
var Nw = class extends Rp {
    constructor() { super(...arguments), this.types = { AbnfAlternation: { name: Sy.$type, properties: { alternatives: { name: Sy.alternatives, defaultValue: [] } }, superTypes: [] }, AbnfConcatenation: { name: wy.$type, properties: { elements: { name: wy.elements, defaultValue: [] } }, superTypes: [] }, AbnfElement: { name: Xu.$type, properties: { primary: { name: Xu.primary }, repeat: { name: Xu.repeat } }, superTypes: [] }, AbnfGroup: { name: Iy.$type, properties: { element: { name: Iy.element } }, superTypes: [na.$type] }, AbnfNumVal: { name: Ny.$type, properties: { value: { name: Ny.value } }, superTypes: [na.$type] }, AbnfOptionalGroup: { name: Py.$type, properties: { element: { name: Py.element } }, superTypes: [na.$type] }, AbnfPrimary: { name: na.$type, properties: {}, superTypes: [] }, AbnfRule: { name: Ju.$type, properties: { definition: { name: Ju.definition }, name: { name: Ju.name } }, superTypes: [] }, AbnfRuleName: { name: ky.$type, properties: { name: { name: ky.name } }, superTypes: [na.$type] }, AbnfStringLiteral: { name: Oy.$type, properties: { value: { name: Oy.value } }, superTypes: [na.$type] }, Accelerator: { name: ao.$type, properties: { name: { name: ao.name }, x: { name: ao.x }, y: { name: ao.y } }, superTypes: [] }, Alignment: { name: Zu.$type, properties: { direction: { name: Zu.direction }, members: { name: Zu.members, defaultValue: [] } }, superTypes: [] }, Anchor: { name: io.$type, properties: { evolution: { name: io.evolution }, name: { name: io.name }, visibility: { name: io.visibility } }, superTypes: [] }, Annotation: { name: Ii.$type, properties: { number: { name: Ii.number }, text: { name: Ii.text }, x: { name: Ii.x }, y: { name: Ii.y } }, superTypes: [] }, Annotations: { name: Qu.$type, properties: { x: { name: Qu.x }, y: { name: Qu.y } }, superTypes: [] }, Architecture: { name: Kt.$type, properties: { accDescr: { name: Kt.accDescr }, accTitle: { name: Kt.accTitle }, alignments: { name: Kt.alignments, defaultValue: [] }, edges: { name: Kt.edges, defaultValue: [] }, groups: { name: Kt.groups, defaultValue: [] }, junctions: { name: Kt.junctions, defaultValue: [] }, services: { name: Kt.services, defaultValue: [] }, title: { name: Kt.title } }, superTypes: [] }, Axis: { name: so.$type, properties: { label: { name: so.label }, name: { name: so.name } }, superTypes: [] }, Branch: { name: Go.$type, properties: { name: { name: Go.name }, order: { name: Go.order } }, superTypes: [oa.$type] }, Checkout: { name: Ly.$type, properties: { branch: { name: Ly.branch } }, superTypes: [oa.$type] }, CherryPicking: { name: oo.$type, properties: { id: { name: oo.id }, parent: { name: oo.parent }, tags: { name: oo.tags, defaultValue: [] } }, superTypes: [oa.$type] }, ClassDefStatement: { name: ec.$type, properties: { className: { name: ec.className }, styleText: { name: ec.styleText } }, superTypes: [] }, Commit: { name: ha.$type, properties: { id: { name: ha.id }, message: { name: ha.message }, tags: { name: ha.tags, defaultValue: [] }, type: { name: ha.type } }, superTypes: [oa.$type] }, Common: { name: lo.$type, properties: { accDescr: { name: lo.accDescr }, accTitle: { name: lo.accTitle }, title: { name: lo.title } }, superTypes: [] }, Component: { name: Wr.$type, properties: { decorator: { name: Wr.decorator }, evolution: { name: Wr.evolution }, inertia: { name: Wr.inertia, defaultValue: !1 }, label: { name: Wr.label }, name: { name: Wr.name }, visibility: { name: Wr.visibility } }, superTypes: [] }, Curve: { name: uo.$type, properties: { entries: { name: uo.entries, defaultValue: [] }, label: { name: uo.label }, name: { name: uo.name } }, superTypes: [] }, Cynefin: { name: nn.$type, properties: { accDescr: { name: nn.accDescr }, accTitle: { name: nn.accTitle }, domains: { name: nn.domains, defaultValue: [] }, title: { name: nn.title }, transitions: { name: nn.transitions, defaultValue: [] } }, superTypes: [] }, Deaccelerator: { name: co.$type, properties: { name: { name: co.name }, x: { name: co.x }, y: { name: co.y } }, superTypes: [] }, Decorator: { name: Dy.$type, properties: { strategy: { name: Dy.strategy } }, superTypes: [] }, Direction: { name: aa.$type, properties: { accDescr: { name: aa.accDescr }, accTitle: { name: aa.accTitle }, dir: { name: aa.dir }, statements: { name: aa.statements, defaultValue: [] }, title: { name: aa.title } }, superTypes: [an.$type] }, DomainBlock: { name: Fo.$type, properties: { domain: { name: Fo.domain }, items: { name: Fo.items, defaultValue: [] } }, superTypes: [] }, DomainItem: { name: mp.$type, properties: { label: { name: mp.label } }, superTypes: [] }, EbnfChoice: { name: xy.$type, properties: { alternatives: { name: xy.alternatives, defaultValue: [] } }, superTypes: [] }, EbnfExceptionPostfix: { name: My.$type, properties: { except: { name: My.except } }, superTypes: [Ni.$type] }, EbnfGroup: { name: Gy.$type, properties: { element: { name: Gy.element } }, superTypes: [Vr.$type] }, EbnfNonTerminal: { name: Fy.$type, properties: { name: { name: Fy.name } }, superTypes: [Vr.$type] }, EbnfOneOrMorePostfix: { name: zy.$type, properties: { operator: { name: zy.operator } }, superTypes: [Ni.$type] }, EbnfOptional: { name: jy.$type, properties: { element: { name: jy.element } }, superTypes: [Vr.$type] }, EbnfOptionalPostfix: { name: Uy.$type, properties: { operator: { name: Uy.operator } }, superTypes: [Ni.$type] }, EbnfPostfix: { name: Ni.$type, properties: {}, superTypes: [] }, EbnfPrimary: { name: Vr.$type, properties: {}, superTypes: [] }, EbnfRepetition: { name: By.$type, properties: { element: { name: By.element } }, superTypes: [Vr.$type] }, EbnfRule: { name: tc.$type, properties: { definition: { name: tc.definition }, name: { name: tc.name } }, superTypes: [] }, EbnfSequence: { name: Ky.$type, properties: { elements: { name: Ky.elements, defaultValue: [] } }, superTypes: [] }, EbnfSpecial: { name: qy.$type, properties: { text: { name: qy.text } }, superTypes: [Vr.$type] }, EbnfTerm: { name: rc.$type, properties: { base: { name: rc.base }, postfixes: { name: rc.postfixes, defaultValue: [] } }, superTypes: [] }, EbnfTerminal: { name: Wy.$type, properties: { value: { name: Wy.value } }, superTypes: [Vr.$type] }, EbnfZeroOrMorePostfix: { name: Vy.$type, properties: { operator: { name: Vy.operator } }, superTypes: [Ni.$type] }, Edge: { name: Ut.$type, properties: { lhsDir: { name: Ut.lhsDir }, lhsGroup: { name: Ut.lhsGroup, defaultValue: !1 }, lhsId: { name: Ut.lhsId }, lhsInto: { name: Ut.lhsInto, defaultValue: !1 }, rhsDir: { name: Ut.rhsDir }, rhsGroup: { name: Ut.rhsGroup, defaultValue: !1 }, rhsId: { name: Ut.rhsId }, rhsInto: { name: Ut.rhsInto, defaultValue: !1 }, title: { name: Ut.title } }, superTypes: [] }, EmDataEntity: { name: ia.$type, properties: { dataBlockValue: { name: ia.dataBlockValue }, dataType: { name: ia.dataType }, name: { name: ia.name } }, superTypes: [] }, EmFrame: { name: Hr.$type, properties: {}, superTypes: [] }, EmGwt: { name: Pi.$type, properties: { givenStatements: { name: Pi.givenStatements, defaultValue: [] }, sourceFrame: { name: Pi.sourceFrame, referenceType: Hr.$type }, thenStatements: { name: Pi.thenStatements, defaultValue: [] }, whenStatements: { name: Pi.whenStatements, defaultValue: [] } }, superTypes: [] }, EmGwtStatement: { name: Hy.$type, properties: { entityIdentifier: { name: Hy.entityIdentifier, referenceType: nc.$type } }, superTypes: [] }, EmModelEntity: { name: nc.$type, properties: { name: { name: nc.name } }, superTypes: [] }, EmNoteEntity: { name: fo.$type, properties: { dataBlockValue: { name: fo.dataBlockValue }, dataType: { name: fo.dataType }, sourceFrame: { name: fo.sourceFrame, referenceType: Hr.$type } }, superTypes: [] }, EmResetFrame: { name: lr.$type, properties: { dataInlineValue: { name: lr.dataInlineValue }, dataReference: { name: lr.dataReference, referenceType: ia.$type }, dataType: { name: lr.dataType }, entityIdentifier: { name: lr.entityIdentifier }, modelEntityType: { name: lr.modelEntityType }, name: { name: lr.name }, sourceFrames: { name: lr.sourceFrames, defaultValue: [], referenceType: Hr.$type } }, superTypes: [Hr.$type] }, EmTimeFrame: { name: Ir.$type, properties: { dataInlineValue: { name: Ir.dataInlineValue }, dataReference: { name: Ir.dataReference, referenceType: ia.$type }, dataType: { name: Ir.dataType }, entityIdentifier: { name: Ir.entityIdentifier }, modelEntityType: { name: Ir.modelEntityType }, name: { name: Ir.name }, sourceFrames: { name: Ir.sourceFrames, defaultValue: [], referenceType: Hr.$type } }, superTypes: [Hr.$type] }, Entry: { name: ac.$type, properties: { axis: { name: ac.axis, referenceType: so.$type }, value: { name: ac.value } }, superTypes: [] }, EventModel: { name: ar.$type, properties: { accDescr: { name: ar.accDescr }, accTitle: { name: ar.accTitle }, dataEntities: { name: ar.dataEntities, defaultValue: [] }, frames: { name: ar.frames, defaultValue: [] }, gwtEntities: { name: ar.gwtEntities, defaultValue: [] }, modelEntities: { name: ar.modelEntities, defaultValue: [] }, noteEntities: { name: ar.noteEntities, defaultValue: [] }, title: { name: ar.title } }, superTypes: [] }, Evolution: { name: Yy.$type, properties: { stages: { name: Yy.stages, defaultValue: [] } }, superTypes: [] }, EvolutionStage: { name: po.$type, properties: { boundary: { name: po.boundary }, name: { name: po.name }, secondName: { name: po.secondName } }, superTypes: [] }, Evolve: { name: ic.$type, properties: { component: { name: ic.component }, target: { name: ic.target } }, superTypes: [] }, GitGraph: { name: an.$type, properties: { accDescr: { name: an.accDescr }, accTitle: { name: an.accTitle }, statements: { name: an.statements, defaultValue: [] }, title: { name: an.title } }, superTypes: [] }, Group: { name: ki.$type, properties: { icon: { name: ki.icon }, id: { name: ki.id }, in: { name: ki.in }, title: { name: ki.title } }, superTypes: [] }, Info: { name: Yi.$type, properties: { accDescr: { name: Yi.accDescr }, accTitle: { name: Yi.accTitle }, title: { name: Yi.title } }, superTypes: [] }, Item: { name: Oi.$type, properties: { classSelector: { name: Oi.classSelector }, name: { name: Oi.name } }, superTypes: [] }, Junction: { name: sc.$type, properties: { id: { name: sc.id }, in: { name: sc.in } }, superTypes: [] }, Label: { name: Li.$type, properties: { negX: { name: Li.negX, defaultValue: !1 }, negY: { name: Li.negY, defaultValue: !1 }, offsetX: { name: Li.offsetX }, offsetY: { name: Li.offsetY } }, superTypes: [] }, Leaf: { name: mo.$type, properties: { classSelector: { name: mo.classSelector }, name: { name: mo.name }, value: { name: mo.value } }, superTypes: [Oi.$type] }, Link: { name: Yr.$type, properties: { arrow: { name: Yr.arrow }, from: { name: Yr.from }, fromPort: { name: Yr.fromPort }, linkLabel: { name: Yr.linkLabel }, to: { name: Yr.to }, toPort: { name: Yr.toPort } }, superTypes: [] }, Merge: { name: ya.$type, properties: { branch: { name: ya.branch }, id: { name: ya.id }, tags: { name: ya.tags, defaultValue: [] }, type: { name: ya.type } }, superTypes: [oa.$type] }, Note: { name: ho.$type, properties: { evolution: { name: ho.evolution }, text: { name: ho.text }, visibility: { name: ho.visibility } }, superTypes: [] }, Option: { name: oc.$type, properties: { name: { name: oc.name }, value: { name: oc.value, defaultValue: !1 } }, superTypes: [] }, Packet: { name: ga.$type, properties: { accDescr: { name: ga.accDescr }, accTitle: { name: ga.accTitle }, blocks: { name: ga.blocks, defaultValue: [] }, title: { name: ga.title } }, superTypes: [] }, PacketBlock: { name: va.$type, properties: { bits: { name: va.bits }, end: { name: va.end }, label: { name: va.label }, start: { name: va.start } }, superTypes: [] }, PegAny: { name: Xy.$type, properties: { dot: { name: Xy.dot } }, superTypes: [Di.$type] }, PegGroup: { name: Jy.$type, properties: { element: { name: Jy.element } }, superTypes: [Di.$type] }, PegIdentifier: { name: Zy.$type, properties: { name: { name: Zy.name } }, superTypes: [Di.$type] }, PegLiteral: { name: Qy.$type, properties: { value: { name: Qy.value } }, superTypes: [Di.$type] }, PegOrderedChoice: { name: eg.$type, properties: { alternatives: { name: eg.alternatives, defaultValue: [] } }, superTypes: [] }, PegPrefix: { name: lc.$type, properties: { operator: { name: lc.operator }, suffix: { name: lc.suffix } }, superTypes: [] }, PegPrimary: { name: Di.$type, properties: {}, superTypes: [] }, PegRule: { name: uc.$type, properties: { definition: { name: uc.definition }, name: { name: uc.name } }, superTypes: [] }, PegSequence: { name: tg.$type, properties: { elements: { name: tg.elements, defaultValue: [] } }, superTypes: [] }, PegSuffix: { name: cc.$type, properties: { operator: { name: cc.operator }, primary: { name: cc.primary } }, superTypes: [] }, Pie: { name: sn.$type, properties: { accDescr: { name: sn.accDescr }, accTitle: { name: sn.accTitle }, sections: { name: sn.sections, defaultValue: [] }, showData: { name: sn.showData, defaultValue: !1 }, title: { name: sn.title } }, superTypes: [] }, PieSection: { name: zo.$type, properties: { label: { name: zo.label }, value: { name: zo.value } }, superTypes: [] }, Pipeline: { name: fc.$type, properties: { components: { name: fc.components, defaultValue: [] }, parent: { name: fc.parent } }, superTypes: [] }, PipelineComponent: { name: yo.$type, properties: { evolution: { name: yo.evolution }, label: { name: yo.label }, name: { name: yo.name } }, superTypes: [] }, Radar: { name: Xr.$type, properties: { accDescr: { name: Xr.accDescr }, accTitle: { name: Xr.accTitle }, axes: { name: Xr.axes, defaultValue: [] }, curves: { name: Xr.curves, defaultValue: [] }, options: { name: Xr.options, defaultValue: [] }, title: { name: Xr.title } }, superTypes: [] }, Railroad: { name: Ta.$type, properties: { accDescr: { name: Ta.accDescr }, accTitle: { name: Ta.accTitle }, rules: { name: Ta.rules, defaultValue: [] }, title: { name: Ta.title } }, superTypes: [] }, RailroadAbnf: { name: $a.$type, properties: { accDescr: { name: $a.accDescr }, accTitle: { name: $a.accTitle }, rules: { name: $a.rules, defaultValue: [] }, title: { name: $a.title } }, superTypes: [] }, RailroadChoiceExpr: { name: rg.$type, properties: { alternatives: { name: rg.alternatives, defaultValue: [] } }, superTypes: [ir.$type] }, RailroadEbnf: { name: Ra.$type, properties: { accDescr: { name: Ra.accDescr }, accTitle: { name: Ra.accTitle }, rules: { name: Ra.rules, defaultValue: [] }, title: { name: Ra.title } }, superTypes: [] }, RailroadExpression: { name: ir.$type, properties: {}, superTypes: [] }, RailroadNonTerminalExpr: { name: ng.$type, properties: { name: { name: ng.name } }, superTypes: [ir.$type] }, RailroadOneOrMoreExpr: { name: ag.$type, properties: { element: { name: ag.element } }, superTypes: [ir.$type] }, RailroadOptionalExpr: { name: ig.$type, properties: { element: { name: ig.element } }, superTypes: [ir.$type] }, RailroadPeg: { name: Aa.$type, properties: { accDescr: { name: Aa.accDescr }, accTitle: { name: Aa.accTitle }, rules: { name: Aa.rules, defaultValue: [] }, title: { name: Aa.title } }, superTypes: [] }, RailroadRule: { name: pc.$type, properties: { definition: { name: pc.definition }, name: { name: pc.name } }, superTypes: [] }, RailroadSequenceExpr: { name: sg.$type, properties: { elements: { name: sg.elements, defaultValue: [] } }, superTypes: [ir.$type] }, RailroadSpecialExpr: { name: og.$type, properties: { text: { name: og.text } }, superTypes: [ir.$type] }, RailroadTerminalExpr: { name: lg.$type, properties: { value: { name: lg.value } }, superTypes: [ir.$type] }, RailroadZeroOrMoreExpr: { name: ug.$type, properties: { element: { name: ug.element } }, superTypes: [ir.$type] }, Section: { name: dc.$type, properties: { classSelector: { name: dc.classSelector }, name: { name: dc.name } }, superTypes: [Oi.$type] }, Service: { name: sa.$type, properties: { icon: { name: sa.icon }, iconText: { name: sa.iconText }, id: { name: sa.id }, in: { name: sa.in }, title: { name: sa.title } }, superTypes: [] }, Size: { name: mc.$type, properties: { height: { name: mc.height }, width: { name: mc.width } }, superTypes: [] }, Statement: { name: oa.$type, properties: {}, superTypes: [] }, Transition: { name: Xi.$type, properties: { from: { name: Xi.from }, label: { name: Xi.label }, to: { name: Xi.to } }, superTypes: [] }, TreeNode: { name: la.$type, properties: { classAnnotation: { name: la.classAnnotation }, descAnnotation: { name: la.descAnnotation }, iconAnnotation: { name: la.iconAnnotation }, indent: { name: la.indent }, name: { name: la.name } }, superTypes: [] }, TreeView: { name: xi.$type, properties: { accDescr: { name: xi.accDescr }, accTitle: { name: xi.accTitle }, nodes: { name: xi.nodes, defaultValue: [] }, title: { name: xi.title } }, superTypes: [] }, Treemap: { name: Ea.$type, properties: { accDescr: { name: Ea.accDescr }, accTitle: { name: Ea.accTitle }, title: { name: Ea.title }, TreemapRows: { name: Ea.TreemapRows, defaultValue: [] } }, superTypes: [] }, TreemapRow: { name: hc.$type, properties: { indent: { name: hc.indent }, item: { name: hc.item } }, superTypes: [] }, Wardley: { name: We.$type, properties: { accDescr: { name: We.accDescr }, accelerators: { name: We.accelerators, defaultValue: [] }, accTitle: { name: We.accTitle }, anchors: { name: We.anchors, defaultValue: [] }, annotation: { name: We.annotation, defaultValue: [] }, annotations: { name: We.annotations, defaultValue: [] }, components: { name: We.components, defaultValue: [] }, deaccelerators: { name: We.deaccelerators, defaultValue: [] }, evolution: { name: We.evolution }, evolves: { name: We.evolves, defaultValue: [] }, links: { name: We.links, defaultValue: [] }, notes: { name: We.notes, defaultValue: [] }, pipelines: { name: We.pipelines, defaultValue: [] }, size: { name: We.size }, title: { name: We.title } }, superTypes: [] } }; }
    static { s(this, "MermaidAstReflection"); }
}, Oe = new Nw, cg, gF = s(() => cg ?? (cg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"ArchitectureGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Architecture","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"architecture-beta"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Statement","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"groups","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"services","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"junctions","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}},{"$type":"Assignment","feature":"edges","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}},{"$type":"Assignment","feature":"alignments","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"LeftPort","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"lhsDir","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"RightPort","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"rhsDir","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}},{"$type":"Keyword","value":":"}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Arrow","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]},{"$type":"Assignment","feature":"lhsInto","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"--"},{"$type":"Group","elements":[{"$type":"Keyword","value":"-"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@30"},"arguments":[]}},{"$type":"Keyword","value":"-"}]}]},{"$type":"Assignment","feature":"rhsInto","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"Group","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"group"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Assignment","feature":"icon","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]},"cardinality":"?"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@30"},"arguments":[]},"cardinality":"?"},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Service","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"service"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"iconText","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Assignment","feature":"icon","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]}}],"cardinality":"?"},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@30"},"arguments":[]},"cardinality":"?"},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Junction","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"junction"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"in"},{"$type":"Assignment","feature":"in","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Edge","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"lhsId","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Assignment","feature":"lhsGroup","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"Assignment","feature":"rhsId","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Assignment","feature":"rhsGroup","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Alignment","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"align"},{"$type":"Assignment","feature":"direction","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"row"},{"$type":"Keyword","value":"column"}]}},{"$type":"Assignment","feature":"members","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Assignment","feature":"members","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]},"cardinality":"+"},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"ARROW_DIRECTION","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"L"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"R"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"T"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"B"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARROW_GROUP","definition":{"$type":"RegexToken","regex":"/\\\\{group\\\\}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARROW_INTO","definition":{"$type":"RegexToken","regex":"/<|>/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@19"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@20"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","name":"ARCH_ICON","definition":{"$type":"RegexToken","regex":"/\\\\([\\\\w-:]+\\\\)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARCH_TITLE","definition":{"$type":"RegexToken","regex":"/\\\\[(?:\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'|[^\\\\[\\\\]\\\\r\\\\n]+)\\\\]/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[],"types":[]}`)), "ArchitectureGrammarGrammar"), fg, vF = s(() => fg ?? (fg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"CynefinGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Cynefin","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"cynefin-beta"},{"$type":"Keyword","value":"cynefin-beta:"}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"Assignment","feature":"domains","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"transitions","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"DomainBlock","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"domain","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"},{"$type":"Group","elements":[{"$type":"Assignment","feature":"items","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"DomainItem","definition":{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Transition","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"from","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Keyword","value":"-->"},{"$type":"Assignment","feature":"to","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"DOMAIN_NAME","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"complex"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"complicated"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"clear"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"chaotic"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"confusion"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@11"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@12"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "CynefinGrammarGrammar"), pg, TF = s(() => pg ?? (pg = Ue('{"$type":"Grammar","isDeclared":true,"name":"EventModeling","interfaces":[{"$type":"Interface","name":"Common","attributes":[{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]}],"rules":[{"$type":"ParserRule","entry":true,"name":"EventModel","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"eventmodeling"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Assignment","feature":"modelEntities","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"frames","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}},{"$type":"Assignment","feature":"dataEntities","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}},{"$type":"Assignment","feature":"noteEntities","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"Assignment","feature":"gwtEntities","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmModelEntityType","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"rmo"},{"$type":"Keyword","value":"readmodel"},{"$type":"Keyword","value":"ui"},{"$type":"Keyword","value":"cmd"},{"$type":"Keyword","value":"command"},{"$type":"Keyword","value":"evt"},{"$type":"Keyword","value":"event"},{"$type":"Keyword","value":"pcr"},{"$type":"Keyword","value":"processor"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmDataType","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"json"},{"$type":"Keyword","value":"jsobj"},{"$type":"Keyword","value":"figma"},{"$type":"Keyword","value":"salt"},{"$type":"Keyword","value":"uri"},{"$type":"Keyword","value":"md"},{"$type":"Keyword","value":"html"},{"$type":"Keyword","value":"text"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"EmDataInline","definition":{"$type":"Group","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"`"},{"$type":"Assignment","feature":"dataType","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Keyword","value":"`"}],"cardinality":"?"},{"$type":"Assignment","feature":"dataInlineValue","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"EmDataBlock","definition":{"$type":"Group","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"`"},{"$type":"Assignment","feature":"dataType","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Keyword","value":"`"}],"cardinality":"?"},{"$type":"Assignment","feature":"dataBlockValue","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"QualifiedName","dataType":"string","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},{"$type":"Group","elements":[{"$type":"Keyword","value":"."},{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmTimeFrame","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"tf"},{"$type":"Keyword","value":"timeframe"}]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Assignment","feature":"modelEntityType","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"entityIdentifier","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"->>"},{"$type":"Assignment","feature":"sourceFrames","operator":"+=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@8"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}}],"cardinality":"*"},{"$type":"Group","elements":[{"$type":"Keyword","value":"[["},{"$type":"Assignment","feature":"dataReference","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@10"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"Keyword","value":"]]"}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmResetFrame","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"rf"},{"$type":"Keyword","value":"resetframe"}]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Assignment","feature":"modelEntityType","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"entityIdentifier","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"->>"},{"$type":"Assignment","feature":"sourceFrames","operator":"+=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@8"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}}],"cardinality":"*"},{"$type":"Group","elements":[{"$type":"Keyword","value":"[["},{"$type":"Assignment","feature":"dataReference","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@10"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"Keyword","value":"]]"}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmFrame","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmModelEntity","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"entity"},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmDataEntity","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"data"},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmNoteEntity","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"note"},{"$type":"Assignment","feature":"sourceFrame","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@8"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmGwt","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"gwt"},{"$type":"Assignment","feature":"sourceFrame","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@8"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"Keyword","value":"given"},{"$type":"Assignment","feature":"givenStatements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},"cardinality":"+"},{"$type":"Group","elements":[{"$type":"Keyword","value":"when"},{"$type":"Assignment","feature":"whenStatements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},"cardinality":"+"}],"cardinality":"?"},{"$type":"Keyword","value":"then"},{"$type":"Assignment","feature":"thenStatements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},"cardinality":"+"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EmGwtStatement","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]},{"$type":"Assignment","feature":"entityIdentifier","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@9"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EM_EID","dataType":"string","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EM_FI","dataType":"string","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"EM_ID","definition":{"$type":"RegexToken","regex":"/[_a-zA-Z][\\\\w_]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_FID","definition":{"$type":"RegexToken","regex":"/\\\\d{1,3}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_DATA_INLINE","definition":{"$type":"RegexToken","regex":"/\\\\{(.*)\\\\}|\\"(.*)\\"|\'(.*)\'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_DATA_BLOCK","definition":{"$type":"RegexToken","regex":"/\\\\{[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?\\\\}(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EM_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"EM_WS","definition":{"$type":"RegexToken","regex":"/\\\\s+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EM_YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EM_DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EM_SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EM_ML_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\/\\\\*[\\\\s\\\\S]*?\\\\*\\\\//","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EM_SL_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\/\\\\/[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"imports":[],"types":[]}')), "EventModelingGrammar"), dg, $F = s(() => dg ?? (dg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"GitGraphGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"GitGraph","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"Group","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"Keyword","value":":"}]},{"$type":"Keyword","value":"gitGraph:"},{"$type":"Group","elements":[{"$type":"Keyword","value":"gitGraph"},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]},{"$type":"Keyword","value":":"}]}]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]},{"$type":"Assignment","feature":"statements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Statement","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Direction","definition":{"$type":"Assignment","feature":"dir","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"LR"},{"$type":"Keyword","value":"TB"},{"$type":"Keyword","value":"BT"}]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Commit","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"commit"},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"msg:","cardinality":"?"},{"$type":"Assignment","feature":"message","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"type:"},{"$type":"Assignment","feature":"type","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"NORMAL"},{"$type":"Keyword","value":"REVERSE"},{"$type":"Keyword","value":"HIGHLIGHT"}]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Branch","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"branch"},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"order:"},{"$type":"Assignment","feature":"order","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Merge","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"merge"},{"$type":"Assignment","feature":"branch","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"type:"},{"$type":"Assignment","feature":"type","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"NORMAL"},{"$type":"Keyword","value":"REVERSE"},{"$type":"Keyword","value":"HIGHLIGHT"}]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Checkout","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"checkout"},{"$type":"Keyword","value":"switch"}]},{"$type":"Assignment","feature":"branch","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"CherryPicking","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"cherry-pick"},{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Keyword","value":"id:"},{"$type":"Assignment","feature":"id","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"tag:"},{"$type":"Assignment","feature":"tags","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"parent:"},{"$type":"Assignment","feature":"parent","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@14"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@15"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","name":"REFERENCE","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\\\w([-\\\\./\\\\w]*[-\\\\w])?/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[],"types":[]}`)), "GitGraphGrammarGrammar"), mg, RF = s(() => mg ?? (mg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"InfoGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Info","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"info"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"},{"$type":"Group","elements":[{"$type":"Keyword","value":"showInfo"},{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"*"}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[],"cardinality":"?"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@7"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@8"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "InfoGrammarGrammar"), hg, AF = s(() => hg ?? (hg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"PacketGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Packet","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"packet"},{"$type":"Keyword","value":"packet-beta"}]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]},{"$type":"Assignment","feature":"blocks","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PacketBlock","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Assignment","feature":"start","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"-"},{"$type":"Assignment","feature":"end","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}],"cardinality":"?"}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"+"},{"$type":"Assignment","feature":"bits","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}}]}]},{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@8"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@9"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "PacketGrammarGrammar"), yg, EF = s(() => yg ?? (yg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"PieGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Pie","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"*"},{"$type":"Keyword","value":"pie"},{"$type":"Assignment","feature":"showData","operator":"?=","terminal":{"$type":"Keyword","value":"showData"},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"Assignment","feature":"sections","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PieSection","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":":"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"FLOAT_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/-?[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/-?(0|[1-9][0-9]*)(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER_PIE","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@2"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@3"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@11"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@12"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "PieGrammarGrammar"), gg, bF = s(() => gg ?? (gg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"RadarGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Radar","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"radar-beta"},{"$type":"Keyword","value":"radar-beta:"},{"$type":"Group","elements":[{"$type":"Keyword","value":"radar-beta"},{"$type":"Keyword","value":":"}]}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]},{"$type":"Group","elements":[{"$type":"Keyword","value":"axis"},{"$type":"Assignment","feature":"axes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"axes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"Keyword","value":"curve"},{"$type":"Assignment","feature":"curves","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"curves","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"options","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"options","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}],"cardinality":"*"}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Label","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}},{"$type":"Keyword","value":"]"}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"Axis","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Curve","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[],"cardinality":"?"},{"$type":"Keyword","value":"{"},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]},{"$type":"Keyword","value":"}"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Entries","definition":{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"}]},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"},{"$type":"Assignment","feature":"entries","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}}],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"*"}]}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"DetailedEntry","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"axis","operator":"=","terminal":{"$type":"CrossReference","type":{"$ref":"#/rules@2"},"terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},"deprecatedSyntax":false,"isMulti":false}},{"$type":"Keyword","value":":","cardinality":"?"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"NumberEntry","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Option","definition":{"$type":"Alternatives","elements":[{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"showLegend"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"ticks"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"max"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"min"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Keyword","value":"graticule"}},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]}}]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"GRATICULE","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"circle"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"polygon"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@15"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@16"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[{"$type":"Interface","name":"Entry","attributes":[{"$type":"TypeAttribute","name":"axis","isOptional":true,"type":{"$type":"ReferenceType","referenceType":{"$type":"SimpleType","typeRef":{"$ref":"#/rules@2"}},"isMulti":false}},{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"number"},"isOptional":false}],"superTypes":[]}],"types":[]}`)), "RadarGrammarGrammar"), vg, CF = s(() => vg ?? (vg = Ue('{"$type":"Grammar","isDeclared":true,"name":"RailroadAbnfGrammar","rules":[{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ABNF_RULENAME","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[A-Za-z][A-Za-z0-9-]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ABNF_STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"[^\\"]*\\"/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ABNF_NUMVAL","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/%[xXdDbB][0-9A-Fa-f]+(?:-[0-9A-Fa-f]+|\\\\.[0-9A-Fa-f]+)*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ABNF_REPEAT","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[0-9]*\\\\*[0-9]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ABNF_EXACT_REPEAT","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[0-9]+/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"ABNF_WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t \\\\r\\\\n]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ABNF_YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ABNF_DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ABNF_SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ABNF_COMMENT","definition":{"$type":"RegexToken","regex":"/;[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"ParserRule","entry":true,"name":"RailroadAbnf","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"railroad-abnf-beta"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"},{"$type":"Assignment","feature":"rules","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfRule","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Keyword","value":"="},{"$type":"Assignment","feature":"definition","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Keyword","value":";"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfAlternation","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"/"},{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfConcatenation","returnType":{"$ref":"#/interfaces@3"},"definition":{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]},"cardinality":"+"},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfElement","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"repeat","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"repeat","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}],"cardinality":"?"},{"$type":"Assignment","feature":"primary","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfPrimary","returnType":{"$ref":"#/interfaces@5"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfStringLiteral","returnType":{"$ref":"#/interfaces@6"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfNumVal","returnType":{"$ref":"#/interfaces@7"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfRuleName","returnType":{"$ref":"#/interfaces@8"},"definition":{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfGroup","returnType":{"$ref":"#/interfaces@9"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"AbnfOptionalGroup","returnType":{"$ref":"#/interfaces@10"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Keyword","value":"]"}]},"entry":false,"fragment":false,"parameters":[]}],"interfaces":[{"$type":"Interface","name":"RailroadAbnf","attributes":[{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"rules","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@1"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"AbnfRule","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"definition","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"AbnfAlternation","attributes":[{"$type":"TypeAttribute","name":"alternatives","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@3"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"AbnfConcatenation","attributes":[{"$type":"TypeAttribute","name":"elements","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@4"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"AbnfElement","attributes":[{"$type":"TypeAttribute","name":"repeat","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"primary","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@5"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"AbnfPrimary","attributes":[],"superTypes":[]},{"$type":"Interface","name":"AbnfStringLiteral","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"AbnfNumVal","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"AbnfRuleName","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"AbnfGroup","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"AbnfOptionalGroup","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]}],"imports":[],"types":[]}')), "RailroadAbnfGrammarGrammar"), Tg, _F = s(() => Tg ?? (Tg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"RailroadEbnfGrammar","rules":[{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EBNF_ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[A-Z_a-z][\\\\w-]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EBNF_STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"EBNF_SPECIAL_SEQUENCE","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\\\?(?=[^?;]*[^?\\\\s;][^?;]*\\\\?)[^?;]*\\\\?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t \\\\r\\\\n]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_BLOCK_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\/\\\\*[\\\\s\\\\S]*?\\\\*\\\\//","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"EBNF_ISO_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\(\\\\*[\\\\s\\\\S]*?\\\\*\\\\)/","parenthesized":false},"fragment":false},{"$type":"ParserRule","entry":true,"name":"RailroadEbnf","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"railroad-ebnf-beta"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"},{"$type":"Assignment","feature":"rules","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfRule","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Alternatives","elements":[{"$type":"Keyword","value":"="},{"$type":"Keyword","value":"::="}]},{"$type":"Assignment","feature":"definition","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":";"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfChoice","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"|"},{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfSequence","returnType":{"$ref":"#/interfaces@3"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":",","cardinality":"?"},{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfTerm","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"base","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},{"$type":"Assignment","feature":"postfixes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]},"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfPrimary","returnType":{"$ref":"#/interfaces@5"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfTerminal","returnType":{"$ref":"#/interfaces@7"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfNonTerminal","returnType":{"$ref":"#/interfaces@8"},"definition":{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfSpecial","returnType":{"$ref":"#/interfaces@9"},"definition":{"$type":"Assignment","feature":"text","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfGroup","returnType":{"$ref":"#/interfaces@10"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfOptional","returnType":{"$ref":"#/interfaces@11"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":"]"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfRepetition","returnType":{"$ref":"#/interfaces@12"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"{"},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Keyword","value":"}"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfPostfix","returnType":{"$ref":"#/interfaces@6"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@25"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@26"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@27"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@28"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfOptionalPostfix","returnType":{"$ref":"#/interfaces@13"},"definition":{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"?"}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfZeroOrMorePostfix","returnType":{"$ref":"#/interfaces@14"},"definition":{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"*"}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfOneOrMorePostfix","returnType":{"$ref":"#/interfaces@15"},"definition":{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"+"}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EbnfExceptionPostfix","returnType":{"$ref":"#/interfaces@16"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"-"},{"$type":"Assignment","feature":"except","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]}],"interfaces":[{"$type":"Interface","name":"RailroadEbnf","attributes":[{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"rules","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@1"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"EbnfRule","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"definition","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"EbnfChoice","attributes":[{"$type":"TypeAttribute","name":"alternatives","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@3"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"EbnfSequence","attributes":[{"$type":"TypeAttribute","name":"elements","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@4"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"EbnfTerm","attributes":[{"$type":"TypeAttribute","name":"base","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@5"}},"isOptional":false},{"$type":"TypeAttribute","name":"postfixes","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@6"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"EbnfPrimary","attributes":[],"superTypes":[]},{"$type":"Interface","name":"EbnfPostfix","attributes":[],"superTypes":[]},{"$type":"Interface","name":"EbnfTerminal","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfNonTerminal","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfSpecial","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"text","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfGroup","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"EbnfOptional","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"EbnfRepetition","superTypes":[{"$ref":"#/interfaces@5"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"EbnfOptionalPostfix","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"operator","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfZeroOrMorePostfix","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"operator","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfOneOrMorePostfix","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"operator","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"EbnfExceptionPostfix","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"except","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@5"}},"isOptional":false}]}],"imports":[],"types":[]}`)), "RailroadEbnfGrammarGrammar"), $g, SF = s(() => $g ?? ($g = Ue(`{"$type":"Grammar","isDeclared":true,"name":"RailroadGrammar","rules":[{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"RR_ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[A-Z_a-z][\\\\w-]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"RR_STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"RR_WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t \\\\r\\\\n]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"RR_YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"RR_DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"RR_SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"RR_BLOCK_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\/\\\\*[\\\\s\\\\S]*?\\\\*\\\\//","parenthesized":false},"fragment":false},{"$type":"ParserRule","entry":true,"name":"Railroad","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"railroad-beta"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"},{"$type":"Assignment","feature":"rules","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadRule","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Keyword","value":"="},{"$type":"Assignment","feature":"definition","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":";"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadExpression","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadSequenceExpr","returnType":{"$ref":"#/interfaces@3"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"sequence"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}}],"cardinality":"*"},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadChoiceExpr","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"choice"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}}],"cardinality":"*"},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadOptionalExpr","returnType":{"$ref":"#/interfaces@5"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"optional"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadOneOrMoreExpr","returnType":{"$ref":"#/interfaces@6"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"oneOrMore"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadZeroOrMoreExpr","returnType":{"$ref":"#/interfaces@7"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"zeroOrMore"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadTerminalExpr","returnType":{"$ref":"#/interfaces@8"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"terminal"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadNonTerminalExpr","returnType":{"$ref":"#/interfaces@9"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"nonterminal"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"RailroadSpecialExpr","returnType":{"$ref":"#/interfaces@10"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"special"},{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"text","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]}],"interfaces":[{"$type":"Interface","name":"Railroad","attributes":[{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"rules","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@1"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"RailroadRule","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"definition","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"RailroadExpression","attributes":[],"superTypes":[]},{"$type":"Interface","name":"RailroadSequenceExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"elements","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}}},"isOptional":false}]},{"$type":"Interface","name":"RailroadChoiceExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"alternatives","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}}},"isOptional":false}]},{"$type":"Interface","name":"RailroadOptionalExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"RailroadOneOrMoreExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"RailroadZeroOrMoreExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"RailroadTerminalExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"RailroadNonTerminalExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"RailroadSpecialExpr","superTypes":[{"$ref":"#/interfaces@2"}],"attributes":[{"$type":"TypeAttribute","name":"text","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]}],"imports":[],"types":[]}`)), "RailroadGrammarGrammar"), Rg, wF = s(() => Rg ?? (Rg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"RailroadPegGrammar","rules":[{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"PEG_ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[A-Z_a-z][\\\\w-]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"PEG_STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"PEG_WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t \\\\r\\\\n]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"PEG_YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"PEG_DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"PEG_SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"PEG_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/#[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false},{"$type":"ParserRule","entry":true,"name":"RailroadPeg","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"railroad-peg-beta"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"*"},{"$type":"Assignment","feature":"rules","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegRule","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Keyword","value":"<-"},{"$type":"Assignment","feature":"definition","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":";"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegOrderedChoice","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"/"},{"$type":"Assignment","feature":"alternatives","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegSequence","returnType":{"$ref":"#/interfaces@3"},"definition":{"$type":"Assignment","feature":"elements","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"cardinality":"+"},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegPrefix","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"&"}},{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"!"}}],"cardinality":"?"},{"$type":"Assignment","feature":"suffix","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegSuffix","returnType":{"$ref":"#/interfaces@5"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"primary","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"?"}},{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"*"}},{"$type":"Assignment","feature":"operator","operator":"=","terminal":{"$type":"Keyword","value":"+"}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegPrimary","returnType":{"$ref":"#/interfaces@6"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegLiteral","returnType":{"$ref":"#/interfaces@7"},"definition":{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegIdentifier","returnType":{"$ref":"#/interfaces@8"},"definition":{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegGroup","returnType":{"$ref":"#/interfaces@9"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"element","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PegAny","returnType":{"$ref":"#/interfaces@10"},"definition":{"$type":"Assignment","feature":"dot","operator":"=","terminal":{"$type":"Keyword","value":"."}},"entry":false,"fragment":false,"parameters":[]}],"interfaces":[{"$type":"Interface","name":"RailroadPeg","attributes":[{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"rules","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@1"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"PegRule","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"definition","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"PegOrderedChoice","attributes":[{"$type":"TypeAttribute","name":"alternatives","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@3"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"PegSequence","attributes":[{"$type":"TypeAttribute","name":"elements","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@4"}}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"PegPrefix","attributes":[{"$type":"TypeAttribute","name":"operator","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"suffix","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@5"}},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"PegSuffix","attributes":[{"$type":"TypeAttribute","name":"primary","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@6"}},"isOptional":false},{"$type":"TypeAttribute","name":"operator","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]},{"$type":"Interface","name":"PegPrimary","attributes":[],"superTypes":[]},{"$type":"Interface","name":"PegLiteral","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"PegIdentifier","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]},{"$type":"Interface","name":"PegGroup","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"element","type":{"$type":"SimpleType","typeRef":{"$ref":"#/interfaces@2"}},"isOptional":false}]},{"$type":"Interface","name":"PegAny","superTypes":[{"$ref":"#/interfaces@6"}],"attributes":[{"$type":"TypeAttribute","name":"dot","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}]}],"imports":[],"types":[]}`)), "RailroadPegGrammarGrammar"), Ag, IF = s(() => Ag ?? (Ag = Ue(`{"$type":"Grammar","isDeclared":true,"name":"TreemapGrammar","rules":[{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","entry":true,"name":"Treemap","returnType":{"$ref":"#/interfaces@4"},"definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]},{"$type":"Assignment","feature":"TreemapRows","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"TREEMAP_KEYWORD","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"treemap-beta"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"treemap"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"CLASS_DEF","definition":{"$type":"RegexToken","regex":"/classDef\\\\s+([a-zA-Z_][a-zA-Z0-9_]+)(?:\\\\s+([^;\\\\r\\\\n]*))?(?:;)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STYLE_SEPARATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":":::"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"SEPARATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":":"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"COMMA","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":","},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INDENTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]{1,}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WS","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ML_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\%\\\\%[^\\\\n]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"NL","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false},{"$type":"ParserRule","name":"TreemapRow","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"indent","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"item","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"ClassDef","dataType":"string","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Item","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Section","returnType":{"$ref":"#/interfaces@1"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},{"$type":"Assignment","feature":"classSelector","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Leaf","returnType":{"$ref":"#/interfaces@2"},"definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[],"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[],"cardinality":"?"},{"$type":"Assignment","feature":"value","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},{"$type":"Assignment","feature":"classSelector","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"ID2","definition":{"$type":"RegexToken","regex":"/[a-zA-Z_][a-zA-Z0-9_]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER2","definition":{"$type":"RegexToken","regex":"/[0-9_\\\\.\\\\,]+/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"MyNumber","dataType":"number","definition":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"STRING2","definition":{"$type":"RegexToken","regex":"/\\"[^\\"]*\\"|'[^']*'/","parenthesized":false},"fragment":false,"hidden":false}],"interfaces":[{"$type":"Interface","name":"Item","attributes":[{"$type":"TypeAttribute","name":"name","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"classSelector","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]},{"$type":"Interface","name":"Section","superTypes":[{"$ref":"#/interfaces@0"}],"attributes":[]},{"$type":"Interface","name":"Leaf","superTypes":[{"$ref":"#/interfaces@0"}],"attributes":[{"$type":"TypeAttribute","name":"value","type":{"$type":"SimpleType","primitiveType":"number"},"isOptional":false}]},{"$type":"Interface","name":"ClassDefStatement","attributes":[{"$type":"TypeAttribute","name":"className","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false},{"$type":"TypeAttribute","name":"styleText","type":{"$type":"SimpleType","primitiveType":"string"},"isOptional":false}],"superTypes":[]},{"$type":"Interface","name":"Treemap","attributes":[{"$type":"TypeAttribute","name":"TreemapRows","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/rules@15"}}},"isOptional":false},{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]}],"imports":[],"types":[],"$comment":"/**\\n * Treemap grammar for Langium\\n * Converted from mindmap grammar\\n *\\n * The ML_COMMENT and NL hidden terminals handle whitespace, comments, and newlines\\n * before the treemap keyword, allowing for empty lines and comments before the\\n * treemap declaration.\\n */"}`)), "TreemapGrammarGrammar"), Eg, NF = s(() => Eg ?? (Eg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"TreeViewGrammar","rules":[{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","entry":true,"name":"TreeView","returnType":{"$ref":"#/interfaces@0"},"definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"treeView-beta"},{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[],"cardinality":"?"},{"$type":"Assignment","feature":"nodes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]},"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@0"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"CLASS_ANNOTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+:::[ \\\\t]*[A-Za-z_][\\\\w-]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ICON_ANNOTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+icon\\\\([\\\\w-]*(?::[\\\\w-]+)?\\\\)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"DESC_ANNOTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+##[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INDENTATION","definition":{"$type":"RegexToken","regex":"/[ \\\\t]{1,}/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"QUOTED_NAME","definition":{"$type":"RegexToken","regex":"/\\"[^\\"]*\\"|'[^']*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WS","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"ML_COMMENT","definition":{"$type":"RegexToken","regex":"/\\\\%\\\\%[^\\\\n]*/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"NL","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","name":"BARE_NAME","definition":{"$type":"RegexToken","regex":"/(?!:::|icon\\\\(|##)[^ \\\\t\\\\n\\\\r\\"'](?:(?![ \\\\t]+:::[ \\\\t]*[A-Za-z_]|[ \\\\t]+icon\\\\(|[ \\\\t]+##)[^\\\\n\\\\r])*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"ParserRule","name":"TreeNode","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"indent","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}}]},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"classAnnotation","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"iconAnnotation","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"descAnnotation","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]}}],"cardinality":"*"}]},"entry":false,"fragment":false,"parameters":[]}],"interfaces":[{"$type":"Interface","name":"TreeView","attributes":[{"$type":"TypeAttribute","name":"nodes","type":{"$type":"ArrayType","elementType":{"$type":"SimpleType","typeRef":{"$ref":"#/rules@14"}}},"isOptional":false},{"$type":"TypeAttribute","name":"title","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accTitle","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}},{"$type":"TypeAttribute","name":"accDescr","isOptional":true,"type":{"$type":"SimpleType","primitiveType":"string"}}],"superTypes":[]}],"imports":[],"types":[],"$comment":"/**\\n * TreeView grammar for Langium\\n *\\n * Supports both quoted labels (\\"my file\\") and bare labels (index.js).\\n * Annotations (:::class, icon(), ## description) are parsed directly into\\n * AST fields by the grammar. Value conversion for stripping quotes, extracting\\n * class names, icon names, and description text happens in valueConverter.ts.\\n *\\n * The ML_COMMENT and NL hidden terminals handle whitespace, comments, and newlines\\n * before the treeView keyword, allowing for empty lines and comments before the\\n * treeView declaration.\\n */"}`)), "TreeViewGrammarGrammar"), bg, PF = s(() => bg ?? (bg = Ue(`{"$type":"Grammar","isDeclared":true,"name":"WardleyGrammar","imports":[],"rules":[{"$type":"ParserRule","entry":true,"name":"Wardley","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@52"},"arguments":[],"cardinality":"*"},{"$type":"RuleCall","rule":{"$ref":"#/rules@25"},"arguments":[]},{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@52"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@42"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@1"},"arguments":[]}],"cardinality":"*"}]},"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"Statement","definition":{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"size","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@2"},"arguments":[]}},{"$type":"Assignment","feature":"evolution","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@3"},"arguments":[]}},{"$type":"Assignment","feature":"anchors","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@5"},"arguments":[]}},{"$type":"Assignment","feature":"components","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@6"},"arguments":[]}},{"$type":"Assignment","feature":"links","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@9"},"arguments":[]}},{"$type":"Assignment","feature":"evolves","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@10"},"arguments":[]}},{"$type":"Assignment","feature":"pipelines","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@11"},"arguments":[]}},{"$type":"Assignment","feature":"notes","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@13"},"arguments":[]}},{"$type":"Assignment","feature":"annotations","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@14"},"arguments":[]}},{"$type":"Assignment","feature":"annotation","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@15"},"arguments":[]}},{"$type":"Assignment","feature":"accelerators","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@17"},"arguments":[]}},{"$type":"Assignment","feature":"deaccelerators","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@18"},"arguments":[]}}]},"entry":false,"parameters":[]},{"$type":"ParserRule","name":"Size","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@26"},"arguments":[]},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"width","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"height","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Evolution","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@27"},"arguments":[]},{"$type":"Assignment","feature":"stages","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]},{"$type":"Assignment","feature":"stages","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@4"},"arguments":[]}}],"cardinality":"+"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"EvolutionStage","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"@"},{"$type":"Assignment","feature":"boundary","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}}],"cardinality":"?"},{"$type":"Group","elements":[{"$type":"Keyword","value":"/"},{"$type":"Assignment","feature":"secondName","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}}],"cardinality":"?"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Anchor","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@28"},"arguments":[]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"visibility","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"evolution","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Component","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"visibility","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"evolution","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]},"cardinality":"?"},{"$type":"Assignment","feature":"decorator","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@8"},"arguments":[]},"cardinality":"?"},{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"inertia","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@31"},"arguments":[]}},{"$type":"Group","elements":[{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"inertia","operator":"?=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@31"},"arguments":[]}},{"$type":"Keyword","value":")"}]}],"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Label","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@30"},"arguments":[]},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"negX","operator":"?=","terminal":{"$type":"Keyword","value":"-"},"cardinality":"?"},{"$type":"Assignment","feature":"offsetX","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"negY","operator":"?=","terminal":{"$type":"Keyword","value":"-"},"cardinality":"?"},{"$type":"Assignment","feature":"offsetY","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}},{"$type":"Keyword","value":"]"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Decorator","definition":{"$type":"Group","elements":[{"$type":"Keyword","value":"("},{"$type":"Assignment","feature":"strategy","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@24"},"arguments":[]}},{"$type":"Keyword","value":")"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Link","definition":{"$type":"Group","elements":[{"$type":"Assignment","feature":"from","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Assignment","feature":"fromPort","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},"cardinality":"?"},{"$type":"Assignment","feature":"arrow","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@22"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@20"},"arguments":[]}]},"cardinality":"?"},{"$type":"Assignment","feature":"to","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Assignment","feature":"toPort","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@21"},"arguments":[]},"cardinality":"?"},{"$type":"Assignment","feature":"linkLabel","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@23"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Evolve","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@32"},"arguments":[]},{"$type":"Assignment","feature":"component","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Assignment","feature":"target","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Pipeline","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@33"},"arguments":[]},{"$type":"Assignment","feature":"parent","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"{"},{"$type":"RuleCall","rule":{"$ref":"#/rules@52"},"arguments":[],"cardinality":"+"},{"$type":"Assignment","feature":"components","operator":"+=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@12"},"arguments":[]},"cardinality":"+"},{"$type":"Keyword","value":"}"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"PipelineComponent","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@29"},"arguments":[]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"evolution","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"Assignment","feature":"label","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@7"},"arguments":[]},"cardinality":"?"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Note","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@34"},"arguments":[]},{"$type":"Assignment","feature":"text","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"visibility","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"evolution","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Annotations","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@35"},"arguments":[]},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"x","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"y","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Annotation","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@36"},"arguments":[]},{"$type":"Assignment","feature":"number","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"x","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"y","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@16"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"Assignment","feature":"text","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]}},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"CoordinateValue","dataType":"number","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@48"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Accelerator","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@37"},"arguments":[]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"x","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"y","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","name":"Deaccelerator","definition":{"$type":"Group","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@38"},"arguments":[]},{"$type":"Assignment","feature":"name","operator":"=","terminal":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@50"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@51"},"arguments":[]},{"$type":"RuleCall","rule":{"$ref":"#/rules@39"},"arguments":[]}]}},{"$type":"Keyword","value":"["},{"$type":"Assignment","feature":"x","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":","},{"$type":"Assignment","feature":"y","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@19"},"arguments":[]}},{"$type":"Keyword","value":"]"},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"TerminalRule","name":"WARDLEY_NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ARROW","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"->"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"LINK_PORT","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"+<>"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"+>"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"+<"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"LINK_ARROW","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"-->"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"-.->"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":">"},"parenthesized":false}],"parenthesized":false},{"$type":"RegexToken","regex":"/\\\\+'[^']*'<>/","parenthesized":false}],"parenthesized":false},{"$type":"RegexToken","regex":"/\\\\+'[^']*'</","parenthesized":false}],"parenthesized":false},{"$type":"RegexToken","regex":"/\\\\+'[^']*'>/","parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"LINK_LABEL","definition":{"$type":"RegexToken","regex":"/;[^\\\\n\\\\r]+/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRATEGY","definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"build"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"buy"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"outsource"},"parenthesized":false}],"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"market"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_WARDLEY","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"wardley-beta"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_SIZE","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"size"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_EVOLUTION","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"evolution"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_ANCHOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"anchor"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_COMPONENT","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"component"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_LABEL","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"label"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_INERTIA","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"inertia"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_EVOLVE","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"evolve"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_PIPELINE","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"pipeline"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_NOTE","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"note"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_ANNOTATIONS","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"annotations"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_ANNOTATION","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"annotation"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_ACCELERATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"accelerator"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"KW_DEACCELERATOR","definition":{"$type":"CharacterRange","left":{"$type":"Keyword","value":"deaccelerator"},"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NAME_WITH_SPACES","definition":{"$type":"RegexToken","regex":"/(?!title\\\\s|accTitle|accDescr)[A-Za-z](?:[A-Za-z0-9_()&]|-(?!>))*(?:[ \\\\t]+[A-Za-z(](?:[A-Za-z0-9_()&]|-(?!>))*)*/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WS","definition":{"$type":"RegexToken","regex":"/[ \\\\t]+/","parenthesized":false},"fragment":false},{"$type":"ParserRule","name":"EOL","dataType":"string","definition":{"$type":"Alternatives","elements":[{"$type":"RuleCall","rule":{"$ref":"#/rules@52"},"arguments":[],"cardinality":"+"},{"$type":"EndOfFile"}]},"entry":false,"fragment":false,"parameters":[]},{"$type":"ParserRule","fragment":true,"name":"TitleAndAccessibilities","definition":{"$type":"Group","elements":[{"$type":"Alternatives","elements":[{"$type":"Assignment","feature":"accDescr","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@44"},"arguments":[]}},{"$type":"Assignment","feature":"accTitle","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@45"},"arguments":[]}},{"$type":"Assignment","feature":"title","operator":"=","terminal":{"$type":"RuleCall","rule":{"$ref":"#/rules@46"},"arguments":[]}}]},{"$type":"RuleCall","rule":{"$ref":"#/rules@41"},"arguments":[]}],"cardinality":"+"},"entry":false,"parameters":[]},{"$type":"TerminalRule","name":"BOOLEAN","type":{"$type":"ReturnType","name":"boolean"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"CharacterRange","left":{"$type":"Keyword","value":"true"},"parenthesized":false},{"$type":"CharacterRange","left":{"$type":"Keyword","value":"false"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_DESCR","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accDescr(?:[\\\\t ]*:([^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)|\\\\s*{([^}]*)})/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ACC_TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*accTitle[\\\\t ]*:(?:[^\\\\n\\\\r]*?(?=%%)|[^\\\\n\\\\r]*)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"TITLE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*title(?:[\\\\t ][^\\\\n\\\\r]*?(?=%%)|[\\\\t ][^\\\\n\\\\r]*|)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"FLOAT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/[0-9]+\\\\.[0-9]+(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"INT","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"RegexToken","regex":"/0|[1-9][0-9]*(?!\\\\.)/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NUMBER","type":{"$type":"ReturnType","name":"number"},"definition":{"$type":"TerminalAlternatives","elements":[{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@47"},"parenthesized":false},{"$type":"TerminalRuleCall","rule":{"$ref":"#/rules@48"},"parenthesized":false}],"parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"STRING","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/\\"([^\\"\\\\\\\\]|\\\\\\\\.)*\\"|'([^'\\\\\\\\]|\\\\\\\\.)*'/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"ID","type":{"$type":"ReturnType","name":"string"},"definition":{"$type":"RegexToken","regex":"/[\\\\w]([-\\\\w]*\\\\w)?/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","name":"NEWLINE","definition":{"$type":"RegexToken","regex":"/\\\\r?\\\\n/","parenthesized":false},"fragment":false,"hidden":false},{"$type":"TerminalRule","hidden":true,"name":"WHITESPACE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]+/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"YAML","definition":{"$type":"RegexToken","regex":"/---[\\\\t ]*\\\\r?\\\\n(?:[\\\\S\\\\s]*?\\\\r?\\\\n)?---(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"DIRECTIVE","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%{[\\\\S\\\\s]*?}%%(?:\\\\r?\\\\n|(?!\\\\S))/","parenthesized":false},"fragment":false},{"$type":"TerminalRule","hidden":true,"name":"SINGLE_LINE_COMMENT","definition":{"$type":"RegexToken","regex":"/[\\\\t ]*%%[^\\\\n\\\\r]*/","parenthesized":false},"fragment":false}],"interfaces":[],"types":[]}`)), "WardleyGrammarGrammar"), kF = { languageId: "architecture", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, OF = { languageId: "cynefin", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, LF = { languageId: "eventmodeling", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, DF = { languageId: "gitGraph", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, xF = { languageId: "info", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, MF = { languageId: "packet", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, GF = { languageId: "pie", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, FF = { languageId: "radar", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, zF = { languageId: "railroadAbnf", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, jF = { languageId: "railroadEbnf", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, UF = { languageId: "railroad", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, BF = { languageId: "railroadPeg", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, KF = { languageId: "treemap", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, qF = { languageId: "treeView", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, WF = { languageId: "wardley", fileExtensions: [".mmd", ".mermaid"], caseInsensitive: !1, mode: "production" }, tz = { AstReflection: s(() => new Nw, "AstReflection") }, rz = { Grammar: s(() => gF(), "Grammar"), LanguageMetaData: s(() => kF, "LanguageMetaData"), parser: {} }, nz = { Grammar: s(() => vF(), "Grammar"), LanguageMetaData: s(() => OF, "LanguageMetaData"), parser: {} }, az = { Grammar: s(() => TF(), "Grammar"), LanguageMetaData: s(() => LF, "LanguageMetaData"), parser: {} }, iz = { Grammar: s(() => $F(), "Grammar"), LanguageMetaData: s(() => DF, "LanguageMetaData"), parser: {} }, sz = { Grammar: s(() => RF(), "Grammar"), LanguageMetaData: s(() => xF, "LanguageMetaData"), parser: {} }, oz = { Grammar: s(() => AF(), "Grammar"), LanguageMetaData: s(() => MF, "LanguageMetaData"), parser: {} }, lz = { Grammar: s(() => EF(), "Grammar"), LanguageMetaData: s(() => GF, "LanguageMetaData"), parser: {} }, uz = { Grammar: s(() => bF(), "Grammar"), LanguageMetaData: s(() => FF, "LanguageMetaData"), parser: {} }, cz = { Grammar: s(() => CF(), "Grammar"), LanguageMetaData: s(() => zF, "LanguageMetaData"), parser: {} }, fz = { Grammar: s(() => _F(), "Grammar"), LanguageMetaData: s(() => jF, "LanguageMetaData"), parser: {} }, pz = { Grammar: s(() => SF(), "Grammar"), LanguageMetaData: s(() => UF, "LanguageMetaData"), parser: {} }, dz = { Grammar: s(() => wF(), "Grammar"), LanguageMetaData: s(() => BF, "LanguageMetaData"), parser: {} }, mz = { Grammar: s(() => IF(), "Grammar"), LanguageMetaData: s(() => KF, "LanguageMetaData"), parser: {} }, hz = { Grammar: s(() => NF(), "Grammar"), LanguageMetaData: s(() => qF, "LanguageMetaData"), parser: {} }, yz = { Grammar: s(() => PF(), "Grammar"), LanguageMetaData: s(() => WF, "LanguageMetaData"), parser: {} }, VF = /accDescr(?:[\t ]*:([^\n\r]*)|\s*{([^}]*)})/, HF = /accTitle[\t ]*:([^\n\r]*)/, YF = /title([\t ][^\n\r]*|)/, XF = { ACC_DESCR: VF, ACC_TITLE: HF, TITLE: YF }, JF = class extends Pm {
    static { s(this, "AbstractMermaidValueConverter"); }
    runConverter(e, t, r) { let n = this.runCommonConverter(e, t, r); return n === void 0 && (n = this.runCustomConverter(e, t, r)), n === void 0 ? super.runConverter(e, t, r) : n; }
    runCommonConverter(e, t, r) {
        let n = XF[e.name];
        if (n === void 0)
            return;
        let a = n.exec(t);
        if (a !== null) {
            if (a[1] !== void 0)
                return a[1].trim().replace(/[\t ]{2,}/gm, " ");
            if (a[2] !== void 0)
                return a[2].replace(/^\s*/gm, "").replace(/\s+$/gm, "").replace(/[\t ]{2,}/gm, " ").replace(/[\n\r]{2,}/gm, `
`);
        }
    }
}, gz = class extends JF {
    static { s(this, "CommonValueConverter"); }
    runCustomConverter(e, t, r) { }
}, ZF = class extends Pu {
    static { s(this, "AbstractMermaidTokenBuilder"); }
    constructor(e) { super(), this.keywords = new Set(e); }
    buildKeywordTokens(e, t, r) { let n = super.buildKeywordTokens(e, t, r); return n.forEach(a => { this.keywords.has(a.name) && a.PATTERN !== void 0 && (a.PATTERN = new RegExp(a.PATTERN.toString() + "(?:(?=%%)|(?!\\S))")); }), n; }
}, vz = class extends ZF {
    static { s(this, "CommonTokenBuilder"); }
};
export { s as a, Xm as b, Jm as c, Il as d, Sw as e, rF as f, tz as g, rz as h, nz as i, az as j, iz as k, sz as l, oz as m, lz as n, uz as o, cz as p, fz as q, pz as r, dz as s, mz as t, hz as u, yz as v, JF as w, gz as x, ZF as y };
/*! Bundled license information:

@mermaid-js/parser/dist/chunks/mermaid-parser.core/chunk-FOHPRMQF.mjs:
  (*! Bundled license information:
  
  lodash-es/lodash.js:
    (**
     * @license
     * Lodash (Custom Build) <https://lodash.com/>
     * Build: `lodash modularize exports="es" -o ./`
     * Copyright OpenJS Foundation and other contributors <https://openjsf.org/>
     * Released under MIT license <https://lodash.com/license>
     * Based on Underscore.js 1.8.3 <http://underscorejs.org/LICENSE>
     * Copyright Jeremy Ashkenas, DocumentCloud and Investigative Reporters & Editors
     *)
  *)
*/
