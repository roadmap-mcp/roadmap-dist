import * as a from "@angular/core";
import { ElementRef as w, NgModuleRef as p, Injector as _, EnvironmentInjector as v, createComponent as R, inject as r, TemplateRef as g, ViewContainerRef as m, DOCUMENT as D, EventEmitter as P } from "@angular/core";
var s = class {
    _attachedHost = null;
    attach(e) { return this._attachedHost = e, e.attach(this); }
    detach() { let e = this._attachedHost; e != null && (this._attachedHost = null, e.detach()); }
    get isAttached() { return this._attachedHost != null; }
    setAttachedHost(e) { this._attachedHost = e; }
}, l = class extends s {
    component;
    viewContainerRef;
    injector;
    projectableNodes;
    bindings;
    constructor(e, t, n, o, c) { super(), this.component = e, this.viewContainerRef = t, this.injector = n, this.projectableNodes = o, this.bindings = c || null; }
}, d = class extends s {
    templateRef;
    viewContainerRef;
    context;
    injector;
    constructor(e, t, n, o) { super(), this.templateRef = e, this.viewContainerRef = t, this.context = n, this.injector = o; }
    get origin() { return this.templateRef.elementRef; }
    attach(e, t = this.context) { return this.context = t, super.attach(e); }
    detach() { return this.context = void 0, super.detach(); }
}, u = class extends s {
    element;
    constructor(e) { super(), this.element = e instanceof w ? e.nativeElement : e; }
}, h = class {
    _attachedPortal = null;
    _disposeFn = null;
    _isDisposed = !1;
    hasAttached() { return !!this._attachedPortal; }
    attach(e) { if (e instanceof l)
        return this._attachedPortal = e, this.attachComponentPortal(e); if (e instanceof d)
        return this._attachedPortal = e, this.attachTemplatePortal(e); if (this.attachDomPortal && e instanceof u)
        return this._attachedPortal = e, this.attachDomPortal(e); }
    attachDomPortal = null;
    detach() { this._attachedPortal && (this._attachedPortal.setAttachedHost(null), this._attachedPortal = null), this._invokeDisposeFn(); }
    dispose() { this.hasAttached() && this.detach(), this._invokeDisposeFn(), this._isDisposed = !0; }
    setDisposeFn(e) { this._disposeFn = e; }
    _invokeDisposeFn() { this._disposeFn && (this._disposeFn(), this._disposeFn = null); }
}, f = class extends h {
    outletElement;
    _appRef;
    _defaultInjector;
    constructor(e, t, n) { super(), this.outletElement = e, this._appRef = t, this._defaultInjector = n; }
    attachComponentPortal(e) { let t; if (e.viewContainerRef) {
        let n = e.injector || e.viewContainerRef.injector, o = n.get(p, null, { optional: !0 }) || void 0;
        t = e.viewContainerRef.createComponent(e.component, { index: e.viewContainerRef.length, injector: n, ngModuleRef: o, projectableNodes: e.projectableNodes || void 0, bindings: e.bindings || void 0 }), this.setDisposeFn(() => t.destroy());
    }
    else {
        let n = this._appRef, o = e.injector || this._defaultInjector || _.NULL, c = o.get(v, n.injector);
        t = R(e.component, { elementInjector: o, environmentInjector: c, projectableNodes: e.projectableNodes || void 0, bindings: e.bindings || void 0 }), n.attachView(t.hostView), this.setDisposeFn(() => { n.viewCount > 0 && n.detachView(t.hostView), t.destroy(); });
    } return this.outletElement.appendChild(this._getComponentRootNode(t)), this._attachedPortal = e, t; }
    attachTemplatePortal(e) { let t = e.viewContainerRef, n = t.createEmbeddedView(e.templateRef, e.context, { injector: e.injector }); return n.rootNodes.forEach(o => this.outletElement.appendChild(o)), n.detectChanges(), this.setDisposeFn(() => { let o = t.indexOf(n); o !== -1 && t.remove(o); }), this._attachedPortal = e, n; }
    attachDomPortal = e => { let t = e.element; t.parentNode; let n = this.outletElement.ownerDocument.createComment("dom-portal"); t.parentNode.insertBefore(n, t), this.outletElement.appendChild(t), this._attachedPortal = e, super.setDisposeFn(() => { n.parentNode && n.parentNode.replaceChild(t, n); }); };
    dispose() { super.dispose(), this.outletElement.remove(); }
    _getComponentRootNode(e) { return e.hostView.rootNodes[0]; }
}, M = (() => { class i extends d {
    constructor() { let t = r(g), n = r(m); super(t, n); }
    static \u0275fac = function (n) { return new (n || i); };
    static \u0275dir = a.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkPortal", ""]], exportAs: ["cdkPortal"], features: [a.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), A = (() => { class i extends h {
    _moduleRef = r(p, { optional: !0 });
    _document = r(D);
    _viewContainerRef = r(m);
    _isInitialized = !1;
    _attachedRef = null;
    constructor() { super(); }
    get portal() { return this._attachedPortal; }
    set portal(t) { this.hasAttached() && !t && !this._isInitialized || (this.hasAttached() && super.detach(), t && super.attach(t), this._attachedPortal = t || null); }
    attached = new P;
    get attachedRef() { return this._attachedRef; }
    ngOnInit() { this._isInitialized = !0; }
    ngOnDestroy() { super.dispose(), this._attachedRef = this._attachedPortal = null; }
    attachComponentPortal(t) { t.setAttachedHost(this); let n = t.viewContainerRef != null ? t.viewContainerRef : this._viewContainerRef, o = n.createComponent(t.component, { index: n.length, injector: t.injector || n.injector, projectableNodes: t.projectableNodes || void 0, ngModuleRef: this._moduleRef || void 0, bindings: t.bindings || void 0 }); return n !== this._viewContainerRef && this._getRootNode().appendChild(o.hostView.rootNodes[0]), super.setDisposeFn(() => o.destroy()), this._attachedPortal = t, this._attachedRef = o, this.attached.emit(o), o; }
    attachTemplatePortal(t) { t.setAttachedHost(this); let n = this._viewContainerRef.createEmbeddedView(t.templateRef, t.context, { injector: t.injector }); return super.setDisposeFn(() => this._viewContainerRef.clear()), this._attachedPortal = t, this._attachedRef = n, this.attached.emit(n), n; }
    attachDomPortal = t => { let n = t.element; n.parentNode; let o = this._document.createComment("dom-portal"); t.setAttachedHost(this), n.parentNode.insertBefore(o, n), this._getRootNode().appendChild(n), this._attachedPortal = t, super.setDisposeFn(() => { o.parentNode && o.parentNode.replaceChild(n, o); }); };
    _getRootNode() { let t = this._viewContainerRef.element.nativeElement; return t.nodeType === t.ELEMENT_NODE ? t : t.parentNode; }
    static \u0275fac = function (n) { return new (n || i); };
    static \u0275dir = a.\u0275\u0275defineDirective({ type: i, selectors: [["", "cdkPortalOutlet", ""]], inputs: { portal: [0, "cdkPortalOutlet", "portal"] }, outputs: { attached: "attached" }, exportAs: ["cdkPortalOutlet"], features: [a.\u0275\u0275InheritDefinitionFeature] });
} return i; })(), b = (() => { class i {
    static \u0275fac = function (n) { return new (n || i); };
    static \u0275mod = a.\u0275\u0275defineNgModule({ type: i });
    static \u0275inj = a.\u0275\u0275defineInjector({});
} return i; })();
export { s as a, l as b, d as c, u as d, h as e, f, M as g, A as h, b as i };
