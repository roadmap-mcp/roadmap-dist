"""On-disk TTL cache for fetched Trello data (self-contained; plugins never
import each other, so this is not shared with the jira/bitbucket caches)."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path


class TrelloCache:
    def __init__(self, cache_dir: str, refresh_duration: int):
        self._root = Path(cache_dir)
        self._ttl = refresh_duration

    def card_path(self, card_id: str) -> Path:
        return self._root / "trello" / "cards" / f"{card_id}.json"

    def board_cards_path(self, board_id: str) -> Path:
        return self._root / "trello" / "boards" / f"{board_id}-cards.json"

    def is_fresh(self, path: Path) -> bool:
        if not path.exists():
            return False
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            cached_at = datetime.fromisoformat(data["_cached_at"])
            return (datetime.now(timezone.utc) - cached_at).total_seconds() < self._ttl
        except Exception:
            return False

    def read(self, path: Path) -> dict | None:
        if not self.is_fresh(path):
            return None
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except Exception:
            return None

    def write(self, path: Path, data: dict) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        data["_cached_at"] = datetime.now(timezone.utc).isoformat()
        path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
