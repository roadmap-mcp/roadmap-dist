"""The file-based user store: ``users.yaml`` next to the base config.

Server-level, like the roles it holds (a role is not per workspace). Passwords are
scrypt hashes; API tokens are shown once and kept only as a SHA-256 hash. Browser
sessions live in memory: a restart signs everyone out, which is also what makes a
lost cookie harmless after one.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import re
import secrets
import threading
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import yaml

from roadmap_framework import Role, User

USERNAME_RE = re.compile(r"^[a-z0-9][a-z0-9._-]{0,63}$")
MIN_PASSWORD = 8
#: a browser session ends after this long without a request
SESSION_IDLE_SECONDS = 12 * 3600
TOKEN_PREFIX = "rm_"

_SCRYPT = {"n": 2 ** 14, "r": 8, "p": 1}


def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _older_than(stamp: str, seconds: int) -> bool:
    try:
        return (datetime.now(timezone.utc) - datetime.fromisoformat(stamp)).total_seconds() > seconds
    except (TypeError, ValueError):
        return True


def hash_password(password: str) -> str:
    salt = secrets.token_bytes(16)
    digest = hashlib.scrypt(password.encode(), salt=salt, dklen=32, **_SCRYPT)
    return "scrypt$" + base64.b64encode(salt).decode() + "$" + base64.b64encode(digest).decode()


def check_password(password: str, stored: str) -> bool:
    try:
        scheme, salt_b64, digest_b64 = stored.split("$")
        if scheme != "scrypt":
            return False
        digest = hashlib.scrypt(password.encode(), salt=base64.b64decode(salt_b64), dklen=32, **_SCRYPT)
        return hmac.compare_digest(digest, base64.b64decode(digest_b64))
    except Exception:
        return False


def _token_hash(token: str) -> str:
    return hashlib.sha256(token.encode()).hexdigest()


class UserError(ValueError):
    """A request the store refuses, with the reason."""


class FileUserStore:
    """Implements the framework's ``AuthProvider`` (``setup_required``,
    ``user_for_session``, ``user_for_token``) plus what the users plugin's
    endpoints need."""

    def __init__(self, path: Path) -> None:
        self.path = path
        self._lock = threading.RLock()
        self._sessions: dict[str, tuple[str, float]] = {}

    # ── the file ──
    def _load(self) -> list[dict]:
        if not self.path.exists():
            return []
        with open(self.path, encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
        return [u for u in data.get("users") or [] if isinstance(u, dict)]

    def _save(self, users: list[dict]) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        tmp = self.path.with_suffix(".tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            yaml.safe_dump({"users": users}, f, sort_keys=False, allow_unicode=True)
        tmp.replace(self.path)

    @staticmethod
    def _user(u: dict) -> User:
        try:
            role = Role(u.get("role") or "viewer")
        except ValueError:
            role = Role.VIEWER
        return User(username=u["username"], name=u.get("name") or u["username"], role=role,
                    root=bool(u.get("root")))

    def _find(self, users: list[dict], username: str) -> Optional[dict]:
        return next((u for u in users if u.get("username") == username), None)

    # ── AuthProvider ──
    def setup_required(self) -> bool:
        with self._lock:
            return not any(u.get("root") for u in self._load())

    def user_for_session(self, session_id: str) -> Optional[User]:
        with self._lock:
            hit = self._sessions.get(session_id)
            if hit is None:
                return None
            username, last = hit
            if time.time() - last > SESSION_IDLE_SECONDS:
                self._sessions.pop(session_id, None)
                return None
            u = self._find(self._load(), username)
            if u is None:                       # removed while signed in
                self._sessions.pop(session_id, None)
                return None
            self._sessions[session_id] = (username, time.time())
            return self._user(u)

    def user_for_token(self, token: str) -> Optional[User]:
        if not token.startswith(TOKEN_PREFIX):
            return None
        h = _token_hash(token)
        with self._lock:
            users = self._load()
            for u in users:
                for t in u.get("tokens") or []:
                    if hmac.compare_digest(str(t.get("hash", "")), h):
                        # an MCP client sends it on every call: record use at most
                        # every few minutes, not a file write per call
                        if _older_than(t.get("last_used", ""), 300):
                            t["last_used"] = _now()
                            self._save(users)
                        return self._user(u)
        return None

    # ── signing in ──
    def setup_root(self, username: str, password: str, name: str = "") -> User:
        with self._lock:
            if not self.setup_required():
                raise UserError("Roadmap already has a root user.")
            self._check_username(username)
            self._check_password(password)
            users = [u for u in self._load() if u.get("username") != username]
            users.insert(0, {"username": username, "name": name or username, "role": "admin",
                             "root": True, "password": hash_password(password),
                             "created": _now(), "tokens": []})
            self._save(users)
            return self._user(users[0])

    def login(self, username: str, password: str) -> tuple[str, User]:
        with self._lock:
            u = self._find(self._load(), username.strip().lower())
        # the same answer, and roughly the same time, for a wrong name and a wrong password
        ok = check_password(password, u.get("password", "") if u else hash_password("x"))
        if u is None or not ok:
            raise UserError("Wrong user name or password.")
        sid = secrets.token_urlsafe(32)
        with self._lock:
            self._sessions[sid] = (u["username"], time.time())
        return sid, self._user(u)

    def logout(self, session_id: str) -> None:
        with self._lock:
            self._sessions.pop(session_id, None)

    def _end_sessions(self, username: str) -> None:
        for sid, (who, _) in list(self._sessions.items()):
            if who == username:
                self._sessions.pop(sid, None)

    # ── one's own account ──
    def change_password(self, username: str, current: str, new: str) -> None:
        self._check_password(new)
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None or not check_password(current, u.get("password", "")):
                raise UserError("The current password is not right.")
            u["password"] = hash_password(new)
            self._save(users)

    def tokens(self, username: str) -> list[dict]:
        with self._lock:
            u = self._find(self._load(), username) or {}
            return [{k: t.get(k, "") for k in ("id", "name", "created", "last_used")}
                    for t in u.get("tokens") or []]

    def create_token(self, username: str, name: str) -> dict:
        name = (name or "").strip() or "token"
        token = TOKEN_PREFIX + secrets.token_urlsafe(32)
        entry = {"id": secrets.token_hex(4), "name": name, "hash": _token_hash(token),
                 "created": _now(), "last_used": ""}
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None:
                raise UserError(f"No user {username}.")
            u.setdefault("tokens", []).append(entry)
            self._save(users)
        return {"id": entry["id"], "name": name, "created": entry["created"], "token": token}

    def revoke_token(self, username: str, token_id: str) -> bool:
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None:
                return False
            before = len(u.get("tokens") or [])
            u["tokens"] = [t for t in u.get("tokens") or [] if t.get("id") != token_id]
            if len(u["tokens"]) == before:
                return False
            self._save(users)
            return True

    # ── administering users ──
    def list_users(self) -> list[dict]:
        with self._lock:
            return [{**self._user(u).public(), "created": u.get("created", ""),
                     "tokens": len(u.get("tokens") or [])} for u in self._load()]

    def create_user(self, username: str, password: str, role: str, name: str = "") -> User:
        self._check_username(username)
        self._check_password(password)
        r = self._check_role(role)
        with self._lock:
            users = self._load()
            if self._find(users, username):
                raise UserError(f"There is already a user {username}.")
            users.append({"username": username, "name": name or username, "role": r.value,
                          "root": False, "password": hash_password(password),
                          "created": _now(), "tokens": []})
            self._save(users)
            return self._user(users[-1])

    def update_user(self, username: str, *, name: Optional[str] = None,
                    role: Optional[str] = None) -> User:
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None:
                raise LookupError(f"No user {username}.")
            if role is not None:
                r = self._check_role(role)
                if u.get("root") and r is not Role.ADMIN:
                    raise UserError("The root user stays an admin.")
                u["role"] = r.value
            if name is not None:
                u["name"] = name.strip() or username
            self._save(users)
            return self._user(u)

    def set_password(self, username: str, password: str) -> None:
        self._check_password(password)
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None:
                raise LookupError(f"No user {username}.")
            u["password"] = hash_password(password)
            self._save(users)
            self._end_sessions(username)      # signed in elsewhere: signs in again

    def delete_user(self, username: str) -> None:
        with self._lock:
            users = self._load()
            u = self._find(users, username)
            if u is None:
                raise LookupError(f"No user {username}.")
            if u.get("root"):
                raise UserError("The root user cannot be removed.")
            self._save([x for x in users if x is not u])
            self._end_sessions(username)

    # ── checks ──
    @staticmethod
    def _check_username(username: str) -> None:
        if not USERNAME_RE.match(username or ""):
            raise UserError("A user name is lower case letters, digits, '.', '_' or '-' "
                            "(starting with a letter or digit), at most 64 long.")

    @staticmethod
    def _check_password(password: str) -> None:
        if len(password or "") < MIN_PASSWORD:
            raise UserError(f"A password is at least {MIN_PASSWORD} characters long.")

    @staticmethod
    def _check_role(role: str) -> Role:
        try:
            return Role(role)
        except ValueError:
            raise UserError("A role is admin, editor or viewer.")
