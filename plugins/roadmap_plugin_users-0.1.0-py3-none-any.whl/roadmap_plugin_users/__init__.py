"""Users plugin — the default, file-based auth provider: the root user and the
users an admin adds (admin / editor / viewer), sign-in, and personal API tokens.
Publishes the framework's ``auth`` service; see ``roadmap_framework.auth``."""
