"""Users plugin activator — the file-based auth provider (the ``auth`` service the
framework's middleware asks), ``/api/auth`` (setup, sign in/out, one's own
password and API tokens) and ``/api/users`` (administering users; admins only).

A core plugin: with it installed, every request needs a signed-in user or an API
token with the role the request needs (see ``roadmap_framework.auth``). Another
provider (OAuth, a directory) can take its place by publishing ``auth``.
"""

from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, HTTPException, Request, Response
from pydantic import BaseModel

from roadmap_framework import AUTH_SERVICE, SESSION_COOKIE, Plugin, PluginContext, User
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT, SettingsSection

from .store import FileUserStore, TooManyAttempts, UserError


class SetupBody(BaseModel):
    username: str
    password: str
    name: str = ""


class LoginBody(BaseModel):
    username: str
    password: str


class PasswordChange(BaseModel):
    current: str
    new: str


class TokenBody(BaseModel):
    name: str = ""


class NewUser(BaseModel):
    username: str
    password: str
    role: str = "viewer"
    name: str = ""


class UserUpdate(BaseModel):
    name: Optional[str] = None
    role: Optional[str] = None


class PasswordReset(BaseModel):
    password: str


def _refuse(fn):
    try:
        return fn()
    except TooManyAttempts as e:
        raise HTTPException(status_code=429, detail=str(e))
    except UserError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except LookupError as e:
        raise HTTPException(status_code=404, detail=str(e))


def _set_cookie(response: Response, sid: str) -> None:
    response.set_cookie(SESSION_COOKIE, sid, httponly=True, samesite="lax", path="/")


def create_routers(store: FileUserStore) -> list[APIRouter]:
    auth = APIRouter(prefix="/api/auth", tags=["auth"])

    def who(request: Request) -> Optional[User]:
        """/api/auth is public, so these endpoints find the user themselves."""
        header = request.headers.get("authorization", "")
        if header.lower().startswith("bearer "):
            return store.user_for_token(header[7:].strip())
        sid = request.cookies.get(SESSION_COOKIE, "")
        return store.user_for_session(sid) if sid else None

    def me_or_401(request: Request) -> User:
        user = who(request)
        if user is None:
            raise HTTPException(status_code=401, detail="Sign in first.")
        return user

    @auth.get("/status")
    def status(request: Request):
        """Whether the root user still has to be created, and who is signed in."""
        user = who(request)
        return {"setup_required": store.setup_required(),
                "user": user.public() if user else None}

    @auth.post("/setup")
    def setup(body: SetupBody, response: Response):
        """Create the root user (an admin that cannot be removed). Only while there
        is none; it signs in at once."""
        user = _refuse(lambda: store.setup_root(body.username.strip().lower(), body.password,
                                                body.name.strip()))
        sid, _ = store.login(user.username, body.password)
        _set_cookie(response, sid)
        return {"user": user.public()}

    @auth.post("/login")
    def login(body: LoginBody, response: Response):
        if store.setup_required():
            raise HTTPException(status_code=409, detail="Create the root user first.")
        sid, user = _refuse(lambda: store.login(body.username, body.password))
        _set_cookie(response, sid)
        return {"user": user.public()}

    @auth.post("/logout")
    def logout(request: Request, response: Response):
        store.logout(request.cookies.get(SESSION_COOKIE, ""))
        response.delete_cookie(SESSION_COOKIE, path="/")
        return {"ok": True}

    @auth.get("/me")
    def me(request: Request):
        return {"user": me_or_401(request).public()}

    @auth.put("/me/password")
    def change_password(body: PasswordChange, request: Request):
        user = me_or_401(request)
        _refuse(lambda: store.change_password(user.username, body.current, body.new))
        return {"ok": True}

    @auth.get("/me/tokens")
    def my_tokens(request: Request):
        return {"tokens": store.tokens(me_or_401(request).username)}

    @auth.post("/me/tokens")
    def new_token(body: TokenBody, request: Request):
        """A personal API token, for an MCP client or a script. Shown once."""
        user = me_or_401(request)
        return _refuse(lambda: store.create_token(user.username, body.name))

    @auth.delete("/me/tokens/{token_id}")
    def revoke(token_id: str, request: Request):
        if not store.revoke_token(me_or_401(request).username, token_id):
            raise HTTPException(status_code=404, detail="No such token.")
        return {"ok": True}

    users = APIRouter(prefix="/api/users", tags=["users"])   # admins only (framework rules)

    @users.get("")
    def list_users():
        return {"users": store.list_users()}

    @users.post("")
    def create_user(body: NewUser):
        user = _refuse(lambda: store.create_user(body.username.strip().lower(), body.password,
                                                 body.role, body.name.strip()))
        return {"user": user.public()}

    @users.put("/{username}")
    def update_user(username: str, body: UserUpdate):
        return {"user": _refuse(lambda: store.update_user(username, name=body.name,
                                                          role=body.role)).public()}

    @users.post("/{username}/password")
    def reset_password(username: str, body: PasswordReset):
        _refuse(lambda: store.set_password(username, body.password))
        return {"ok": True}

    @users.delete("/{username}")
    def delete_user(username: str):
        _refuse(lambda: store.delete_user(username))
        return {"ok": True}

    return [auth, users]


# the two settings tabs (their frontend registers them): Account for everyone,
# Users for admins; they own no part of the settings document
ACCOUNT_SECTION = SettingsSection(id="account", label="Account", order=840, group="System")
USERS_SECTION = SettingsSection(id="users", label="Users", order=870, group="System")


class UsersPlugin(Plugin):
    id = "roadmap.users"
    name = "Users"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        store = FileUserStore(ctx.config.base_dir / "users.yaml")
        ctx.services.register(AUTH_SERVICE, store)
        ctx.extend(SETTINGS_SECTIONS_POINT, ACCOUNT_SECTION)
        ctx.extend(SETTINGS_SECTIONS_POINT, USERS_SECTION)
        for router in create_routers(store):
            ctx.add_router(router)
