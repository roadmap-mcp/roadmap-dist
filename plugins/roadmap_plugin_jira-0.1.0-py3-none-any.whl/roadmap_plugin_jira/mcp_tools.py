"""Jira/Confluence interactive MCP tools.

Registered on the *shared* MCP server (obtained from the context service), so an
edition without the Jira plugin simply doesn't expose these tools."""

import re

from fastapi import HTTPException

from .context_items import (
    render_confluence_page, render_confluence_children,
    render_jira_issue, render_jira_children,
)


def register_mcp_tools(context) -> None:
    mcp = context.mcp

    @mcp.tool()
    def request_confluence_page(name: str, page_id: str, label: str = "") -> str:
        """Fetch a Confluence page by its ID and record the inquiry in the context."""
        label = label or f"Page {page_id}"
        context.upsert_inquiry(name, "confluence_page", {"page_id": page_id}, label)
        return render_confluence_page(page_id, label)

    @mcp.tool()
    def list_confluence_children(name: str, page_id: str, label: str = "") -> str:
        """List the tree of child pages under a Confluence page and record it as an inquiry."""
        label = label or f"Children of page {page_id}"
        context.upsert_inquiry(name, "confluence_children", {"page_id": page_id}, label)
        return render_confluence_children(page_id, label)

    @mcp.tool()
    def add_confluence_pages(name: str, page_ids: str, label_prefix: str = "") -> str:
        """Add one or more Confluence pages to a context as permanent items."""
        ids = [p for p in re.split(r"[\s,]+", page_ids.strip()) if p]
        if not ids:
            return "No page IDs provided."
        resolved, failed = [], []
        for pid in ids:
            try:
                item = context.resolve_item("confluence_page", pid)
                if label_prefix:
                    item["label"] = f"{label_prefix}{item.get('label', '')}"
                resolved.append(item)
            except HTTPException as e:
                failed.append(f"{pid} ({e.detail})")
            except Exception as e:
                failed.append(f"{pid} ({e})")
        added, skipped = context.add_context_items(name, resolved)
        lines = [f"Added {added} Confluence page(s) to context '{name}'."]
        if skipped:
            lines.append(f"{skipped} already present (skipped).")
        if failed:
            lines.append("Failed: " + "; ".join(failed))
        for it in resolved:
            lines.append(f"- {it['label']} (page_id: {it['id']})")
        return "\n".join(lines)

    @mcp.tool()
    def list_jira_children(name: str, issue_key: str, label: str = "") -> str:
        """List the tree of child issues under a Jira issue and record it as an inquiry."""
        issue_key = issue_key.upper()
        label = label or f"Children of {issue_key}"
        context.upsert_inquiry(name, "jira_children", {"issue_key": issue_key}, label)
        return render_jira_children(issue_key, label)

    @mcp.tool()
    def add_jira_issues(name: str, issue_keys: str, label_prefix: str = "") -> str:
        """Add one or more Jira issues to a context as permanent items."""
        keys = [k.upper() for k in re.split(r"[\s,]+", issue_keys.strip()) if k]
        if not keys:
            return "No issue keys provided."
        resolved, failed = [], []
        for key in keys:
            try:
                item = context.resolve_item("jira_issue", key)
                if label_prefix:
                    item["label"] = f"{label_prefix}{item.get('label', '')}"
                resolved.append(item)
            except HTTPException as e:
                failed.append(f"{key} ({e.detail})")
            except Exception as e:
                failed.append(f"{key} ({e})")
        added, skipped = context.add_context_items(name, resolved)
        lines = [f"Added {added} Jira issue(s) to context '{name}'."]
        if skipped:
            lines.append(f"{skipped} already present (skipped).")
        if failed:
            lines.append("Failed: " + "; ".join(failed))
        for it in resolved:
            lines.append(f"- {it['label']} ({it['id']})")
        return "\n".join(lines)

    @mcp.tool()
    def request_jira_issue(name: str, issue_key: str, label: str = "") -> str:
        """Fetch a Jira issue by its key and record the inquiry in the context."""
        issue_key = issue_key.upper()
        label = label or issue_key
        context.upsert_inquiry(name, "jira_issue", {"issue_key": issue_key}, label)
        return render_jira_issue(issue_key, label)
