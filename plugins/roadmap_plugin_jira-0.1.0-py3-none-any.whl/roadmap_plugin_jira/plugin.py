"""Jira / Atlassian plugin activator — the reference implementation that
contributes to the settings and context extension points declared by other
plugins, and mounts its own ``/api/jira`` + ``/api/confluence`` routers.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT
from roadmap_plugin_context import CONTEXT_ITEM_TYPES_POINT, CONTEXT_PREVIEW_POINT

from . import runtime
from .jira_router import router as jira_router
from .confluence_router import router as confluence_router
from .settings_section import ATLASSIAN_SECTION, create_atlassian_settings_router
from .context_items import JIRA_ITEM_TYPES, JIRA_PREVIEWS
from .mcp_tools import register_mcp_tools


class JiraPlugin(Plugin):
    id = "roadmap.jira"
    name = "Jira / Atlassian"
    requires = ["roadmap.settings", "roadmap.context"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services)
        ctx.register_sensitive_path("atlassian.api_token")

        # contribute to the settings + context extension points
        ctx.extend(SETTINGS_SECTIONS_POINT, ATLASSIAN_SECTION)
        for it in JIRA_ITEM_TYPES:
            ctx.extend(CONTEXT_ITEM_TYPES_POINT, it)
        for pc in JIRA_PREVIEWS:
            ctx.extend(CONTEXT_PREVIEW_POINT, pc)

        # own routers
        ctx.add_router(jira_router)
        ctx.add_router(confluence_router)
        ctx.add_router(create_atlassian_settings_router())

        # interactive Jira/Confluence MCP tools on the shared MCP server
        register_mcp_tools(ctx.services.require("context"))
