"""Jira/Confluence context item types + preview contributions.

Resolve + render logic moved verbatim from the monolith's ``contexts.py`` /
``mcp_server.py``; rehomed here and made self-sufficient via the Jira runtime so
the context plugin never references Jira directly.
"""

from __future__ import annotations

import json

from fastapi import HTTPException

from roadmap_plugin_context import ContextItemType, PreviewContribution

from . import runtime
from .confluence_html import _clean_confluence_html


# ── resolve (add-time metadata) ───────────────────────────────────────────

def resolve_jira_issue(issue_key: str, *, text=None, path=None) -> dict:
    parts = issue_key.split("-", 1)
    if len(parts) != 2:
        raise HTTPException(status_code=400,
                            detail=f"Invalid issue key format: {issue_key}")
    project_key = parts[0]
    data = runtime.issue_service().get_issue(issue_key)
    if data is None:
        raise HTTPException(status_code=404, detail=f"Jira issue {issue_key} not found")
    title = data.get("summary", "Untitled")
    return {"type": "jira_issue", "id": issue_key, "title": title,
            "label": title, "project_key": project_key}


def resolve_confluence_page(page_id: str, *, text=None, path=None) -> dict:
    from .confluence_router import _fetch_single_page

    cache = runtime.cache()
    atl = runtime.atlassian_config()
    for space in atl.confluence_spaces:
        p = cache.confluence_page_path(space.key, page_id)
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            title = data.get("title", "Untitled")
            return {"type": "confluence_page", "id": page_id, "title": title,
                    "label": title, "space_key": data.get("space_key", space.key)}

    try:
        data = _fetch_single_page(atl, page_id)
    except Exception:
        raise HTTPException(status_code=404,
                            detail=f"Confluence page {page_id} not found")
    space_key = data.get("space_key", "unknown")
    cache.write(cache.confluence_page_path(space_key, page_id), data)
    title = data.get("title", "Untitled")
    return {"type": "confluence_page", "id": page_id, "title": title,
            "label": title, "space_key": space_key}


# ── render (AI / preview text) ────────────────────────────────────────────

def render_jira_issue(issue_key: str, label: str) -> str:
    data = runtime.issue_service().get_issue(issue_key)
    if not data:
        return f"## {label} ({issue_key})\n\n(Issue not found)"
    lines = [
        f"## {label} ({issue_key})",
        f"**Status:** {data.get('status', 'Unknown')} | "
        f"**Type:** {data.get('issuetype', 'Unknown')} | "
        f"**Priority:** {data.get('priority', 'Unknown')}",
    ]
    if data.get("assignee"):
        lines.append(f"**Assignee:** {data['assignee']}")
    if data.get("description"):
        lines.append(f"\n### Description\n{data['description']}")
    comments = data.get("comments", [])
    if comments:
        lines.append(f"\n### Comments ({len(comments)})")
        for c in comments[:10]:
            lines.append(f"\n**{c.get('author', 'Unknown')}** "
                         f"({c.get('created', '')[:10]}):\n{c.get('body', '')}")
    return "\n".join(lines)


def render_confluence_page(page_id: str, label: str) -> str:
    cache = runtime.cache()
    atl = runtime.atlassian_config()
    for space in atl.confluence_spaces:
        p = cache.confluence_page_path(space.key, page_id)
        if p.exists():
            data = json.loads(p.read_text(encoding="utf-8"))
            clean_text = _clean_confluence_html(data.get("body_html", ""))
            title = (data.get("title") or "").strip()
            meta = [f"**Space:** {data.get('space_key', space.key)}",
                    f"**Page ID:** {page_id}"]
            if title:
                meta.insert(0, f"**Title:** {title}")
            return f"## {label} (Confluence Page)\n{' | '.join(meta)}\n\n{clean_text}"
    return f"## {label} (Confluence Page)\n**Page ID:** {page_id}\n\n(Page not found in cache)"


def _render_confluence_tree(children: list, depth: int = 0) -> list[str]:
    lines = []
    for c in children:
        lines.append(f"{'  ' * depth}- **{c.get('title', 'Untitled')}** "
                     f"(page_id: `{c.get('id')}`)")
        kids = c.get("children", [])
        if kids:
            lines.extend(_render_confluence_tree(kids, depth + 1))
    return lines


def render_confluence_children(page_id: str, label: str) -> str:
    from .confluence_router import fetch_page_descendants
    try:
        data = fetch_page_descendants(page_id)
    except Exception as e:
        return (f"## {label} (Confluence Child Pages)\n"
                f"**Parent page ID:** {page_id}\n\n(Could not load children: {e})")
    children = data.get("children", [])
    head = (f"## {label} (Confluence Child Pages)\n"
            f"**Space:** {data.get('space_key', '?')} | "
            f"**Parent page ID:** {page_id}\n\n")
    if not children:
        return head + "_This page has no child pages._"
    body = "\n".join(_render_confluence_tree(children))
    return head + body + (
        "\n\nUse the `add_confluence_pages` tool with the page_id(s) above "
        "to add specific pages as permanent context items.")


def _render_jira_tree(children: list, depth: int = 0) -> list[str]:
    lines = []
    for c in children:
        meta = " / ".join(x for x in (c.get("issuetype", ""), c.get("status", "")) if x)
        meta = f" — _{meta}_" if meta else ""
        lines.append(f"{'  ' * depth}- **{c.get('key')}** {c.get('summary', '')}{meta}")
        kids = c.get("children", [])
        if kids:
            lines.extend(_render_jira_tree(kids, depth + 1))
    return lines


def render_jira_children(issue_key: str, label: str) -> str:
    from .jira_router import fetch_issue_children_tree
    try:
        data = fetch_issue_children_tree(issue_key)
    except Exception as e:
        return (f"## {label} (Jira Child Issues)\n"
                f"**Parent issue:** {issue_key}\n\n(Could not load children: {e})")
    children = data.get("children", [])
    head = f"## {label} (Jira Child Issues)\n**Parent issue:** {issue_key}\n\n"
    if not children:
        return head + "_This issue has no sub-tasks or child issues._"
    body = "\n".join(_render_jira_tree(children))
    return head + body + (
        "\n\nUse the `add_jira_issues` tool with the issue key(s) above "
        "to add specific issues as permanent context items.")


# ── contributions ─────────────────────────────────────────────────────────

JIRA_ITEM_TYPES = [
    ContextItemType(
        "jira_issue", resolve=resolve_jira_issue,
        render=lambda item, cfg: render_jira_issue(
            item.get("id", ""), item.get("label", item.get("title", "Untitled"))),
        label="Jira Issue",
    ),
    ContextItemType(
        "confluence_page", resolve=resolve_confluence_page,
        render=lambda item, cfg: render_confluence_page(
            item.get("id", ""), item.get("label", item.get("title", "Untitled"))),
        label="Confluence Page",
    ),
]

JIRA_PREVIEWS = [
    PreviewContribution("jira_issue",
                        lambda params, label, cfg: render_jira_issue(params.get("issue_key", ""), label)),
    PreviewContribution("confluence_page",
                        lambda params, label, cfg: render_confluence_page(params.get("page_id", ""), label)),
    PreviewContribution("jira_children",
                        lambda params, label, cfg: render_jira_children(params.get("issue_key", ""), label)),
    PreviewContribution("confluence_children",
                        lambda params, label, cfg: render_confluence_children(params.get("page_id", ""), label)),
]
