"""Built-in work-item sources contributed to ``roadmap.gitmining.sources``.

The engine ships the ``git`` source (commits + branches). A satellite plugin adds pull-request
or Jira-issue sources by contributing its own :class:`~..contracts.WorkItemSource`.
"""

from __future__ import annotations

from .git_source import GIT_SOURCE

BUILTIN_SOURCES = [GIT_SOURCE]
