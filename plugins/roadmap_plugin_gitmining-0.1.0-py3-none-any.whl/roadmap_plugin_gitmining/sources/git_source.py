"""The built-in ``git`` work-item source: commits + branches from a server-managed mirror.

Wraps the git plumbing (:mod:`..gitops`) as a :class:`~..contracts.WorkItemSource`. For a
scope (a :class:`~..models.MiningRepo`) it fetches, per tracked branch, the new commits since
the cursor's stored tip and produces:

* a ``branch`` work item per branch (``details.tip`` = current tip);
* a ``git_commit`` work item per new commit (all the git-specific fields live in ``details``);
* relations: commit ``--parent-->`` commit, commit ``--on_branch-->`` branch,
  branch ``--tip-->`` commit, and commit ``--references-->`` ``jira_issue`` (cross-scope, from
  the commit message's issue keys — a dangling edge that lights up if a Jira source is added).

The cursor is ``{"branch_tips": {branch: full_hash}}`` — an empty cursor means a full walk.
``reader`` reads a file at a commit (``git show``) for processors that need content.
"""

from __future__ import annotations

from .. import gitops
from ..contracts import FetchResult, WorkItemSource
from ..models import WorkItem, WorkItemRef, WorkItemRelation


def _commit_item(scope: str, parsed: dict) -> WorkItem:
    return WorkItem(
        scope=scope, type="git_commit", id=parsed["hash"],
        title=parsed["message"], timestamp=parsed["date"],
        details={
            "full_hash": parsed["full_hash"],
            "author_name": parsed["author_name"],
            "author_email": parsed["author_email"],
            "message": parsed["message"],
            "files_changed": parsed["files_changed"],
            "parents": parsed["parents"],
            "issue_keys": parsed["issue_keys"],
        })


def _fetch(sctx) -> FetchResult:
    repo = sctx.repo
    scope = sctx.scope
    mirror = gitops.ensure_mirror(sctx.repos_dir, repo, sctx.credential)
    prior_tips = (sctx.cursor or {}).get("branch_tips", {})
    # honor an explicit branch filter (e.g. only the branches a scan flagged as changed)
    branches = getattr(sctx, "branches", None) or repo.branches or gitops.list_branches(mirror)

    items: dict[tuple[str, str], WorkItem] = {}
    rels: dict[tuple, WorkItemRelation] = {}
    new_tips = dict(prior_tips)

    def commit_ref(h: str) -> WorkItemRef:
        return WorkItemRef(scope=scope, type="git_commit", id=h)

    def add_rel(src: WorkItemRef, dst: WorkItemRef, kind: str) -> None:
        rels[(src.scope, src.type, src.id, dst.scope, dst.type, dst.id, kind)] = \
            WorkItemRelation(src=src, dst=dst, kind=kind)

    for br in branches:
        tip = gitops.branch_tip(mirror, br)
        if not tip:
            continue
        branch_ref = WorkItemRef(scope=scope, type="branch", id=br)
        items[("branch", br)] = WorkItem(scope=scope, type="branch", id=br,
                                         title=br, details={"tip": tip})
        since = prior_tips.get(br, "")
        for parsed in gitops.walk_commits(mirror, br, since_full=since):
            h = parsed["hash"]
            if ("git_commit", h) not in items:
                items[("git_commit", h)] = _commit_item(scope, parsed)
            add_rel(commit_ref(h), branch_ref, "on_branch")
            for p in parsed["parents"]:
                add_rel(commit_ref(h), commit_ref(p), "parent")
            for key in parsed["issue_keys"]:
                project = key.split("-")[0]
                add_rel(commit_ref(h),
                        WorkItemRef(scope=project, type="jira_issue", id=key), "references")
        add_rel(branch_ref, commit_ref(tip[:12]), "tip")
        new_tips[br] = tip

    return FetchResult(items=list(items.values()), relations=list(rels.values()),
                       cursor={"branch_tips": new_tips})


def _reader(sctx, item, path: str) -> str:
    mirror = gitops.mirror_path(sctx.repos_dir, item.scope)
    full = item.details.get("full_hash") or item.id
    return gitops.read_file_at(mirror, full, path)


GIT_SOURCE = WorkItemSource(
    id="git",
    label="Git (commits + branches)",
    types=["git_commit", "branch"],
    fetch=_fetch,
    reader=_reader,
    icon="bi-git",
)
