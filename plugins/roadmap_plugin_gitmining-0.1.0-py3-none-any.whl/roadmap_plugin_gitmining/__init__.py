"""Roadmap git-mining engine.

Owns a **generic unit-of-work** mining domain: server-managed repos, scheduled scanning, and
three swappable seams — all around the :class:`WorkItem` model, so new kinds of mined work
(pull requests, Jira issues) drop in without touching the engine:

* ``roadmap.gitmining.persistence`` — where work items are stored (built-in SQLite default +
  filesystem; a satellite can add Postgres/SQL-Server). Supplies a :class:`WorkItemStore`.
* ``roadmap.gitmining.sources`` — where work items come from (built-in ``git`` = commits +
  branches). Supplies a :class:`WorkItemSource`.
* ``roadmap.gitmining.processors`` — analyzers that extract structured data from a work item.

Re-exported so satellite plugins can import the point ids + contracts from the package root.
"""

from .contracts import (
    GITMINING_PERSISTENCE_POINT, GITMINING_PROCESSORS_POINT, GITMINING_SOURCES_POINT,
    FetchResult, PersistenceProvider, WorkItemSource,
)
from .models import WorkItem, WorkItemRef, WorkItemRelation, SourceCursor
from .ports import WorkItemStore

__all__ = [
    "GITMINING_PERSISTENCE_POINT", "GITMINING_SOURCES_POINT", "GITMINING_PROCESSORS_POINT",
    "PersistenceProvider", "WorkItemSource", "FetchResult", "WorkItemStore",
    "WorkItem", "WorkItemRef", "WorkItemRelation", "SourceCursor",
]
