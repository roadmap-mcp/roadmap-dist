"""SQLite persistence backend — the default :class:`~.ports.WorkItemStore`.

Zero-dependency (stdlib ``sqlite3``): one database file per workspace at
``<config_dir>/gitmining/mining.db``. Four tables — work items, their per-processor results,
the relations between them, and the per-source cursor. Everything type-specific (a commit's
hash/author/files, a relation's attributes, a source's cursor) is stored as JSON text, so
adding a new work-item type never changes the schema.
"""

from __future__ import annotations

import json
import sqlite3
from pathlib import Path

from ..models import SourceCursor, WorkItem, WorkItemRef, WorkItemRelation

_SCHEMA = """
CREATE TABLE IF NOT EXISTS work_items (
    scope     TEXT NOT NULL,
    type      TEXT NOT NULL,
    id        TEXT NOT NULL,
    title     TEXT,
    timestamp TEXT,
    details   TEXT,          -- json dict (type-specific fields)
    PRIMARY KEY (scope, type, id)
);
CREATE INDEX IF NOT EXISTS ix_items_scope_ts ON work_items (scope, type, timestamp DESC);

CREATE TABLE IF NOT EXISTS item_results (
    scope      TEXT NOT NULL,
    type       TEXT NOT NULL,
    id         TEXT NOT NULL,
    result_key TEXT NOT NULL,
    payload    TEXT,          -- json dict
    version    INTEGER DEFAULT 1,
    PRIMARY KEY (scope, type, id, result_key)
);

CREATE TABLE IF NOT EXISTS relations (
    src_scope TEXT NOT NULL, src_type TEXT NOT NULL, src_id TEXT NOT NULL,
    dst_scope TEXT NOT NULL, dst_type TEXT NOT NULL, dst_id TEXT NOT NULL,
    kind      TEXT NOT NULL,
    attributes TEXT,          -- json dict
    PRIMARY KEY (src_scope, src_type, src_id, dst_scope, dst_type, dst_id, kind)
);
CREATE INDEX IF NOT EXISTS ix_rel_src ON relations (src_scope, src_type, src_id);
CREATE INDEX IF NOT EXISTS ix_rel_dst ON relations (dst_scope, dst_type, dst_id);

CREATE TABLE IF NOT EXISTS cursors (
    scope              TEXT NOT NULL,
    source             TEXT NOT NULL,
    cursor             TEXT,     -- json dict (source-defined)
    processor_versions TEXT,     -- json {name: version}
    last_ingested_at   TEXT,
    PRIMARY KEY (scope, source)
);
"""


def _dumps(value) -> str:
    return json.dumps(value, ensure_ascii=False)


def _loads(text, default):
    if not text:
        return default
    try:
        return json.loads(text)
    except (json.JSONDecodeError, TypeError):
        return default


class SqliteWorkItemStore:
    """stdlib-``sqlite3`` implementation of the :class:`~.ports.WorkItemStore` port."""

    id = "sql"

    def __init__(self, db_path: Path) -> None:
        self._path = Path(db_path)

    def _conn(self) -> sqlite3.Connection:
        self._path.parent.mkdir(parents=True, exist_ok=True)
        conn = sqlite3.connect(self._path)
        conn.row_factory = sqlite3.Row
        return conn

    # ── lifecycle ─────────────────────────────────────────────────────────────
    def init(self) -> None:
        with self._conn() as conn:
            conn.executescript(_SCHEMA)

    # ── cursor ────────────────────────────────────────────────────────────────
    def load_cursor(self, scope: str, source: str) -> SourceCursor | None:
        with self._conn() as conn:
            row = conn.execute("SELECT * FROM cursors WHERE scope = ? AND source = ?",
                               (scope, source)).fetchone()
        if row is None:
            return None
        return SourceCursor(
            scope=scope, source=source, cursor=_loads(row["cursor"], {}),
            processor_versions=_loads(row["processor_versions"], {}),
            last_ingested_at=row["last_ingested_at"] or "")

    def save_cursor(self, cursor: SourceCursor) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO cursors (scope, source, cursor, processor_versions, last_ingested_at)
                   VALUES (?, ?, ?, ?, ?)
                   ON CONFLICT(scope, source) DO UPDATE SET
                       cursor=excluded.cursor,
                       processor_versions=excluded.processor_versions,
                       last_ingested_at=excluded.last_ingested_at""",
                (cursor.scope, cursor.source, _dumps(cursor.cursor),
                 _dumps(cursor.processor_versions), cursor.last_ingested_at))

    # ── work items ────────────────────────────────────────────────────────────
    def upsert_items(self, scope: str, items: list[WorkItem]) -> int:
        if not items:
            return 0
        rows = [(scope, it.type, it.id, it.title, it.timestamp, _dumps(it.details))
                for it in items]
        with self._conn() as conn:
            # base fields only — item_results is a separate table, so processor results survive
            conn.executemany(
                """INSERT INTO work_items (scope, type, id, title, timestamp, details)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(scope, type, id) DO UPDATE SET
                       title=excluded.title, timestamp=excluded.timestamp,
                       details=excluded.details""",
                rows)
        return len(rows)

    def save_processor_result(self, scope: str, item_type: str, item_id: str,
                              result_key: str, payload: dict, version: int = 1) -> None:
        with self._conn() as conn:
            conn.execute(
                """INSERT INTO item_results (scope, type, id, result_key, payload, version)
                   VALUES (?, ?, ?, ?, ?, ?)
                   ON CONFLICT(scope, type, id, result_key) DO UPDATE SET
                       payload=excluded.payload, version=excluded.version""",
                (scope, item_type, item_id, result_key, _dumps(payload), version))

    # ── relations ─────────────────────────────────────────────────────────────
    def upsert_relations(self, relations: list[WorkItemRelation]) -> int:
        if not relations:
            return 0
        rows = [(r.src.scope, r.src.type, r.src.id, r.dst.scope, r.dst.type, r.dst.id,
                 r.kind, _dumps(r.attributes)) for r in relations]
        with self._conn() as conn:
            conn.executemany(
                """INSERT INTO relations
                       (src_scope, src_type, src_id, dst_scope, dst_type, dst_id, kind, attributes)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                   ON CONFLICT(src_scope, src_type, src_id, dst_scope, dst_type, dst_id, kind)
                   DO UPDATE SET attributes=excluded.attributes""",
                rows)
        return len(rows)

    def _rel(self, row: sqlite3.Row) -> WorkItemRelation:
        return WorkItemRelation(
            src=WorkItemRef(scope=row["src_scope"], type=row["src_type"], id=row["src_id"]),
            dst=WorkItemRef(scope=row["dst_scope"], type=row["dst_type"], id=row["dst_id"]),
            kind=row["kind"], attributes=_loads(row["attributes"], {}))

    def list_relations(self, ref: WorkItemRef, kind: str = "",
                       incoming: bool = False) -> list[WorkItemRelation]:
        col = "dst" if incoming else "src"
        clause = f"{col}_scope = ? AND {col}_type = ? AND {col}_id = ?"
        params = [ref.scope, ref.type, ref.id]
        if kind:
            clause += " AND kind = ?"
            params.append(kind)
        with self._conn() as conn:
            rows = conn.execute(f"SELECT * FROM relations WHERE {clause}", params).fetchall()
            return [self._rel(r) for r in rows]

    # ── queries ───────────────────────────────────────────────────────────────
    def list_types(self, scope: str) -> list[str]:
        with self._conn() as conn:
            rows = conn.execute(
                "SELECT DISTINCT type FROM work_items WHERE scope = ? ORDER BY type",
                (scope,)).fetchall()
            return [r["type"] for r in rows]

    def _item(self, conn: sqlite3.Connection, row: sqlite3.Row) -> WorkItem:
        results = {
            rr["result_key"]: _loads(rr["payload"], {})
            for rr in conn.execute(
                "SELECT result_key, payload FROM item_results WHERE scope=? AND type=? AND id=?",
                (row["scope"], row["type"], row["id"])).fetchall()
        }
        return WorkItem(
            scope=row["scope"], type=row["type"], id=row["id"], title=row["title"] or "",
            timestamp=row["timestamp"] or "", details=_loads(row["details"], {}),
            processor_results=results)

    def list_items(self, scope: str, item_type: str = "",
                   limit: int = 200) -> list[WorkItem]:
        clause = "scope = ?"
        params: list = [scope]
        if item_type:
            clause += " AND type = ?"
            params.append(item_type)
        params.append(max(1, limit))
        with self._conn() as conn:
            rows = conn.execute(
                f"SELECT * FROM work_items WHERE {clause} ORDER BY timestamp DESC LIMIT ?",
                params).fetchall()
            return [self._item(conn, r) for r in rows]

    def get_item(self, scope: str, item_type: str, item_id: str) -> WorkItem | None:
        with self._conn() as conn:
            row = conn.execute(
                "SELECT * FROM work_items WHERE scope=? AND type=? AND id=?",
                (scope, item_type, item_id)).fetchone()
            return self._item(conn, row) if row else None

    def item_count(self, scope: str, item_type: str = "") -> int:
        with self._conn() as conn:
            if item_type:
                return conn.execute(
                    "SELECT COUNT(*) AS n FROM work_items WHERE scope=? AND type=?",
                    (scope, item_type)).fetchone()["n"]
            return conn.execute("SELECT COUNT(*) AS n FROM work_items WHERE scope=?",
                                (scope,)).fetchone()["n"]

    def clear_scope(self, scope: str) -> None:
        with self._conn() as conn:
            conn.execute("DELETE FROM work_items WHERE scope = ?", (scope,))
            conn.execute("DELETE FROM item_results WHERE scope = ?", (scope,))
            conn.execute("DELETE FROM cursors WHERE scope = ?", (scope,))
            conn.execute("DELETE FROM relations WHERE src_scope = ? OR dst_scope = ?",
                         (scope, scope))
