"""Filesystem persistence backend — a JSON-file-per-entity :class:`~.ports.WorkItemStore`.

The database-free alternative to SQLite. Layout under ``<config_dir>/gitmining/data/``::

    <scope>/
      items/<type>/<slug(id)>.json   one WorkItem (processor results embedded)
      cursors/<source>.json          one SourceCursor
    _relations/<slug>.json           one WorkItemRelation (kept at the root — edges can
                                     cross scopes, so they aren't nested under a scope)

Ids (branch names, issue keys) are slugified for filenames but the real id is kept inside the
JSON. Simple and inspectable; for large histories the SQLite store is faster (the default).
"""

from __future__ import annotations

import json
import re
from pathlib import Path

from ..models import SourceCursor, WorkItem, WorkItemRef, WorkItemRelation


def _slug(value: str) -> str:
    return re.sub(r"[^A-Za-z0-9_.-]", "_", value) or "_"


def _read(path: Path) -> dict | None:
    if not path.exists():
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return None


def _write(path: Path, data: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


class FilesystemWorkItemStore:
    """JSON-file implementation of the :class:`~.ports.WorkItemStore` port."""

    id = "filesystem"

    def __init__(self, root: Path) -> None:
        self._root = Path(root)

    # ── layout helpers ────────────────────────────────────────────────────────
    def _scope_dir(self, scope: str) -> Path:
        return self._root / _slug(scope)

    def _items_dir(self, scope: str, item_type: str) -> Path:
        return self._scope_dir(scope) / "items" / _slug(item_type)

    def _item_path(self, scope: str, item_type: str, item_id: str) -> Path:
        return self._items_dir(scope, item_type) / f"{_slug(item_id)}.json"

    def _rel_dir(self) -> Path:
        return self._root / "_relations"

    # ── lifecycle ─────────────────────────────────────────────────────────────
    def init(self) -> None:
        self._root.mkdir(parents=True, exist_ok=True)

    # ── cursor ────────────────────────────────────────────────────────────────
    def load_cursor(self, scope: str, source: str) -> SourceCursor | None:
        d = _read(self._scope_dir(scope) / "cursors" / f"{_slug(source)}.json")
        return SourceCursor(**d) if d else None

    def save_cursor(self, cursor: SourceCursor) -> None:
        _write(self._scope_dir(cursor.scope) / "cursors" / f"{_slug(cursor.source)}.json",
               cursor.model_dump())

    # ── work items ────────────────────────────────────────────────────────────
    def upsert_items(self, scope: str, items: list[WorkItem]) -> int:
        for it in items:
            path = self._item_path(scope, it.type, it.id)
            existing = _read(path)
            if existing and existing.get("processor_results") and not it.processor_results:
                it = it.model_copy(update={"processor_results": existing["processor_results"]})
            _write(path, it.model_dump())
        return len(items)

    def save_processor_result(self, scope: str, item_type: str, item_id: str,
                              result_key: str, payload: dict, version: int = 1) -> None:
        path = self._item_path(scope, item_type, item_id)
        d = _read(path)
        if d is None:
            return
        results = d.get("processor_results") or {}
        results[result_key] = payload
        d["processor_results"] = results
        _write(path, d)

    # ── relations ─────────────────────────────────────────────────────────────
    def _rel_slug(self, r: WorkItemRelation) -> str:
        return _slug(f"{r.src.scope}~{r.src.type}~{r.src.id}~{r.dst.scope}~{r.dst.type}~"
                     f"{r.dst.id}~{r.kind}")

    def upsert_relations(self, relations: list[WorkItemRelation]) -> int:
        for r in relations:
            _write(self._rel_dir() / f"{self._rel_slug(r)}.json", r.model_dump())
        return len(relations)

    def _all_relations(self) -> list[WorkItemRelation]:
        out = []
        for f in self._rel_dir().glob("*.json"):
            d = _read(f)
            if d:
                out.append(WorkItemRelation(**d))
        return out

    def list_relations(self, ref: WorkItemRef, kind: str = "",
                       incoming: bool = False) -> list[WorkItemRelation]:
        out = []
        for r in self._all_relations():
            end = r.dst if incoming else r.src
            if end.scope == ref.scope and end.type == ref.type and end.id == ref.id \
                    and (not kind or r.kind == kind):
                out.append(r)
        return out

    # ── queries ───────────────────────────────────────────────────────────────
    def list_types(self, scope: str) -> list[str]:
        d = self._scope_dir(scope) / "items"
        return sorted(p.name for p in d.iterdir() if p.is_dir()) if d.exists() else []

    def _all_items(self, scope: str, item_type: str = "") -> list[WorkItem]:
        base = self._scope_dir(scope) / "items"
        type_dirs = [base / _slug(item_type)] if item_type else \
            ([p for p in base.iterdir() if p.is_dir()] if base.exists() else [])
        out = []
        for td in type_dirs:
            for f in td.glob("*.json"):
                d = _read(f)
                if d:
                    out.append(WorkItem(**d))
        out.sort(key=lambda it: it.timestamp, reverse=True)
        return out

    def list_items(self, scope: str, item_type: str = "",
                   limit: int = 200) -> list[WorkItem]:
        return self._all_items(scope, item_type)[:max(1, limit)]

    def get_item(self, scope: str, item_type: str, item_id: str) -> WorkItem | None:
        d = _read(self._item_path(scope, item_type, item_id))
        return WorkItem(**d) if d else None

    def item_count(self, scope: str, item_type: str = "") -> int:
        return len(self._all_items(scope, item_type))

    def clear_scope(self, scope: str) -> None:
        import shutil
        d = self._scope_dir(scope)
        if d.exists():
            shutil.rmtree(d, ignore_errors=True)
        for f in self._rel_dir().glob("*.json"):
            r = _read(f)
            if r and (r.get("src", {}).get("scope") == scope
                      or r.get("dst", {}).get("scope") == scope):
                f.unlink(missing_ok=True)
