"""Built-in persistence providers contributed to ``roadmap.gitmining.persistence``.

Each provider's ``create(env)`` builds its store lazily from the provider environment
(``env.gitmining_dir`` is the workspace-scoped data dir). ``sql`` is the default (see
:class:`~.models.GitMiningConfig`); ``filesystem`` is the database-free alternative. A
satellite plugin adds a Postgres/SQL-Server backend by contributing its own provider.
"""

from __future__ import annotations

from ..contracts import PersistenceProvider
from .fs_store import FilesystemWorkItemStore
from .sql_store import SqliteWorkItemStore

SQL_PROVIDER = PersistenceProvider(
    id="sql",
    label="SQLite (built-in)",
    create=lambda env: SqliteWorkItemStore(env.gitmining_dir / "mining.db"),
    icon="bi-database",
)

FILESYSTEM_PROVIDER = PersistenceProvider(
    id="filesystem",
    label="Filesystem (JSON files)",
    create=lambda env: FilesystemWorkItemStore(env.gitmining_dir / "data"),
    icon="bi-folder",
)

BUILTIN_PERSISTENCE = [SQL_PROVIDER, FILESYSTEM_PROVIDER]
