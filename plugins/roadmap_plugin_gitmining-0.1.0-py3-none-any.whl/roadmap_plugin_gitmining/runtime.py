"""Per-process runtime wiring for the git-mining engine.

Stashes the framework handles at activate time so storage/service/scheduler modules can
read config, resolve the workspace-scoped data dir, and enumerate persistence providers
without threading the context through every call. Because ``ConfigStore.path`` is already
workspace-scoped, everything under ``gitmining_dir()`` is per-workspace automatically.
Mirrors the workflow/brain plugins' ``runtime``.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import (
    GITMINING_PERSISTENCE_POINT, GITMINING_PROCESSORS_POINT, GITMINING_SOURCES_POINT,
)
from .models import GitMiningConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def config_dir() -> Path:
    assert _store is not None, "gitmining runtime not initialised"
    return _store.path.parent


def gitmining_dir() -> Path:
    """Workspace-aware data dir (``<config_dir>/gitmining``). Created on demand."""
    d = config_dir() / "gitmining"
    d.mkdir(parents=True, exist_ok=True)
    return d


def repos_dir() -> Path:
    """Where server-managed repos are cloned (``<config_dir>/gitmining/repos``)."""
    d = gitmining_dir() / "repos"
    d.mkdir(parents=True, exist_ok=True)
    return d


def gitmining_config() -> GitMiningConfig:
    assert _store is not None, "gitmining runtime not initialised"
    raw = _store.load_decrypted()
    return GitMiningConfig(**(raw.get("gitmining") or {}))


def save_gitmining_config(cfg: GitMiningConfig) -> GitMiningConfig:
    """Persist the ``gitmining`` slice back into ``config.yaml`` (encrypting any sensitive
    fields via the config store), leaving the rest of the document untouched."""
    assert _store is not None, "gitmining runtime not initialised"
    raw = _store.load_decrypted()
    raw["gitmining"] = cfg.model_dump()
    _store.save(raw)
    return cfg


def store() -> ConfigStore:
    assert _store is not None, "gitmining runtime not initialised"
    return _store


def services() -> ServiceRegistry:
    assert _services is not None, "gitmining runtime not initialised"
    return _services


def jobs_service():
    """The generic ``roadmap.jobs`` service (a hard dependency — see plugin ``requires``)."""
    return services().require("jobs")


def _providers() -> list:
    if _extensions is None:
        return []
    return list(_extensions.get(GITMINING_PERSISTENCE_POINT))


def persistence_providers() -> list:
    """The registered persistence providers (id/label/icon). Public accessor so the
    service/UI can list the available backends and show which is active."""
    return _providers()


def processor_extensions() -> list:
    """The work-item processors contributed to ``roadmap.gitmining.processors`` (the built-in
    example plus any satellite's). Config-defined AI processors are built separately."""
    if _extensions is None:
        return []
    return list(_extensions.get(GITMINING_PROCESSORS_POINT))


def source_extensions() -> list:
    """The work-item sources contributed to ``roadmap.gitmining.sources`` (built-in ``git``
    plus any satellite's)."""
    if _extensions is None:
        return []
    return list(_extensions.get(GITMINING_SOURCES_POINT))


def resolve_source(source_id: str):
    """The registered :class:`~.contracts.WorkItemSource` with ``source_id``, or ``None``."""
    return next((s for s in source_extensions() if s.id == source_id), None)


def component_env() -> SimpleNamespace:
    """Context handed to a persistence provider's ``create(env)``: the data dir and the
    decrypted config slice (a store may want either)."""
    return SimpleNamespace(config=gitmining_config(), gitmining_dir=gitmining_dir())
