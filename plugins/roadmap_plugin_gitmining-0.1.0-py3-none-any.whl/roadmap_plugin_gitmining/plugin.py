"""Git-mining engine plugin activator.

Declares the two extension points — ``roadmap.gitmining.persistence`` (swappable storage)
and ``roadmap.gitmining.processors`` (pluggable commit processors, wired in phase 2) —
contributes the built-in persistence providers (SQLite default + filesystem), registers the
credential-secret as a sensitive config path, publishes the ``gitmining`` service, mounts
``/api/gitmining``, and contributes a Git Mining settings tab. The scanner/ingestion, the
commit processors, the scheduler, and the frontend land in later phases.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_scheduler import SCHEDULER_TASKS_POINT
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .contracts import (
    GITMINING_PERSISTENCE_POINT, GITMINING_PROCESSORS_POINT, GITMINING_SOURCES_POINT,
    PersistenceProvider, WorkItemSource,
)
from .processors import WorkItemProcessor
from .processors.example import FILE_CATEGORIES_PROCESSOR
from .router import create_gitmining_router
from .service import GitMiningService
from .settings_section import GITMINING_SECRET_PATH, GITMINING_SECTION
from .sources import BUILTIN_SOURCES
from .stores import BUILTIN_PERSISTENCE
from .tasks import SCAN_TASK


class GitMiningPlugin(Plugin):
    id = "roadmap.gitmining"
    name = "Git Mining"
    requires = ["roadmap.settings", "roadmap.context", "roadmap.jobs", "roadmap.scheduler"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)
        ctx.register_sensitive_path(GITMINING_SECRET_PATH)

        # the swappable component: where mined data is stored (SQLite / filesystem / …)
        ctx.define_point(GITMINING_PERSISTENCE_POINT, PersistenceProvider,
                         "Persistence backends that store mined commits, results, and jobs.")
        for provider in BUILTIN_PERSISTENCE:
            ctx.extend(GITMINING_PERSISTENCE_POINT, provider)

        # where work items come from — engine ships the git source (commits + branches);
        # satellites add pull-request / Jira-issue sources with no engine change.
        ctx.define_point(GITMINING_SOURCES_POINT, WorkItemSource,
                         "Sources of work items (git commits, pull requests, Jira issues, …).")
        for src in BUILTIN_SOURCES:
            ctx.extend(GITMINING_SOURCES_POINT, src)

        # the pluggable work-item processors — engine ships the generic example; satellites
        # (and config-defined AI processors) add more without an engine change.
        ctx.define_point(GITMINING_PROCESSORS_POINT, WorkItemProcessor,
                         "Processors that extract structured data from a work item.")
        ctx.extend(GITMINING_PROCESSORS_POINT, FILE_CATEGORIES_PROCESSOR)

        ctx.extend(SETTINGS_SECTIONS_POINT, GITMINING_SECTION)

        # scheduled scanning is provided by roadmap.scheduler — contribute the scan task
        ctx.extend(SCHEDULER_TASKS_POINT, SCAN_TASK)

        gitmining = GitMiningService()
        ctx.services.register("gitmining", gitmining)
        ctx.add_router(create_gitmining_router(gitmining))
