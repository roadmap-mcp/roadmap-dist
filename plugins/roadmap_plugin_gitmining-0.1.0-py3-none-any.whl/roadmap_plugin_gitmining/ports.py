"""The persistence port — the interface every mined record goes through.

:class:`WorkItemStore` is the whole abstraction the ``roadmap.gitmining.persistence``
extension point supplies. The engine reads and writes the generic mined data — work items,
the relations between them, per-processor results, and the per-source ingestion cursor —
*only* through this Protocol, so the storage backend is entirely swappable: the built-in
SQLite (:mod:`.stores.sql_store`) and filesystem (:mod:`.stores.fs_store`) providers implement
it, and a satellite can add a Postgres/SQL-Server one without the engine changing.

A ``@runtime_checkable`` Protocol so ``ctx.extend`` validates a provider's product by
structural ``isinstance``. Everything is keyed by ``scope`` (the container — a repo name or a
project key); identity within a scope is ``(type, id)``. Implementations must be idempotent
(re-ingesting an item or relation upserts, never duplicates).
"""

from __future__ import annotations

from typing import Protocol, runtime_checkable

from .models import SourceCursor, WorkItem, WorkItemRef, WorkItemRelation


@runtime_checkable
class WorkItemStore(Protocol):
    id: str

    # ── lifecycle ─────────────────────────────────────────────────────────────
    def init(self) -> None:
        """Create/upgrade whatever backing structure is needed (tables, dirs). Idempotent."""
        ...

    # ── incremental cursor ────────────────────────────────────────────────────
    def load_cursor(self, scope: str, source: str) -> SourceCursor | None:
        """The last-scan checkpoint for a ``(scope, source)`` pair, or ``None`` if never run."""
        ...

    def save_cursor(self, cursor: SourceCursor) -> None:
        """Persist (upsert) a source cursor."""
        ...

    # ── work items ────────────────────────────────────────────────────────────
    def upsert_items(self, scope: str, items: list[WorkItem]) -> int:
        """Insert-or-update work items (keyed by ``(scope, type, id)``). Returns rows written.
        Idempotent; must preserve existing ``processor_results`` when re-upserting base data."""
        ...

    def save_processor_result(self, scope: str, item_type: str, item_id: str,
                              result_key: str, payload: dict, version: int = 1) -> None:
        """Store one processor's structured output on a work item, under ``result_key``."""
        ...

    # ── relations ─────────────────────────────────────────────────────────────
    def upsert_relations(self, relations: list[WorkItemRelation]) -> int:
        """Insert-or-update edges (keyed by ``(src, dst, kind)``). Returns rows written."""
        ...

    def list_relations(self, ref: WorkItemRef, kind: str = "",
                       incoming: bool = False) -> list[WorkItemRelation]:
        """Edges touching ``ref``: outgoing (``src == ref``) by default, or incoming
        (``dst == ref``) when ``incoming``. Optionally filtered to one ``kind``."""
        ...

    # ── queries (feed the workbench + MCP) ─────────────────────────────────────
    def list_types(self, scope: str) -> list[str]:
        """The distinct work-item types present for ``scope``."""
        ...

    def list_items(self, scope: str, item_type: str = "",
                   limit: int = 200) -> list[WorkItem]:
        """Work items for ``scope`` (optionally one ``type``), newest first by timestamp."""
        ...

    def get_item(self, scope: str, item_type: str, item_id: str) -> WorkItem | None:
        """One work item by identity, with its processor results, or ``None``."""
        ...

    def item_count(self, scope: str, item_type: str = "") -> int:
        """Count of work items for ``scope`` (optionally one ``type``)."""
        ...

    def clear_scope(self, scope: str) -> None:
        """Drop all mined data for ``scope`` (items, results, relations, cursors) — used when a
        repo is removed or before a full re-mine. Job history (in ``roadmap.jobs``) is
        unaffected."""
        ...
