"""Work-item processors — pluggable analyzers that extract structured data from a work item.

A processor inspects a :class:`~.models.WorkItem` and emits a structured payload the engine
stores on it (keyed by :attr:`WorkItemProcessor.result_key`). Contributed through the
``roadmap.gitmining.processors`` extension point: the engine ships the generic
:class:`~.example.FileCategoriesProcessor`, config-defined AI processors are built on top, and
a satellite adds more by extending the point.

A processor declares the work-item ``types`` it handles (``["git_commit"]``, ``["jira_issue"]``,
…) so the engine only runs it on relevant items. ``detect(item)`` decides whether a given item
is relevant; ``process(item, ctx)`` returns the payload. ``ctx`` exposes source-provided
capabilities — notably ``ctx.read_file(item, path)`` for sources (like git) that can supply
file content. Processors MUST be read-only.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import WorkItem


class WorkItemProcessor(ABC):
    """Base class for work-item processors (contributed to ``roadmap.gitmining.processors``)."""

    name: str = ""            # unique id, e.g. "file_categories"
    label: str = ""           # display name
    description: str = ""     # short UI/catalog text
    result_key: str = ""      # key the payload is stored under on the item
    types: list[str] = []     # work-item types this processor handles
    version: int = 1          # bump to force reprocessing
    snapshot: bool = False    # while True, reprocess on every run (dev mode)

    def handles(self, item_type: str) -> bool:
        return not self.types or item_type in self.types

    @abstractmethod
    def detect(self, item: WorkItem) -> bool:
        """Whether this processor applies to ``item`` (``False`` ⇒ skip it)."""

    @abstractmethod
    def process(self, item: WorkItem, ctx) -> dict | None:
        """Extract structured data from ``item``. ``ctx.read_file(item, path)`` reads content
        when the item's source supports it. Return the payload dict, or ``None`` to store
        nothing. The payload SHOULD include a stable summary of what it processed."""


def resolve_processors(extension_processors: list, config) -> list[WorkItemProcessor]:
    """The active processors for a run: the extension-point processors plus the config-defined
    AI processors, minus any disabled by name. Built fresh each run so config edits take
    effect immediately."""
    from .ai import build_ai_processors
    disabled = set(getattr(config, "disabled_processors", []) or [])
    out: list[WorkItemProcessor] = [
        p for p in extension_processors
        if isinstance(p, WorkItemProcessor) and p.name not in disabled
    ]
    out.extend(p for p in build_ai_processors(config) if p.name not in disabled)
    return out


def processor_catalog(extension_processors: list, config) -> list[dict]:
    """``{name, label, description, result_key, types, kind}`` for every available processor —
    the self-describing list the settings UI renders (``kind`` ∈ ``builtin|ai``)."""
    out = []
    for p in extension_processors:
        if isinstance(p, WorkItemProcessor):
            out.append({"name": p.name, "label": p.label or p.name,
                        "description": p.description, "result_key": p.result_key,
                        "types": list(p.types), "kind": "builtin"})
    from .ai import build_ai_processors
    for p in build_ai_processors(config):
        out.append({"name": p.name, "label": p.label or p.name,
                    "description": p.description, "result_key": p.result_key,
                    "types": list(p.types), "kind": "ai"})
    return out
