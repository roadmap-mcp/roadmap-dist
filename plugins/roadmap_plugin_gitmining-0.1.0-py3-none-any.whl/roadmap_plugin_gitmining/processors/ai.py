"""Prompt-driven work-item processors, built from :class:`~.models.AIProcessorDef` config.

Each config entry becomes an :class:`AIProcessor`: it detects ``git_commit`` items touching
files whose paths match its regex ``file_patterns`` and asks the ``ai`` service to extract
structured data per its ``instructions``, reading file content through ``ctx.read_file``. The
family is dormant by default (no AI processors until the user defines one), and any processor
degrades to "skipped" (returns ``None``) if the ``ai`` service is absent or a call fails, so
mining never hard-depends on AI.
"""

from __future__ import annotations

import json
import re

from . import WorkItemProcessor
from .. import runtime
from ..models import WorkItem

_MAX_FILE_CHARS = 12_000


class AIProcessor(WorkItemProcessor):
    types = ["git_commit"]

    def __init__(self, definition) -> None:
        self.name = definition.name
        self.label = definition.label or definition.name
        self.description = definition.description
        self.result_key = f"ai_{definition.name}"
        self.version = definition.version
        self.instructions = definition.instructions
        self._patterns = [re.compile(p) for p in definition.file_patterns if p]

    def _matched_files(self, item: WorkItem) -> list[str]:
        files = item.details.get("files_changed") or []
        if not self._patterns:
            return []
        return [f for f in files if any(p.search(f) for p in self._patterns)]

    def detect(self, item: WorkItem) -> bool:
        return bool(self._matched_files(item))

    def process(self, item: WorkItem, ctx) -> dict | None:
        ai = _ai_service()
        matched = self._matched_files(item)
        if ai is None or not matched:
            return None
        read = getattr(ctx, "read_file", None)
        blobs = []
        for f in matched[:20]:
            content = (read(item, f) if read else "")[:_MAX_FILE_CHARS]
            if content:
                blobs.append(f"### {f}\n{content}")
        if not blobs:
            return None
        system = ("You extract structured data from source files for a git-mining index. "
                  "Follow the instructions and reply with ONLY a JSON object, no prose.\n\n"
                  f"Instructions:\n{self.instructions}")
        user = "Files changed in this commit:\n\n" + "\n\n".join(blobs)
        try:
            provider = ai.provider_for_task("gitmining_processor")
            text = ai.chat_text(provider, [{"role": "system", "content": system},
                                           {"role": "user", "content": user}])
        except Exception:
            return None
        payload = _parse_json(text)
        payload.setdefault("files", matched)
        return payload


def _ai_service():
    try:
        return runtime.services().get("ai")
    except Exception:
        return None


def _parse_json(text: str) -> dict:
    text = (text or "").strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[-1].rsplit("```", 1)[0]
    try:
        val = json.loads(text)
        return val if isinstance(val, dict) else {"result": val}
    except (json.JSONDecodeError, TypeError):
        return {"raw": text[:2000]}


def build_ai_processors(config) -> list[AIProcessor]:
    """Instantiate an :class:`AIProcessor` per configured definition (empty by default)."""
    defs = getattr(config, "ai_processors", None) or []
    return [AIProcessor(d) for d in defs if getattr(d, "name", "")]
