"""The built-in example processor — a generic, language-agnostic categorizer for commits.

Demonstrates the :class:`~.WorkItemProcessor` contract without any framework/language
specificity. For every ``git_commit`` work item it categorizes the changed files (read from
the item's ``details.files_changed``) by extension and top-level directory and flags whether
documentation/config/test files were touched — cheap, deterministic, and a clean smoke test
of the pipeline. It reads no file content, so it works from ``details`` alone.
"""

from __future__ import annotations

from . import WorkItemProcessor
from ..models import WorkItem

_DOC_HINT = ("readme", "changelog", "license", "contributing")
_CONFIG_EXT = {".yaml", ".yml", ".toml", ".ini", ".env", ".properties", ".json", ".xml"}
_TEST_HINT = ("test", "spec")


def _ext(path: str) -> str:
    base = path.rsplit("/", 1)[-1]
    return base[base.rindex("."):].lower() if "." in base else ""


def _top_dir(path: str) -> str:
    return path.split("/", 1)[0] if "/" in path else "(root)"


class FileCategoriesProcessor(WorkItemProcessor):
    name = "file_categories"
    label = "File categories"
    description = ("Categorizes a commit's changed files by extension and top-level directory, "
                  "and flags docs/config/test changes. Language-agnostic.")
    result_key = "file_categories"
    types = ["git_commit"]
    version = 1

    def _files(self, item: WorkItem) -> list[str]:
        return item.details.get("files_changed") or []

    def detect(self, item: WorkItem) -> bool:
        return bool(self._files(item))

    def process(self, item: WorkItem, ctx) -> dict | None:
        files = self._files(item)
        if not files:
            return None
        by_extension: dict[str, int] = {}
        by_top_dir: dict[str, int] = {}
        for f in files:
            by_extension[_ext(f) or "(none)"] = by_extension.get(_ext(f) or "(none)", 0) + 1
            by_top_dir[_top_dir(f)] = by_top_dir.get(_top_dir(f), 0) + 1
        lower = [f.lower() for f in files]
        return {
            "files": files,
            "file_count": len(files),
            "by_extension": dict(sorted(by_extension.items())),
            "by_top_dir": dict(sorted(by_top_dir.items())),
            "touches_docs": any(h in f for f in lower for h in _DOC_HINT)
                            or any(_ext(f) == ".md" for f in files),
            "touches_config": any(_ext(f) in _CONFIG_EXT for f in files),
            "touches_tests": any(h in f for f in lower for h in _TEST_HINT),
        }


FILE_CATEGORIES_PROCESSOR = FileCategoriesProcessor()
