"""Persistence factory — resolve and build the configured :class:`~.ports.WorkItemStore`.

Reads ``gitmining.persistence`` from config, finds the matching provider among those
registered on the extension point, builds the store, and calls ``init()``. Falls back to
the built-in default id (``sql``), then to the first registered provider, so a mis-typed
config name degrades instead of crashing (same pattern as the Brain's ``components``).
"""

from __future__ import annotations

from . import runtime
from .ports import WorkItemStore


def _resolve(providers: list, wanted: str, default_id: str):
    by_id = {p.id: p for p in providers}
    if wanted in by_id:
        return by_id[wanted]
    if default_id in by_id:
        return by_id[default_id]
    if providers:
        return providers[0]
    raise RuntimeError("no git-mining persistence provider is registered")


def build_store() -> WorkItemStore:
    cfg = runtime.gitmining_config()
    provider = _resolve(runtime.persistence_providers(), cfg.persistence, "sql")
    store = provider.create(runtime.component_env())
    store.init()
    return store
