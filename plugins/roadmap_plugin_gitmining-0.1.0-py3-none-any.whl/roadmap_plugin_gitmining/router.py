"""HTTP surface: ``/api/gitmining``.

Phase 1: CRUD for server-managed mining repos + the credential vault (write-only secrets),
the persistence-provider list/selector, and read access to mined data (repo status,
commits, jobs). The scan/ingest endpoints and the scheduler are added in later phases.
"""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

from .models import MiningRepo


class CredentialWriteRequest(BaseModel):
    name: str
    username: str = ""
    secret: str = ""          # blank = keep existing; never returned by any GET


class PersistenceRequest(BaseModel):
    provider: str


class IngestRequest(BaseModel):
    branches: list[str] | None = None
    mode: str = "incremental"          # incremental | full


def create_gitmining_router(gitmining) -> APIRouter:
    router = APIRouter(prefix="/api/gitmining", tags=["gitmining"])

    # ── persistence providers ──────────────────────────────────────────────────
    @router.get("/persistence")
    def list_persistence():
        return {"providers": gitmining.list_persistence()}

    @router.put("/persistence")
    def set_persistence(req: PersistenceRequest):
        cfg = gitmining.set_persistence(req.provider)
        return {"persistence": cfg.persistence}

    # ── commit processors (self-describing catalog) ────────────────────────────
    @router.get("/processors")
    def list_processors():
        return {"processors": gitmining.list_processors()}

    # ── mining repos (server-managed) ──────────────────────────────────────────
    @router.get("/repos")
    def list_repos():
        return {"repos": [r.model_dump() for r in gitmining.list_repos()]}

    @router.get("/repos/{name}")
    def get_repo(name: str):
        r = gitmining.get_repo(name)
        if r is None:
            raise HTTPException(status_code=404, detail="Mining repo not found.")
        return r.model_dump()

    @router.post("/repos")
    def create_repo(repo: MiningRepo):
        if gitmining.get_repo(repo.name):
            raise HTTPException(status_code=409, detail="A repo with that name exists.")
        return gitmining.save_repo(repo).model_dump()

    @router.put("/repos/{name}")
    def update_repo(name: str, repo: MiningRepo):
        repo.name = name
        return gitmining.save_repo(repo).model_dump()

    @router.delete("/repos/{name}")
    def delete_repo(name: str):
        return {"deleted": gitmining.delete_repo(name)}

    @router.get("/repos/{name}/status")
    def repo_status(name: str):
        if gitmining.get_repo(name) is None:
            raise HTTPException(status_code=404, detail="Mining repo not found.")
        return gitmining.repo_status(name)

    # ── scan + ingest ──────────────────────────────────────────────────────────
    @router.post("/scan")
    def scan_all(ingest: bool = False):
        """Fetch every enabled repo's mirror and report which branches changed; when
        ``ingest`` is set, start an incremental ingest for each changed repo."""
        return gitmining.scan(None, ingest)

    @router.post("/repos/{name}/scan")
    def scan_repo(name: str, ingest: bool = False):
        if gitmining.get_repo(name) is None:
            raise HTTPException(status_code=404, detail="Mining repo not found.")
        return gitmining.scan([name], ingest)

    @router.post("/repos/{name}/ingest")
    def ingest_repo(name: str, req: IngestRequest):
        """Start a background ingest for one repo; returns the job to poll via GET /jobs/{id}."""
        if gitmining.get_repo(name) is None:
            raise HTTPException(status_code=404, detail="Mining repo not found.")
        return gitmining.start_ingest(name, req.branches, req.mode).model_dump()

    @router.get("/repos/{name}/items")
    def repo_items(name: str, type: str = "", limit: int = 200):
        """Mined work items for a repo, newest first. Filter to one ``type`` (e.g.
        ``git_commit``, ``branch``) or omit for all."""
        return {"items": [it.model_dump() for it in gitmining.list_items(name, type, limit)]}

    @router.get("/repos/{name}/items/{item_type}/{item_id}")
    def repo_item(name: str, item_type: str, item_id: str):
        """One work item with its outgoing + incoming relations."""
        it = gitmining.get_item(name, item_type, item_id)
        if it is None:
            raise HTTPException(status_code=404, detail="Work item not found.")
        return it

    # ── credentials (write + metadata only; no secret is ever returned) ────────
    @router.get("/credentials")
    def list_credentials():
        return {"credentials": gitmining.list_credentials()}

    @router.post("/credentials")
    def save_credential(req: CredentialWriteRequest):
        return gitmining.save_credential(req.name, req.username, req.secret)

    @router.delete("/credentials/{name}")
    def delete_credential(name: str):
        return {"deleted": gitmining.delete_credential(name)}

    # ── ingest run history (a repo-scoped view over the shared roadmap.jobs store) ──
    @router.get("/jobs")
    def list_jobs(repo: str = "", limit: int = 50):
        return {"jobs": gitmining.list_jobs(repo, limit)}

    @router.get("/jobs/{job_id}")
    def get_job(job_id: str):
        j = gitmining.get_job(job_id)
        if j is None:
            raise HTTPException(status_code=404, detail="Job not found.")
        return j

    return router
