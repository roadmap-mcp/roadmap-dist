"""The scan + ingestion engine (generic over work-item sources).

Storage-agnostic (everything goes through the active :class:`~.ports.WorkItemStore`) and
source-agnostic (items come from a :class:`~.contracts.WorkItemSource`):

* :func:`check_remotes` — the cheap "what changed?" probe for git repos: fetch each mirror and
  compare tracked branch tips against the stored cursor. Optionally kicks an ingest for the
  changed repos (what the scheduler's ``gitmining.scan`` task calls).
* :func:`run_ingest` — the real work for one scope: ask the source to ``fetch`` new work items
  + relations since the cursor, upsert them, run every applicable processor on the new items,
  store results, and advance the cursor. Runs on a daemon thread via :func:`start_ingest_async`
  (through the ``jobs`` service, which re-pins ``current_workspace``).

A scope is a :class:`~.models.MiningRepo` today (source ``git``); the same loop serves a
future pull-request or Jira source unchanged.
"""

from __future__ import annotations

from datetime import datetime
from types import SimpleNamespace

from . import gitops, runtime
from .models import SourceCursor
from .processors import resolve_processors

_GIT_SOURCE = "git"          # repos are mined by the git source


def _now() -> str:
    return datetime.now().astimezone().isoformat(timespec="seconds")


def _find_cred(cfg, name: str):
    return next((c for c in cfg.credentials if c.name == name), None) if name else None


# ── scan (cheap tip comparison for git repos) ─────────────────────────────────

def check_remotes(gitmining, repo_names: list[str] | None = None,
                  ingest: bool = False) -> dict:
    """Fetch each enabled repo's mirror and report which tracked branches moved (vs the stored
    git cursor). When ``ingest`` is set, start an incremental ingest for every changed repo."""
    cfg = runtime.gitmining_config()
    store = gitmining.store()
    results: list[dict] = []
    jobs_started: list[str] = []

    repos = [r for r in cfg.repos if r.enabled
             and (not repo_names or r.name in repo_names)]
    for repo in repos:
        cred = _find_cred(cfg, repo.credential)
        try:
            mirror = gitops.ensure_mirror(runtime.repos_dir(), repo, cred)
        except gitops.GitError as ex:
            results.append({"repo": repo.name, "status": "error", "detail": str(ex)})
            continue

        cursor = store.load_cursor(repo.name, _GIT_SOURCE)
        stored = (cursor.cursor.get("branch_tips", {}) if cursor else {})
        branches = repo.branches or gitops.list_branches(mirror)
        changed = [br for br in branches
                   if (t := gitops.branch_tip(mirror, br)) and t != stored.get(br)]

        entry = {"repo": repo.name, "branches": branches, "changed_branches": changed,
                 "has_changes": bool(changed),
                 "status": "changed" if changed else "up_to_date"}
        if changed and ingest:
            job = start_ingest_async(gitmining, repo.name, changed, mode="incremental")
            entry["job_id"] = job.id
            entry["status"] = "ingestion_started"
            jobs_started.append(job.id)
        results.append(entry)

    return {"checked": len(results),
            "changed": sum(1 for r in results if r.get("has_changes")),
            "jobs_started": jobs_started, "results": results}


# ── ingest (fetch via source → upsert items + relations → process → advance cursor) ──

def _do_ingest(gitmining, job_id: str, repo_name: str,
               branches: list[str] | None, mode: str) -> None:
    """Ingest one scope through its work-item source. Progress is reported through the generic
    ``jobs`` service; a fatal error is raised so ``run_async`` records it as a failed job."""
    jobs = runtime.jobs_service()
    store = gitmining.store()
    cfg = runtime.gitmining_config()

    repo = next((r for r in cfg.repos if r.name == repo_name), None)
    if repo is None:
        raise RuntimeError(f"Mining repo '{repo_name}' not found.")
    source = runtime.resolve_source(_GIT_SOURCE)
    if source is None:
        raise RuntimeError("No 'git' work-item source is registered.")

    scope = repo_name
    if mode == "full":
        store.clear_scope(scope)      # mined data only; job history lives in roadmap.jobs
    cursor = None if mode == "full" else store.load_cursor(scope, source.id)
    cursor_data = cursor.cursor if cursor else {}

    sctx = SimpleNamespace(
        scope=scope, repo=repo, cursor=cursor_data,
        credential=_find_cred(cfg, repo.credential),
        repos_dir=runtime.repos_dir(), branches=branches, services=runtime.services())

    procs = resolve_processors(runtime.processor_extensions(), cfg)
    jobs.log(job_id, f"Source '{source.id}' ({mode} mode) — "
                     f"processors: {', '.join(p.name for p in procs) or '(none)'}")

    result = source.fetch(sctx)
    store.upsert_items(scope, result.items)
    store.upsert_relations(result.relations)
    jobs.log(job_id, f"{len(result.items)} work item(s), {len(result.relations)} relation(s).")

    # a per-item content reader, backed by the source (if it supports content)
    proc_ctx = SimpleNamespace(
        scope=scope,
        read_file=(lambda item, path: source.reader(sctx, item, path)) if source.reader
                  else (lambda item, path: ""))

    processed: dict[str, int] = {}
    for item in result.items:
        for p in procs:
            if not p.handles(item.type) or not p.detect(item):
                continue
            try:
                payload = p.process(item, proc_ctx)
            except Exception as ex:      # a processor failure never fails the run
                jobs.log(job_id, f"Processor '{p.name}' failed on {item.type}:{item.id}: {ex}",
                         "warn")
                continue
            if payload is not None:
                store.save_processor_result(scope, item.type, item.id, p.result_key,
                                            payload, p.version)
                processed[p.name] = processed.get(p.name, 0) + 1

    store.save_cursor(SourceCursor(
        scope=scope, source=source.id, cursor=result.cursor,
        processor_versions={p.name: p.version for p in procs}, last_ingested_at=_now()))

    proc_summary = ", ".join(f"{n}×{c}" for n, c in processed.items()) or "no matches"
    jobs.finish(job_id, summary=f"{len(result.items)} item(s); processors: {proc_summary}")


def start_ingest_async(gitmining, repo_name: str, branches: list[str] | None = None,
                       mode: str = "incremental"):
    """Kick a background ingest through the ``jobs`` service (owner ``gitmining``, kind
    ``ingest``) and return the created :class:`~roadmap_plugin_jobs.Job` to poll."""
    jobs = runtime.jobs_service()
    title = f"Ingest {repo_name} ({mode})"
    data = {"repo": repo_name, "mode": mode, "branches": branches or []}
    return jobs.run_async(
        "gitmining", "ingest", title,
        lambda job_id: _do_ingest(gitmining, job_id, repo_name, branches, mode),
        data=data)
