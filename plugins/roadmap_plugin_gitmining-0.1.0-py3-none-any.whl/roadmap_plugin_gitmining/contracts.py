"""The git-mining engine's extension points.

Three swappable seams — all around the generic *work item* model, so new kinds of mined work
drop in without touching the engine:

* ``roadmap.gitmining.persistence`` — where mined data is stored. A
  :class:`PersistenceProvider`'s ``create(env)`` lazily builds a :class:`~.ports.WorkItemStore`.
  Built-in ``sql`` (SQLite) + ``filesystem``; a satellite adds Postgres/SQL-Server. Chosen by
  config (``gitmining.persistence``).

* ``roadmap.gitmining.sources`` — where work items *come from*. A :class:`WorkItemSource`
  fetches new items + relations for a scope since a cursor. Built-in ``git`` (commits +
  branches); a satellite adds pull-request or Jira-issue sources with no engine change.

* ``roadmap.gitmining.processors`` — pluggable processors that extract structured data from a
  work item. A processor declares which item ``types`` it handles.

Other plugins re-import the point ids + dataclasses from the package root (see ``__init__``).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Callable

#: Persistence backends supply a :class:`~.ports.WorkItemStore` here.
GITMINING_PERSISTENCE_POINT = "roadmap.gitmining.persistence"

#: Work-item sources (git commits, pull requests, Jira issues, …) are contributed here.
GITMINING_SOURCES_POINT = "roadmap.gitmining.sources"

#: Work-item processors are contributed here.
GITMINING_PROCESSORS_POINT = "roadmap.gitmining.processors"


@dataclass
class PersistenceProvider:
    """Registers a named :class:`~.ports.WorkItemStore` implementation.

    ``create(env)`` receives the provider environment (see ``runtime.component_env``: the
    data dir + decrypted config slice) and returns a ready store. ``id`` is what
    ``gitmining.persistence`` selects on (``"sql"``, ``"filesystem"``, …).
    """

    id: str
    label: str
    create: Callable[[Any], Any]          # create(env) -> WorkItemStore
    icon: str = "bi-database"


@dataclass
class FetchResult:
    """What a :class:`WorkItemSource.fetch` returns: the new/updated work items, the relations
    among them (and to items in other sources — e.g. a commit ``references`` a Jira issue), and
    the new cursor value to persist for incremental continuation."""

    items: list                           # list[WorkItem]
    relations: list                       # list[WorkItemRelation]
    cursor: dict                          # source-defined next cursor


@dataclass
class WorkItemSource:
    """Registers a source of work items.

    ``fetch(sctx)`` receives a source context (``runtime.source_context``: the ``scope``, the
    scope's config e.g. a :class:`~.models.MiningRepo`, the current ``cursor`` dict, the
    resolved credential, the data dir, and the services) and returns a :class:`FetchResult`.
    ``reader(sctx, item, path)`` optionally reads content for one of this source's items (git
    uses it to read a file at a commit) — processors that need content go through it. ``types``
    lists the work-item types this source produces (for display/routing).
    """

    id: str                               # "git", "bitbucket", "jira", …
    label: str
    types: list                           # list[str] of work-item types produced
    fetch: Callable[[Any], FetchResult]   # fetch(sctx) -> FetchResult
    reader: Callable[[Any, Any, str], str] | None = None   # reader(sctx, item, path) -> str
    icon: str = "bi-box"
