"""The Git Mining settings section (the ``gitmining`` config slice + defaults).

Declares the sensitive path for credential secrets so they are encrypted at rest. The
matching frontend tab (persistence choice, scan schedule, credentials, processors) is
registered separately under the same ``id`` in phase 4.
"""

from roadmap_plugin_settings import SettingsSection

from .models import GitMiningConfig

#: dotted path to the encrypted credential secret (``*`` matches every credential entry).
GITMINING_SECRET_PATH = "gitmining.credentials.*.secret"

GITMINING_SECTION = SettingsSection(
    id="gitmining",
    label="Git Mining",
    order=54,
    group="Information Sources",
    defaults=lambda: {"gitmining": GitMiningConfig().model_dump()},
    sensitive_fields=[GITMINING_SECRET_PATH],
)
