"""The scheduled task git mining contributes to ``roadmap.scheduler``.

A single "gitmining.scan" task: fetch every enabled repo's mirror, and for each tracked
branch that moved since the last checkpoint, start an incremental ingest job. The scheduler
invokes ``run`` per workspace with ``current_workspace`` already pinned, so it operates on the
right tenant's repos and store. The cron + enabled for it live in the scheduler's central
config (disabled by default — no automatic scanning until the user turns it on).
"""

from __future__ import annotations

from roadmap_plugin_scheduler import ScheduledTask

from . import runtime


def _scan_all() -> None:
    gitmining = runtime.services().require("gitmining")
    gitmining.scan(None, ingest=True)


SCAN_TASK = ScheduledTask(
    id="gitmining.scan",
    label="Scan git-mining repositories",
    description="Fetch each server-managed repo and ingest any branch that changed.",
    run=_scan_all,
    default_cron="0 * * * *",     # hourly
    default_enabled=False,
)
