"""Pydantic models for the git-mining domain.

Two distinct data planes, deliberately kept apart:

* **Configuration** (the ``gitmining`` slice of ``config.yaml``, edited in the Git Mining
  settings page): the server-managed :class:`MiningRepo` list, the :class:`MiningCredential`
  vault, and the selected persistence provider. (Scan scheduling lives in ``roadmap.scheduler``.) These are
  *server-managed* repos — a remote URL + tracked branches the server clones and fetches
  itself — as opposed to the local-development ``repositories`` owned by the context plugin.
* **Mined data** — a **generic unit-of-work model** so the engine isn't tied to git commits.
  A :class:`WorkItem` has a ``type`` (``git_commit`` / ``branch`` / later ``pull_request`` /
  ``jira_issue``) that determines its JSON ``details``; :class:`WorkItemRelation` edges connect
  them (a commit's ``parent`` commit, its ``on_branch`` branch, a ``references`` link to a Jira
  issue that may not be ingested yet). A :class:`SourceCursor` is the per-source incremental
  checkpoint. All of it is persisted through the swappable :class:`~.ports.WorkItemStore`
  (SQLite by default, filesystem, or a satellite). New item *types* come from **sources**
  (``roadmap.gitmining.sources``); git commits are just the first one.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


# ── configuration plane (config.yaml `gitmining` slice) ───────────────────────

class MiningRepo(BaseModel):
    """A server-managed git repository to mine.

    Unlike a local-development repo (a filesystem ``path`` the context plugin points at),
    a mining repo is defined by its ``remote_url`` + the ``branches`` to track; the server
    clones it into its own area (``<config_dir>/gitmining/repos/<name>.git``) and fetches
    it on a schedule. ``credential`` names a :class:`MiningCredential` for private remotes
    (blank for public/anonymous). ``name`` is the stable id (unique, no dots).
    """

    name: str
    remote_url: str = ""
    branches: list[str] = Field(default_factory=list)
    credential: str = ""                            # MiningCredential.name, or "" for public
    enabled: bool = True


class MiningCredential(BaseModel):
    """A git remote credential (HTTPS username + secret token/password).

    ``secret`` is stored encrypted at rest (registered as a sensitive config path) and is
    injected server-side only when cloning/fetching — never returned by any API. ``name``
    is referenced from :attr:`MiningRepo.credential`.
    """

    name: str
    username: str = ""
    secret: str = ""                                # encrypted at rest; never serialized back


# Scan scheduling is owned by the generic ``roadmap.scheduler`` plugin: git mining contributes
# a "gitmining.scan" task and the cron + enabled for it live in the scheduler's central config
# (Scheduler settings tab), not here.


class AIProcessorDef(BaseModel):
    """A user-defined, prompt-driven commit processor (built from config at run time).

    Detects commits touching files matching ``file_patterns`` (regexes) and asks the AI to
    extract structured data per ``instructions``. ``version`` bumps force reprocessing.
    ``result_key`` defaults to ``ai_<name>``. Dormant unless the ``ai`` service is present.
    """

    name: str
    label: str = ""
    description: str = ""
    instructions: str = ""
    file_patterns: list[str] = Field(default_factory=list)
    version: int = 1


class GitMiningConfig(BaseModel):
    """The ``gitmining`` config slice (the Git Mining settings tab + page).

    ``persistence`` selects the active :class:`~.ports.WorkItemStore` provider by id
    (``sql`` = SQLite default, ``filesystem``, or a satellite's id).
    """

    persistence: str = "sql"
    repos: list[MiningRepo] = Field(default_factory=list)
    credentials: list[MiningCredential] = Field(default_factory=list)
    ai_processors: list[AIProcessorDef] = Field(default_factory=list)
    disabled_processors: list[str] = Field(default_factory=list)


# ── mined-data plane (generic units of work, persisted through the WorkItemStore) ──

class WorkItem(BaseModel):
    """One **unit of work** — the generic mined entity. ``type`` is the discriminator that
    determines the shape of ``details`` (a JSON blob of the type-specific fields), so new
    kinds of work (pull requests, Jira issues) need no schema change — only a new ``type``
    string and a source that produces it.

    Only the fields the store and UI need to *list, sort, and key on* are promoted to their
    own columns; everything else lives in ``details``. Identity is the triple
    ``(scope, type, id)``: ``scope`` is the container (a repo name for commits/branches, a
    project key for Jira issues), ``id`` is stable within ``(scope, type)`` — a short commit
    hash, a branch name, a PR number, an issue key.

    ``details`` examples::

        git_commit  {full_hash, author_name, author_email, message, files_changed, parents, issue_keys}
        branch      {tip}
        (later) jira_issue {status, assignee, labels, priority, ...}

    ``processor_results`` is keyed by processor ``result_key`` → its structured payload.
    """

    scope: str
    type: str                                       # git_commit | branch | pull_request | jira_issue | …
    id: str
    title: str = ""                                 # one-line summary for listing
    timestamp: str = ""                             # ISO; primary sort time
    details: dict = Field(default_factory=dict)     # ALL type-specific fields
    processor_results: dict = Field(default_factory=dict)  # {result_key: payload}


class WorkItemRef(BaseModel):
    """A pointer to a :class:`WorkItem` by identity — a relation endpoint. Carries ``scope``
    so relations can cross scopes (a commit in a repo → a Jira issue in a project)."""

    scope: str
    type: str
    id: str


class WorkItemRelation(BaseModel):
    """A generic directed edge between two work items. The endpoints are references, so an
    edge may point at an item that isn't ingested yet (e.g. a commit ``references`` a Jira
    issue before any Jira source runs — the edge lights up once it is). ``kind`` examples:
    ``parent`` (commit→commit), ``on_branch`` (commit→branch), ``tip`` (branch→commit),
    ``references`` (commit→jira_issue)."""

    src: WorkItemRef
    dst: WorkItemRef
    kind: str
    attributes: dict = Field(default_factory=dict)


class SourceCursor(BaseModel):
    """The incremental checkpoint for one ``(scope, source)`` pair. ``cursor`` is
    source-defined — git puts ``{"branch_tips": {branch: tip}}`` in it, a Jira source would
    put ``{"updated_since": "…"}``. ``processor_versions`` drives reprocessing when a
    processor is bumped."""

    scope: str
    source: str                                     # the source id, e.g. "git"
    cursor: dict = Field(default_factory=dict)
    processor_versions: dict[str, int] = Field(default_factory=dict)
    last_ingested_at: str = ""


# Scan/ingest run records live in the generic ``roadmap.jobs`` plugin (owner ``gitmining``,
# kind ``ingest``) — not here — so job history is a reusable facility shared across plugins.
