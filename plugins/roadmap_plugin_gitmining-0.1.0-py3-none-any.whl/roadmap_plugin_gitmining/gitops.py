"""Git plumbing for server-managed mining repos — clone, fetch, and read history.

The server owns each repo as a **bare mirror** under ``<config_dir>/gitmining/repos/<name>.git``
(``git clone --mirror``): no working tree, all remote refs kept in sync by ``git fetch``.
Everything here shells out to ``git`` read-only against that mirror; processors read file
content with ``git show <hash>:<path>`` (no checkout needed).

Credentials: for a private HTTPS remote a :class:`MiningCredential` (username + secret) is
injected into the URL **only at command time**. The stored origin is scrubbed to the clean
URL so the token never lands in the mirror's on-disk config; each fetch re-supplies it.
Local-path remotes (used in tests) need no credential.
"""

from __future__ import annotations

import re
import subprocess
from pathlib import Path
from urllib.parse import quote, urlsplit, urlunsplit

from .models import MiningCredential, MiningRepo

_ISSUE_KEY_RE = re.compile(r"\b([A-Z][A-Z0-9]+-\d+)\b")

# unit/record separators used to parse `git log` unambiguously
_US = "\x1f"
_COMMIT = "\x1eCOMMIT\x1f"
_FMT = _COMMIT + _US.join(["%H", "%h", "%P", "%an", "%ae", "%aI", "%s"])


class GitError(RuntimeError):
    pass


def _run(args: list[str], cwd: Path | None = None, timeout: int = 120) -> str:
    """Run a git command, returning stdout. Raises :class:`GitError` on failure.

    ``GIT_TERMINAL_PROMPT=0`` so a missing/instant-fail credential never blocks on an
    interactive prompt (which would hang a background scan)."""
    proc = subprocess.run(
        ["git", *args], cwd=str(cwd) if cwd else None,
        capture_output=True, text=True, encoding="utf-8", errors="replace",
        timeout=timeout, env={"GIT_TERMINAL_PROMPT": "0", "GIT_ASKPASS": "echo",
                              "PATH": _path_env()})
    if proc.returncode != 0:
        raise GitError((proc.stderr or proc.stdout or "git failed").strip())
    return proc.stdout


def _path_env() -> str:
    import os
    return os.environ.get("PATH", "")


def _authed_url(remote_url: str, cred: MiningCredential | None) -> str:
    """Inject ``user:secret`` into an http(s) URL for a single command. Non-http remotes
    (local paths, ssh) are returned unchanged."""
    if not cred or not (cred.username or cred.secret):
        return remote_url
    parts = urlsplit(remote_url)
    if parts.scheme not in ("http", "https"):
        return remote_url
    userinfo = quote(cred.username, safe="")
    if cred.secret:
        userinfo += ":" + quote(cred.secret, safe="")
    netloc = f"{userinfo}@{parts.hostname or ''}"
    if parts.port:
        netloc += f":{parts.port}"
    return urlunsplit((parts.scheme, netloc, parts.path, parts.query, parts.fragment))


def mirror_path(repos_dir: Path, name: str) -> Path:
    return repos_dir / f"{name}.git"


def ensure_mirror(repos_dir: Path, repo: MiningRepo,
                  cred: MiningCredential | None = None, timeout: int = 300) -> Path:
    """Clone the repo as a bare mirror if absent, else fetch updates. Returns the mirror dir.

    The token (if any) is used for the network op but never persisted: after a fresh clone
    the stored origin is reset to the clean URL, and fetch re-supplies the token via an
    explicit authenticated refspec fetch rather than the stored remote.
    """
    repos_dir.mkdir(parents=True, exist_ok=True)
    path = mirror_path(repos_dir, repo.name)
    authed = _authed_url(repo.remote_url, cred)
    if not (path / "HEAD").exists():
        _run(["clone", "--mirror", authed, str(path)], timeout=timeout)
        if authed != repo.remote_url:
            _run(["remote", "set-url", "origin", repo.remote_url], cwd=path)
    else:
        # update all head refs from the (re-)authenticated source
        _run(["fetch", "--prune", authed, "+refs/heads/*:refs/heads/*"],
             cwd=path, timeout=timeout)
    return path


def branch_tip(mirror: Path, branch: str) -> str:
    """Full hash of ``refs/heads/<branch>`` in the mirror, or ``""`` if the branch is absent."""
    try:
        return _run(["rev-parse", "--verify", "--quiet", f"refs/heads/{branch}"],
                    cwd=mirror).strip()
    except GitError:
        return ""


def list_branches(mirror: Path) -> list[str]:
    """All local head names in the mirror (mirror refs mirror the remote's heads)."""
    out = _run(["for-each-ref", "--format=%(refname:short)", "refs/heads/"], cwd=mirror)
    return [ln.strip() for ln in out.splitlines() if ln.strip()]


def _short(full: str) -> str:
    return full[:12]


def _parse_log(raw: str) -> list[dict]:
    """Parse ``git log`` output produced with ``_FMT`` + ``--name-only`` into commit dicts."""
    commits: list[dict] = []
    for chunk in raw.split(_COMMIT):
        chunk = chunk.strip("\n")
        if not chunk:
            continue
        lines = chunk.split("\n")
        fields = lines[0].split(_US)
        if len(fields) < 7:
            continue
        full, _short_h, parents, an, ae, ai, subject = fields[:7]
        files = [ln.strip() for ln in lines[1:] if ln.strip()]
        parent_shorts = [_short(p) for p in parents.split() if p]
        commits.append({
            # derive the short hash from the full one (a fixed 12 chars) so it matches the
            # parent/tip refs we truncate the same way — git's own %h width varies (7+).
            "full_hash": full, "hash": _short(full),
            "message": subject, "author_name": an, "author_email": ae, "date": ai,
            "parents": parent_shorts, "files_changed": files,
            "issue_keys": sorted(set(_ISSUE_KEY_RE.findall(subject))),
        })
    return commits


def walk_commits(mirror: Path, branch: str, since_full: str = "",
                 timeout: int = 300) -> list[dict]:
    """Commits on ``branch`` (newest first). Incremental when ``since_full`` is a known
    ancestor: only commits after it (``<branch> ^<since>``); otherwise the full branch."""
    ref = f"refs/heads/{branch}"
    args = ["log", ref]
    if since_full and since_full != branch_tip(mirror, branch):
        args.append(f"^{since_full}")
    args += ["--name-only", f"--format={_FMT}"]
    try:
        raw = _run(args, cwd=mirror, timeout=timeout)
    except GitError:
        # e.g. the stored tip was force-pushed away — fall back to the full branch.
        raw = _run(["log", ref, "--name-only", f"--format={_FMT}"],
                   cwd=mirror, timeout=timeout)
    return _parse_log(raw)


def read_file_at(mirror: Path, commit: str, path: str, max_bytes: int = 400_000) -> str:
    """File content at a commit (``git show <commit>:<path>``), capped. ``""`` if absent."""
    try:
        text = _run(["show", f"{commit}:{path}"], cwd=mirror)
    except GitError:
        return ""
    return text[:max_bytes]
