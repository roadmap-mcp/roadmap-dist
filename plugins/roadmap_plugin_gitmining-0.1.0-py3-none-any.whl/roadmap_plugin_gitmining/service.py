"""The ``gitmining`` service — the facade the router (and later the scanner / scheduler /
MCP tools) use.

Two responsibilities kept apart, matching the two data planes:

* **Repo configuration** — CRUD over the server-managed :class:`MiningRepo` list and the
  :class:`MiningCredential` vault, persisted in the ``gitmining`` config slice. Credential
  ``secret`` values are write-only: never returned, and a blank secret on update keeps the
  stored one.
* **Mined data** — read/write access to the active :class:`~.ports.WorkItemStore`, resolved
  fresh from config so a persistence switch in settings takes effect without a restart.

Keeps a stable surface so the scan/ingest internals (phase 2) and the scheduler (phase 3)
can be layered on without changing callers.
"""

from __future__ import annotations

from . import components, engine, runtime
from .models import (
    GitMiningConfig, MiningCredential, MiningRepo, WorkItem, WorkItemRef,
)
from .processors import processor_catalog

_SECRET_KEPT = ""   # a blank secret on save means "keep the existing one"


class GitMiningService:
    # ── persistence providers (self-describing; drives the settings dropdown) ──
    def list_persistence(self) -> list[dict]:
        """The registered persistence backends as ``{id, label, icon, active}``."""
        active = runtime.gitmining_config().persistence
        return [
            {"id": p.id, "label": p.label, "icon": getattr(p, "icon", "bi-database"),
             "active": p.id == active}
            for p in runtime.persistence_providers()
        ]

    def store(self):
        """The active :class:`~.ports.WorkItemStore` (built + ``init()``-ed from config)."""
        return components.build_store()

    # ── processors (self-describing catalog) ───────────────────────────────────
    def list_processors(self) -> list[dict]:
        """Every available commit processor as ``{name, label, description, result_key,
        kind}`` — the built-in/satellite extension processors plus config-defined AI ones."""
        return processor_catalog(runtime.processor_extensions(), runtime.gitmining_config())

    # ── scan + ingest ──────────────────────────────────────────────────────────
    def scan(self, repo_names: list[str] | None = None, ingest: bool = False) -> dict:
        """Fetch mirrors and report which tracked branches moved; optionally start ingests."""
        return engine.check_remotes(self, repo_names, ingest)

    def start_ingest(self, repo_name: str, branches: list[str] | None = None,
                     mode: str = "incremental"):
        """Kick a background ingest for one repo and return the ``roadmap.jobs`` Job to poll."""
        return engine.start_ingest_async(self, repo_name, branches, mode)

    # ── repo configuration ─────────────────────────────────────────────────────
    def config(self) -> GitMiningConfig:
        return runtime.gitmining_config()

    def list_repos(self) -> list[MiningRepo]:
        return runtime.gitmining_config().repos

    def get_repo(self, name: str) -> MiningRepo | None:
        return next((r for r in runtime.gitmining_config().repos if r.name == name), None)

    def save_repo(self, repo: MiningRepo) -> MiningRepo:
        """Add or update a mining repo (matched by ``name``)."""
        cfg = runtime.gitmining_config()
        repos = [r for r in cfg.repos if r.name != repo.name]
        repos.append(repo)
        cfg.repos = sorted(repos, key=lambda r: r.name.lower())
        runtime.save_gitmining_config(cfg)
        return repo

    def delete_repo(self, name: str, drop_data: bool = True) -> bool:
        cfg = runtime.gitmining_config()
        before = len(cfg.repos)
        cfg.repos = [r for r in cfg.repos if r.name != name]
        if len(cfg.repos) == before:
            return False
        runtime.save_gitmining_config(cfg)
        if drop_data:
            try:
                self.store().clear_repo(name)
            except Exception:
                pass
        return True

    # ── credentials (secret is write-only) ─────────────────────────────────────
    def list_credentials(self) -> list[dict]:
        """Credential metadata only — ``{name, username, has_secret}``; secrets never leave."""
        return [
            {"name": c.name, "username": c.username, "has_secret": bool(c.secret)}
            for c in runtime.gitmining_config().credentials
        ]

    def save_credential(self, name: str, username: str, secret: str) -> dict:
        cfg = runtime.gitmining_config()
        existing = next((c for c in cfg.credentials if c.name == name), None)
        kept = existing.secret if (existing and secret == _SECRET_KEPT) else secret
        creds = [c for c in cfg.credentials if c.name != name]
        creds.append(MiningCredential(name=name, username=username, secret=kept))
        cfg.credentials = sorted(creds, key=lambda c: c.name.lower())
        runtime.save_gitmining_config(cfg)
        return {"name": name, "username": username, "has_secret": bool(kept)}

    def delete_credential(self, name: str) -> bool:
        cfg = runtime.gitmining_config()
        before = len(cfg.credentials)
        cfg.credentials = [c for c in cfg.credentials if c.name != name]
        if len(cfg.credentials) == before:
            return False
        runtime.save_gitmining_config(cfg)
        return True

    def set_persistence(self, provider_id: str) -> GitMiningConfig:
        cfg = runtime.gitmining_config()
        cfg.persistence = provider_id
        return runtime.save_gitmining_config(cfg)

    # ── mined-data queries (delegate to the active store) ──────────────────────
    def repo_status(self, name: str) -> dict:
        """Summary for a repo: work-item counts per type and the git cursor (branch tips)."""
        store = self.store()
        cursor = store.load_cursor(name, "git")
        types = store.list_types(name)
        return {
            "repo": name,
            "item_count": store.item_count(name),
            "types": {t: store.item_count(name, t) for t in types},
            "branch_tips": (cursor.cursor.get("branch_tips", {}) if cursor else {}),
            "last_ingested_at": cursor.last_ingested_at if cursor else "",
        }

    def list_items(self, name: str, item_type: str = "", limit: int = 200) -> list[WorkItem]:
        return self.store().list_items(name, item_type, limit)

    def get_item(self, name: str, item_type: str, item_id: str) -> dict | None:
        """A work item plus its outgoing and incoming relations, or ``None``."""
        store = self.store()
        item = store.get_item(name, item_type, item_id)
        if item is None:
            return None
        ref = WorkItemRef(scope=name, type=item_type, id=item_id)
        out = item.model_dump()
        out["relations_out"] = [r.model_dump() for r in store.list_relations(ref)]
        out["relations_in"] = [r.model_dump() for r in store.list_relations(ref, incoming=True)]
        return out

    # ── ingest job history (delegates to the generic roadmap.jobs service) ─────
    def list_jobs(self, repo: str = "", limit: int = 50) -> list[dict]:
        """This repo's ingest runs (or all gitmining ingests when ``repo`` is blank),
        newest first — read from the shared ``roadmap.jobs`` store, filtered by owner."""
        jobs = runtime.jobs_service().list("gitmining", "ingest", limit)
        out = [j.model_dump() for j in jobs]
        return [j for j in out if j.get("data", {}).get("repo") == repo] if repo else out

    def get_job(self, job_id: str) -> dict | None:
        j = runtime.jobs_service().get(job_id)
        return j.model_dump() if j else None
