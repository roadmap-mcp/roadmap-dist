"""Atlassian datasource plugin — Jira/Confluence config + access.

Consumers use the published ``atlassian`` service (``ctx.services.require("atlassian")``)
rather than importing internals.
"""
