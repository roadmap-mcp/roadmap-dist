"""Atlassian settings section + its 'test connection' / lookup endpoints.

Contributes a tab to the settings plugin's ``roadmap.settings.sections`` point
and mounts its routes under ``/api/settings`` (alongside the settings plugin's
own routes — FastAPI serves multiple routers sharing a prefix)."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException

from roadmap_framework import session
from roadmap_plugin_settings import SettingsSection

from . import runtime
from .models import AtlassianConfig
from .atlassian_client import atlassian_request, require_atlassian_configured


def _atlassian_defaults() -> dict:
    return {"atlassian": AtlassianConfig().model_dump()}


ATLASSIAN_SECTION = SettingsSection(
    id="atlassian",
    label="Atlassian",
    order=20,
    group="Information Sources",
    defaults=_atlassian_defaults,
    sensitive_fields=["atlassian.api_token"],
)


def create_atlassian_settings_router() -> APIRouter:
    router = APIRouter(prefix="/api/settings", tags=["settings", "atlassian"])

    def require_unlocked():
        if runtime.has_encrypted_fields() and not session.is_unlocked():
            raise HTTPException(status_code=403,
                                detail="App is locked. Provide password to unlock.")

    @router.post("/test-atlassian")
    def test_atlassian():
        require_unlocked()
        atl = runtime.atlassian_config()
        require_atlassian_configured(atl)
        data = atlassian_request(atl, "/rest/api/2/myself")
        name = data.get("displayName", data.get("name", "Unknown"))
        return {"status": "ok", "message": f"Connected as {name}"}

    @router.get("/atlassian/project")
    def lookup_jira_project(key: str):
        require_unlocked()
        atl = runtime.atlassian_config()
        require_atlassian_configured(atl)
        project = atlassian_request(atl, f"/rest/api/2/project/{key}")
        try:
            board_data = atlassian_request(atl, f"/rest/agile/1.0/board?projectKeyOrId={key}")
            boards = [{"id": b["id"], "name": b["name"]} for b in board_data.get("values", [])]
        except Exception:
            boards = []
        return {"key": project["key"], "name": project["name"], "boards": boards}

    @router.get("/atlassian/confluence-space")
    def lookup_confluence_space(key: str):
        require_unlocked()
        atl = runtime.atlassian_config()
        require_atlassian_configured(atl)
        prefix = "/wiki" if atl.deployment_type == "cloud" else ""
        data = atlassian_request(atl, f"{prefix}/rest/api/space/{key}")
        return {"key": data["key"], "name": data["name"]}

    return router
