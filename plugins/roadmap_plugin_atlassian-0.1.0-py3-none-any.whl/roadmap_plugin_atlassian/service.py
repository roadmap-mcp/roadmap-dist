"""The ``atlassian`` service — the facade consumers (jira context items, the brain
Atlassian source) use to read Jira/Confluence data without importing internals.

Returns normalized data (issues, pages, trees); presentation (markdown) lives with the
consumer. Confluence page bodies are returned both raw (``body_html``) and cleaned
(``body_markdown``) so consumers don't need BeautifulSoup/markdownify themselves.
"""

from __future__ import annotations

import json

from . import runtime
from .confluence_html import _clean_confluence_html
from .confluence_router import (
    fetch_page_descendants, _fetch_single_page, _fetch_pages_flat,
)
from .jira_router import fetch_issue_children_tree, _jql_search


class AtlassianService:
    # ── config ────────────────────────────────────────────────────────────
    def config(self):
        return runtime.atlassian_config()

    def spaces(self):
        return runtime.atlassian_config().confluence_spaces

    def projects(self):
        return runtime.atlassian_config().jira_projects

    # ── Jira ──────────────────────────────────────────────────────────────
    def get_issue(self, issue_key: str) -> dict | None:
        return runtime.issue_service().get_issue(issue_key)

    def issue_children(self, issue_key: str) -> dict:
        return fetch_issue_children_tree(issue_key)

    def project_issue_keys(self, project_key: str, jql: str | None = None,
                           limit: int = 500) -> list[str]:
        """Issue keys for a project (most-recently-updated first), for ingestion."""
        atl = runtime.atlassian_config()
        query = jql or f"project = {project_key} ORDER BY updated DESC"
        keys: list[str] = []
        start = 0
        while len(keys) < limit:
            data = _jql_search(atl, query, "summary", start, 100)
            issues = data.get("issues", [])
            keys.extend(raw["key"] for raw in issues)
            total = data.get("total", 0)
            start += len(issues)
            if not issues or start >= total:
                break
        return keys[:limit]

    # ── Confluence ────────────────────────────────────────────────────────
    def get_page(self, page_id: str) -> dict | None:
        """A single page, cache-first. Adds ``body_markdown`` (cleaned)."""
        cache = runtime.cache()
        atl = runtime.atlassian_config()
        data = None
        for space in atl.confluence_spaces:
            p = cache.confluence_page_path(space.key, page_id)
            if p.exists():
                data = json.loads(p.read_text(encoding="utf-8"))
                break
        if data is None:
            try:
                data = _fetch_single_page(atl, page_id)
            except Exception:
                return None
            cache.write(cache.confluence_page_path(
                data.get("space_key", "unknown"), page_id), data)
        if "body_markdown" not in data:
            data = {**data,
                    "body_markdown": _clean_confluence_html(data.get("body_html", ""))}
        return data

    def page_descendants(self, page_id: str) -> dict:
        return fetch_page_descendants(page_id)

    def space_page_ids(self, space_key: str) -> list[str]:
        """All page ids in a space, for ingestion."""
        atl = runtime.atlassian_config()
        return [p["id"] for p in _fetch_pages_flat(atl, space_key)]
