"""Convert Confluence storage-format HTML to LLM-friendly markdown.

Extracted from the original functional-doc analyzer so the MCP/context
rendering path doesn't pull in the (out-of-scope) analyzer dependencies.
"""

import re

from bs4 import BeautifulSoup


def _clean_confluence_html(body_html: str) -> str:
    """Convert Confluence storage-format XML/HTML to LLM-friendly markdown.

    Confluence-specific macros / namespaced elements (drawio, plantuml,
    status, jira, children, page references, user mentions, …) are
    substituted with compact text placeholders first, then the resulting
    HTML is converted to markdown via ``markdownify`` so that headings,
    lists, tables, code blocks, links and emphasis are preserved (rather
    than flattened by ``soup.get_text``).
    """
    soup = BeautifulSoup(body_html, "html.parser")

    # Remove draw.io / plantuml macros (binary diagram data)
    for macro in soup.find_all("ac:structured-macro"):
        macro_name = macro.get("ac:name", "")
        if macro_name in ("drawio", "plantumlcloud", "plantuml"):
            label = macro.find("ac:parameter", attrs={"ac:name": "diagramName"})
            name = label.string if label and label.string else macro_name
            macro.replace_with(f"[Diagram: {name}]")
        elif macro_name == "status":
            title_param = macro.find("ac:parameter", attrs={"ac:name": "title"})
            if title_param and title_param.string:
                macro.replace_with(title_param.string)
        elif macro_name == "details":
            # Keep the rich-text-body content inside details macros
            body = macro.find("ac:rich-text-body")
            if body:
                macro.replace_with(body)
        elif macro_name in ("children", "include", "detailssummary",
                            "recently-updated", "contributors"):
            macro.replace_with(f"[Macro: {macro_name}]")
        elif macro_name == "jira":
            key_param = macro.find("ac:parameter", attrs={"ac:name": "key"})
            if key_param and key_param.string:
                macro.replace_with(f"[JIRA: {key_param.string}]")

    # Remove placeholders
    for ph in soup.find_all("ac:placeholder"):
        ph.decompose()

    # Convert ac:link page references to text
    for link in soup.find_all("ac:link"):
        body = link.find("ac:link-body")
        if body:
            link.replace_with(body.get_text())
        else:
            page_ref = link.find("ri:page")
            if page_ref:
                link.replace_with(page_ref.get("ri:content-title", ""))
            else:
                link.replace_with("")

    # Remove user references, replace with placeholder
    for user in soup.find_all("ri:user"):
        user.replace_with("[User]")

    # Convert the (macro-stripped) HTML to markdown so structure survives.
    # ATX headings (#) are mandatory for LLM sectioning; consistent bullets
    # keep diffs stable; <span> wrappers add noise so we discard them.
    from markdownify import markdownify as _to_md
    text = _to_md(
        str(soup),
        heading_style="ATX",
        bullets="-",
        strip=["span"],
    )
    # Collapse 3+ blank lines into 2 (markdownify can emit large gaps
    # around nested blocks).
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()
