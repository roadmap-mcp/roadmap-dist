"""Atlassian datasource plugin — owns the Jira/Confluence config, HTTP client, cache,
and browse endpoints, and publishes the ``atlassian`` service that the jira context-item
plugin and the brain Atlassian source consume. Contributes no context item types itself.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime
from .settings_section import ATLASSIAN_SECTION, create_atlassian_settings_router
from .jira_router import router as jira_router
from .confluence_router import router as confluence_router
from .service import AtlassianService


class AtlassianPlugin(Plugin):
    id = "roadmap.atlassian"
    name = "Atlassian (Jira + Confluence datasource)"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services)
        ctx.register_sensitive_path("atlassian.api_token")

        ctx.extend(SETTINGS_SECTIONS_POINT, ATLASSIAN_SECTION)
        ctx.add_router(jira_router)
        ctx.add_router(confluence_router)
        ctx.add_router(create_atlassian_settings_router())

        # the datasource facade — consumed via ctx.services.require("atlassian")
        ctx.services.register("atlassian", AtlassianService())
