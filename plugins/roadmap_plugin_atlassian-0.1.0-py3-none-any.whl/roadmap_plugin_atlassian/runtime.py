"""Per-process runtime wiring for the Jira plugin.

Provides the config helpers the moved routers/services expect
(``load_config_decrypted`` / ``save_config`` / ``has_encrypted_fields``), reading
and writing only the ``atlassian`` slice of the composed config document.
"""

from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace
from typing import Optional

from roadmap_framework import ConfigStore, ServiceRegistry

from .models import AtlassianConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry) -> None:
    global _store, _services
    _store, _services = config, services


def config_dir() -> Path:
    assert _store is not None, "jira runtime not initialised"
    return _store.path.parent


def has_encrypted_fields() -> bool:
    assert _store is not None, "jira runtime not initialised"
    return _store.has_encrypted_fields()


def atlassian_config() -> AtlassianConfig:
    assert _store is not None, "jira runtime not initialised"
    raw = _store.load_decrypted()
    return AtlassianConfig(**(raw.get("atlassian") or {}))


def load_config_decrypted() -> SimpleNamespace:
    """Drop-in for the monolith's helper: an object exposing ``.atlassian``."""
    return SimpleNamespace(atlassian=atlassian_config())


def save_config(cfg: SimpleNamespace) -> None:
    """Persist mutations to the atlassian section (e.g. board_id discovery)."""
    assert _store is not None, "jira runtime not initialised"
    raw = _store.load_decrypted()
    raw["atlassian"] = cfg.atlassian.model_dump()
    _store.save(raw)


def cache():
    from .jira_cache import JiraCache
    atl = atlassian_config()
    return JiraCache(atl.cache_dir, atl.refresh_duration)


def issue_service():
    from .jira_issue_service import JiraIssueService
    return JiraIssueService(atlassian_config(), cache())
