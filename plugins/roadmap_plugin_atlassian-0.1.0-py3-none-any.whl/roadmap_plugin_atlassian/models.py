"""Atlassian config schema — now owned by the Jira plugin (was in the monolith's
``app/models.py``)."""

from typing import Literal, Optional

from pydantic import BaseModel


class JiraProjectConfig(BaseModel):
    key: str = ""
    name: str = ""
    board_id: Optional[int] = None


class ConfluenceSpaceConfig(BaseModel):
    key: str = ""
    name: str = ""


class AtlassianConfig(BaseModel):
    deployment_type: Literal["cloud", "datacenter"] = "cloud"
    base_url: str = ""
    email: str = ""
    api_token: str = ""
    jira_projects: list[JiraProjectConfig] = []
    confluence_spaces: list[ConfluenceSpaceConfig] = []
    cache_dir: str = ""
    refresh_duration: int = 3600
