"""SQL Server executor plugin activator.

Contributes the ``sql`` executor provider to the engine's ``roadmap.workflow.executors``
point. The provider is self-describing (icon + config-field schema), so the ``sql`` step
kind and its form appear in the workflow step editor with no change to the engine. The
provider builds a :class:`~.executor.SqlExecutor` lazily when a run starts, so
importing/activating this plugin never opens a database connection.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_workflow import (
    WORKFLOW_EXECUTORS_POINT, ExecutorField, ExecutorProvider,
)

from .executor import SqlExecutor

SQL_PROVIDER = ExecutorProvider(
    id="sql",
    label="SQL query (SQL Server)",
    icon="bi-database",
    create=lambda env: SqlExecutor(env.config),
    fields=[
        ExecutorField(
            key="url", label="JDBC URL", type="text",
            placeholder="jdbc:sqlserver://host;database=DB;encrypt=false",
            hint="Reused as-is; parsed into server / database / port",
        ),
        ExecutorField(
            key="user", label="User", type="text",
            placeholder="{{vault.mydb.username}}",
            hint="Store the login in the vault and reference it (name must have no dot)",
        ),
        ExecutorField(
            key="password", label="Password", type="text",
            placeholder="{{vault.mydb.password}}",
        ),
        ExecutorField(
            key="query", label="SQL", type="textarea",
            placeholder="SELECT id, name FROM my_table WHERE id = ${id}",
        ),
    ],
)


class WorkflowSqlPlugin(Plugin):
    id = "roadmap.workflow.sql"
    name = "Workflows — SQL Server executor"
    requires = ["roadmap.workflow"]

    def activate(self, ctx: PluginContext) -> None:
        ctx.extend(WORKFLOW_EXECUTORS_POINT, SQL_PROVIDER)
