"""The ``sql`` executor — run one SQL statement against SQL Server via ``pymssql``.

Self-contained: ``pymssql`` bundles its own client, so there is **no ODBC driver and no JVM**
to install. For convenience it accepts a **JDBC URL** (``jdbc:sqlserver://…``) and parses it
into the host / database / port ``pymssql`` needs, so an existing JDBC connection string can
be reused verbatim.

``config`` fields (``${param}`` / ``{{vault…}}`` aware — the engine resolves them before we
see them and redacts any injected secret out of the result afterwards)::

    url        a jdbc:sqlserver:// URL (required), e.g.
               ``jdbc:sqlserver://host;database=DB;encrypt=false``
    user       login (optional if the URL carries ``user=``) — reference the vault, e.g.
               ``{{vault.mydb.username}}``
    password   password (optional if the URL carries ``password=``) — e.g.
               ``{{vault.mydb.password}}``
    query      the SQL to run (required); supports ``${param}`` from the run context

A ``SELECT`` (any statement with a result set) returns ``{columns, rows, rowcount}`` (rows
capped, ``truncated`` flagged); a write / DDL / proc returns ``{rowcount}``. The connection
is autocommit, so writes persist per step. An error (bad SQL, connect/parse failure) is an
ordinary ``failed`` outcome, never a raise.
"""

from __future__ import annotations

import datetime
from decimal import Decimal

from roadmap_plugin_workflow import StepOutcome

_MAX_ROWS = 500
_JDBC_PREFIX = "jdbc:sqlserver://"


def _safe(v):
    """Coerce a column value to something JSON-serializable (the result is persisted as
    JSON). Primitives pass through; dates/decimals/bytes/etc. become strings."""
    if v is None or isinstance(v, (str, int, float, bool)):
        return v
    if isinstance(v, Decimal):
        return float(v)
    if isinstance(v, (datetime.datetime, datetime.date, datetime.time)):
        return v.isoformat()
    if isinstance(v, (bytes, bytearray)):
        return v.hex()
    return str(v)


def parse_jdbc_sqlserver(url: str) -> dict:
    """Parse a ``jdbc:sqlserver://server[\\instance][:port][;prop=value…]`` URL into
    ``pymssql.connect`` kwargs: ``{server, port?, database?, user?, password?}``.

    Server-instance form ``host\\instance`` is preserved (pymssql resolves the instance via
    SQL Browser); a bare ``host:port`` splits into ``server`` + ``port``. Properties are
    case-insensitive; ``database``/``databaseName`` map to ``database`` and ``user``/
    ``password`` are picked up if present (the explicit fields still take precedence).
    Encryption/other properties are ignored — pymssql negotiates its own transport.
    """
    s = url.strip()
    if s.lower().startswith(_JDBC_PREFIX):
        s = s[len(_JDBC_PREFIX):]
    parts = s.split(";")
    server_spec = parts[0].strip()
    props: dict = {}
    for p in parts[1:]:
        if "=" in p:
            k, _, v = p.partition("=")
            props[k.strip().lower()] = v.strip()

    host, instance, port = server_spec, None, None
    if "\\" in host:
        host, instance = host.split("\\", 1)
    if instance and ":" in instance:
        instance, port = instance.split(":", 1)
    elif ":" in host:
        host, port = host.split(":", 1)

    out: dict = {"server": f"{host}\\{instance}" if instance else host}
    if port:
        out["port"] = port
    db = props.get("database") or props.get("databasename")
    if db:
        out["database"] = db
    user = props.get("user") or props.get("username")
    if user:
        out["user"] = user
    if props.get("password"):
        out["password"] = props["password"]
    return out


class SqlExecutor:
    id = "sql"

    def __init__(self, config):
        self._timeout = getattr(config, "default_timeout", 30.0)

    def run_step(self, step: dict, ctx: dict) -> StepOutcome:
        c = step.get("config") or {}
        url = (c.get("url") or "").strip()
        query = (c.get("query") or "").strip()
        if not url:
            return StepOutcome(status="failed",
                               error="sql step needs config.url (a jdbc:sqlserver:// URL)")
        if not query:
            return StepOutcome(status="failed", error="sql step needs config.query")
        try:
            import pymssql
        except ImportError:
            return StepOutcome(status="failed",
                               error="pymssql is not installed on the server. Install it to "
                                     "use the SQL executor.")
        try:
            parsed = parse_jdbc_sqlserver(url)
        except Exception as e:
            return StepOutcome(status="failed", error=f"could not parse JDBC URL: {e}")
        if not parsed.get("server"):
            return StepOutcome(status="failed", error="JDBC URL has no server host")

        user = (c.get("user") or "").strip() or parsed.get("user")
        password = c.get("password") or parsed.get("password")
        timeout = int(step.get("timeout") or self._timeout)
        kwargs = {
            "server": parsed["server"],
            "database": parsed.get("database"),
            "user": user,
            "password": password,
            "port": parsed.get("port"),
            "autocommit": True,
            "login_timeout": timeout,
            "timeout": timeout,
        }
        try:
            cx = pymssql.connect(**{k: v for k, v in kwargs.items() if v is not None})
        except Exception as e:
            return StepOutcome(status="failed", error=f"connect failed: {type(e).__name__}: {e}")
        try:
            cur = cx.cursor(as_dict=True)
            cur.execute(query)
            if cur.description:                      # a result set (SELECT / proc output)
                cols = [d[0] for d in cur.description]
                fetched = cur.fetchmany(_MAX_ROWS + 1)
                truncated = len(fetched) > _MAX_ROWS
                fetched = fetched[:_MAX_ROWS]
                out: dict = {
                    "columns": cols,
                    "rows": [{k: _safe(v) for k, v in row.items()} for row in fetched],
                    "rowcount": len(fetched),
                }
                if truncated:
                    out["truncated"] = True
            else:                                    # a write / DDL / proc with no result set
                out = {"rowcount": cur.rowcount}
            return StepOutcome(status="passed", output=out)
        except Exception as e:
            return StepOutcome(status="failed", error=f"{type(e).__name__}: {e}")
        finally:
            try:
                cx.close()
            except Exception:
                pass

    def close(self) -> None:
        return None
