"""SQL Server executor plugin for the Roadmap workflow engine.

A satellite of ``roadmap.workflow`` (mirrors the e2e Selenium driver): it contributes a
single ``sql`` executor to the ``roadmap.workflow.executors`` point. Activating the plugin
never opens a connection — only running a ``sql`` step does.
"""
