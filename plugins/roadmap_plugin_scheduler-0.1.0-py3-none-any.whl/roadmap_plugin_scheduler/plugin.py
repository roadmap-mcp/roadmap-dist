"""Scheduler plugin activator.

Declares the ``roadmap.scheduler.tasks`` extension point, publishes the ``scheduler`` service,
mounts ``/api/scheduler``, contributes a Scheduler settings tab, and starts the background loop
(stopped on deactivate). Plugins that want periodic work depend on ``roadmap.scheduler`` and
contribute a :class:`ScheduledTask`; the cron/enabled for each lives in this plugin's config.
"""

from roadmap_framework import Plugin, PluginContext
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

from . import runtime, scheduler
from .contracts import SCHEDULER_TASKS_POINT, ScheduledTask
from .router import create_scheduler_router
from .service import SchedulerService
from .settings_section import SCHEDULER_SECTION


class SchedulerPlugin(Plugin):
    id = "roadmap.scheduler"
    name = "Scheduler"
    requires = ["roadmap.settings"]

    def activate(self, ctx: PluginContext) -> None:
        runtime.set_runtime(ctx.config, ctx.services, ctx.extensions)

        ctx.define_point(SCHEDULER_TASKS_POINT, ScheduledTask,
                         "Periodic tasks the scheduler fires on their configured cron.")
        ctx.extend(SETTINGS_SECTIONS_POINT, SCHEDULER_SECTION)

        svc = SchedulerService()
        ctx.services.register("scheduler", svc)
        ctx.add_router(create_scheduler_router(svc))

        scheduler.start()

    def deactivate(self, ctx: PluginContext) -> None:
        scheduler.stop()
