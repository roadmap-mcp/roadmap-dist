"""The background scheduler loop.

A single daemon thread wakes every ``_TICK`` seconds and, for each workspace, evaluates the
central schedule: for every enabled task whose cron is due, it runs the contributed task's
``run`` callable **with ``current_workspace`` pinned to that workspace**. Config is read live
each tick, so enabling/disabling a task or editing its cron takes effect without a restart —
and firing is skipped entirely while the app is locked (tasks generally need decrypted config).

Cron evaluation uses ``croniter``; next-run times are kept in memory per ``(workspace, task)``
and re-armed when the cron expression changes (a restart simply re-arms from ``now``).
"""

from __future__ import annotations

import logging
import threading
from datetime import datetime

from croniter import croniter
from roadmap_framework import current_workspace, session

from . import runtime

log = logging.getLogger("roadmap.scheduler")

_TICK_SECONDS = 30
_thread: threading.Thread | None = None
_stop = threading.Event()
# (workspace, task_id) -> (active_cron, next_run_datetime)
_arm: dict[tuple[str, str], tuple[str, datetime]] = {}


def _tick() -> None:
    if not session.is_unlocked():
        return
    now = datetime.now()
    tasks_by_id = {t.id: t for t in runtime.tasks()}
    if not tasks_by_id:
        return

    for ws in runtime.workspace_names():
        token = current_workspace.set(ws)
        try:
            cfg = runtime.scheduler_config()
            for entry in cfg.tasks:
                if not entry.enabled or entry.id not in tasks_by_id:
                    continue
                if not croniter.is_valid(entry.cron):
                    continue
                key = (ws, entry.id)
                armed = _arm.get(key)
                # (re)arm when first seen or when the cron changed
                if armed is None or armed[0] != entry.cron:
                    _arm[key] = (entry.cron, croniter(entry.cron, now).get_next(datetime))
                    continue
                if now >= armed[1]:
                    _run_task(tasks_by_id[entry.id], ws)
                    _arm[key] = (entry.cron,
                                 croniter(entry.cron, datetime.now()).get_next(datetime))
        except Exception:
            log.exception("scheduler tick failed for workspace %s", ws)
        finally:
            current_workspace.reset(token)


def _run_task(task, ws: str) -> None:
    log.info("scheduler firing task %s (workspace=%s)", task.id, ws)
    try:
        task.run()
    except Exception:
        log.exception("scheduled task %s failed", task.id)


def run_now(task_id: str) -> bool:
    """Fire a task immediately in the current workspace (the "Run now" button). Returns
    False if no such task is contributed."""
    task = next((t for t in runtime.tasks() if t.id == task_id), None)
    if task is None:
        return False
    _run_task(task, current_workspace.get())
    return True


def _loop() -> None:
    log.info("scheduler loop started (tick=%ss)", _TICK_SECONDS)
    while not _stop.wait(_TICK_SECONDS):
        try:
            _tick()
        except Exception:
            log.exception("scheduler loop error")


def start() -> None:
    global _thread
    if _thread is not None and _thread.is_alive():
        return
    _stop.clear()
    _thread = threading.Thread(target=_loop, name="scheduler", daemon=True)
    _thread.start()


def stop() -> None:
    _stop.set()
