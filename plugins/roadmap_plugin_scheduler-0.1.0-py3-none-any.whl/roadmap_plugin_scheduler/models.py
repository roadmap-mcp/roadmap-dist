"""Scheduler config models (the central schedule — ``scheduler`` config slice)."""

from __future__ import annotations

from pydantic import BaseModel, Field


class TaskSchedule(BaseModel):
    """One task's cadence, keyed to a contributed :class:`~.contracts.ScheduledTask` by ``id``.
    ``cron`` is a 5-field expression (``m h dom mon dow``)."""

    id: str
    cron: str = "0 * * * *"
    enabled: bool = False


class SchedulerConfig(BaseModel):
    """The ``scheduler`` config slice: the central list of every task's schedule. Tasks that a
    plugin contributes but the config hasn't seen yet are seeded from the task's defaults the
    first time they're listed/saved."""

    tasks: list[TaskSchedule] = Field(default_factory=list)
