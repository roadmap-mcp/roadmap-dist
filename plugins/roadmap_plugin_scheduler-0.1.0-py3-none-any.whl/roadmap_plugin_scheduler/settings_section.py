"""The Scheduler settings section (the ``scheduler`` config slice — the central schedule)."""

from roadmap_plugin_settings import SettingsSection

from .models import SchedulerConfig

SCHEDULER_SECTION = SettingsSection(
    id="scheduler",
    label="Scheduler",
    order=61,
    group="System",
    defaults=lambda: {"scheduler": SchedulerConfig().model_dump()},
)
