"""HTTP surface: ``/api/scheduler`` — list tasks + their schedule, edit a schedule, run now."""

from __future__ import annotations

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel


class ScheduleUpdate(BaseModel):
    cron: str = "0 * * * *"
    enabled: bool = False


def create_scheduler_router(scheduler_svc) -> APIRouter:
    router = APIRouter(prefix="/api/scheduler", tags=["scheduler"])

    @router.get("/tasks")
    def list_tasks():
        return {"tasks": scheduler_svc.list_tasks()}

    @router.put("/tasks/{task_id}")
    def update_task(task_id: str, req: ScheduleUpdate):
        return scheduler_svc.update_task(task_id, req.cron, req.enabled)

    @router.post("/tasks/{task_id}/run")
    def run_task(task_id: str):
        if not scheduler_svc.run_now(task_id):
            raise HTTPException(status_code=404, detail="Task not found.")
        return {"ran": task_id}

    return router
