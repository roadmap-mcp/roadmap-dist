"""The ``scheduler`` service — list tasks with their schedule, edit a schedule, run now.

Merges the two halves of the model: the **contributed tasks** (id/label/description, from the
extension point) and the **central schedule** (cron/enabled, from config). A task the config
hasn't seen is reported with its declared defaults; saving a schedule persists it.
"""

from __future__ import annotations

from . import runtime, scheduler
from .models import TaskSchedule


class SchedulerService:
    def list_tasks(self) -> list[dict]:
        """Every contributed task with its effective schedule ``{id, label, description,
        cron, enabled, available}`` — ``available`` is True when the task is currently
        contributed (a config entry can outlive an uninstalled plugin)."""
        cfg = runtime.scheduler_config()
        sched_by_id = {s.id: s for s in cfg.tasks}
        out = []
        seen = set()
        for t in runtime.tasks():
            seen.add(t.id)
            s = sched_by_id.get(t.id)
            out.append({
                "id": t.id, "label": t.label, "description": t.description,
                "cron": s.cron if s else t.default_cron,
                "enabled": s.enabled if s else t.default_enabled,
                "available": True,
            })
        # config entries whose task is no longer contributed (still editable/removable)
        for s in cfg.tasks:
            if s.id not in seen:
                out.append({"id": s.id, "label": s.id, "description": "",
                            "cron": s.cron, "enabled": s.enabled, "available": False})
        return sorted(out, key=lambda e: e["id"])

    def update_task(self, task_id: str, cron: str, enabled: bool) -> dict:
        cfg = runtime.scheduler_config()
        entries = [s for s in cfg.tasks if s.id != task_id]
        entries.append(TaskSchedule(id=task_id, cron=cron, enabled=enabled))
        cfg.tasks = entries
        runtime.save_scheduler_config(cfg)
        return {"id": task_id, "cron": cron, "enabled": enabled}

    def run_now(self, task_id: str) -> bool:
        return scheduler.run_now(task_id)
