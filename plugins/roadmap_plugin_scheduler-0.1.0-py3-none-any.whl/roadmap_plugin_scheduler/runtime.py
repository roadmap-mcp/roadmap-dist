"""Per-process runtime wiring for the scheduler plugin."""

from __future__ import annotations

from typing import Optional

from roadmap_framework import ConfigStore, ExtensionRegistry, ServiceRegistry

from .contracts import SCHEDULER_TASKS_POINT
from .models import SchedulerConfig

_store: Optional[ConfigStore] = None
_services: Optional[ServiceRegistry] = None
_extensions: Optional[ExtensionRegistry] = None


def set_runtime(config: ConfigStore, services: ServiceRegistry,
                extensions: ExtensionRegistry) -> None:
    global _store, _services, _extensions
    _store, _services, _extensions = config, services, extensions


def scheduler_config() -> SchedulerConfig:
    assert _store is not None, "scheduler runtime not initialised"
    raw = _store.load_decrypted()
    return SchedulerConfig(**(raw.get("scheduler") or {}))


def save_scheduler_config(cfg: SchedulerConfig) -> SchedulerConfig:
    assert _store is not None, "scheduler runtime not initialised"
    raw = _store.load_decrypted()
    raw["scheduler"] = cfg.model_dump()
    _store.save(raw)
    return cfg


def tasks() -> list:
    """The contributed :class:`~.contracts.ScheduledTask`s (live from the extension point)."""
    if _extensions is None:
        return []
    return list(_extensions.get(SCHEDULER_TASKS_POINT))


def workspace_names() -> list[str]:
    """Every workspace to run tasks for. Falls back to the default workspace when the
    workspaces service isn't present (single-tenant editions)."""
    from roadmap_framework import DEFAULT_WORKSPACE
    if _services is not None:
        reg = _services.get("workspaces")
        if reg is not None:
            try:
                return list(reg.names())
            except Exception:
                pass
    return [DEFAULT_WORKSPACE]
