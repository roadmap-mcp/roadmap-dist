"""The scheduler's one extension point: contributed periodic tasks.

A plugin contributes a :class:`ScheduledTask` — an ``id`` + a ``run`` callable — to
``roadmap.scheduler.tasks``. It does NOT carry a schedule: per the central-config model, the
cron expression and enabled flag live in the scheduler's own config (one place lists every
task's cadence), keyed to the task ``id``. The scheduler invokes ``run`` per workspace with
``current_workspace`` pinned, so a task reads/writes that workspace's data correctly.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

SCHEDULER_TASKS_POINT = "roadmap.scheduler.tasks"


@dataclass
class ScheduledTask:
    """A periodic task a plugin offers to the scheduler.

    ``run()`` is called with no arguments, already inside the target workspace's context, and
    should perform one unit of work (it may kick a background job of its own). It must not
    raise for ordinary failures — the scheduler catches exceptions so one bad task never
    stops the loop, but a task should still handle its own errors. ``default_cron`` seeds the
    config the first time the task is seen (the user can change it); ``default_enabled`` is
    almost always False so nothing runs automatically until switched on.
    """

    id: str                               # stable, dotted, e.g. "gitmining.scan"
    label: str
    run: Callable[[], None]
    description: str = ""
    default_cron: str = "0 * * * *"       # hourly
    default_enabled: bool = False
