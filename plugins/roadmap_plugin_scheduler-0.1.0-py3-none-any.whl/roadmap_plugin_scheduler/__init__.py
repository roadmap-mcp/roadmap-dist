"""Roadmap generic scheduler.

A reusable periodic-task facility: a plugin contributes a :class:`ScheduledTask` (an id + a
``run`` callable) to ``roadmap.scheduler.tasks``; a central config sets each task's cron +
enabled; one workspace-aware background loop fires due tasks with ``current_workspace`` pinned.
Stops plugins (Brain, git mining, …) each reinventing their own scheduler.

Re-exported so consumer plugins can ``from roadmap_plugin_scheduler import
SCHEDULER_TASKS_POINT, ScheduledTask``.
"""

from .contracts import SCHEDULER_TASKS_POINT, ScheduledTask

__all__ = ["SCHEDULER_TASKS_POINT", "ScheduledTask"]
