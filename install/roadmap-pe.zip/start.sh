#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
command -v python3 >/dev/null || { echo "Python 3.13+ is required on PATH."; exit 1; }
[ -d .venv ] || python3 -m venv .venv
# Install only on first run. Delete .venv/.installed to force a re-setup. This
# lets you add/remove plugins (e.g. from the in-app registry) without a restart
# undoing them.
if [ ! -f .venv/.installed ]; then
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  .venv/bin/python -m pip install --find-links wheels roadmap-framework roadmap-plugin-ai roadmap-plugin-context roadmap-plugin-fileviewer roadmap-plugin-jira roadmap-plugin-settings roadmap-plugin-whisper
  .venv/bin/python -m pip install -r backend/requirements.txt
  touch .venv/.installed
fi
echo "Starting on http://localhost:8090  (press Ctrl+C to stop)"
cd backend
../.venv/bin/python -m uvicorn app.main:app --port 8090
