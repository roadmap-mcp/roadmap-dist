# Roadmap — Personal Edition

Self-contained build. Requires **Python 3.13+** on your PATH.

## Run

- **Windows:** double-click `start.bat` (or run it from a terminal).
- **macOS / Linux:** `bash start.sh`

The first run creates a local `.venv`, installs the bundled plugin wheels
(`wheels/`) plus their dependencies from PyPI, then serves the app at
<http://localhost:8090>. Subsequent runs reuse `.venv` and start immediately.

## Notes

- Contexts and `config.yaml` are created next to `ROADMAP_CONFIG_PATH`; if unset
  they default under `backend/`. Set `ROADMAP_KEY` to auto-unlock encrypted secrets.
- Settings → **Admin** lists the installed plugins and their extension points.
- Version: 0.1.0
