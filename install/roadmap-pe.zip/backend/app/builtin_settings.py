"""Personal Edition built-in settings sections.

Only the few config groups not yet owned by a plugin remain here (scratch dir +
git repositories). AI providers/proxy/tasks, Whisper, File Viewers, and Atlassian
are contributed by their respective plugins.
"""

from roadmap_plugin_settings import SettingsSection

BUILTIN_SECTIONS = [
    SettingsSection(id="context", label="Context", order=10,
                    defaults=lambda: {"scratch_base_dir": ""}),
    SettingsSection(id="repos", label="Git Repos", order=30,
                    defaults=lambda: {"repositories": []}),
]

#: The edition's built-in sections own no sensitive fields (plugins register theirs).
BUILTIN_SENSITIVE_PATHS: list[str] = []
