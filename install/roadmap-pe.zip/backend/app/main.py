"""Personal Edition entry point.

Thin: build the app via the framework factory (which discovers + activates the
installed plugins — settings, context, jira), register the edition's built-in
contributions for features not yet extracted into plugins, mount the built-in
routers, then serve the SPA.
"""

import os
from pathlib import Path

from roadmap_framework import create_app, mount_frontend
from roadmap_plugin_settings import SETTINGS_SECTIONS_POINT

import app.config as cfg
from app.builtin_settings import BUILTIN_SECTIONS, BUILTIN_SENSITIVE_PATHS
from app.routers import context_assistant, personal_settings

_BACKEND_DIR = Path(__file__).resolve().parent.parent       # roadmap-personal/backend
# Honour ROADMAP_CONFIG_PATH (config + contexts live next to it); else default.
_CONFIG_PATH = Path(os.environ.get("ROADMAP_CONFIG_PATH") or (_BACKEND_DIR / "config.yaml"))
_STATIC_DIR = Path(__file__).resolve().parent / "static"

app = create_app(
    "personal",
    config_path=_CONFIG_PATH,
    static_dir=_STATIC_DIR,
    title="Roadmap Personal Edition",
)

# The personal config shim reads/writes through the framework store.
cfg.set_store(app.state.config_store)

# Built-in (not-yet-extracted) settings tabs + their sensitive fields.
for _section in BUILTIN_SECTIONS:
    app.state.extensions.add(SETTINGS_SECTIONS_POINT, _section)
for _path in BUILTIN_SENSITIVE_PATHS:
    app.state.config_store.register_sensitive_path(_path)

# Built-in routers (AI context-assistant, AI-task-prompts + folder pickers).
app.include_router(context_assistant.router)
app.include_router(personal_settings.router)

# SPA catch-all — must be registered last.
mount_frontend(app)
