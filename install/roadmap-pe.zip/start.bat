@echo off
setlocal
cd /d "%~dp0"
where python >nul 2>nul || (echo Python 3.13+ is required on PATH. && exit /b 1)
if not exist .venv (
  echo Creating virtual environment...
  python -m venv .venv || goto :err
)
REM Install only on first run (or after a failed install). Delete
REM .venv\.installed to force a re-setup. This lets you add/remove plugins
REM (e.g. from the in-app registry) without a restart undoing them.
if not exist .venv\.installed (
  echo Installing Roadmap Personal Edition ^(first run^)...
  .venv\Scripts\python -m pip install --upgrade pip >nul
  .venv\Scripts\python -m pip install --find-links wheels roadmap-framework roadmap-plugin-ai roadmap-plugin-context roadmap-plugin-fileviewer roadmap-plugin-jira roadmap-plugin-settings roadmap-plugin-whisper || goto :err
  .venv\Scripts\python -m pip install -r backend\requirements.txt || goto :err
  echo installed> .venv\.installed
)
echo.
echo Starting on http://localhost:8090  (press Ctrl+C to stop)
cd backend
..\.venv\Scripts\python -m uvicorn app.main:app --port 8090
goto :eof
:err
echo Install failed.
exit /b 1
