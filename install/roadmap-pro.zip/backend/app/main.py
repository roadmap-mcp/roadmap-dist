"""Roadmap entry point — a thin composition root.

Build the app via the framework factory (which discovers + activates every
installed plugin) and serve the SPA. The app carries no feature code of its
own: everything is a plugin.
"""

import os
from pathlib import Path

from roadmap_framework import create_app, mount_frontend

_BACKEND_DIR = Path(__file__).resolve().parent.parent       # roadmap/backend
# Honour ROADMAP_CONFIG_PATH (config + contexts live next to it); else default.
_CONFIG_PATH = Path(os.environ.get("ROADMAP_CONFIG_PATH") or (_BACKEND_DIR / "config.yaml"))
_STATIC_DIR = Path(__file__).resolve().parent / "static"

app = create_app(
    "roadmap",
    config_path=_CONFIG_PATH,
    static_dir=_STATIC_DIR,
    title="Roadmap",
)

# SPA catch-all — must be registered last.
mount_frontend(app)
