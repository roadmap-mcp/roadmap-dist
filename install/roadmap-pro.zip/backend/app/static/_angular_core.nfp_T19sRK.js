import { a as AT } from "@nf-internal/chunk-D5L6RGMC";
import { $ as Mo, $a as bo, $b as M, $c as IT, A as vn, Aa as q, Ab as de, Ac as te, B as ei, Ba as le, Bb as ic, Bc as Ze, C as Wa, Ca as ue, Cb as ui, Cc as Ce, D as vt, Da as ae, Db as mp, Dc as Mc, E as Ft, Ea as Vt, Eb as ko, Ec as Nc, F as En, Fa as H, Fb as di, Fc as wc, G as ti, Ga as k, Gb as fi, Gc as Ei, H as W, Ha as $e, Hb as pi, Hc as Lo, I as Ne, Ia as T, Ib as sc, Ic as Ve, J as Ue, Ja as Dt, Jb as zt, Jc as yT, K as Co, Ka as wo, Kb as yp, Kc as Sp, L as N, La as _o, Lb as vp, Lc as Te, M as we, Ma as J, Mb as Ep, Mc as Gt, N as op, Na as Ct, Nb as Ip, Nc as Po, O as qa, Oa as Dn, Ob as Dp, Oc as bp, P as Ht, Pa as ze, Pb as ac, Pc as Ap, Q as rp, Qa as Se, Qb as hi, Qc as Wt, R as Pe, Ra as Xa, Rb as Oo, Rc as vT, S as ni, Sa as ec, Sb as cc, Sc as Rp, T as I, Ta as li, Tb as lc, Tc as kp, U as Qa, Ua as So, Ub as Cp, Uc as _c, V as In, Va as be, Vb as uc, Vc as U, W as oi, Wa as jt, Wb as dc, Wc as Sc, X as ip, Xa as Ge, Xb as g, Xc as bc, Y as Fe, Ya as E, Yb as w, Yc as qt, Z as Ya, Za as De, Zb as fc, Zc as Ac, _ as To, _a as He, _b as pc, _c as ET, a as sT, aa as Za, ab as Bt, ac as Tp, ad as Rc, b as aT, ba as sp, bb as V, bc as Tn, bd as Op, c as Ua, ca as No, cb as re, cc as qe, cd as DT, d as Yr, da as ri, db as ee, dc as hc, dd as Ii, e as _, ea as ii, eb as tc, ec as gc, ed as Nt, f as ep, fa as _e, fb as me, fc as mc, fd as Mn, g as Ie, ga as F, gb as Cn, gc as yc, gd as CT, h as $a, ha as Et, hb as Ae, hc as vc, hd as Di, i as tp, ia as pT, ib as We, ic as fe, id as kc, j as Zr, ja as nt, jb as nc, jc as Qe, jd as Oc, k as Kr, ka as hT, kb as dp, kc as Ec, kd as TT, l as cT, la as gT, lb as Tt, lc as he, ld as xc, m as za, ma as Ka, mb as oc, mc as Ye, md as MT, n as G, na as si, nb as rc, nc as Mp, nd as NT, o as Jr, oa as ap, ob as O, oc as Ic, od as Qt, p as np, pa as cp, pb as Ao, pc as Np, pd as wT, q as B, qa as ai, qb as Ut, qc as wp, qd as _T, r as Do, ra as It, rb as ie, rc as Dc, rd as ST, s as lT, sa as Ja, sb as fp, sc as gi, sd as bT, t as uT, ta as lp, tb as $t, tc as mi, td as xp, u as Xr, ua as ci, ub as Mt, uc as xo, v as Ga, va as up, vb as Ro, vc as Cc, w as S, wa as mT, wb as pe, wc as yi, x as dT, xa as j, xb as pp, xc as Tc, y as fT, ya as m, yb as hp, yc as vi, z as yt, za as A, zb as gp, zc as _p } from "@nf-internal/chunk-MYW6CHVT";
import { b as iT } from "@nf-internal/chunk-5LZTP3EB";
import { B as ja, E as Ba, a as tt, b as L, c as Kf, f as Va, g as Wr, n as Eo, p as qr, r as Qr, s as Io, w as Jf, x as Xf } from "@nf-internal/chunk-6EHDLDRY";
import { a as K, b as et, d as mt } from "@nf-internal/chunk-4CLCTAJ7";
import { setActiveConsumer as _n } from "@angular/core/primitives/signals";
import { Subject as Kh, Subscription as RT } from "rxjs";
import { map as kT } from "rxjs/operators";
var Nn = { JSACTION: "jsaction" };
function Je(e) { return { toString: e }.toString(); }
var Sn = "__annotations__", bn = "__parameters__", An = "__prop__metadata__";
function vr(e, t, n, o, r) { return Je(() => { let i = cu(t); function s(...a) { if (this instanceof s)
    return i.call(this, ...a), this; let c = new s(...a); return function (u) { return r && r(u, ...a), (u.hasOwnProperty(Sn) ? u[Sn] : Object.defineProperty(u, Sn, { value: [] })[Sn]).push(c), u; }; } return n && (s.prototype = Object.create(n.prototype)), s.prototype.ngMetadataName = e, s.annotationCls = s, s; }); }
function cu(e) { return function (...n) { if (e) {
    let o = e(...n);
    for (let r in o)
        this[r] = o[r];
} }; }
function Kn(e, t, n) { return Je(() => { let o = cu(t); function r(...i) { if (this instanceof r)
    return o.apply(this, i), this; let s = new r(...i); return a.annotation = s, a; function a(c, l, u) { let d = c.hasOwnProperty(bn) ? c[bn] : Object.defineProperty(c, bn, { value: [] })[bn]; for (; d.length <= u;)
    d.push(null); return (d[u] = d[u] || []).push(s), c; } } return r.prototype.ngMetadataName = e, r.annotationCls = r, r; }); }
function ct(e, t, n, o) { return Je(() => { let r = cu(t); function i(...s) { if (this instanceof i)
    return r.apply(this, s), this; let a = new i(...s); function c(l, u) { if (l === void 0)
    throw new Error("Standard Angular field decorators are not supported in JIT mode."); let d = l.constructor, f = d.hasOwnProperty(An) ? d[An] : Object.defineProperty(d, An, { value: {} })[An]; f[u] = f.hasOwnProperty(u) && f[u] || [], f[u].unshift(a); } return c; } return n && (i.prototype = Object.create(n.prototype)), i.prototype.ngMetadataName = e, i.annotationCls = i, i; }); }
var Jh = In(Kn("Inject", e => ({ token: e })), -1), Xh = In(Kn("Optional"), 8), eg = In(Kn("Self"), 2), tg = In(Kn("SkipSelf"), 4), ng = In(Kn("Host"), 1);
function oe(e) { let t = Ie.ng; if (t && t.\u0275compilerFacade)
    return t.\u0275compilerFacade; throw new Error("JIT compiler unavailable"); }
var Lp = { \u0275\u0275defineInjectable: B, \u0275\u0275defineInjector: Do, \u0275\u0275inject: Pe, \u0275\u0275invalidFactoryDep: ni, resolveForwardRef: G }, og = Function;
function Vo(e) { return typeof e == "function"; }
var OT = /^function\s+\S+\(\)\s*{[\s\S]+\.apply\(this,\s*(arguments|(?:[^()]+\(\[\],)?[^()]+\(arguments\).*)\)/, xT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{/, LT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(/, PT = /^class\s+[A-Za-z\d$_]*\s*extends\s+[^{]+{[\s\S]*constructor\s*\(\)\s*{[^}]*super\(\.\.\.arguments\)/;
function FT(e) { return OT.test(e) || PT.test(e) || xT.test(e) && !LT.test(e); }
var zi = class {
    _reflect;
    constructor(t) { this._reflect = t || Ie.Reflect; }
    factory(t) { return (...n) => new t(...n); }
    _zipTypesAndAnnotations(t, n) { let o; typeof t > "u" ? o = Mo(n.length) : o = Mo(t.length); for (let r = 0; r < o.length; r++)
        typeof t > "u" ? o[r] = [] : t[r] && t[r] != Object ? o[r] = [t[r]] : o[r] = [], n && n[r] != null && (o[r] = o[r].concat(n[r])); return o; }
    _ownParameters(t, n) { let o = t.toString(); if (FT(o))
        return null; if (t.parameters && t.parameters !== n.parameters)
        return t.parameters; let r = t.ctorParameters; if (r && r !== n.ctorParameters) {
        let a = typeof r == "function" ? r() : r, c = a.map(u => u && u.type), l = a.map(u => u && Lc(u.decorators));
        return this._zipTypesAndAnnotations(c, l);
    } let i = t.hasOwnProperty(bn) && t[bn], s = this._reflect && this._reflect.getOwnMetadata && this._reflect.getOwnMetadata("design:paramtypes", t); return s || i ? this._zipTypesAndAnnotations(s, i) : Mo(t.length); }
    parameters(t) { if (!Vo(t))
        return []; let n = Ci(t), o = this._ownParameters(t, n); return !o && n !== Object && (o = this.parameters(n)), o || []; }
    _ownAnnotations(t, n) { if (t.annotations && t.annotations !== n.annotations) {
        let o = t.annotations;
        return typeof o == "function" && o.annotations && (o = o.annotations), o;
    } return t.decorators && t.decorators !== n.decorators ? Lc(t.decorators) : t.hasOwnProperty(Sn) ? t[Sn] : null; }
    annotations(t) { if (!Vo(t))
        return []; let n = Ci(t), o = this._ownAnnotations(t, n) || []; return (n !== Object ? this.annotations(n) : []).concat(o); }
    _ownPropMetadata(t, n) { if (t.propMetadata && t.propMetadata !== n.propMetadata) {
        let o = t.propMetadata;
        return typeof o == "function" && o.propMetadata && (o = o.propMetadata), o;
    } if (t.propDecorators && t.propDecorators !== n.propDecorators) {
        let o = t.propDecorators, r = {};
        return Object.keys(o).forEach(i => { r[i] = Lc(o[i]); }), r;
    } return t.hasOwnProperty(An) ? t[An] : null; }
    propMetadata(t) { if (!Vo(t))
        return {}; let n = Ci(t), o = {}; if (n !== Object) {
        let i = this.propMetadata(n);
        Object.keys(i).forEach(s => { o[s] = i[s]; });
    } let r = this._ownPropMetadata(t, n); return r && Object.keys(r).forEach(i => { let s = []; o.hasOwnProperty(i) && s.push(...o[i]), s.push(...r[i]), o[i] = s; }), o; }
    ownPropMetadata(t) { return Vo(t) ? this._ownPropMetadata(t, Ci(t)) || {} : {}; }
    hasLifecycleHook(t, n) { return t instanceof og && n in t.prototype; }
};
function Lc(e) { return e ? e.map(t => { let o = t.type.annotationCls, r = t.args ? t.args : []; return new o(...r); }) : []; }
function Ci(e) { let t = e.prototype ? Object.getPrototypeOf(e.prototype) : null; return (t ? t.constructor : null) || Object; }
function rg(e, t, n, o) { t !== null ? t.applyValueToInputSignal(t, o) : e[n] = o; }
var Gi = class {
    previousValue;
    currentValue;
    firstChange;
    constructor(t, n, o) { this.previousValue = t, this.currentValue = n, this.firstChange = o; }
    isFirstChange() { return this.firstChange; }
}, ig = (() => { let e = () => sg; return e.ngInherit = !0, e; })();
function sg(e) { return e.type.prototype.ngOnChanges && (e.setInput = VT), HT; }
function HT() { let e = cg(this), t = e?.current; if (t) {
    let n = e.previous;
    if (n === _e)
        e.previous = t;
    else
        for (let o in t)
            n[o] = t[o];
    e.current = null, this.ngOnChanges(t);
} }
function VT(e, t, n, o, r) { let i = this.declaredInputs[o], s = cg(e) || jT(e, { previous: _e, current: null }), a = s.current || (s.current = {}), c = s.previous, l = c[i]; a[i] = new Gi(l && l.currentValue, n, c === _e), rg(e, t, r, n); }
var ag = "__ngSimpleChanges__";
function cg(e) { return e[ag] || null; }
function jT(e, t) { return e[ag] = t; }
var Pp = [];
var x = function (e, t = null, n) { for (let o = 0; o < Pp.length; o++) {
    let r = Pp[o];
    r(e, t, n);
} }, R = (function (e) { return e[e.TemplateCreateStart = 0] = "TemplateCreateStart", e[e.TemplateCreateEnd = 1] = "TemplateCreateEnd", e[e.TemplateUpdateStart = 2] = "TemplateUpdateStart", e[e.TemplateUpdateEnd = 3] = "TemplateUpdateEnd", e[e.LifecycleHookStart = 4] = "LifecycleHookStart", e[e.LifecycleHookEnd = 5] = "LifecycleHookEnd", e[e.OutputStart = 6] = "OutputStart", e[e.OutputEnd = 7] = "OutputEnd", e[e.BootstrapApplicationStart = 8] = "BootstrapApplicationStart", e[e.BootstrapApplicationEnd = 9] = "BootstrapApplicationEnd", e[e.BootstrapComponentStart = 10] = "BootstrapComponentStart", e[e.BootstrapComponentEnd = 11] = "BootstrapComponentEnd", e[e.ChangeDetectionStart = 12] = "ChangeDetectionStart", e[e.ChangeDetectionEnd = 13] = "ChangeDetectionEnd", e[e.ChangeDetectionSyncStart = 14] = "ChangeDetectionSyncStart", e[e.ChangeDetectionSyncEnd = 15] = "ChangeDetectionSyncEnd", e[e.AfterRenderHooksStart = 16] = "AfterRenderHooksStart", e[e.AfterRenderHooksEnd = 17] = "AfterRenderHooksEnd", e[e.ComponentStart = 18] = "ComponentStart", e[e.ComponentEnd = 19] = "ComponentEnd", e[e.DeferBlockStateStart = 20] = "DeferBlockStateStart", e[e.DeferBlockStateEnd = 21] = "DeferBlockStateEnd", e[e.DynamicComponentStart = 22] = "DynamicComponentStart", e[e.DynamicComponentEnd = 23] = "DynamicComponentEnd", e[e.HostBindingsUpdateStart = 24] = "HostBindingsUpdateStart", e[e.HostBindingsUpdateEnd = 25] = "HostBindingsUpdateEnd", e; })(R || {});
function BT(e, t, n) { let { ngOnChanges: o, ngOnInit: r, ngDoCheck: i } = t.type.prototype; if (o) {
    let s = sg(t);
    (n.preOrderHooks ??= []).push(e, s), (n.preOrderCheckHooks ??= []).push(e, s);
} r && (n.preOrderHooks ??= []).push(0 - e, r), i && ((n.preOrderHooks ??= []).push(e, i), (n.preOrderCheckHooks ??= []).push(e, i)); }
function lg(e, t) { for (let n = t.directiveStart, o = t.directiveEnd; n < o; n++) {
    let i = e.data[n].type.prototype, { ngAfterContentInit: s, ngAfterContentChecked: a, ngAfterViewInit: c, ngAfterViewChecked: l, ngOnDestroy: u } = i;
    s && (e.contentHooks ??= []).push(-n, s), a && ((e.contentHooks ??= []).push(n, a), (e.contentCheckHooks ??= []).push(n, a)), c && (e.viewHooks ??= []).push(-n, c), l && ((e.viewHooks ??= []).push(n, l), (e.viewCheckHooks ??= []).push(n, l)), u != null && (e.destroyHooks ??= []).push(n, u);
} }
function Oi(e, t, n) { ug(e, t, 3, n); }
function xi(e, t, n, o) { (e[A] & 3) === n && ug(e, t, n, o); }
function Pc(e, t) { let n = e[A]; (n & 3) === t && (n &= 16383, n += 1, e[A] = n); }
function ug(e, t, n, o) { let r = o !== void 0 ? e[Dn] & 65535 : 0, i = o ?? -1, s = t.length - 1, a = 0; for (let c = r; c < s; c++)
    if (typeof t[c + 1] == "number") {
        if (a = t[c], o != null && a >= o)
            break;
    }
    else
        t[c] < 0 && (e[Dn] += 65536), (a < i || i == -1) && (UT(e, n, t, c), e[Dn] = (e[Dn] & 4294901760) + c + 2), c++; }
function Fp(e, t) { x(R.LifecycleHookStart, e, t); let n = L(null); try {
    t.call(e);
}
finally {
    L(n), x(R.LifecycleHookEnd, e, t);
} }
function UT(e, t, n, o) { let r = n[o] < 0, i = n[o + 1], s = r ? -n[o] : n[o], a = e[s]; r ? e[A] >> 14 < e[Dn] >> 16 && (e[A] & 3) === t && (e[A] += 16384, Fp(a, i)) : Fp(a, i); }
var xn = -1, tn = class {
    factory;
    name;
    injectImpl;
    resolving = !1;
    canSeeViewProviders;
    multi;
    componentProviders;
    index;
    providerFactory;
    constructor(t, n, o, r) { this.factory = t, this.name = r, this.canSeeViewProviders = n, this.injectImpl = o; }
};
function Es(e) { return e != null && typeof e == "object" && (e.insertBeforeIndex === null || typeof e.insertBeforeIndex == "number" || Array.isArray(e.insertBeforeIndex)); }
function dg(e) { return !!(e.type & 128); }
function $T(e) { return (e.flags & 8) !== 0; }
function zT(e) { return (e.flags & 16) !== 0; }
function GT(e, t, n) { let o = 0; for (; o < n.length;) {
    let r = n[o];
    if (typeof r == "number") {
        if (r !== 0)
            break;
        o++;
        let i = n[o++], s = n[o++], a = n[o++];
        e.setAttribute(t, s, a, i);
    }
    else {
        let i = r, s = n[++o];
        WT(i) ? e.setProperty(t, i, s) : e.setAttribute(t, i, s), o++;
    }
} return o; }
function fg(e) { return e === 3 || e === 4 || e === 6; }
function WT(e) { return e.charCodeAt(0) === 64; }
function jn(e, t) { if (!(t === null || t.length === 0))
    if (e === null || e.length === 0)
        e = t.slice();
    else {
        let n = -1;
        for (let o = 0; o < t.length; o++) {
            let r = t[o];
            typeof r == "number" ? n = r : n === 0 || (n === -1 || n === 2 ? Hp(e, n, r, null, t[++o]) : Hp(e, n, r, null, null));
        }
    } return e; }
function Hp(e, t, n, o, r) { let i = 0, s = e.length; if (t === -1)
    s = -1;
else
    for (; i < e.length;) {
        let a = e[i++];
        if (typeof a == "number") {
            if (a === t) {
                s = -1;
                break;
            }
            else if (a > t) {
                s = i - 1;
                break;
            }
        }
    } for (; i < e.length;) {
    let a = e[i];
    if (typeof a == "number")
        break;
    if (a === n) {
        r !== null && (e[i + 1] = r);
        return;
    }
    i++, r !== null && i++;
} s !== -1 && (e.splice(s, 0, t), i = s + 1), e.splice(i++, 0, n), r !== null && e.splice(i++, 0, r); }
function pg(e) { return e !== xn; }
function Wi(e) { return e & 32767; }
function qT(e) { return e >> 16; }
function qi(e, t) { let n = qT(e), o = t; for (; n > 0;)
    o = o[_o], n--; return o; }
var il = !0;
function Qi(e) { let t = il; return il = e, t; }
var QT = 256, hg = QT - 1, gg = 5, YT = 0, Ke = {};
function ZT(e, t, n) { let o; typeof n == "string" ? o = n.charCodeAt(0) || 0 : n.hasOwnProperty(Ft) && (o = n[Ft]), o == null && (o = n[Ft] = YT++); let r = o & hg, i = 1 << r; t.data[e + (r >> gg)] |= i; }
function Yi(e, t) { let n = mg(e, t); if (n !== -1)
    return n; let o = t[m]; o.firstCreatePass && (e.injectorIndex = t.length, Fc(o.data, e), Fc(t, null), Fc(o.blueprint, null)); let r = lu(e, t), i = e.injectorIndex; if (pg(r)) {
    let s = Wi(r), a = qi(r, t), c = a[m].data;
    for (let l = 0; l < 8; l++)
        t[i + l] = a[s + l] | c[s + l];
} return t[i + 8] = r, i; }
function Fc(e, t) { e.push(0, 0, 0, 0, 0, 0, 0, 0, t); }
function mg(e, t) { return e.injectorIndex === -1 || e.parent && e.parent.injectorIndex === e.injectorIndex || t[e.injectorIndex + 8] === null ? -1 : e.injectorIndex; }
function lu(e, t) { if (e.parent && e.parent.injectorIndex !== -1)
    return e.parent.injectorIndex; let n = 0, o = null, r = t; for (; r !== null;) {
    if (o = Cg(r), o === null)
        return xn;
    if (n++, r = r[_o], o.injectorIndex !== -1)
        return o.injectorIndex | n << 16;
} return xn; }
function sl(e, t, n) { ZT(e, t, n); }
function KT(e, t) { if (t === "class")
    return e.classes; if (t === "style")
    return e.styles; let n = e.attrs; if (n) {
    let o = n.length, r = 0;
    for (; r < o;) {
        let i = n[r];
        if (fg(i))
            break;
        if (i === 0)
            r = r + 2;
        else if (typeof i == "number")
            for (r++; r < o && typeof n[r] == "string";)
                r++;
        else {
            if (i === t)
                return n[r + 1];
            r = r + 2;
        }
    }
} return null; }
function yg(e, t, n) { if (n & 8 || e !== void 0)
    return e; qa(t, "NodeInjector"); }
function vg(e, t, n, o) { if (n & 8 && o === void 0 && (o = null), (n & 3) === 0) {
    let r = e[k], i = Ht(void 0);
    try {
        return r ? r.get(t, o, n & 8) : rp(t, o, n & 8);
    }
    finally {
        Ht(i);
    }
} return yg(o, t, n); }
function Eg(e, t, n, o = 0, r) { if (e !== null) {
    if (t[A] & 2048 && !(o & 2)) {
        let s = tM(e, t, n, o, Ke);
        if (s !== Ke)
            return s;
    }
    let i = Ig(e, t, n, o, Ke);
    if (i !== Ke)
        return i;
} return vg(t, n, o, r); }
function Ig(e, t, n, o, r) { let i = XT(n); if (typeof i == "function") {
    if (!Cc(t, e, o))
        return o & 1 ? yg(r, n, o) : vg(t, n, o, r);
    try {
        let s;
        if (s = i(o), s == null && !(o & 8))
            qa(n);
        else
            return s;
    }
    finally {
        Tc();
    }
}
else if (typeof i == "number") {
    let s = null, a = mg(e, t), c = xn, l = o & 1 ? t[J][ue] : null;
    for ((a === -1 || o & 4) && (c = a === -1 ? lu(e, t) : t[a + 8], c === xn || !jp(o, !1) ? a = -1 : (s = t[m], a = Wi(c), t = qi(c, t))); a !== -1;) {
        let u = t[m];
        if (Vp(i, a, u.data)) {
            let d = JT(a, t, n, s, o, l);
            if (d !== Ke)
                return d;
        }
        c = t[a + 8], c !== xn && jp(o, t[m].data[a + 8] === l) && Vp(i, a, t) ? (s = u, a = Wi(c), t = qi(c, t)) : a = -1;
    }
} return r; }
function JT(e, t, n, o, r, i) { let s = t[m], a = s.data[e + 8], c = o == null ? me(a) && il : o != s && (a.type & 3) !== 0, l = r & 1 && i === a, u = Li(a, s, n, c, l); return u !== null ? Jo(t, s, u, a, r) : Ke; }
function Li(e, t, n, o, r) { let i = e.providerIndexes, s = t.data, a = i & 1048575, c = e.directiveStart, l = e.directiveEnd, u = i >> 20, d = o ? a : a + u, f = r ? a + u : l; for (let p = d; p < f; p++) {
    let h = s[p];
    if (p < c && n === h || p >= c && h.type === n)
        return p;
} if (r) {
    let p = s[c];
    if (p && Ae(p) && p.type === n)
        return c;
} return null; }
function Jo(e, t, n, o, r) { let i = e[n], s = t.data; if (i instanceof tn) {
    let a = i;
    if (a.resolving)
        throw op("");
    let c = Qi(a.canSeeViewProviders);
    a.resolving = !0;
    let l = s[n].type || s[n], u, d = a.injectImpl ? Ht(a.injectImpl) : null, f = Cc(e, o, 0);
    try {
        i = e[n] = a.factory(void 0, r, s, e, o), t.firstCreatePass && n >= o.directiveStart && BT(n, s[n], t);
    }
    finally {
        d !== null && Ht(d), Qi(c), a.resolving = !1, Tc();
    }
} return i; }
function XT(e) { if (typeof e == "string")
    return e.charCodeAt(0) || 0; let t = e.hasOwnProperty(Ft) ? e[Ft] : void 0; return typeof t == "number" ? t >= 0 ? t & hg : eM : t; }
function Vp(e, t, n) { let o = 1 << e; return !!(n[t + (e >> gg)] & o); }
function jp(e, t) { return !(e & 2) && !(e & 1 && t); }
var bt = class {
    _tNode;
    _lView;
    constructor(t, n) { this._tNode = t, this._lView = n; }
    get(t, n, o) { return Eg(this._tNode, this._lView, t, Qa(o), n); }
};
function eM() { return new bt(M(), g()); }
function Dg(e) { return Je(() => { let t = e.prototype.constructor, n = t[vt] || al(t), o = Object.prototype, r = Object.getPrototypeOf(e.prototype).constructor; for (; r && r !== o;) {
    let i = r[vt] || al(r);
    if (i && i !== n)
        return i;
    r = Object.getPrototypeOf(r);
} return i => new i; }); }
function al(e) { return Jr(e) ? () => { let t = al(G(e)); return t && t(); } : oi(e); }
function tM(e, t, n, o, r) { let i = e, s = t; for (; i !== null && s !== null && s[A] & 2048 && !We(s);) {
    let a = Ig(i, s, n, o | 2, Ke);
    if (a !== Ke)
        return a;
    let c = i.parent;
    if (!c) {
        let l = s[Xa];
        if (l) {
            let u = l.get(n, Ke, o & -5);
            if (u !== Ke)
                return u;
        }
        c = Cg(s), s = s[_o];
    }
    i = c;
} return r; }
function Cg(e) { let t = e[m], n = t.type; return n === 2 ? t.declTNode : n === 1 ? e[ue] : null; }
function Is(e) { return KT(M(), e); }
var Tg = Kn("Attribute", e => ({ attributeName: e, __NG_ELEMENT_ID__: () => Is(e) })), Bp = null;
function uu() { return Bp = Bp || new zi; }
function Ds(e) { return Mg(uu().parameters(e)); }
function Mg(e) { return e.map(t => nM(t)); }
function nM(e) { let t = { token: null, attribute: null, host: !1, optional: !1, self: !1, skipSelf: !1 }; if (Array.isArray(e) && e.length > 0)
    for (let n = 0; n < e.length; n++) {
        let o = e[n];
        if (o === void 0)
            continue;
        let r = Object.getPrototypeOf(o);
        if (o instanceof Xh || r.ngMetadataName === "Optional")
            t.optional = !0;
        else if (o instanceof tg || r.ngMetadataName === "SkipSelf")
            t.skipSelf = !0;
        else if (o instanceof eg || r.ngMetadataName === "Self")
            t.self = !0;
        else if (o instanceof ng || r.ngMetadataName === "Host")
            t.host = !0;
        else if (o instanceof Jh)
            t.token = o.token;
        else if (o instanceof Tg) {
            if (o.attributeName === void 0)
                throw new _(-204, !1);
            t.attribute = o.attributeName;
        }
        else
            t.token = o;
    }
else
    e === void 0 || Array.isArray(e) && e.length === 0 ? t.token = null : t.token = e; return t; }
function oM(e, t) { let n = null, o = null; e.hasOwnProperty(Xr) || Object.defineProperty(e, Xr, { get: () => (n === null && (n = oe({ usage: 0, kind: "injectable", type: e }).compileInjectable(Lp, `ng:///${e.name}/\u0275prov.js`, aM(e, t))), n) }), e.hasOwnProperty(vt) || Object.defineProperty(e, vt, { get: () => { if (o === null) {
        let r = oe({ usage: 0, kind: "injectable", type: e });
        o = r.compileFactory(Lp, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, typeArgumentCount: 0, deps: Ds(e), target: r.FactoryTarget.Injectable });
    } return o; }, configurable: !0 }); }
var rM = $a({ provide: String, useValue: $a });
function Up(e) { return e.useClass !== void 0; }
function iM(e) { return rM in e; }
function $p(e) { return e.useFactory !== void 0; }
function sM(e) { return e.useExisting !== void 0; }
function aM(e, t) { let n = t || { providedIn: null }, o = { name: e.name, type: e, typeArgumentCount: 0, providedIn: n.providedIn }; return (Up(n) || $p(n)) && n.deps !== void 0 && (o.deps = Mg(n.deps)), Up(n) ? o.useClass = n.useClass : iM(n) ? o.useValue = n.useValue : $p(n) ? o.useFactory = n.useFactory : sM(n) && (o.useExisting = n.useExisting), o; }
var cM = vr("Injectable", void 0, void 0, void 0, (e, t) => oM(e, t));
function lM() { return Jn(M(), g()); }
function Jn(e, t) { return new Er(ie(e, t)); }
var Er = (() => { class e {
    nativeElement;
    constructor(n) { this.nativeElement = n; }
    static __NG_ELEMENT_ID__ = lM;
} return e; })();
function Ng(e) { return e instanceof Er ? e.nativeElement : e; }
function uM() { return this._results[Symbol.iterator](); }
var Zi = class {
    _emitDistinctChangesOnly;
    dirty = !0;
    _onDirty = void 0;
    _results = [];
    _changesDetected = !1;
    _changes = void 0;
    length = 0;
    first = void 0;
    last = void 0;
    get changes() { return this._changes ??= new Kh; }
    constructor(t = !1) { this._emitDistinctChangesOnly = t; }
    get(t) { return this._results[t]; }
    map(t) { return this._results.map(t); }
    filter(t) { return this._results.filter(t); }
    find(t) { return this._results.find(t); }
    reduce(t, n) { return this._results.reduce(t, n); }
    forEach(t) { this._results.forEach(t); }
    some(t) { return this._results.some(t); }
    toArray() { return this._results.slice(); }
    toString() { return this._results.toString(); }
    reset(t, n) { this.dirty = !1; let o = Fe(t); (this._changesDetected = !ip(this._results, o, n)) && (this._results = o, this.length = o.length, this.last = o[this.length - 1], this.first = o[0]); }
    notifyOnChanges() { this._changes !== void 0 && (this._changesDetected || !this._emitDistinctChangesOnly) && this._changes.next(this); }
    onDirty(t) { this._onDirty = t; }
    setDirty() { this.dirty = !0, this._onDirty?.(); }
    destroy() { this._changes !== void 0 && (this._changes.complete(), this._changes.unsubscribe()); }
    [Symbol.iterator] = uM;
}, fn = "ngSkipHydration", dM = "ngskiphydration";
function du(e) { let t = e.mergedAttrs; if (t === null)
    return !1; for (let n = 0; n < t.length; n += 2) {
    let o = t[n];
    if (typeof o == "number")
        return !1;
    if (typeof o == "string" && o.toLowerCase() === dM)
        return !0;
} return !1; }
function wg(e) { return e.hasAttribute(fn); }
function Xo(e) { return (e.flags & 128) === 128; }
function Xn(e) { if (Xo(e))
    return !0; let t = e.parent; for (; t;) {
    if (Xo(e) || du(t))
        return !0;
    t = t.parent;
} return !1; }
function _g(e) { return Xo(e) || du(e) || Xn(e); }
var Cs = (function (e) { return e[e.OnPush = 0] = "OnPush", e[e.Eager = 1] = "Eager", e[e.Default = 1] = "Default", e; })(Cs || {}), Ts = new Map, fM = 0;
function pM() { return fM++; }
function hM(e) { Ts.set(e[Se], e); }
function Sg(e) { return Ts.get(e) || null; }
function cl(e) { Ts.delete(e[Se]); }
function gM() { return Ts; }
var Ki = class {
    lViewId;
    nodeIndex;
    native;
    component;
    directives;
    localRefs;
    get lView() { return Sg(this.lViewId); }
    constructor(t, n, o) { this.lViewId = t, this.nodeIndex = n, this.native = o; }
};
function Ee(e) { let t = Pi(e); if (t) {
    if (re(t)) {
        let n = t, o, r, i;
        if (bg(e)) {
            if (o = EM(n, e), o == -1)
                throw new Error("The provided component was not found in the application");
            r = e;
        }
        else if (yM(e)) {
            if (o = IM(n, e), o == -1)
                throw new Error("The provided directive was not found in the application");
            i = Ag(o, n);
        }
        else if (o = Gp(n, e), o == -1)
            return null;
        let s = O(n[o]), a = Pi(s), c = a && !Array.isArray(a) ? a : zp(n, o, s);
        if (r && c.component === void 0 && (c.component = r, Re(c.component, c)), i && c.directives === void 0) {
            c.directives = i;
            for (let l = 0; l < i.length; l++)
                Re(i[l], c);
        }
        Re(c.native, c), t = c;
    }
}
else {
    let n = e, o = n;
    for (; o = o.parentNode;) {
        let r = Pi(o);
        if (r) {
            let i = Array.isArray(r) ? r : r.lView;
            if (!i)
                return null;
            let s = Gp(i, n);
            if (s >= 0) {
                let a = O(i[s]), c = zp(i, s, a);
                Re(a, c), t = c;
                break;
            }
        }
    }
} return t || null; }
function zp(e, t, n) { return new Ki(e[Se], t, n); }
var ll = "__ngContext__";
function Re(e, t) { re(t) ? (e[ll] = t[Se], hM(t)) : e[ll] = t; }
function Pi(e) { let t = e[ll]; return typeof t == "number" ? Sg(t) : t || null; }
function mM(e) { let t = Pi(e); return t ? re(t) ? t : t.lView : null; }
function bg(e) { return e && e.constructor && e.constructor.\u0275cmp; }
function yM(e) { return e && e.constructor && e.constructor.\u0275dir; }
function Gp(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (O(e[o]) === t)
        return o; return -1; }
function vM(e) { if (e.child)
    return e.child; if (e.next)
    return e.next; for (; e.parent && !e.parent.next;)
    e = e.parent; return e.parent && e.parent.next; }
function EM(e, t) { let n = e[m].components; if (n)
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        if (pe(r, e)[H] === t)
            return r;
    }
else if (pe(E, e)[H] === t)
    return E; return -1; }
function IM(e, t) { let n = e[m].firstChild; for (; n;) {
    let o = n.directiveStart, r = n.directiveEnd;
    for (let i = o; i < r; i++)
        if (e[i] === t)
            return n.index;
    n = vM(n);
} return -1; }
function Ag(e, t) { let n = t[m].data[e]; if (n.directiveStart === 0)
    return F; let o = []; for (let r = n.directiveStart; r < n.directiveEnd; r++) {
    let i = t[r];
    bg(i) || o.push(i);
} return o; }
function DM(e, t) { let n = t[m].data[e]; return me(n) ? t[n.directiveStart + n.componentOffset] : null; }
function CM(e, t) { let n = e[m].data[t]; if (n && n.localNames) {
    let o = {}, r = n.index + 1;
    for (let i = 0; i < n.localNames.length; i += 2)
        o[n.localNames[i]] = e[r], r++;
    return o;
} return null; }
function Rg(e) { return Og(e[Dt]); }
function kg(e) { return Og(e[le]); }
function Og(e) { for (; e !== null && !ee(e);)
    e = e[le]; return e; }
function Wp(e) { let t = Ee(e); if (t === null)
    return null; if (t.component === void 0) {
    let n = t.lView;
    if (n === null)
        return null;
    t.component = DM(t.nodeIndex, n);
} return t.component; }
function TM(e) { OM(e); let t = Ee(e), n = t ? t.lView : null; return n === null ? null : n[H]; }
function MM(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return null; let o; for (; n[m].type === 2 && (o = zt(n));)
    n = o; return We(n) ? null : n[H]; }
function NM(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return Te.NULL; let o = n[m].data[t.nodeIndex]; return new bt(o, n); }
function wM(e) { let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = o.data[t.nodeIndex], i = [], s = r.providerIndexes & 1048575, a = r.directiveEnd; for (let c = s; c < a; c++) {
    let l = o.data[c];
    kM(l) && (l = l.type), i.push(l);
} return i; }
function _M(e) { if (e instanceof Text)
    return []; let t = Ee(e), n = t ? t.lView : null; if (n === null)
    return []; let o = n[m], r = t.nodeIndex; return o?.data[r] ? (t.directives === void 0 && (t.directives = Ag(r, n)), t.directives === null ? [] : [...t.directives]) : []; }
var xg = (function (e) { return e[e.Default = 0] = "Default", e[e.OnPush = 1] = "OnPush", e; })(xg || {}), Lg = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 1] = "None", e; })(Lg || {});
function SM(e) { let t = Ee(e); if (t === null)
    return {}; if (t.localRefs === void 0) {
    let n = t.lView;
    if (n === null)
        return {};
    t.localRefs = CM(n, t.nodeIndex);
} return t.localRefs || {}; }
function bM(e) { return Ee(e).native; }
function AM(e) { let t = Ee(e), n = t === null ? null : t.lView; if (n === null)
    return []; let o = n[m], r = n[Vt], i = o.cleanup, s = []; if (i && r)
    for (let a = 0; a < i.length;) {
        let c = i[a++], l = i[a++];
        if (typeof c == "string") {
            let u = c, d = O(n[l]), f = r[i[a++]], p = i[a++], h = typeof p == "boolean" || p >= 0 ? "dom" : "output", y = typeof p == "boolean" ? p : !1;
            e == d && s.push({ element: e, name: u, callback: f, useCapture: y, type: h });
        }
    } return s.sort(RM), s; }
function RM(e, t) { return e.name == t.name ? 0 : e.name < t.name ? -1 : 1; }
function kM(e) { return e.type !== void 0 && e.declaredInputs !== void 0 && e.resolveHostDirectives !== void 0; }
function OM(e) { if (typeof Element < "u" && !(e instanceof Element))
    throw new Error("Expecting instance of DOM Element"); }
var ul;
function xM(e) { ul = e; }
function Ms() { if (ul !== void 0)
    return ul; if (typeof document < "u")
    return document; throw new _(210, !1); }
var lt = new S("", { factory: () => LM }), LM = "ng";
var fu = new S(""), PM = new S("", { providedIn: "platform", factory: () => "unknown" }), FM = new S(""), HM = new S("", { factory: () => I(Gt).body?.querySelector("[ngCspNonce]")?.getAttribute("ngCspNonce") || null }), Pg = { breakpoints: [16, 32, 48, 64, 96, 128, 256, 384, 640, 750, 828, 1080, 1200, 1920, 2048, 3840], placeholderResolution: 30, disableImageSizeWarning: !1, disableImageLazyLoadWarning: !1 }, VM = new S("", { factory: () => Pg });
function jM(e) { return e; }
var eo = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => { let n = new e; return (typeof ngServerMode > "u" || !ngServerMode) && (n.store = Fg(I(Gt), I(lt))), n; } });
    store = {};
    onSerializeCallbacks = {};
    get(n, o) { return this.store[n] !== void 0 ? this.store[n] : o; }
    set(n, o) { this.store[n] = o; }
    remove(n) { delete this.store[n]; }
    hasKey(n) { return this.store.hasOwnProperty(n); }
    get isEmpty() { return Object.keys(this.store).length === 0; }
    onSerialize(n, o) { this.onSerializeCallbacks[n] = o; }
    toJson() { for (let n in this.onSerializeCallbacks)
        if (this.onSerializeCallbacks.hasOwnProperty(n))
            try {
                this.store[n] = this.onSerializeCallbacks[n]();
            }
            catch (o) {
                console.warn("Exception in onSerialize callback: ", o);
            } return JSON.stringify(this.store).replace(/</g, "\\u003C").replace(/\//g, "\\u002F"); }
} return e; })();
function Fg(e, t) { let n = e.getElementById(t + "-state"); if (n?.textContent)
    try {
        return JSON.parse(n.textContent);
    }
    catch (o) {
        console.warn("Exception while restoring TransferState for app " + t, o);
    } return {}; }
var pu = "h", hu = "b", Hg = "f", Vg = "n", Ir = "e", Ns = "t", to = "c", Dr = "x", st = "r", ws = "i", Cr = "n", no = "d", _s = "l", Ss = "di", Tr = "s", gu = "p", Mr = "t", pn = new S(""), jg = !1, mu = new S("", { factory: () => jg }), yu = new S(""), bs = new S(""), vu = !1, Bg = new S("", { factory: () => [] }), Eu = new S(""), Nr = new S("", { factory: () => new Map }), BM = new S(""), Ji = { passive: !0, capture: !0 }, Hc = new WeakMap, Vc = new WeakMap, St = new WeakMap, Xi = ["click", "keydown"], es = ["mouseenter", "mouseover", "focusin"], Ti = new Map, er = class {
    callbacks = new Set;
    listener = () => { for (let t of this.callbacks)
        t(); };
};
function Ug(e, t) { let n = Vc.get(e); if (!n) {
    n = new er, Vc.set(e, n);
    for (let o of Xi)
        e.addEventListener(o, n.listener, Ji);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    Vc.delete(e);
    for (let i of Xi)
        e.removeEventListener(i, r, Ji);
} }; }
function $g(e, t) { let n = Hc.get(e); if (!n) {
    n = new er, Hc.set(e, n);
    for (let o of es)
        e.addEventListener(o, n.listener, Ji);
} return n.callbacks.add(t), () => { let { callbacks: o, listener: r } = n; if (o.delete(t), o.size === 0) {
    for (let i of es)
        e.removeEventListener(i, r, Ji);
    Hc.delete(e);
} }; }
function UM(e) { let t = zg(e); return new IntersectionObserver(n => { for (let o of n)
    o.isIntersecting && St.has(o.target) && St.get(o.target)?.get(t)?.listener(); }, e); }
function $M(e, t, n, o) { let r = zg(o), i = St.get(e)?.get(r); Ti.has(r) || Ti.set(r, { observer: n(o), count: 0 }); let s = Ti.get(r); if (!i) {
    i = new er, s.observer.observe(e);
    let a = St.get(e);
    a ? a.set(r, i) : (a = new Map, St.set(e, a)), a.set(r, i), s.count++;
} return i.callbacks.add(t), () => { if (St.get(e)?.has(r)) {
    if (i.callbacks.delete(t), i.callbacks.size === 0) {
        s.observer.unobserve(e), s.count--;
        let a = St.get(e);
        a && (a.delete(r), a.size === 0 && St.delete(e));
    }
    s.count === 0 && (s.observer.disconnect(), Ti.delete(r));
} }; }
function zg(e) {
    return e ? `${e.rootMargin}/${typeof e.threshold == "number" ? e.threshold : e.threshold?.join(`
`)}` : "";
}
var oo = "ngb";
function Iu(e, t, n = null) { if (t.length === 0 || e.nodeType !== Node.ELEMENT_NODE)
    return; let o = e.getAttribute(Nn.JSACTION), r = t.reduce((s, a) => (o?.indexOf(a) ?? -1) === -1 ? s + a + ":;" : s, ""); e.setAttribute(Nn.JSACTION, `${o ?? ""}${r}`); let i = n ?? ""; i !== "" && r.length > 0 && e.setAttribute(oo, i); }
var Gg = (e, t, n) => { let o = e, r = o.__jsaction_fns ?? new Map, i = r.get(t) ?? []; i.push(n), r.set(t, i), o.__jsaction_fns = r; }, Du = (e, t) => { let n = e, o = n.getAttribute(oo) ?? "", r = t.get(o) ?? new Set; r.has(n) || r.add(n), t.set(o, r); };
function zM(e, t) { if (e.length > 0) {
    let n = [];
    for (let r of e)
        t.has(r) && (n = [...n, ...t.get(r)]);
    new Set(n).forEach(Cu);
} }
var Cu = e => { e.removeAttribute(Nn.JSACTION), e.removeAttribute(oo), e.__jsaction_fns = void 0; }, Tu = new S("", { factory: () => ({}) }), dl = new WeakMap;
function GM(e, t) { if (e == null || typeof e != "object")
    return; let n = dl.get(e); n || (n = new WeakSet, dl.set(e, n)), n.add(t); }
function Mu(e, t) { let n = t?.__jsaction_fns?.get(e.type); if (!(!n || !t?.isConnected) && !(t && dl.get(e)?.has(t)))
    for (let o of n)
        o(e); }
var fl = new Map;
function Wg(e, t) { return fl.set(e, t), () => fl.delete(e); }
var qp = !1, qg = (e, t, n, o) => { };
function WM(e, t, n, o) { qg(e, t, n, o); }
function Qg() { qp || (qg = (e, t, n, o) => { let r = e[k].get(lt); fl.get(r)?.(t, n, o); }, qp = !0); }
var ut = new S(""), Yg = (() => { class e {
    registry = new Map;
    cleanupFns = new Map;
    jsActionMap = I(Nr);
    contract = I(Tu);
    add(n, o) { if (this.registry.set(n, o), this.awaitingCallbacks.has(n)) {
        let r = this.awaitingCallbacks.get(n);
        for (let i of r)
            i();
    } }
    get(n) { return this.registry.get(n) ?? null; }
    has(n) { return this.registry.has(n); }
    cleanup(n) { zM(n, this.jsActionMap); for (let o of n)
        this.registry.delete(o), this.jsActionMap.delete(o), this.invokeTriggerCleanupFns(o), this.hydrating.delete(o), this.awaitingCallbacks.delete(o); this.size === 0 && this.contract.instance?.cleanUp(); }
    get size() { return this.registry.size; }
    addCleanupFn(n, o) { let r = []; this.cleanupFns.has(n) && (r = this.cleanupFns.get(n)), r.push(o), this.cleanupFns.set(n, r); }
    invokeTriggerCleanupFns(n) { let o = this.cleanupFns.get(n) ?? []; for (let r of o)
        r(); this.cleanupFns.delete(n); }
    hydrating = new Map;
    awaitingCallbacks = new Map;
    awaitParentBlock(n, o) { let r = this.awaitingCallbacks.get(n) ?? []; r.push(o), this.awaitingCallbacks.set(n, r); }
    static \u0275prov = B({ token: e, providedIn: null, factory: () => new e });
} return e; })();
function ro(e) { return (e.flags & 32) === 32; }
var Zg = "__nghData__", As = Zg, Kg = "__nghDeferData__", Rs = Kg;
function qM(e) { return e === Zg || e === Kg; }
var Ln = "ngh", Jg = "nghm", Xg = () => null;
function QM(e, t, n = !1) { let o = e.getAttribute(Ln); if (o == null)
    return null; let [r, i] = o.split("|"); if (o = n ? i : r, !o)
    return null; let s = i ? `|${i}` : "", a = n ? r : s, c = {}; if (o !== "") {
    let u = t.get(eo, null, { optional: !0 });
    u !== null && (c = u.get(As, [])[Number(o)]);
} let l = { data: c, firstChild: e.firstChild ?? null }; return n && (l.firstChild = e, ks(l, 0, e.nextSibling)), a ? e.setAttribute(Ln, a) : e.removeAttribute(Ln), l; }
function em() { Xg = QM; }
function tm(e, t, n = !1) { return Xg(e, t, n); }
function Nu(e) { let t = e._lView; return t[m].type === 2 ? null : (We(t) && (t = t[E]), t); }
function YM(e) { return e.textContent?.replace(/\s/gm, ""); }
function ZM(e) { let t = Ms(), n = t.createNodeIterator(e, NodeFilter.SHOW_COMMENT, { acceptNode(i) { let s = YM(i); return s === "ngetn" || s === "ngtns" ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; } }), o, r = []; for (; o = n.nextNode();)
    r.push(o); for (let i of r)
    i.textContent === "ngetn" ? i.replaceWith(t.createTextNode("")) : i.remove(); }
var nm = (function (e) { return e.Hydrated = "hydrated", e.Skipped = "skipped", e.Mismatched = "mismatched", e; })(nm || {}), KM = "__ngDebugHydrationInfo__";
function JM(e) { return e[KM] ?? null; }
function ks(e, t, n) { e.segmentHeads ??= {}, e.segmentHeads[t] = n; }
function pl(e, t) { return e.segmentHeads?.[t] ?? null; }
function wr(e) { return e.get(Eu, !1, { optional: !0 }); }
var XM = !1;
function eN() { XM = !1; }
function om(e, t) { let n = e.data, o = n[Ir]?.[t] ?? null; return o === null && n[to]?.[t] && (o = wu(e, t)), o; }
function tN(e, t) { return e.data[Ir]?.[t] !== void 0; }
function rm(e, t) { return e.data[to]?.[t] ?? null; }
function wu(e, t) { let n = rm(e, t) ?? [], o = 0; for (let r of n)
    o += r[st] * (r[Dr] ?? 1); return o; }
function im(e) { if (typeof e.disconnectedNodes > "u") {
    let t = e.data[no];
    e.disconnectedNodes = t ? new Set(t) : null;
} return e.disconnectedNodes; }
function Os(e, t) { if (typeof e.disconnectedNodes > "u") {
    let n = e.data[no];
    e.disconnectedNodes = n ? new Set(n) : null;
} return !!im(e)?.has(t); }
function xs(e, t) { let n = e[ae]; return n !== null && !Oo() && !ro(t) && !Os(n, t.index - E); }
function _u(e, t) { let n = t, o = e.corruptedTextNodes; n.textContent === "" ? o.set(n, "ngetn") : n.nextSibling?.nodeType === Node.TEXT_NODE && o.set(n, "ngtns"); }
function sm(e) { let t = []; return e !== null && (e.has(4) && t.push(...es), e.has(3) && t.push(...Xi)), t; }
function nN(e, t) { let n = t.get(ut), r = t.get(eo).get(Rs, {}), i = !1, s = e, a = null, c = []; for (; !i && s;) {
    i = n.has(s);
    let l = n.hydrating.get(s);
    if (a === null && l != null) {
        a = l.promise;
        break;
    }
    c.unshift(s), s = r[s][gu];
} return { parentBlockPromise: a, hydrationQueue: c }; }
function oN(e) { let t = e.body.querySelectorAll("[jsaction]"), n = new Set, o = [es.join(":;"), Xi.join(":;")].join("|"); for (let r of t) {
    let i = r.getAttribute("jsaction"), s = r.getAttribute("ngb");
    i?.match(o) && s !== null && n.add(r);
} return n; }
function am(e, t) { let n = oN(e), o = t.get(Nr); for (let r of n)
    Du(r, o); }
var cm = () => ({});
function rN(e) { let t = e.get(eo, null, { optional: !0 }); return t !== null ? t.get(Rs, {}) : {}; }
function lm() { cm = rN; }
function iN(e) { return cm(e); }
function sN(e) { return typeof e == "object" && e.trigger === 5; }
function aN(e) { return e[Mr]?.find(n => sN(n))?.delay ?? null; }
function cN(e) { let t = e[Mr]; if (t)
    for (let n of t) {
        if (n === 2)
            return !0;
        if (typeof n == "object" && n.trigger === 2)
            return n.intersectionObserverOptions || !0;
    } return null; }
function Qp(e, t) { return e[Mr]?.includes(t) ?? !1; }
function lN(e) { return { data: e, hydrate: { idle: Qp(e, 0), immediate: Qp(e, 1), timer: aN(e), viewport: cN(e) } }; }
function um(e) { let t = iN(e), n = new Map; for (let o in t)
    n.set(o, lN(t[o])); return n; }
function jc(e) { return !!e && e.nodeType === Node.COMMENT_NODE && e.textContent?.trim() === Jg; }
function Yp(e) { for (; e && e.nodeType === Node.TEXT_NODE;)
    e = e.previousSibling; return e; }
function dm(e) { for (let o of e.body.childNodes)
    if (jc(o))
        return; let t = Yp(e.body.previousSibling); if (jc(t))
    return; let n = Yp(e.head.lastChild); if (!jc(n))
    throw new _(-507, !1); }
function fm(e, t) { let n = e.contentQueries; if (n !== null) {
    let o = L(null);
    try {
        for (let r = 0; r < n.length; r += 2) {
            let i = n[r], s = n[r + 1];
            if (s !== -1) {
                let a = e.data[s];
                xo(i), a.contentQueries(2, t[s], s);
            }
        }
    }
    finally {
        L(o);
    }
} }
function hl(e, t, n) { xo(0); let o = L(null); try {
    t(e, n);
}
finally {
    L(o);
} }
function Su(e, t, n) { if (tc(t)) {
    let o = L(null);
    try {
        let r = t.directiveStart, i = t.directiveEnd;
        for (let s = r; s < i; s++) {
            let a = e.data[s];
            if (a.contentQueries) {
                let c = n[s];
                a.contentQueries(1, c, s);
            }
        }
    }
    finally {
        L(o);
    }
} }
var ke = (function (e) { return e[e.Emulated = 0] = "Emulated", e[e.None = 2] = "None", e[e.ShadowDom = 3] = "ShadowDom", e[e.ExperimentalIsolatedShadowDom = 4] = "ExperimentalIsolatedShadowDom", e; })(ke || {}), uN = { name: "custom-elements" }, dN = { name: "no-errors-schema" }, pm = !1;
function fN(e) { pm = e; }
function pN() { return pm; }
var hm = !1;
function hN(e) { hm = e; }
function gN() { return hm; }
var Mi;
function gm() { if (Mi === void 0 && (Mi = null, Ie.trustedTypes))
    try {
        Mi = Ie.trustedTypes.createPolicy("angular", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Mi; }
function io(e) { return gm()?.createHTML(e) || e; }
function mN(e) { return gm()?.createScriptURL(e) || e; }
var Ni;
function bu() { if (Ni === void 0 && (Ni = null, Ie.trustedTypes))
    try {
        Ni = Ie.trustedTypes.createPolicy("angular#unsafe-bypass", { createHTML: e => e, createScript: e => e, createScriptURL: e => e });
    }
    catch { } return Ni; }
function Zp(e) { return bu()?.createHTML(e) || e; }
function Kp(e) { return bu()?.createScript(e) || e; }
function Jp(e) { return bu()?.createScriptURL(e) || e; }
var at = class {
    changingThisBreaksApplicationSecurity;
    constructor(t) { this.changingThisBreaksApplicationSecurity = t; }
    toString() { return `SafeValue must use [property]=binding: ${this.changingThisBreaksApplicationSecurity} (see ${Yr})`; }
}, gl = class extends at {
    getTypeName() { return "HTML"; }
}, ml = class extends at {
    getTypeName() { return "Style"; }
}, yl = class extends at {
    getTypeName() { return "Script"; }
}, vl = class extends at {
    getTypeName() { return "URL"; }
}, El = class extends at {
    getTypeName() { return "ResourceURL"; }
};
function dt(e) { return e instanceof at ? e.changingThisBreaksApplicationSecurity : e; }
function so(e, t) { let n = mm(e); if (n != null && n !== t) {
    if (n === "ResourceURL" && t === "URL")
        return !0;
    throw new Error(`Required a safe ${t}, got a ${n} (see ${Yr})`);
} return n === t; }
function mm(e) { return e instanceof at && e.getTypeName() || null; }
function yN(e) { return new gl(e); }
function vN(e) { return new ml(e); }
function EN(e) { return new yl(e); }
function IN(e) { return new vl(e); }
function DN(e) { return new El(e); }
function ym(e) { let t = new Dl(e); return CN() ? new Il(t) : t; }
var Il = class {
    inertDocumentHelper;
    constructor(t) { this.inertDocumentHelper = t; }
    getInertBodyElement(t) { t = "<body><remove></remove>" + t; try {
        let n = new window.DOMParser().parseFromString(io(t), "text/html").body;
        return n === null ? this.inertDocumentHelper.getInertBodyElement(t) : (n.firstChild?.remove(), n);
    }
    catch {
        return null;
    } }
}, Dl = class {
    defaultDoc;
    inertDocument;
    constructor(t) { this.defaultDoc = t, this.inertDocument = this.defaultDoc.implementation.createHTMLDocument("sanitization-inert"); }
    getInertBodyElement(t) { let n = this.inertDocument.createElement("template"); return n.innerHTML = io(t), n; }
};
function CN() { try {
    return !!new window.DOMParser().parseFromString(io(""), "text/html");
}
catch {
    return !1;
} }
var TN = /^(?!javascript:)(?:[a-z0-9+.-]+:|[^&:\/?#]*(?:[\/?#]|$))/i;
function Ls(e) { return e = String(e), e.match(TN) ? e : "unsafe:" + e; }
function ft(e) { let t = {}; for (let n of e.split(","))
    t[n] = !0; return t; }
function _r(...e) { let t = {}; for (let n of e)
    for (let o in n)
        n.hasOwnProperty(o) && (t[o] = !0); return t; }
var vm = ft("area,br,col,hr,img,wbr"), Em = ft("colgroup,dd,dt,li,p,tbody,td,tfoot,th,thead,tr"), Im = ft("rp,rt"), MN = _r(Im, Em), NN = _r(Em, ft("address,article,aside,blockquote,caption,center,del,details,dialog,dir,div,dl,figure,figcaption,footer,h1,h2,h3,h4,h5,h6,header,hgroup,hr,ins,main,map,menu,nav,ol,pre,section,summary,table,ul")), wN = _r(Im, ft("a,abbr,acronym,audio,b,bdi,bdo,big,br,cite,code,del,dfn,em,font,i,img,ins,kbd,label,map,mark,picture,q,ruby,rp,rt,s,samp,small,source,span,strike,strong,sub,sup,time,track,tt,u,var,video")), Cl = _r(vm, NN, wN, MN), Dm = ft("background,cite,href,itemtype,longdesc,poster,src,xlink:href"), _N = ft("abbr,accesskey,align,alt,autoplay,axis,bgcolor,border,cellpadding,cellspacing,class,clear,color,cols,colspan,compact,controls,coords,datetime,default,dir,download,face,headers,height,hidden,hreflang,hspace,ismap,itemscope,itemprop,kind,label,lang,language,loop,media,muted,nohref,nowrap,open,preload,rel,rev,role,rows,rowspan,rules,scope,scrolling,shape,size,sizes,span,srclang,srcset,start,summary,tabindex,target,title,translate,type,usemap,valign,value,vspace,width"), SN = ft("aria-activedescendant,aria-atomic,aria-autocomplete,aria-busy,aria-checked,aria-colcount,aria-colindex,aria-colspan,aria-controls,aria-current,aria-describedby,aria-details,aria-disabled,aria-dropeffect,aria-errormessage,aria-expanded,aria-flowto,aria-grabbed,aria-haspopup,aria-hidden,aria-invalid,aria-keyshortcuts,aria-label,aria-labelledby,aria-level,aria-live,aria-modal,aria-multiline,aria-multiselectable,aria-orientation,aria-owns,aria-placeholder,aria-posinset,aria-pressed,aria-readonly,aria-relevant,aria-required,aria-roledescription,aria-rowcount,aria-rowindex,aria-rowspan,aria-selected,aria-setsize,aria-sort,aria-valuemax,aria-valuemin,aria-valuenow,aria-valuetext"), Tl = _r(Dm, _N, SN), bN = ft("script,style,template"), Ml = class {
    sanitizedSomething = !1;
    buf = [];
    sanitizeChildren(t) { let n = t.firstChild, o = !0, r = []; for (; n;) {
        if (n.nodeType === Node.ELEMENT_NODE ? o = this.startElement(n) : n.nodeType === Node.TEXT_NODE ? this.chars(n.nodeValue) : this.sanitizedSomething = !0, o && n.firstChild) {
            r.push(n), n = kN(n);
            continue;
        }
        for (; n;) {
            n.nodeType === Node.ELEMENT_NODE && this.endElement(n);
            let i = RN(n);
            if (i) {
                n = i;
                break;
            }
            n = r.pop();
        }
    } return this.buf.join(""); }
    startElement(t) { let n = Xp(t).toLowerCase(); if (!Cl.hasOwnProperty(n))
        return this.sanitizedSomething = !0, !bN.hasOwnProperty(n); this.buf.push("<"), this.buf.push(n); let o = t.attributes; for (let r = 0; r < o.length; r++) {
        let i = o.item(r), s = i.name, a = s.toLowerCase();
        if (!Tl.hasOwnProperty(a)) {
            this.sanitizedSomething = !0;
            continue;
        }
        let c = i.value;
        Dm[a] && (c = Ls(c)), this.buf.push(" ", s, '="', eh(c), '"');
    } return this.buf.push(">"), !0; }
    endElement(t) { let n = Xp(t).toLowerCase(); Cl.hasOwnProperty(n) && !vm.hasOwnProperty(n) && (this.buf.push("</"), this.buf.push(n), this.buf.push(">")); }
    chars(t) { this.buf.push(eh(t)); }
};
function AN(e, t) { return (e.compareDocumentPosition(t) & Node.DOCUMENT_POSITION_CONTAINED_BY) !== Node.DOCUMENT_POSITION_CONTAINED_BY; }
function RN(e) { let t = e.nextSibling; if (t && e !== t.previousSibling)
    throw Cm(t); return t; }
function kN(e) { let t = e.firstChild; if (t && AN(e, t))
    throw Cm(t); return t; }
function Xp(e) { let t = e.nodeName; return typeof t == "string" ? t : "FORM"; }
function Cm(e) { return new Error(`Failed to sanitize html because the element is clobbered: ${e.outerHTML}`); }
var ON = /[\uD800-\uDBFF][\uDC00-\uDFFF]/g, xN = /([^\#-~ |!])/g;
function eh(e) { return e.replace(/&/g, "&amp;").replace(ON, function (t) { let n = t.charCodeAt(0), o = t.charCodeAt(1); return "&#" + ((n - 55296) * 1024 + (o - 56320) + 65536) + ";"; }).replace(xN, function (t) { return "&#" + t.charCodeAt(0) + ";"; }).replace(/</g, "&lt;").replace(/>/g, "&gt;"); }
var wi;
function Tm(e, t) { let n = null; try {
    wi = wi || ym(e);
    let o = t ? String(t) : "";
    n = wi.getInertBodyElement(o);
    let r = 5, i = o;
    do {
        if (r === 0)
            throw new Error("Failed to sanitize html because the input is unstable");
        r--, o = i, i = n.innerHTML, n = wi.getInertBodyElement(o);
    } while (o !== i);
    let a = new Ml().sanitizeChildren(Nl(n) || n);
    return io(a);
}
finally {
    if (n) {
        let o = Nl(n) || n;
        for (; o.firstChild;)
            o.firstChild.remove();
    }
} }
function Nl(e) { return "content" in e && LN(e) ? e.content : null; }
function LN(e) { return e.nodeType === Node.ELEMENT_NODE && e.nodeName === "TEMPLATE"; }
var PN = /^>|^->|<!--|-->|--!>|<!-$/g, FN = /(<|>)/g, HN = "\u200B$1\u200B";
function VN(e) { return e.replace(PN, t => t.replace(FN, HN)); }
function Au(e, t) { return e.createText(t); }
function Mm(e, t, n) { e.setValue(t, n); }
function Ru(e, t) { return e.createComment(VN(t)); }
function Ps(e, t, n) { return e.createElement(t, n); }
function nn(e, t, n, o, r) { e.insertBefore(t, n, o, r); }
function Nm(e, t, n) { e.appendChild(t, n); }
function th(e, t, n, o, r) { o !== null ? nn(e, t, n, o, r) : Nm(e, t, n); }
function Sr(e, t, n, o) { e.removeChild(null, t, n, o); }
function wm(e) { e.textContent = ""; }
function jN(e, t, n) { e.setAttribute(t, "style", n); }
function BN(e, t, n) { n === "" ? e.removeAttribute(t, "class") : e.setAttribute(t, "class", n); }
function _m(e, t, n) { let { mergedAttrs: o, classes: r, styles: i } = n; o !== null && GT(e, t, o), r !== null && BN(e, t, r), i !== null && jN(e, t, i); }
function UN(e) { let t = g(); e.src = "", e.srcdoc = io(""), Sr(t[T], e); }
var Q = (function (e) { return e[e.NONE = 0] = "NONE", e[e.HTML = 1] = "HTML", e[e.STYLE = 2] = "STYLE", e[e.SCRIPT = 3] = "SCRIPT", e[e.URL = 4] = "URL", e[e.RESOURCE_URL = 5] = "RESOURCE_URL", e[e.ATTRIBUTE_NO_BINDING = 6] = "ATTRIBUTE_NO_BINDING", e; })(Q || {}), Fi, nh = "svg", $N = "math";
function zN() { return Fi || (Fi = {}, wt(Q.HTML, void 0, [["iframe", ["srcdoc"]], ["*", ["innerHTML", "outerHTML"]]]), wt(Q.STYLE, void 0, [["*", ["style"]]]), wt(Q.URL, void 0, [["*", ["formAction"]], ["area", ["href"]], ["a", ["href", "xlink:href"]], ["form", ["action"]], ["img", ["src"]], ["video", ["src"]]]), wt(Q.URL, $N, [["annotation", ["href", "xlink:href"]], ["annotation-xml", ["href", "xlink:href"]], ["maction", ["href", "xlink:href"]], ["malignmark", ["href", "xlink:href"]], ["math", ["href", "xlink:href"]], ["mroot", ["href", "xlink:href"]], ["msqrt", ["href", "xlink:href"]], ["merror", ["href", "xlink:href"]], ["mfrac", ["href", "xlink:href"]], ["mglyph", ["href", "xlink:href"]], ["msub", ["href", "xlink:href"]], ["msup", ["href", "xlink:href"]], ["msubsup", ["href", "xlink:href"]], ["mmultiscripts", ["href", "xlink:href"]], ["mprescripts", ["href", "xlink:href"]], ["mi", ["href", "xlink:href"]], ["mn", ["href", "xlink:href"]], ["mo", ["href", "xlink:href"]], ["mpadded", ["href", "xlink:href"]], ["mphantom", ["href", "xlink:href"]], ["mrow", ["href", "xlink:href"]], ["ms", ["href", "xlink:href"]], ["mspace", ["href", "xlink:href"]], ["mstyle", ["href", "xlink:href"]], ["mtable", ["href", "xlink:href"]], ["mtd", ["href", "xlink:href"]], ["mtr", ["href", "xlink:href"]], ["mtext", ["href", "xlink:href"]], ["mover", ["href", "xlink:href"]], ["munder", ["href", "xlink:href"]], ["munderover", ["href", "xlink:href"]], ["semantics", ["href", "xlink:href"]], ["none", ["href", "xlink:href"]]]), wt(Q.RESOURCE_URL, void 0, [["base", ["href"]], ["embed", ["src"]], ["frame", ["src"]], ["iframe", ["src"]], ["link", ["href"]], ["object", ["codebase", "data"]]]), wt(Q.URL, nh, [["a", ["href", "xlink:href"]]]), wt(Q.ATTRIBUTE_NO_BINDING, nh, [["animate", ["attributeName", "values", "to", "from"]], ["set", ["to", "attributeName"]], ["animateMotion", ["attributeName"]], ["animateTransform", ["attributeName"]]]), wt(Q.ATTRIBUTE_NO_BINDING, void 0, [["unknown", ["attributeName", "values", "to", "from", "sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority"]], ["iframe", ["sandbox", "allow", "allowFullscreen", "referrerPolicy", "csp", "fetchPriority"]]])), Fi; }
function wt(e, t, n) { for (let [o, r] of n) {
    let i = t && o !== "*" && o !== "unknown" ? `:${t}:${o}` : o;
    i = i.toLowerCase();
    for (let s of r)
        Fi[`${i}|${s.toLowerCase()}`] = e;
} }
function ku(e) { let t = br(); return t ? Zp(t.sanitize(Q.HTML, e) || "") : so(e, "HTML") ? Zp(dt(e)) : Tm(Ms(), N(e)); }
function Ou(e) { let t = br(); return t ? t.sanitize(Q.STYLE, e) || "" : so(e, "Style") ? dt(e) : N(e); }
function xu(e) { let t = br(); return t ? t.sanitize(Q.URL, e) || "" : so(e, "URL") ? dt(e) : Ls(N(e)); }
function Fs(e) { let t = br(); if (t)
    return Jp(t.sanitize(Q.RESOURCE_URL, e) || ""); if (so(e, "ResourceURL"))
    return Jp(dt(e)); throw new _(904, !1); }
function Lu(e) { let t = br(); if (t)
    return Kp(t.sanitize(Q.SCRIPT, e) || ""); if (so(e, "Script"))
    return Kp(dt(e)); throw new _(905, !1); }
function Sm(e) { return io(e[0]); }
function bm(e) { return mN(e[0]); }
var GN = { embed: { src: !0 }, frame: { src: !0 }, iframe: { src: !0 }, media: { src: !0 }, base: { href: !0 }, link: { href: !0 }, object: { data: !0, codebase: !0 } };
function WN(e, t) { return GN[e.toLowerCase()]?.[t.toLowerCase()] === !0 ? Fs : xu; }
function Am(e, t, n) { return WN(t, n)(e); }
function br() { let e = g(); return e && e[$e].sanitizer; }
var _i = new Set(["href", "xlink:href"]), qN = { iframe: { sandbox: !0, allow: !0, allowfullscreen: !0, referrerpolicy: !0, csp: !0, fetchpriority: !0 }, ":svg:animate": { attributename: !0, to: _i, values: _i, from: _i }, ":svg:set": { attributename: !0, to: _i }, ":svg:animatemotion": { attributename: !0 }, ":svg:animatetransform": { attributename: !0 } };
function Pu(e, t, n) { let o = t.toLowerCase(), r = n.toLowerCase(), s = te() === -1 ? null : Ce(); if (s && s.type !== 2)
    return e; let a = o[0] !== ":" && s?.namespace ? `:${s.namespace}:${o}` : o, c = qN[a]?.[r]; if (!c)
    return e; let l = g(); if (s && o === "iframe") {
    let f = ie(s, l);
    UN(f);
} let u = t[0] === ":" ? t.split(":").pop() : t; if (typeof c != "boolean") {
    if (!s)
        throw new _(-910, !1);
    let p = ie(s, l).getAttribute("attributeName");
    if (p && c.has(p.toLowerCase()))
        throw new _(-910, !1);
    return e;
} let d = !1; throw new _(-910, d); }
function QN() { return nt([]); }
function Rm(e) { return e.ownerDocument.defaultView; }
function km(e) { return e.ownerDocument; }
function Fu(e) { return e.ownerDocument.body; }
var YN = "\uFFFD";
function Rn(e) { return e instanceof Function ? e() : e; }
function ZN(e, t, n) { let o = e.length; for (;;) {
    let r = e.indexOf(t, n);
    if (r === -1)
        return r;
    if (r === 0 || e.charCodeAt(r - 1) <= 32) {
        let i = t.length;
        if (r + i === o || e.charCodeAt(r + i) <= 32)
            return r;
    }
    n = r + 1;
} }
var Om = "ng-template";
function KN(e, t, n, o) { let r = 0; if (o) {
    for (; r < t.length && typeof t[r] == "string"; r += 2)
        if (t[r] === "class" && ZN(t[r + 1].toLowerCase(), n, 0) !== -1)
            return !0;
}
else if (Hu(e))
    return !1; if (r = t.indexOf(1, r), r > -1) {
    let i;
    for (; ++r < t.length && typeof (i = t[r]) == "string";)
        if (i.toLowerCase() === n)
            return !0;
} return !1; }
function Hu(e) { return e.type === 4 && e.value !== Om; }
function JN(e, t, n) { let o = e.type === 4 && !n ? Om : e.value; return t === o; }
function XN(e, t, n) { let o = 4, r = e.attrs, i = r !== null ? nw(r) : 0, s = !1; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "number") {
        if (!s && !je(o) && !je(c))
            return !1;
        if (s && je(c))
            continue;
        s = !1, o = c | o & 1;
        continue;
    }
    if (!s)
        if (o & 4) {
            if (o = 2 | o & 1, c !== "" && !JN(e, c, n) || c === "" && t.length === 1) {
                if (je(o))
                    return !1;
                s = !0;
            }
        }
        else if (o & 8) {
            if (r === null || !KN(e, r, c, n)) {
                if (je(o))
                    return !1;
                s = !0;
            }
        }
        else {
            let l = t[++a], u = ew(c, r, Hu(e), n);
            if (u === -1) {
                if (je(o))
                    return !1;
                s = !0;
                continue;
            }
            if (l !== "") {
                let d;
                if (u > i ? d = "" : d = r[u + 1].toLowerCase(), o & 2 && l !== d) {
                    if (je(o))
                        return !1;
                    s = !0;
                }
            }
        }
} return je(o) || s; }
function je(e) { return (e & 1) === 0; }
function ew(e, t, n, o) { if (t === null)
    return -1; let r = 0; if (o || !n) {
    let i = !1;
    for (; r < t.length;) {
        let s = t[r];
        if (s === e)
            return r;
        if (s === 3 || s === 6)
            i = !0;
        else if (s === 1 || s === 2) {
            let a = t[++r];
            for (; typeof a == "string";)
                a = t[++r];
            continue;
        }
        else {
            if (s === 4)
                break;
            if (s === 0) {
                r += 4;
                continue;
            }
        }
        r += i ? 1 : 2;
    }
    return -1;
}
else
    return ow(t, e); }
function xm(e, t, n = !1) { for (let o = 0; o < t.length; o++)
    if (XN(e, t[o], n))
        return !0; return !1; }
function tw(e) { let t = e.attrs; if (t != null) {
    let n = t.indexOf(5);
    if ((n & 1) === 0)
        return t[n + 1];
} return null; }
function nw(e) { for (let t = 0; t < e.length; t++) {
    let n = e[t];
    if (fg(n))
        return t;
} return e.length; }
function ow(e, t) { let n = e.indexOf(4); if (n > -1)
    for (n++; n < e.length;) {
        let o = e[n];
        if (typeof o == "number")
            return -1;
        if (o === t)
            return n;
        n++;
    } return -1; }
function rw(e, t) { e: for (let n = 0; n < t.length; n++) {
    let o = t[n];
    if (e.length === o.length) {
        for (let r = 0; r < e.length; r++)
            if (e[r] !== o[r])
                continue e;
        return !0;
    }
} return !1; }
function oh(e, t) { return e ? ":not(" + t.trim() + ")" : t; }
function iw(e) { let t = e[0], n = 1, o = 2, r = "", i = !1; for (; n < e.length;) {
    let s = e[n];
    if (typeof s == "string")
        if (o & 2) {
            let a = e[++n];
            r += "[" + s + (a.length > 0 ? '="' + a + '"' : "") + "]";
        }
        else
            o & 8 ? r += "." + s : o & 4 && (r += " " + s);
    else
        r !== "" && !je(s) && (t += oh(i, r), r = ""), o = s, i = i || !je(o);
    n++;
} return r !== "" && (t += oh(i, r)), t; }
function sw(e) { return e.map(iw).join(","); }
function aw(e) { let t = [], n = [], o = 1, r = 2; for (; o < e.length;) {
    let i = e[o];
    if (typeof i == "string")
        r === 2 ? i !== "" && t.push(i, e[++o]) : r === 8 && n.push(i);
    else {
        if (!je(r))
            break;
        r = i;
    }
    o++;
} return n.length && t.push(1, ...n), t; }
var P = {};
function Vu(e, t, n, o, r, i, s, a, c, l, u) { let d = E + o, f = d + r, p = cw(d, f), h = typeof l == "function" ? l() : l; return p[m] = { type: e, blueprint: p, template: n, queries: null, viewQuery: a, declTNode: t, data: p.slice().fill(null, d), bindingStartIndex: d, expandoStartIndex: f, hostBindingOpCodes: null, firstCreatePass: !0, firstUpdatePass: !0, staticViewQueries: !1, staticContentQueries: !1, preOrderHooks: null, preOrderCheckHooks: null, contentHooks: null, contentCheckHooks: null, viewHooks: null, viewCheckHooks: null, destroyHooks: null, cleanup: null, contentQueries: null, components: null, directiveRegistry: typeof i == "function" ? i() : i, pipeRegistry: typeof s == "function" ? s() : s, firstChild: null, schemas: c, consts: h, incompleteFirstPass: !1, ssrId: u }; }
function cw(e, t) { let n = []; for (let o = 0; o < t; o++)
    n.push(o < e ? null : P); return n; }
function Lm(e) { let t = e.tView; return t === null || t.incompleteFirstPass ? e.tView = Vu(1, null, e.template, e.decls, e.vars, e.directiveDefs, e.pipeDefs, e.viewQuery, e.schemas, e.consts, e.id) : t; }
function Hs(e, t, n, o, r, i, s, a, c, l, u) { let d = t.blueprint.slice(); return d[j] = r, d[A] = o | 4 | 128 | 8 | 64 | 1024, (l !== null || e && e[A] & 2048) && (d[A] |= 2048), ic(d), d[q] = d[_o] = e, d[H] = n, d[$e] = s || e && e[$e], d[T] = a || e && e[T], d[k] = c || e && e[k] || null, d[ue] = i, d[Se] = pM(), d[ae] = u, d[Xa] = l, d[J] = t.type == 2 ? e[J] : d, d; }
function lw(e, t, n) { let o = ie(t, e), r = Lm(n), i = e[$e].rendererFactory, s = Bu(e, Hs(e, r, null, ju(n), o, t, null, i.createRenderer(o, n), null, null, null)); return e[t.index] = s; }
function ju(e) { let t = 16; return e.signals ? t = 4096 : e.onPush && (t = 64), t; }
function Ar(e, t, n, o) { if (n === 0)
    return -1; let r = t.length; for (let i = 0; i < n; i++)
    t.push(o), e.blueprint.push(o), e.data.push(null); return r; }
function Bu(e, t) { return e[Dt] ? e[wo][le] = t : e[Dt] = t, e[wo] = t, t; }
function Pm(e = 1) { Fm(w(), g(), te() + e, !1); }
function Fm(e, t, n, o) { if (!o)
    if ((t[A] & 3) === 3) {
        let i = e.preOrderCheckHooks;
        i !== null && Oi(t, i, n);
    }
    else {
        let i = e.preOrderHooks;
        i !== null && xi(t, i, 0, n);
    } Ze(n); }
var Vs = (function (e) { return e[e.None = 0] = "None", e[e.SignalBased = 1] = "SignalBased", e[e.HasDecoratorInputTransform = 2] = "HasDecoratorInputTransform", e; })(Vs || {});
function At(e, t, n, o) { let r = L(null); try {
    let [i, s, a] = e.inputs[n], c = null;
    (s & Vs.SignalBased) !== 0 && (c = t[i][tt]), c !== null && c.transformFn !== void 0 ? o = c.transformFn(o) : a !== null && (o = a.call(t, o)), e.setInput !== null ? e.setInput(t, c, o, n, i) : rg(t, c, i, o);
}
finally {
    L(r);
} }
var ts = (function (e) { return e[e.Important = 1] = "Important", e[e.DashCase = 2] = "DashCase", e; })(ts || {}), wl;
function Uu(e, t) { return wl(e, t); }
function uw(e) { wl === void 0 && (wl = e()); }
var Hm = new S("", { factory: () => !1 }), Vm = new S("", { factory: () => dw }), dw = 4e3, fw = !1, hn = (typeof ngServerMode > "u" || !ngServerMode) && typeof document < "u" && typeof document?.documentElement?.getAnimations == "function";
function js(e) { return e[k].get(Hm, fw); }
function pw(e, t, n) { let o = Bn.get(e); if (o) {
    for (let r of t)
        o.classList.push(r);
    for (let r of n)
        o.cleanupFns.push(r);
}
else
    Bn.set(e, { classList: t, cleanupFns: n }); }
function $u(e) { let t = Bn.get(e); if (t) {
    for (let n of t.cleanupFns)
        n();
    Bn.delete(e);
} en.delete(e); }
var hw = () => { }, Bn = new WeakMap, en = new WeakMap, tr = new WeakMap, jo = new WeakSet;
function _l(e, t) { let n = tr.get(e); if (n && n.length > 0) {
    let o = n.findIndex(r => r === t);
    o > -1 && n.splice(o, 1);
} n?.length === 0 && tr.delete(e); }
function gw(e, t) { let n = tr.get(e); if (!n || n.length === 0)
    return; let o = t.parentNode, r = t.previousSibling; for (let i = n.length - 1; i >= 0; i--) {
    let s = n[i], a = s.parentNode;
    s === t ? (n.splice(i, 1), jo.add(s), s.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } }))) : (r && s === r || a && o && a !== o) && (n.splice(i, 1), s.dispatchEvent(new CustomEvent("animationend", { detail: { cancel: !0 } })), s.parentNode?.removeChild(s));
} }
function zu(e, t) { let n = tr.get(e); n ? n.includes(t) || n.push(t) : tr.set(e, [t]); }
function ns(e) { let t = e[Ge] ??= {}; return t.enter ??= new Map; }
function on(e) { let t = e[Ge] ??= {}; return t.leave ??= new Map; }
function jm(e) { let t = typeof e == "function" ? e() : e, n = Array.isArray(t) ? t : null; return typeof t == "string" && (n = t.trim().split(/\s+/).filter(o => o)), n; }
function mw(e, t) { if (!hn)
    return; let n = Bn.get(e); if (n && n.classList.length > 0 && yw(e, n.classList))
    for (let o of n.classList)
        t.removeClass(e, o); $u(e); }
function yw(e, t) { for (let n of t)
    if (e.classList.contains(n))
        return !0; return !1; }
function nr(e) { return e.composedPath ? e.composedPath()[0] : e.target; }
function Gu(e, t) { let n = en.get(t); return n === void 0 ? !0 : t === nr(e) && (n.animationName !== void 0 && e.animationName === n.animationName || n.propertyName !== void 0 && (n.propertyName === "all" || e.propertyName === n.propertyName)); }
function Bs(e, t, n) { let o = e.get(t.index) ?? { animateFns: [] }; o.animateFns.push(n), e.set(t.index, o); }
function Sl(e, t) { if (e)
    for (let n of e)
        n(); for (let n of t)
    n(); }
function bl(e, t) { let n = on(e).get(t.index); n && (n.resolvers = void 0); }
function Si(e, t, n, o, r) { _l(t, n), Sl(o, r), bl(e, t); }
function os(e) { if (!e)
    return 0; let t = e.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(e) * t; }
function Jt(e, t) { return e.getPropertyValue(t).split(",").map(o => o.trim()); }
function vw(e) { let t = Jt(e, "transition-property"), n = Jt(e, "transition-duration"), o = Jt(e, "transition-delay"), r = { propertyName: "", duration: 0, animationName: void 0 }; for (let i = 0; i < t.length; i++) {
    let s = os(o[i]) + os(n[i]);
    s > r.duration && (r.propertyName = t[i], r.duration = s);
} return r; }
function Ew(e) { let t = Jt(e, "animation-name"), n = Jt(e, "animation-delay"), o = Jt(e, "animation-duration"), r = Jt(e, "animation-iteration-count"), i = { animationName: "", propertyName: void 0, duration: 0 }; for (let s = 0; s < t.length; s++) {
    let a = os(n[s]) + os(o[s]), c = r[s];
    a > i.duration && c !== "infinite" && (i.animationName = t[s], i.duration = a);
} return i; }
function Bm(e, t) { return e !== void 0 && e.duration > t.duration; }
function Um(e) { return (e.animationName != null || e.propertyName != null) && e.duration > 0; }
function Iw(e, t) { let n = getComputedStyle(e), o = Ew(n), r = vw(n), i = o.duration > r.duration ? o : r; Bm(t.get(e), i) || Um(i) && t.set(e, i); }
function $m(e, t, n) { if (!n)
    return; let o = e.getAnimations(); return o.length === 0 ? Iw(e, t) : Dw(e, t, o); }
function Dw(e, t, n) { let o = { animationName: void 0, propertyName: void 0, duration: 0 }; for (let r of n) {
    let i = r.effect?.getTiming();
    if (i?.iterations === 1 / 0)
        continue;
    let s = typeof i?.duration == "number" ? i.duration : 0, a = (i?.delay ?? 0) + s, c = r.playbackRate;
    c !== void 0 && c !== 0 && c !== 1 && (a /= Math.abs(c));
    let l, u;
    r.animationName ? u = r.animationName : l = r.transitionProperty, a >= o.duration && (o = { animationName: u, propertyName: l, duration: a });
} Bm(t.get(e), o) || Um(o) && t.set(e, o); }
var rn = new Set, Us = (function (e) { return e[e.CHANGE_DETECTION = 0] = "CHANGE_DETECTION", e[e.AFTER_NEXT_RENDER = 1] = "AFTER_NEXT_RENDER", e; })(Us || {}), gn = new S(""), rh = new Set;
function Y(e) { rh.has(e) || (rh.add(e), performance?.mark?.("mark_feature_usage", { detail: { feature: e } })); }
var $s = (() => { class e {
    impl = null;
    execute() { this.impl?.execute(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), Wu = [0, 1, 2, 3], qu = (() => { class e {
    ngZone = I(U);
    scheduler = I(Nt);
    errorHandler = I(bc, { optional: !0 });
    sequences = new Set;
    deferredRegistrations = new Set;
    executing = !1;
    constructor() { I(gn, { optional: !0 }); }
    execute() { let n = this.sequences.size > 0; n && x(R.AfterRenderHooksStart), this.executing = !0; for (let o of Wu)
        for (let r of this.sequences)
            if (!(r.erroredOrDestroyed || !r.hooks[o]))
                try {
                    r.pipelinedValue = this.ngZone.runOutsideAngular(() => this.maybeTrace(() => { let i = r.hooks[o]; return i(r.pipelinedValue); }, r.snapshot));
                }
                catch (i) {
                    r.erroredOrDestroyed = !0, this.errorHandler?.handleError(i);
                } this.executing = !1; for (let o of this.sequences)
        o.afterRun(), o.once && (this.sequences.delete(o), o.destroy()); for (let o of this.deferredRegistrations)
        this.sequences.add(o); this.deferredRegistrations.size > 0 && this.scheduler.notify(7), this.deferredRegistrations.clear(), n && x(R.AfterRenderHooksEnd); }
    register(n) { let { view: o } = n; o !== void 0 ? ((o[jt] ??= []).push(n), fi(o), o[A] |= 8192) : this.executing ? this.deferredRegistrations.add(n) : this.addSequence(n); }
    addSequence(n) { this.sequences.add(n), this.scheduler.notify(7); }
    unregister(n) { this.executing && this.sequences.has(n) ? (n.erroredOrDestroyed = !0, n.pipelinedValue = void 0, n.once = !0) : (this.sequences.delete(n), this.deferredRegistrations.delete(n)); }
    maybeTrace(n, o) { return o ? o.run(Us.AFTER_NEXT_RENDER, n) : n(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), or = class {
    impl;
    hooks;
    view;
    once;
    snapshot;
    erroredOrDestroyed = !1;
    pipelinedValue = void 0;
    unregisterOnDestroy;
    constructor(t, n, o, r, i, s = null) { this.impl = t, this.hooks = n, this.view = o, this.once = r, this.snapshot = s, this.unregisterOnDestroy = i?.onDestroy(() => this.destroy()); }
    afterRun() { this.erroredOrDestroyed = !1, this.pipelinedValue = void 0, this.snapshot?.dispose(), this.snapshot = null; }
    destroy() { this.impl.unregister(this), this.unregisterOnDestroy?.(); let t = this.view?.[jt]; t && (this.view[jt] = t.filter(n => n !== this)); }
};
function zm(e, t) { let n = t?.injector ?? I(Te); return typeof ngServerMode < "u" && ngServerMode ? zs : (Y("NgAfterRender"), Gm(e, n, t, !1)); }
function Qu(e, t) { let n = t?.injector ?? I(Te); return typeof ngServerMode < "u" && ngServerMode ? zs : (Y("NgAfterNextRender"), Gm(e, n, t, !0)); }
function Cw(e) { return e instanceof Function ? [void 0, void 0, e, void 0] : [e.earlyRead, e.write, e.mixedReadWrite, e.read]; }
function Gm(e, t, n, o) { let r = t.get($s); r.impl ??= t.get(qu); let i = t.get(gn, null, { optional: !0 }), s = n?.manualCleanup !== !0 ? t.get(Po) : null, a = t.get(Ii, null, { optional: !0 }), c = new or(r.impl, Cw(e), a?.view, o, s, i?.snapshot(null)); return r.impl.register(c), c; }
var zs = { destroy() { } }, Gs = new S("", { factory: () => ({ queue: new Set, isScheduled: !1, scheduler: null, injector: I(It) }) });
function Wm(e, t, n) { let o = e.get(Gs); if (Array.isArray(t))
    for (let r of t)
        o.queue.add(r), n?.detachedLeaveAnimationFns?.push(r);
else
    o.queue.add(t), n?.detachedLeaveAnimationFns?.push(t); o.scheduler && o.scheduler(e); }
function Tw(e, t) { let n = e.get(Gs); if (t.detachedLeaveAnimationFns) {
    for (let o of t.detachedLeaveAnimationFns)
        n.queue.delete(o);
    t.detachedLeaveAnimationFns = void 0;
} }
function Mw(e) { let t = e.get(Gs); t.isScheduled || (Qu(() => { t.isScheduled = !1; for (let n of t.queue)
    n(); t.queue.clear(); }, { injector: t.injector }), t.isScheduled = !0); }
function Ws(e) { let t = e.get(Gs); t.scheduler = Mw, t.scheduler(e); }
function Yu(e, t) { for (let [n, o] of t)
    Wm(e, o.animateFns); }
function ih(e, t, n, o) { let r = e?.[Ge]?.enter; t !== null && r && r.has(n.index) && Yu(o, r); }
function kn(e, t, n, o, r, i, s, a) { if (r != null) {
    let c, l = !1;
    ee(r) ? c = r : re(r) && (l = !0, r = r[j]);
    let u = O(r);
    e === 0 && o !== null ? (ih(a, o, i, n), s == null ? Nm(t, o, u) : nn(t, o, u, s || null, !0)) : e === 1 && o !== null ? (ih(a, o, i, n), nn(t, o, u, s || null, !0), gw(i, u)) : e === 2 ? (a?.[Ge]?.leave?.has(i.index) && zu(i, u), jo.delete(u), sh(a, i, n, d => { if (jo.has(u)) {
        jo.delete(u);
        return;
    } Sr(t, u, l, d); })) : e === 3 && (jo.delete(u), sh(a, i, n, () => { t.destroyNode(u); })), c != null && Rw(t, e, n, c, i, o, s);
} }
function qm(e, t) { Qm(e, t), t[j] = null, t[ue] = null; }
function Nw(e, t, n, o, r, i) { o[j] = r, o[ue] = t, qs(e, o, n, 1, r, i); }
function Qm(e, t) { t[$e].changeDetectionScheduler?.notify(9), qs(e, t, t[T], 2, null, null); }
function ww(e) { let t = e[Dt]; if (!t)
    return Bc(e[m], e); for (; t;) {
    let n = null;
    if (re(t))
        n = t[Dt];
    else {
        let o = t[V];
        o && (n = o);
    }
    if (!n) {
        for (; t && !t[le] && t !== e;)
            re(t) && Bc(t[m], t), t = t[q];
        t === null && (t = e), re(t) && Bc(t[m], t), n = t && t[le];
    }
    t = n;
} }
function Zu(e, t) { let n = e[Bt], o = n.indexOf(t); n.splice(o, 1); }
function Rr(e, t) { if (Tt(t))
    return; let n = t[T]; n.destroyNode && qs(e, t, n, 3, null, null), ww(t); }
function Bc(e, t) { if (Tt(t))
    return; let n = L(null); try {
    t[A] &= -129, t[A] |= 256, t[be] && Io(t[be]), bw(e, t), Sw(e, t), t[m].type === 1 && t[T].destroy();
    let o = t[Ct];
    if (o !== null && ee(t[q])) {
        o !== t[q] && Zu(o, t);
        let r = t[ze];
        r !== null && r.detachView(e);
    }
    cl(t);
}
finally {
    L(n);
} }
function sh(e, t, n, o) { let r = e?.[Ge]; if (r == null || r.leave == null || !r.leave.has(t.index))
    return o(!1); e && rn.add(e[Se]), Wm(n, () => { if (r.leave && r.leave.has(t.index)) {
    let s = r.leave.get(t.index), a = [];
    if (s) {
        for (let c = 0; c < s.animateFns.length; c++) {
            let l = s.animateFns[c], { promise: u } = l();
            a.push(u);
        }
        r.detachedLeaveAnimationFns = void 0;
    }
    r.running = Promise.allSettled(a), _w(e, o);
}
else
    e && rn.delete(e[Se]), o(!1); }, r); }
function _w(e, t) { let n = e[Ge]?.running; if (n) {
    n.then(() => { e[Ge].running = void 0, rn.delete(e[Se]), t(!0); });
    return;
} t(!1); }
function Sw(e, t) { let n = e.cleanup, o = t[Vt]; if (n !== null)
    for (let s = 0; s < n.length - 1; s += 2)
        if (typeof n[s] == "string") {
            let a = n[s + 3];
            a >= 0 ? o[a]() : o[-a].unsubscribe(), s += 2;
        }
        else {
            let a = o[n[s + 1]];
            n[s].call(a);
        } o !== null && (t[Vt] = null); let r = t[ec]; if (r !== null) {
    t[ec] = null;
    for (let s = 0; s < r.length; s++) {
        let a = r[s];
        a();
    }
} let i = t[So]; if (i !== null) {
    t[So] = null;
    for (let s of i)
        s.destroy();
} }
function bw(e, t) { let n; if (e != null && (n = e.destroyHooks) != null)
    for (let o = 0; o < n.length; o += 2) {
        let r = t[n[o]];
        if (!(r instanceof tn)) {
            let i = n[o + 1];
            if (Array.isArray(i))
                for (let s = 0; s < i.length; s += 2) {
                    let a = r[i[s]], c = i[s + 1];
                    x(R.LifecycleHookStart, a, c);
                    try {
                        c.call(a);
                    }
                    finally {
                        x(R.LifecycleHookEnd, a, c);
                    }
                }
            else {
                x(R.LifecycleHookStart, r, i);
                try {
                    i.call(r);
                }
                finally {
                    x(R.LifecycleHookEnd, r, i);
                }
            }
        }
    } }
function Ku(e, t, n) { return Ym(e, t.parent, n); }
function Ym(e, t, n) { let o = t; for (; o !== null && o.type & 168;)
    t = o, o = t.parent; if (o === null)
    return n[j]; if (me(o)) {
    let { encapsulation: r } = e.data[o.directiveStart + o.componentOffset];
    if (r === ke.None || r === ke.Emulated)
        return null;
} return ie(o, n); }
function Zm(e, t, n) { return Jm(e, t, n); }
function Km(e, t, n) { return e.type & 40 ? ie(e, n) : null; }
var Jm = Km, Al;
function Xm(e, t) { Jm = e, Al = t; }
function Ju(e, t, n, o) { let r = Ku(e, o, t), i = t[T], s = o.parent || t[ue], a = Zm(s, o, t); if (r != null)
    if (Array.isArray(n))
        for (let c = 0; c < n.length; c++)
            th(i, r, n[c], a, !1);
    else
        th(i, r, n, a, !1); Al !== void 0 && Al(i, o, t, n, r); }
function Xt(e, t) { if (t !== null) {
    let n = t.type;
    if (n & 3)
        return ie(t, e);
    if (n & 4)
        return Rl(-1, e[t.index]);
    if (n & 8) {
        let o = t.child;
        if (o !== null)
            return Xt(e, o);
        {
            let r = e[t.index];
            return ee(r) ? Rl(-1, r) : O(r);
        }
    }
    else {
        if (n & 128)
            return Xt(e, t.next);
        if (n & 32)
            return Uu(t, e)() || O(e[t.index]);
        {
            let o = ey(e, t);
            if (o !== null) {
                if (Array.isArray(o))
                    return o[0];
                let r = zt(e[J]);
                return Xt(r, o);
            }
            else
                return Xt(e, t.next);
        }
    }
} return null; }
function ey(e, t) { if (t !== null) {
    let o = e[J][ue], r = t.projection;
    return o.projection[r];
} return null; }
function Rl(e, t) { let n = V + e + 1; if (n < t.length) {
    let o = t[n], r = o[m].firstChild;
    if (r !== null)
        return Xt(o, r);
} return t[He]; }
function Xu(e, t, n, o, r, i, s) { for (; n != null;) {
    let a = o[k];
    if (n.type === 128) {
        n = n.next;
        continue;
    }
    let c = o[n.index], l = n.type;
    if (s && t === 0 && (c && Re(O(c), o), n.flags |= 2), !ro(n))
        if (l & 8)
            Xu(e, t, n.child, o, r, i, !1), kn(t, e, a, r, c, n, i, o);
        else if (l & 32) {
            let u = Uu(n, o), d;
            for (; d = u();)
                kn(t, e, a, r, d, n, i, o);
            kn(t, e, a, r, c, n, i, o);
        }
        else
            l & 16 ? ty(e, t, o, n, r, i) : kn(t, e, a, r, c, n, i, o);
    n = s ? n.projectionNext : n.next;
} }
function qs(e, t, n, o, r, i) { Xu(n, o, e.firstChild, t, r, i, !1); }
function Aw(e, t, n) { let o = t[T], r = Ku(e, n, t), i = n.parent || t[ue], s = Zm(i, n, t); ty(o, 0, t, n, r, s); }
function ty(e, t, n, o, r, i) { let s = n[J], c = s[ue].projection[o.projection]; if (Array.isArray(c))
    for (let l = 0; l < c.length; l++) {
        let u = c[l];
        kn(t, e, n[k], r, u, o, i, n);
    }
else {
    let l = c, u = s[q];
    Xo(o) && (l.flags |= 128), Xu(e, t, l, u, r, i, !0);
} }
function Rw(e, t, n, o, r, i, s) { let a = o[He], c = O(o); a !== c && kn(t, e, n, i, a, r, s); for (let l = V; l < o.length; l++) {
    let u = o[l];
    qs(u[m], u, e, t, i, a);
} }
function kw(e, t, n, o, r) { if (t)
    r ? e.addClass(n, o) : e.removeClass(n, o);
else {
    let i = o.indexOf("-") === -1 ? void 0 : ts.DashCase;
    r == null ? e.removeStyle(n, o, i) : (typeof r == "string" && r.endsWith("!important") && (r = r.slice(0, -10), i |= ts.Important), e.setStyle(n, o, r, i));
} }
function ny(e, t, n, o, r) { let i = te(), s = o & 2; try {
    Ze(-1), s && t.length > E && Fm(e, t, E, !1);
    let a = s ? R.TemplateUpdateStart : R.TemplateCreateStart;
    x(a, r, n), n(o, r);
}
finally {
    Ze(i);
    let a = s ? R.TemplateUpdateEnd : R.TemplateCreateEnd;
    x(a, r, n);
} }
function Qs(e, t, n) { Fw(e, t, n), (n.flags & 64) === 64 && Hw(e, t, n); }
function ao(e, t, n = ie) { let o = t.localNames; if (o !== null) {
    let r = t.index + 1;
    for (let i = 0; i < o.length; i += 2) {
        let s = o[i + 1], a = s === -1 ? n(t, e) : e[s];
        e[r++] = a;
    }
} }
function Ow(e, t, n, o) { let i = o.get(mu, jg) || n === ke.ShadowDom || n === ke.ExperimentalIsolatedShadowDom, s = e.selectRootElement(t, i); if (s.tagName.toLowerCase() === "script")
    throw new _(905, !1); return xw(s), s; }
function xw(e) { oy(e); }
var oy = () => null;
function Lw(e) { wg(e) ? wm(e) : ZM(e); }
function ry() { oy = Lw; }
function Pw(e) { return e === "class" ? "className" : e === "for" ? "htmlFor" : e === "formaction" ? "formAction" : e === "innerHtml" ? "innerHTML" : e === "readonly" ? "readOnly" : e === "tabindex" ? "tabIndex" : e; }
function ed(e, t, n, o, r, i) { let s = t[m]; if (Js(e, s, t, n, o)) {
    me(e) && iy(t, e.index);
    return;
} e.type & 3 && (n = Pw(n)), td(e, t, n, o, r, i); }
function td(e, t, n, o, r, i) { if (e.type & 3) {
    let s = ie(e, t);
    o = i != null ? i(o, e.value || "", n) : o, r.setProperty(s, n, o);
}
else
    e.type & 12; }
function iy(e, t) { let n = pe(t, e); n[A] & 16 || (n[A] |= 64); }
function Fw(e, t, n) { let o = n.directiveStart, r = n.directiveEnd; me(n) && lw(t, n, e.data[o + n.componentOffset]), e.firstCreatePass || Yi(n, t); let i = n.initialInputs; for (let s = o; s < r; s++) {
    let a = e.data[s], c = Jo(t, e, s, n);
    if (Re(c, t), i !== null && Bw(t, s - o, c, a, n, i), Ae(a)) {
        let l = pe(n.index, t);
        l[H] = Jo(t, e, s, n);
    }
} }
function Hw(e, t, n) { let o = n.directiveStart, r = n.directiveEnd, i = n.index, s = wp(); try {
    Ze(i);
    for (let a = o; a < r; a++) {
        let c = e.data[a], l = t[a];
        Dc(a), (c.hostBindings !== null || c.hostVars !== 0 || c.hostAttrs !== null) && Vw(c, l);
    }
}
finally {
    Ze(-1), Dc(s);
} }
function Vw(e, t) { e.hostBindings !== null && e.hostBindings(1, t); }
function nd(e, t) { let n = e.directiveRegistry, o = null; if (n)
    for (let r = 0; r < n.length; r++) {
        let i = n[r];
        xm(t, i.selectors, !1) && (o ??= [], Ae(i) ? o.unshift(i) : o.push(i));
    } return o; }
function jw(e, t, n, o, r, i) { let s = ie(e, t); Ys(t[T], s, i, e.value, n, o, r); }
function Ys(e, t, n, o, r, i, s) { if (i == null)
    e.removeAttribute(t, r, n);
else {
    let a = s == null ? N(i) : s(i, o || "", r);
    e.setAttribute(t, r, a, n);
} }
function Bw(e, t, n, o, r, i) { let s = i[t]; if (s !== null)
    for (let a = 0; a < s.length; a += 2) {
        let c = s[a], l = s[a + 1];
        At(o, n, c, l);
    } }
function Zs(e, t, n, o, r) { let i = E + n, s = t[m], a = r(s, t, e, o, n); t[i] = a, qe(e, !0); let c = e.type === 2; return c ? (_m(t[T], a, e), (Ip() === 0 || Cn(e)) && Re(a, t), Dp()) : Re(a, t), Lo() && (!c || !ro(e)) && Ju(s, t, a, e), e; }
function Ks(e) { let t = e; return hc() ? gc() : (t = t.parent, qe(t, !1)), t; }
function sy(e, t, n) { return (e === null || Ae(e)) && (n = Ao(n[t.index])), n[T]; }
function od(e, t) { let n = e[k]; if (!n)
    return; let o; try {
    o = n.get(qt, null);
}
catch {
    o = null;
} o?.(t); }
function Js(e, t, n, o, r) { let i = e.inputs?.[o], s = e.hostDirectiveInputs?.[o], a = !1; if (s)
    for (let c = 0; c < s.length; c += 2) {
        let l = s[c], u = s[c + 1], d = t.data[l];
        At(d, n[l], u, r), a = !0;
    } if (i)
    for (let c of i) {
        let l = n[c], u = t.data[c];
        At(u, l, o, r), a = !0;
    } return a; }
function Uw(e, t, n, o, r, i) { let s = null, a = null, c = null, l = !1, u = e.directiveToIndex.get(o.type); if (typeof u == "number" ? s = u : [s, a, c] = u, a !== null && c !== null && e.hostDirectiveInputs?.hasOwnProperty(r)) {
    let d = e.hostDirectiveInputs[r];
    for (let f = 0; f < d.length; f += 2) {
        let p = d[f];
        if (p >= a && p <= c) {
            let h = t.data[p], y = d[f + 1];
            At(h, n[p], y, i), l = !0;
        }
        else if (p > c)
            break;
    }
} return s !== null && o.inputs.hasOwnProperty(r) && (At(o, n[s], r, i), l = !0), l; }
function $w(e, t) { let n = pe(t, e), o = n[m]; zw(o, n); let r = n[j]; r !== null && n[ae] === null && (n[ae] = tm(r, n[k])), x(R.ComponentStart); try {
    Xs(o, n, n[H]);
}
finally {
    x(R.ComponentEnd, n[H]);
} }
function zw(e, t) { for (let n = t.length; n < e.blueprint.length; n++)
    t.push(e.blueprint[n]); }
function Xs(e, t, n) { yi(t); try {
    let o = e.viewQuery;
    o !== null && hl(1, o, n);
    let r = e.template;
    r !== null && ny(e, t, r, 1, n), e.firstCreatePass && (e.firstCreatePass = !1), t[ze]?.finishViewCreation(e), e.staticContentQueries && fm(e, t), e.staticViewQueries && hl(2, e.viewQuery, n);
    let i = e.components;
    i !== null && Gw(t, i);
}
catch (o) {
    throw e.firstCreatePass && (e.incompleteFirstPass = !0, e.firstCreatePass = !1), o;
}
finally {
    t[A] &= -5, vi();
} }
function Gw(e, t) { for (let n = 0; n < t.length; n++)
    $w(e, t[n]); }
function co(e, t, n, o) { let r = L(null); try {
    let i = t.tView, a = e[A] & 4096 ? 4096 : 16, c = Hs(e, i, n, a, null, t, null, null, o?.injector ?? null, o?.embeddedViewInjector ?? null, o?.dehydratedView ?? null), l = e[t.index];
    c[Ct] = l;
    let u = e[ze];
    return u !== null && (c[ze] = u.createEmbeddedView(i)), Xs(i, c, n), c;
}
finally {
    L(r);
} }
function sn(e, t) { return !t || t.firstChild === null || Xo(e); }
function Un(e, t, n, o, r = !1) { for (; n !== null;) {
    if (n.type === 128) {
        n = r ? n.projectionNext : n.next;
        continue;
    }
    let i = t[n.index];
    i !== null && o.push(O(i)), ee(i) && ea(i, o);
    let s = n.type;
    if (s & 8)
        Un(e, t, n.child, o);
    else if (s & 32) {
        let a = Uu(n, t), c;
        for (; c = a();)
            o.push(c);
    }
    else if (s & 16) {
        let a = ey(t, n);
        if (Array.isArray(a))
            o.push(...a);
        else {
            let c = zt(t[J]);
            Un(c[m], c, a, o, !0);
        }
    }
    n = r ? n.projectionNext : n.next;
} return o; }
function ea(e, t) { for (let n = V; n < e.length; n++) {
    let o = e[n], r = o[m].firstChild;
    r !== null && Un(o[m], o, r, t);
} e[He] !== e[j] && t.push(e[He]); }
function ay(e) { if (e[jt] !== null) {
    for (let t of e[jt])
        t.impl.addSequence(t);
    e[jt].length = 0;
} }
var cy = [];
function Ww(e) { return e[be] ?? qw(e); }
function qw(e) { let t = cy.pop() ?? Object.create(Yw); return t.lView = e, t; }
function Qw(e) { e.lView[be] !== e && (e.lView = null, cy.push(e)); }
var Yw = et(K({}, Va), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { fi(e.lView); }, consumerOnSignalRead() { this.lView[be] = this; } });
function Zw(e) { let t = e[be] ?? Object.create(Kw); return t.lView = e, t; }
var Kw = et(K({}, Va), { consumerIsAlwaysLive: !0, kind: "template", consumerMarkedDirty: e => { let t = zt(e.lView); for (; t && !ly(t[m]);)
        t = zt(t); t && ui(t); }, consumerOnSignalRead() { this.lView[be] = this; } });
function ly(e) { return e.type !== 2; }
function uy(e) { if (e[So] === null)
    return; let t = !0; for (; t;) {
    let n = !1;
    for (let o of e[So])
        o.dirty && (n = !0, o.zone === null || Zone.current === o.zone ? o.run() : o.zone.run(() => o.run()));
    t = n && !!(e[A] & 8192);
} }
var Jw = 100;
function dy(e, t = 0) { let o = e[$e].rendererFactory, r = !1; r || o.begin?.(); try {
    Xw(e, t);
}
finally {
    r || o.end?.();
} }
function Xw(e, t) { let n = yc(); try {
    vc(!0), kl(e, t);
    let o = 0;
    for (; ko(e);) {
        if (o === Jw)
            throw new _(103, !1);
        o++, kl(e, 1);
    }
}
finally {
    vc(n);
} }
function fy(e, t, n, o) { if (Tt(t))
    return; let r = t[A], i = !1, s = !1; yi(t); let a = !0, c = null, l = null; i || (ly(e) ? (l = Ww(t), c = Eo(l)) : Kf() === null ? (a = !1, l = Zw(t), c = Eo(l)) : t[be] && (Io(t[be]), t[be] = null)); try {
    ic(t), Ec(e.bindingStartIndex), n !== null && ny(e, t, n, 2, o);
    let u = (r & 3) === 3;
    if (!i)
        if (u) {
            let p = e.preOrderCheckHooks;
            p !== null && Oi(t, p, null);
        }
        else {
            let p = e.preOrderHooks;
            p !== null && xi(t, p, 0, null), Pc(t, 0);
        }
    if (s || e_(t), uy(t), py(t, 0), e.contentQueries !== null && fm(e, t), !i)
        if (u) {
            let p = e.contentCheckHooks;
            p !== null && Oi(t, p);
        }
        else {
            let p = e.contentHooks;
            p !== null && xi(t, p, 1), Pc(t, 1);
        }
    n_(e, t);
    let d = e.components;
    d !== null && gy(t, d, 0);
    let f = e.viewQuery;
    if (f !== null && hl(2, f, o), !i)
        if (u) {
            let p = e.viewCheckHooks;
            p !== null && Oi(t, p);
        }
        else {
            let p = e.viewHooks;
            p !== null && xi(t, p, 2), Pc(t, 2);
        }
    if (e.firstUpdatePass === !0 && (e.firstUpdatePass = !1), t[li]) {
        for (let p of t[li])
            p();
        t[li] = null;
    }
    i || (ay(t), t[A] &= -73);
}
catch (u) {
    throw i || fi(t), u;
}
finally {
    l !== null && (qr(l, c), a && Qw(l)), vi();
} }
function py(e, t) { for (let n = Rg(e); n !== null; n = kg(n))
    for (let o = V; o < n.length; o++) {
        let r = n[o];
        hy(r, t);
    } }
function e_(e) { for (let t = Rg(e); t !== null; t = kg(t)) {
    if (!(t[A] & 2))
        continue;
    let n = t[Bt];
    for (let o = 0; o < n.length; o++) {
        let r = n[o];
        ui(r);
    }
} }
function t_(e, t, n) { x(R.ComponentStart); let o = pe(t, e); try {
    hy(o, n);
}
finally {
    x(R.ComponentEnd, o[H]);
} }
function hy(e, t) { hp(e) && kl(e, t); }
function kl(e, t) { let o = e[m], r = e[A], i = e[be], s = !!(t === 0 && r & 16); if (s ||= !!(r & 64 && t === 0), s ||= !!(r & 1024), s ||= !!(i?.dirty && Qr(i)), s ||= !1, i && (i.dirty = !1), e[A] &= -9217, s)
    fy(o, e, o.template, e[H]);
else if (r & 8192) {
    let a = L(null);
    try {
        uy(e), py(e, 1);
        let c = o.components;
        c !== null && gy(e, c, 1), ay(e);
    }
    finally {
        L(a);
    }
} }
function gy(e, t, n) { for (let o = 0; o < t.length; o++)
    t_(e, t[o], n); }
function n_(e, t) { let n = e.hostBindingOpCodes; if (n !== null)
    try {
        for (let o = 0; o < n.length; o++) {
            let r = n[o];
            if (r < 0)
                Ze(~r);
            else {
                let i = r, s = n[++o], a = n[++o];
                Np(s, i);
                let c = t[i];
                x(R.HostBindingsUpdateStart, c);
                try {
                    a(2, c);
                }
                finally {
                    x(R.HostBindingsUpdateEnd, c);
                }
            }
        }
    }
    finally {
        Ze(-1);
    } }
function kr(e, t) { let n = yc() ? 64 : 1088; for (e[$e].changeDetectionScheduler?.notify(t); e;) {
    e[A] |= n;
    let o = zt(e);
    if (We(e) && !o)
        return e;
    e = o;
} return null; }
function my(e, t, n, o) { return [e, !0, 0, t, null, o, null, n, null, null]; }
function yy(e, t) { let n = V + t; if (n < e.length)
    return e[n]; }
function lo(e, t, n, o = !0) { let r = t[m]; if (o_(r, t, e, n), o) {
    let s = Rl(n, e), a = t[T], c = a.parentNode(e[He]);
    c !== null && Nw(r, e[ue], a, t, c, s);
} let i = t[ae]; i !== null && i.firstChild !== null && (i.firstChild = null); }
function rd(e, t) { let n = rr(e, t); return n !== void 0 && Rr(n[m], n), n; }
function rr(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n]; if (o) {
    let r = o[Ct];
    r !== null && r !== e && Zu(r, o), t > 0 && (e[n - 1][le] = o[le]);
    let i = To(e, V + t);
    qm(o[m], o);
    let s = i[ze];
    s !== null && s.detachView(i[m]), o[q] = null, o[le] = null, o[A] &= -129;
} return o; }
function o_(e, t, n, o) { let r = V + o, i = n.length; o > 0 && (n[r - 1][le] = t), o < i - V ? (t[le] = n[r], Ya(n, V + o, t)) : (n.push(t), t[le] = null), t[q] = n; let s = t[Ct]; s !== null && n !== s && vy(s, t); let a = t[ze]; a !== null && a.insertView(e), di(t), t[A] |= 128; }
function vy(e, t) { let n = e[Bt], o = t[q]; if (re(o))
    e[A] |= 2;
else {
    let r = o[q][J];
    t[J] !== r && (e[A] |= 2);
} n === null ? e[Bt] = [t] : n.push(t); }
var kt = class {
    _lView;
    _cdRefInjectingView;
    _appRef = null;
    _attachedToViewContainer = !1;
    exhaustive;
    get rootNodes() { let t = this._lView, n = t[m]; return Un(n, t, n.firstChild, []); }
    constructor(t, n) { this._lView = t, this._cdRefInjectingView = n; }
    get context() { return this._lView[H]; }
    set context(t) { this._lView[H] = t; }
    get destroyed() { return Tt(this._lView); }
    destroy() { if (this._appRef)
        this._appRef.detachView(this);
    else if (this._attachedToViewContainer) {
        let t = this._lView[q];
        if (ee(t)) {
            let n = t[bo], o = n ? n.indexOf(this) : -1;
            o > -1 && (rr(t, o), To(n, o));
        }
        this._attachedToViewContainer = !1;
    } Rr(this._lView[m], this._lView); }
    onDestroy(t) { pi(this._lView, t); }
    markForCheck() { kr(this._cdRefInjectingView || this._lView, 4); }
    detach() { this._lView[A] &= -129; }
    reattach() { di(this._lView), this._lView[A] |= 128; }
    detectChanges() { this._lView[A] |= 1024, dy(this._lView); }
    checkNoChanges() { }
    attachToViewContainerRef() { if (this._appRef)
        throw new _(902, !1); this._attachedToViewContainer = !0; }
    detachFromAppRef() { this._appRef = null; let t = We(this._lView), n = this._lView[Ct]; n !== null && !t && Zu(n, this._lView), Qm(this._lView[m], this._lView); }
    attachToAppRef(t) { if (this._attachedToViewContainer)
        throw new _(902, !1); this._appRef = t; let n = We(this._lView), o = this._lView[Ct]; o !== null && !n && vy(o, this._lView), di(this._lView); }
};
function r_(e) { return ko(e._lView) || !!(e._lView[A] & 64); }
function i_(e) { ui(e._lView); }
var ir = (() => { class e {
    _declarationLView;
    _declarationTContainer;
    elementRef;
    static __NG_ELEMENT_ID__ = s_;
    constructor(n, o, r) { this._declarationLView = n, this._declarationTContainer = o, this.elementRef = r; }
    get ssrId() { return this._declarationTContainer.tView?.ssrId || null; }
    createEmbeddedView(n, o) { return this.createEmbeddedViewImpl(n, o); }
    createEmbeddedViewImpl(n, o, r) { let i = co(this._declarationLView, this._declarationTContainer, n, { embeddedViewInjector: o, dehydratedView: r }); return new kt(i); }
} return e; })();
function s_() { return ta(M(), g()); }
function ta(e, t) { return e.type & 4 ? new ir(t, e, Jn(e, t)) : null; }
var Ol = "<-- AT THIS LOCATION", a_ = "/guide/hydration#third-party-scripts-with-dom-manipulation";
function c_(e) { switch (e) {
    case 4: return "view container";
    case 2: return "element";
    case 8: return "ng-container";
    case 32: return "icu";
    case 64: return "i18n";
    case 16: return "projection";
    case 1: return "text";
    case 128: return "@let";
    default: return "<unknown>";
} }
function l_(e, t) {
    let n = `During serialization, Angular was unable to find an element in the DOM:

`, o = `${p_(e, t, !1)}

`, r = g_();
    throw new _(-502, n + o + r);
}
function Ey(e) {
    let t = "During serialization, Angular detected DOM nodes that were created outside of Angular context and provided as projectable nodes (likely via `ViewContainerRef.createComponent` or `createComponent` APIs). Hydration is not supported for such cases, consider refactoring the code to avoid this pattern or using `ngSkipHydration` on the host element of the component.\n\n", n = `${h_(e)}

`, o = t + n + m_();
    return new _(-503, o);
}
function u_(e) { let t = []; if (e.attrs)
    for (let n = 0; n < e.attrs.length;) {
        let o = e.attrs[n++];
        if (typeof o == "number")
            break;
        let r = e.attrs[n++];
        t.push(`${o}="${rs(r)}"`);
    } return t.join(" "); }
var d_ = new Set(["ngh", "ng-version", "ng-server-context"]);
function f_(e) { let t = []; for (let n = 0; n < e.attributes.length; n++) {
    let o = e.attributes[n];
    d_.has(o.name) || t.push(`${o.name}="${rs(o.value)}"`);
} return t.join(" "); }
function Uc(e, t = "\u2026") { switch (e.type) {
    case 1: return `#text${e.value ? `(${e.value})` : ""}`;
    case 2:
        let o = u_(e), r = e.value.toLowerCase();
        return `<${r}${o ? " " + o : ""}>${t}</${r}>`;
    case 8: return "<!-- ng-container -->";
    case 4: return "<!-- container -->";
    default: return `#node(${c_(e.type)})`;
} }
function Hi(e, t = "\u2026") { let n = e; switch (n.nodeType) {
    case Node.ELEMENT_NODE:
        let o = n.tagName.toLowerCase(), r = f_(n);
        return `<${o}${r ? " " + r : ""}>${t}</${o}>`;
    case Node.TEXT_NODE:
        let i = n.textContent ? rs(n.textContent) : "";
        return `#text${i ? `(${i})` : ""}`;
    case Node.COMMENT_NODE: return `<!-- ${rs(n.textContent ?? "")} -->`;
    default: return `#node(${n.nodeType})`;
} }
function p_(e, t, n) {
    let r = "";
    t.prev ? (r += `  \u2026
`, r += "  " + Uc(t.prev) + `
`) : t.type && t.type & 12 && (r += `  \u2026
`), n ? (r += "  " + Uc(t) + `
`, r += `  <!-- container -->  ${Ol}
`) : r += "  " + Uc(t) + `  ${Ol}
`, r += `  \u2026
`;
    let i = t.type ? Ku(e[m], t, e) : null;
    return i && (r = Hi(i, `
` + r)), r;
}
function h_(e) {
    let n = "", o = e;
    return o.previousSibling && (n += `  \u2026
`, n += "  " + Hi(o.previousSibling) + `
`), n += "  " + Hi(o) + `  ${Ol}
`, e.nextSibling && (n += `  \u2026
`), e.parentNode && (n = Hi(o.parentNode, `
` + n)), n;
}
function g_(e) {
    return `To fix this problem:
  * check ${e ? `the "${e}"` : "corresponding"} component for hydration-related issues
  * check to see if your template has valid HTML structure
  * check if there are any third-party scripts that manipulate the DOM. More info: ${Ua}${a_}
  * or skip hydration by adding the \`ngSkipHydration\` attribute to its host node in a template

`;
}
function m_() {
    return `Note: attributes are only displayed to better represent the DOM but have no effect on hydration mismatches.

`;
}
function y_(e) { return e.replace(/\s+/gm, ""); }
function rs(e, t = 50) { return e ? (e = y_(e), e.length > t ? `${e.substring(0, t - 1)}\u2026` : e) : ""; }
function Iy(e, t, n) { let o = t.insertBeforeIndex, r = Array.isArray(o) ? o[0] : o; return r === null ? Km(e, t, n) : O(n[r]); }
function Dy(e, t, n, o, r) { let i = t.insertBeforeIndex; if (Array.isArray(i)) {
    let s = o, a = null;
    if (t.type & 3 || (a = s, s = r), s !== null && t.componentOffset === -1)
        for (let c = 1; c < i.length; c++) {
            let l = n[i[c]];
            nn(e, s, l, a, !1);
        }
} }
function mn(e, t, n, o, r) { let i = e.data[t]; if (i === null)
    i = id(e, t, n, o, r), Mp() && (i.flags |= 32);
else if (i.type & 64) {
    i.type = n, i.value = o, i.attrs = r;
    let s = Tn();
    i.injectorIndex = s === null ? -1 : s.injectorIndex;
} return qe(i, !0), i; }
function id(e, t, n, o, r) { let i = Tp(), s = hc(), a = s ? i : i && i.parent, c = e.data[t] = E_(e, a, n, t, o, r); return v_(e, c, i, s), c; }
function v_(e, t, n, o) { e.firstChild === null && (e.firstChild = t), n !== null && (o ? n.child == null && t.parent !== null && (n.child = t) : n.next === null && (n.next = t, t.prev = n)); }
function E_(e, t, n, o, r, i) { let s = t ? t.injectorIndex : -1, a = 0; return Oo() && (a |= 128), { type: n, index: o, insertBeforeIndex: null, injectorIndex: s, directiveStart: -1, directiveEnd: -1, directiveStylingLast: -1, componentOffset: -1, controlDirectiveIndex: -1, customControlIndex: -1, propertyBindings: null, flags: a, providerIndexes: 0, value: r, namespace: Ei(), attrs: i, mergedAttrs: null, localNames: null, initialInputs: null, inputs: null, hostDirectiveInputs: null, outputs: null, hostDirectiveOutputs: null, directiveToIndex: null, tView: null, next: null, prev: null, projectionNext: null, child: null, parent: t, projection: null, styles: null, stylesWithoutHost: null, residualStyles: void 0, classes: null, classesWithoutHost: null, residualClasses: void 0, classBindings: 0, styleBindings: 0 }; }
function Cy(e, t) { if (e.push(t), e.length > 1)
    for (let n = e.length - 2; n >= 0; n--) {
        let o = e[n];
        Ty(o) || I_(o, t) && D_(o) === null && C_(o, t.index);
    } }
function Ty(e) { return !(e.type & 64); }
function I_(e, t) { return Ty(t) || e.index > t.index; }
function D_(e) { let t = e.insertBeforeIndex; return Array.isArray(t) ? t[0] : t; }
function C_(e, t) { let n = e.insertBeforeIndex; Array.isArray(n) ? n[0] = t : (Xm(Iy, Dy), e.insertBeforeIndex = t); }
function Uo(e, t) { let n = e.data[t]; return n === null || typeof n == "string" ? null : n.hasOwnProperty("currentCaseLViewIndex") ? n : n.value; }
function T_(e, t, n) { let o = e.data[t]; o === null ? e.data[t] = n : o.value = n; }
function M_(e, t) { let n = e.insertBeforeIndex; n === null ? (Xm(Iy, Dy), n = e.insertBeforeIndex = [null, t]) : (np(Array.isArray(n), !0, "Expecting array here"), n.push(t)); }
function N_(e, t, n) { let o = id(e, n, 64, null, null); return Cy(t, o), o; }
function na(e, t) { let n = t[e.currentCaseLViewIndex]; return n === null ? n : n < 0 ? ~n : n; }
function w_(e) { return e >>> 17; }
function __(e) { return (e & 131070) >>> 1; }
function S_(e, t, n) { return e | t << 17 | n << 1; }
function My(e) { return e === -1; }
function sd(e, t, n) { e.index = 0; let o = na(t, n); o !== null ? e.removes = t.remove[o] : e.removes = F; }
function is(e) { if (e.index < e.removes.length) {
    let t = e.removes[e.index++];
    if (t > 0)
        return e.lView[t];
    {
        e.stack.push(e.index, e.removes);
        let n = ~t, o = e.lView[m].data[n];
        return sd(e, o, e.lView), is(e);
    }
}
else
    return e.stack.length === 0 ? (e.lView = void 0, null) : (e.removes = e.stack.pop(), e.index = e.stack.pop(), is(e)); }
function b_() { let e = { stack: [], index: -1 }; function t(n, o) { for (e.lView = o; e.stack.length;)
    e.stack.pop(); return sd(e, n.value, o), is.bind(null, e); } return t; }
function A_(e, t) { let n = { stack: [], index: -1, lView: t }; return sd(n, e, t), is.bind(null, n); }
var R_ = new RegExp(`^(\\d+)*(${hu}|${pu})*(.*)`);
function k_(e, t) { let n = [e]; for (let o of t) {
    let r = n.length - 1;
    if (r > 0 && n[r - 1] === o) {
        let i = n[r] || 1;
        n[r] = i + 1;
    }
    else
        n.push(o, "");
} return n.join(""); }
function O_(e) { let t = e.match(R_), [n, o, r, i] = t, s = o ? parseInt(o, 10) : r, a = []; for (let [c, l, u] of i.matchAll(/(f|n)(\d*)/g)) {
    let d = parseInt(u, 10) || 1;
    a.push(l, d);
} return [s, ...a]; }
function x_(e) { return !e.prev && e.parent?.type === 8; }
function $c(e) { return e.index - E; }
function uo(e, t) { return !(e.type & 144) && !!t[e.index] && Ny(O(t[e.index])); }
function Ny(e) { return !!e && !e.isConnected; }
function wy(e, t) { let n = e.i18nNodes; if (n)
    return n.get(t); }
function L_(e, t, n) { let r = e.data[Cr]?.[n]; return r ? _y(r, t) : null; }
function Or(e, t, n, o) { let r = $c(o), i = wy(e, r); if (i === void 0) {
    let s = e.data[Cr];
    if (s?.[r])
        i = _y(s[r], n);
    else if (t.firstChild === o)
        i = e.firstChild;
    else {
        let a = o.prev === null, c = o.prev ?? o.parent;
        if (x_(o)) {
            let l = $c(o.parent);
            i = pl(e, l);
        }
        else {
            let l = ie(c, n);
            if (a)
                i = l.firstChild;
            else {
                let u = $c(c), d = pl(e, u);
                if (c.type === 2 && d) {
                    let p = wu(e, u) + 1;
                    i = oa(p, d);
                }
                else
                    i = l.nextSibling;
            }
        }
    }
} return i; }
function oa(e, t) { let n = t; for (let o = 0; o < e; o++)
    n = n.nextSibling; return n; }
function P_(e, t) { let n = e; for (let o = 0; o < t.length; o += 2) {
    let r = t[o], i = t[o + 1];
    for (let s = 0; s < i; s++)
        switch (r) {
            case Hg:
                n = n.firstChild;
                break;
            case Vg:
                n = n.nextSibling;
                break;
        }
} return n; }
function _y(e, t) { let [n, ...o] = O_(e), r; if (n === pu)
    r = t[J][j];
else if (n === hu)
    r = Fu(t[J][j]);
else {
    let i = Number(n);
    r = O(t[i + E]);
} return P_(r, o); }
function xl(e, t) { if (e === t)
    return []; if (e.parentElement == null || t.parentElement == null)
    return null; if (e.parentElement === t.parentElement)
    return F_(e, t); {
    let n = t.parentElement, o = xl(e, n), r = xl(n.firstChild, t);
    return !o || !r ? null : [...o, Hg, ...r];
} }
function F_(e, t) { let n = [], o = null; for (o = e; o != null && o !== t; o = o.nextSibling)
    n.push(Vg); return o == null ? null : n; }
function ah(e, t, n) { let o = xl(e, t); return o === null ? null : k_(n, o); }
function Sy(e, t, n) { let o = e.parent, r, i, s; for (; o !== null && (uo(o, t) || n?.has(o.index));)
    o = o.parent; o === null || !(o.type & 3) ? (r = s = pu, i = t[J][j]) : (r = o.index, i = O(t[r]), s = N(r - E)); let a = O(t[e.index]); if (e.type & 44) {
    let l = Xt(t, e);
    l && (a = l);
} let c = ah(i, a, s); if (c === null && i !== a) {
    let l = i.ownerDocument.body;
    if (c = ah(l, a, hu), c === null)
        throw l_(t, e);
} return c; }
function by(e, t) { let n = e.createNodeIterator(t, NodeFilter.SHOW_COMMENT, { acceptNode: H_ }), o, r = new Map; for (; o = n.nextNode();) {
    let i = "ngh=", s = o?.textContent, a = s?.indexOf(i) ?? -1;
    if (a > -1) {
        let c = s.substring(a + i.length).trim();
        r.set(c, o);
    }
} return r; }
function H_(e) { return e.textContent?.trimStart().startsWith("ngh=") ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }
var Ay = !1, Ry = () => { };
function ad(e) { Ay = e; }
function ra() { return Ay; }
function V_(e, t, n, o) { Ry(e, t, n, o); }
function ky() { Ry = z_; }
function Oy(e) { return e = e ?? I(Te), e.get(yu, !1); }
function xy(e, t) { let n = t.i18nChildren.get(e); return n === void 0 && (n = j_(e), t.i18nChildren.set(e, n)), n; }
function j_(e) { let t = new Set; function n(o) { switch (t.add(o.index), o.kind) {
    case 1:
    case 2: {
        for (let r of o.children)
            n(r);
        break;
    }
    case 3: {
        for (let r of o.cases)
            for (let i of r)
                n(i);
        break;
    }
} } for (let o = E; o < e.bindingStartIndex; o++) {
    let r = e.data[o];
    if (!(!r || !r.ast))
        for (let i of r.ast)
            n(i);
} return t.size === 0 ? null : t; }
function Ly(e, t, n) { if (!n.isI18nHydrationEnabled)
    return null; let o = e[m], r = o.data[t]; if (!r || !r.ast)
    return null; let i = o.data[r.parentTNodeIndex]; if (i && _g(i))
    return null; let s = { caseQueue: [], disconnectedNodes: new Set, disjointNodes: new Set }; return Ll(e, s, n, r.ast), s.caseQueue.length === 0 && s.disconnectedNodes.size === 0 && s.disjointNodes.size === 0 ? null : s; }
function Ll(e, t, n, o) { let r = null; for (let i of o) {
    let s = U_(e, t, n, i);
    s && (B_(r, s) && t.disjointNodes.add(i.index - E), r = s);
} return r; }
function B_(e, t) { return e && e.nextSibling !== t; }
function U_(e, t, n, o) { let r = O(e[o.index]); if (!r || Ny(r))
    return t.disconnectedNodes.add(o.index - E), null; let i = r; switch (o.kind) {
    case 0: {
        _u(n, i);
        break;
    }
    case 1:
    case 2: {
        Ll(e, t, n, o.children);
        break;
    }
    case 3: {
        let s = e[o.currentCaseLViewIndex];
        if (s != null) {
            let a = s < 0 ? ~s : s;
            t.caseQueue.push(a), Ll(e, t, n, o.cases[a]);
        }
        break;
    }
} return $_(e, o); }
function $_(e, t) { let o = e[m].data[t.index]; return Es(o) ? Xt(e, o) : t.kind === 3 ? A_(o, e)() ?? O(e[t.index]) : O(e[t.index]) ?? null; }
function Yt(e, t) { e.currentNode = t; }
function Fo(e, t, n) { let o = n.index - E, { disconnectedNodes: r } = e, i = t.currentNode; return t.isConnected ? (e.i18nNodes.set(o, i), r.delete(o)) : r.add(o), i; }
function zc(e, t) { let n = e.currentNode; for (let o = 0; o < t && n; o++)
    n = n?.nextSibling ?? null; return n; }
function Gc(e, t) { return { currentNode: t, isConnected: e.isConnected }; }
function z_(e, t, n, o) { let r = e[ae]; if (!r || !ra() || n && (_g(n) || Os(r, n.index - E)))
    return; let i = e[m], s = i.data[t]; function a() { if (My(o)) {
    let p = Or(r, i, e, n);
    return n.type & 8 ? p : p.firstChild;
} return r?.firstChild; } let c = a(), l = im(r) ?? new Set, u = r.i18nNodes ??= new Map, d = r.data[_s]?.[t - E] ?? [], f = r.dehydratedIcuData ??= new Map; wn({ hydrationInfo: r, lView: e, i18nNodes: u, disconnectedNodes: l, caseQueue: d, dehydratedIcuData: f }, { currentNode: c, isConnected: !0 }, s.ast), r.disconnectedNodes = l.size === 0 ? null : l; }
function wn(e, t, n) { if (Array.isArray(n)) {
    let o = t;
    for (let r of n) {
        let i = L_(e.hydrationInfo, e.lView, r.index - E);
        i && (o = Gc(t, i)), wn(e, o, r);
    }
}
else {
    if (e.disconnectedNodes.has(n.index - E))
        return;
    switch (n.kind) {
        case 0: {
            let o = Fo(e, t, n);
            Yt(t, o?.nextSibling ?? null);
            break;
        }
        case 1: {
            wn(e, Gc(t, t.currentNode?.firstChild ?? null), n.children);
            let o = Fo(e, t, n);
            Yt(t, o?.nextSibling ?? null);
            break;
        }
        case 2: {
            let o = n.index - E, { hydrationInfo: r } = e, i = om(r, o);
            switch (n.type) {
                case 0: {
                    let s = Fo(e, t, n);
                    if (tN(r, o)) {
                        wn(e, t, n.children);
                        let a = zc(t, 1);
                        Yt(t, a);
                    }
                    else if (wn(e, Gc(t, t.currentNode?.firstChild ?? null), n.children), Yt(t, s?.nextSibling ?? null), i !== null) {
                        let a = zc(t, i + 1);
                        Yt(t, a);
                    }
                    break;
                }
                case 1: {
                    Fo(e, t, n);
                    let s = zc(t, i + 1);
                    Yt(t, s);
                    break;
                }
            }
            break;
        }
        case 3: {
            let o = t.isConnected ? e.caseQueue.shift() : null, r = { currentNode: null, isConnected: !1 };
            for (let s = 0; s < n.cases.length; s++)
                wn(e, s === o ? t : r, n.cases[s]);
            o !== null && e.dehydratedIcuData.set(n.index, { case: o, node: n });
            let i = Fo(e, t, n);
            Yt(t, i?.nextSibling ?? null);
            break;
        }
    }
} }
var Py = () => { };
function G_(e, t, n) { Py(e, t, n); }
function Fy() { Py = W_; }
function W_(e, t, n) { let o = e[ae]?.dehydratedIcuData; o && o.get(t)?.case === n && o.delete(t); }
function q_(e) { let t = e[ae]; if (t) {
    let { i18nNodes: n, dehydratedIcuData: o } = t;
    if (n && o) {
        let r = e[T];
        for (let i of o.values())
            Q_(r, n, i);
    }
    t.i18nNodes = void 0, t.dehydratedIcuData = void 0;
} }
function Q_(e, t, n) { for (let o of n.node.cases[n.case]) {
    let r = t.get(o.index - E);
    r && Sr(e, r, !1);
} }
function ia(e) { let t = e[De] ?? [], o = e[q][T], r = []; for (let i of t)
    i.data[Ss] !== void 0 ? r.push(i) : Hy(i, o); e[De] = r; }
function Y_(e) { let { lContainer: t } = e, n = t[De]; if (n === null)
    return; let r = t[q][T]; for (let i of n)
    Hy(i, r); }
function Hy(e, t) { let n = 0, o = e.firstChild; if (o) {
    let r = e.data[st];
    for (; n < r;) {
        let i = o.nextSibling;
        Sr(t, o, !1), o = i, n++;
    }
} }
function sa(e) { ia(e); let t = e[j]; re(t) && sr(t); for (let n = V; n < e.length; n++)
    sr(e[n]); }
function sr(e) { q_(e); let t = e[m]; for (let n = E; n < t.bindingStartIndex; n++)
    if (ee(e[n])) {
        let o = e[n];
        sa(o);
    }
    else
        re(e[n]) && sr(e[n]); }
function cd(e) { let t = e._views; for (let n of t) {
    let o = Nu(n);
    o !== null && o[j] !== null && (re(o) ? sr(o) : sa(o));
} }
function Z_(e, t, n, o) { e !== null && (n.cleanup(t), sa(e.lContainer), cd(o)); }
function K_(e, t) { let n = []; for (let o of t)
    for (let r = 0; r < (o[Dr] ?? 1); r++) {
        let i = { data: o, firstChild: null };
        o[st] > 0 && (i.firstChild = e, e = oa(o[st], e)), n.push(i);
    } return [e, n]; }
var Vy = () => null, jy = () => null;
function By() { Vy = J_, jy = X_; }
function J_(e, t) { return $y(e, t) ? e[De].shift() : (ia(e), null); }
function ar(e, t) { return Vy(e, t); }
function X_(e, t, n) { if (t.tView.ssrId === null)
    return null; let o = ar(e, t.tView.ssrId); return n[m].firstUpdatePass && o === null && eS(n, t), o; }
function Uy(e, t, n) { return jy(e, t, n); }
function eS(e, t) { let n = t; for (; n;) {
    if (ch(e, n))
        return;
    if ((n.flags & 256) === 256)
        break;
    n = n.prev;
} for (n = t.next; n && (n.flags & 512) === 512;) {
    if (ch(e, n))
        return;
    n = n.next;
} }
function $y(e, t) { let n = e[De]; return !t || n === null || n.length === 0 ? !1 : n[0].data[ws] === t; }
function ch(e, t) { let n = t.tView?.ssrId; if (n == null)
    return !1; let o = e[t.index]; return ee(o) && $y(o, n) ? (ia(o), !0) : !1; }
var zy = class {
}, aa = class {
}, Pl = class {
    resolveComponentFactory(t) { throw new _(917, !1); }
}, xr = class {
    static NULL = new Pl;
}, cr = class {
}, tS = (() => { class e {
    destroyNode = null;
    static __NG_ELEMENT_ID__ = () => nS();
} return e; })();
function nS() { let e = g(), t = M(), n = pe(t.index, e); return (re(n) ? n : e)[T]; }
var Gy = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => null });
} return e; })();
function ld(e) { return e.ngModule !== void 0; }
function Zt(e) { return !!En(e); }
function bi(e) { return !!Ue(e); }
function lh(e) { return !!Ne(e); }
function $o(e) { return !!W(e); }
function oS(e) { return W(e) ? "component" : Ne(e) ? "directive" : Ue(e) ? "pipe" : "type"; }
function rS(e, t) { if (Jr(e) && (e = G(e), !e))
    throw new Error(`Expected forwardRef function, imported from "${we(t)}", to return a standalone entity or NgModule but got "${we(e) || e}".`); if (En(e) == null) {
    let n = W(e) || Ne(e) || Ue(e);
    if (n != null) {
        if (!n.standalone) {
            let o = oS(e);
            throw new Error(`The "${we(e)}" ${o}, imported from "${we(t)}", is not standalone. Does the ${o} have the standalone: false flag?`);
        }
    }
    else
        throw ld(e) ? new Error(`A module with providers was imported from "${we(t)}". Modules with providers are not supported in standalone components imports.`) : new Error(`The "${we(e)}" type, imported from "${we(t)}", must be a standalone component / directive / pipe or an NgModule. Did you forget to add the required @Component / @Directive / @Pipe or @NgModule annotation?`);
} }
var Fl = class {
    ownerNgModule = new WeakMap;
    ngModulesWithSomeUnresolvedDecls = new Set;
    ngModulesScopeCache = new WeakMap;
    standaloneComponentsScopeCache = new WeakMap;
    resolveNgModulesDecls() { if (this.ngModulesWithSomeUnresolvedDecls.size !== 0) {
        for (let t of this.ngModulesWithSomeUnresolvedDecls) {
            let n = En(t);
            if (n?.declarations)
                for (let o of Rn(n.declarations))
                    $o(o) && this.ownerNgModule.set(o, t);
        }
        this.ngModulesWithSomeUnresolvedDecls.clear();
    } }
    getComponentDependencies(t, n) { this.resolveNgModulesDecls(); let o = W(t); if (o === null)
        throw new Error(`Attempting to get component dependencies for a type that is not a component: ${t}`); if (o.standalone) {
        let r = this.getStandaloneComponentScope(t, n);
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes, ...r.compilation.ngModules] };
    }
    else {
        if (!this.ownerNgModule.has(t))
            return { dependencies: [] };
        let r = this.getNgModuleScope(this.ownerNgModule.get(t));
        return r.compilation.isPoisoned ? { dependencies: [] } : { dependencies: [...r.compilation.directives, ...r.compilation.pipes] };
    } }
    registerNgModule(t, n) { if (!Zt(t))
        throw new Error(`Attempting to register a Type which is not NgModule as NgModule: ${t}`); this.ngModulesWithSomeUnresolvedDecls.add(t); }
    clearScopeCacheFor(t) { this.ngModulesScopeCache.delete(t), this.standaloneComponentsScopeCache.delete(t); }
    getNgModuleScope(t) { if (this.ngModulesScopeCache.has(t))
        return this.ngModulesScopeCache.get(t); let n = this.computeNgModuleScope(t); return this.ngModulesScopeCache.set(t, n), n; }
    computeNgModuleScope(t) { let n = ti(t), o = { exported: { directives: new Set, pipes: new Set }, compilation: { directives: new Set, pipes: new Set } }; for (let r of Rn(n.imports))
        if (Zt(r)) {
            let i = this.getNgModuleScope(r);
            _t(i.exported.directives, o.compilation.directives), _t(i.exported.pipes, o.compilation.pipes);
        }
        else if (Co(r))
            if (lh(r) || $o(r))
                o.compilation.directives.add(r);
            else if (bi(r))
                o.compilation.pipes.add(r);
            else
                throw new _(980, "The standalone imported type is neither a component nor a directive nor a pipe");
        else {
            o.compilation.isPoisoned = !0;
            break;
        } if (!o.compilation.isPoisoned)
        for (let r of Rn(n.declarations)) {
            if (Zt(r) || Co(r)) {
                o.compilation.isPoisoned = !0;
                break;
            }
            bi(r) ? o.compilation.pipes.add(r) : o.compilation.directives.add(r);
        } for (let r of Rn(n.exports))
        if (Zt(r)) {
            let i = this.getNgModuleScope(r);
            _t(i.exported.directives, o.exported.directives), _t(i.exported.pipes, o.exported.pipes), _t(i.exported.directives, o.compilation.directives), _t(i.exported.pipes, o.compilation.pipes);
        }
        else
            bi(r) ? o.exported.pipes.add(r) : o.exported.directives.add(r); return o; }
    getStandaloneComponentScope(t, n) { if (this.standaloneComponentsScopeCache.has(t))
        return this.standaloneComponentsScopeCache.get(t); let o = this.computeStandaloneComponentScope(t, n); return this.standaloneComponentsScopeCache.set(t, o), o; }
    computeStandaloneComponentScope(t, n) { let o = { compilation: { directives: new Set([t]), pipes: new Set, ngModules: new Set } }; for (let r of Fe(n ?? [])) {
        let i = G(r);
        try {
            rS(i, t);
        }
        catch {
            return o.compilation.isPoisoned = !0, o;
        }
        if (Zt(i)) {
            o.compilation.ngModules.add(i);
            let s = this.getNgModuleScope(i);
            if (s.exported.isPoisoned)
                return o.compilation.isPoisoned = !0, o;
            _t(s.exported.directives, o.compilation.directives), _t(s.exported.pipes, o.compilation.pipes);
        }
        else if (bi(i))
            o.compilation.pipes.add(i);
        else if (lh(i) || $o(i))
            o.compilation.directives.add(i);
        else
            return o.compilation.isPoisoned = !0, o;
    } return o; }
    isOrphanComponent(t) { let n = W(t); return !n || n.standalone ? !1 : (this.resolveNgModulesDecls(), !this.ownerNgModule.has(t)); }
};
function _t(e, t) { for (let n of e)
    t.add(n); }
var $n = new Fl, Vi = {}, Pn = class {
    injector;
    parentInjector;
    constructor(t, n) { this.injector = t, this.parentInjector = n; }
    get(t, n, o) { let r = this.injector.get(t, Vi, o); return r !== Vi || n === Vi ? r : this.parentInjector.get(t, n, o); }
};
function ss(e, t, n) { let o = n ? e.styles : null, r = n ? e.classes : null, i = 0; if (t !== null)
    for (let s = 0; s < t.length; s++) {
        let a = t[s];
        if (typeof a == "number")
            i = a;
        else if (i == 1)
            r = Kr(r, a);
        else if (i == 2) {
            let c = a, l = t[++s];
            o = Kr(o, c + ": " + l + ";");
        }
    } n ? e.styles = o : e.stylesWithoutHost = o, n ? e.classes = r : e.classesWithoutHost = r; }
function fo(e, t = 0) { let n = g(); if (n === null)
    return Pe(e, t); let o = M(); return Eg(o, n, G(e), t); }
function Wy() { let e = "invalid"; throw new Error(e); }
function qy(e, t, n, o, r) { let i = o === null ? null : { "": -1 }, s = r(e, n); if (s !== null) {
    let a = s, c = null, l = null;
    for (let u of s)
        if (u.resolveHostDirectives !== null) {
            [a, c, l] = u.resolveHostDirectives(s);
            break;
        }
    aS(e, t, n, a, i, c, l);
} i !== null && o !== null && iS(n, o, i); }
function iS(e, t, n) { let o = e.localNames = []; for (let r = 0; r < t.length; r += 2) {
    let i = n[t[r + 1]];
    if (i == null)
        throw new _(-301, !1);
    o.push(t[r], i);
} }
function sS(e, t, n) { t.componentOffset = n, (e.components ??= []).push(t.index); }
function aS(e, t, n, o, r, i, s) { let a = o.length, c = null; for (let f = 0; f < a; f++) {
    let p = o[f];
    c === null && Ae(p) && (c = p, sS(e, n, f)), sl(Yi(n, t), e, p.type);
} pS(n, e.data.length, a), c?.viewProvidersResolver && c.viewProvidersResolver(c); for (let f = 0; f < a; f++) {
    let p = o[f];
    p.providersResolver && p.providersResolver(p);
} let l = !1, u = !1, d = Ar(e, t, a, null); a > 0 && (n.directiveToIndex = new Map); for (let f = 0; f < a; f++) {
    let p = o[f];
    if (n.mergedAttrs = jn(n.mergedAttrs, p.hostAttrs), lS(e, n, t, d, p), fS(d, p, r), s !== null && s.has(p)) {
        let [y, v] = s.get(p);
        n.directiveToIndex.set(p.type, [d, y + n.directiveStart, v + n.directiveStart]);
    }
    else
        (i === null || !i.has(p)) && n.directiveToIndex.set(p.type, d);
    p.contentQueries !== null && (n.flags |= 4), (p.hostBindings !== null || p.hostAttrs !== null || p.hostVars !== 0) && (n.flags |= 64);
    let h = p.type.prototype;
    !l && (h.ngOnChanges || h.ngOnInit || h.ngDoCheck) && ((e.preOrderHooks ??= []).push(n.index), l = !0), !u && (h.ngOnChanges || h.ngDoCheck) && ((e.preOrderCheckHooks ??= []).push(n.index), u = !0), d++;
} cS(e, n, i); }
function cS(e, t, n) { for (let o = t.directiveStart; o < t.directiveEnd; o++) {
    let r = e.data[o];
    if (n === null || !n.has(r))
        uh(0, t, r, o), uh(1, t, r, o), fh(t, o, !1);
    else {
        let i = n.get(r);
        dh(0, t, i, o), dh(1, t, i, o), fh(t, o, !0);
    }
} }
function uh(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s;
        e === 0 ? s = t.inputs ??= {} : s = t.outputs ??= {}, s[i] ??= [], s[i].push(o), Qy(t, i);
    } }
function dh(e, t, n, o) { let r = e === 0 ? n.inputs : n.outputs; for (let i in r)
    if (r.hasOwnProperty(i)) {
        let s = r[i], a;
        e === 0 ? a = t.hostDirectiveInputs ??= {} : a = t.hostDirectiveOutputs ??= {}, a[s] ??= [], a[s].push(o, i), Qy(t, s);
    } }
function Qy(e, t) { t === "class" ? e.flags |= 8 : t === "style" && (e.flags |= 16); }
function fh(e, t, n) { let { attrs: o, inputs: r, hostDirectiveInputs: i } = e; if (o === null || !n && r === null || n && i === null || Hu(e)) {
    e.initialInputs ??= [], e.initialInputs.push(null);
    return;
} let s = null, a = 0; for (; a < o.length;) {
    let c = o[a];
    if (c === 0) {
        a += 4;
        continue;
    }
    else if (c === 5) {
        a += 2;
        continue;
    }
    else if (typeof c == "number")
        break;
    if (!n && r.hasOwnProperty(c)) {
        let l = r[c];
        for (let u of l)
            if (u === t) {
                s ??= [], s.push(c, o[a + 1]);
                break;
            }
    }
    else if (n && i.hasOwnProperty(c)) {
        let l = i[c];
        for (let u = 0; u < l.length; u += 2)
            if (l[u] === t) {
                s ??= [], s.push(l[u + 1], o[a + 1]);
                break;
            }
    }
    a += 2;
} e.initialInputs ??= [], e.initialInputs.push(s); }
function lS(e, t, n, o, r) { e.data[o] = r; let i = r.factory || (r.factory = oi(r.type, !0)), s = new tn(i, Ae(r), fo, null); e.blueprint[o] = s, n[o] = s, uS(e, t, o, Ar(e, n, r.hostVars, P), r); }
function uS(e, t, n, o, r) { let i = r.hostBindings; if (i) {
    let s = e.hostBindingOpCodes;
    s === null && (s = e.hostBindingOpCodes = []);
    let a = ~t.index;
    dS(s) != a && s.push(a), s.push(n, o, i);
} }
function dS(e) { let t = e.length; for (; t > 0;) {
    let n = e[--t];
    if (typeof n == "number" && n < 0)
        return n;
} return 0; }
function fS(e, t, n) { if (n) {
    if (t.exportAs)
        for (let o = 0; o < t.exportAs.length; o++)
            n[t.exportAs[o]] = e;
    Ae(t) && (n[""] = e);
} }
function pS(e, t, n) { e.flags |= 1, e.directiveStart = t, e.directiveEnd = t + n, e.providerIndexes = t; }
function ud(e, t, n, o, r, i, s, a) { let c = t[m], l = c.consts, u = de(l, s), d = mn(c, e, n, o, u); return i && qy(c, t, d, de(l, a), r), d.mergedAttrs = jn(d.mergedAttrs, d.attrs), d.attrs !== null && ss(d, d.attrs, !1), d.mergedAttrs !== null && ss(d, d.mergedAttrs, !0), c.queries !== null && c.queries.elementStart(c, d), d; }
function dd(e, t) { lg(e, t), tc(t) && e.queries.elementEnd(t); }
function Yy(e, t, n, o, r, i) { let s = t.consts, a = de(s, r), c = mn(t, e, n, o, a); if (c.mergedAttrs = jn(c.mergedAttrs, c.attrs), i != null) {
    let l = de(s, i);
    c.localNames = [];
    for (let u = 0; u < l.length; u += 2)
        c.localNames.push(l[u], -1);
} return c.attrs !== null && ss(c, c.attrs, !1), c.mergedAttrs !== null && ss(c, c.mergedAttrs, !0), t.queries !== null && t.queries.elementStart(t, c), c; }
function lr(e) { return ca(e) ? Array.isArray(e) || !(e instanceof Map) && Symbol.iterator in e : !1; }
function hS(e, t, n) { let o = e[Symbol.iterator](), r = t[Symbol.iterator](); for (;;) {
    let i = o.next(), s = r.next();
    if (i.done && s.done)
        return !0;
    if (i.done || s.done || !n(i.value, s.value))
        return !1;
} }
function Zy(e, t) { if (Array.isArray(e))
    for (let n = 0; n < e.length; n++)
        t(e[n]);
else {
    let n = e[Symbol.iterator](), o;
    for (; !(o = n.next()).done;)
        t(o.value);
} }
function ca(e) { return e !== null && (typeof e == "function" || typeof e == "object"); }
function Ky(e, t) { let n = lr(e), o = lr(t); return n && o ? hS(e, t, Ky) : !n && (e && (typeof e == "object" || typeof e == "function")) && !o && (t && (typeof t == "object" || typeof t == "function")) ? !0 : Object.is(e, t); }
function Be(e, t, n) { return e[t] = n; }
function po(e, t) { return e[t]; }
function z(e, t, n) { if (n === P)
    return !1; let o = e[t]; return Object.is(o, n) ? !1 : (e[t] = n, !0); }
function an(e, t, n, o) { let r = z(e, t, n); return z(e, t + 1, o) || r; }
function la(e, t, n, o, r) { let i = an(e, t, n, o); return z(e, t + 2, r) || i; }
function Oe(e, t, n, o, r, i) { let s = an(e, t, n, o); return an(e, t + 2, r, i) || s; }
function Rt(e, t, n) { return function o(r) { let i = o.__ngNativeEl__; i !== void 0 && GM(r, i); let s = me(e) ? pe(e.index, t) : t; kr(s, 5); let a = t[H], c = ph(t, a, n, r), l = o.__ngNextListenerFn__; for (; l;)
    c = ph(t, a, l, r) && c, l = l.__ngNextListenerFn__; return c; }; }
function ph(e, t, n, o) { let r = _n(null); try {
    return x(R.OutputStart, t, n), n(o) !== !1;
}
catch (i) {
    return od(e, i), !1;
}
finally {
    x(R.OutputEnd, t, n), _n(r);
} }
function fd(e, t, n, o, r, i, s, a) { let c = Cn(e), l = !1, u = null; if (!o && c && (u = mS(t, n, i, e.index)), u !== null) {
    let d = u.__ngLastListenerFn__ || u;
    d.__ngNextListenerFn__ = s, u.__ngLastListenerFn__ = s, l = !0;
}
else {
    let d = ie(e, n), f = o ? o(d) : d;
    WM(n, f, i, a), o || (a.__ngNativeEl__ = d);
    let p = r.listen(f, i, a);
    if (!gS(i)) {
        let h = o ? y => o(O(y[e.index])) : e.index;
        Jy(h, t, n, i, a, p, !1);
    }
} return l; }
function gS(e) { return e.startsWith("animation") || e.startsWith("transition"); }
function mS(e, t, n, o) { let r = e.cleanup; if (r != null)
    for (let i = 0; i < r.length - 1; i += 2) {
        let s = r[i];
        if (s === n && r[i + 1] === o) {
            let a = t[Vt], c = r[i + 2];
            return a && a.length > c ? a[c] : null;
        }
        typeof s == "string" && (i += 2);
    } return null; }
function Jy(e, t, n, o, r, i, s) { let a = t.firstCreatePass ? vp(t) : null, c = yp(n), l = c.length; c.push(r, i), a && a.push(o, e, l, (l + 1) * (s ? -1 : 1)); }
function yS(e, t, n, o, r) { let i = Rt(e, t, n), s = vS(e, t, o, r, i); }
function vS(e, t, n, o, r) { let i = null, s = null, a = null, c = !1, l = e.directiveToIndex.get(n.type); if (typeof l == "number" ? i = l : [i, s, a] = l, s !== null && a !== null && e.hostDirectiveOutputs?.hasOwnProperty(o)) {
    let u = e.hostDirectiveOutputs[o];
    for (let d = 0; d < u.length; d += 2) {
        let f = u[d];
        if (f >= s && f <= a)
            c = !0, zn(e, t, f, u[d + 1], o, r);
        else if (f > a)
            break;
    }
} return n.outputs.hasOwnProperty(o) && (c = !0, zn(e, t, i, o, o, r)), c; }
function zn(e, t, n, o, r, i) { let s = t[n], a = t[m], l = a.data[n].outputs[o], d = s[l].subscribe(i); Jy(e.index, a, t, r, i, d, !0); }
function Xy() { ev(); }
function ev() { let e = g(), t = w(), n = M(); if (t.firstCreatePass && ES(t, n), n.controlDirectiveIndex === -1)
    return; Y("NgSignalForms"); let o = e[n.controlDirectiveIndex]; t.data[n.controlDirectiveIndex].controlDef.create(o, new as(e, t, n)); }
function tv() { nv(); }
function nv() { let e = g(), t = w(), n = Ce(); if (n.controlDirectiveIndex === -1)
    return; let o = t.data[n.controlDirectiveIndex].controlDef, r = e[n.controlDirectiveIndex]; o.update(r, new as(e, t, n)); }
var as = class {
    lView;
    tView;
    tNode;
    hasPassThrough;
    constructor(t, n, o) { this.lView = t, this.tView = n, this.tNode = o, this.hasPassThrough = !!(o.flags & 4096); }
    get customControl() { return this.tNode.customControlIndex !== -1 ? this.lView[this.tNode.customControlIndex] : void 0; }
    get descriptor() { return `<${this.tNode.value}>`; }
    listenToCustomControlOutput(t, n) { ov(this.tView.data[this.tNode.customControlIndex], t) && zn(this.tNode, this.lView, this.tNode.customControlIndex, t, t, Rt(this.tNode, this.lView, n)); }
    listenToCustomControlModel(t) { let n = this.tNode.flags & 1024 ? "valueChange" : "checkedChange"; zn(this.tNode, this.lView, this.tNode.customControlIndex, n, n, Rt(this.tNode, this.lView, t)); }
    listenToDom(t, n) { fd(this.tNode, this.tView, this.lView, void 0, this.lView[T], t, n, Rt(this.tNode, this.lView, n)); }
    setInputOnDirectives(t, n) { let o = this.tNode.inputs?.[t], r = this.tNode.hostDirectiveInputs?.[t]; if (!o && !r)
        return !1; if (o)
        for (let i of o) {
            let s = this.tView.data[i], a = this.lView[i];
            At(s, a, t, n);
        } if (r)
        for (let i = 0; i < r.length; i += 2) {
            let s = r[i], a = r[i + 1], c = this.tView.data[s], l = this.lView[s];
            At(c, l, a, n);
        } return !0; }
    setCustomControlModelInput(t) { let n = this.lView[this.tNode.customControlIndex], o = this.tView.data[this.tNode.customControlIndex], r = this.tNode.flags & 1024 ? "value" : "checked"; At(o, n, r, t); }
    customControlHasInput(t) { return this.tNode.customControlIndex === -1 ? !1 : this.tView.data[this.tNode.customControlIndex].inputs[t] != null; }
};
function ES(e, t, n) { for (let r = t.directiveStart; r < t.directiveEnd; r++)
    if (e.data[r].controlDef) {
        t.controlDirectiveIndex = r;
        break;
    } if (t.controlDirectiveIndex === -1)
    return; let o = e.data[t.controlDirectiveIndex].controlDef; if (o.passThroughInput && (t.inputs?.[o.passThroughInput]?.length ?? 0) > 1) {
    t.flags |= 4096;
    return;
} IS(e, t); }
function IS(e, t) { for (let n = t.directiveStart; n < t.directiveEnd; n++) {
    let o = e.data[n];
    if (hh(o, "value")) {
        t.flags |= 1024, t.customControlIndex = n;
        return;
    }
    if (hh(o, "checked")) {
        t.flags |= 2048, t.customControlIndex = n;
        return;
    }
} }
function hh(e, t) { return DS(e, t) && ov(e, t + "Change"); }
function DS(e, t) { return t in e.inputs; }
function ov(e, t) { return t in e.outputs; }
var it = Symbol("BINDING"), gh = { kind: "input", requiredVars: 1 }, CS = { kind: "output", requiredVars: 0 };
function mh(e, t, n) { let o = g(), r = he(); if (z(o, r, n)) {
    let i = o[m], s = Ce(), a = pe(s.index, o);
    kr(a, 1);
    let c = i.directiveRegistry[e], l = Uw(s, i, o, c, t, n);
} }
function rv(e, t) { if (e === "formField") {
    let o = { [it]: gh, create: () => { ev(); }, update: () => { mh(o.targetIdx, e, t()), nv(); } };
    return o;
} let n = { [it]: gh, update: () => mh(n.targetIdx, e, t()) }; return n; }
function iv(e, t) { let n = { [it]: CS, create: () => { let o = g(), r = M(), s = o[m].directiveRegistry[n.targetIdx]; yS(r, o, t, s, e); } }; return n; }
function TS(e, t) { let n = rv(e, t), o = iv(e + "Change", i => t.set(i)); return { [it]: { kind: "twoWay", requiredVars: n[it].requiredVars + o[it].requiredVars }, set targetIdx(i) { n.targetIdx = i, o.targetIdx = i; }, create: o.create, update: n.update }; }
function MS(e) { let t = e; for (; t;) {
    let n = mM(t);
    if (n !== null)
        for (let o = E; o < n.length; o++) {
            let r = n[o];
            if (!re(r) && !ee(r) || r[j] !== t)
                continue;
            let i = n[m], s = $t(i, o);
            if (me(s)) {
                let a = i.data[s.directiveStart + s.componentOffset], c = pd(a);
                if (c !== null)
                    return c;
                break;
            }
        }
    t = t.parentNode;
} return null; }
function pd(e) { return e.debugInfo?.className || e.type.name || null; }
var cs = class extends xr {
    ngModule;
    constructor(t) { super(), this.ngModule = t; }
    resolveComponentFactory(t) { let n = W(t); return new Ot(n, this.ngModule); }
};
function NS(e) { return Object.keys(e).map(t => { let [n, o, r] = e[t], i = { propName: n, templateName: t, isSignal: (o & Vs.SignalBased) !== 0 }; return r && (i.transform = r), i; }); }
function wS(e) { return Object.keys(e).map(t => ({ propName: e[t], templateName: t })); }
function _S(e, t, n) { let o = t instanceof It ? t : t?.injector; return o && e.getStandaloneInjector !== null && (o = e.getStandaloneInjector(o) || o), o ? new Pn(n, o) : n; }
function SS(e) { let t = e.get(cr, null); if (t === null)
    throw new _(407, !1); let n = e.get(Gy, null), o = e.get(Nt, null), r = e.get(gn, null, { optional: !0 }); return { rendererFactory: t, sanitizer: n, changeDetectionScheduler: o, ngReflect: !1, tracingService: r }; }
function bS(e, t) { let n = sv(e); return Ps(t, n, n === "svg" ? oc : n === "math" ? rc : null); }
function sv(e) { return (e.selectors[0][0] || "div").toLowerCase(); }
var Ot = class extends aa {
    componentDef;
    ngModule;
    selector;
    componentType;
    ngContentSelectors;
    isBoundToModule;
    cachedInputs = null;
    cachedOutputs = null;
    get inputs() { return this.cachedInputs ??= NS(this.componentDef.inputs), this.cachedInputs; }
    get outputs() { return this.cachedOutputs ??= wS(this.componentDef.outputs), this.cachedOutputs; }
    constructor(t, n) { super(), this.componentDef = t, this.ngModule = n, this.componentType = t.type, this.selector = sw(t.selectors), this.ngContentSelectors = t.ngContentSelectors ?? [], this.isBoundToModule = !!n; }
    create(t, n, o, r, i, s) { x(R.DynamicComponentStart); let a = L(null); try {
        let c = this.componentDef, l = _S(c, r || this.ngModule, t), u = SS(l), d = u.tracingService;
        return d && d.componentCreate ? d.componentCreate(pd(c), () => this.createComponentRef(u, l, n, o, i, s)) : this.createComponentRef(u, l, n, o, i, s);
    }
    finally {
        L(a);
    } }
    createComponentRef(t, n, o, r, i, s) { let a = this.componentDef, c = AS(r, a, s, i), l = t.rendererFactory.createRenderer(null, a), u = r ? Ow(l, r, a.encapsulation, n) : bS(a, l), d = s?.some(yh) || i?.some(h => typeof h != "function" && h.bindings.some(yh)), f = Hs(null, c, null, 512 | ju(a), null, null, t, l, n, null, tm(u, n, !0)); f[E] = u, yi(f); let p = null; try {
        let h = ud(E, f, 2, "#host", () => c.directiveRegistry, !0, 0);
        _m(l, u, h), Re(u, f), Qs(c, f, h), Su(c, h, f), dd(c, h), o !== void 0 && kS(h, this.ngContentSelectors, o), p = pe(h.index, f), f[H] = p[H], Xs(c, f, null);
    }
    catch (h) {
        throw p !== null && cl(p), cl(f), h;
    }
    finally {
        x(R.DynamicComponentEnd), vi();
    } return new ls(this.componentType, f, !!d); }
};
function AS(e, t, n, o) { let r = e ? ["ng-version", "21.2.16"] : aw(t.selectors[0]), i = null, s = null, a = 0; if (n)
    for (let u of n)
        a += u[it].requiredVars, u.create && (u.targetIdx = 0, (i ??= []).push(u)), u.update && (u.targetIdx = 0, (s ??= []).push(u)); if (o)
    for (let u = 0; u < o.length; u++) {
        let d = o[u];
        if (typeof d != "function")
            for (let f of d.bindings) {
                a += f[it].requiredVars;
                let p = u + 1;
                f.create && (f.targetIdx = p, (i ??= []).push(f)), f.update && (f.targetIdx = p, (s ??= []).push(f));
            }
    } let c = [t]; if (o)
    for (let u of o) {
        let d = typeof u == "function" ? u : u.type, f = Ne(d);
        c.push(f);
    } return Vu(0, null, RS(i, s), 1, a, c, null, null, null, [r], null); }
function RS(e, t) { return !e && !t ? null : n => { if (n & 1 && e)
    for (let o of e)
        o.create(); if (n & 2 && t)
    for (let o of t)
        o.update(); }; }
function yh(e) { let t = e[it].kind; return t === "input" || t === "twoWay"; }
var ls = class extends zy {
    _rootLView;
    _hasInputBindings;
    instance;
    hostView;
    changeDetectorRef;
    componentType;
    location;
    previousInputValues = null;
    _tNode;
    constructor(t, n, o) { super(), this._rootLView = n, this._hasInputBindings = o, this._tNode = $t(n[m], E), this.location = Jn(this._tNode, n), this.instance = pe(this._tNode.index, n)[H], this.hostView = this.changeDetectorRef = new kt(n, void 0), this.componentType = t; }
    setInput(t, n) { this._hasInputBindings; let o = this._tNode; if (this.previousInputValues ??= new Map, this.previousInputValues.has(t) && Object.is(this.previousInputValues.get(t), n))
        return; let r = this._rootLView, i = Js(o, r[m], r, t, n); this.previousInputValues.set(t, n); let s = pe(o.index, r); kr(s, 1); }
    get injector() { return new bt(this._tNode, this._rootLView); }
    destroy() { this.hostView.destroy(); }
    onDestroy(t) { this.hostView.onDestroy(t); }
};
function kS(e, t, n) { let o = e.projection = []; for (let r = 0; r < t.length; r++) {
    let i = n[r];
    o.push(i != null && i.length ? Array.from(i) : null);
} }
var ua = (() => { class e {
    static __NG_ELEMENT_ID__ = OS;
} return e; })();
function OS() { let e = M(); return av(e, g()); }
var Hl = class e extends ua {
    _lContainer;
    _hostTNode;
    _hostLView;
    constructor(t, n, o) { super(), this._lContainer = t, this._hostTNode = n, this._hostLView = o; }
    get element() { return Jn(this._hostTNode, this._hostLView); }
    get injector() { return new bt(this._hostTNode, this._hostLView); }
    get parentInjector() { let t = lu(this._hostTNode, this._hostLView); if (pg(t)) {
        let n = qi(t, this._hostLView), o = Wi(t), r = n[m].data[o + 8];
        return new bt(r, n);
    }
    else
        return new bt(null, this._hostLView); }
    clear() { for (; this.length > 0;)
        this.remove(this.length - 1); }
    get(t) { let n = vh(this._lContainer); return n !== null && n[t] || null; }
    get length() { return this._lContainer.length - V; }
    createEmbeddedView(t, n, o) { let r, i; typeof o == "number" ? r = o : o != null && (r = o.index, i = o.injector); let s = ar(this._lContainer, t.ssrId), a = t.createEmbeddedViewImpl(n || {}, i, s); return this.insertImpl(a, r, sn(this._hostTNode, s)), a; }
    createComponent(t, n, o, r, i, s, a) { let c = t && !Vo(t), l; if (c)
        l = n;
    else {
        let v = n || {};
        l = v.index, o = v.injector, r = v.projectableNodes, i = v.environmentInjector || v.ngModuleRef, s = v.directives, a = v.bindings;
    } let u = c ? t : new Ot(W(t)), d = o || this.parentInjector; if (!i && u.ngModule == null) {
        let D = (c ? d : this.parentInjector).get(It, null);
        D && (i = D);
    } let f = W(u.componentType ?? {}), p = ar(this._lContainer, f?.id ?? null), h = p?.firstChild ?? null, y = u.create(d, r, h, i, s, a); return this.insertImpl(y.hostView, l, sn(this._hostTNode, p)), y; }
    insert(t, n) { return this.insertImpl(t, n, !0); }
    insertImpl(t, n, o) { let r = t._lView; if (gp(r)) {
        let a = this.indexOf(t);
        if (a !== -1)
            this.detach(a);
        else {
            let c = r[q], l = new e(c, c[ue], c[q]);
            l.detach(l.indexOf(t));
        }
    } let i = this._adjustIndex(n), s = this._lContainer; return lo(s, r, i, o), t.attachToViewContainerRef(), Ya(Wc(s), i, t), t; }
    move(t, n) { return this.insert(t, n); }
    indexOf(t) { let n = vh(this._lContainer); return n !== null ? n.indexOf(t) : -1; }
    remove(t) { let n = this._adjustIndex(t, -1), o = rr(this._lContainer, n); o && (To(Wc(this._lContainer), n), Rr(o[m], o)); }
    detach(t) { let n = this._adjustIndex(t, -1), o = rr(this._lContainer, n); return o && To(Wc(this._lContainer), n) != null ? new kt(o) : null; }
    _adjustIndex(t, n = 0) { return t ?? this.length + n; }
};
function vh(e) { return e[bo]; }
function Wc(e) { return e[bo] || (e[bo] = []); }
function av(e, t) { let n, o = t[e.index]; return ee(o) ? n = o : (n = my(o, t, null, e), t[e.index] = n, Bu(t, n)), cv(n, t, e, o), new Hl(n, e, t); }
function xS(e, t) { let n = e[T], o = n.createComment(""), r = ie(t, e), i = n.parentNode(r); return nn(n, i, o, n.nextSibling(r), !1), o; }
var cv = uv, hd = () => !1;
function lv(e, t, n) { return hd(e, t, n); }
function uv(e, t, n, o) { if (e[He])
    return; let r; n.type & 8 ? r = O(o) : r = xS(t, n), e[He] = r; }
function LS(e, t, n) { if (e[He] && e[De])
    return !0; let o = n[ae], r = t.index - E; if (!o || Xn(t) || Os(o, r))
    return !1; let s = pl(o, r), a = o.data[to]?.[r]; if (a === void 0)
    return !1; let [c, l] = K_(s, a); return e[He] = c, e[De] = l, !0; }
function PS(e, t, n, o) { hd(e, n, t) || uv(e, t, n, o); }
function dv() { cv = PS, hd = LS; }
var Vl = class e {
    queryList;
    matches = null;
    constructor(t) { this.queryList = t; }
    clone() { return new e(this.queryList); }
    setDirty() { this.queryList.setDirty(); }
}, jl = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    createEmbeddedView(t) { let n = t.queries; if (n !== null) {
        let o = t.contentQueries !== null ? t.contentQueries[0] : n.length, r = [];
        for (let i = 0; i < o; i++) {
            let s = n.getByIndex(i), a = this.queries[s.indexInDeclarationView];
            r.push(a.clone());
        }
        return new e(r);
    } return null; }
    insertView(t) { this.dirtyQueriesWithMatches(t); }
    detachView(t) { this.dirtyQueriesWithMatches(t); }
    finishViewCreation(t) { this.dirtyQueriesWithMatches(t); }
    dirtyQueriesWithMatches(t) { for (let n = 0; n < this.queries.length; n++)
        md(t, n).matches !== null && this.queries[n].setDirty(); }
}, us = class {
    flags;
    read;
    predicate;
    constructor(t, n, o = null) { this.flags = n, this.read = o, typeof t == "string" ? this.predicate = BS(t) : this.predicate = t; }
}, Bl = class e {
    queries;
    constructor(t = []) { this.queries = t; }
    elementStart(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].elementStart(t, n); }
    elementEnd(t) { for (let n = 0; n < this.queries.length; n++)
        this.queries[n].elementEnd(t); }
    embeddedTView(t) { let n = null; for (let o = 0; o < this.length; o++) {
        let r = n !== null ? n.length : 0, i = this.getByIndex(o).embeddedTView(t, r);
        i && (i.indexInDeclarationView = o, n !== null ? n.push(i) : n = [i]);
    } return n !== null ? new e(n) : null; }
    template(t, n) { for (let o = 0; o < this.queries.length; o++)
        this.queries[o].template(t, n); }
    getByIndex(t) { return this.queries[t]; }
    get length() { return this.queries.length; }
    track(t) { this.queries.push(t); }
}, Ul = class e {
    metadata;
    matches = null;
    indexInDeclarationView = -1;
    crossesNgTemplate = !1;
    _declarationNodeIndex;
    _appliesToNextNode = !0;
    constructor(t, n = -1) { this.metadata = t, this._declarationNodeIndex = n; }
    elementStart(t, n) { this.isApplyingToNode(n) && this.matchTNode(t, n); }
    elementEnd(t) { this._declarationNodeIndex === t.index && (this._appliesToNextNode = !1); }
    template(t, n) { this.elementStart(t, n); }
    embeddedTView(t, n) { return this.isApplyingToNode(t) ? (this.crossesNgTemplate = !0, this.addMatch(-t.index, n), new e(this.metadata)) : null; }
    isApplyingToNode(t) { if (this._appliesToNextNode && (this.metadata.flags & 1) !== 1) {
        let n = this._declarationNodeIndex, o = t.parent;
        for (; o !== null && o.type & 8 && o.index !== n;)
            o = o.parent;
        return n === (o !== null ? o.index : -1);
    } return this._appliesToNextNode; }
    matchTNode(t, n) { let o = this.metadata.predicate; if (Array.isArray(o))
        for (let r = 0; r < o.length; r++) {
            let i = o[r];
            this.matchTNodeWithReadOption(t, n, FS(n, i)), this.matchTNodeWithReadOption(t, n, Li(n, t, i, !1, !1));
        }
    else
        o === ir ? n.type & 4 && this.matchTNodeWithReadOption(t, n, -1) : this.matchTNodeWithReadOption(t, n, Li(n, t, o, !1, !1)); }
    matchTNodeWithReadOption(t, n, o) { if (o !== null) {
        let r = this.metadata.read;
        if (r !== null)
            if (r === Er || r === ua || r === ir && n.type & 4)
                this.addMatch(n.index, -2);
            else {
                let i = Li(n, t, r, !1, !1);
                i !== null && this.addMatch(n.index, i);
            }
        else
            this.addMatch(n.index, o);
    } }
    addMatch(t, n) { this.matches === null ? this.matches = [t, n] : this.matches.push(t, n); }
};
function FS(e, t) { let n = e.localNames; if (n !== null) {
    for (let o = 0; o < n.length; o += 2)
        if (n[o] === t)
            return n[o + 1];
} return null; }
function HS(e, t) { return e.type & 11 ? Jn(e, t) : e.type & 4 ? ta(e, t) : null; }
function VS(e, t, n, o) { return n === -1 ? HS(t, e) : n === -2 ? jS(e, t, o) : Jo(e, e[m], n, t); }
function jS(e, t, n) { if (n === Er)
    return Jn(t, e); if (n === ir)
    return ta(t, e); if (n === ua)
    return av(t, e); }
function fv(e, t, n, o) { let r = t[ze].queries[o]; if (r.matches === null) {
    let i = e.data, s = n.matches, a = [];
    for (let c = 0; s !== null && c < s.length; c += 2) {
        let l = s[c];
        if (l < 0)
            a.push(null);
        else {
            let u = i[l];
            a.push(VS(t, u, s[c + 1], n.metadata.read));
        }
    }
    r.matches = a;
} return r.matches; }
function $l(e, t, n, o) { let r = e.queries.getByIndex(n), i = r.matches; if (i !== null) {
    let s = fv(e, t, r, n);
    for (let a = 0; a < i.length; a += 2) {
        let c = i[a];
        if (c > 0)
            o.push(s[a / 2]);
        else {
            let l = i[a + 1], u = t[-c];
            for (let d = V; d < u.length; d++) {
                let f = u[d];
                f[Ct] === f[q] && $l(f[m], f, l, o);
            }
            if (u[Bt] !== null) {
                let d = u[Bt];
                for (let f = 0; f < d.length; f++) {
                    let p = d[f];
                    $l(p[m], p, l, o);
                }
            }
        }
    }
} return o; }
function gd(e, t) { return e[ze].queries[t].queryList; }
function pv(e, t, n) { let o = new Zi((n & 4) === 4); return Ep(e, t, o, o.destroy), (t[ze] ??= new jl).queries.push(new Vl(o)) - 1; }
function hv(e, t, n) { let o = w(); return o.firstCreatePass && (mv(o, new us(e, t, n), -1), (t & 2) === 2 && (o.staticViewQueries = !0)), pv(o, g(), t); }
function gv(e, t, n, o) { let r = w(); if (r.firstCreatePass) {
    let i = M();
    mv(r, new us(t, n, o), i.index), US(r, e), (n & 2) === 2 && (r.staticContentQueries = !0);
} return pv(r, g(), n); }
function BS(e) { return e.split(",").map(t => t.trim()); }
function mv(e, t, n) { e.queries === null && (e.queries = new Bl), e.queries.track(new Ul(t, n)); }
function US(e, t) { let n = e.contentQueries || (e.contentQueries = []), o = n.length ? n[n.length - 1] : -1; t !== o && n.push(e.queries.length - 1, t); }
function md(e, t) { return e.queries.getByIndex(t); }
function yv(e, t) { let n = e[m], o = md(n, t); return o.crossesNgTemplate ? $l(n, e, t, []) : fv(n, e, o, t); }
function yd(e, t, n) { let o, r = Jf(() => { o._dirtyCounter(); let i = $S(o, e); if (t && i === void 0)
    throw new _(-951, !1); return i; }); return o = r[tt], o._dirtyCounter = Rc(0), o._flatValue = void 0, r; }
function vd(e) { return yd(!0, !1, e); }
function Ed(e) { return yd(!0, !0, e); }
function Id(e) { return yd(!1, !1, e); }
function vv(e, t) { let n = e[tt]; n._lView = g(), n._queryIndex = t, n._queryList = gd(n._lView, t), n._queryList.onDirty(() => n._dirtyCounter.update(o => o + 1)); }
function $S(e, t) { let n = e._lView, o = e._queryIndex; if (n === void 0 || o === void 0 || n[A] & 4)
    return t ? void 0 : F; let r = gd(n, o), i = yv(n, o); return r.reset(i, Ng), t ? r.first : r._changesDetected || e._flatValue === void 0 ? e._flatValue = r.toArray() : e._flatValue; }
var cn = new Map, ur = new Set;
function Ev(e) { return mt(this, null, function* () { let t = cn; cn = new Map; let n = new Map; function o(i) { let s = n.get(i); if (s)
    return s; let a = e(i).then(c => QS(i, c)); return n.set(i, a), a; } let r = Array.from(t).map(a => mt(null, [a], function* ([i, s]) { if (s.styleUrl && s.styleUrls?.length)
    throw new Error("@Component cannot define both `styleUrl` and `styleUrls`. Use `styleUrl` if the component has one stylesheet, or `styleUrls` if it has multiple"); let c = []; s.templateUrl && c.push(o(s.templateUrl).then(f => { s.template = f; })); let l = typeof s.styles == "string" ? [s.styles] : s.styles ?? []; s.styles = l; let { styleUrl: u, styleUrls: d } = s; if (u && (d = [u], s.styleUrl = void 0), d?.length) {
    let f = Promise.all(d.map(p => o(p))).then(p => { l.push(...p), s.styleUrls = void 0; });
    c.push(f);
} yield Promise.all(c), ur.delete(i); })); yield Promise.all(r); }); }
function zS(e, t) { Iv(t) && (cn.set(e, t), ur.add(e)); }
function GS(e) { return ur.has(e); }
function Iv(e) { return !!(e.templateUrl && !e.hasOwnProperty("template") || e.styleUrls?.length || e.styleUrl); }
function WS() { let e = cn; return cn = new Map, e; }
function qS(e) { ur.clear(); for (let t of e.keys())
    ur.add(t); cn = e; }
function Dv() { return cn.size === 0; }
function QS(e, t) { return mt(this, null, function* () { if (typeof t == "string")
    return t; if (t.status !== void 0 && t.status !== 200)
    throw new _(918, !1); return t.text(); }); }
var zl = new Map, Cv = !0;
function YS(e, t, n) { if (t && t !== n && Cv)
    throw new _(921, !1); }
function Dd(e, t) { let n = zl.get(t) || null; YS(t, n, e), zl.set(t, e); }
function Cd(e) { return zl.get(e); }
function ZS(e) { Cv = !e; }
var Gn = class {
}, Tv = class {
};
function Mv(e, t) { return new Wn(e, t ?? null, []); }
var KS = Mv, Wn = class extends Gn {
    ngModuleType;
    _parent;
    _bootstrapComponents = [];
    _r3Injector;
    instance;
    destroyCbs = [];
    componentFactoryResolver = new cs(this);
    constructor(t, n, o, r = !0) { super(), this.ngModuleType = t, this._parent = n; let i = En(t); this._bootstrapComponents = Rn(i.bootstrap), this._r3Injector = Sp(t, n, [{ provide: Gn, useValue: this }, { provide: xr, useValue: this.componentFactoryResolver }, ...o], Zr(t), new Set(["environment"])), r && this.resolveInjectorInitializers(); }
    resolveInjectorInitializers() { this._r3Injector.resolveInjectorInitializers(), this.instance = this._r3Injector.get(this.ngModuleType); }
    get injector() { return this._r3Injector; }
    destroy() { let t = this._r3Injector; !t.destroyed && t.destroy(), this.destroyCbs.forEach(n => n()), this.destroyCbs = null; }
    onDestroy(t) { this.destroyCbs.push(t); }
}, qn = class extends Tv {
    moduleType;
    constructor(t) { super(), this.moduleType = t; }
    create(t) { return new Wn(this.moduleType, t, []); }
};
function Nv(e, t, n) { return new Wn(e, t, n, !1); }
var dr = class extends Gn {
    injector;
    componentFactoryResolver = new cs(this);
    instance = null;
    constructor(t) { super(); let n = new Ja([...t.providers, { provide: Gn, useValue: this }, { provide: xr, useValue: this.componentFactoryResolver }], t.parent || ai(), t.debugName, new Set(["environment"])); this.injector = n, t.runEnvironmentInitializers && n.resolveInjectorInitializers(); }
    destroy() { this.injector.destroy(); }
    onDestroy(t) { this.injector.onDestroy(t); }
};
function Td(e, t, n = null) { return new dr({ providers: e, parent: t, debugName: n, runEnvironmentInitializers: !0 }).injector; }
var JS = (() => { class e {
    _injector;
    cachedInjectors = new Map;
    constructor(n) { this._injector = n; }
    getOrCreateStandaloneInjector(n) { if (!n.standalone)
        return null; if (!this.cachedInjectors.has(n)) {
        let o = Ka(!1, n.type), r = o.length > 0 ? Td([o], this._injector, "") : null;
        this.cachedInjectors.set(n, r);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = B({ token: e, providedIn: "environment", factory: () => new e(Pe(It)) });
} return e; })();
function wv(e) { return Je(() => { let t = Av(e), n = et(K({}, t), { decls: e.decls, vars: e.vars, template: e.template, consts: e.consts || null, ngContentSelectors: e.ngContentSelectors, onPush: e.changeDetection === Cs.OnPush, directiveDefs: null, pipeDefs: null, dependencies: t.standalone && e.dependencies || null, getStandaloneInjector: t.standalone ? r => r.get(JS).getOrCreateStandaloneInjector(n) : null, getExternalStyles: null, signals: e.signals ?? !1, data: e.data || {}, encapsulation: e.encapsulation || ke.Emulated, styles: e.styles || F, _: null, schemas: e.schemas || null, tView: null, id: "" }); t.standalone && Y("NgStandalone"), Rv(n); let o = e.dependencies; return n.directiveDefs = ds(o, _v), n.pipeDefs = ds(o, Ue), n.id = nb(n), n; }); }
function _v(e) { return W(e) || Ne(e); }
function Md(e) { return Je(() => ({ type: e.type, bootstrap: e.bootstrap || F, declarations: e.declarations || F, imports: e.imports || F, exports: e.exports || F, transitiveCompileScopes: null, schemas: e.schemas || null, id: e.id || null })); }
function XS(e, t) { if (e == null)
    return _e; let n = {}; for (let o in e)
    if (e.hasOwnProperty(o)) {
        let r = e[o], i, s, a, c;
        Array.isArray(r) ? (a = r[0], i = r[1], s = r[2] ?? i, c = r[3] || null) : (i = r, s = r, a = Vs.None, c = null), n[i] = [o, a, c], t[i] = s;
    } return n; }
function eb(e) { if (e == null)
    return _e; let t = {}; for (let n in e)
    e.hasOwnProperty(n) && (t[e[n]] = n); return t; }
function Sv(e) { return Je(() => { let t = Av(e); return Rv(t), t; }); }
function bv(e) { return { type: e.type, name: e.name, factory: null, pure: e.pure !== !1, standalone: e.standalone ?? !0, onDestroy: e.type.prototype.ngOnDestroy || null }; }
function Av(e) { let t = {}; return { type: e.type, providersResolver: null, viewProvidersResolver: null, factory: null, hostBindings: e.hostBindings || null, hostVars: e.hostVars || 0, hostAttrs: e.hostAttrs || null, contentQueries: e.contentQueries || null, declaredInputs: t, inputConfig: e.inputs || _e, exportAs: e.exportAs || null, standalone: e.standalone ?? !0, signals: e.signals === !0, selectors: e.selectors || F, viewQuery: e.viewQuery || null, features: e.features || null, setInput: null, resolveHostDirectives: null, hostDirectives: null, controlDef: null, inputs: XS(e.inputs, t), outputs: eb(e.outputs), debugInfo: null }; }
function Rv(e) { e.features?.forEach(t => t(e)); }
function ds(e, t) { return e ? () => { let n = typeof e == "function" ? e() : e, o = []; for (let r of n) {
    let i = t(r);
    i !== null && o.push(i);
} return o; } : null; }
var tb = new Map;
function nb(e) { let t = 0, n = typeof e.consts == "function" ? "" : e.consts, o = [e.selectors, e.ngContentSelectors, e.hostVars, e.hostAttrs, n, e.vars, e.decls, e.encapsulation, e.standalone, e.signals, e.exportAs, JSON.stringify(e.inputs), JSON.stringify(e.outputs), Object.getOwnPropertyNames(e.type.prototype), !!e.contentQueries, !!e.viewQuery]; for (let i of o.join("|"))
    t = Math.imul(31, t) + i.charCodeAt(0) << 0; return t += 2147483648, "c" + t; }
function kv(e) { return t => { t.controlDef = { create: (n, o) => { n?.\u0275ngControlCreate(o); }, update: (n, o) => { n?.\u0275ngControlUpdate?.(o); }, passThroughInput: e }; }; }
function Ov(e) { let t = n => { let o = Array.isArray(e); n.hostDirectives === null ? (n.resolveHostDirectives = ob, n.hostDirectives = o ? e.map(Gl) : [e]) : o ? n.hostDirectives.unshift(...e.map(Gl)) : n.hostDirectives.unshift(e); }; return t.ngInherit = !0, t; }
function ob(e) { let t = [], n = !1, o = null, r = null; for (let i = 0; i < e.length; i++) {
    let s = e[i];
    if (s.hostDirectives !== null) {
        let a = t.length;
        o ??= new Map, r ??= new Map, xv(s, t, o), r.set(s, [a, t.length - 1]);
    }
    i === 0 && Ae(s) && (n = !0, t.push(s));
} for (let i = n ? 1 : 0; i < e.length; i++)
    t.push(e[i]); return [t, o, r]; }
function xv(e, t, n) { if (e.hostDirectives !== null)
    for (let o of e.hostDirectives)
        if (typeof o == "function") {
            let r = o();
            for (let i of r)
                Eh(Gl(i), t, n);
        }
        else
            Eh(o, t, n); }
function Eh(e, t, n) { let o = Ne(e.directive); rb(o.declaredInputs, e.inputs), xv(o, t, n), n.set(o, e), t.push(o); }
function Gl(e) { return typeof e == "function" ? { directive: G(e), inputs: _e, outputs: _e } : { directive: G(e.directive), inputs: Ih(e.inputs), outputs: Ih(e.outputs) }; }
function Ih(e) { if (e === void 0 || e.length === 0)
    return _e; let t = {}; for (let n = 0; n < e.length; n += 2)
    t[e[n]] = e[n + 1]; return t; }
function rb(e, t) { for (let n in t)
    if (t.hasOwnProperty(n)) {
        let o = t[n], r = e[n];
        e[o] = r;
    } }
function ib(e) { return Object.getPrototypeOf(e.prototype).constructor; }
function Nd(e) { let t = ib(e.type), n = !0, o = [e]; for (; t && t !== Function.prototype && t !== Object.prototype;) {
    let r, i = Object.hasOwn(t, yt) ? t[yt] : void 0, s = Object.hasOwn(t, vn) ? t[vn] : void 0;
    if (Ae(e))
        r = i ?? s;
    else {
        if (i)
            throw new _(903, !1);
        r = s;
    }
    if (r) {
        if (n) {
            o.push(r);
            let c = e;
            c.inputs = qc(e.inputs), c.declaredInputs = qc(e.declaredInputs), c.outputs = qc(e.outputs);
            let l = r.hostBindings;
            l && ub(e, l);
            let u = r.viewQuery, d = r.contentQueries;
            if (u && cb(e, u), d && lb(e, d), sb(e, r), tp(e.outputs, r.outputs), Ae(r) && r.data.animation) {
                let f = e.data;
                f.animation = (f.animation || []).concat(r.data.animation);
            }
        }
        let a = r.features;
        if (a)
            for (let c = 0; c < a.length; c++) {
                let l = a[c];
                l && l.ngInherit && l(e), l === Nd && (n = !1);
            }
    }
    t = Object.getPrototypeOf(t);
} ab(o); }
function sb(e, t) { for (let n in t.inputs) {
    if (!t.inputs.hasOwnProperty(n) || e.inputs.hasOwnProperty(n))
        continue;
    let o = t.inputs[n];
    o !== void 0 && (e.inputs[n] = o, e.declaredInputs[n] = t.declaredInputs[n]);
} }
function ab(e) { let t = 0, n = null; for (let o = e.length - 1; o >= 0; o--) {
    let r = e[o];
    r.hostVars = t += r.hostVars, r.hostAttrs = jn(r.hostAttrs, n = jn(n, r.hostAttrs));
} }
function qc(e) { return e === _e ? {} : e === F ? [] : e; }
function cb(e, t) { let n = e.viewQuery; n ? e.viewQuery = (o, r) => { t(o, r), n(o, r); } : e.viewQuery = t; }
function lb(e, t) { let n = e.contentQueries; n ? e.contentQueries = (o, r, i) => { t(o, r, i), n(o, r, i); } : e.contentQueries = t; }
function ub(e, t) { let n = e.hostBindings; n ? e.hostBindings = (o, r) => { t(o, r), n(o, r); } : e.hostBindings = t; }
function Lv(e, t, n, o, r, i, s, a) { if (n.firstCreatePass) {
    e.mergedAttrs = jn(e.mergedAttrs, e.attrs);
    let u = e.tView = Vu(2, e, r, i, s, n.directiveRegistry, n.pipeRegistry, null, n.schemas, n.consts, null);
    n.queries !== null && (n.queries.template(n, e), u.queries = n.queries.embeddedTView(e));
} a && (e.flags |= a), qe(e, !1); let c = Pv(n, t, e, o); Lo() && Ju(n, t, c, e), Re(c, t); let l = my(c, t, c, e); t[o + E] = l, Bu(t, l), lv(l, e, t); }
function db(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; return t.firstCreatePass ? (f = mn(t, d, 4, s || null, a || null), hi() && qy(t, e, f, de(t.consts, l), nd), lg(t, f)) : f = t.data[d], Lv(f, e, t, n, o, r, i, c), Cn(f) && Qs(t, e, f), l != null && ao(e, f, u), f; }
function ln(e, t, n, o, r, i, s, a, c, l, u) { let d = n + E, f; if (t.firstCreatePass) {
    if (f = mn(t, d, 4, s || null, a || null), l != null) {
        let p = de(t.consts, l);
        f.localNames = [];
        for (let h = 0; h < p.length; h += 2)
            f.localNames.push(p[h], -1);
    }
}
else
    f = t.data[d]; return Lv(f, e, t, n, o, r, i, c), l != null && ao(e, f, u), f; }
function wd(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = de(l.consts, i); return db(c, l, e, t, n, o, r, u, void 0, s, a), wd; }
function _d(e, t, n, o, r, i, s, a) { let c = g(), l = w(), u = de(l.consts, i); return ln(c, l, e, t, n, o, r, u, void 0, s, a), _d; }
var Pv = Fv;
function Fv(e, t, n, o) { return Ve(!0), t[T].createComment(""); }
function fb(e, t, n, o) { let r = !xs(t, n); Ve(r); let i = t[ae]?.data[Ns]?.[o] ?? null; if (i !== null && n.tView !== null && n.tView.ssrId === null && (n.tView.ssrId = i), r)
    return Fv(e, t); let s = t[ae], a = Or(s, e, t, n); ks(s, o, a); let c = wu(s, o); return oa(c, a); }
function Hv() { Pv = fb; }
var ne = (function (e) { return e[e.NOT_STARTED = 0] = "NOT_STARTED", e[e.IN_PROGRESS = 1] = "IN_PROGRESS", e[e.COMPLETE = 2] = "COMPLETE", e[e.FAILED = 3] = "FAILED", e; })(ne || {}), Dh = 0, pb = 1, $ = (function (e) { return e[e.Placeholder = 0] = "Placeholder", e[e.Loading = 1] = "Loading", e[e.Complete = 2] = "Complete", e[e.Error = 3] = "Error", e; })($ || {}), fr = (function (e) { return e[e.Initial = -1] = "Initial", e; })(fr || {}), Fn = 0, pt = 1, Bo = 2, Ai = 3, hb = 4, gb = 5, da = 6, mb = 7, Hn = 8, yb = 9, Sd = (function (e) { return e[e.Manual = 0] = "Manual", e[e.Playthrough = 1] = "Playthrough", e; })(Sd || {});
function Lr(e, t, n) { let o = jv(e); t[o] === null && (t[o] = []), t[o].push(n); }
function ji(e, t) { let n = jv(e), o = t[n]; if (o !== null) {
    for (let r of o)
        r();
    t[n] = null;
} }
function Vv(e) { ji(1, e), ji(0, e), ji(2, e); }
function jv(e) { let t = hb; return e === 1 ? t = gb : e === 2 && (t = yb), t; }
function Pr(e) { return e + 1; }
function ye(e, t) { let n = e[m], o = Pr(t.index); return e[o]; }
function vb(e, t, n) { let o = e[m], r = Pr(t); e[r] = n; }
function ce(e, t) { let n = Pr(t.index); return e.data[n]; }
function Eb(e, t, n) { let o = Pr(t); e.data[o] = n; }
function Ib(e, t, n) { let o = t[m], r = ce(o, n); switch (e) {
    case $.Complete: return r.primaryTmplIndex;
    case $.Loading: return r.loadingTmplIndex;
    case $.Error: return r.errorTmplIndex;
    case $.Placeholder: return r.placeholderTmplIndex;
    default: return null;
} }
function Wl(e, t) { return t === $.Placeholder ? e.placeholderBlockConfig?.[Dh] ?? null : t === $.Loading ? e.loadingBlockConfig?.[Dh] ?? null : null; }
function Bv(e) { return e.loadingBlockConfig?.[pb] ?? null; }
function Ch(e, t) { if (!e || e.length === 0)
    return t; let n = new Set(e); for (let o of t)
    n.add(o); return e.length === n.size ? e : Array.from(n); }
function Db(e, t) { let n = t.primaryTmplIndex + E; return $t(e, n); }
function Uv(e) { return e !== null && typeof e == "object" && typeof e.primaryTmplIndex == "number"; }
function $v(e, t) { let n = null, o = Pr(t.index); return E < o && o < e.bindingStartIndex && (n = ce(e, t)), !!n && Uv(n); }
function bd(e, t, n, o) { let r = n.get(U); return $M(e, () => r.run(t), i => r.runOutsideAngular(() => UM(i)), o); }
function Cb(e, t, n) { return n == null ? e : n >= 0 ? mp(n, e) : e[t.index][V] ?? null; }
function Tb(e, t) { return Ut(E + t, e); }
function ho(e, t, n, o, r, i, s, a) { let c = e[k], l = c.get(U), u; function d() { if (Tt(e)) {
    u.destroy();
    return;
} let f = ye(e, t), p = f[pt]; if (p !== fr.Initial && p !== $.Placeholder) {
    u.destroy();
    return;
} let h = Cb(e, t, o); if (!h || (u.destroy(), Tt(h)))
    return; let y = Tb(h, n), v = r(y, () => { l.run(() => { e !== h && sc(h, v), i(); }); }, c, a); e !== h && pi(h, v), Lr(s, f, v); } u = zm({ read: d }, { injector: c }); }
function fa(e, t) { let n = t.get(wb), o = () => n.remove(e); return n.add(e), o; }
var Mb = () => typeof requestIdleCallback < "u" ? requestIdleCallback : setTimeout, Nb = () => typeof requestIdleCallback < "u" ? cancelIdleCallback : clearTimeout, wb = (() => { class e {
    executingCallbacks = !1;
    idleId = null;
    current = new Set;
    deferred = new Set;
    ngZone = I(U);
    requestIdleCallbackFn = Mb().bind(globalThis);
    cancelIdleCallbackFn = Nb().bind(globalThis);
    add(n) { (this.executingCallbacks ? this.deferred : this.current).add(n), this.idleId === null && this.scheduleIdleCallback(); }
    remove(n) { let { current: o, deferred: r } = this; o.delete(n), r.delete(n), o.size === 0 && r.size === 0 && this.cancelIdleCallback(); }
    scheduleIdleCallback() { let n = () => { this.cancelIdleCallback(), this.executingCallbacks = !0; for (let o of this.current)
        o(); if (this.current.clear(), this.executingCallbacks = !1, this.deferred.size > 0) {
        for (let o of this.deferred)
            this.current.add(o);
        this.deferred.clear(), this.scheduleIdleCallback();
    } }; this.idleId = this.requestIdleCallbackFn(() => this.ngZone.run(n)); }
    cancelIdleCallback() { this.idleId !== null && (this.cancelIdleCallbackFn(this.idleId), this.idleId = null); }
    ngOnDestroy() { this.cancelIdleCallback(), this.current.clear(), this.deferred.clear(); }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })();
function pa(e) { return (t, n) => zv(e, t, n); }
function zv(e, t, n) { let o = n.get(Gv), r = n.get(U), i = () => o.remove(t); return o.add(e, t, r), i; }
var Gv = (() => { class e {
    executingCallbacks = !1;
    timeoutId = null;
    invokeTimerAt = null;
    current = [];
    deferred = [];
    add(n, o, r) { let i = this.executingCallbacks ? this.deferred : this.current; this.addToQueue(i, Date.now() + n, o), this.scheduleTimer(r); }
    remove(n) { let { current: o, deferred: r } = this; this.removeFromQueue(o, n) === -1 && this.removeFromQueue(r, n), o.length === 0 && r.length === 0 && this.clearTimeout(); }
    addToQueue(n, o, r) { let i = n.length; for (let s = 0; s < n.length; s += 2)
        if (n[s] > o) {
            i = s;
            break;
        } sp(n, i, o, r); }
    removeFromQueue(n, o) { let r = -1; for (let i = 0; i < n.length; i += 2)
        if (n[i + 1] === o) {
            r = i;
            break;
        } return r > -1 && Za(n, r, 2), r; }
    scheduleTimer(n) { let o = () => { this.clearTimeout(), this.executingCallbacks = !0; let i = [...this.current], s = Date.now(); for (let c = 0; c < i.length; c += 2) {
        let l = i[c], u = i[c + 1];
        if (l <= s)
            u();
        else
            break;
    } let a = -1; for (let c = 0; c < this.current.length && this.current[c] <= s; c += 2)
        a = c + 1; if (a >= 0 && Za(this.current, 0, a + 1), this.executingCallbacks = !1, this.deferred.length > 0) {
        for (let c = 0; c < this.deferred.length; c += 2) {
            let l = this.deferred[c], u = this.deferred[c + 1];
            this.addToQueue(this.current, l, u);
        }
        this.deferred.length = 0;
    } this.scheduleTimer(n); }; if (this.current.length > 0) {
        let i = Date.now(), s = this.current[0];
        if (this.timeoutId === null || this.invokeTimerAt && this.invokeTimerAt - s > 16) {
            this.clearTimeout();
            let a = Math.max(s - i, 16);
            this.invokeTimerAt = s, this.timeoutId = n.runOutsideAngular(() => setTimeout(() => n.run(o), a));
        }
    } }
    clearTimeout() { this.timeoutId !== null && (clearTimeout(this.timeoutId), this.timeoutId = null); }
    ngOnDestroy() { this.clearTimeout(), this.current.length = 0, this.deferred.length = 0; }
    static \u0275prov = B({ token: e, providedIn: "root", factory: () => new e });
} return e; })(), _b = (() => { class e {
    cachedInjectors = new Map;
    getOrCreateInjector(n, o, r, i) { if (!this.cachedInjectors.has(n)) {
        let s = r.length > 0 ? Td(r, o, i) : null;
        this.cachedInjectors.set(n, s);
    } return this.cachedInjectors.get(n); }
    ngOnDestroy() { try {
        for (let n of this.cachedInjectors.values())
            n !== null && n.destroy();
    }
    finally {
        this.cachedInjectors.clear();
    } }
    static \u0275prov = B({ token: e, providedIn: "environment", factory: () => new e });
} return e; })(), Sb = new S("DEFER_BLOCK_DEPENDENCY_INTERCEPTOR"), Wv = new S("");
function Qc(e, t, n) { return e.get(_b).getOrCreateInjector(t, e, n, ""); }
function bb(e, t, n) { if (e instanceof Pn) {
    let r = e.injector, i = e.parentInjector, s = Qc(i, t, n);
    return new Pn(r, s);
} let o = e.get(It); if (o !== e) {
    let r = Qc(o, t, n);
    return new Pn(e, r);
} return Qc(e, t, n); }
function rt(e, t, n, o = !1) { let r = n[q], i = r[m]; if (Tt(r))
    return; let s = ye(r, t), a = s[pt], c = s[mb]; if (!(c !== null && e < c) && Mh(a, e) && Mh(s[Fn] ?? -1, e)) {
    let l = ce(i, t), d = !o && (typeof ngServerMode > "u" || !ngServerMode) && (Bv(l) !== null || Wl(l, $.Loading) !== null || Wl(l, $.Placeholder)) ? ql : qv;
    try {
        d(e, s, n, t, r);
    }
    catch (f) {
        od(r, f);
    }
} }
function Ab(e, t) { let n = e[De]?.findIndex(r => r.data[Tr] === t[pt]) ?? -1; return { dehydratedView: n > -1 ? e[De][n] : null, dehydratedViewIx: n }; }
function qv(e, t, n, o, r) { x(R.DeferBlockStateStart); let i = Ib(e, r, o); if (i !== null) {
    t[pt] = e;
    let s = r[m], a = i + E, c = $t(s, a), l = 0;
    rd(n, l);
    let u;
    if (e === $.Complete) {
        let h = ce(s, o), y = h.providers;
        y && y.length > 0 && (u = bb(r[k], h, y));
    }
    let { dehydratedView: d, dehydratedViewIx: f } = Ab(n, t), p = co(r, c, null, { injector: u, dehydratedView: d });
    if (lo(n, p, l, sn(c, d)), kr(p, 2), f > -1 && n[De]?.splice(f, 1), (e === $.Complete || e === $.Error) && Array.isArray(t[Hn])) {
        for (let h of t[Hn])
            h();
        t[Hn] = null;
    }
} x(R.DeferBlockStateEnd); }
function Rb(e, t, n, o, r) { let i = Date.now(), s = r[m], a = ce(s, o); if (t[Bo] === null || t[Bo] <= i) {
    t[Bo] = null;
    let c = Bv(a), l = t[Ai] !== null;
    if (e === $.Loading && c !== null && !l) {
        t[Fn] = e;
        let u = Th(c, t, o, n, r);
        t[Ai] = u;
    }
    else {
        e > $.Loading && l && (t[Ai](), t[Ai] = null, t[Fn] = null), qv(e, t, n, o, r);
        let u = Wl(a, e);
        u !== null && (t[Bo] = i + u, Th(u, t, o, n, r));
    }
}
else
    t[Fn] = e; }
function Th(e, t, n, o, r) { return zv(e, () => { let s = t[Fn]; t[Bo] = null, t[Fn] = null, s !== null && rt(s, n, o); }, r[k]); }
function Mh(e, t) { return e < t; }
function go(e, t) { let n = e[t.index]; rt($.Placeholder, t, n); }
function Nh(e, t, n) { e.loadingPromise.then(() => { e.loadingState === ne.COMPLETE ? rt($.Complete, t, n) : e.loadingState === ne.FAILED && rt($.Error, t, n); }); }
var ql = null;
function Qv(e, t, n, o) { let r = e.consts; n != null && (t.placeholderBlockConfig = de(r, n)), o != null && (t.loadingBlockConfig = de(r, o)), ql === null && (ql = Rb); }
var Bi = "__ngAsyncComponentMetadataFn__";
function kb(e) { return e[Bi] ?? null; }
function Yv(e, t, n) { let o = e; return o[Bi] = () => Promise.all(t()).then(r => (n(...r), o[Bi] = null, r)), o[Bi]; }
function Ad(e, t, n, o) { return Je(() => { let r = e; t !== null && (r.hasOwnProperty("decorators") && r.decorators !== void 0 ? r.decorators.push(...t) : r.decorators = t), n !== null && (r.ctorParameters = n), o !== null && (r.hasOwnProperty("propDecorators") && r.propDecorators !== void 0 ? r.propDecorators = K(K({}, r.propDecorators), o) : r.propDecorators = o); }); }
var Ob = (() => { class e {
    log(n) { console.log(n); }
    warn(n) { console.warn(n); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function Rd(e) { return typeof e == "function" && e[tt] !== void 0; }
function kd(e) { return Rd(e) && typeof e.set == "function"; }
function Ui(e, t) { let n = e[m]; for (let o = E; o < n.bindingStartIndex; o++)
    if (ee(e[o])) {
        let r = e[o];
        if (!(o === n.bindingStartIndex - 1)) {
            let s = n.data[o], a = ce(n, s);
            if (Uv(a)) {
                t.push({ lContainer: r, lView: e, tNode: s, tDetails: a });
                continue;
            }
        }
        re(r[j]) && Ui(r[j], t);
        for (let s = V; s < r.length; s++)
            Ui(r[s], t);
    }
    else
        re(e[o]) && Ui(e[o], t); }
function xb() { return Y("Chrome DevTools profiling"), () => { }; }
function Lb(e) { let t = e.get(Gt), n = e.get(lt), o = Fg(t, n), r = {}; for (let [i, s] of Object.entries(o))
    qM(i) || (r[i] = s); return r; }
var wh = "ng";
function Pb(e, t) { Fb(e, t); }
function Fb(e, t) { if (typeof COMPILED > "u" || !COMPILED) {
    let n = Ie;
    n[wh] ??= {}, n[wh][e] = t;
} }
var Zv = new S(""), Kv = new S(""), Hb = (() => { class e {
    _ngZone;
    registry;
    _isZoneStable = !0;
    _callbacks = [];
    _taskTrackingZone = null;
    _destroyRef;
    constructor(n, o, r) { this._ngZone = n, this.registry = o, up() && (this._destroyRef = I(Po, { optional: !0 }) ?? void 0), Od || (Xv(r), r.addToWindow(o)), this._watchAngularEvents(), n.run(() => { this._taskTrackingZone = typeof Zone > "u" ? null : Zone.current.get("TaskTrackingZone"); }); }
    _watchAngularEvents() { let n = this._ngZone.onUnstable.subscribe({ next: () => { this._isZoneStable = !1; } }), o = this._ngZone.runOutsideAngular(() => this._ngZone.onStable.subscribe({ next: () => { U.assertNotInAngularZone(), queueMicrotask(() => { this._isZoneStable = !0, this._runCallbacksIfReady(); }); } })); this._destroyRef?.onDestroy(() => { n.unsubscribe(), o.unsubscribe(); }); }
    isStable() { return this._isZoneStable && !this._ngZone.hasPendingMacrotasks; }
    _runCallbacksIfReady() { if (this.isStable())
        queueMicrotask(() => { for (; this._callbacks.length !== 0;) {
            let n = this._callbacks.pop();
            clearTimeout(n.timeoutId), n.doneCb();
        } });
    else {
        let n = this.getPendingTasks();
        this._callbacks = this._callbacks.filter(o => o.updateCb && o.updateCb(n) ? (clearTimeout(o.timeoutId), !1) : !0);
    } }
    getPendingTasks() { return this._taskTrackingZone ? this._taskTrackingZone.macroTasks.map(n => ({ source: n.source, creationLocation: n.creationLocation, data: n.data })) : []; }
    addCallback(n, o, r) { let i = -1; o && o > 0 && (i = setTimeout(() => { this._callbacks = this._callbacks.filter(s => s.timeoutId !== i), n(); }, o)), this._callbacks.push({ doneCb: n, timeoutId: i, updateCb: r }); }
    whenStable(n, o, r) { if (r && !this._taskTrackingZone)
        throw new Error('Task tracking zone is required when passing an update callback to whenStable(). Is "zone.js/plugins/task-tracking" loaded?'); this.addCallback(n, o, r), this._runCallbacksIfReady(); }
    registerApplication(n) { this.registry.registerApplication(n, this); }
    unregisterApplication(n) { this.registry.unregisterApplication(n); }
    findProviders(n, o, r) { return []; }
    static \u0275fac = function (o) { return new (o || e)(Pe(U), Pe(Jv), Pe(Kv)); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac });
} return e; })(), Jv = (() => { class e {
    _applications = new Map;
    registerApplication(n, o) { this._applications.set(n, o); }
    unregisterApplication(n) { this._applications.delete(n); }
    unregisterAllApplications() { this._applications.clear(); }
    getTestability(n) { return this._applications.get(n) || null; }
    getAllTestabilities() { return Array.from(this._applications.values()); }
    getAllRootElements() { return Array.from(this._applications.keys()); }
    findTestabilityInTree(n, o = !0) { return Od?.findTestabilityInTree(this, n, o) ?? null; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })();
function Xv(e) { Od = e; }
var Od;
function xd(e) { return !!e && typeof e.then == "function"; }
function eE(e) { return !!e && typeof e.subscribe == "function"; }
var Ld = new S("");
function tE(e) { return nt([{ provide: Ld, multi: !0, useValue: e }]); }
var Pd = (() => { class e {
    resolve;
    reject;
    initialized = !1;
    done = !1;
    donePromise = new Promise((n, o) => { this.resolve = n, this.reject = o; });
    appInits = I(Ld, { optional: !0 }) ?? [];
    injector = I(Te);
    constructor() { }
    runInitializers() { if (this.initialized)
        return; let n = []; for (let r of this.appInits) {
        let i = ci(this.injector, r);
        if (xd(i))
            n.push(i);
        else if (eE(i)) {
            let s = new Promise((a, c) => { i.subscribe({ complete: a, error: c }); });
            n.push(s);
        }
    } let o = () => { this.done = !0, this.resolve(); }; Promise.all(n).then(() => { o(); }).catch(r => { this.reject(r); }), n.length === 0 && o(), this.initialized = !0; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), Fr = new S("");
function Fd() { Xf(() => { let e = ""; throw new _(600, e); }); }
function nE(e) { return e.isBoundToModule; }
var Vb = 10;
function Hd(e, t) { return Array.isArray(t) ? t.reduce(Hd, e) : K(K({}, e), t); }
var xe = (() => { class e {
    _runningTick = !1;
    _destroyed = !1;
    _destroyListeners = [];
    _views = [];
    internalErrorHandler = I(qt);
    afterRenderManager = I($s);
    zonelessEnabled = I(Mn);
    rootEffectScheduler = I(Oc);
    dirtyFlags = 0;
    tracingSnapshot = null;
    allTestViews = new Set;
    autoDetectTestViews = new Set;
    includeAllTestViews = !1;
    afterTick = new Kh;
    get allViews() { return [...(this.includeAllTestViews ? this.allTestViews : this.autoDetectTestViews).keys(), ...this._views]; }
    get destroyed() { return this._destroyed; }
    componentTypes = [];
    components = [];
    internalPendingTask = I(Wt);
    get isStable() { return this.internalPendingTask.hasPendingTasksObservable.pipe(kT(n => !n)); }
    constructor() { I(gn, { optional: !0 }); }
    whenStable() { let n; return new Promise(o => { n = this.isStable.subscribe({ next: r => { r && o(); } }); }).finally(() => { n.unsubscribe(); }); }
    _injector = I(It);
    _rendererFactory = null;
    get injector() { return this._injector; }
    bootstrap(n, o) { return this.bootstrapImpl(n, o); }
    bootstrapImpl(n, o, r = Te.NULL) { return this._injector.get(U).run(() => { x(R.BootstrapComponentStart); let s = n instanceof aa; if (!this._injector.get(Pd).done) {
        let h = "";
        throw new _(405, h);
    } let c; s ? c = n : c = this._injector.get(xr).resolveComponentFactory(n), this.componentTypes.push(c.componentType); let l = nE(c) ? void 0 : this._injector.get(Gn), u = o || c.selector, d = c.create(r, [], u, l), f = d.location.nativeElement, p = d.injector.get(Zv, null); return p?.registerApplication(f), d.onDestroy(() => { this.detachView(d.hostView), zo(this.components, d), p?.unregisterApplication(f); }), this._loadComponent(d), x(R.BootstrapComponentEnd, d), d; }); }
    tick() { this.zonelessEnabled || (this.dirtyFlags |= 1), this._tick(); }
    _tick() { x(R.ChangeDetectionStart), this.tracingSnapshot !== null ? this.tracingSnapshot.run(Us.CHANGE_DETECTION, this.tickImpl) : this.tickImpl(); }
    tickImpl = () => { if (this._runningTick)
        throw x(R.ChangeDetectionEnd), new _(101, !1); let n = L(null); try {
        this._runningTick = !0, this.synchronize();
    }
    finally {
        this._runningTick = !1, this.tracingSnapshot?.dispose(), this.tracingSnapshot = null, L(n), this.afterTick.next(), x(R.ChangeDetectionEnd);
    } };
    synchronize() { this._rendererFactory === null && !this._injector.destroyed && (this._rendererFactory = this._injector.get(cr, null, { optional: !0 })); let n = 0; for (; this.dirtyFlags !== 0 && n++ < Vb;) {
        x(R.ChangeDetectionSyncStart);
        try {
            this.synchronizeOnce();
        }
        finally {
            x(R.ChangeDetectionSyncEnd);
        }
    } }
    synchronizeOnce() { this.dirtyFlags & 16 && (this.dirtyFlags &= -17, this.rootEffectScheduler.flush()); let n = !1; if (this.dirtyFlags & 7) {
        let o = !!(this.dirtyFlags & 1);
        this.dirtyFlags &= -8, this.dirtyFlags |= 8;
        for (let { _lView: r } of this.allViews) {
            if (!o && !ko(r))
                continue;
            let i = o && !this.zonelessEnabled ? 0 : 1;
            dy(r, i), n = !0;
        }
        if (this.dirtyFlags &= -5, this.syncDirtyFlagsWithViews(), this.dirtyFlags & 23)
            return;
    } n || (this._rendererFactory?.begin?.(), this._rendererFactory?.end?.()), this.dirtyFlags & 8 && (this.dirtyFlags &= -9, this.afterRenderManager.execute()), this.syncDirtyFlagsWithViews(); }
    syncDirtyFlagsWithViews() { if (this.allViews.some(({ _lView: n }) => ko(n))) {
        this.dirtyFlags |= 2;
        return;
    }
    else
        this.dirtyFlags &= -8; }
    attachView(n) { let o = n; this._views.push(o), o.attachToAppRef(this); }
    detachView(n) { let o = n; zo(this._views, o), o.detachFromAppRef(); }
    _loadComponent(n) { this.attachView(n.hostView); try {
        this.tick();
    }
    catch (r) {
        this.internalErrorHandler(r);
    } this.components.push(n), this._injector.get(Fr, []).forEach(r => r(n)); }
    ngOnDestroy() { if (!this._destroyed)
        try {
            this._destroyListeners.forEach(n => n()), this._views.slice().forEach(n => n.destroy());
        }
        finally {
            this._destroyed = !0, this._views = [], this._destroyListeners = [];
        } }
    onDestroy(n) { return this._destroyListeners.push(n), () => zo(this._destroyListeners, n); }
    destroy() { if (this._destroyed)
        throw new _(406, !1); let n = this._injector; n.destroy && !n.destroyed && n.destroy(); }
    get viewCount() { return this._views.length; }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function zo(e, t) { let n = e.indexOf(t); n > -1 && e.splice(n, 1); }
function ha() { let e, t; return { promise: new Promise((o, r) => { e = o, t = r; }), resolve: e, reject: t }; }
function oE(e) { let t = g(), n = M(); if (go(t, n), !sE(0, t))
    return; let o = t[k], r = ye(t, n), i = e(() => ve(0, t, n), o); Lr(0, r, i); }
function rE(e) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let t = g(), n = t[k], o = M(), r = t[m], i = ce(r, o); if (i.loadingState === ne.NOT_STARTED) {
    let s = ye(t, o), c = e(() => Hr(i, t, o), n);
    Lr(1, s, c);
} }
function iE(e, t, n) { if (typeof ngServerMode < "u" && ngServerMode)
    return; let o = t[k], r = ye(t, n), i = r[da], s = e(() => ht(o, i), o); Lr(2, r, s); }
function Hr(e, t, n) { ga(e, t, n); }
function ga(e, t, n) { let o = t[k], r = t[m]; if (e.loadingState !== ne.NOT_STARTED)
    return e.loadingPromise ?? Promise.resolve(); let i = ye(t, n), s = Db(r, e); e.loadingState = ne.IN_PROGRESS, ji(1, i); let a = e.dependencyResolverFn, c = o.get(kc).add(); return a ? (e.loadingPromise = Promise.allSettled(a()).then(l => { let u = !1, d = null, f = [], p = []; for (let h = 0; h < l.length; h++) {
    let y = l[h];
    if (y.status === "fulfilled") {
        let v = y.value, D = W(v) || Ne(v);
        if (D)
            f.push(D);
        else {
            let b = Ue(v);
            b && p.push(b);
        }
    }
    else {
        u = !0, d = y.reason instanceof Error ? y.reason : new Error(String(y.reason));
        break;
    }
} if (u) {
    if (e.loadingState = ne.FAILED, e.errorTmplIndex === null) {
        let y = "", v = new _(-750, y);
        od(t, v);
    }
}
else {
    e.loadingState = ne.COMPLETE;
    let h = s.tView;
    if (f.length > 0) {
        h.directiveRegistry = Ch(h.directiveRegistry, f);
        let y = f.map(D => D.type), v = Ka(!1, ...y);
        e.providers = v;
    }
    p.length > 0 && (h.pipeRegistry = Ch(h.pipeRegistry, p));
} }), e.loadingPromise.finally(() => { e.loadingPromise = null, c(); })) : (e.loadingPromise = Promise.resolve().then(() => { e.loadingPromise = null, e.loadingState = ne.COMPLETE, c(); }), e.loadingPromise); }
function sE(e, t) { return !(e === 0 && typeof ngServerMode < "u" && ngServerMode || t[k].get(Wv, null, { optional: !0 })?.behavior === Sd.Manual); }
function ve(e, t, n) { let o = t[m], r = t[n.index]; if (!sE(e, t))
    return; let i = ye(t, n), s = ce(o, n); switch (Vv(i), s.loadingState) {
    case ne.NOT_STARTED:
        rt($.Loading, n, r), ga(s, t, n), s.loadingState === ne.IN_PROGRESS && Nh(s, n, r);
        break;
    case ne.IN_PROGRESS:
        rt($.Loading, n, r), Nh(s, n, r);
        break;
    case ne.COMPLETE:
        rt($.Complete, n, r);
        break;
    case ne.FAILED:
        rt($.Error, n, r);
        break;
    default:
} }
function ht(e, t, n) { return mt(this, null, function* () { let o = e.get(ut); if (o.hydrating.has(t))
    return; let { parentBlockPromise: i, hydrationQueue: s } = nN(t, e); if (s.length === 0)
    return; i !== null && s.shift(), Ub(o, s), i !== null && (yield i); let a = s[0]; o.has(a) ? yield _h(e, s, n) : o.awaitParentBlock(a, () => mt(null, null, function* () { return yield _h(e, s, n); })); }); }
function _h(e, t, n) { return mt(this, null, function* () { let o = e.get(ut), r = o.hydrating, i = e.get(Wt), s = i.add(); for (let c = 0; c < t.length; c++) {
    let l = t[c], u = o.get(l);
    if (u != null) {
        if (yield zb(u), yield $b(e), jb(u)) {
            Y_(u), Sh(t.slice(c), o);
            break;
        }
        r.get(l).resolve();
    }
    else {
        Bb(c, t, o), Sh(t.slice(c), o);
        break;
    }
} let a = t[t.length - 1]; yield r.get(a)?.promise, i.remove(s), n && n(t), Z_(o.get(a), t, o, e.get(xe)); }); }
function jb(e) { return ye(e.lView, e.tNode)[pt] === $.Error; }
function Bb(e, t, n) { let o = e - 1, r = o > -1 ? n.get(t[o]) : null; r && sa(r.lContainer); }
function Sh(e, t) { let n = t.hydrating; for (let o in e)
    n.get(o)?.reject(); t.cleanup(e); }
function Ub(e, t) { for (let n of t)
    e.hydrating.set(n, ha()); }
function $b(e) { return new Promise(t => Qu(t, { injector: e })); }
function zb(e) { return mt(this, null, function* () { let { tNode: t, lView: n } = e, o = ye(n, t); return new Promise(r => { Gb(o, r), ve(2, n, t); }); }); }
function Gb(e, t) { Array.isArray(e[Hn]) || (e[Hn] = []), e[Hn].push(t); }
function Z(e, t, n) { return e === 0 ? bh(t, n) : e === 2 ? !bh(t, n) : !(typeof ngServerMode < "u" && ngServerMode); }
function Wb(e) { return e != null && (e & 1) === 1; }
function bh(e, t) { let n = e[k], o = ce(e[m], t), r = wr(n), i = Wb(o.flags); if (typeof ngServerMode < "u" && ngServerMode)
    return !r || !i; let a = ye(e, t)[da] !== null; return !(i && a && r); }
function xt(e, t) { let n = ce(e, t); return n.hydrateTriggers ??= new Map; }
function aE(e, t, n) { let o = [], r = [], i = [], s = []; for (let [a, c] of t) {
    let l = n.get(a);
    if (l !== void 0) {
        let u = c.data[st], d = l;
        for (let f = 0; f < u; f++) {
            if (d = d.previousSibling, d.nodeType !== Node.ELEMENT_NODE)
                continue;
            let p = { el: d, blockName: a };
            c.hydrate.idle && o.push(p), c.hydrate.immediate && s.push(p), c.hydrate.timer !== null && (p.delay = c.hydrate.timer, r.push(p)), c.hydrate.viewport && (typeof c.hydrate.viewport != "boolean" && (p.intersectionObserverOptions = c.hydrate.viewport), i.push(p));
        }
    }
} qb(e, o), Zb(e, s), Qb(e, i), Yb(e, r); }
function qb(e, t) { for (let n of t) {
    let o = e.get(ut), i = fa(() => ht(e, n.blockName), e);
    o.addCleanupFn(n.blockName, i);
} }
function Qb(e, t) { if (t.length > 0) {
    let n = e.get(ut);
    for (let o of t) {
        let r = bd(o.el, () => ht(e, o.blockName), e, o.intersectionObserverOptions);
        n.addCleanupFn(o.blockName, r);
    }
} }
function Yb(e, t) { for (let n of t) {
    let o = e.get(ut), r = () => ht(e, n.blockName), s = pa(n.delay)(r, e);
    o.addCleanupFn(n.blockName, s);
} }
function Zb(e, t) { for (let n of t)
    ht(e, n.blockName); }
function cE(e, t, n, o, r, i, s, a, c, l) { let u = g(), d = w(), f = e + E, p = ln(u, d, e, null, 0, 0), h = u[k], y = wr(h); if (d.firstCreatePass) {
    Y("NgDefer");
    let Xe = { primaryTmplIndex: t, loadingTmplIndex: o ?? null, placeholderTmplIndex: r ?? null, errorTmplIndex: i ?? null, placeholderBlockConfig: null, loadingBlockConfig: null, dependencyResolverFn: n ?? null, loadingState: ne.NOT_STARTED, loadingPromise: null, providers: null, hydrateTriggers: null, debug: null, flags: l ?? 0 };
    c?.(d, Xe, a, s), Eb(d, f, Xe);
} let v = u[f]; lv(v, p, u); let D = null, b = null; if (v[De]?.length > 0) {
    let Xe = v[De][0].data;
    b = Xe[Ss] ?? null, D = Xe[Tr];
} let X = [null, fr.Initial, null, null, null, null, b, D, null, null]; vb(u, f, X); let Le = null; b !== null && y && (Le = h.get(ut), Le.add(b, { lView: u, tNode: p, lContainer: v })); let Me = () => { Vv(X), b !== null && Le?.cleanup([b]); }; Lr(0, X, () => sc(u, Me)), pi(u, Me); }
function lE(e) { let t = g(), n = Ce(); if (!Z(0, t, n))
    return; let o = he(); if (z(t, o, e)) {
    let r = L(null);
    try {
        let i = !!e, a = ye(t, n)[pt];
        i === !1 && a === fr.Initial ? go(t, n) : i === !0 && (a === fr.Initial || a === $.Placeholder) && ve(0, t, n);
    }
    finally {
        L(r);
    }
} }
function uE(e) { let t = g(), n = Ce(); if (!Z(1, t, n))
    return; let o = he(); if (z(t, o, e)) {
    let r = L(null);
    try {
        let i = !!e, s = t[m], a = ce(s, n);
        i === !0 && a.loadingState === ne.NOT_STARTED && Hr(a, t, n);
    }
    finally {
        L(r);
    }
} }
function dE(e) { let t = g(), n = Ce(); if (!Z(2, t, n))
    return; let o = he(), r = w(); if (xt(r, n).set(6, null), z(t, o, e))
    if (typeof ngServerMode < "u" && ngServerMode)
        ve(2, t, n);
    else {
        let s = t[k], a = L(null);
        try {
            if (!!e === !0) {
                let u = ye(t, n)[da];
                ht(s, u);
            }
        }
        finally {
            L(a);
        }
    } }
function fE() { let e = g(), t = M(); if (!Z(2, e, t))
    return; xt(w(), t).set(7, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function pE() { let e = g(), t = M(); Z(0, e, t) && oE(fa); }
function hE() { let e = g(), t = M(); Z(1, e, t) && rE(fa); }
function gE() { let e = g(), t = M(); if (!Z(2, e, t))
    return; xt(w(), t).set(0, null), typeof ngServerMode < "u" && ngServerMode ? ve(2, e, t) : iE(fa, e, t); }
function mE() { let e = g(), t = M(); if (!Z(0, e, t))
    return; ce(e[m], t).loadingTmplIndex === null && go(e, t), ve(0, e, t); }
function yE() { let e = g(), t = M(); if (!Z(1, e, t))
    return; let n = e[m], o = ce(n, t); o.loadingState === ne.NOT_STARTED && ga(o, e, t); }
function vE() { let e = g(), t = M(); if (!Z(2, e, t))
    return; if (xt(w(), t).set(1, null), typeof ngServerMode < "u" && ngServerMode)
    ve(2, e, t);
else {
    let o = e[k], i = ye(e, t)[da];
    ht(o, i);
} }
function EE(e) { let t = g(), n = M(); Z(0, t, n) && oE(pa(e)); }
function IE(e) { let t = g(), n = M(); Z(1, t, n) && rE(pa(e)); }
function DE(e) { let t = g(), n = M(); if (!Z(2, t, n))
    return; xt(w(), n).set(5, { type: 5, delay: e }), typeof ngServerMode < "u" && ngServerMode ? ve(2, t, n) : iE(pa(e), t, n); }
function CE(e, t) { let n = g(), o = M(); Z(0, n, o) && (go(n, o), typeof ngServerMode < "u" && ngServerMode || ho(n, o, e, t, $g, () => ve(0, n, o), 0)); }
function TE(e, t) { let n = g(), o = M(); if (!Z(1, n, o))
    return; let r = n[m], i = ce(r, o); i.loadingState === ne.NOT_STARTED && ho(n, o, e, t, $g, () => Hr(i, n, o), 1); }
function ME() { let e = g(), t = M(); if (!Z(2, e, t))
    return; xt(w(), t).set(4, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function NE(e, t) { let n = g(), o = M(); Z(0, n, o) && (go(n, o), typeof ngServerMode < "u" && ngServerMode || ho(n, o, e, t, Ug, () => ve(0, n, o), 0)); }
function wE(e, t) { let n = g(), o = M(); if (!Z(1, n, o))
    return; let r = n[m], i = ce(r, o); i.loadingState === ne.NOT_STARTED && ho(n, o, e, t, Ug, () => Hr(i, n, o), 1); }
function _E() { let e = g(), t = M(); if (!Z(2, e, t))
    return; xt(w(), t).set(3, null), typeof ngServerMode < "u" && ngServerMode && ve(2, e, t); }
function SE(e, t, n) { let o = g(), r = M(); Z(0, o, r) && (go(o, r), typeof ngServerMode < "u" && ngServerMode || ho(o, r, e, t, bd, () => ve(0, o, r), 0, n)); }
function bE(e, t, n) { let o = g(), r = M(); if (!Z(1, o, r))
    return; let i = o[m], s = ce(i, r); s.loadingState === ne.NOT_STARTED && ho(o, r, e, t, bd, () => Hr(s, o, r), 1, n); }
function AE(e) { let t = g(), n = M(); if (!Z(2, t, n))
    return; xt(w(), n).set(2, e ? { type: 2, intersectionObserverOptions: e } : null), typeof ngServerMode < "u" && ngServerMode && ve(2, t, n); }
function Vd(e, t) { let n = g(), o = he(); if (z(n, o, t)) {
    let r = w(), i = Ce();
    if (Js(i, r, n, e, t))
        me(i) && iy(n, i.index);
    else {
        let a = ie(i, n);
        Ys(n[T], a, null, i.value, e, t, null);
    }
} return Vd; }
function jd(e, t, n, o) { let r = g(), i = he(); if (z(r, i, t)) {
    let s = w(), a = Ce();
    jw(a, r, e, t, n, o);
} return jd; }
function Go(e) { if (Y("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !hn)
    return Go; let t = g(); if (js(t))
    return Go; let n = M(), o = t[k].get(U); return Bs(ns(t), n, () => Kb(t, n, e, o)), Ws(t[k]), Yu(t[k], ns(t)), Go; }
function Kb(e, t, n, o) { let r = ie(t, e), i = e[T], s = jm(n), a = [], c = !1, l = d => { if (nr(d) !== r)
    return; let f = d instanceof AnimationEvent ? "animationend" : "transitionend"; o.runOutsideAngular(() => { i.listen(r, f, u); }); }, u = d => { nr(d) === r && (Gu(d, r) && (c = !0), Jb(d, r, i)); }; if (s && s.length > 0) {
    o.runOutsideAngular(() => { a.push(i.listen(r, "animationstart", l)), a.push(i.listen(r, "transitionstart", l)); }), pw(r, s, a);
    for (let d of s)
        i.addClass(r, d);
    o.runOutsideAngular(() => { requestAnimationFrame(() => { if (!c && ($m(r, en, hn), !en.has(r))) {
        for (let d of s)
            i.removeClass(r, d);
        $u(r);
    } }); });
} }
function Jb(e, t, n) { let o = Bn.get(t); if (!(nr(e) !== t || !o) && Gu(e, t)) {
    e.stopPropagation();
    for (let r of o.classList)
        n.removeClass(t, r);
    $u(t);
} }
function Wo(e) { if (Y("NgAnimateEnter"), typeof ngServerMode < "u" && ngServerMode || !hn)
    return Wo; let t = g(); if (js(t))
    return Wo; let n = M(); return Bs(ns(t), n, () => Xb(t, n, e)), Ws(t[k]), Yu(t[k], ns(t)), Wo; }
function Xb(e, t, n) { let o = ie(t, e); n.call(e[H], { target: o, animationComplete: hw }); }
function qo(e) { if (Y("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !hn)
    return qo; let t = g(); if (js(t))
    return qo; let o = M(), r = t[k].get(U); return Bs(on(t), o, () => eA(t, o, e, r)), Ws(t[k]), qo; }
function eA(e, t, n, o) { let { promise: r, resolve: i } = ha(), s = ie(t, e), a = e[T]; rn.add(e[Se]), (on(e).get(t.index).resolvers ??= []).push(i); let c = jm(n); return c && c.length > 0 ? tA(s, t, e, c, a, o) : i(), { promise: r, resolve: i }; }
function tA(e, t, n, o, r, i) { mw(e, r); let s = [], a = on(n).get(t.index)?.resolvers, c, l = !1, u = d => { if (!(nr(d) !== e && d.type !== "animation-fallback") && (d.type === "animation-fallback" || Gu(d, e))) {
    if (l = !0, c && clearTimeout(c), d.type !== "animation-fallback" && d.stopPropagation(), en.delete(e), _l(t, e), Array.isArray(t.projection))
        for (let p of o)
            r.removeClass(e, p);
    Sl(a, s), bl(n, t);
} }; i.runOutsideAngular(() => { s.push(r.listen(e, "animationend", u)), s.push(r.listen(e, "transitionend", u)); }), zu(t, e); for (let d of o)
    r.addClass(e, d); i.runOutsideAngular(() => { requestAnimationFrame(() => { if (l)
    return; $m(e, en, hn); let d = en.get(e); d ? (c = setTimeout(() => { u(new CustomEvent("animation-fallback")); }, d.duration + 50), s.push(() => clearTimeout(c))) : (_l(t, e), Sl(a, s), bl(n, t)); }); }); }
function fs(e) { if (Y("NgAnimateLeave"), typeof ngServerMode < "u" && ngServerMode || !hn)
    return fs; let t = g(), n = M(); rn.add(t[Se]); let o = t[k].get(U), r = t[k].get(Vm); return Bs(on(t), n, () => nA(t, n, e, o, r)), Ws(t[k]), fs; }
function nA(e, t, n, o, r) { let { promise: i, resolve: s } = ha(), a = ie(t, e), c = [], l = e[T], u = js(e); (on(e).get(t.index).resolvers ??= []).push(s); let d = on(e).get(t.index)?.resolvers; if (u)
    Si(e, t, a, d, c);
else {
    let f = setTimeout(() => Si(e, t, a, d, c), r), p = { target: a, animationComplete: () => { Si(e, t, a, d, c), clearTimeout(f); } };
    zu(t, a), o.runOutsideAngular(() => { c.push(l.listen(a, "animationend", () => { Si(e, t, a, d, c), clearTimeout(f); }, { once: !0 })); }), n.call(e[H], p);
} return { promise: i, resolve: s }; }
function RE() { return g()[J][H]; }
var Ql = class {
    destroy(t) { }
    updateValue(t, n) { }
    swap(t, n) { let o = Math.min(t, n), r = Math.max(t, n), i = this.detach(r); if (r - o > 1) {
        let s = this.detach(o);
        this.attach(o, i), this.attach(r, s);
    }
    else
        this.attach(o, i); }
    move(t, n) { this.attach(n, this.detach(t)); }
};
function Yc(e, t, n, o, r) { return e === n && Object.is(t, o) ? 1 : Object.is(r(e, t), r(n, o)) ? -1 : 0; }
function oA(e, t, n, o) { let r, i, s = 0, a = e.length - 1, c = void 0; if (Array.isArray(t)) {
    _n(o);
    let l = t.length - 1;
    for (_n(null); s <= a && s <= l;) {
        let u = e.at(s), d = t[s], f = Yc(s, u, s, d, n);
        if (f !== 0) {
            f < 0 && e.updateValue(s, d), s++;
            continue;
        }
        let p = e.at(a), h = t[l], y = Yc(a, p, l, h, n);
        if (y !== 0) {
            y < 0 && e.updateValue(a, h), a--, l--;
            continue;
        }
        let v = n(s, u), D = n(a, p), b = n(s, d);
        if (Object.is(b, D)) {
            let X = n(l, h);
            Object.is(X, v) ? (e.swap(s, a), e.updateValue(a, h), l--, a--) : e.move(a, s), e.updateValue(s, d), s++;
            continue;
        }
        if (r ??= new ps, i ??= Rh(e, s, a, n), Yl(e, r, s, b))
            e.updateValue(s, d), s++, a++;
        else if (i.has(b))
            r.set(v, e.detach(s)), a--;
        else {
            let X = e.create(s, t[s]);
            e.attach(s, X), s++, a++;
        }
    }
    for (; s <= l;)
        Ah(e, r, n, s, t[s]), s++;
}
else if (t != null) {
    _n(o);
    let l = t[Symbol.iterator]();
    _n(null);
    let u = l.next();
    for (; !u.done && s <= a;) {
        let d = e.at(s), f = u.value, p = Yc(s, d, s, f, n);
        if (p !== 0)
            p < 0 && e.updateValue(s, f), s++, u = l.next();
        else {
            r ??= new ps, i ??= Rh(e, s, a, n);
            let h = n(s, f);
            if (Yl(e, r, s, h))
                e.updateValue(s, f), s++, a++, u = l.next();
            else if (!i.has(h))
                e.attach(s, e.create(s, f)), s++, a++, u = l.next();
            else {
                let y = n(s, d);
                r.set(y, e.detach(s)), a--;
            }
        }
    }
    for (; !u.done;)
        Ah(e, r, n, e.length, u.value), u = l.next();
} for (; s <= a;)
    e.destroy(e.detach(a--)); r?.forEach(l => { e.destroy(l); }); }
function Yl(e, t, n, o) { return t !== void 0 && t.has(o) ? (e.attach(n, t.get(o)), t.delete(o), !0) : !1; }
function Ah(e, t, n, o, r) { if (Yl(e, t, o, n(o, r)))
    e.updateValue(o, r);
else {
    let i = e.create(o, r);
    e.attach(o, i);
} }
function Rh(e, t, n, o) { let r = new Set; for (let i = t; i <= n; i++)
    r.add(o(i, e.at(i))); return r; }
var ps = class {
    kvMap = new Map;
    _vMap = void 0;
    has(t) { return this.kvMap.has(t); }
    delete(t) { if (!this.has(t))
        return !1; let n = this.kvMap.get(t); return this._vMap !== void 0 && this._vMap.has(n) ? (this.kvMap.set(t, this._vMap.get(n)), this._vMap.delete(n)) : this.kvMap.delete(t), !0; }
    get(t) { return this.kvMap.get(t); }
    set(t, n) { if (this.kvMap.has(t)) {
        let o = this.kvMap.get(t);
        this._vMap === void 0 && (this._vMap = new Map);
        let r = this._vMap;
        for (; r.has(o);)
            o = r.get(o);
        r.set(o, n);
    }
    else
        this.kvMap.set(t, n); }
    forEach(t) { for (let [n, o] of this.kvMap)
        if (t(o, n), this._vMap !== void 0) {
            let r = this._vMap;
            for (; r.has(o);)
                o = r.get(o), t(o, n);
        } }
};
function kE(e, t, n, o, r, i, s, a) { Y("NgControlFlow"); let c = g(), l = w(), u = de(l.consts, i); return ln(c, l, e, t, n, o, r, u, 256, s, a), ma; }
function ma(e, t, n, o, r, i, s, a) { Y("NgControlFlow"); let c = g(), l = w(), u = de(l.consts, i); return ln(c, l, e, t, n, o, r, u, 512, s, a), ma; }
function OE(e, t) { Y("NgControlFlow"); let n = g(), o = he(), r = n[o] !== P ? n[o] : -1, i = r !== -1 ? hs(n, E + r) : void 0, s = 0; if (z(n, o, e)) {
    let a = L(null);
    try {
        if (i !== void 0 && rd(i, s), e !== -1) {
            let c = E + e, l = hs(n, c), u = Xl(n[m], c), d = Uy(l, u, n), f = co(n, u, t, { dehydratedView: d });
            lo(l, f, s, sn(u, d));
        }
    }
    finally {
        L(a);
    }
}
else if (i !== void 0) {
    let a = yy(i, s);
    a !== void 0 && (a[H] = t);
} }
var Zl = class {
    lContainer;
    $implicit;
    $index;
    constructor(t, n, o) { this.lContainer = t, this.$implicit = n, this.$index = o; }
    get $count() { return this.lContainer.length - V; }
};
function xE(e) { return e; }
function LE(e, t) { return t; }
var Kl = class {
    hasEmptyBlock;
    trackByFn;
    liveCollection;
    constructor(t, n, o) { this.hasEmptyBlock = t, this.trackByFn = n, this.liveCollection = o; }
};
function PE(e, t, n, o, r, i, s, a, c, l, u, d, f) { Y("NgControlFlow"); let p = g(), h = w(), y = c !== void 0, v = g(), D = a ? s.bind(v[J][H]) : s, b = new Kl(y, D); v[E + e] = b, ln(p, h, e + 1, t, n, o, r, de(h.consts, i), 256), y && ln(p, h, e + 2, c, l, u, d, de(h.consts, f), 512); }
var Jl = class extends Ql {
    lContainer;
    hostLView;
    templateTNode;
    operationsCounter = void 0;
    needsIndexUpdate = !1;
    constructor(t, n, o) { super(), this.lContainer = t, this.hostLView = n, this.templateTNode = o; }
    get length() { return this.lContainer.length - V; }
    at(t) { return this.getLView(t)[H].$implicit; }
    attach(t, n) { let o = n[ae]; this.needsIndexUpdate ||= t !== this.length, lo(this.lContainer, n, t, sn(this.templateTNode, o)), rA(this.lContainer, t); }
    detach(t) { return this.needsIndexUpdate ||= t !== this.length - 1, iA(this.lContainer, t), sA(this.lContainer, t); }
    create(t, n) { let o = ar(this.lContainer, this.templateTNode.tView.ssrId); return co(this.hostLView, this.templateTNode, new Zl(this.lContainer, n, t), { dehydratedView: o }); }
    destroy(t) { Rr(t[m], t); }
    updateValue(t, n) { this.getLView(t)[H].$implicit = n; }
    reset() { this.needsIndexUpdate = !1; }
    updateIndexes() { if (this.needsIndexUpdate)
        for (let t = 0; t < this.length; t++)
            this.getLView(t)[H].$index = t; }
    getLView(t) { return aA(this.lContainer, t); }
};
function FE(e) { let t = L(null), n = te(); try {
    let o = g(), r = o[m], i = o[n], s = n + 1, a = hs(o, s);
    if (i.liveCollection === void 0) {
        let l = Xl(r, s);
        i.liveCollection = new Jl(a, o, l);
    }
    else
        i.liveCollection.reset();
    let c = i.liveCollection;
    if (oA(c, e, i.trackByFn, t), c.updateIndexes(), i.hasEmptyBlock) {
        let l = he(), u = c.length === 0;
        if (z(o, l, u)) {
            let d = n + 2, f = hs(o, d);
            if (u) {
                let p = Xl(r, d), h = Uy(f, p, o), y = co(o, p, void 0, { dehydratedView: h });
                lo(f, y, 0, sn(p, h));
            }
            else
                r.firstUpdatePass && ia(f), rd(f, 0);
        }
    }
}
finally {
    L(t);
} }
function hs(e, t) { return e[t]; }
function rA(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n], r = o ? o[Ge] : void 0; if (o && r && r.detachedLeaveAnimationFns && r.detachedLeaveAnimationFns.length > 0) {
    let i = o[k];
    Tw(i, r), rn.delete(o[Se]), r.detachedLeaveAnimationFns = void 0;
} }
function iA(e, t) { if (e.length <= V)
    return; let n = V + t, o = e[n], r = o ? o[Ge] : void 0; r && r.leave && r.leave.size > 0 && (r.detachedLeaveAnimationFns = []); }
function sA(e, t) { return rr(e, t); }
function aA(e, t) { return yy(e, t); }
function Xl(e, t) { return $t(e, t); }
function Bd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ce();
    ed(s, o, e, t, o[T], n);
} return Bd; }
function eu(e, t, n, o, r) { Js(t, e, n, r ? "class" : "style", o); }
function pr(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? ud(s, r, 2, t, nd, hi(), n, o) : i.data[s]; if (me(a)) {
    let c = r[$e].tracingService;
    if (c && c.componentCreate) {
        let l = i.data[a.directiveStart + a.componentOffset];
        return c.componentCreate(pd(l), () => (kh(e, t, r, a, o), pr));
    }
} return kh(e, t, r, a, o), pr; }
function kh(e, t, n, o, r) { if (Zs(o, n, e, t, zd), Cn(o)) {
    let i = n[m];
    Qs(i, n, o), Su(i, o, n);
} r != null && ao(n, o); }
function ya() { let e = w(), t = M(), n = Ks(t); return e.firstCreatePass && dd(e, n), cc(n) && dc(), ac(), n.classesWithoutHost != null && $T(n) && eu(e, n, g(), n.classesWithoutHost, !0), n.stylesWithoutHost != null && zT(n) && eu(e, n, g(), n.stylesWithoutHost, !1), ya; }
function Ud(e, t, n, o) { return pr(e, t, n, o), ya(), Ud; }
function va(e, t, n, o) { let r = g(), i = r[m], s = e + E, a = i.firstCreatePass ? Yy(s, i, 2, t, n, o) : i.data[s]; return Zs(a, r, e, t, zd), o != null && ao(r, a), va; }
function Ea() { let e = M(), t = Ks(e); return cc(t) && dc(), ac(), Ea; }
function $d(e, t, n, o) { return va(e, t, n, o), Ea(), $d; }
var zd = (e, t, n, o, r) => (Ve(!0), Ps(t[T], o, Ei()));
function cA(e, t, n, o, r) { let i = !xs(t, n); if (Ve(i), i)
    return Ps(t[T], o, Ei()); let s = t[ae], a = Or(s, e, t, n); return rm(s, r) && ks(s, r, a.nextSibling), s && (du(n) || wg(a)) && me(n) && (Cp(n), wm(a)), a; }
function HE() { zd = cA; }
function Ia(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? ud(i, o, 8, "ng-container", nd, hi(), t, n) : r.data[i]; if (Zs(s, o, e, "ng-container", Qd), Cn(s)) {
    let a = o[m];
    Qs(a, o, s), Su(a, s, o);
} return n != null && ao(o, s), Ia; }
function Vr() { let e = w(), t = M(), n = Ks(t); return e.firstCreatePass && dd(e, n), Vr; }
function Gd(e, t, n) { return Ia(e, t, n), Vr(), Gd; }
function Da(e, t, n) { let o = g(), r = o[m], i = e + E, s = r.firstCreatePass ? Yy(i, r, 8, "ng-container", t, n) : r.data[i]; return Zs(s, o, e, "ng-container", Qd), n != null && ao(o, s), Da; }
function Wd() { let e = M(), t = Ks(e); return Vr; }
function qd(e, t, n) { return Da(e, t, n), Wd(), qd; }
var Qd = (e, t, n, o, r) => (Ve(!0), Ru(t[T], ""));
function lA(e, t, n, o, r) { let i, s = !xs(t, n); if (Ve(s), s)
    return Ru(t[T], ""); let a = t[ae], c = Or(a, e, t, n), l = om(a, r); return ks(a, r, c), i = oa(l, c), i; }
function VE() { Qd = lA; }
function jE() { return g(); }
function Yd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ce();
    td(s, o, e, t, o[T], n);
} return Yd; }
function Zd(e, t, n) { let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ce(), a = gi(i.data), c = sy(a, s, o);
    td(s, o, e, t, c, n);
} return Zd; }
var Ho = void 0;
function uA(e) { let t = Math.floor(Math.abs(e)), n = e.toString().replace(/^[^.]*\.?/, "").length; return t === 1 && n === 0 ? 1 : 5; }
var dA = ["en", [["a", "p"], ["AM", "PM"]], [["AM", "PM"]], [["S", "M", "T", "W", "T", "F", "S"], ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"], ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"], ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"]], Ho, [["J", "F", "M", "A", "M", "J", "J", "A", "S", "O", "N", "D"], ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"], ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]], Ho, [["B", "A"], ["BC", "AD"], ["Before Christ", "Anno Domini"]], 0, [6, 0], ["M/d/yy", "MMM d, y", "MMMM d, y", "EEEE, MMMM d, y"], ["h:mm\u202Fa", "h:mm:ss\u202Fa", "h:mm:ss\u202Fa z", "h:mm:ss\u202Fa zzzz"], ["{1}, {0}", Ho, Ho, Ho], [".", ",", ";", "%", "+", "-", "E", "\xD7", "\u2030", "\u221E", "NaN", ":"], ["#,##0.###", "#,##0%", "\xA4#,##0.00", "#E0"], "USD", "$", "US Dollar", {}, "ltr", uA], Vn = Object.create(null);
function fA(e, t, n) { typeof t != "string" && (n = t, t = e[Qn.LocaleId]), t = t.toLowerCase().replace(/_/g, "-"), Vn[t] = e, n && (Vn[t][Qn.ExtraData] = n); }
function Kd(e) { let t = gA(e), n = Oh(t); if (n)
    return n; let o = t.split("-")[0]; if (n = Oh(o), n)
    return n; if (o === "en")
    return dA; throw new _(701, !1); }
function pA(e) { return Kd(e)[Qn.CurrencyCode] || null; }
function BE(e) { return Kd(e)[Qn.PluralCase]; }
function Oh(e) { return e in Vn || (Vn[e] = Ie.ng && Ie.ng.common && Ie.ng.common.locales && Ie.ng.common.locales[e]), Vn[e]; }
function hA() { Vn = Object.create(null); }
var Qn = (function (e) { return e[e.LocaleId = 0] = "LocaleId", e[e.DayPeriodsFormat = 1] = "DayPeriodsFormat", e[e.DayPeriodsStandalone = 2] = "DayPeriodsStandalone", e[e.DaysFormat = 3] = "DaysFormat", e[e.DaysStandalone = 4] = "DaysStandalone", e[e.MonthsFormat = 5] = "MonthsFormat", e[e.MonthsStandalone = 6] = "MonthsStandalone", e[e.Eras = 7] = "Eras", e[e.FirstDayOfWeek = 8] = "FirstDayOfWeek", e[e.WeekendRange = 9] = "WeekendRange", e[e.DateFormat = 10] = "DateFormat", e[e.TimeFormat = 11] = "TimeFormat", e[e.DateTimeFormat = 12] = "DateTimeFormat", e[e.NumberSymbols = 13] = "NumberSymbols", e[e.NumberFormats = 14] = "NumberFormats", e[e.CurrencyCode = 15] = "CurrencyCode", e[e.CurrencySymbol = 16] = "CurrencySymbol", e[e.CurrencyName = 17] = "CurrencyName", e[e.Currencies = 18] = "Currencies", e[e.Directionality = 19] = "Directionality", e[e.PluralCase = 20] = "PluralCase", e[e.ExtraData = 21] = "ExtraData", e; })(Qn || {});
function gA(e) { return e.toLowerCase().replace(/_/g, "-"); }
var mA = ["zero", "one", "two", "few", "many"];
function yA(e, t) { let n = BE(t)(parseInt(e, 10)), o = mA[n]; return o !== void 0 ? o : "other"; }
var jr = "en-US", vA = "USD", UE = { marker: "element" }, $E = { marker: "ICU" }, ot = (function (e) { return e[e.SHIFT = 2] = "SHIFT", e[e.APPEND_EAGERLY = 1] = "APPEND_EAGERLY", e[e.COMMENT = 2] = "COMMENT", e; })(ot || {}), zE = jr;
function GE(e) { typeof e == "string" && (zE = e.toLowerCase().replace(/_/g, "-")); }
function EA() { return zE; }
var hr = 0, Qo = 0;
function IA(e) { e && (hr = hr | 1 << Math.min(Qo, 31)), Qo++; }
function DA(e, t, n) { try {
    if (Qo > 0) {
        let o = e.data[n], r = Array.isArray(o) ? o : o.update, i = Qe() - Qo - 1;
        YE(e, t, r, i, hr);
    }
}
finally {
    hr = 0, Qo = 0;
} }
function WE(e, t, n) { let o = e[T]; switch (n) {
    case Node.COMMENT_NODE: return Ru(o, t);
    case Node.TEXT_NODE: return Au(o, t);
    case Node.ELEMENT_NODE: return Ps(o, t, null);
} }
var Yo = (e, t, n, o) => (Ve(!0), WE(e, n, o));
function CA(e, t, n, o) { let r = e[ae], i = t - E, s = !ra() || !r || Oo() || Os(r, i); return Ve(s), s ? WE(e, n, o) : wy(r, i); }
function qE() { Yo = CA; }
function TA(e, t, n, o) { let r = e[T]; for (let i = 0; i < t.length; i++) {
    let s = t[i++], a = t[i], c = (s & ot.COMMENT) === ot.COMMENT, l = (s & ot.APPEND_EAGERLY) === ot.APPEND_EAGERLY, u = s >>> ot.SHIFT, d = e[u], f = !1;
    d === null && (d = e[u] = Yo(e, u, a, c ? Node.COMMENT_NODE : Node.TEXT_NODE), f = Lo()), l && n !== null && f && nn(r, n, d, o, !1);
} }
function QE(e, t, n, o) { let r = n[T], i = null, s; for (let a = 0; a < t.length; a++) {
    let c = t[a];
    if (typeof c == "string") {
        let l = t[++a];
        n[l] === null && (n[l] = Yo(n, l, c, Node.TEXT_NODE));
    }
    else if (typeof c == "number")
        switch (c & 1) {
            case 0:
                let l = w_(c);
                i === null && (i = l, s = r.parentNode(o));
                let u, d;
                if (l === i ? (u = o, d = s) : (u = null, d = O(n[l])), d !== null) {
                    let y = __(c), v = n[y];
                    nn(r, d, v, u, !1);
                    let D = Uo(e, y);
                    if (D !== null && typeof D == "object") {
                        let b = na(D, n);
                        b !== null && QE(e, D.create[b], n, n[D.anchorIdx]);
                    }
                }
                break;
            case 1:
                let f = c >>> 1, p = t[++a], h = t[++a];
                Ys(r, Ut(f, n), null, null, p, h, null);
                break;
            default:
        }
    else
        switch (c) {
            case $E:
                let l = t[++a], u = t[++a];
                if (n[u] === null) {
                    let p = n[u] = Yo(n, u, l, Node.COMMENT_NODE);
                    Re(p, n);
                }
                break;
            case UE:
                let d = t[++a], f = t[++a];
                if (n[f] === null) {
                    let p = n[f] = Yo(n, f, d, Node.ELEMENT_NODE);
                    Re(p, n);
                }
                break;
            default:
        }
} }
function YE(e, t, n, o, r) { for (let i = 0; i < n.length; i++) {
    let s = n[i], a = n[++i];
    if (s & r) {
        let c = "";
        for (let l = i + 1; l <= i + a; l++) {
            let u = n[l];
            if (typeof u == "string")
                c += u;
            else if (typeof u == "number")
                if (u < 0)
                    c += N(t[o - u]);
                else {
                    let d = u >>> 2;
                    switch (u & 3) {
                        case 1:
                            let f = n[++l], p = n[++l], h = e.data[d];
                            if (typeof h == "string")
                                Ys(t[T], t[d], null, h, f, c, p);
                            else {
                                let v = te();
                                Ze(d);
                                try {
                                    ed(h, t, f, c, t[T], p);
                                }
                                finally {
                                    Ze(v);
                                }
                            }
                            break;
                        case 0:
                            let y = t[d];
                            y !== null && Mm(t[T], y, c);
                            break;
                        case 2:
                            MA(e, Uo(e, d), t, c);
                            break;
                        case 3:
                            xh(e, Uo(e, d), o, t);
                            break;
                    }
                }
        }
    }
    else {
        let c = n[i + 1];
        if (c > 0 && (c & 3) === 3) {
            let l = c >>> 2, u = Uo(e, l);
            t[u.currentCaseLViewIndex] < 0 && xh(e, u, o, t);
        }
    }
    i += a;
} }
function xh(e, t, n, o) { let r = o[t.currentCaseLViewIndex]; if (r !== null) {
    let i = hr;
    r < 0 && (r = o[t.currentCaseLViewIndex] = ~r, i = -1), YE(e, o, t.update[r], n, i);
} }
function MA(e, t, n, o) { let r = NA(t, o); if (na(t, n) !== r && (ZE(e, t, n), n[t.currentCaseLViewIndex] = r === null ? null : ~r, r !== null)) {
    let s = n[t.anchorIdx];
    s && QE(e, t.create[r], n, s), G_(n, t.anchorIdx, r);
} }
function ZE(e, t, n) { let o = na(t, n); if (o !== null) {
    let r = t.remove[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i];
        if (s > 0) {
            let a = Ut(s, n);
            a !== null && Sr(n[T], a);
        }
        else
            ZE(e, Uo(e, ~s), n);
    }
} }
function NA(e, t) { let n = e.cases.indexOf(t); if (n === -1)
    switch (e.type) {
        case 1: {
            let o = yA(t, EA());
            n = e.cases.indexOf(o), n === -1 && o !== "other" && (n = e.cases.indexOf("other"));
            break;
        }
        case 0: {
            n = e.cases.indexOf("other");
            break;
        }
    } return n === -1 ? null : n; }
var gs = /�(\d+):?\d*�/gi, wA = /({\s*�\d+:?\d*�\s*,\s*\S{6}\s*,[\s\S]*})/gi, _A = /�(\d+)�/, KE = /^\s*(�\d+:?\d*�)\s*,\s*(select|plural)\s*,/, Zo = "\uFFFD", SA = /�\/?\*(\d+:\d+)�/gi, bA = /�(\/?[#*]\d+):?\d*�/gi, AA = /\uE500/g;
function RA(e) { return e.replace(AA, " "); }
function kA(e, t, n, o, r, i) { let s = Tn(), a = [], c = [], l = [[]], u = [[]]; r = PA(r, i); let d = RA(r).split(bA); for (let f = 0; f < d.length; f++) {
    let p = d[f];
    if ((f & 1) === 0) {
        let h = tu(p);
        for (let y = 0; y < h.length; y++) {
            let v = h[y];
            if ((y & 1) === 0) {
                let D = v;
                D !== "" && OA(u[0], e, s, l[0], a, c, n, D);
            }
            else {
                let D = v;
                if (typeof D != "object")
                    throw new Error(`Unable to parse ICU expression in "${r}" message.`);
                let X = JE(e, s, l[0], n, a, "", !0).index;
                eI(u[0], e, n, c, t, D, X);
            }
        }
    }
    else {
        let h = p.charCodeAt(0) === 47, y = p.charCodeAt(h ? 1 : 0), v = E + Number.parseInt(p.substring(h ? 2 : 1));
        if (h)
            l.shift(), u.shift(), qe(Tn(), !1);
        else {
            let D = N_(e, l[0], v);
            l.unshift([]), qe(D, !0);
            let b = { kind: 2, index: v, children: [], type: y === 35 ? 0 : 1 };
            u[0].push(b), u.unshift(b.children);
        }
    }
} e.data[o] = { create: a, update: c, ast: u[0], parentTNodeIndex: t }; }
function JE(e, t, n, o, r, i, s) { let a = Ar(e, o, 1, null), c = a << ot.SHIFT, l = Tn(); t === l && (l = null), l === null && (c |= ot.APPEND_EAGERLY), s && (c |= ot.COMMENT, uw(b_)), r.push(c, i === null ? "" : i); let u = id(e, a, s ? 32 : 1, i === null ? "" : i, null); Cy(n, u); let d = u.index; return qe(u, !1), l !== null && t !== l && M_(l, d), u; }
function OA(e, t, n, o, r, i, s, a) { let c = a.match(gs), u = JE(t, n, o, s, r, c ? null : a, !1).index; c && ms(i, a, u, null, 0, null), e.push({ kind: 0, index: u }); }
function xA(e, t, n) { let o = M(), r = o.index, i = []; if (e.firstCreatePass && e.data[t] === null) {
    for (let s = 0; s < n.length; s += 2) {
        let a = n[s], c = n[s + 1];
        if (c !== "") {
            if (wA.test(c))
                throw new Error(`ICU expressions are not supported in attributes. Message: "${c}".`);
            let l = o.namespace ? `:${o.namespace}:${o.value}` : o.value;
            ms(i, c, r, a, LA(i), nu(a, l));
        }
    }
    e.data[t] = i;
} }
function ms(e, t, n, o, r, i) { let s = e.length, a = s + 1; e.push(null, null); let c = s + 2, l = t.split(gs), u = 0; for (let d = 0; d < l.length; d++) {
    let f = l[d];
    if (d & 1) {
        let p = r + parseInt(f, 10);
        e.push(-1 - p), u = u | XE(p);
    }
    else
        f !== "" && e.push(f);
} return e.push(n << 2 | (o ? 1 : 0)), o && e.push(o, i), e[s] = u, e[a] = e.length - c, u; }
function LA(e) { let t = 0; for (let n = 0; n < e.length; n++) {
    let o = e[n];
    typeof o == "number" && o < 0 && t++;
} return t; }
function XE(e) { return 1 << Math.min(e, 31); }
function Lh(e) { let t, n = "", o = 0, r = !1, i; for (; (t = SA.exec(e)) !== null;)
    r ? t[0] === `${Zo}/*${i}${Zo}` && (o = t.index, r = !1) : (n += e.substring(o, t.index + t[0].length), i = t[1], r = !0); return n += e.slice(o), n; }
function PA(e, t) { if (My(t))
    return Lh(e); {
    let n = e.indexOf(`:${t}${Zo}`) + 2 + t.toString().length, o = e.search(new RegExp(`${Zo}\\/\\*\\d+:${t}${Zo}`));
    return Lh(e.substring(n, o));
} }
function eI(e, t, n, o, r, i, s) { let a = 0, c = { type: i.type, currentCaseLViewIndex: Ar(t, n, 1, null), anchorIdx: s, cases: [], create: [], remove: [], update: [] }; jA(o, i, s), T_(t, s, c); let l = i.values, u = []; for (let d = 0; d < l.length; d++) {
    let f = l[d], p = [];
    for (let y = 0; y < f.length; y++) {
        let v = f[y];
        if (typeof v != "string") {
            let D = p.push(v) - 1;
            f[y] = `<!--\uFFFD${D}\uFFFD-->`;
        }
    }
    let h = [];
    u.push(h), a = HA(h, t, c, n, o, r, i.cases[d], f.join(""), p) | a;
} a && BA(o, a, s), e.push({ kind: 3, index: s, cases: u, currentCaseLViewIndex: c.currentCaseLViewIndex }); }
function FA(e) { let t = [], n = [], o = 1, r = 0; e = e.replace(KE, function (s, a, c) { return c === "select" ? o = 0 : o = 1, r = parseInt(a.slice(1), 10), ""; }); let i = tu(e); for (let s = 0; s < i.length;) {
    let a = i[s++].trim();
    o === 1 && (a = a.replace(/\s*(?:=)?(\w+)\s*/, "$1")), a.length && t.push(a);
    let c = tu(i[s++]);
    t.length > n.length && n.push(c);
} return { type: o, mainBinding: r, cases: t, values: n }; }
function tu(e) { if (!e)
    return []; let t = 0, n = [], o = [], r = /[{}]/g; r.lastIndex = 0; let i; for (; i = r.exec(e);) {
    let a = i.index;
    if (i[0] == "}") {
        if (n.pop(), n.length == 0) {
            let c = e.substring(t, a);
            KE.test(c) ? o.push(FA(c)) : o.push(c), t = a + 1;
        }
    }
    else {
        if (n.length == 0) {
            let c = e.substring(t, a);
            o.push(c), t = a + 1;
        }
        n.push("{");
    }
} let s = e.substring(t); return o.push(s), o; }
function HA(e, t, n, o, r, i, s, a, c) { let l = [], u = [], d = []; n.cases.push(s), n.create.push(l), n.remove.push(u), n.update.push(d); let p = ym(Ms()).getInertBodyElement(a), h = Nl(p) || p; return h ? tI(e, t, n, o, r, l, u, d, h, i, c, 0) : 0; }
function tI(e, t, n, o, r, i, s, a, c, l, u, d) { let f = 0, p = c.firstChild; for (; p;) {
    let h = Ar(t, o, 1, null);
    switch (p.nodeType) {
        case Node.ELEMENT_NODE:
            let y = p, v = y.tagName.toLowerCase();
            if (Cl.hasOwnProperty(v)) {
                Zc(i, UE, v, l, h), t.data[h] = v;
                let Le = y.attributes;
                for (let Xe = 0; Xe < Le.length; Xe++) {
                    let Pt = Le.item(Xe), Gr = Pt.name.toLowerCase(), oT = !!Pt.value.match(gs), Yf = y.namespaceURI, Zf = Yf === "http://www.w3.org/2000/svg" ? `:svg:${v}` : Yf === "http://www.w3.org/1998/Math/MathML" ? `:math:${v}` : v;
                    if (oT)
                        Tl.hasOwnProperty(Gr) && ms(a, Pt.value, h, Pt.name, 0, nu(Gr, Zf));
                    else if (Tl[Gr]) {
                        let rT = Pt.value;
                        nu(Gr, Zf) ? Fh(i, h, Pt.name, "unsafe:blocked") : Fh(i, h, Pt.name, rT);
                    }
                }
                let Me = { kind: 1, index: h, children: [] };
                e.push(Me), f = tI(Me.children, t, n, o, r, i, s, a, p, h, u, d + 1) | f, Ph(s, h, d);
            }
            break;
        case Node.TEXT_NODE:
            let D = p.textContent || "", b = D.match(gs);
            Zc(i, null, b ? "" : D, l, h), Ph(s, h, d), b && (f = ms(a, D, h, null, 0, null) | f), e.push({ kind: 0, index: h });
            break;
        case Node.COMMENT_NODE:
            let X = _A.exec(p.textContent || "");
            if (X) {
                let Le = parseInt(X[1], 10), Me = u[Le];
                Zc(i, $E, "", l, h), eI(e, t, o, r, l, Me, h), VA(s, h, d);
            }
            break;
    }
    p = p.nextSibling;
} return f; }
function Ph(e, t, n) { n === 0 && e.push(t); }
function VA(e, t, n) { n === 0 && (e.push(~t), e.push(t)); }
function jA(e, t, n) { e.push(XE(t.mainBinding), 2, -1 - t.mainBinding, n << 2 | 2); }
function BA(e, t, n) { e.push(t, 1, n << 2 | 3); }
function Zc(e, t, n, o, r) { t !== null && e.push(t), e.push(n, r, S_(0, o, r)); }
function Fh(e, t, n, o) { e.push(t << 1 | 1, n, o); }
function UA(e, t = !0) { if (e[0] != ":")
    return [null, e]; let n = e.indexOf(":", 1); if (n === -1) {
    if (t)
        throw new Error(`Unsupported format "${e}" expecting ":namespace:name"`);
    return [null, e];
} return [e.slice(1, n), e.slice(n + 1)]; }
function $A(e) { let t = e.toLowerCase(), [n, o] = UA(t, !1); return n === oc || n === rc ? `:${n}:${o}` : o; }
function nu(e, t) { let n = e.toLowerCase(), o = t ? $A(t) : "*", r = zN(); switch (r[`${o}|${n}`] || r[`*|${n}`] || Q.NONE) {
    case Q.HTML: return ku;
    case Q.STYLE: return Ou;
    case Q.SCRIPT: return Lu;
    case Q.URL: return Ls;
    case Q.RESOURCE_URL: return Fs;
    case Q.ATTRIBUTE_NO_BINDING: return Pu;
    default: return null;
} }
var Hh = 0, zA = /\[(�.+?�?)\]/, GA = /\[(�.+?�?)\]|(�\/?\*\d+:\d+�)/g, WA = /({\s*)(VAR_(PLURAL|SELECT)(_\d+)?)(\s*,)/g, qA = /{([A-Z0-9_]+)}/g, QA = /�I18N_EXP_(ICU(_\d+)?)�/g, YA = /\/\*/, ZA = /\d+\:(\d+)/;
function KA(e, t = {}) { let n = e; if (zA.test(e)) {
    let o = {}, r = [Hh];
    n = n.replace(GA, (i, s, a) => { let c = s || a, l = o[c] || []; if (l.length || (c.split("|").forEach(y => { let v = y.match(ZA), D = v ? parseInt(v[1], 10) : Hh, b = YA.test(y); l.push([D, b, y]); }), o[c] = l), !l.length)
        throw new Error(`i18n postprocess: unmatched placeholder - ${c}`); let u = r[r.length - 1], d = 0; for (let y = 0; y < l.length; y++)
        if (l[y][0] === u) {
            d = y;
            break;
        } let [f, p, h] = l[d]; return p ? r.pop() : u !== f && r.push(f), l.splice(d, 1), h; });
} return Object.keys(t).length && (n = n.replace(WA, (o, r, i, s, a, c) => t.hasOwnProperty(i) ? `${r}${t[i]}${c}` : o), n = n.replace(qA, (o, r) => t.hasOwnProperty(r) ? t[r] : o), n = n.replace(QA, (o, r) => { if (t.hasOwnProperty(r)) {
    let i = t[r];
    if (!i.length)
        throw new Error(`i18n postprocess: unmatched ICU - ${o} with key: ${r}`);
    return i.shift();
} return o; })), n; }
function Jd(e, t, n = -1) { let o = w(), r = g(), i = E + e, s = de(o.consts, t), a = Tn(); if (o.firstCreatePass && kA(o, a === null ? 0 : a.index, r, i, s, n), o.type === 2) {
    let f = r[J];
    f[A] |= 32;
}
else
    r[A] |= 32; let c = o.data[i], l = a === r[ue] ? null : a, u = Ym(o, l, r), d = a && a.type & 8 ? r[a.index] : null; V_(r, i, a, n), TA(r, c.create, u, d), Ic(!0); }
function Xd() { Ic(!1); }
function nI(e, t, n) { Jd(e, t, n), Xd(); }
function oI(e, t) { let n = w(), o = de(n.consts, t); xA(n, e + E, o); }
function ef(e) { let t = g(); return IA(z(t, he(), e)), ef; }
function rI(e) { DA(w(), g(), e + E); }
function iI(e, t = {}) { return KA(e, t); }
function tf(e, t, n) { let o = g(), r = w(), i = M(); return rf(r, o, o[T], i, e, t, n), tf; }
function nf(e, t) { let n = M(), o = g(), r = w(), i = gi(r.data), s = sy(i, n, o); return rf(r, o, s, n, e, t), nf; }
function of(e, t, n) { let o = g(), r = w(), i = M(); return (i.type & 3 || n) && fd(i, r, o, n, o[T], e, t, Rt(i, o, t)), of; }
function rf(e, t, n, o, r, i, s) { let a = !0, c = null; if ((o.type & 3 || s) && (c ??= Rt(o, t, i), fd(o, e, t, s, n, r, i, c) && (a = !1)), a) {
    let l = o.outputs?.[r], u = o.hostDirectiveOutputs?.[r];
    if (u && u.length)
        for (let d = 0; d < u.length; d += 2) {
            let f = u[d], p = u[d + 1];
            c ??= Rt(o, t, i), zn(o, t, f, p, r, c);
        }
    if (l && l.length)
        for (let d of l)
            c ??= Rt(o, t, i), zn(o, t, d, r, r, c);
} }
function sI(e = 1) { return _p(e); }
function JA(e, t) { let n = null, o = tw(e); for (let r = 0; r < t.length; r++) {
    let i = t[r];
    if (i === "*") {
        n = r;
        continue;
    }
    if (o === null ? xm(e, i, !0) : rw(o, i))
        return r;
} return n; }
function aI(e) { let t = g()[J][ue]; if (!t.projection) {
    let n = e ? e.length : 1, o = t.projection = Mo(n, null), r = o.slice(), i = t.child;
    for (; i !== null;) {
        if (i.type !== 128) {
            let s = e ? JA(i, e) : 0;
            s !== null && (r[s] ? r[s].projectionNext = i : o[s] = i, r[s] = i);
        }
        i = i.next;
    }
} }
function cI(e, t = 0, n, o, r, i) { let s = g(), a = w(), c = o ? e + 1 : null; c !== null && ln(s, a, c, o, r, i, null, n); let l = mn(a, E + e, 16, null, n || null); l.projection === null && (l.projection = t), gc(); let d = !s[ae] || Oo(); s[J][ue].projection[l.projection] === null && c !== null ? XA(s, a, c) : d && !ro(l) && Aw(a, s, l); }
function XA(e, t, n) { let o = E + n, r = t.data[o], i = e[o], s = ar(i, r.tView.ssrId), a = co(e, r, void 0, { dehydratedView: s }); lo(i, a, 0, sn(r, s)); }
function sf(e, t, n, o) { return gv(e, t, n, o), sf; }
function af(e, t, n) { return hv(e, t, n), af; }
function lI(e) { let t = g(), n = w(), o = mi(); xo(o + 1); let r = md(n, o); if (e.dirty && pp(t) === ((r.metadata.flags & 2) === 2)) {
    if (r.matches === null)
        e.reset([]);
    else {
        let i = yv(t, o);
        e.reset(i, Ng), e.notifyOnChanges();
    }
    return !0;
} return !1; }
function uI() { return gd(g(), mi()); }
function cf(e, t, n, o, r) { return vv(t, gv(e, n, o, r)), cf; }
function lf(e, t, n, o) { return vv(e, hv(t, n, o)), lf; }
function dI(e = 1) { xo(mi() + e); }
function fI(e) { let t = mc(); return Mt(t, E + e); }
function Ri(e, t) { return e << 17 | t << 2; }
function un(e) { return e >> 17 & 32767; }
function eR(e) { return (e & 2) == 2; }
function tR(e, t) { return e & 131071 | t << 17; }
function ou(e) { return e | 2; }
function Yn(e) { return (e & 131068) >> 2; }
function Kc(e, t) { return e & -131069 | t << 2; }
function nR(e) { return (e & 1) === 1; }
function ru(e) { return e | 1; }
function oR(e, t, n, o, r, i) { let s = i ? t.classBindings : t.styleBindings, a = un(s), c = Yn(s); e[o] = n; let l = !1, u; if (Array.isArray(n)) {
    let d = n;
    u = d[1], (u === null || ii(d, u) > 0) && (l = !0);
}
else
    u = n; if (r)
    if (c !== 0) {
        let f = un(e[a + 1]);
        e[o + 1] = Ri(f, a), f !== 0 && (e[f + 1] = Kc(e[f + 1], o)), e[a + 1] = tR(e[a + 1], o);
    }
    else
        e[o + 1] = Ri(a, 0), a !== 0 && (e[a + 1] = Kc(e[a + 1], o)), a = o;
else
    e[o + 1] = Ri(c, 0), a === 0 ? a = o : e[c + 1] = Kc(e[c + 1], o), c = o; l && (e[o + 1] = ou(e[o + 1])), Vh(e, u, o, !0), Vh(e, u, o, !1), rR(t, u, e, o, i), s = Ri(a, c), i ? t.classBindings = s : t.styleBindings = s; }
function rR(e, t, n, o, r) { let i = r ? e.residualClasses : e.residualStyles; i != null && typeof t == "string" && ii(i, t) >= 0 && (n[o + 1] = ru(n[o + 1])); }
function Vh(e, t, n, o) { let r = e[n + 1], i = t === null, s = o ? un(r) : Yn(r), a = !1; for (; s !== 0 && (a === !1 || i);) {
    let c = e[s], l = e[s + 1];
    iR(c, t) && (a = !0, e[s + 1] = o ? ru(l) : ou(l)), s = o ? un(l) : Yn(l);
} a && (e[n + 1] = o ? ou(r) : ru(r)); }
function iR(e, t) { return e === null || t == null || (Array.isArray(e) ? e[1] : e) === t ? !0 : Array.isArray(e) && typeof t == "string" ? ii(e, t) >= 0 : !1; }
var se = { textEnd: 0, key: 0, keyEnd: 0, value: 0, valueEnd: 0 };
function pI(e) { return e.substring(se.key, se.keyEnd); }
function sR(e) { return e.substring(se.value, se.valueEnd); }
function aR(e) { return mI(e), hI(e, Zn(e, 0, se.textEnd)); }
function hI(e, t) { let n = se.textEnd; return n === t ? -1 : (t = se.keyEnd = lR(e, se.key = t, n), Zn(e, t, n)); }
function cR(e) { return mI(e), gI(e, Zn(e, 0, se.textEnd)); }
function gI(e, t) { let n = se.textEnd, o = se.key = Zn(e, t, n); return n === o ? -1 : (o = se.keyEnd = uR(e, o, n), o = jh(e, o, n, 58), o = se.value = Zn(e, o, n), o = se.valueEnd = dR(e, o, n), jh(e, o, n, 59)); }
function mI(e) { se.key = 0, se.keyEnd = 0, se.value = 0, se.valueEnd = 0, se.textEnd = e.length; }
function Zn(e, t, n) { for (; t < n && e.charCodeAt(t) <= 32;)
    t++; return t; }
function lR(e, t, n) { for (; t < n && e.charCodeAt(t) > 32;)
    t++; return t; }
function uR(e, t, n) { let o; for (; t < n && ((o = e.charCodeAt(t)) === 45 || o === 95 || (o & -33) >= 65 && (o & -33) <= 90 || o >= 48 && o <= 57);)
    t++; return t; }
function jh(e, t, n, o) { return t = Zn(e, t, n), t < n && t++, t; }
function dR(e, t, n) { let o = -1, r = -1, i = -1, s = t, a = s; for (; s < n;) {
    let c = e.charCodeAt(s++);
    if (c === 59)
        return a;
    c === 34 || c === 39 ? a = s = Bh(e, c, s, n) : t === s - 4 && i === 85 && r === 82 && o === 76 && c === 40 ? a = s = Bh(e, 41, s, n) : c > 32 && (a = s), i = r, r = o, o = c & -33;
} return a; }
function Bh(e, t, n, o) { let r = -1, i = n; for (; i < o;) {
    let s = e.charCodeAt(i++);
    if (s == t && r !== 92)
        return i;
    s == 92 && r === 92 ? r = 0 : r = s;
} throw new Error; }
function uf(e, t, n) { return EI(e, t, n, !1), uf; }
function df(e, t) { return EI(e, t, null, !0), df; }
function yI(e) { II(TI, fR, e, !1); }
function fR(e, t) { for (let n = cR(t); n >= 0; n = gI(t, n))
    TI(e, pI(t), sR(t)); }
function vI(e) { II(ER, pR, e, !0); }
function pR(e, t) { for (let n = aR(t); n >= 0; n = hI(t, n))
    No(e, pI(t), !0); }
function EI(e, t, n, o) { let r = g(), i = w(), s = Ye(2); if (i.firstUpdatePass && CI(i, e, s, o), t !== P && z(r, s, t)) {
    let a = i.data[te()];
    MI(i, a, r, r[T], e, r[s + 1] = DR(t, n), o, s);
} }
function II(e, t, n, o) { let r = w(), i = Ye(2); r.firstUpdatePass && CI(r, null, i, o); let s = g(); if (n !== P && z(s, i, n)) {
    let a = r.data[te()];
    if (NI(a, o) && !DI(r, i)) {
        let c = o ? a.classesWithoutHost : a.stylesWithoutHost;
        c !== null && (n = Kr(c, n || "")), eu(r, a, s, n, o);
    }
    else
        IR(r, a, s, s[T], s[i + 1], s[i + 1] = vR(e, t, n), o, i);
} }
function DI(e, t) { return t >= e.expandoStartIndex; }
function CI(e, t, n, o) { let r = e.data; if (r[n + 1] === null) {
    let i = r[te()], s = DI(e, n);
    NI(i, o) && t === null && !s && (t = !1), t = hR(r, i, t, o), oR(r, i, t, n, s, o);
} }
function hR(e, t, n, o) { let r = gi(e), i = o ? t.residualClasses : t.residualStyles; if (r === null)
    (o ? t.classBindings : t.styleBindings) === 0 && (n = Jc(null, e, t, n, o), n = gr(n, t.attrs, o), i = null);
else {
    let s = t.directiveStylingLast;
    if (s === -1 || e[s] !== r)
        if (n = Jc(r, e, t, n, o), i === null) {
            let c = gR(e, t, o);
            c !== void 0 && Array.isArray(c) && (c = Jc(null, e, t, c[1], o), c = gr(c, t.attrs, o), mR(e, t, o, c));
        }
        else
            i = yR(e, t, o);
} return i !== void 0 && (o ? t.residualClasses = i : t.residualStyles = i), n; }
function gR(e, t, n) { let o = n ? t.classBindings : t.styleBindings; if (Yn(o) !== 0)
    return e[un(o)]; }
function mR(e, t, n, o) { let r = n ? t.classBindings : t.styleBindings; e[un(r)] = o; }
function yR(e, t, n) { let o, r = t.directiveEnd; for (let i = 1 + t.directiveStylingLast; i < r; i++) {
    let s = e[i].hostAttrs;
    o = gr(o, s, n);
} return gr(o, t.attrs, n); }
function Jc(e, t, n, o, r) { let i = null, s = n.directiveEnd, a = n.directiveStylingLast; for (a === -1 ? a = n.directiveStart : a++; a < s && (i = t[a], o = gr(o, i.hostAttrs, r), i !== e);)
    a++; return e !== null && (n.directiveStylingLast = a), o; }
function gr(e, t, n) { let o = n ? 1 : 2, r = -1; if (t !== null)
    for (let i = 0; i < t.length; i++) {
        let s = t[i];
        typeof s == "number" ? r = s : r === o && (Array.isArray(e) || (e = e === void 0 ? [] : ["", e]), No(e, s, n ? !0 : t[++i]));
    } return e === void 0 ? null : e; }
function vR(e, t, n) { if (n == null || n === "")
    return F; let o = [], r = dt(n); if (Array.isArray(r))
    for (let i = 0; i < r.length; i++)
        e(o, r[i], !0);
else if (r instanceof Set)
    for (let i of r)
        e(o, i, !0);
else if (typeof r == "object")
    for (let i in r)
        r.hasOwnProperty(i) && e(o, i, r[i]);
else
    typeof r == "string" && t(o, r); return o; }
function TI(e, t, n) { No(e, t, dt(n)); }
function ER(e, t, n) { let o = String(t); o !== "" && !o.includes(" ") && No(e, o, n); }
function IR(e, t, n, o, r, i, s, a) { r === P && (r = F); let c = 0, l = 0, u = 0 < r.length ? r[0] : null, d = 0 < i.length ? i[0] : null; for (; u !== null || d !== null;) {
    let f = c < r.length ? r[c + 1] : void 0, p = l < i.length ? i[l + 1] : void 0, h = null, y;
    u === d ? (c += 2, l += 2, f !== p && (h = d, y = p)) : d === null || u !== null && u < d ? (c += 2, h = u) : (l += 2, h = d, y = p), h !== null && MI(e, t, n, o, h, y, s, a), u = c < r.length ? r[c] : null, d = l < i.length ? i[l] : null;
} }
function MI(e, t, n, o, r, i, s, a) { if (!(t.type & 3))
    return; let c = e.data, l = c[a + 1], u = nR(l) ? Uh(c, t, n, r, Yn(l), s) : void 0; if (!ys(u)) {
    ys(i) || eR(l) && (i = Uh(c, null, n, r, a, s));
    let d = Ut(te(), n);
    kw(o, s, d, r, i);
} }
function Uh(e, t, n, o, r, i) { let s = t === null, a; for (; r > 0;) {
    let c = e[r], l = Array.isArray(c), u = l ? c[1] : c, d = u === null, f = n[r + 1];
    f === P && (f = d ? F : void 0);
    let p = d ? ri(f, o) : u === o ? f : void 0;
    if (l && !ys(p) && (p = ri(c, o)), ys(p) && (a = p, s))
        return a;
    let h = e[r + 1];
    r = s ? un(h) : Yn(h);
} if (t !== null) {
    let c = i ? t.residualClasses : t.residualStyles;
    c != null && (a = ri(c, o));
} return a; }
function ys(e) { return e !== void 0; }
function DR(e, t) { return e == null || e === "" || (typeof t == "string" ? e = e + t : typeof e == "object" && (e = Zr(dt(e)))), e; }
function NI(e, t) { return (e.flags & (t ? 8 : 16)) !== 0; }
function wI(e, t = "") { let n = g(), o = w(), r = e + E, i = o.firstCreatePass ? mn(o, r, 1, t, null) : o.data[r], s = _I(o, n, i, t); n[r] = s, Lo() && Ju(o, n, s, i), qe(i, !1); }
var _I = (e, t, n, o) => (Ve(!0), Au(t[T], o));
function CR(e, t, n, o) { let r = !xs(t, n); if (Ve(r), r)
    return Au(t[T], o); let i = t[ae]; return Or(i, e, t, n); }
function SI() { _I = CR; }
function bI(e, t) { let n = !1, o = Qe(); for (let i = 1; i < t.length; i += 2)
    n = z(e, o++, t[i]) || n; if (Ec(o), !n)
    return P; let r = t[0]; for (let i = 1; i < t.length; i += 2)
    r += N(t[i]) + (i + 1 !== t.length ? t[i + 1] : ""); return r; }
function AI(e, t, n, o = "") { return z(e, he(), n) ? t + N(n) + o : P; }
function RI(e, t, n, o, r, i = "") { let s = Qe(), a = an(e, s, n, r); return Ye(2), a ? t + N(n) + o + N(r) + i : P; }
function kI(e, t, n, o, r, i, s, a = "") { let c = Qe(), l = la(e, c, n, r, s); return Ye(3), l ? t + N(n) + o + N(r) + i + N(s) + a : P; }
function OI(e, t, n, o, r, i, s, a, c, l = "") { let u = Qe(), d = Oe(e, u, n, r, s, c); return Ye(4), d ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l : P; }
function xI(e, t, n, o, r, i, s, a, c, l, u, d = "") { let f = Qe(), p = Oe(e, f, n, r, s, c); return p = z(e, f + 4, u) || p, Ye(5), p ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d : P; }
function LI(e, t, n, o, r, i, s, a, c, l, u, d, f, p = "") { let h = Qe(), y = Oe(e, h, n, r, s, c); return y = an(e, h + 4, u, f) || y, Ye(6), y ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p : P; }
function PI(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y = "") { let v = Qe(), D = Oe(e, v, n, r, s, c); return D = la(e, v + 4, u, f, h) || D, Ye(7), D ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p + N(h) + y : P; }
function FI(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v, D = "") { let b = Qe(), X = Oe(e, b, n, r, s, c); return X = Oe(e, b + 4, u, f, h, v) || X, Ye(8), X ? t + N(n) + o + N(r) + i + N(s) + a + N(c) + l + N(u) + d + N(f) + p + N(h) + y + N(v) + D : P; }
function ff(e) { return Ca("", e), ff; }
function Ca(e, t, n) { let o = g(), r = AI(o, e, t, n); return r !== P && gt(o, te(), r), Ca; }
function pf(e, t, n, o, r) { let i = g(), s = RI(i, e, t, n, o, r); return s !== P && gt(i, te(), s), pf; }
function hf(e, t, n, o, r, i, s) { let a = g(), c = kI(a, e, t, n, o, r, i, s); return c !== P && gt(a, te(), c), hf; }
function gf(e, t, n, o, r, i, s, a, c) { let l = g(), u = OI(l, e, t, n, o, r, i, s, a, c); return u !== P && gt(l, te(), u), gf; }
function mf(e, t, n, o, r, i, s, a, c, l, u) { let d = g(), f = xI(d, e, t, n, o, r, i, s, a, c, l, u); return f !== P && gt(d, te(), f), mf; }
function yf(e, t, n, o, r, i, s, a, c, l, u, d, f) { let p = g(), h = LI(p, e, t, n, o, r, i, s, a, c, l, u, d, f); return h !== P && gt(p, te(), h), yf; }
function vf(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h) { let y = g(), v = PI(y, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); return v !== P && gt(y, te(), v), vf; }
function Ef(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v) { let D = g(), b = FI(D, e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v); return b !== P && gt(D, te(), b), Ef; }
function If(e) { let t = g(), n = bI(t, e); return n !== P && gt(t, te(), n), If; }
function gt(e, t, n) { let o = Ut(t, e); Mm(e[T], o, n); }
function Df(e, t, n) { kd(t) && (t = t()); let o = g(), r = he(); if (z(o, r, t)) {
    let i = w(), s = Ce();
    ed(s, o, e, t, o[T], n);
} return Df; }
function HI(e, t) { let n = kd(e); return n && e.set(t), n; }
function Cf(e, t) { let n = g(), o = w(), r = M(); return rf(o, n, n[T], r, e, t), Cf; }
var VI = {};
function Tf(e) { Y("NgLet"); let t = w(), n = g(), o = e + E, r = mn(t, o, 128, null, null); return qe(r, !1), Ro(t, n, o, VI), Tf; }
function jI(e) { let t = w(), n = g(), o = te(); return Ro(t, n, o, e), e; }
function BI(e) { let t = mc(), n = Mt(t, E + e); if (n === VI)
    throw new _(314, !1); return n; }
function UI(e, t) { let n = w(), o = g(), r = o[T], i = "data-ng-source-location"; for (let [s, a, c, l] of t) {
    let u = $t(n, s + E), d = Ut(s + E, o);
    if (!d.hasAttribute(i)) {
        let f = `${e}@o:${a},l:${c},c:${l}`;
        r.setAttribute(d, i, f);
    }
} }
function $I(e) { return z(g(), he(), e) ? N(e) : P; }
function zI(e, t, n = "") { return AI(g(), e, t, n); }
function GI(e, t, n, o, r = "") { return RI(g(), e, t, n, o, r); }
function WI(e, t, n, o, r, i, s = "") { return kI(g(), e, t, n, o, r, i, s); }
function qI(e, t, n, o, r, i, s, a, c = "") { return OI(g(), e, t, n, o, r, i, s, a, c); }
function QI(e, t, n, o, r, i, s, a, c, l, u = "") { return xI(g(), e, t, n, o, r, i, s, a, c, l, u); }
function YI(e, t, n, o, r, i, s, a, c, l, u, d, f = "") { return LI(g(), e, t, n, o, r, i, s, a, c, l, u, d, f); }
function ZI(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h = "") { return PI(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h); }
function KI(e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v = "") { return FI(g(), e, t, n, o, r, i, s, a, c, l, u, d, f, p, h, y, v); }
function JI(e) { return bI(g(), e); }
function XI(e, t, n) { let o = fe() + e, r = g(); return r[o] === P ? Be(r, o, t(n, r)) : po(r, o); }
function $h(e, t, n) { let o = w(); o.firstCreatePass && eD(t, o.data, o.blueprint, Ae(e), n); }
function eD(e, t, n, o, r) { if (e = G(e), Array.isArray(e))
    for (let i = 0; i < e.length; i++)
        eD(e[i], t, n, o, r);
else {
    let i = w(), s = g(), a = M(), c = si(e) ? e : G(e.provide), l = lp(e), u = a.providerIndexes & 1048575, d = a.directiveStart, f = a.providerIndexes >> 20;
    if (si(e) || !e.multi) {
        let p = new tn(l, r, fo, null), h = el(c, t, r ? u : u + f, d);
        h === -1 ? (sl(Yi(a, s), i, c), Xc(i, e, t.length), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(p), s.push(p)) : (n[h] = p, s[h] = p);
    }
    else {
        let p = el(c, t, u + f, d), h = el(c, t, u, u + f), y = p >= 0 && n[p], v = h >= 0 && n[h];
        if (r && !v || !r && !y) {
            sl(Yi(a, s), i, c);
            let D = NR(r ? MR : TR, n.length, r, o, l, e);
            !r && v && (n[h].providerFactory = D), Xc(i, e, t.length, 0), t.push(c), a.directiveStart++, a.directiveEnd++, r && (a.providerIndexes += 1048576), n.push(D), s.push(D);
        }
        else {
            let D = tD(n[r ? h : p], l, !r && o);
            Xc(i, e, p > -1 ? p : h, D);
        }
        !r && o && v && n[h].componentProviders++;
    }
} }
function Xc(e, t, n, o) { let r = si(t), i = ap(t); if (r || i) {
    let c = (i ? G(t.useClass) : t).prototype.ngOnDestroy;
    if (c) {
        let l = e.destroyHooks || (e.destroyHooks = []);
        if (!r && t.multi) {
            let u = l.indexOf(n);
            u === -1 ? l.push(n, [o, c]) : l[u + 1].push(o, c);
        }
        else
            l.push(n, c);
    }
} }
function tD(e, t, n) { return n && e.componentProviders++, e.multi.push(t) - 1; }
function el(e, t, n, o) { for (let r = n; r < o; r++)
    if (t[r] === e)
        return r; return -1; }
function TR(e, t, n, o, r) { return iu(this.multi, []); }
function MR(e, t, n, o, r) { let i = this.multi, s; if (this.providerFactory) {
    let a = this.providerFactory.componentProviders, c = Jo(o, o[m], this.providerFactory.index, r);
    s = c.slice(0, a), iu(i, s);
    for (let l = a; l < c.length; l++)
        s.push(c[l]);
}
else
    s = [], iu(i, s); return s; }
function iu(e, t) { for (let n = 0; n < e.length; n++) {
    let o = e[n];
    t.push(o());
} return t; }
function NR(e, t, n, o, r, i) { let s = new tn(e, n, fo, null); return s.multi = [], s.index = t, s.componentProviders = 0, tD(s, r, o && !n), s; }
function nD(e, t) { return n => { n.providersResolver = (o, r) => $h(o, r ? r(e) : e, !1), t && (n.viewProvidersResolver = (o, r) => $h(o, r ? r(t) : t, !0)); }; }
function oD(e) { return t => { e.length < 1 || (t.getExternalStyles = n => e.map(r => r + "?ngcomp" + (n ? "=" + encodeURIComponent(n) : "") + "&e=" + t.encapsulation)); }; }
function rD(e, t, n) { let o = e.\u0275cmp; o.directiveDefs = ds(t, _v), o.pipeDefs = ds(n, Ue); }
function iD(e, t) { return Je(() => { let n = ti(e); n.declarations = ki(t.declarations || F), n.imports = ki(t.imports || F), n.exports = ki(t.exports || F), t.bootstrap && (n.bootstrap = ki(t.bootstrap)), $n.registerNgModule(e, t); }); }
function ki(e) { if (typeof e == "function")
    return e; let t = Fe(e); return t.some(Jr) ? () => t.map(G).map(zh) : t.map(zh); }
function zh(e) { return ld(e) ? e.ngModule : e; }
function sD(e, t) { let n = fe() + e, o = g(); return o[n] === P ? Be(o, n, t()) : po(o, n); }
function aD(e, t, n) { return mD(g(), fe(), e, t, n); }
function cD(e, t, n, o) { return yD(g(), fe(), e, t, n, o); }
function lD(e, t, n, o, r) { return vD(g(), fe(), e, t, n, o, r); }
function uD(e, t, n, o, r, i, s) { return ED(g(), fe(), e, t, n, o, r, i); }
function dD(e, t, n, o, r, i, s) { let a = fe() + e, c = g(), l = Oe(c, a, n, o, r, i); return z(c, a + 4, s) || l ? Be(c, a + 5, t(n, o, r, i, s)) : po(c, a + 5); }
function fD(e, t, n, o, r, i, s, a) { let c = fe() + e, l = g(), u = Oe(l, c, n, o, r, i); return an(l, c + 4, s, a) || u ? Be(l, c + 6, t(n, o, r, i, s, a)) : po(l, c + 6); }
function pD(e, t, n, o, r, i, s, a, c) { let l = fe() + e, u = g(), d = Oe(u, l, n, o, r, i); return la(u, l + 4, s, a, c) || d ? Be(u, l + 7, t(n, o, r, i, s, a, c)) : po(u, l + 7); }
function hD(e, t, n, o, r, i, s, a, c, l) { let u = fe() + e, d = g(), f = Oe(d, u, n, o, r, i); return Oe(d, u + 4, s, a, c, l) || f ? Be(d, u + 8, t(n, o, r, i, s, a, c, l)) : po(d, u + 8); }
function gD(e, t, n) { return ID(g(), fe(), e, t, n); }
function Br(e, t) { let n = e[t]; return n === P ? void 0 : n; }
function mD(e, t, n, o, r, i) { let s = t + n; return z(e, s, r) ? Be(e, s + 1, i ? o.call(i, r) : o(r)) : Br(e, s + 1); }
function yD(e, t, n, o, r, i, s) { let a = t + n; return an(e, a, r, i) ? Be(e, a + 2, s ? o.call(s, r, i) : o(r, i)) : Br(e, a + 2); }
function vD(e, t, n, o, r, i, s, a) { let c = t + n; return la(e, c, r, i, s) ? Be(e, c + 3, a ? o.call(a, r, i, s) : o(r, i, s)) : Br(e, c + 3); }
function ED(e, t, n, o, r, i, s, a, c) { let l = t + n; return Oe(e, l, r, i, s, a) ? Be(e, l + 4, c ? o.call(c, r, i, s, a) : o(r, i, s, a)) : Br(e, l + 4); }
function ID(e, t, n, o, r, i) { let s = t + n, a = !1; for (let c = 0; c < r.length; c++)
    z(e, s++, r[c]) && (a = !0); return a ? Be(e, s, o.apply(i, r)) : Br(e, s); }
function DD(e, t) { let n = w(), o, r = e + E; n.firstCreatePass ? (o = wR(t, n.pipeRegistry), n.data[r] = o, o.onDestroy && (n.destroyHooks ??= []).push(r, o.onDestroy)) : o = n.data[r]; let i = o.factory || (o.factory = oi(o.type, !0)), s, a = Ht(fo); try {
    let c = Qi(!1), l = i();
    return Qi(c), Ro(n, g(), r, l), l;
}
finally {
    Ht(a);
} }
function wR(e, t) { if (t)
    for (let n = t.length - 1; n >= 0; n--) {
        let o = t[n];
        if (e === o.name)
            return o;
    } }
function CD(e, t, n) { let o = e + E, r = g(), i = Mt(r, o); return Ur(r, o) ? mD(r, fe(), t, i.transform, n, i) : i.transform(n); }
function TD(e, t, n, o) { let r = e + E, i = g(), s = Mt(i, r); return Ur(i, r) ? yD(i, fe(), t, s.transform, n, o, s) : s.transform(n, o); }
function MD(e, t, n, o, r) { let i = e + E, s = g(), a = Mt(s, i); return Ur(s, i) ? vD(s, fe(), t, a.transform, n, o, r, a) : a.transform(n, o, r); }
function ND(e, t, n, o, r, i) { let s = e + E, a = g(), c = Mt(a, s); return Ur(a, s) ? ED(a, fe(), t, c.transform, n, o, r, i, c) : c.transform(n, o, r, i); }
function wD(e, t, n) { let o = e + E, r = g(), i = Mt(r, o); return Ur(r, o) ? ID(r, fe(), t, i.transform, n, i) : i.transform.apply(i, n); }
function Ur(e, t) { return e[m].data[t].pure; }
function _D(e, t) { return ta(e, t); }
function SD(e, t) { return () => { try {
    return $n.getComponentDependencies(e, t).dependencies;
}
catch (n) {
    throw console.error(`Computing dependencies in local compilation mode for the component "${e.name}" failed with the exception:`, n), n;
} }; }
function bD(e, t) { let n = W(e); n !== null && (n.debugInfo = t); }
function AD(e, t, n) { let o = `./@ng/component?c=${e}&t=${encodeURIComponent(t)}`; return new URL(o, n).href; }
function RD(e, t, n, o, r = null, i = null) { let s = W(e); t.apply(null, [e, n, ...o]); let { newDef: a, oldDef: c } = _R(s, W(e)); if (e[yt] = a, c.tView) {
    let l = gM().values();
    for (let u of l)
        We(u) && u[q] === null && $i(r, i, a, c, u);
} }
function _R(e, t) { let n = K({}, e); return { newDef: Object.assign(e, t, { directiveDefs: n.directiveDefs, pipeDefs: n.pipeDefs, setInput: n.setInput, type: n.type }), oldDef: n }; }
function $i(e, t, n, o, r) { let i = r[m]; if (i === o.tView) {
    bR(e, t, n, o, r);
    return;
} for (let s = E; s < i.bindingStartIndex; s++) {
    let a = r[s];
    if (ee(a)) {
        re(a[j]) && $i(e, t, n, o, a[j]);
        for (let c = V; c < a.length; c++)
            $i(e, t, n, o, a[c]);
    }
    else
        re(a) && $i(e, t, n, o, a);
} }
function SR(e, t) { e.componentReplaced?.(t.id); }
function bR(e, t, n, o, r) { let i = r[H], s = r[j], a = r[q], c = r[ue], l = r[k].get(U, null), u = () => { if (o.encapsulation === ke.ShadowDom || o.encapsulation === ke.ExperimentalIsolatedShadowDom) {
    let h = s.cloneNode(!1);
    s.replaceWith(h), s = h;
} let d = Lm(n), f = Hs(a, d, i, ju(n), s, c, null, null, null, null, null); AR(a, r, f, c.index), Rr(r[m], r), sr(r); let p = r[$e].rendererFactory; SR(p, o), f[T] = p.createRenderer(s, n), qm(r[m], r), RR(c), Xs(d, f, i), fy(d, f, d.template, i); }; l === null ? Gh(e, t, u) : l.run(() => Gh(e, t, u)); }
function Gh(e, t, n) {
    try {
        n();
    }
    catch (o) {
        let r = o;
        if (t !== null && r.message) {
            let i = r.message + (r.stack ? `
` + r.stack : "");
            e?.hot?.send?.("angular:invalidate", { id: t, message: i, error: !0 });
        }
        throw o;
    }
}
function AR(e, t, n, o) { for (let r = E; r < e[m].bindingStartIndex; r++) {
    let i = e[r];
    if ((re(i) || ee(i)) && i[le] === t) {
        i[le] = n;
        break;
    }
} e[Dt] === t && (e[Dt] = n), e[wo] === t && (e[wo] = n), n[le] = t[le], t[le] = null, e[o] = n; }
function RR(e) { if (e.projection !== null) {
    for (let t of e.projection)
        Es(t) && (t.projectionNext = null, t.flags &= -3);
    e.projection = null;
} }
var ge = { \u0275\u0275animateEnter: Go, \u0275\u0275animateEnterListener: Wo, \u0275\u0275animateLeave: qo, \u0275\u0275animateLeaveListener: fs, \u0275\u0275attribute: jd, \u0275\u0275defineComponent: wv, \u0275\u0275defineDirective: Sv, \u0275\u0275defineInjectable: B, \u0275\u0275defineInjector: Do, \u0275\u0275defineNgModule: Md, \u0275\u0275definePipe: bv, \u0275\u0275directiveInject: fo, \u0275\u0275getInheritedFactory: Dg, \u0275\u0275inject: Pe, \u0275\u0275injectAttribute: Is, \u0275\u0275invalidFactory: Wy, \u0275\u0275invalidFactoryDep: ni, \u0275\u0275templateRefExtractor: _D, \u0275\u0275resetView: pc, \u0275\u0275HostDirectivesFeature: Ov, \u0275\u0275NgOnChangesFeature: ig, \u0275\u0275ControlFeature: kv, \u0275\u0275ProvidersFeature: nD, \u0275\u0275InheritDefinitionFeature: Nd, \u0275\u0275ExternalStylesFeature: oD, \u0275\u0275nextContext: sI, \u0275\u0275namespaceHTML: wc, \u0275\u0275namespaceMathML: Nc, \u0275\u0275namespaceSVG: Mc, \u0275\u0275enableBindings: lc, \u0275\u0275disableBindings: uc, \u0275\u0275elementStart: pr, \u0275\u0275elementEnd: ya, \u0275\u0275element: Ud, \u0275\u0275elementContainerStart: Ia, \u0275\u0275elementContainerEnd: Vr, \u0275\u0275domElement: $d, \u0275\u0275domElementStart: va, \u0275\u0275domElementEnd: Ea, \u0275\u0275domElementContainer: qd, \u0275\u0275domElementContainerStart: Da, \u0275\u0275domElementContainerEnd: Wd, \u0275\u0275domTemplate: _d, \u0275\u0275domListener: of, \u0275\u0275elementContainer: Gd, \u0275\u0275pureFunction0: sD, \u0275\u0275pureFunction1: aD, \u0275\u0275pureFunction2: cD, \u0275\u0275pureFunction3: lD, \u0275\u0275pureFunction4: uD, \u0275\u0275pureFunction5: dD, \u0275\u0275pureFunction6: fD, \u0275\u0275pureFunction7: pD, \u0275\u0275pureFunction8: hD, \u0275\u0275pureFunctionV: gD, \u0275\u0275getCurrentView: jE, \u0275\u0275restoreView: fc, \u0275\u0275listener: tf, \u0275\u0275projection: cI, \u0275\u0275syntheticHostProperty: Zd, \u0275\u0275syntheticHostListener: nf, \u0275\u0275pipeBind1: CD, \u0275\u0275pipeBind2: TD, \u0275\u0275pipeBind3: MD, \u0275\u0275pipeBind4: ND, \u0275\u0275pipeBindV: wD, \u0275\u0275projectionDef: aI, \u0275\u0275domProperty: Yd, \u0275\u0275ariaProperty: Vd, \u0275\u0275property: Bd, \u0275\u0275control: tv, \u0275\u0275controlCreate: Xy, \u0275\u0275pipe: DD, \u0275\u0275queryRefresh: lI, \u0275\u0275queryAdvance: dI, \u0275\u0275viewQuery: af, \u0275\u0275viewQuerySignal: lf, \u0275\u0275loadQuery: uI, \u0275\u0275contentQuery: sf, \u0275\u0275contentQuerySignal: cf, \u0275\u0275reference: fI, \u0275\u0275classMap: vI, \u0275\u0275styleMap: yI, \u0275\u0275styleProp: uf, \u0275\u0275classProp: df, \u0275\u0275advance: Pm, \u0275\u0275template: wd, \u0275\u0275conditional: OE, \u0275\u0275conditionalCreate: kE, \u0275\u0275conditionalBranchCreate: ma, \u0275\u0275defer: cE, \u0275\u0275deferWhen: lE, \u0275\u0275deferOnIdle: pE, \u0275\u0275deferOnImmediate: mE, \u0275\u0275deferOnTimer: EE, \u0275\u0275deferOnHover: CE, \u0275\u0275deferOnInteraction: NE, \u0275\u0275deferOnViewport: SE, \u0275\u0275deferPrefetchWhen: uE, \u0275\u0275deferPrefetchOnIdle: hE, \u0275\u0275deferPrefetchOnImmediate: yE, \u0275\u0275deferPrefetchOnTimer: IE, \u0275\u0275deferPrefetchOnHover: TE, \u0275\u0275deferPrefetchOnInteraction: wE, \u0275\u0275deferPrefetchOnViewport: bE, \u0275\u0275deferHydrateWhen: dE, \u0275\u0275deferHydrateNever: fE, \u0275\u0275deferHydrateOnIdle: gE, \u0275\u0275deferHydrateOnImmediate: vE, \u0275\u0275deferHydrateOnTimer: DE, \u0275\u0275deferHydrateOnHover: ME, \u0275\u0275deferHydrateOnInteraction: _E, \u0275\u0275deferHydrateOnViewport: AE, \u0275\u0275deferEnableTimerScheduling: Qv, \u0275\u0275repeater: FE, \u0275\u0275repeaterCreate: PE, \u0275\u0275repeaterTrackByIndex: xE, \u0275\u0275repeaterTrackByIdentity: LE, \u0275\u0275componentInstance: RE, \u0275\u0275text: wI, \u0275\u0275textInterpolate: ff, \u0275\u0275textInterpolate1: Ca, \u0275\u0275textInterpolate2: pf, \u0275\u0275textInterpolate3: hf, \u0275\u0275textInterpolate4: gf, \u0275\u0275textInterpolate5: mf, \u0275\u0275textInterpolate6: yf, \u0275\u0275textInterpolate7: vf, \u0275\u0275textInterpolate8: Ef, \u0275\u0275textInterpolateV: If, \u0275\u0275i18n: nI, \u0275\u0275i18nAttributes: oI, \u0275\u0275i18nExp: ef, \u0275\u0275i18nStart: Jd, \u0275\u0275i18nEnd: Xd, \u0275\u0275i18nApply: rI, \u0275\u0275i18nPostprocess: iI, \u0275\u0275resolveWindow: Rm, \u0275\u0275resolveDocument: km, \u0275\u0275resolveBody: Fu, \u0275\u0275setComponentScope: rD, \u0275\u0275setNgModuleScope: iD, \u0275\u0275registerNgModuleType: Dd, \u0275\u0275getComponentDepsFactory: SD, \u0275setClassDebugInfo: bD, \u0275\u0275declareLet: Tf, \u0275\u0275storeLet: jI, \u0275\u0275arrowFunction: XI, \u0275\u0275readContextLet: BI, \u0275\u0275attachSourceLocations: UI, \u0275\u0275interpolate: $I, \u0275\u0275interpolate1: zI, \u0275\u0275interpolate2: GI, \u0275\u0275interpolate3: WI, \u0275\u0275interpolate4: qI, \u0275\u0275interpolate5: QI, \u0275\u0275interpolate6: YI, \u0275\u0275interpolate7: ZI, \u0275\u0275interpolate8: KI, \u0275\u0275interpolateV: JI, \u0275\u0275sanitizeHtml: ku, \u0275\u0275sanitizeStyle: Ou, \u0275\u0275sanitizeResourceUrl: Fs, \u0275\u0275sanitizeScript: Lu, \u0275\u0275validateAttribute: Pu, \u0275\u0275sanitizeUrl: xu, \u0275\u0275sanitizeUrlOrResourceUrl: Am, \u0275\u0275trustConstantHtml: Sm, \u0275\u0275trustConstantResourceUrl: bm, forwardRef: za, resolveForwardRef: G, \u0275\u0275twoWayProperty: Df, \u0275\u0275twoWayBindingSet: HI, \u0275\u0275twoWayListener: Cf, \u0275\u0275replaceMetadata: RD, \u0275\u0275getReplaceMetadataURL: AD }, On = null;
function kD(e) { On !== null && (e.defaultEncapsulation !== On.defaultEncapsulation || e.preserveWhitespaces !== On.preserveWhitespaces) || (On = e); }
function kR() { return On; }
function OR() { On = null; }
var Ko = [];
function xR(e, t) { Ko.push({ moduleType: e, ngModule: t }); }
var tl = !1;
function OD() { if (!tl) {
    tl = !0;
    try {
        for (let e = Ko.length - 1; e >= 0; e--) {
            let { moduleType: t, ngModule: n } = Ko[e];
            n.declarations && n.declarations.every(xD) && (Ko.splice(e, 1), VR(t, n));
        }
    }
    finally {
        tl = !1;
    }
} }
function xD(e) { return Array.isArray(e) ? e.every(xD) : !!G(e); }
function LD(e, t = {}) { PD(e, t), t.id !== void 0 && Dd(e, t.id), xR(e, t); }
function PD(e, t, n = !1) { let o = Fe(t.declarations || F), r = null; Object.defineProperty(e, Wa, { configurable: !0, get: () => (r === null && (r = oe({ usage: 0, kind: "NgModule", type: e }).compileNgModule(ge, `ng:///${e.name}/\u0275mod.js`, { type: e, bootstrap: Fe(t.bootstrap || F).map(G), declarations: o.map(G), imports: Fe(t.imports || F).map(G).map(Wh), exports: Fe(t.exports || F).map(G).map(Wh), schemas: t.schemas ? Fe(t.schemas) : null, id: t.id || null }), r.schemas || (r.schemas = [])), r) }); let i = null; Object.defineProperty(e, vt, { get: () => { if (i === null) {
        let a = oe({ usage: 0, kind: "NgModule", type: e });
        i = a.compileFactory(ge, `ng:///${e.name}/\u0275fac.js`, { name: e.name, type: e, deps: Ds(e), target: a.FactoryTarget.NgModule, typeArgumentCount: 0 });
    } return i; }, configurable: !1 }); let s = null; Object.defineProperty(e, Ga, { get: () => { if (s === null) {
        let a = { name: e.name, type: e, providers: t.providers || F, imports: [(t.imports || F).map(G), (t.exports || F).map(G)] };
        s = oe({ usage: 0, kind: "NgModule", type: e }).compileInjector(ge, `ng:///${e.name}/\u0275inj.js`, a);
    } return s; }, configurable: !1 }); }
function LR(e, t) { let n = `Unexpected "${we(e)}" found in the "declarations" array of the`, o = `"${we(e)}" is marked as standalone and can't be declared in any NgModule - did you intend to import it instead (by adding it to the "imports" array)?`; return `${n} ${t}, ${o}`; }
var PR = new WeakMap, FR = new WeakMap;
function HR() { PR = new WeakMap, FR = new WeakMap, Ko.length = 0, tb.clear(); }
function VR(e, t) { let n = Fe(t.declarations || F), o = Nf(e); n.forEach(r => { if (r = G(r), r.hasOwnProperty(yt)) {
    let s = W(r);
    Mf(s, o);
}
else
    !r.hasOwnProperty(vn) && !r.hasOwnProperty(ei) && (r.ngSelectorScope = e); }); }
function Mf(e, t) { e.directiveDefs = () => Array.from(t.compilation.directives).map(n => n.hasOwnProperty(yt) ? W(n) : Ne(n)).filter(n => !!n), e.pipeDefs = () => Array.from(t.compilation.pipes).map(n => Ue(n)), e.schemas = t.schemas, e.tView = null; }
function Nf(e) { if (Zt(e)) {
    let t = $n.getNgModuleScope(e), n = ti(e);
    return K({ schemas: n.schemas || null }, t);
}
else if (Co(e)) {
    if ((W(e) || Ne(e)) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set([e]), pipes: new Set } };
    if (Ue(e) !== null)
        return { schemas: null, compilation: { directives: new Set, pipes: new Set }, exported: { directives: new Set, pipes: new Set([e]) } };
} throw new Error(`${e.name} does not have a module def (\u0275mod property)`); }
function Wh(e) { return ld(e) ? e.ngModule : e; }
var nl = 0;
function FD(e, t) {
    let n = null;
    zS(e, t), VD(e, t), Object.defineProperty(e, yt, { get: () => {
            if (n === null) {
                let o = oe({ usage: 0, kind: "component", type: e });
                if (Iv(t)) {
                    let u = [`Component '${e.name}' is not resolved:`];
                    throw t.templateUrl && u.push(` - templateUrl: ${t.templateUrl}`), t.styleUrls && t.styleUrls.length && u.push(` - styleUrls: ${JSON.stringify(t.styleUrls)}`), t.styleUrl && u.push(` - styleUrl: ${t.styleUrl}`), u.push("Did you run and wait for 'resolveComponentResources()'?"), new Error(u.join(`
`));
                }
                let r = kR(), i = t.preserveWhitespaces;
                i === void 0 && (r !== null && r.preserveWhitespaces !== void 0 ? i = r.preserveWhitespaces : i = !1);
                let s = t.encapsulation;
                s === void 0 && (r !== null && r.defaultEncapsulation !== void 0 ? s = r.defaultEncapsulation : s = ke.Emulated);
                let a = t.templateUrl || `ng:///${e.name}/template.html`, c = jD(e, t), l = et(K({}, c), { typeSourceSpan: o.createParseSourceSpan("Component", e.name, a), template: t.template || "", preserveWhitespaces: i, styles: typeof t.styles == "string" ? [t.styles] : t.styles || F, animations: t.animations, declarations: [], changeDetection: t.changeDetection, encapsulation: s, viewProviders: t.viewProviders || null, hasDirectiveDependencies: !c.isStandalone || t.imports != null && t.imports.length > 0 });
                nl++;
                try {
                    if (l.usesInheritance && BD(e), n = o.compileComponent(ge, a, l), l.isStandalone) {
                        let u = Fe(t.imports || F), { directiveDefs: d, pipeDefs: f } = jR(e, u);
                        n.directiveDefs = d, n.pipeDefs = f, n.dependencies = () => u.map(G);
                    }
                }
                finally {
                    nl--;
                }
                if (nl === 0 && OD(), BR(e)) {
                    let u = Nf(e.ngSelectorScope);
                    Mf(n, u);
                }
                if (t.schemas)
                    if (l.isStandalone)
                        n.schemas = t.schemas;
                    else
                        throw new Error(`The 'schemas' was specified for the ${we(e)} but is only valid on a component that is standalone.`);
                else
                    l.isStandalone && (n.schemas = []);
            }
            return n;
        }, set: o => { n = o; }, configurable: !1 });
}
function jR(e, t) { return { directiveDefs: () => $o(e) ? [...$n.getStandaloneComponentScope(e, t).compilation.directives].map(i => W(i) || Ne(i)).filter(i => i !== null) : [], pipeDefs: () => $o(e) ? [...$n.getStandaloneComponentScope(e, t).compilation.pipes].map(i => Ue(i)).filter(i => i !== null) : [] }; }
function BR(e) { return e.ngSelectorScope !== void 0; }
function wf(e, t) { let n = null; VD(e, t || {}), Object.defineProperty(e, vn, { get: () => { if (n === null) {
        let o = HD(e, t || {});
        n = oe({ usage: 0, kind: "directive", type: e }).compileDirective(ge, o.sourceMapUrl, o.metadata);
    } return n; }, configurable: !1 }); }
function HD(e, t) { let n = e && e.name, o = `ng:///${n}/\u0275dir.js`, r = oe({ usage: 0, kind: "directive", type: e }), i = jD(e, t); return i.typeSourceSpan = r.createParseSourceSpan("Directive", n, o), i.usesInheritance && BD(e), { metadata: i, sourceMapUrl: o }; }
function VD(e, t) { let n = null; Object.defineProperty(e, vt, { get: () => { if (n === null) {
        let o = HD(e, t), r = oe({ usage: 0, kind: "directive", type: e });
        n = r.compileFactory(ge, `ng:///${e.name}/\u0275fac.js`, { name: o.metadata.name, type: o.metadata.type, typeArgumentCount: 0, deps: Ds(e), target: r.FactoryTarget.Directive });
    } return n; }, configurable: !1 }); }
function UR(e) { return Object.getPrototypeOf(e.prototype) === Object.prototype; }
function jD(e, t) { let n = uu(), o = n.ownPropMetadata(e); return { name: e.name, type: e, selector: t.selector !== void 0 ? t.selector : null, host: t.host || _e, propMetadata: o, inputs: t.inputs || F, outputs: t.outputs || F, queries: qh(e, o, UD), lifecycle: { usesOnChanges: n.hasLifecycleHook(e, "ngOnChanges") }, controlCreate: null, typeSourceSpan: null, usesInheritance: !UR(e), exportAs: GR(t.exportAs), providers: t.providers || null, viewQueries: qh(e, o, $D), isStandalone: t.standalone === void 0 ? !0 : !!t.standalone, isSignal: !!t.signals, hostDirectives: t.hostDirectives?.map(r => typeof r == "function" ? { directive: r } : r) || null }; }
function BD(e) { let t = Object.prototype, n = Object.getPrototypeOf(e.prototype).constructor; for (; n && n !== t;)
    !Ne(n) && !W(n) && qR(n) && wf(n, null), n = Object.getPrototypeOf(n); }
function $R(e) { return typeof e == "string" ? GD(e) : G(e); }
function zR(e, t) { return { propertyName: e, predicate: $R(t.selector), descendants: t.descendants, first: t.first, read: t.read ? t.read : null, static: !!t.static, emitDistinctChangesOnly: !!t.emitDistinctChangesOnly, isSignal: !!t.isSignal }; }
function qh(e, t, n) { let o = [], r = []; for (let i in t)
    if (t.hasOwnProperty(i)) {
        let s = t[i];
        s.forEach(a => { if (n(a)) {
            if (!a.selector)
                throw new Error(`Can't construct a query for the property "${i}" of "${we(e)}" since the query selector wasn't defined.`);
            if (s.some(zD))
                throw new Error("Cannot combine @Input decorators with query decorators");
            let c = zR(i, a);
            c.isSignal ? o.push(c) : r.push(c);
        } });
    } return [...o, ...r]; }
function GR(e) { return e === void 0 ? null : GD(e); }
function UD(e) { let t = e.ngMetadataName; return t === "ContentChild" || t === "ContentChildren"; }
function $D(e) { let t = e.ngMetadataName; return t === "ViewChild" || t === "ViewChildren"; }
function zD(e) { return e.ngMetadataName === "Input"; }
function GD(e) { return e.split(",").map(t => t.trim()); }
var WR = ["ngOnChanges", "ngOnInit", "ngOnDestroy", "ngDoCheck", "ngAfterViewInit", "ngAfterViewChecked", "ngAfterContentInit", "ngAfterContentChecked"];
function qR(e) { let t = uu(); if (WR.some(o => t.hasLifecycleHook(e, o)))
    return !0; let n = t.propMetadata(e); for (let o in n) {
    let r = n[o];
    for (let i = 0; i < r.length; i++) {
        let s = r[i], a = s.ngMetadataName;
        if (zD(s) || UD(s) || $D(s) || a === "Output" || a === "HostBinding" || a === "HostListener")
            return !0;
    }
} return !1; }
function WD(e, t) { let n = null, o = null; Object.defineProperty(e, vt, { get: () => { if (o === null) {
        let r = Qh(e, t), i = oe({ usage: 0, kind: "pipe", type: r.type });
        o = i.compileFactory(ge, `ng:///${r.name}/\u0275fac.js`, { name: r.name, type: r.type, typeArgumentCount: 0, deps: Ds(e), target: i.FactoryTarget.Pipe });
    } return o; }, configurable: !1 }), Object.defineProperty(e, ei, { get: () => { if (n === null) {
        let r = Qh(e, t);
        n = oe({ usage: 0, kind: "pipe", type: r.type }).compilePipe(ge, `ng:///${r.name}/\u0275pipe.js`, r);
    } return n; }, configurable: !1 }); }
function Qh(e, t) { return { type: e, name: e.name, pipeName: t.name, pure: t.pure !== void 0 ? t.pure : !0, isStandalone: t.standalone === void 0 ? !0 : !!t.standalone }; }
var qD = vr("Directive", (e = {}) => e, void 0, void 0, (e, t) => wf(e, t)), QR = vr("Component", (e = {}) => K({ changeDetection: Cs.Eager }, e), qD, void 0, (e, t) => FD(e, t)), YR = vr("Pipe", e => K({ pure: !0 }, e), void 0, void 0, (e, t) => WD(e, t)), ZR = ct("Input", e => e ? typeof e == "string" ? { alias: e } : e : {}), KR = ct("Output", e => ({ alias: e })), JR = ct("HostBinding", e => ({ hostPropertyName: e })), XR = ct("HostListener", (e, t) => ({ eventName: e, args: t })), ek = vr("NgModule", e => e, void 0, void 0, (e, t) => LD(e, t)), vs = class {
    ngModuleFactory;
    componentFactories;
    constructor(t, n) { this.ngModuleFactory = t, this.componentFactories = n; }
}, tk = (() => { class e {
    compileModuleSync(n) { return new qn(n); }
    compileModuleAsync(n) { return Promise.resolve(this.compileModuleSync(n)); }
    compileModuleAndAllComponentsSync(n) { let o = this.compileModuleSync(n), r = En(n), i = Rn(r.declarations).reduce((s, a) => { let c = W(a); return c && s.push(new Ot(c)), s; }, []); return new vs(o, i); }
    compileModuleAndAllComponentsAsync(n) { return Promise.resolve(this.compileModuleAndAllComponentsSync(n)); }
    clearCache() { }
    clearCacheFor(n) { }
    getModuleId(n) { }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), QD = new S(""), su = class {
};
var YD = (() => { class e {
    applicationErrorHandler = I(qt);
    appRef = I(xe);
    taskService = I(Wt);
    ngZone = I(U);
    zonelessEnabled = I(Mn);
    tracing = I(gn, { optional: !0 });
    zoneIsDefined = typeof Zone < "u" && !!Zone.root.run;
    schedulerTickApplyArgs = [{ data: { __scheduler_tick__: !0 } }];
    subscriptions = new RT;
    angularZoneId = this.zoneIsDefined ? this.ngZone._inner?.get(_c) : null;
    scheduleInRootZone = !this.zonelessEnabled && this.zoneIsDefined && (I(Di, { optional: !0 }) ?? !1);
    cancelScheduledCallback = null;
    useMicrotaskScheduler = !1;
    runningTick = !1;
    pendingRenderTaskId = null;
    constructor() { this.subscriptions.add(this.appRef.afterTick.subscribe(() => { let n = this.taskService.add(); if (!this.runningTick && (this.cleanup(), !this.zonelessEnabled || this.appRef.includeAllTestViews)) {
        this.taskService.remove(n);
        return;
    } this.switchToMicrotaskScheduler(), this.taskService.remove(n); })), this.subscriptions.add(this.ngZone.onUnstable.subscribe(() => { this.runningTick || this.cleanup(); })); }
    switchToMicrotaskScheduler() { this.ngZone.runOutsideAngular(() => { let n = this.taskService.add(); this.useMicrotaskScheduler = !0, queueMicrotask(() => { this.useMicrotaskScheduler = !1, this.taskService.remove(n); }); }); }
    notify(n) { if (!this.zonelessEnabled && n === 5)
        return; switch (n) {
        case 0: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 3:
        case 2:
        case 4:
        case 5:
        case 1: {
            this.appRef.dirtyFlags |= 4;
            break;
        }
        case 6: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 12: {
            this.appRef.dirtyFlags |= 16;
            break;
        }
        case 13: {
            this.appRef.dirtyFlags |= 2;
            break;
        }
        case 11: break;
        default: this.appRef.dirtyFlags |= 8;
    } if (this.appRef.tracingSnapshot = this.tracing?.snapshot(this.appRef.tracingSnapshot) ?? null, !this.shouldScheduleTick())
        return; let o = this.useMicrotaskScheduler ? kp : Rp; this.pendingRenderTaskId = this.taskService.add(), this.scheduleInRootZone ? this.cancelScheduledCallback = Zone.root.run(() => o(() => this.tick())) : this.cancelScheduledCallback = this.ngZone.runOutsideAngular(() => o(() => this.tick())); }
    shouldScheduleTick() { return !(this.appRef.destroyed || this.pendingRenderTaskId !== null || this.runningTick || this.appRef._runningTick || !this.zonelessEnabled && this.zoneIsDefined && Zone.current.get(_c + this.angularZoneId)); }
    tick() { if (this.runningTick || this.appRef.destroyed)
        return; if (this.appRef.dirtyFlags === 0) {
        this.cleanup();
        return;
    } !this.zonelessEnabled && this.appRef.dirtyFlags & 7 && (this.appRef.dirtyFlags |= 1); let n = this.taskService.add(); try {
        this.ngZone.run(() => { this.runningTick = !0, this.appRef._tick(); }, void 0, this.schedulerTickApplyArgs);
    }
    catch (o) {
        this.applicationErrorHandler(o);
    }
    finally {
        this.taskService.remove(n), this.cleanup();
    } }
    ngOnDestroy() { this.subscriptions.unsubscribe(), this.cleanup(); }
    cleanup() { if (this.runningTick = !1, this.cancelScheduledCallback?.(), this.cancelScheduledCallback = null, this.pendingRenderTaskId !== null) {
        let n = this.pendingRenderTaskId;
        this.pendingRenderTaskId = null, this.taskService.remove(n);
    } }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
function nk() { return Y("NgZoneless"), nt([...Ta(), []]); }
function Ta() { return [{ provide: Nt, useExisting: YD }, { provide: U, useClass: Sc }, { provide: Mn, useValue: !0 }]; }
function ok() { return typeof $localize < "u" && $localize.locale || jr; }
var _f = new S("", { factory: () => I(_f, { optional: !0, skipSelf: !0 }) || ok() }), rk = new S("", { factory: () => vA }), ik = new S(""), sk = new S(""), ZD = (function (e) { return e[e.Error = 0] = "Error", e[e.Warning = 1] = "Warning", e[e.Ignore = 2] = "Ignore", e; })(ZD || {}), au = class {
    name;
    callback;
    constructor(t, n) { this.name = t, this.callback = n; }
};
function ak(e) { return e.map(t => t.nativeElement); }
var mr = class {
    nativeNode;
    constructor(t) { this.nativeNode = t; }
    get parent() { let t = this.nativeNode.parentNode; return t ? new dn(t) : null; }
    get injector() { return NM(this.nativeNode); }
    get componentInstance() { let t = this.nativeNode; return t && (Wp(t) || MM(t)); }
    get context() { return Wp(this.nativeNode) || TM(this.nativeNode); }
    get listeners() { return AM(this.nativeNode).filter(t => t.type === "dom"); }
    get references() { return SM(this.nativeNode); }
    get providerTokens() { return wM(this.nativeNode); }
}, dn = class extends mr {
    constructor(t) { super(t); }
    get nativeElement() { return this.nativeNode.nodeType == Node.ELEMENT_NODE ? this.nativeNode : null; }
    get name() { let t = Ee(this.nativeNode), n = t ? t.lView : null; return n !== null ? n[m].data[t.nodeIndex].value : this.nativeNode.nodeName; }
    get properties() { let t = Ee(this.nativeNode), n = t ? t.lView : null; if (n === null)
        return {}; let o = n[m].data, r = o[t.nodeIndex], i = {}; return ck(this.nativeElement, i), uk(i, r, n, o), i; }
    get attributes() { let t = {}, n = this.nativeElement; if (!n)
        return t; let o = Ee(n), r = o ? o.lView : null; if (r === null)
        return {}; let i = r[m].data[o.nodeIndex].attrs, s = []; if (i) {
        let a = 0;
        for (; a < i.length;) {
            let c = i[a];
            if (typeof c != "string")
                break;
            let l = i[a + 1];
            t[c] = l, s.push(c.toLowerCase()), a += 2;
        }
    } for (let a of n.attributes)
        s.includes(a.name) || (t[a.name] = a.value); return t; }
    get styles() { return this.nativeElement?.style ?? {}; }
    get classes() { let t = {}, o = this.nativeElement.className; return (typeof o != "string" ? o.baseVal.split(" ") : o.split(" ")).forEach(i => t[i] = !0), t; }
    get childNodes() { let t = this.nativeNode.childNodes, n = []; for (let o = 0; o < t.length; o++) {
        let r = t[o];
        n.push(yr(r));
    } return n; }
    get children() { let t = this.nativeElement; if (!t)
        return []; let n = t.children, o = []; for (let r = 0; r < n.length; r++) {
        let i = n[r];
        o.push(yr(i));
    } return o; }
    query(t) { return this.queryAll(t)[0] || null; }
    queryAll(t) { let n = []; return Yh(this, t, n, !0), n; }
    queryAllNodes(t) { let n = []; return Yh(this, t, n, !1), n; }
    triggerEventHandler(t, n) { let o = this.nativeNode, r = []; this.listeners.forEach(i => { if (i.name === t) {
        let s = i.callback;
        s.call(o, n), r.push(s);
    } }), typeof o.eventListeners == "function" && o.eventListeners(t).forEach(i => { if (i.toString().indexOf("__ngUnwrap__") !== -1) {
        let s = i("__ngUnwrap__");
        return r.indexOf(s) === -1 && s.call(o, n);
    } }); }
};
function ck(e, t) { if (e) {
    let n = Object.getPrototypeOf(e), o = Node.prototype;
    for (; n !== null && n !== o;) {
        let r = Object.getOwnPropertyDescriptors(n);
        for (let i in r)
            if (!i.startsWith("__") && !i.startsWith("on")) {
                let s = e[i];
                lk(s) && (t[i] = s);
            }
        n = Object.getPrototypeOf(n);
    }
} }
function lk(e) { return typeof e == "string" || typeof e == "boolean" || typeof e == "number" || e === null; }
function Yh(e, t, n, o) { let r = Ee(e.nativeNode), i = r ? r.lView : null; if (i !== null) {
    let s = i[m].data[r.nodeIndex];
    Kt(s, i, t, n, o, e.nativeNode);
}
else
    Sf(e.nativeNode, t, n, o); }
function Kt(e, t, n, o, r, i) { let s = fp(e, t); if (e.type & 11) {
    if (ol(s, n, o, r, i), me(e)) {
        let c = pe(e.index, t);
        c && c[m].firstChild && Kt(c[m].firstChild, c, n, o, r, i);
    }
    else
        e.child && Kt(e.child, t, n, o, r, i), s && Sf(s, n, o, r);
    let a = t[e.index];
    ee(a) && Zh(a, n, o, r, i);
}
else if (e.type & 4) {
    let a = t[e.index];
    ol(a[He], n, o, r, i), Zh(a, n, o, r, i);
}
else if (e.type & 16) {
    let a = t[J], l = a[ue].projection[e.projection];
    if (Array.isArray(l))
        for (let u of l)
            ol(u, n, o, r, i);
    else if (l) {
        let u = a[q], d = u[m].data[l.index];
        Kt(d, u, n, o, r, i);
    }
}
else
    e.child && Kt(e.child, t, n, o, r, i); if (i !== s) {
    let a = e.flags & 2 ? e.projectionNext : e.next;
    a && Kt(a, t, n, o, r, i);
} }
function Zh(e, t, n, o, r) { for (let i = V; i < e.length; i++) {
    let s = e[i], a = s[m].firstChild;
    a && Kt(a, s, t, n, o, r);
} }
function ol(e, t, n, o, r) { if (r !== e) {
    let i = yr(e);
    if (!i)
        return;
    (o && i instanceof dn && t(i) && n.indexOf(i) === -1 || !o && t(i) && n.indexOf(i) === -1) && n.push(i);
} }
function Sf(e, t, n, o) { let r = e.childNodes, i = r.length; for (let s = 0; s < i; s++) {
    let a = r[s], c = yr(a);
    c && ((o && c instanceof dn && t(c) && n.indexOf(c) === -1 || !o && t(c) && n.indexOf(c) === -1) && n.push(c), Sf(a, t, n, o));
} }
function uk(e, t, n, o) { let r = t.propertyBindings; if (r !== null)
    for (let i = 0; i < r.length; i++) {
        let s = r[i], c = o[s].split(YN), l = c[0];
        if (c.length > 1) {
            let u = c[1];
            for (let d = 1; d < c.length - 1; d++)
                u += N(n[s + d - 1]) + c[d + 1];
            e[l] = u;
        }
        else
            e[l] = n[s];
    } }
var rl = "__ng_debug__";
function yr(e) { return e instanceof Node ? (e.hasOwnProperty(rl) || (e[rl] = e.nodeType == Node.ELEMENT_NODE ? new dn(e) : new mr(e)), e[rl]) : null; }
import { Subscription as zk } from "rxjs";
var Of = { JSACTION: "__jsaction", OWNER: "__owner" }, eC = {};
function dk(e) { return e[Of.JSACTION]; }
function KD(e, t) { e[Of.JSACTION] = t; }
function fk(e) { return eC[e]; }
function pk(e, t) { eC[e] = t; }
var C = { CLICK: "click", CLICKMOD: "clickmod", DBLCLICK: "dblclick", FOCUS: "focus", FOCUSIN: "focusin", BLUR: "blur", FOCUSOUT: "focusout", SUBMIT: "submit", KEYDOWN: "keydown", KEYPRESS: "keypress", KEYUP: "keyup", MOUSEOVER: "mouseover", MOUSEOUT: "mouseout", MOUSEENTER: "mouseenter", MOUSELEAVE: "mouseleave", POINTEROVER: "pointerover", POINTEROUT: "pointerout", POINTERENTER: "pointerenter", POINTERLEAVE: "pointerleave", ERROR: "error", LOAD: "load", TOUCHSTART: "touchstart", TOUCHEND: "touchend", TOUCHMOVE: "touchmove", TOGGLE: "toggle" }, hk = [C.MOUSEENTER, C.MOUSELEAVE, "pointerenter", "pointerleave"], gk = [C.CLICK, C.DBLCLICK, C.FOCUSIN, C.FOCUSOUT, C.KEYDOWN, C.KEYUP, C.KEYPRESS, C.MOUSEOVER, C.MOUSEOUT, C.SUBMIT, C.TOUCHSTART, C.TOUCHEND, C.TOUCHMOVE, "touchcancel", "auxclick", "change", "compositionstart", "compositionupdate", "compositionend", "beforeinput", "input", "select", "copy", "cut", "paste", "mousedown", "mouseup", "wheel", "contextmenu", "dragover", "dragenter", "dragleave", "drop", "dragstart", "dragend", "pointerdown", "pointermove", "pointerup", "pointercancel", "pointerover", "pointerout", "gotpointercapture", "lostpointercapture", "ended", "loadedmetadata", "pagehide", "pageshow", "visibilitychange", "beforematch"], tC = [C.FOCUS, C.BLUR, C.ERROR, C.LOAD, C.TOGGLE], ba = e => tC.indexOf(e) >= 0, mk = gk.concat(tC), nC = e => mk.indexOf(e) >= 0;
function yk(e) { return e === C.MOUSEENTER ? C.MOUSEOVER : e === C.MOUSELEAVE ? C.MOUSEOUT : e === C.POINTERENTER ? C.POINTEROVER : e === C.POINTERLEAVE ? C.POINTEROUT : e; }
function vk(e, t, n, o) { let r = !1; ba(t) && (r = !0); let i = typeof o == "boolean" ? { capture: r, passive: o } : r; return e.addEventListener(t, n, i), { eventType: t, handler: n, capture: r, passive: o }; }
function Ek(e, t) { if (e.removeEventListener) {
    let n = typeof t.passive == "boolean" ? { capture: t.capture } : t.capture;
    e.removeEventListener(t.eventType, t.handler, n);
}
else
    e.detachEvent && e.detachEvent(`on${t.eventType}`, t.handler); }
function Ik(e) { e.preventDefault ? e.preventDefault() : e.returnValue = !1; }
var JD = typeof navigator < "u" && /Macintosh/.test(navigator.userAgent);
function Dk(e) { return e.which === 2 || e.which == null && e.button === 4; }
function Ck(e) { return JD && e.metaKey || !JD && e.ctrlKey || Dk(e) || e.shiftKey; }
function Tk(e, t, n) { let o = e.relatedTarget; return (e.type === C.MOUSEOVER && t === C.MOUSEENTER || e.type === C.MOUSEOUT && t === C.MOUSELEAVE || e.type === C.POINTEROVER && t === C.POINTERENTER || e.type === C.POINTEROUT && t === C.POINTERLEAVE) && (!o || o !== n && !n.contains(o)); }
function Mk(e, t) { let n = {}; for (let o in e) {
    if (o === "srcElement" || o === "target")
        continue;
    let r = o, i = e[r];
    typeof i != "function" && (n[r] = i);
} return e.type === C.MOUSEOVER ? n.type = C.MOUSEENTER : e.type === C.MOUSEOUT ? n.type = C.MOUSELEAVE : e.type === C.POINTEROVER ? n.type = C.POINTERENTER : n.type = C.POINTERLEAVE, n.target = n.srcElement = t, n.bubbles = !1, n._originalEvent = e, n; }
var _a = class {
    element;
    handlerInfos = [];
    constructor(t) { this.element = t; }
    addEventListener(t, n, o) { this.handlerInfos.push(vk(this.element, t, n(this.element), o)); }
    cleanUp() { for (let t = 0; t < this.handlerInfos.length; t++)
        Ek(this.element, this.handlerInfos[t]); this.handlerInfos = []; }
}, Nk = { EVENT_ACTION_SEPARATOR: ":" };
function Lt(e) { return e.eventType; }
function xf(e, t) { e.eventType = t; }
function Na(e) { return e.event; }
function oC(e, t) { e.event = t; }
function rC(e) { return e.targetElement; }
function iC(e, t) { e.targetElement = t; }
function sC(e) { return e.eic; }
function wk(e, t) { e.eic = t; }
function _k(e) { return e.timeStamp; }
function Sk(e, t) { e.timeStamp = t; }
function wa(e) { return e.eia; }
function aC(e, t, n) { e.eia = [t, n]; }
function bf(e) { e.eia = void 0; }
function Ma(e) { return e[1]; }
function bk(e) { return e.eirp; }
function cC(e, t) { e.eirp = t; }
function lC(e) { return e.eir; }
function uC(e, t) { e.eir = t; }
function dC(e) { return { eventType: e.eventType, event: e.event, targetElement: e.targetElement, eic: e.eic, eia: e.eia, timeStamp: e.timeStamp, eirp: e.eirp, eiack: e.eiack, eir: e.eir }; }
function Ak(e, t, n, o, r, i, s, a) { return { eventType: e, event: t, targetElement: n, eic: o, timeStamp: r, eia: i, eirp: s, eiack: a }; }
var Af = class e {
    eventInfo;
    constructor(t) { this.eventInfo = t; }
    getEventType() { return Lt(this.eventInfo); }
    setEventType(t) { xf(this.eventInfo, t); }
    getEvent() { return Na(this.eventInfo); }
    setEvent(t) { oC(this.eventInfo, t); }
    getTargetElement() { return rC(this.eventInfo); }
    setTargetElement(t) { iC(this.eventInfo, t); }
    getContainer() { return sC(this.eventInfo); }
    setContainer(t) { wk(this.eventInfo, t); }
    getTimestamp() { return _k(this.eventInfo); }
    setTimestamp(t) { Sk(this.eventInfo, t); }
    getAction() { let t = wa(this.eventInfo); if (t)
        return { name: t[0], element: t[1] }; }
    setAction(t) { if (!t) {
        bf(this.eventInfo);
        return;
    } aC(this.eventInfo, t.name, t.element); }
    getIsReplay() { return bk(this.eventInfo); }
    setIsReplay(t) { cC(this.eventInfo, t); }
    getResolved() { return lC(this.eventInfo); }
    setResolved(t) { uC(this.eventInfo, t); }
    clone() { return new e(dC(this.eventInfo)); }
}, Rk = {}, kk = /\s*;\s*/, Ok = C.CLICK, Rf = class {
    a11yClickSupport = !1;
    clickModSupport = !0;
    syntheticMouseEventSupport;
    updateEventInfoForA11yClick = void 0;
    preventDefaultForA11yClick = void 0;
    populateClickOnlyAction = void 0;
    constructor({ syntheticMouseEventSupport: t = !1, clickModSupport: n = !0 } = {}) { this.syntheticMouseEventSupport = t, this.clickModSupport = n; }
    resolveEventType(t) { this.clickModSupport && Lt(t) === C.CLICK && Ck(Na(t)) ? xf(t, C.CLICKMOD) : this.a11yClickSupport && this.updateEventInfoForA11yClick(t); }
    resolveAction(t) { lC(t) || (this.populateAction(t, rC(t)), uC(t, !0)); }
    resolveParentAction(t) { let n = wa(t), o = n && Ma(n); bf(t); let r = o && this.getParentNode(o); r && this.populateAction(t, r); }
    populateAction(t, n) { let o = n; for (; o && o !== sC(t) && (o.nodeType === Node.ELEMENT_NODE && this.populateActionOnElement(o, t), !wa(t));)
        o = this.getParentNode(o); let r = wa(t); if (r && (this.a11yClickSupport && this.preventDefaultForA11yClick(t), this.syntheticMouseEventSupport && (Lt(t) === C.MOUSEENTER || Lt(t) === C.MOUSELEAVE || Lt(t) === C.POINTERENTER || Lt(t) === C.POINTERLEAVE)))
        if (Tk(Na(t), Lt(t), Ma(r))) {
            let i = Mk(Na(t), Ma(r));
            oC(t, i), iC(t, Ma(r));
        }
        else
            bf(t); }
    getParentNode(t) { let n = t[Of.OWNER]; if (n)
        return n; let o = t.parentNode; return o?.nodeName === "#document-fragment" ? o?.host ?? null : o; }
    populateActionOnElement(t, n) { let o = this.parseActions(t), r = o[Lt(n)]; r !== void 0 && aC(n, r, t), this.a11yClickSupport && this.populateClickOnlyAction(t, n, o); }
    parseActions(t) { let n = dk(t); if (!n) {
        let o = t.getAttribute(Nn.JSACTION);
        if (!o)
            n = Rk, KD(t, n);
        else {
            if (n = fk(o), !n) {
                n = {};
                let r = o.split(kk);
                for (let i = 0; i < r.length; i++) {
                    let s = r[i];
                    if (!s)
                        continue;
                    let a = s.indexOf(Nk.EVENT_ACTION_SEPARATOR), c = a !== -1, l = c ? s.substr(0, a).trim() : Ok, u = c ? s.substr(a + 1).trim() : s;
                    n[l] = u;
                }
                pk(o, n);
            }
            KD(t, n);
        }
    } return n; }
    addA11yClickSupport(t, n, o) { this.a11yClickSupport = !0, this.updateEventInfoForA11yClick = t, this.preventDefaultForA11yClick = n, this.populateClickOnlyAction = o; }
}, fC = (function (e) { return e[e.I_AM_THE_JSACTION_FRAMEWORK = 0] = "I_AM_THE_JSACTION_FRAMEWORK", e; })(fC || {}), kf = class {
    dispatchDelegate;
    actionResolver;
    eventReplayer;
    eventReplayScheduled = !1;
    replayEventInfoWrappers = [];
    constructor(t, { actionResolver: n, eventReplayer: o } = {}) { this.dispatchDelegate = t, this.actionResolver = n, this.eventReplayer = o; }
    dispatch(t) { let n = new Af(t); this.actionResolver?.resolveEventType(t), this.actionResolver?.resolveAction(t); let o = n.getAction(); if (o && xk(o.element, n) && Ik(n.getEvent()), this.eventReplayer && n.getIsReplay()) {
        this.scheduleEventInfoWrapperReplay(n);
        return;
    } this.dispatchDelegate(n); }
    scheduleEventInfoWrapperReplay(t) { this.replayEventInfoWrappers.push(t), !this.eventReplayScheduled && (this.eventReplayScheduled = !0, Promise.resolve().then(() => { this.eventReplayScheduled = !1, this.eventReplayer(this.replayEventInfoWrappers); })); }
};
function xk(e, t) { return e.tagName === "A" && (t.getEventType() === C.CLICK || t.getEventType() === C.CLICKMOD); }
var pC = Symbol.for("propagationStopped"), Lf = { REPLAY: 101 };
var Lk = "`preventDefault` called during event replay.";
var Pk = "`composedPath` called during event replay.", Sa = class {
    dispatchDelegate;
    clickModSupport;
    actionResolver;
    dispatcher;
    constructor(t, n = !0) { this.dispatchDelegate = t, this.clickModSupport = n, this.actionResolver = new Rf({ clickModSupport: n }), this.dispatcher = new kf(o => { this.dispatchToDelegate(o); }, { actionResolver: this.actionResolver }); }
    dispatch(t) { this.dispatcher.dispatch(t); }
    dispatchToDelegate(t) { for (t.getIsReplay() && Vk(t), Fk(t); t.getAction();) {
        if (jk(t), ba(t.getEventType()) && t.getAction().element !== t.getTargetElement() || (this.dispatchDelegate(t.getEvent(), t.getAction().name), Hk(t)))
            return;
        this.actionResolver.resolveParentAction(t.eventInfo);
    } }
};
function Fk(e) { let t = e.getEvent(), n = e.getEvent().stopPropagation.bind(t), o = () => { t[pC] = !0, n(); }; yn(t, "stopPropagation", o), yn(t, "stopImmediatePropagation", o); }
function Hk(e) { return !!e.getEvent()[pC]; }
function Vk(e) { let t = e.getEvent(), n = e.getTargetElement(), o = t.preventDefault.bind(t); yn(t, "target", n), yn(t, "eventPhase", Lf.REPLAY), yn(t, "preventDefault", () => { throw o(), new Error(Lk + ""); }), yn(t, "composedPath", () => { throw new Error(Pk + ""); }); }
function jk(e) { let t = e.getEvent(), n = e.getAction()?.element; n && yn(t, "currentTarget", n, { configurable: !0 }); }
function yn(e, t, n, { configurable: o = !1 } = {}) { Object.defineProperty(e, t, { value: n, configurable: o }); }
function hC(e, t) { e.ecrd(n => { t.dispatch(n); }, fC.I_AM_THE_JSACTION_FRAMEWORK); }
function Bk(e) { return e?.q ?? []; }
function Uk(e) { e && (XD(e.c, e.et, e.h), XD(e.c, e.etc, e.h, !0)); }
function XD(e, t, n, o) { for (let r = 0; r < t.length; r++)
    e.removeEventListener(t[r], n, o); }
var $k = !1, gC = (() => { class e {
    static MOUSE_SPECIAL_SUPPORT = $k;
    containerManager;
    eventHandlers = {};
    browserEventTypeToExtraEventTypes = {};
    dispatcher = null;
    queuedEventInfos = [];
    constructor(n) { this.containerManager = n; }
    handleEvent(n, o, r) { let i = Ak(n, o, o.target, r, Date.now()); this.handleEventInfo(i); }
    handleEventInfo(n) { if (!this.dispatcher) {
        cC(n, !0), this.queuedEventInfos?.push(n);
        return;
    } this.dispatcher(n); }
    addEvent(n, o, r) { if (n in this.eventHandlers || !this.containerManager || !e.MOUSE_SPECIAL_SUPPORT && hk.indexOf(n) >= 0)
        return; let i = (a, c, l) => { this.handleEvent(a, c, l); }; this.eventHandlers[n] = i; let s = yk(o || n); if (s !== n) {
        let a = this.browserEventTypeToExtraEventTypes[s] || [];
        a.push(n), this.browserEventTypeToExtraEventTypes[s] = a;
    } this.containerManager.addEventListener(s, a => c => { i(n, c, a); }, r); }
    replayEarlyEvents(n = window._ejsa) { n && (this.replayEarlyEventInfos(n.q), Uk(n), delete window._ejsa); }
    replayEarlyEventInfos(n) { for (let o = 0; o < n.length; o++) {
        let r = n[o], i = this.getEventTypesForBrowserEventType(r.eventType);
        for (let s = 0; s < i.length; s++) {
            let a = dC(r);
            xf(a, i[s]), this.handleEventInfo(a);
        }
    } }
    getEventTypesForBrowserEventType(n) { let o = []; return this.eventHandlers[n] && o.push(n), this.browserEventTypeToExtraEventTypes[n] && o.push(...this.browserEventTypeToExtraEventTypes[n]), o; }
    handler(n) { return this.eventHandlers[n]; }
    cleanUp() { this.containerManager?.cleanUp(), this.containerManager = null, this.eventHandlers = {}, this.browserEventTypeToExtraEventTypes = {}, this.dispatcher = null, this.queuedEventInfos = []; }
    registerDispatcher(n, o) { this.ecrd(n, o); }
    ecrd(n, o) { if (this.dispatcher = n, this.queuedEventInfos?.length) {
        for (let r = 0; r < this.queuedEventInfos.length; r++)
            this.handleEventInfo(this.queuedEventInfos[r]);
        this.queuedEventInfos = null;
    } }
} return e; })();
function mC(e, t = window) { return Bk(t._ejsas?.[e]); }
function Pf(e, t = window) { t._ejsas && (t._ejsas[e] = void 0); }
import "@angular/core/primitives/signals";
import "rxjs/operators";
import "@angular/core/primitives/di";
typeof globalThis.ngServerMode > "u" && (globalThis.ngServerMode = typeof window > "u");
var Pa = Symbol("InputSignalNode#UNSET"), FC = et(K({}, Ba), { transformFn: void 0, applyValueToInputSignal(e, t) { ja(e, t); } }), SL = Symbol();
function HC(e, t) { let n = Object.create(FC); n.value = e, n.transformFn = t?.transform; function o() { if (Wr(n), n.value === Pa) {
    let r = null;
    throw new _(-950, r);
} return n.value; } return o[tt] = n, o; }
var mo = (function (e) { return e[e.Directive = 0] = "Directive", e[e.Component = 1] = "Component", e[e.Injectable = 2] = "Injectable", e[e.Pipe = 3] = "Pipe", e[e.NgModule = 4] = "NgModule", e; })(mo || {});
var Gk = (function (e) { return e.Angular = "angular", e.ACX = "acx", e.Wiz = "wiz", e; })(Gk || {}), yC = class {
    attributeName;
    constructor(t) { this.attributeName = t; }
    __NG_ELEMENT_ID__ = () => Is(this.attributeName);
    toString() { return `HostAttributeToken ${this.attributeName}`; }
}, bL = (() => { let e = new S(""); return e.__NG_ELEMENT_ID__ = t => { let n = M(); if (n === null)
    throw new _(-204, !1); if (n.type & 2)
    return n.value; if (t & 8)
    return null; throw new _(-204, !1); }, e; })();
function AL(e) { return new xc; }
function vC(e, t) { return HC(e, t); }
function Wk(e) { return HC(Pa, e); }
var RL = (vC.required = Wk, vC);
function EC(e, t) { return vd(t); }
function qk(e, t) { return Ed(t); }
var kL = (EC.required = qk, EC);
function OL(e, t) { return Id(t); }
function IC(e, t) { return vd(t); }
function Qk(e, t) { return Ed(t); }
var xL = (IC.required = Qk, IC);
function LL(e, t) { return Id(t); }
function VC(e, t) { let n = Object.create(FC), o = new xc; n.value = e; function r() { return Wr(n), DC(n.value), n.value; } return r[tt] = n, r.asReadonly = Op.bind(r), r.set = i => { n.equal(n.value, i) || (ja(n, i), o.emit(i)); }, r.update = i => { DC(n.value), r.set(i(n.value)); }, r.subscribe = o.subscribe.bind(o), r.destroyRef = o.destroyRef, r; }
function DC(e) { if (e === Pa)
    throw new _(952, !1); }
function CC(e, t) { return VC(e, t); }
function Yk(e) { return VC(Pa, e); }
var PL = (CC.required = Yk, CC), jC = !0, vo = class {
}, FL = ct("ContentChildren", (e, t = {}) => K({ selector: e, first: !1, isViewQuery: !1, descendants: !1, emitDistinctChangesOnly: jC }, t), vo), HL = ct("ContentChild", (e, t = {}) => K({ selector: e, first: !0, isViewQuery: !1, descendants: !0 }, t), vo), VL = ct("ViewChildren", (e, t = {}) => K({ selector: e, first: !1, isViewQuery: !0, descendants: !0, emitDistinctChangesOnly: jC }, t), vo), jL = ct("ViewChild", (e, t) => K({ selector: e, first: !0, isViewQuery: !0, descendants: !0 }, t), vo);
function Zk(e, t, n) { let o = new qn(n); return Promise.resolve(o); }
function TC(e) { for (let t = e.length - 1; t >= 0; t--)
    if (e[t] !== void 0)
        return e[t]; }
var Kk = (() => { class e {
    zone = I(U);
    changeDetectionScheduler = I(Nt);
    applicationRef = I(xe);
    applicationErrorHandler = I(qt);
    _onMicrotaskEmptySubscription;
    initialize() { this._onMicrotaskEmptySubscription || (this._onMicrotaskEmptySubscription = this.zone.onMicrotaskEmpty.subscribe({ next: () => { this.changeDetectionScheduler.runningTick || this.zone.run(() => { try {
            this.applicationRef.dirtyFlags |= 1, this.applicationRef._tick();
        }
        catch (n) {
            this.applicationErrorHandler(n);
        } }); } })); }
    ngOnDestroy() { this._onMicrotaskEmptySubscription?.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })(), Jk = new S("", { factory: () => !1 });
function Xk({ ngZoneFactory: e, scheduleInRootZone: t }) { return e ??= () => new U(et(K({}, BC()), { scheduleInRootZone: t })), [{ provide: Mn, useValue: !1 }, { provide: U, useFactory: e }, { provide: Et, multi: !0, useFactory: () => { let n = I(Kk, { optional: !0 }); return () => n.initialize(); } }, { provide: Et, multi: !0, useFactory: () => { let n = I(eO); return () => { n.initialize(); }; } }, { provide: Di, useValue: t ?? bp }]; }
function BL(e) { let t = e?.scheduleInRootZone, n = Xk({ ngZoneFactory: () => { let o = BC(e); return o.scheduleInRootZone = t, o.shouldCoalesceEventChangeDetection && Y("NgZone_CoalesceEvent"), new U(o); }, scheduleInRootZone: t }); return nt([{ provide: Jk, useValue: !0 }, n]); }
function BC(e) { return { enableLongStackTrace: !1, shouldCoalesceEventChangeDetection: e?.eventCoalescing ?? !1, shouldCoalesceRunChangeDetection: e?.runCoalescing ?? !1 }; }
var eO = (() => { class e {
    subscription = new zk;
    initialized = !1;
    zone = I(U);
    pendingTasks = I(Wt);
    initialize() { if (this.initialized)
        return; this.initialized = !0; let n = null; !this.zone.isStable && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (n = this.pendingTasks.add()), this.zone.runOutsideAngular(() => { this.subscription.add(this.zone.onStable.subscribe(() => { U.assertNotInAngularZone(), queueMicrotask(() => { n !== null && !this.zone.hasPendingMacrotasks && !this.zone.hasPendingMicrotasks && (this.pendingTasks.remove(n), n = null); }); })); }), this.subscription.add(this.zone.onUnstable.subscribe(() => { U.assertInAngularZone(), n ??= this.pendingTasks.add(); })); }
    ngOnDestroy() { this.subscription.unsubscribe(); }
    static \u0275fac = function (o) { return new (o || e); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "root" });
} return e; })();
var Ra = new S(""), tO = new S("");
function $r(e) { return !e.moduleRef; }
function UC(e) { let t = $r(e) ? e.r3Injector : e.moduleRef.injector, n = t.get(U); return n.run(() => { $r(e) ? e.r3Injector.resolveInjectorInitializers() : e.moduleRef.resolveInjectorInitializers(); let o = t.get(qt), r; if (n.runOutsideAngular(() => { r = n.onError.subscribe({ next: o }); }), $r(e)) {
    let i = () => t.destroy(), s = e.platformInjector.get(Ra);
    s.add(i), t.onDestroy(() => { r.unsubscribe(), s.delete(i); });
}
else {
    let i = () => e.moduleRef.destroy(), s = e.platformInjector.get(Ra);
    s.add(i), e.moduleRef.onDestroy(() => { zo(e.allPlatformModules, e.moduleRef), r.unsubscribe(), s.delete(i); });
} return oO(o, n, () => { let i = t.get(Wt), s = i.add(), a = t.get(Pd); return a.runInitializers(), a.donePromise.then(() => { let c = t.get(_f, jr); if (GE(c || jr), !t.get(tO, !0))
    return $r(e) ? t.get(xe) : (e.allPlatformModules.push(e.moduleRef), e.moduleRef); if ($r(e)) {
    let u = t.get(xe);
    return e.rootComponent !== void 0 && u.bootstrap(e.rootComponent), u;
}
else
    return $C?.(e.moduleRef, e.allPlatformModules), e.moduleRef; }).finally(() => { i.remove(s); }); }); }); }
var $C;
function MC() { $C = nO; }
function nO(e, t) { let n = e.injector.get(xe); if (e._bootstrapComponents.length > 0)
    e._bootstrapComponents.forEach(o => n.bootstrap(o));
else if (e.instance.ngDoBootstrap)
    e.instance.ngDoBootstrap(n);
else
    throw new _(-403, !1); t.push(e); }
function oO(e, t, n) { try {
    let o = n();
    return xd(o) ? o.catch(r => { throw t.runOutsideAngular(() => e(r)), r; }) : o;
}
catch (o) {
    throw t.runOutsideAngular(() => e(o)), o;
} }
var zC = (() => { class e {
    _injector;
    _modules = [];
    _destroyListeners = [];
    _destroyed = !1;
    constructor(n) { this._injector = n; }
    bootstrapModuleFactory(n, o) { let r = [Ta(), ...o?.applicationProviders ?? [], Ac], i = Nv(n.moduleType, this.injector, r); return MC(), UC({ moduleRef: i, allPlatformModules: this._modules, platformInjector: this.injector }); }
    bootstrapModule(n, o = []) { let r = Hd({}, o); return MC(), Zk(this.injector, r, n).then(i => this.bootstrapModuleFactory(i, r)); }
    onDestroy(n) { this._destroyListeners.push(n); }
    get injector() { return this._injector; }
    destroy() { if (this._destroyed)
        throw new _(404, !1); this._modules.slice().forEach(o => o.destroy()), this._destroyListeners.forEach(o => o()); let n = this._injector.get(Ra, null); n && (n.forEach(o => o()), n.clear()), this._destroyed = !0; }
    get destroyed() { return this._destroyed; }
    static \u0275fac = function (o) { return new (o || e)(Pe(Te)); };
    static \u0275prov = B({ token: e, factory: e.\u0275fac, providedIn: "platform" });
} return e; })(), yo = null;
function rO(e) { if (Fa())
    throw new _(400, !1); Fd(), yo = typeof ngServerMode > "u" || !ngServerMode ? e : null; let t = e.get(zC); return WC(e), t; }
function iO(e, t, n = []) { let o = `Platform: ${t}`, r = new S(o); return (i = []) => { let s = Fa(); if (!s) {
    let a = [...n, ...i, { provide: r, useValue: !0 }];
    s = e?.(a) ?? rO(GC(a, o));
} return typeof ngServerMode < "u" && ngServerMode ? s : sO(r); }; }
function GC(e = [], t) { return Te.create({ name: t, providers: [{ provide: cp, useValue: "platform" }, { provide: Ra, useValue: new Set([() => yo = null]) }, ...e] }); }
function sO(e) { let t = Fa(); if (!t)
    throw new _(-401, !1); return t; }
function Fa() { return typeof ngServerMode < "u" && ngServerMode ? null : yo?.get(zC) ?? null; }
function UL() { Fa()?.destroy(); }
function aO(e = []) { if (yo)
    return yo; let t = GC(e); return (typeof ngServerMode > "u" || !ngServerMode) && (yo = t), Fd(), WC(t), t; }
function $L(e) { return { provide: fu, useValue: e, multi: !0 }; }
function WC(e) { let t = e.get(fu, null); ci(e, () => { t?.forEach(n => n()); }); }
function zL(e) { return nt([]); }
function GL() { return !1; }
function WL() { }
var Aa = new WeakSet, NC = "";
function wC(e) { return e.get(bs, vu); }
function cO() { let e = [{ provide: bs, useFactory: () => { let t = !0; if (typeof ngServerMode > "u" || !ngServerMode) {
            let n = I(lt);
            t = !!window._ejsas?.[n];
        } return t && Y("NgEventReplay"), t; } }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Et, useValue: () => { let t = I(xe), { injector: n } = t; if (!Aa.has(t)) {
        let o = I(Nr);
        if (wC(n)) {
            Qg();
            let r = n.get(lt), i = Wg(r, (s, a, c) => { s.nodeType === Node.ELEMENT_NODE && (Gg(s, a, c), Du(s, o)); });
            t.onDestroy(i);
        }
    } }, multi: !0 }, { provide: Fr, useFactory: () => { let t = I(xe), { injector: n } = t; return () => { if (!wC(n) || Aa.has(t))
        return; Aa.add(t); let o = n.get(lt); t.onDestroy(() => { Aa.delete(t), typeof ngServerMode < "u" && !ngServerMode && Pf(o); }), t.whenStable().then(() => { if (t.destroyed)
        return; let r = n.get(Tu); lO(r, n); let i = n.get(Nr); i.get(NC)?.forEach(Cu), i.delete(NC); let s = r.instance; wr(n) ? t.onDestroy(() => s.cleanUp()) : s.cleanUp(); }); }; }, multi: !0 }), e; }
var lO = (e, t) => { let n = t.get(lt), o = window._ejsas[n], r = e.instance = new gC(new _a(o.c)); for (let a of o.et)
    r.addEvent(a); for (let a of o.etc)
    r.addEvent(a); let i = mC(n); r.replayEarlyEventInfos(i), Pf(n); let s = new Sa(a => { dO(t, a, a.currentTarget); }); hC(r, s); };
function uO(e, t, n) { let o = new Map, r = t[Vt], i = e.cleanup; if (!i || !r)
    return o; for (let s = 0; s < i.length;) {
    let a = i[s++], c = i[s++];
    if (typeof a != "string")
        continue;
    let l = a;
    if (!nC(l))
        continue;
    ba(l) ? n.capture.add(l) : n.regular.add(l);
    let u = O(t[c]);
    s++;
    let d = i[s++];
    (typeof d == "boolean" || d >= 0) && (o.has(u) ? o.get(u).push(l) : o.set(u, [l]));
} return o; }
function dO(e, t, n) { let o = (n && n.getAttribute(oo)) ?? ""; /d\d+/.test(o) ? fO(o, e, t, n) : t.eventPhase === Lf.REPLAY && Mu(t, n); }
function fO(e, t, n, o) { let r = t.get(Bg); r.push({ event: n, currentTarget: o }), ht(t, e, pO(r)); }
function pO(e) { return t => { let n = new Set(t), o = []; for (let { event: r, currentTarget: i } of e) {
    let s = i.getAttribute(oo);
    n.has(s) ? Mu(r, i) : o.push({ event: r, currentTarget: i });
} e.length = 0, e.push(...o); }; }
var _C = !1, SC = !1, bC = !1, hO = 1e4;
function gO() { _C || (_C = !0, em(), HE(), SI(), VE(), Hv(), dv(), By(), ry()); }
function mO() { SC || (SC = !0, qE(), ky(), Fy()); }
function yO() { bC || (bC = !0, lm()); }
function vO(e) { return e.whenStable(); }
var qL = "ngcm";
function QL() { let e = [{ provide: pn, useFactory: () => { let t = !0; return (typeof ngServerMode > "u" || !ngServerMode) && (t = !!I(eo, { optional: !0 })?.get(As, null)), t && Y("NgHydration"), t; } }, { provide: Et, useValue: () => { if (ad(!1), typeof ngServerMode < "u" && ngServerMode)
            return; let t = I(Gt); I(pn) && (dm(t), gO()); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: mu, useFactory: () => I(pn) }, { provide: Fr, useFactory: () => { let t = I(Nt); if (I(pn)) {
        let n = I(xe);
        return () => { vO(n).then(() => { n.destroyed || (cd(n), t.notify(7)); }); };
    } return () => { }; }, multi: !0 }), nt(e); }
function YL() { return [{ provide: yu, useFactory: () => I(pn) }, { provide: Et, useValue: () => { I(pn) && (mO(), ad(!0), Y("NgI18nHydration")); }, multi: !0 }]; }
function ZL() { let e = [cO(), { provide: Eu, useValue: !0 }, { provide: ut, useClass: Yg }, { provide: Et, useValue: () => { yO(), Y("NgIncrementalHydration"); }, multi: !0 }]; return (typeof ngServerMode > "u" || !ngServerMode) && e.push({ provide: Fr, useFactory: () => { let t = I(Te), n = I(Gt); return () => { let o = um(t), r = by(n, n.body); aE(t, o, r), am(n, t); }; }, multi: !0 }), e; }
var AC = hO - 1e3, Vf = class {
    openTasks = new Map;
    add(t) { this.openTasks.set(t, new Error("Task stack tracking error")); }
    remove(t) { this.openTasks.delete(t); }
};
function KL() { let e = new Vf, { openTasks: t } = e; return nt([{ provide: Ap, useValue: e }, tE(() => { console.warn("Stability debugging utility was provided in production mode. This will cause debug code to be included in production bundles. If this is intentional because you are debugging stability issues in a production environment, you can ignore this warning."); let n = I(U), o = I(xe), r = null; typeof Zone < "u" && n.run(() => { r = Zone.current.get("TaskTrackingZone"); }), n.runOutsideAngular(() => { let i = setTimeout(() => { if (console.debug(`---- Application did not stabilize within ${AC / 1e3} seconds ----`), typeof Zone < "u" && !r && console.info('Zone.js is present but no TaskTrackingZone found. To enable better debugging of tasks in the Angular Zone, import "zone.js/plugins/task-tracking" in your application.'), r?.macroTasks?.length) {
        console.group("Macrotasks keeping Angular Zone unstable:");
        for (let s of r?.macroTasks ?? [])
            console.debug(s.creationLocation.stack);
        console.groupEnd();
    } console.group("PendingTasks keeping application unstable:"); for (let s of t.values())
        console.debug(s.stack); console.groupEnd(); }, AC); o.whenStable().then(() => { clearTimeout(i); }); }); })]); }
function JL(e) { let t = Cd(e); if (!t)
    throw qC(e); return new qn(t); }
function XL(e) { let t = Cd(e); if (!t)
    throw qC(e); return t; }
function qC(e) { return new _(920, !1); }
var EO = (() => { class e {
    static __NG_ELEMENT_ID__ = IO;
} return e; })();
function IO(e) { return DO(M(), g(), (e & 16) === 16); }
function DO(e, t, n) { if (me(e) && !n) {
    let o = pe(e.index, t);
    return new kt(o, o);
}
else if (e.type & 175) {
    let o = t[J];
    return new kt(o, t);
} return null; }
var jf = class extends EO {
}, RC = class extends jf {
}, ka = class {
    supports(t) { return lr(t); }
    create(t) { return new Bf(t); }
}, CO = (e, t) => t, Bf = class {
    length = 0;
    collection;
    _linkedRecords = null;
    _unlinkedRecords = null;
    _previousItHead = null;
    _itHead = null;
    _itTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _movesHead = null;
    _movesTail = null;
    _removalsHead = null;
    _removalsTail = null;
    _identityChangesHead = null;
    _identityChangesTail = null;
    _trackByFn;
    constructor(t) { this._trackByFn = t || CO; }
    forEachItem(t) { let n; for (n = this._itHead; n !== null; n = n._next)
        t(n); }
    forEachOperation(t) { let n = this._itHead, o = this._removalsHead, r = 0, i = null; for (; n || o;) {
        let s = !o || n && n.currentIndex < kC(o, r, i) ? n : o, a = kC(s, r, i), c = s.currentIndex;
        if (s === o)
            r--, o = o._nextRemoved;
        else if (n = n._next, s.previousIndex == null)
            r++;
        else {
            i || (i = []);
            let l = a - r, u = c - r;
            if (l != u) {
                for (let f = 0; f < l; f++) {
                    let p = f < i.length ? i[f] : i[f] = 0, h = p + f;
                    u <= h && h < l && (i[f] = p + 1);
                }
                let d = s.previousIndex;
                i[d] = u - l;
            }
        }
        a !== c && t(s, a, c);
    } }
    forEachPreviousItem(t) { let n; for (n = this._previousItHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachMovedItem(t) { let n; for (n = this._movesHead; n !== null; n = n._nextMoved)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    forEachIdentityChange(t) { let n; for (n = this._identityChangesHead; n !== null; n = n._nextIdentityChange)
        t(n); }
    diff(t) { if (t == null && (t = []), !lr(t))
        throw new _(900, !1); return this.check(t) ? this : null; }
    onDestroy() { }
    check(t) { this._reset(); let n = this._itHead, o = !1, r, i, s; if (Array.isArray(t)) {
        this.length = t.length;
        for (let a = 0; a < this.length; a++)
            i = t[a], s = this._trackByFn(a, i), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, i, s, a), o = !0) : (o && (n = this._verifyReinsertion(n, i, s, a)), Object.is(n.item, i) || this._addIdentityChange(n, i)), n = n._next;
    }
    else
        r = 0, Zy(t, a => { s = this._trackByFn(r, a), n === null || !Object.is(n.trackById, s) ? (n = this._mismatch(n, a, s, r), o = !0) : (o && (n = this._verifyReinsertion(n, a, s, r)), Object.is(n.item, a) || this._addIdentityChange(n, a)), n = n._next, r++; }), this.length = r; return this._truncate(n), this.collection = t, this.isDirty; }
    get isDirty() { return this._additionsHead !== null || this._movesHead !== null || this._removalsHead !== null || this._identityChangesHead !== null; }
    _reset() { if (this.isDirty) {
        let t;
        for (t = this._previousItHead = this._itHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._additionsHead; t !== null; t = t._nextAdded)
            t.previousIndex = t.currentIndex;
        for (this._additionsHead = this._additionsTail = null, t = this._movesHead; t !== null; t = t._nextMoved)
            t.previousIndex = t.currentIndex;
        this._movesHead = this._movesTail = null, this._removalsHead = this._removalsTail = null, this._identityChangesHead = this._identityChangesTail = null;
    } }
    _mismatch(t, n, o, r) { let i; return t === null ? i = this._itTail : (i = t._prev, this._remove(t)), t = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._reinsertAfter(t, i, r)) : (t = this._linkedRecords === null ? null : this._linkedRecords.get(o, r), t !== null ? (Object.is(t.item, n) || this._addIdentityChange(t, n), this._moveAfter(t, i, r)) : t = this._addAfter(new Uf(n, o), i, r)), t; }
    _verifyReinsertion(t, n, o, r) { let i = this._unlinkedRecords === null ? null : this._unlinkedRecords.get(o, null); return i !== null ? t = this._reinsertAfter(i, t._prev, r) : t.currentIndex != r && (t.currentIndex = r, this._addToMoves(t, r)), t; }
    _truncate(t) { for (; t !== null;) {
        let n = t._next;
        this._addToRemovals(this._unlink(t)), t = n;
    } this._unlinkedRecords !== null && this._unlinkedRecords.clear(), this._additionsTail !== null && (this._additionsTail._nextAdded = null), this._movesTail !== null && (this._movesTail._nextMoved = null), this._itTail !== null && (this._itTail._next = null), this._removalsTail !== null && (this._removalsTail._nextRemoved = null), this._identityChangesTail !== null && (this._identityChangesTail._nextIdentityChange = null); }
    _reinsertAfter(t, n, o) { this._unlinkedRecords !== null && this._unlinkedRecords.remove(t); let r = t._prevRemoved, i = t._nextRemoved; return r === null ? this._removalsHead = i : r._nextRemoved = i, i === null ? this._removalsTail = r : i._prevRemoved = r, this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _moveAfter(t, n, o) { return this._unlink(t), this._insertAfter(t, n, o), this._addToMoves(t, o), t; }
    _addAfter(t, n, o) { return this._insertAfter(t, n, o), this._additionsTail === null ? this._additionsTail = this._additionsHead = t : this._additionsTail = this._additionsTail._nextAdded = t, t; }
    _insertAfter(t, n, o) { let r = n === null ? this._itHead : n._next; return t._next = r, t._prev = n, r === null ? this._itTail = t : r._prev = t, n === null ? this._itHead = t : n._next = t, this._linkedRecords === null && (this._linkedRecords = new Oa), this._linkedRecords.put(t), t.currentIndex = o, t; }
    _remove(t) { return this._addToRemovals(this._unlink(t)); }
    _unlink(t) { this._linkedRecords !== null && this._linkedRecords.remove(t); let n = t._prev, o = t._next; return n === null ? this._itHead = o : n._next = o, o === null ? this._itTail = n : o._prev = n, t; }
    _addToMoves(t, n) { return t.previousIndex === n || (this._movesTail === null ? this._movesTail = this._movesHead = t : this._movesTail = this._movesTail._nextMoved = t), t; }
    _addToRemovals(t) { return this._unlinkedRecords === null && (this._unlinkedRecords = new Oa), this._unlinkedRecords.put(t), t.currentIndex = null, t._nextRemoved = null, this._removalsTail === null ? (this._removalsTail = this._removalsHead = t, t._prevRemoved = null) : (t._prevRemoved = this._removalsTail, this._removalsTail = this._removalsTail._nextRemoved = t), t; }
    _addIdentityChange(t, n) { return t.item = n, this._identityChangesTail === null ? this._identityChangesTail = this._identityChangesHead = t : this._identityChangesTail = this._identityChangesTail._nextIdentityChange = t, t; }
}, Uf = class {
    item;
    trackById;
    currentIndex = null;
    previousIndex = null;
    _nextPrevious = null;
    _prev = null;
    _next = null;
    _prevDup = null;
    _nextDup = null;
    _prevRemoved = null;
    _nextRemoved = null;
    _nextAdded = null;
    _nextMoved = null;
    _nextIdentityChange = null;
    constructor(t, n) { this.item = t, this.trackById = n; }
}, $f = class {
    _head = null;
    _tail = null;
    add(t) { this._head === null ? (this._head = this._tail = t, t._nextDup = null, t._prevDup = null) : (this._tail._nextDup = t, t._prevDup = this._tail, t._nextDup = null, this._tail = t); }
    get(t, n) { let o; for (o = this._head; o !== null; o = o._nextDup)
        if ((n === null || n <= o.currentIndex) && Object.is(o.trackById, t))
            return o; return null; }
    remove(t) { let n = t._prevDup, o = t._nextDup; return n === null ? this._head = o : n._nextDup = o, o === null ? this._tail = n : o._prevDup = n, this._head === null; }
}, Oa = class {
    map = new Map;
    put(t) { let n = t.trackById, o = this.map.get(n); o || (o = new $f, this.map.set(n, o)), o.add(t); }
    get(t, n) { let o = t, r = this.map.get(o); return r ? r.get(t, n) : null; }
    remove(t) { let n = t.trackById; return this.map.get(n).remove(t) && this.map.delete(n), t; }
    get isEmpty() { return this.map.size === 0; }
    clear() { this.map.clear(); }
};
function kC(e, t, n) { let o = e.previousIndex; if (o === null)
    return o; let r = 0; return n && o < n.length && (r = n[o]), o + t + r; }
var xa = class {
    supports(t) { return t instanceof Map || ca(t); }
    create() { return new zf; }
}, zf = class {
    _records = new Map;
    _mapHead = null;
    _appendAfter = null;
    _previousMapHead = null;
    _changesHead = null;
    _changesTail = null;
    _additionsHead = null;
    _additionsTail = null;
    _removalsHead = null;
    get isDirty() { return this._additionsHead !== null || this._changesHead !== null || this._removalsHead !== null; }
    forEachItem(t) { let n; for (n = this._mapHead; n !== null; n = n._next)
        t(n); }
    forEachPreviousItem(t) { let n; for (n = this._previousMapHead; n !== null; n = n._nextPrevious)
        t(n); }
    forEachChangedItem(t) { let n; for (n = this._changesHead; n !== null; n = n._nextChanged)
        t(n); }
    forEachAddedItem(t) { let n; for (n = this._additionsHead; n !== null; n = n._nextAdded)
        t(n); }
    forEachRemovedItem(t) { let n; for (n = this._removalsHead; n !== null; n = n._nextRemoved)
        t(n); }
    diff(t) { if (!t)
        t = new Map;
    else if (!(t instanceof Map || ca(t)))
        throw new _(900, !1); return this.check(t) ? this : null; }
    check(t) { this._reset(); let n = this._mapHead; if (this._appendAfter = null, this._forEach(t, (o, r) => { if (n && n.key === r)
        this._maybeAddToChanges(n, o), this._appendAfter = n, n = n._next;
    else {
        let i = this._getOrCreateRecordForKey(r, o);
        n = this._insertBeforeOrAppend(n, i);
    } }), n) {
        n._prev && (n._prev._next = null), this._removalsHead = n;
        for (let o = n; o !== null; o = o._nextRemoved)
            o === this._mapHead && (this._mapHead = null), this._records.delete(o.key), o._nextRemoved = o._next, o.previousValue = o.currentValue, o.currentValue = null, o._prev = null, o._next = null;
    } return this._changesTail && (this._changesTail._nextChanged = null), this._additionsTail && (this._additionsTail._nextAdded = null), this.isDirty; }
    _insertBeforeOrAppend(t, n) { if (t) {
        let o = t._prev;
        return n._next = t, n._prev = o, t._prev = n, o && (o._next = n), t === this._mapHead && (this._mapHead = n), this._appendAfter = t, t;
    } return this._appendAfter ? (this._appendAfter._next = n, n._prev = this._appendAfter) : this._mapHead = n, this._appendAfter = n, null; }
    _getOrCreateRecordForKey(t, n) { if (this._records.has(t)) {
        let r = this._records.get(t);
        this._maybeAddToChanges(r, n);
        let i = r._prev, s = r._next;
        return i && (i._next = s), s && (s._prev = i), r._next = null, r._prev = null, r;
    } let o = new Gf(t); return this._records.set(t, o), o.currentValue = n, this._addToAdditions(o), o; }
    _reset() { if (this.isDirty) {
        let t;
        for (this._previousMapHead = this._mapHead, t = this._previousMapHead; t !== null; t = t._next)
            t._nextPrevious = t._next;
        for (t = this._changesHead; t !== null; t = t._nextChanged)
            t.previousValue = t.currentValue;
        for (t = this._additionsHead; t != null; t = t._nextAdded)
            t.previousValue = t.currentValue;
        this._changesHead = this._changesTail = null, this._additionsHead = this._additionsTail = null, this._removalsHead = null;
    } }
    _maybeAddToChanges(t, n) { Object.is(n, t.currentValue) || (t.previousValue = t.currentValue, t.currentValue = n, this._addToChanges(t)); }
    _addToAdditions(t) { this._additionsHead === null ? this._additionsHead = this._additionsTail = t : (this._additionsTail._nextAdded = t, this._additionsTail = t); }
    _addToChanges(t) { this._changesHead === null ? this._changesHead = this._changesTail = t : (this._changesTail._nextChanged = t, this._changesTail = t); }
    _forEach(t, n) { t instanceof Map ? t.forEach(n) : Object.keys(t).forEach(o => n(t[o], o)); }
}, Gf = class {
    key;
    previousValue = null;
    currentValue = null;
    _nextPrevious = null;
    _next = null;
    _prev = null;
    _nextAdded = null;
    _nextRemoved = null;
    _nextChanged = null;
    constructor(t) { this.key = t; }
};
function OC() { return new QC([new ka]); }
var QC = (() => { class e {
    factories;
    static \u0275prov = B({ token: e, providedIn: "root", factory: OC });
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o != null) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = I(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || OC()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o != null)
        return o; throw new _(901, !1); }
} return e; })();
function xC() { return new YC([new xa]); }
var YC = (() => { class e {
    static \u0275prov = B({ token: e, providedIn: "root", factory: xC });
    factories;
    constructor(n) { this.factories = n; }
    static create(n, o) { if (o) {
        let r = o.factories.slice();
        n = n.concat(r);
    } return new e(n); }
    static extend(n) { return { provide: e, useFactory: () => { let o = I(e, { optional: !0, skipSelf: !0 }); return e.create(n, o || xC()); } }; }
    find(n) { let o = this.factories.find(r => r.supports(n)); if (o)
        return o; throw new _(901, !1); }
} return e; })(), TO = [new xa], MO = [new ka], eP = new QC(MO), tP = new YC(TO), nP = iO(null, "core", []), oP = (() => { class e {
    constructor(n) { }
    static \u0275fac = function (o) { return new (o || e)(Pe(xe)); };
    static \u0275mod = Md({ type: e });
    static \u0275inj = Do({});
} return e; })();
function rP(e) { let { rootComponent: t, appProviders: n, platformProviders: o, platformRef: r } = e; if (x(R.BootstrapApplicationStart), typeof ngServerMode < "u" && ngServerMode && !r)
    throw new _(-401, !1); try {
    let i = r?.injector ?? aO(o), s = [Ta(), Ac, ...n || []], a = new dr({ providers: s, parent: i, debugName: "", runEnvironmentInitializers: !1 });
    return UC({ r3Injector: a.injector, platformInjector: i, rootComponent: t });
}
catch (i) {
    return Promise.reject(i);
}
finally {
    x(R.BootstrapApplicationEnd);
} }
var Wf = class {
    views = [];
    indexByContent = new Map;
    add(t) { let n = JSON.stringify(t); if (!this.indexByContent.has(n)) {
        let o = this.views.length;
        return this.views.push(t), this.indexByContent.set(n, o), o;
    } return this.indexByContent.get(n); }
    getAll() { return this.views; }
}, NO = 0;
function ZC(e) { return e.ssrId || (e.ssrId = `t${NO++}`), e.ssrId; }
function KC(e, t, n) { let o = []; return Un(e, t, n, o), o.length; }
function wO(e) { let t = []; return ea(e, t), t.length; }
function JC(e, t) { let n = e[j]; return n && !n.hasAttribute(fn) ? La(n, e, null, t) : null; }
function XC(e, t) { let n = Ao(e[j]), o = JC(n, t); if (o === null)
    return; let r = O(n[j]), i = e[q], s = La(r, i, null, t), a = n[T], c = `${o}|${s}`; a.setAttribute(r, Ln, c); }
function iP(e, t) { let n = e.injector, o = Oy(n), r = wr(n), i = new Wf, s = new Map, a = e._views, c = n.get(bs, vu), l = { regular: new Set, capture: new Set }, u = new Map; e.injector.get(lt); for (let p of a) {
    let h = Nu(p);
    if (h !== null) {
        let y = { serializedViewCollection: i, corruptedTextNodes: s, isI18nHydrationEnabled: o, isIncrementalHydrationEnabled: r, i18nChildren: new Map, eventTypesToReplay: l, shouldReplayEvents: c, deferBlocks: u };
        ee(h) ? XC(h, y) : JC(h, y), RO(s, t);
    }
} let d = i.getAll(), f = n.get(eo); if (f.set(As, d), u.size > 0) {
    let p = {};
    for (let [h, y] of u.entries())
        p[h] = y;
    f.set(Rs, p);
} return l; }
function _O(e, t, n, o, r) { let i = [], s = ""; for (let a = V; a < e.length; a++) {
    let c = e[a], l, u, d;
    if (We(c) && (c = c[E], ee(c))) {
        u = wO(c) + 1, XC(c, r);
        let p = Ao(c[j]);
        d = { [ws]: p[m].ssrId, [st]: u };
    }
    if (!d) {
        let p = c[m];
        p.type === 1 ? (l = p.ssrId, u = 1) : (l = ZC(p), u = KC(p, c, p.firstChild)), d = { [ws]: l, [st]: u };
        let h = !1;
        if ($v(n[m], t)) {
            let y = ye(n, t), v = ce(n[m], t);
            if (r.isIncrementalHydrationEnabled && v.hydrateTriggers !== null) {
                let D = `d${r.deferBlocks.size}`;
                v.hydrateTriggers.has(7) && (h = !0);
                let b = [];
                ea(e, b);
                let X = { [st]: b.length, [Tr]: y[pt] }, Le = SO(v.hydrateTriggers);
                Le.length > 0 && (X[Mr] = Le), o !== null && (X[gu] = o), r.deferBlocks.set(D, X);
                let Me = O(e);
                Me !== void 0 ? Me.nodeType === Node.COMMENT_NODE && LC(Me, D) : LC(Me, D), h || OO(v, b, D, r), o = D, d[Ss] = D;
            }
            d[Tr] = y[pt];
        }
        if (!h) {
            let y = O(c[j]);
            (c[m].type !== 1 || y === null || !y.hasAttribute(fn)) && Object.assign(d, eT(e[a], o, r));
        }
    }
    let f = JSON.stringify(d);
    if (i.length > 0 && f === s) {
        let p = i[i.length - 1];
        p[Dr] ??= 1, p[Dr]++;
    }
    else
        s = f, i.push(d);
} return i; }
function SO(e) { let t = new Set([0, 1, 2, 5]), n = []; for (let [o, r] of e)
    t.has(o) && (r === null ? n.push(o) : r.type === 5 ? n.push({ trigger: o, delay: r.delay }) : n.push({ trigger: o, intersectionObserverOptions: r.intersectionObserverOptions })); return n; }
function zr(e, t, n, o) { let r = t.index - E; e[Cr] ??= {}, e[Cr][r] ??= Sy(t, n, o); }
function Ff(e, t) { let n = typeof t == "number" ? t : t.index - E; e[no] ??= [], e[no].includes(n) || e[no].push(n); }
function eT(e, t = null, n) { let o = {}, r = e[m], i = xy(r, n), s = n.shouldReplayEvents ? uO(r, e, n.eventTypesToReplay) : null; for (let a = E; a < r.bindingStartIndex; a++) {
    let c = r.data[a], l = a - E, u = Ly(e, a, n);
    if (u) {
        o[_s] ??= {}, o[_s][l] = u.caseQueue;
        for (let d of u.disconnectedNodes)
            Ff(o, d);
        for (let d of u.disjointNodes) {
            let f = r.data[d + E];
            zr(o, f, e, i);
        }
        continue;
    }
    if (Es(c) && !ro(c)) {
        if (ee(e[a]) && c.tView && (o[Ns] ??= {}, o[Ns][l] = ZC(c.tView)), uo(c, e) && kO(c)) {
            Ff(o, c);
            continue;
        }
        if (Array.isArray(c.projection)) {
            for (let d of c.projection)
                if (d)
                    if (!Array.isArray(d))
                        !nc(d) && !Xn(d) && (uo(d, e) ? Ff(o, d) : zr(o, d, e, i));
                    else
                        throw Ey(O(e[a]));
        }
        if (bO(o, c, e, i), ee(e[a])) {
            let d = e[a][j];
            if (Array.isArray(d)) {
                let f = O(d);
                f.hasAttribute(fn) || La(f, d, t, n);
            }
            o[to] ??= {}, o[to][l] = _O(e[a], c, e, t, n);
        }
        else if (Array.isArray(e[a]) && !dg(c)) {
            let d = O(e[a][j]);
            d.hasAttribute(fn) || La(d, e[a], t, n);
        }
        else if (c.type & 8)
            o[Ir] ??= {}, o[Ir][l] = KC(r, e, c.child);
        else if (c.type & 144) {
            let d = c.next;
            for (; d !== null && d.type & 144;)
                d = d.next;
            d && !Xn(d) && zr(o, d, e, i);
        }
        else if (c.type & 1) {
            let d = O(e[a]);
            _u(n, d);
        }
        if (s && c.type & 2) {
            let d = O(e[a]);
            s.has(d) && Iu(d, s.get(d), t);
        }
    }
} return o; }
function bO(e, t, n, o) { nc(t) || (t.projectionNext && t.projectionNext !== t.next && !Xn(t.projectionNext) && zr(e, t.projectionNext, n, o), t.prev === null && t.parent !== null && uo(t.parent, n) && !uo(t, n) && zr(e, t, n, o)); }
function AO(e) { let t = e[H]; if (!t?.constructor)
    return !1; let n = W(t.constructor); return n?.encapsulation === ke.ShadowDom || n?.encapsulation === ke.ExperimentalIsolatedShadowDom; }
function La(e, t, n, o) { let r = t[T]; if (dp(t) && !ra() || AO(t))
    return r.setAttribute(e, fn, ""), null; {
    let i = eT(t, n, o), s = o.serializedViewCollection.add(i);
    return r.setAttribute(e, Ln, s.toString()), s;
} }
function LC(e, t) { e.textContent = `ngh=${t}`; }
function RO(e, t) { for (let [n, o] of e)
    n.after(t.createComment(o)); }
function kO(e) { let t = e; for (; t != null;) {
    if (me(t))
        return !0;
    t = t.parent;
} return !1; }
function OO(e, t, n, o) { let r = sm(e.hydrateTriggers); for (let i of r)
    o.eventTypesToReplay.regular.add(i); if (r.length > 0) {
    let i = t.filter(s => s.nodeType === Node.ELEMENT_NODE);
    for (let s of i)
        Iu(s, r, n);
} }
function sP(e) { return typeof e == "boolean" ? e : e != null && e !== "false"; }
function aP(e, t = NaN) { return !isNaN(parseFloat(e)) && !isNaN(Number(e)) ? Number(e) : t; }
var xO = "\u{1F170}\uFE0F", Ha = !1;
function cP(e) { if (!Ha)
    return; let { startLabel: t } = tT(e); performance.mark(t); }
function lP(e) { if (!Ha)
    return; let { startLabel: t, labelName: n, endLabel: o } = tT(e); performance.mark(o), performance.measure(n, t, o), performance.clearMarks(t), performance.clearMarks(o); }
function tT(e) { let t = `${xO}:${e}`; return { labelName: t, startLabel: `start:${t}`, endLabel: `end:${t}` }; }
var PC = !1;
function uP() { if (!PC && (typeof performance > "u" || !performance.mark || !performance.measure)) {
    PC = !0, console.warn("Performance API is not supported on this platform");
    return;
} Ha = !0; }
function dP() { Ha = !1; }
function fP(e) { }
function pP(e) { return oe({ usage: 1, kind: "directive", type: e.type }).compileDirectiveDeclaration(ge, `ng:///${e.type.name}/\u0275fac.js`, e); }
function hP(e) { Ad(e.type, e.decorators, e.ctorParameters ?? null, e.propDecorators ?? null); }
function gP(e) { Yv(e.type, e.resolveDeferredDeps, (...t) => { let n = e.resolveMetadata(...t); Ad(e.type, n.decorators, n.ctorParameters, n.propDecorators); }); }
function mP(e) { return oe({ usage: 1, kind: "component", type: e.type }).compileComponentDeclaration(ge, `ng:///${e.type.name}/\u0275cmp.js`, e); }
function yP(e) { return oe({ usage: 1, kind: LO(e.target), type: e.type }).compileFactoryDeclaration(ge, `ng:///${e.type.name}/\u0275fac.js`, e); }
function LO(e) { switch (e) {
    case mo.Directive: return "directive";
    case mo.Component: return "component";
    case mo.Injectable: return "injectable";
    case mo.Pipe: return "pipe";
    case mo.NgModule: return "NgModule";
} }
function vP(e) { return oe({ usage: 1, kind: "injectable", type: e.type }).compileInjectableDeclaration(ge, `ng:///${e.type.name}/\u0275prov.js`, e); }
function EP(e) { return oe({ usage: 1, kind: "NgModule", type: e.type }).compileInjectorDeclaration(ge, `ng:///${e.type.name}/\u0275inj.js`, e); }
function IP(e) { return oe({ usage: 1, kind: "NgModule", type: e.type }).compileNgModuleDeclaration(ge, `ng:///${e.type.name}/\u0275mod.js`, e); }
function DP(e) { return oe({ usage: 1, kind: "pipe", type: e.type }).compilePipeDeclaration(ge, `ng:///${e.type.name}/\u0275pipe.js`, e); }
var Hf = Symbol("NOT_SET"), nT = new Set, PO = et(K({}, Ba), { kind: "afterRenderEffectPhase", consumerIsAlwaysLive: !0, consumerAllowSignalWrites: !0, value: Hf, cleanup: null, consumerMarkedDirty() { if (this.sequence.impl.executing) {
        if (this.sequence.lastPhase === null || this.sequence.lastPhase < this.phase)
            return;
        this.sequence.erroredOrDestroyed = !0;
    } this.sequence.scheduler.notify(7); }, phaseFn(e) { if (this.sequence.lastPhase = this.phase, !this.dirty)
        return this.signal; if (this.dirty = !1, this.value !== Hf && !Qr(this))
        return this.signal; try {
        for (let r of this.cleanup ?? nT)
            r();
    }
    finally {
        this.cleanup?.clear();
    } let t = []; e !== void 0 && t.push(e), t.push(this.registerCleanupFn); let n = Eo(this), o; try {
        o = this.userFn.apply(null, t);
    }
    finally {
        qr(this, n);
    } return (this.value === Hf || !this.equal(this.value, o)) && (this.value = o, this.version++), this.signal; } }), qf = class extends or {
    scheduler;
    lastPhase = null;
    nodes = [void 0, void 0, void 0, void 0];
    onDestroyFns = null;
    constructor(t, n, o, r, i, s = null) { super(t, [void 0, void 0, void 0, void 0], o, !1, i.get(Po), s), this.scheduler = r; for (let a of Wu) {
        let c = n[a];
        if (c === void 0)
            continue;
        let l = Object.create(PO);
        l.sequence = this, l.phase = a, l.userFn = c, l.dirty = !0, l.signal = () => (Wr(l), l.value), l.signal[tt] = l, l.registerCleanupFn = u => (l.cleanup ??= new Set).add(u), this.nodes[a] = l, this.hooks[a] = u => l.phaseFn(u);
    } }
    afterRun() { super.afterRun(), this.lastPhase = null; }
    destroy() { if (this.onDestroyFns !== null)
        for (let t of this.onDestroyFns)
            t(); super.destroy(); for (let t of this.nodes)
        if (t)
            try {
                for (let n of t.cleanup ?? nT)
                    n();
            }
            finally {
                Io(t);
            } }
};
function CP(e, t) { if (typeof ngServerMode < "u" && ngServerMode)
    return zs; let n = t?.injector ?? I(Te), o = n.get(Nt), r = n.get($s), i = n.get(gn, null, { optional: !0 }); r.impl ??= n.get(qu); let s = e; typeof s == "function" && (s = { mixedReadWrite: e }); let a = n.get(Ii, null, { optional: !0 }), c = new qf(r.impl, [s.earlyRead, s.write, s.mixedReadWrite, s.read], a?.view, o, n, i?.snapshot(null)); return r.impl.register(c), c; }
function TP(e) { return new Qf(Rd(e) ? e : Qt(e)); }
var Qf = class {
    snapshot;
    constructor(t) { this.snapshot = t; }
    get state() { return this.snapshot(); }
    value = Qt(() => { if (this.state.status === "error")
        throw new xp(this.state.error); return this.state.value; });
    status = Qt(() => this.state.status);
    error = Qt(() => this.state.status === "error" ? this.state.error : void 0);
    isLoading = Qt(() => this.state.status === "loading" || this.state.status === "reloading");
    isValueDefined = Qt(() => this.state.status !== "error" && this.state.value !== void 0);
    hasValue() { return this.isValueDefined(); }
};
function MP(e, t) { let n = W(e), o = t.elementInjector || ai(); return new Ot(n).create(o, t.projectableNodes, t.hostElement, t.environmentInjector, t.directives, t.bindings); }
function NP(e) { let t = W(e); if (!t)
    return null; let n = new Ot(t); return { get selector() { return n.selector; }, get type() { return n.componentType; }, get inputs() { return n.inputs; }, get outputs() { return n.outputs; }, get ngContentSelectors() { return n.ngContentSelectors; }, get isStandalone() { return t.standalone; }, get isSignal() { return t.signals; } }; }
function wP(...e) { return e.reduce((t, n) => Object.assign(t, n, { providers: [...t.providers, ...n.providers] }), { providers: [] }); }
var _P = new S("", { providedIn: "platform", factory: () => null }), SP = new S("", { providedIn: "platform", factory: () => null }), bP = new S("", { providedIn: "platform", factory: () => null });
export { FM as ANIMATION_MODULE_TYPE, Fr as APP_BOOTSTRAP_LISTENER, lt as APP_ID, Ld as APP_INITIALIZER, Pd as ApplicationInitStatus, oP as ApplicationModule, xe as ApplicationRef, Tg as Attribute, QD as COMPILER_OPTIONS, HM as CSP_NONCE, uN as CUSTOM_ELEMENTS_SCHEMA, Cs as ChangeDetectionStrategy, EO as ChangeDetectorRef, tk as Compiler, su as CompilerFactory, QR as Component, aa as ComponentFactory, xr as ComponentFactoryResolver, zy as ComponentRef, HL as ContentChild, FL as ContentChildren, rk as DEFAULT_CURRENCY_CODE, Gt as DOCUMENT, dn as DebugElement, au as DebugEventListener, mr as DebugNode, Bf as DefaultIterableDiffer, Po as DestroyRef, qD as Directive, Et as ENVIRONMENT_INITIALIZER, Er as ElementRef, RC as EmbeddedViewRef, It as EnvironmentInjector, bc as ErrorHandler, vT as EventEmitter, bL as HOST_TAG_NAME, ng as Host, yC as HostAttributeToken, JR as HostBinding, XR as HostListener, pT as INJECTOR, Jh as Inject, cM as Injectable, S as InjectionToken, Te as Injector, ZR as Input, QC as IterableDiffers, YC as KeyValueDiffers, _f as LOCALE_ID, Vm as MAX_ANIMATION_TIMEOUT, ZD as MissingTranslationStrategy, vs as ModuleWithComponentFactories, dN as NO_ERRORS_SCHEMA, ek as NgModule, Tv as NgModuleFactory, Gn as NgModuleRef, U as NgZone, Xh as Optional, KR as Output, xc as OutputEmitterRef, PM as PLATFORM_ID, fu as PLATFORM_INITIALIZER, kc as PendingTasks, YR as Pipe, zC as PlatformRef, vo as Query, Zi as QueryList, _P as REQUEST, bP as REQUEST_CONTEXT, SP as RESPONSE_INIT, tS as Renderer2, cr as RendererFactory2, ts as RendererStyleFlags2, Gy as Sanitizer, Q as SecurityContext, eg as Self, Gi as SimpleChange, tg as SkipSelf, ik as TRANSLATIONS, sk as TRANSLATIONS_FORMAT, ir as TemplateRef, Hb as Testability, Jv as TestabilityRegistry, eo as TransferState, og as Type, aT as VERSION, sT as Version, jL as ViewChild, VL as ViewChildren, ua as ViewContainerRef, ke as ViewEncapsulation, jf as ViewRef, zm as afterEveryRender, Qu as afterNextRender, CP as afterRenderEffect, ak as asNativeElements, mT as assertInInjectionContext, DT as assertNotInReactiveContext, sO as assertPlatform, sP as booleanAttribute, Qt as computed, xL as contentChild, LL as contentChildren, MP as createComponent, Td as createEnvironmentInjector, Mv as createNgModule, KS as createNgModuleRef, rO as createPlatform, iO as createPlatformFactory, UL as destroyPlatform, TT as effect, WL as enableProdMode, xb as enableProfiling, za as forwardRef, yr as getDebugNode, JL as getModuleFactory, XL as getNgModuleById, Fa as getPlatform, gT as importProvidersFrom, I as inject, RL as input, rv as inputBinding, GL as isDevMode, Rd as isSignal, Co as isStandalone, kd as isWritableSignal, wT as linkedSignal, nt as makeEnvironmentProviders, jM as makeStateKey, wP as mergeApplicationConfig, PL as model, aP as numberAttribute, AL as output, iv as outputBinding, nP as platformCore, tE as provideAppInitializer, ET as provideBrowserGlobalErrorListeners, zL as provideCheckNoChangesConfig, hT as provideEnvironmentInitializer, QN as provideNgReflectAttributes, $L as providePlatformInitializer, KL as provideStabilityDebugging, BL as provideZoneChangeDetection, nk as provideZonelessChangeDetection, NP as reflectComponentType, G as resolveForwardRef, _T as resource, TP as resourceFromSnapshots, ci as runInInjectionContext, Xv as setTestabilityGetter, Rc as signal, TS as twoWayBinding, NT as untracked, kL as viewChild, OL as viewChildren, Hm as \u0275ANIMATIONS_DISABLED, xg as \u0275AcxChangeDetectionStrategy, Lg as \u0275AcxViewEncapsulation, $s as \u0275AfterRenderManager, qL as \u0275CLIENT_RENDER_MODE_FLAG, V as \u0275CONTAINER_HEADER_OFFSET, Nt as \u0275ChangeDetectionScheduler, aa as \u0275ComponentFactory, Ob as \u0275Console, jr as \u0275DEFAULT_LOCALE_ID, Wv as \u0275DEFER_BLOCK_CONFIG, Sb as \u0275DEFER_BLOCK_DEPENDENCY_INTERCEPTOR, ut as \u0275DEHYDRATED_BLOCK_REGISTRY, Sd as \u0275DeferBlockBehavior, $ as \u0275DeferBlockState, tO as \u0275ENABLE_ROOT_COMPONENT_BOOTSTRAP, Bg as \u0275EVENT_REPLAY_QUEUE, Oc as \u0275EffectScheduler, Gk as \u0275Framework, nm as \u0275HydrationStatus, VM as \u0275IMAGE_CONFIG, Pg as \u0275IMAGE_CONFIG_DEFAULTS, cp as \u0275INJECTOR_SCOPE, SL as \u0275INPUT_SIGNAL_BRAND_WRITE_TYPE, qt as \u0275INTERNAL_APPLICATION_ERROR_HANDLER, BM as \u0275IS_ENABLED_BLOCKING_INITIAL_NAVIGATION, pn as \u0275IS_HYDRATION_DOM_REUSE_ENABLED, Eu as \u0275IS_INCREMENTAL_HYDRATION_ENABLED, Nr as \u0275JSACTION_BLOCK_ELEMENT_MAP, Tu as \u0275JSACTION_EVENT_CONTRACT, Ki as \u0275LContext, Qn as \u0275LocaleDataIndex, yt as \u0275NG_COMP_DEF, vn as \u0275NG_DIR_DEF, Ft as \u0275NG_ELEMENT_ID, Ga as \u0275NG_INJ_DEF, Wa as \u0275NG_MOD_DEF, ei as \u0275NG_PIPE_DEF, Xr as \u0275NG_PROV_DEF, Vi as \u0275NOT_FOUND_CHECK_ONLY_ELEMENT_INJECTOR, P as \u0275NO_CHANGE, qn as \u0275NgModuleFactory, Sc as \u0275NoopNgZone, xO as \u0275PERFORMANCE_MARK_PREFIX, Jk as \u0275PROVIDED_NG_ZONE, CT as \u0275PROVIDED_ZONELESS, Wt as \u0275PendingTasksInternal, R as \u0275ProfilerEvent, Ja as \u0275R3Injector, zi as \u0275ReflectionCapabilities, Ot as \u0275Render3ComponentFactory, ls as \u0275Render3ComponentRef, Wn as \u0275Render3NgModuleRef, ST as \u0275ResourceImpl, _ as \u0275RuntimeError, tt as \u0275SIGNAL, Jg as \u0275SSR_CONTENT_INTEGRITY_MARKER, Zv as \u0275TESTABILITY, Kv as \u0275TESTABILITY_GETTER, Gv as \u0275TimerScheduler, Us as \u0275TracingAction, gn as \u0275TracingService, kt as \u0275ViewRef, Yr as \u0275XSS_SECURITY_URL, Mn as \u0275ZONELESS_ENABLED, Tm as \u0275_sanitizeHtml, Ls as \u0275_sanitizeUrl, rn as \u0275allLeavingAnimations, so as \u0275allowSanitizationBypassAndThrow, iP as \u0275annotateForHydration, fP as \u0275assertType, yN as \u0275bypassSanitizationTrustHtml, DN as \u0275bypassSanitizationTrustResourceUrl, EN as \u0275bypassSanitizationTrustScript, vN as \u0275bypassSanitizationTrustStyle, IN as \u0275bypassSanitizationTrustUrl, WS as \u0275clearResolutionOfComponentResourcesQueue, FD as \u0275compileComponent, wf as \u0275compileDirective, LD as \u0275compileNgModule, PD as \u0275compileNgModuleDefs, Zk as \u0275compileNgModuleFactory, WD as \u0275compilePipe, Qa as \u0275convertToBitFlags, yT as \u0275createInjector, aO as \u0275createOrReusePlatformInjector, eP as \u0275defaultIterableDiffers, tP as \u0275defaultKeyValueDiffers, $n as \u0275depsTracker, Ky as \u0275devModeEqual, dP as \u0275disableProfiling, uP as \u0275enableProfiling, bT as \u0275encapsulateResourceError, Kd as \u0275findLocaleData, OD as \u0275flushModuleScopingQueueAsMuchAsPossible, ep as \u0275formatRuntimeError, LR as \u0275generateStandaloneInDeclarationsError, kb as \u0275getAsyncClassMetadataFn, MS as \u0275getClosestComponentName, W as \u0275getComponentDef, Ui as \u0275getDeferBlocks, _M as \u0275getDirectives, Ms as \u0275getDocument, bM as \u0275getHostElement, lT as \u0275getInjectableDef, Ee as \u0275getLContext, pA as \u0275getLocaleCurrencyCode, BE as \u0275getLocalePluralCase, MT as \u0275getOutputDestroyRef, mm as \u0275getSanitizationBypassType, Lb as \u0275getTransferState, pN as \u0275getUnknownElementStrictMode, gN as \u0275getUnknownPropertyStrictMode, Ie as \u0275global, sv as \u0275inferTagNameFromDefinition, IO as \u0275injectChangeDetectorRef, rP as \u0275internalCreateApplication, Xk as \u0275internalProvideZoneChangeDetection, nE as \u0275isBoundToModule, GS as \u0275isComponentDefPendingResolution, fT as \u0275isEnvironmentProviders, uT as \u0275isInjectable, Zt as \u0275isNgModule, xd as \u0275isPromise, eE as \u0275isSubscribable, r_ as \u0275isViewDirty, i_ as \u0275markForRefresh, Je as \u0275noSideEffects, Mf as \u0275patchComponentDefWithScope, Y as \u0275performanceMarkFeature, ha as \u0275promiseWithResolvers, Ta as \u0275provideZonelessChangeDetectionInternal, Pb as \u0275publishExternalGlobalUtil, JM as \u0275readHydrationInfo, fA as \u0275registerLocaleData, rt as \u0275renderDeferBlockState, HR as \u0275resetCompiledComponents, eN as \u0275resetIncrementalHydrationEnabledWarnedForTests, OR as \u0275resetJitOptions, Ev as \u0275resolveComponentResources, qS as \u0275restoreComponentResolutionQueue, ZS as \u0275setAllowDuplicateNgModuleIdsForTest, AT as \u0275setAlternateWeakRefImpl, bD as \u0275setClassDebugInfo, Ad as \u0275setClassMetadata, Yv as \u0275setClassMetadataAsync, iT as \u0275setCurrentInjector, xM as \u0275setDocument, dT as \u0275setInjectorProfilerContext, GE as \u0275setLocaleId, fN as \u0275setUnknownElementStrictMode, hN as \u0275setUnknownPropertyStrictMode, cP as \u0275startMeasuring, lP as \u0275stopMeasuring, Ro as \u0275store, Zr as \u0275stringify, Nf as \u0275transitiveScopesFor, ga as \u0275triggerResourceLoading, cT as \u0275truncateMiddle, hA as \u0275unregisterLocaleData, dt as \u0275unwrapSafeValue, IT as \u0275unwrapWritableSignal, QL as \u0275withDomHydration, cO as \u0275withEventReplay, YL as \u0275withI18nSupport, ZL as \u0275withIncrementalHydration, kv as \u0275\u0275ControlFeature, oD as \u0275\u0275ExternalStylesFeature, mo as \u0275\u0275FactoryTarget, Ov as \u0275\u0275HostDirectivesFeature, Nd as \u0275\u0275InheritDefinitionFeature, ig as \u0275\u0275NgOnChangesFeature, nD as \u0275\u0275ProvidersFeature, Pm as \u0275\u0275advance, Go as \u0275\u0275animateEnter, Wo as \u0275\u0275animateEnterListener, qo as \u0275\u0275animateLeave, fs as \u0275\u0275animateLeaveListener, Vd as \u0275\u0275ariaProperty, XI as \u0275\u0275arrowFunction, UI as \u0275\u0275attachSourceLocations, jd as \u0275\u0275attribute, vI as \u0275\u0275classMap, df as \u0275\u0275classProp, RE as \u0275\u0275componentInstance, OE as \u0275\u0275conditional, ma as \u0275\u0275conditionalBranchCreate, kE as \u0275\u0275conditionalCreate, sf as \u0275\u0275contentQuery, cf as \u0275\u0275contentQuerySignal, tv as \u0275\u0275control, Xy as \u0275\u0275controlCreate, Tf as \u0275\u0275declareLet, cE as \u0275\u0275defer, Qv as \u0275\u0275deferEnableTimerScheduling, fE as \u0275\u0275deferHydrateNever, ME as \u0275\u0275deferHydrateOnHover, gE as \u0275\u0275deferHydrateOnIdle, vE as \u0275\u0275deferHydrateOnImmediate, _E as \u0275\u0275deferHydrateOnInteraction, DE as \u0275\u0275deferHydrateOnTimer, AE as \u0275\u0275deferHydrateOnViewport, dE as \u0275\u0275deferHydrateWhen, CE as \u0275\u0275deferOnHover, pE as \u0275\u0275deferOnIdle, mE as \u0275\u0275deferOnImmediate, NE as \u0275\u0275deferOnInteraction, EE as \u0275\u0275deferOnTimer, SE as \u0275\u0275deferOnViewport, TE as \u0275\u0275deferPrefetchOnHover, hE as \u0275\u0275deferPrefetchOnIdle, yE as \u0275\u0275deferPrefetchOnImmediate, wE as \u0275\u0275deferPrefetchOnInteraction, IE as \u0275\u0275deferPrefetchOnTimer, bE as \u0275\u0275deferPrefetchOnViewport, uE as \u0275\u0275deferPrefetchWhen, lE as \u0275\u0275deferWhen, wv as \u0275\u0275defineComponent, Sv as \u0275\u0275defineDirective, B as \u0275\u0275defineInjectable, Do as \u0275\u0275defineInjector, Md as \u0275\u0275defineNgModule, bv as \u0275\u0275definePipe, fo as \u0275\u0275directiveInject, uc as \u0275\u0275disableBindings, $d as \u0275\u0275domElement, qd as \u0275\u0275domElementContainer, Wd as \u0275\u0275domElementContainerEnd, Da as \u0275\u0275domElementContainerStart, Ea as \u0275\u0275domElementEnd, va as \u0275\u0275domElementStart, of as \u0275\u0275domListener, Yd as \u0275\u0275domProperty, _d as \u0275\u0275domTemplate, Ud as \u0275\u0275element, Gd as \u0275\u0275elementContainer, Vr as \u0275\u0275elementContainerEnd, Ia as \u0275\u0275elementContainerStart, ya as \u0275\u0275elementEnd, pr as \u0275\u0275elementStart, lc as \u0275\u0275enableBindings, SD as \u0275\u0275getComponentDepsFactory, jE as \u0275\u0275getCurrentView, Dg as \u0275\u0275getInheritedFactory, AD as \u0275\u0275getReplaceMetadataURL, nI as \u0275\u0275i18n, rI as \u0275\u0275i18nApply, oI as \u0275\u0275i18nAttributes, Xd as \u0275\u0275i18nEnd, ef as \u0275\u0275i18nExp, iI as \u0275\u0275i18nPostprocess, Jd as \u0275\u0275i18nStart, Pe as \u0275\u0275inject, Is as \u0275\u0275injectAttribute, $I as \u0275\u0275interpolate, zI as \u0275\u0275interpolate1, GI as \u0275\u0275interpolate2, WI as \u0275\u0275interpolate3, qI as \u0275\u0275interpolate4, QI as \u0275\u0275interpolate5, YI as \u0275\u0275interpolate6, ZI as \u0275\u0275interpolate7, KI as \u0275\u0275interpolate8, JI as \u0275\u0275interpolateV, Wy as \u0275\u0275invalidFactory, ni as \u0275\u0275invalidFactoryDep, tf as \u0275\u0275listener, uI as \u0275\u0275loadQuery, wc as \u0275\u0275namespaceHTML, Nc as \u0275\u0275namespaceMathML, Mc as \u0275\u0275namespaceSVG, sI as \u0275\u0275nextContext, hP as \u0275\u0275ngDeclareClassMetadata, gP as \u0275\u0275ngDeclareClassMetadataAsync, mP as \u0275\u0275ngDeclareComponent, pP as \u0275\u0275ngDeclareDirective, yP as \u0275\u0275ngDeclareFactory, vP as \u0275\u0275ngDeclareInjectable, EP as \u0275\u0275ngDeclareInjector, IP as \u0275\u0275ngDeclareNgModule, DP as \u0275\u0275ngDeclarePipe, DD as \u0275\u0275pipe, CD as \u0275\u0275pipeBind1, TD as \u0275\u0275pipeBind2, MD as \u0275\u0275pipeBind3, ND as \u0275\u0275pipeBind4, wD as \u0275\u0275pipeBindV, cI as \u0275\u0275projection, aI as \u0275\u0275projectionDef, Bd as \u0275\u0275property, sD as \u0275\u0275pureFunction0, aD as \u0275\u0275pureFunction1, cD as \u0275\u0275pureFunction2, lD as \u0275\u0275pureFunction3, uD as \u0275\u0275pureFunction4, dD as \u0275\u0275pureFunction5, fD as \u0275\u0275pureFunction6, pD as \u0275\u0275pureFunction7, hD as \u0275\u0275pureFunction8, gD as \u0275\u0275pureFunctionV, dI as \u0275\u0275queryAdvance, lI as \u0275\u0275queryRefresh, BI as \u0275\u0275readContextLet, fI as \u0275\u0275reference, Dd as \u0275\u0275registerNgModuleType, FE as \u0275\u0275repeater, PE as \u0275\u0275repeaterCreate, LE as \u0275\u0275repeaterTrackByIdentity, xE as \u0275\u0275repeaterTrackByIndex, RD as \u0275\u0275replaceMetadata, pc as \u0275\u0275resetView, Fu as \u0275\u0275resolveBody, km as \u0275\u0275resolveDocument, Rm as \u0275\u0275resolveWindow, fc as \u0275\u0275restoreView, ku as \u0275\u0275sanitizeHtml, Fs as \u0275\u0275sanitizeResourceUrl, Lu as \u0275\u0275sanitizeScript, Ou as \u0275\u0275sanitizeStyle, xu as \u0275\u0275sanitizeUrl, Am as \u0275\u0275sanitizeUrlOrResourceUrl, rD as \u0275\u0275setComponentScope, iD as \u0275\u0275setNgModuleScope, jI as \u0275\u0275storeLet, yI as \u0275\u0275styleMap, uf as \u0275\u0275styleProp, nf as \u0275\u0275syntheticHostListener, Zd as \u0275\u0275syntheticHostProperty, wd as \u0275\u0275template, _D as \u0275\u0275templateRefExtractor, wI as \u0275\u0275text, ff as \u0275\u0275textInterpolate, Ca as \u0275\u0275textInterpolate1, pf as \u0275\u0275textInterpolate2, hf as \u0275\u0275textInterpolate3, gf as \u0275\u0275textInterpolate4, mf as \u0275\u0275textInterpolate5, yf as \u0275\u0275textInterpolate6, vf as \u0275\u0275textInterpolate7, Ef as \u0275\u0275textInterpolate8, If as \u0275\u0275textInterpolateV, Sm as \u0275\u0275trustConstantHtml, bm as \u0275\u0275trustConstantResourceUrl, HI as \u0275\u0275twoWayBindingSet, Cf as \u0275\u0275twoWayListener, Df as \u0275\u0275twoWayProperty, Pu as \u0275\u0275validateAttribute, af as \u0275\u0275viewQuery, lf as \u0275\u0275viewQuerySignal };
/*! Bundled license information:

@angular/core/fesm2022/_attribute-chunk.mjs:
@angular/core/fesm2022/_debug_node-chunk.mjs:
@angular/core/fesm2022/primitives-event-dispatch.mjs:
@angular/core/fesm2022/core.mjs:
  (**
   * @license Angular v21.2.16
   * (c) 2010-2026 Google LLC. https://angular.dev/
   * License: MIT
   *)
*/
