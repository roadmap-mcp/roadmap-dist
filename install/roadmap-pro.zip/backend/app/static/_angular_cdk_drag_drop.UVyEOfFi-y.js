import "@nf-internal/chunk-4CLCTAJ7";
import * as h from "@angular/core";
import { inject as d, NgZone as K, DOCUMENT as _e, RendererFactory2 as Ye, signal as Xe, Renderer2 as Wt, Injector as ge, InjectionToken as P, ElementRef as fe, booleanAttribute as y, ViewContainerRef as Gt, ChangeDetectorRef as Qe, EventEmitter as b, afterNextRender as Ut, numberAttribute as Zt, TemplateRef as Je } from "@angular/core";
import { Subject as _, Observable as et, merge as me, Subscription as L, interval as $t, animationFrameScheduler as Kt, BehaviorSubject as qt } from "rxjs";
import * as ye from "@angular/core";
import { inject as Re, Injector as gt, EnvironmentInjector as ft, ApplicationRef as mt, createComponent as vt } from "@angular/core";
var z = new WeakMap, Ce = (() => { class r {
    _appRef;
    _injector = Re(gt);
    _environmentInjector = Re(ft);
    load(e) { let i = this._appRef = this._appRef || this._injector.get(mt), n = z.get(i); n || (n = { loaders: new Set, refs: [] }, z.set(i, n), i.onDestroy(() => { z.get(i)?.refs.forEach(s => s.destroy()), z.delete(i); })), n.loaders.has(e) || (n.loaders.add(e), n.refs.push(vt(e, { environmentInjector: this._environmentInjector }))); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = ye.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
import { takeUntil as G, map as Yt, take as Xt, tap as Qt, switchMap as Jt, startWith as tt } from "rxjs/operators";
var Q;
function Dt() { if (Q == null) {
    let r = typeof document < "u" ? document.head : null;
    Q = !!(r && (r.createShadowRoot || r.attachShadow));
} return Q; }
function V(r) { if (Dt()) {
    let t = r.getRootNode ? r.getRootNode() : null;
    if (typeof ShadowRoot < "u" && ShadowRoot && t instanceof ShadowRoot)
        return t;
} return null; }
function I(r) { return r.composedPath ? r.composedPath()[0] : r.target; }
function Pe(r) { return r.buttons === 0 || r.detail === 0; }
function Ee(r) { let t = r.touches && r.touches[0] || r.changedTouches && r.changedTouches[0]; return !!t && t.identifier === -1 && (t.radiusX == null || t.radiusX === 1) && (t.radiusY == null || t.radiusY === 1); }
import { ElementRef as wt } from "@angular/core";
function B(r, t = 0) { return St(r) ? Number(r) : arguments.length === 2 ? t : 0; }
function St(r) { return !isNaN(parseFloat(r)) && !isNaN(Number(r)); }
function w(r) { return r instanceof wt ? r.nativeElement : r; }
import * as p from "@angular/core";
import { InjectionToken as Ii, forwardRef as Ti, inject as v, NgZone as te, RendererFactory2 as Oe, ElementRef as Ot, Renderer2 as Lt, DOCUMENT as Nt, ChangeDetectorRef as Ni, signal as Mi, Injector as Ai, effect as Fi, ApplicationRef as zi, DestroyRef as Vi, untracked as Bi, afterNextRender as Hi, booleanAttribute as ji, ViewContainerRef as Ki, TemplateRef as qi, IterableDiffers as Yi } from "@angular/core";
import { Subject as j, of as Mt, Observable as At, Subscription as Ji, animationFrameScheduler as en, asapScheduler as tn, isObservable as nn } from "rxjs";
import { distinctUntilChanged as sn, auditTime as Le, filter as Ft, startWith as on, takeUntil as an, pairwise as ln, switchMap as cn, shareReplay as dn } from "rxjs/operators";
import * as xe from "@angular/core";
import { inject as bt, PLATFORM_ID as Rt } from "@angular/core";
import { isPlatformBrowser as yt } from "@angular/common";
var J;
try {
    J = typeof Intl < "u" && Intl.v8BreakIterator;
}
catch {
    J = !1;
}
var ee = (() => { class r {
    _platformId = bt(Rt);
    isBrowser = this._platformId ? yt(this._platformId) : typeof document == "object" && !!document;
    EDGE = this.isBrowser && /(edge)/i.test(navigator.userAgent);
    TRIDENT = this.isBrowser && /(msie|trident)/i.test(navigator.userAgent);
    BLINK = this.isBrowser && !!(window.chrome || J) && typeof CSS < "u" && !this.EDGE && !this.TRIDENT;
    WEBKIT = this.isBrowser && /AppleWebKit/i.test(navigator.userAgent) && !this.BLINK && !this.EDGE && !this.TRIDENT;
    IOS = this.isBrowser && /iPad|iPhone|iPod/.test(navigator.userAgent) && !("MSStream" in window);
    FIREFOX = this.isBrowser && /(firefox|minefield)/i.test(navigator.userAgent);
    ANDROID = this.isBrowser && /android/i.test(navigator.userAgent) && !this.TRIDENT;
    SAFARI = this.isBrowser && /safari/i.test(navigator.userAgent) && this.WEBKIT;
    constructor() { }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = xe.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
import * as Ie from "@angular/core";
import { InjectionToken as Ct, inject as Te, DOCUMENT as Pt, signal as Et, EventEmitter as xt } from "@angular/core";
var It = new Ct("cdk-dir-doc", { providedIn: "root", factory: () => Te(Pt) }), Tt = /^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i;
function kt(r) { let t = r?.toLowerCase() || ""; return t === "auto" && typeof navigator < "u" && navigator?.language ? Tt.test(navigator.language) ? "rtl" : "ltr" : t === "rtl" ? "rtl" : "ltr"; }
var T = (() => { class r {
    get value() { return this.valueSignal(); }
    valueSignal = Et("ltr");
    change = new xt;
    constructor() { let e = Te(It, { optional: !0 }); if (e) {
        let i = e.body ? e.body.dir : null, n = e.documentElement ? e.documentElement.dir : null;
        this.valueSignal.set(kt(i || n || "ltr"));
    } }
    ngOnDestroy() { this.change.complete(); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = Ie.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
var S = (function (r) { return r[r.NORMAL = 0] = "NORMAL", r[r.NEGATED = 1] = "NEGATED", r[r.INVERTED = 2] = "INVERTED", r; })(S || {}), H, C;
function ke() { if (C == null) {
    if (typeof document != "object" || !document || typeof Element != "function" || !Element)
        return C = !1, C;
    if (document.documentElement?.style && "scrollBehavior" in document.documentElement.style)
        C = !0;
    else {
        let r = Element.prototype.scrollTo;
        r ? C = !/\{\s*\[native code\]\s*\}/.test(r.toString()) : C = !1;
    }
} return C; }
function E() { if (typeof document != "object" || !document)
    return S.NORMAL; if (H == null) {
    let r = document.createElement("div"), t = r.style;
    r.dir = "rtl", t.width = "1px", t.overflow = "auto", t.visibility = "hidden", t.pointerEvents = "none", t.position = "absolute";
    let e = document.createElement("div"), i = e.style;
    i.width = "2px", i.height = "1px", r.appendChild(e), document.body.appendChild(r), H = S.NORMAL, r.scrollLeft === 0 && (r.scrollLeft = 1, H = r.scrollLeft === 0 ? S.NEGATED : S.INVERTED), r.remove();
} return H; }
import "@angular/common";
var zt = 20, ie = (() => { class r {
    _ngZone = v(te);
    _platform = v(ee);
    _renderer = v(Oe).createRenderer(null, null);
    _cleanupGlobalListener;
    constructor() { }
    _scrolled = new j;
    _scrolledCount = 0;
    scrollContainers = new Map;
    register(e) { this.scrollContainers.has(e) || this.scrollContainers.set(e, e.elementScrolled().subscribe(() => this._scrolled.next(e))); }
    deregister(e) { let i = this.scrollContainers.get(e); i && (i.unsubscribe(), this.scrollContainers.delete(e)); }
    scrolled(e = zt) { return this._platform.isBrowser ? new At(i => { this._cleanupGlobalListener || (this._cleanupGlobalListener = this._ngZone.runOutsideAngular(() => this._renderer.listen("document", "scroll", () => this._scrolled.next()))); let n = e > 0 ? this._scrolled.pipe(Le(e)).subscribe(i) : this._scrolled.subscribe(i); return this._scrolledCount++, () => { n.unsubscribe(), this._scrolledCount--, this._scrolledCount || (this._cleanupGlobalListener?.(), this._cleanupGlobalListener = void 0); }; }) : Mt(); }
    ngOnDestroy() { this._cleanupGlobalListener?.(), this._cleanupGlobalListener = void 0, this.scrollContainers.forEach((e, i) => this.deregister(i)), this._scrolled.complete(); }
    ancestorScrolled(e, i) { let n = this.getAncestorScrollContainers(e); return this.scrolled(i).pipe(Ft(s => !s || n.indexOf(s) > -1)); }
    getAncestorScrollContainers(e) { let i = []; return this.scrollContainers.forEach((n, s) => { this._scrollableContainsElement(s, e) && i.push(s); }), i; }
    _scrollableContainsElement(e, i) { let n = w(i), s = e.getElementRef().nativeElement; do
        if (n == s)
            return !0;
    while (n = n.parentElement); return !1; }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })(), Vt = (() => { class r {
    elementRef = v(Ot);
    scrollDispatcher = v(ie);
    ngZone = v(te);
    dir = v(T, { optional: !0 });
    _scrollElement = this.elementRef.nativeElement;
    _destroyed = new j;
    _renderer = v(Lt);
    _cleanupScroll;
    _elementScrolled = new j;
    constructor() { }
    ngOnInit() { this._cleanupScroll = this.ngZone.runOutsideAngular(() => this._renderer.listen(this._scrollElement, "scroll", e => this._elementScrolled.next(e))), this.scrollDispatcher.register(this); }
    ngOnDestroy() { this._cleanupScroll?.(), this._elementScrolled.complete(), this.scrollDispatcher.deregister(this), this._destroyed.next(), this._destroyed.complete(); }
    elementScrolled() { return this._elementScrolled; }
    getElementRef() { return this.elementRef; }
    scrollTo(e) { let i = this.elementRef.nativeElement, n = this.dir && this.dir.value == "rtl"; e.left == null && (e.left = n ? e.end : e.start), e.right == null && (e.right = n ? e.start : e.end), e.bottom != null && (e.top = i.scrollHeight - i.clientHeight - e.bottom), n && E() != S.NORMAL ? (e.left != null && (e.right = i.scrollWidth - i.clientWidth - e.left), E() == S.INVERTED ? e.left = e.right : E() == S.NEGATED && (e.left = e.right ? -e.right : e.right)) : e.right != null && (e.left = i.scrollWidth - i.clientWidth - e.right), this._applyScrollToOptions(e); }
    _applyScrollToOptions(e) { let i = this.elementRef.nativeElement; ke() ? i.scrollTo(e) : (e.top != null && (i.scrollTop = e.top), e.left != null && (i.scrollLeft = e.left)); }
    measureScrollOffset(e) { let i = "left", n = "right", s = this.elementRef.nativeElement; if (e == "top")
        return s.scrollTop; if (e == "bottom")
        return s.scrollHeight - s.clientHeight - s.scrollTop; let o = this.dir && this.dir.value == "rtl"; return e == "start" ? e = o ? n : i : e == "end" && (e = o ? i : n), o && E() == S.INVERTED ? e == i ? s.scrollWidth - s.clientWidth - s.scrollLeft : s.scrollLeft : o && E() == S.NEGATED ? e == i ? s.scrollLeft + s.scrollWidth - s.clientWidth : -s.scrollLeft : e == i ? s.scrollLeft : s.scrollWidth - s.clientWidth - s.scrollLeft; }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = p.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdk-scrollable", ""], ["", "cdkScrollable", ""]] });
} return r; })(), Bt = 20, ne = (() => { class r {
    _platform = v(ee);
    _listeners;
    _viewportSize = null;
    _change = new j;
    _document = v(Nt);
    constructor() { let e = v(te), i = v(Oe).createRenderer(null, null); e.runOutsideAngular(() => { if (this._platform.isBrowser) {
        let n = s => this._change.next(s);
        this._listeners = [i.listen("window", "resize", n), i.listen("window", "orientationchange", n)];
    } this.change().subscribe(() => this._viewportSize = null); }); }
    ngOnDestroy() { this._listeners?.forEach(e => e()), this._change.complete(); }
    getViewportSize() { this._viewportSize || this._updateViewportSize(); let e = { width: this._viewportSize.width, height: this._viewportSize.height }; return this._platform.isBrowser || (this._viewportSize = null), e; }
    getViewportRect() { let e = this.getViewportScrollPosition(), { width: i, height: n } = this.getViewportSize(); return { top: e.top, left: e.left, bottom: e.top + n, right: e.left + i, height: n, width: i }; }
    getViewportScrollPosition() { if (!this._platform.isBrowser)
        return { top: 0, left: 0 }; let e = this._document, i = this._getWindow(), n = e.documentElement, s = n.getBoundingClientRect(), o = -s.top || e.body?.scrollTop || i.scrollY || n.scrollTop || 0, a = -s.left || e.body?.scrollLeft || i.scrollX || n.scrollLeft || 0; return { top: o, left: a }; }
    change(e = Bt) { return e > 0 ? this._change.pipe(Le(e)) : this._change; }
    _getWindow() { return this._document.defaultView || window; }
    _updateViewportSize() { let e = this._getWindow(); this._viewportSize = this._platform.isBrowser ? { width: e.innerWidth, height: e.innerHeight } : { width: 0, height: 0 }; }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = p.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
var Ne = (() => { class r {
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275mod = p.\u0275\u0275defineNgModule({ type: r });
    static \u0275inj = p.\u0275\u0275defineInjector({});
} return r; })();
import * as Me from "@angular/core";
import { inject as Ht, APP_ID as jt } from "@angular/core";
var re = {}, W = class r {
    _appId = Ht(jt);
    static _infix = `a${Math.floor(Math.random() * 1e5).toString()}`;
    getId(t, e = !1) { return this._appId !== "ng" && (t += this._appId), re.hasOwnProperty(t) || (re[t] = 0), `${t}${e ? r._infix + "-" : ""}${re[t]++}`; }
    static \u0275fac = function (e) { return new (e || r); };
    static \u0275prov = Me.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
};
function Ae(r) { return Array.isArray(r) ? r : [r]; }
import "@angular/common";
function ae(r) { let t = r.cloneNode(!0), e = t.querySelectorAll("[id]"), i = r.nodeName.toLowerCase(); t.removeAttribute("id"); for (let n = 0; n < e.length; n++)
    e[n].removeAttribute("id"); return i === "canvas" ? Ve(r, t) : (i === "input" || i === "select" || i === "textarea") && ze(r, t), Fe("canvas", r, t, Ve), Fe("input, textarea, select", r, t, ze), t; }
function Fe(r, t, e, i) { let n = t.querySelectorAll(r); if (n.length) {
    let s = e.querySelectorAll(r);
    for (let o = 0; o < n.length; o++)
        i(n[o], s[o]);
} }
var ei = 0;
function ze(r, t) { t.type !== "file" && (t.value = r.value), t.type === "radio" && t.name && (t.name = `mat-clone-${t.name}-${ei++}`); }
function Ve(r, t) { let e = t.getContext("2d"); if (e)
    try {
        e.drawImage(r, 0, 0);
    }
    catch { } }
function ve(r) { let t = r.getBoundingClientRect(); return { top: t.top, right: t.right, bottom: t.bottom, left: t.left, width: t.width, height: t.height, x: t.x, y: t.y }; }
function le(r, t, e) { let { top: i, bottom: n, left: s, right: o } = r; return e >= i && e <= n && t >= s && t <= o; }
function ti(r, t) { let e = t.left < r.left, i = t.left + t.width > r.right, n = t.top < r.top, s = t.top + t.height > r.bottom; return e || i || n || s; }
function N(r, t, e) { r.top += t, r.bottom = r.top + r.height, r.left += e, r.right = r.left + r.width; }
function Be(r, t, e, i) { let { top: n, right: s, bottom: o, left: a, width: l, height: c } = r, u = l * t, f = c * t; return i > n - f && i < o + f && e > a - u && e < s + u; }
var U = class {
    _document;
    positions = new Map;
    constructor(t) { this._document = t; }
    clear() { this.positions.clear(); }
    cache(t) { this.clear(), this.positions.set(this._document, { scrollPosition: this.getViewportScrollPosition() }), t.forEach(e => { this.positions.set(e, { scrollPosition: { top: e.scrollTop, left: e.scrollLeft }, clientRect: ve(e) }); }); }
    handleScroll(t) { let e = I(t), i = this.positions.get(e); if (!i)
        return null; let n = i.scrollPosition, s, o; if (e === this._document) {
        let c = this.getViewportScrollPosition();
        s = c.top, o = c.left;
    }
    else
        s = e.scrollTop, o = e.scrollLeft; let a = n.top - s, l = n.left - o; return this.positions.forEach((c, u) => { c.clientRect && e !== u && e.contains(u) && N(c.clientRect, a, l); }), n.top = s, n.left = o, { top: a, left: l }; }
    getViewportScrollPosition() { return { top: window.scrollY, left: window.scrollX }; }
};
function it(r, t) { let e = r.rootNodes; if (e.length === 1 && e[0].nodeType === t.ELEMENT_NODE)
    return e[0]; let i = t.createElement("div"); return e.forEach(n => i.appendChild(n)), i; }
function De(r, t, e) { for (let i in t)
    if (t.hasOwnProperty(i)) {
        let n = t[i];
        n ? r.setProperty(i, n, e?.has(i) ? "important" : "") : r.removeProperty(i);
    } return r; }
function x(r, t) { let e = t ? "" : "none"; De(r.style, { "touch-action": t ? "" : "none", "-webkit-user-drag": t ? "" : "none", "-webkit-tap-highlight-color": t ? "" : "transparent", "user-select": e, "-ms-user-select": e, "-webkit-user-select": e, "-moz-user-select": e }); }
function He(r, t, e) { De(r.style, { position: t ? "" : "fixed", top: t ? "" : "0", opacity: t ? "" : "0", left: t ? "" : "-999em" }, e); }
function Z(r, t) { return t && t != "none" ? r + " " + t : r; }
function je(r, t) { r.style.width = `${t.width}px`, r.style.height = `${t.height}px`, r.style.transform = M(t.left, t.top); }
function M(r, t) { return `translate3d(${Math.round(r)}px, ${Math.round(t)}px, 0)`; }
var k = { capture: !0 }, se = { passive: !1, capture: !0 }, ii = (() => {
    class r {
        static \u0275fac = function (i) { return new (i || r); };
        static \u0275cmp = h.\u0275\u0275defineComponent({ type: r, selectors: [["ng-component"]], hostAttrs: ["cdk-drag-resets-container", ""], decls: 0, vars: 0, template: function (i, n) { }, styles: [`@layer cdk-resets {
  .cdk-drag-preview {
    background: none;
    border: none;
    padding: 0;
    color: inherit;
    inset: auto;
  }
}
.cdk-drag-placeholder *,
.cdk-drag-preview * {
  pointer-events: none !important;
}
`], encapsulation: 2, changeDetection: 0 });
    }
    return r;
})(), q = (() => { class r {
    _ngZone = d(K);
    _document = d(_e);
    _styleLoader = d(Ce);
    _renderer = d(Ye).createRenderer(null, null);
    _cleanupDocumentTouchmove;
    _scroll = new _;
    _dropInstances = new Set;
    _dragInstances = new Set;
    _activeDragInstances = Xe([]);
    _globalListeners;
    _draggingPredicate = e => e.isDragging();
    _domNodesToDirectives = null;
    pointerMove = new _;
    pointerUp = new _;
    constructor() { }
    registerDropContainer(e) { this._dropInstances.has(e) || this._dropInstances.add(e); }
    registerDragItem(e) { this._dragInstances.add(e), this._dragInstances.size === 1 && this._ngZone.runOutsideAngular(() => { this._cleanupDocumentTouchmove?.(), this._cleanupDocumentTouchmove = this._renderer.listen(this._document, "touchmove", this._persistentTouchmoveListener, se); }); }
    removeDropContainer(e) { this._dropInstances.delete(e); }
    removeDragItem(e) { this._dragInstances.delete(e), this.stopDragging(e), this._dragInstances.size === 0 && this._cleanupDocumentTouchmove?.(); }
    startDragging(e, i) { if (!(this._activeDragInstances().indexOf(e) > -1) && (this._styleLoader.load(ii), this._activeDragInstances.update(n => [...n, e]), this._activeDragInstances().length === 1)) {
        let n = i.type.startsWith("touch"), s = a => this.pointerUp.next(a), o = [["scroll", a => this._scroll.next(a), k], ["selectstart", this._preventDefaultWhileDragging, se]];
        n ? o.push(["touchend", s, k], ["touchcancel", s, k]) : o.push(["mouseup", s, k]), n || o.push(["mousemove", a => this.pointerMove.next(a), se]), this._ngZone.runOutsideAngular(() => { this._globalListeners = o.map(([a, l, c]) => this._renderer.listen(this._document, a, l, c)); });
    } }
    stopDragging(e) { this._activeDragInstances.update(i => { let n = i.indexOf(e); return n > -1 ? (i.splice(n, 1), [...i]) : i; }), this._activeDragInstances().length === 0 && this._clearGlobalListeners(); }
    isDragging(e) { return this._activeDragInstances().indexOf(e) > -1; }
    scrolled(e) { let i = [this._scroll]; return e && e !== this._document && i.push(new et(n => this._ngZone.runOutsideAngular(() => { let s = this._renderer.listen(e, "scroll", o => { this._activeDragInstances().length && n.next(o); }, k); return () => { s(); }; }))), me(...i); }
    registerDirectiveNode(e, i) { this._domNodesToDirectives ??= new WeakMap, this._domNodesToDirectives.set(e, i); }
    removeDirectiveNode(e) { this._domNodesToDirectives?.delete(e); }
    getDragDirectiveForNode(e) { return this._domNodesToDirectives?.get(e) || null; }
    ngOnDestroy() { this._dragInstances.forEach(e => this.removeDragItem(e)), this._dropInstances.forEach(e => this.removeDropContainer(e)), this._domNodesToDirectives = null, this._clearGlobalListeners(), this.pointerMove.complete(), this.pointerUp.complete(); }
    _preventDefaultWhileDragging = e => { this._activeDragInstances().length > 0 && e.preventDefault(); };
    _persistentTouchmoveListener = e => { this._activeDragInstances().length > 0 && (this._activeDragInstances().some(this._draggingPredicate) && e.preventDefault(), this.pointerMove.next(e)); };
    _clearGlobalListeners() { this._globalListeners?.forEach(e => e()), this._globalListeners = void 0; }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = h.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })();
function We(r) { let t = r.toLowerCase().indexOf("ms") > -1 ? 1 : 1e3; return parseFloat(r) * t; }
function ni(r) { let t = getComputedStyle(r), e = oe(t, "transition-property"), i = e.find(a => a === "transform" || a === "all"); if (!i)
    return 0; let n = e.indexOf(i), s = oe(t, "transition-duration"), o = oe(t, "transition-delay"); return We(s[n]) + We(o[n]); }
function oe(r, t) { return r.getPropertyValue(t).split(",").map(i => i.trim()); }
var ri = new Set(["position"]), ce = class {
    _document;
    _rootElement;
    _direction;
    _initialDomRect;
    _previewTemplate;
    _previewClass;
    _pickupPositionOnPage;
    _initialTransform;
    _zIndex;
    _renderer;
    _previewEmbeddedView = null;
    _preview;
    get element() { return this._preview; }
    constructor(t, e, i, n, s, o, a, l, c, u) { this._document = t, this._rootElement = e, this._direction = i, this._initialDomRect = n, this._previewTemplate = s, this._previewClass = o, this._pickupPositionOnPage = a, this._initialTransform = l, this._zIndex = c, this._renderer = u; }
    attach(t) { this._preview = this._createPreview(), t.appendChild(this._preview), Ge(this._preview) && this._preview.showPopover(); }
    destroy() { this._preview.remove(), this._previewEmbeddedView?.destroy(), this._preview = this._previewEmbeddedView = null; }
    setTransform(t) { this._preview.style.transform = t; }
    getBoundingClientRect() { return this._preview.getBoundingClientRect(); }
    addClass(t) { this._preview.classList.add(t); }
    getTransitionDuration() { return ni(this._preview); }
    addEventListener(t, e) { return this._renderer.listen(this._preview, t, e); }
    _createPreview() { let t = this._previewTemplate, e = this._previewClass, i = t ? t.template : null, n; if (i && t) {
        let s = t.matchSize ? this._initialDomRect : null, o = t.viewContainer.createEmbeddedView(i, t.context);
        o.detectChanges(), n = it(o, this._document), this._previewEmbeddedView = o, t.matchSize ? je(n, s) : n.style.transform = M(this._pickupPositionOnPage.x, this._pickupPositionOnPage.y);
    }
    else
        n = ae(this._rootElement), je(n, this._initialDomRect), this._initialTransform && (n.style.transform = this._initialTransform); return De(n.style, { "pointer-events": "none", margin: Ge(n) ? "0 auto 0 0" : "0", position: "fixed", top: "0", left: "0", "z-index": this._zIndex + "" }, ri), x(n, !1), n.classList.add("cdk-drag-preview"), n.setAttribute("popover", "manual"), n.setAttribute("dir", this._direction), e && (Array.isArray(e) ? e.forEach(s => n.classList.add(s)) : n.classList.add(e)), n; }
};
function Ge(r) { return "showPopover" in r; }
var si = { passive: !0 }, Ue = { passive: !1 }, oi = { passive: !1, capture: !0 }, ai = 800, Ze = "cdk-drag-placeholder", $e = new Set(["position"]);
function nt(r, t, e = { dragStartThreshold: 5, pointerDirectionChangeThreshold: 5 }) { let i = r.get(Wt, null, { optional: !0 }) || r.get(Ye).createRenderer(null, null); return new de(t, e, r.get(_e), r.get(K), r.get(ne), r.get(q), i); }
var de = class {
    _config;
    _document;
    _ngZone;
    _viewportRuler;
    _dragDropRegistry;
    _renderer;
    _rootElementCleanups;
    _cleanupShadowRootSelectStart;
    _preview = null;
    _previewContainer;
    _placeholderRef = null;
    _placeholder;
    _pickupPositionInElement;
    _pickupPositionOnPage;
    _marker;
    _anchor = null;
    _passiveTransform = { x: 0, y: 0 };
    _activeTransform = { x: 0, y: 0 };
    _initialTransform;
    _hasStartedDragging = Xe(!1);
    _hasMoved = !1;
    _initialContainer;
    _initialIndex;
    _parentPositions;
    _moveEvents = new _;
    _pointerDirectionDelta;
    _pointerPositionAtLastDirectionChange;
    _lastKnownPointerPosition;
    _rootElement;
    _ownerSVGElement = null;
    _rootElementTapHighlight;
    _pointerMoveSubscription = L.EMPTY;
    _pointerUpSubscription = L.EMPTY;
    _scrollSubscription = L.EMPTY;
    _resizeSubscription = L.EMPTY;
    _lastTouchEventTime;
    _dragStartTime;
    _boundaryElement = null;
    _nativeInteractionsEnabled = !0;
    _initialDomRect;
    _previewRect;
    _boundaryRect;
    _previewTemplate;
    _placeholderTemplate;
    _handles = [];
    _disabledHandles = new Set;
    _dropContainer;
    _direction = "ltr";
    _parentDragRef = null;
    _cachedShadowRoot;
    lockAxis = null;
    dragStartDelay = 0;
    previewClass;
    scale = 1;
    get disabled() { return this._disabled || !!(this._dropContainer && this._dropContainer.disabled); }
    set disabled(t) { t !== this._disabled && (this._disabled = t, this._toggleNativeDragInteractions(), this._handles.forEach(e => x(e, t))); }
    _disabled = !1;
    beforeStarted = new _;
    started = new _;
    released = new _;
    ended = new _;
    entered = new _;
    exited = new _;
    dropped = new _;
    moved = this._moveEvents;
    data;
    constrainPosition;
    constructor(t, e, i, n, s, o, a) { this._config = e, this._document = i, this._ngZone = n, this._viewportRuler = s, this._dragDropRegistry = o, this._renderer = a, this.withRootElement(t).withParent(e.parentDragRef || null), this._parentPositions = new U(i), o.registerDragItem(this); }
    getPlaceholderElement() { return this._placeholder; }
    getRootElement() { return this._rootElement; }
    getVisibleElement() { return this.isDragging() ? this.getPlaceholderElement() : this.getRootElement(); }
    withHandles(t) { this._handles = t.map(i => w(i)), this._handles.forEach(i => x(i, this.disabled)), this._toggleNativeDragInteractions(); let e = new Set; return this._disabledHandles.forEach(i => { this._handles.indexOf(i) > -1 && e.add(i); }), this._disabledHandles = e, this; }
    withPreviewTemplate(t) { return this._previewTemplate = t, this; }
    withPlaceholderTemplate(t) { return this._placeholderTemplate = t, this; }
    withRootElement(t) { let e = w(t); if (e !== this._rootElement) {
        this._removeRootElementListeners();
        let i = this._renderer;
        this._rootElementCleanups = this._ngZone.runOutsideAngular(() => [i.listen(e, "mousedown", this._pointerDown, Ue), i.listen(e, "touchstart", this._pointerDown, si), i.listen(e, "dragstart", this._nativeDragStart, Ue)]), this._initialTransform = void 0, this._rootElement = e;
    } return typeof SVGElement < "u" && this._rootElement instanceof SVGElement && (this._ownerSVGElement = this._rootElement.ownerSVGElement), this; }
    withBoundaryElement(t) { return this._boundaryElement = t ? w(t) : null, this._resizeSubscription.unsubscribe(), t && (this._resizeSubscription = this._viewportRuler.change(10).subscribe(() => this._containInsideBoundaryOnResize())), this; }
    withParent(t) { return this._parentDragRef = t, this; }
    dispose() { this._removeRootElementListeners(), this.isDragging() && this._rootElement?.remove(), this._marker?.remove(), this._destroyPreview(), this._destroyPlaceholder(), this._dragDropRegistry.removeDragItem(this), this._removeListeners(), this.beforeStarted.complete(), this.started.complete(), this.released.complete(), this.ended.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this._moveEvents.complete(), this._handles = [], this._disabledHandles.clear(), this._dropContainer = void 0, this._resizeSubscription.unsubscribe(), this._parentPositions.clear(), this._boundaryElement = this._rootElement = this._ownerSVGElement = this._placeholderTemplate = this._previewTemplate = this._marker = this._parentDragRef = null; }
    isDragging() { return this._hasStartedDragging() && this._dragDropRegistry.isDragging(this); }
    reset() { this._rootElement.style.transform = this._initialTransform || "", this._activeTransform = { x: 0, y: 0 }, this._passiveTransform = { x: 0, y: 0 }; }
    resetToBoundary() { if (this._boundaryElement && this._rootElement && ti(this._boundaryElement.getBoundingClientRect(), this._rootElement.getBoundingClientRect())) {
        let t = this._boundaryElement.getBoundingClientRect(), e = this._rootElement.getBoundingClientRect(), i = 0, n = 0;
        e.left < t.left ? i = t.left - e.left : e.right > t.right && (i = t.right - e.right), e.top < t.top ? n = t.top - e.top : e.bottom > t.bottom && (n = t.bottom - e.bottom);
        let s = this._activeTransform.x, o = this._activeTransform.y, a = s + i, l = o + n;
        this._rootElement.style.transform = M(a, l), this._activeTransform = { x: a, y: l }, this._passiveTransform = { x: a, y: l };
    } }
    disableHandle(t) { !this._disabledHandles.has(t) && this._handles.indexOf(t) > -1 && (this._disabledHandles.add(t), x(t, !0)); }
    enableHandle(t) { this._disabledHandles.has(t) && (this._disabledHandles.delete(t), x(t, this.disabled)); }
    withDirection(t) { return this._direction = t, this; }
    _withDropContainer(t) { this._dropContainer = t; }
    getFreeDragPosition() { let t = this.isDragging() ? this._activeTransform : this._passiveTransform; return { x: t.x, y: t.y }; }
    setFreeDragPosition(t) { return this._activeTransform = { x: 0, y: 0 }, this._passiveTransform.x = t.x, this._passiveTransform.y = t.y, this._dropContainer || this._applyRootElementTransform(t.x, t.y), this; }
    withPreviewContainer(t) { return this._previewContainer = t, this; }
    _sortFromLastPointerPosition() { let t = this._lastKnownPointerPosition; t && this._dropContainer && this._updateActiveDropContainer(this._getConstrainedPointerPosition(t), t); }
    _removeListeners() { this._pointerMoveSubscription.unsubscribe(), this._pointerUpSubscription.unsubscribe(), this._scrollSubscription.unsubscribe(), this._cleanupShadowRootSelectStart?.(), this._cleanupShadowRootSelectStart = void 0; }
    _destroyPreview() { this._preview?.destroy(), this._preview = null; }
    _destroyPlaceholder() { this._anchor?.remove(), this._placeholder?.remove(), this._placeholderRef?.destroy(), this._placeholder = this._anchor = this._placeholderRef = null; }
    _pointerDown = t => { if (this.beforeStarted.next(), this._handles.length) {
        let e = this._getTargetHandle(t);
        e && !this._disabledHandles.has(e) && !this.disabled && this._initializeDragSequence(e, t);
    }
    else
        this.disabled || this._initializeDragSequence(this._rootElement, t); };
    _pointerMove = t => { let e = this._getPointerPositionOnPage(t); if (!this._hasStartedDragging()) {
        let n = Math.abs(e.x - this._pickupPositionOnPage.x), s = Math.abs(e.y - this._pickupPositionOnPage.y);
        if (n + s >= this._config.dragStartThreshold) {
            let a = Date.now() >= this._dragStartTime + this._getDragStartDelay(t), l = this._dropContainer;
            if (!a) {
                this._endDragSequence(t);
                return;
            }
            (!l || !l.isDragging() && !l.isReceiving()) && (t.cancelable && t.preventDefault(), this._hasStartedDragging.set(!0), this._ngZone.run(() => this._startDragSequence(t)));
        }
        return;
    } t.cancelable && t.preventDefault(); let i = this._getConstrainedPointerPosition(e); if (this._hasMoved = !0, this._lastKnownPointerPosition = e, this._updatePointerDirectionDelta(i), this._dropContainer)
        this._updateActiveDropContainer(i, e);
    else {
        let n = this.constrainPosition ? this._initialDomRect : this._pickupPositionOnPage, s = this._activeTransform;
        s.x = i.x - n.x + this._passiveTransform.x, s.y = i.y - n.y + this._passiveTransform.y, this._applyRootElementTransform(s.x, s.y);
    } this._moveEvents.observers.length && this._ngZone.run(() => { this._moveEvents.next({ source: this, pointerPosition: i, event: t, distance: this._getDragDistance(i), delta: this._pointerDirectionDelta }); }); };
    _pointerUp = t => { this._endDragSequence(t); };
    _endDragSequence(t) { if (this._dragDropRegistry.isDragging(this) && (this._removeListeners(), this._dragDropRegistry.stopDragging(this), this._toggleNativeDragInteractions(), this._handles && (this._rootElement.style.webkitTapHighlightColor = this._rootElementTapHighlight), !!this._hasStartedDragging()))
        if (this.released.next({ source: this, event: t }), this._dropContainer)
            this._dropContainer._stopScrolling(), this._animatePreviewToPlaceholder().then(() => { this._cleanupDragArtifacts(t), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this); });
        else {
            this._passiveTransform.x = this._activeTransform.x;
            let e = this._getPointerPositionOnPage(t);
            this._passiveTransform.y = this._activeTransform.y, this._ngZone.run(() => { this.ended.next({ source: this, distance: this._getDragDistance(e), dropPoint: e, event: t }); }), this._cleanupCachedDimensions(), this._dragDropRegistry.stopDragging(this);
        } }
    _startDragSequence(t) { O(t) && (this._lastTouchEventTime = Date.now()), this._toggleNativeDragInteractions(); let e = this._getShadowRoot(), i = this._dropContainer; if (e && this._ngZone.runOutsideAngular(() => { this._cleanupShadowRootSelectStart = this._renderer.listen(e, "selectstart", li, oi); }), i) {
        let n = this._rootElement, s = n.parentNode, o = this._placeholder = this._createPlaceholderElement(), a = this._marker = this._marker || this._document.createComment("");
        s.insertBefore(a, n), this._initialTransform = n.style.transform || "", this._preview = new ce(this._document, this._rootElement, this._direction, this._initialDomRect, this._previewTemplate || null, this.previewClass || null, this._pickupPositionOnPage, this._initialTransform, this._config.zIndex || 1e3, this._renderer), this._preview.attach(this._getPreviewInsertionPoint(s, e)), He(n, !1, $e), this._document.body.appendChild(s.replaceChild(o, n)), this.started.next({ source: this, event: t }), i.start(), this._initialContainer = i, this._initialIndex = i.getItemIndex(this);
    }
    else
        this.started.next({ source: this, event: t }), this._initialContainer = this._initialIndex = void 0; this._parentPositions.cache(i ? i.getScrollableParents() : []); }
    _initializeDragSequence(t, e) { this._parentDragRef && e.stopPropagation(); let i = this.isDragging(), n = O(e), s = !n && e.button !== 0, o = this._rootElement, a = I(e), l = !n && this._lastTouchEventTime && this._lastTouchEventTime + ai > Date.now(), c = n ? Ee(e) : Pe(e); if (a && a.draggable && e.type === "mousedown" && e.preventDefault(), i || s || l || c)
        return; if (this._handles.length) {
        let R = o.style;
        this._rootElementTapHighlight = R.webkitTapHighlightColor || "", R.webkitTapHighlightColor = "transparent";
    } this._hasMoved = !1, this._hasStartedDragging.set(this._hasMoved), this._removeListeners(), this._initialDomRect = this._rootElement.getBoundingClientRect(), this._pointerMoveSubscription = this._dragDropRegistry.pointerMove.subscribe(this._pointerMove), this._pointerUpSubscription = this._dragDropRegistry.pointerUp.subscribe(this._pointerUp), this._scrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(R => this._updateOnScroll(R)), this._boundaryElement && (this._boundaryRect = ve(this._boundaryElement)); let u = this._previewTemplate; this._pickupPositionInElement = u && u.template && !u.matchSize ? { x: 0, y: 0 } : this._getPointerPositionInElement(this._initialDomRect, t, e); let f = this._pickupPositionOnPage = this._lastKnownPointerPosition = this._getPointerPositionOnPage(e); this._pointerDirectionDelta = { x: 0, y: 0 }, this._pointerPositionAtLastDirectionChange = { x: f.x, y: f.y }, this._dragStartTime = Date.now(), this._dragDropRegistry.startDragging(this, e); }
    _cleanupDragArtifacts(t) { He(this._rootElement, !0, $e), this._marker.parentNode.replaceChild(this._rootElement, this._marker), this._destroyPreview(), this._destroyPlaceholder(), this._initialDomRect = this._boundaryRect = this._previewRect = this._initialTransform = void 0, this._ngZone.run(() => { let e = this._dropContainer, i = e.getItemIndex(this), n = this._getPointerPositionOnPage(t), s = this._getDragDistance(n), o = e._isOverContainer(n.x, n.y); this.ended.next({ source: this, distance: s, dropPoint: n, event: t }), this.dropped.next({ item: this, currentIndex: i, previousIndex: this._initialIndex, container: e, previousContainer: this._initialContainer, isPointerOverContainer: o, distance: s, dropPoint: n, event: t }), e.drop(this, i, this._initialIndex, this._initialContainer, o, s, n, t), this._dropContainer = this._initialContainer; }); }
    _updateActiveDropContainer({ x: t, y: e }, { x: i, y: n }) { let s = this._initialContainer._getSiblingContainerFromPosition(this, t, e); !s && this._dropContainer !== this._initialContainer && this._initialContainer._isOverContainer(t, e) && (s = this._initialContainer), s && s !== this._dropContainer && this._ngZone.run(() => { let o = this._dropContainer.getItemIndex(this), a = this._dropContainer.getItemAtIndex(o + 1)?.getVisibleElement() || null; this.exited.next({ item: this, container: this._dropContainer }), this._dropContainer.exit(this), this._conditionallyInsertAnchor(s, this._dropContainer, a), this._dropContainer = s, this._dropContainer.enter(this, t, e, s === this._initialContainer && s.sortingDisabled ? this._initialIndex : void 0), this.entered.next({ item: this, container: s, currentIndex: s.getItemIndex(this) }); }), this.isDragging() && (this._dropContainer._startScrollingIfNecessary(i, n), this._dropContainer._sortItem(this, t, e, this._pointerDirectionDelta), this.constrainPosition ? this._applyPreviewTransform(t, e) : this._applyPreviewTransform(t - this._pickupPositionInElement.x, e - this._pickupPositionInElement.y)); }
    _animatePreviewToPlaceholder() { if (!this._hasMoved)
        return Promise.resolve(); let t = this._placeholder.getBoundingClientRect(); this._preview.addClass("cdk-drag-animating"), this._applyPreviewTransform(t.left, t.top); let e = this._preview.getTransitionDuration(); return e === 0 ? Promise.resolve() : this._ngZone.runOutsideAngular(() => new Promise(i => { let n = a => { (!a || this._preview && I(a) === this._preview.element && a.propertyName === "transform") && (o(), i(), clearTimeout(s)); }, s = setTimeout(n, e * 1.5), o = this._preview.addEventListener("transitionend", n); })); }
    _createPlaceholderElement() { let t = this._placeholderTemplate, e = t ? t.template : null, i; return e ? (this._placeholderRef = t.viewContainer.createEmbeddedView(e, t.context), this._placeholderRef.detectChanges(), i = it(this._placeholderRef, this._document)) : i = ae(this._rootElement), i.style.pointerEvents = "none", i.classList.add(Ze), i; }
    _getPointerPositionInElement(t, e, i) { let n = e === this._rootElement ? null : e, s = n ? n.getBoundingClientRect() : t, o = O(i) ? i.targetTouches[0] : i, a = this._getViewportScrollPosition(), l = o.pageX - s.left - a.left, c = o.pageY - s.top - a.top; return { x: s.left - t.left + l, y: s.top - t.top + c }; }
    _getPointerPositionOnPage(t) { let e = this._getViewportScrollPosition(), i = O(t) ? t.touches[0] || t.changedTouches[0] || { pageX: 0, pageY: 0 } : t, n = i.pageX - e.left, s = i.pageY - e.top; if (this._ownerSVGElement) {
        let o = this._ownerSVGElement.getScreenCTM();
        if (o) {
            let a = this._ownerSVGElement.createSVGPoint();
            return a.x = n, a.y = s, a.matrixTransform(o.inverse());
        }
    } return { x: n, y: s }; }
    _getConstrainedPointerPosition(t) { let e = this._dropContainer ? this._dropContainer.lockAxis : null, { x: i, y: n } = this.constrainPosition ? this.constrainPosition(t, this, this._initialDomRect, this._pickupPositionInElement) : t; if (this.lockAxis === "x" || e === "x" ? n = this._pickupPositionOnPage.y - (this.constrainPosition ? this._pickupPositionInElement.y : 0) : (this.lockAxis === "y" || e === "y") && (i = this._pickupPositionOnPage.x - (this.constrainPosition ? this._pickupPositionInElement.x : 0)), this._boundaryRect) {
        let { x: s, y: o } = this.constrainPosition ? { x: 0, y: 0 } : this._pickupPositionInElement, a = this._boundaryRect, { width: l, height: c } = this._getPreviewRect(), u = a.top + o, f = a.bottom - (c - o), R = a.left + s, Y = a.right - (l - s);
        i = Ke(i, R, Y), n = Ke(n, u, f);
    } return { x: i, y: n }; }
    _updatePointerDirectionDelta(t) { let { x: e, y: i } = t, n = this._pointerDirectionDelta, s = this._pointerPositionAtLastDirectionChange, o = Math.abs(e - s.x), a = Math.abs(i - s.y); return o > this._config.pointerDirectionChangeThreshold && (n.x = e > s.x ? 1 : -1, s.x = e), a > this._config.pointerDirectionChangeThreshold && (n.y = i > s.y ? 1 : -1, s.y = i), n; }
    _toggleNativeDragInteractions() { if (!this._rootElement || !this._handles)
        return; let t = this._handles.length > 0 || !this.isDragging(); t !== this._nativeInteractionsEnabled && (this._nativeInteractionsEnabled = t, x(this._rootElement, t)); }
    _removeRootElementListeners() { this._rootElementCleanups?.forEach(t => t()), this._rootElementCleanups = void 0; }
    _applyRootElementTransform(t, e) { let i = 1 / this.scale, n = M(t * i, e * i), s = this._rootElement.style; this._initialTransform == null && (this._initialTransform = s.transform && s.transform != "none" ? s.transform : ""), s.transform = Z(n, this._initialTransform); }
    _applyPreviewTransform(t, e) { let i = this._previewTemplate?.template ? void 0 : this._initialTransform, n = M(t, e); this._preview.setTransform(Z(n, i)); }
    _getDragDistance(t) { let e = this._pickupPositionOnPage; return e ? { x: t.x - e.x, y: t.y - e.y } : { x: 0, y: 0 }; }
    _cleanupCachedDimensions() { this._boundaryRect = this._previewRect = void 0, this._parentPositions.clear(); }
    _containInsideBoundaryOnResize() { let { x: t, y: e } = this._passiveTransform; if (t === 0 && e === 0 || this.isDragging() || !this._boundaryElement)
        return; let i = this._rootElement.getBoundingClientRect(), n = this._boundaryElement.getBoundingClientRect(); if (n.width === 0 && n.height === 0 || i.width === 0 && i.height === 0)
        return; let s = n.left - i.left, o = i.right - n.right, a = n.top - i.top, l = i.bottom - n.bottom; n.width > i.width ? (s > 0 && (t += s), o > 0 && (t -= o)) : t = 0, n.height > i.height ? (a > 0 && (e += a), l > 0 && (e -= l)) : e = 0, (t !== this._passiveTransform.x || e !== this._passiveTransform.y) && this.setFreeDragPosition({ y: e, x: t }); }
    _getDragStartDelay(t) { let e = this.dragStartDelay; return typeof e == "number" ? e : O(t) ? e.touch : e ? e.mouse : 0; }
    _updateOnScroll(t) { let e = this._parentPositions.handleScroll(t); if (e) {
        let i = I(t);
        this._boundaryRect && i !== this._boundaryElement && i.contains(this._boundaryElement) && N(this._boundaryRect, e.top, e.left), this._pickupPositionOnPage.x += e.left, this._pickupPositionOnPage.y += e.top, this._dropContainer || (this._activeTransform.x -= e.left, this._activeTransform.y -= e.top, this._applyRootElementTransform(this._activeTransform.x, this._activeTransform.y));
    } }
    _getViewportScrollPosition() { return this._parentPositions.positions.get(this._document)?.scrollPosition || this._parentPositions.getViewportScrollPosition(); }
    _getShadowRoot() { return this._cachedShadowRoot === void 0 && (this._cachedShadowRoot = V(this._rootElement)), this._cachedShadowRoot; }
    _getPreviewInsertionPoint(t, e) { let i = this._previewContainer || "global"; if (i === "parent")
        return t; if (i === "global") {
        let n = this._document;
        return e || n.fullscreenElement || n.webkitFullscreenElement || n.mozFullScreenElement || n.msFullscreenElement || n.body;
    } return w(i); }
    _getPreviewRect() { return (!this._previewRect || !this._previewRect.width && !this._previewRect.height) && (this._previewRect = this._preview ? this._preview.getBoundingClientRect() : this._initialDomRect), this._previewRect; }
    _nativeDragStart = t => { if (this._handles.length) {
        let e = this._getTargetHandle(t);
        e && !this._disabledHandles.has(e) && !this.disabled && t.preventDefault();
    }
    else
        this.disabled || t.preventDefault(); };
    _getTargetHandle(t) { return this._handles.find(e => t.target && (t.target === e || e.contains(t.target))); }
    _conditionallyInsertAnchor(t, e, i) { if (t === this._initialContainer)
        this._anchor?.remove(), this._anchor = null;
    else if (e === this._initialContainer && e.hasAnchor) {
        let n = this._anchor ??= ae(this._placeholder);
        n.classList.remove(Ze), n.classList.add("cdk-drag-anchor"), n.style.transform = "", i ? i.before(n) : w(e.element).appendChild(n);
    } }
};
function Ke(r, t, e) { return Math.max(t, Math.min(e, r)); }
function O(r) { return r.type[0] === "t"; }
function li(r) { r.preventDefault(); }
function rt(r, t, e) { let i = A(t, r.length - 1), n = A(e, r.length - 1); if (i === n)
    return; let s = r[i], o = n < i ? -1 : 1; for (let a = i; a !== n; a += o)
    r[a] = r[a + o]; r[n] = s; }
function Hn(r, t, e, i) { let n = A(e, r.length - 1), s = A(i, t.length); r.length && t.splice(s, 0, r.splice(n, 1)[0]); }
function jn(r, t, e, i) { let n = A(i, t.length); r.length && t.splice(n, 0, r[e]); }
function A(r, t) { return Math.max(0, Math.min(t, r)); }
var $ = class {
    _dragDropRegistry;
    _element;
    _sortPredicate;
    _itemPositions = [];
    _activeDraggables;
    orientation = "vertical";
    direction = "ltr";
    constructor(t) { this._dragDropRegistry = t; }
    _previousSwap = { drag: null, delta: 0, overlaps: !1 };
    start(t) { this.withItems(t); }
    sort(t, e, i, n) { let s = this._itemPositions, o = this._getItemIndexFromPointerPosition(t, e, i, n); if (o === -1 && s.length > 0)
        return null; let a = this.orientation === "horizontal", l = s.findIndex(m => m.drag === t), c = s[o], u = s[l].clientRect, f = c.clientRect, R = l > o ? 1 : -1, Y = this._getItemOffsetPx(u, f, R), ut = this._getSiblingOffsetPx(l, s, R), pt = s.slice(); return rt(s, l, o), s.forEach((m, _t) => { if (pt[_t] === m)
        return; let we = m.drag === t, X = we ? Y : ut, Se = we ? t.getPlaceholderElement() : m.drag.getRootElement(); m.offset += X; let be = Math.round(m.offset * (1 / m.drag.scale)); a ? (Se.style.transform = Z(`translate3d(${be}px, 0, 0)`, m.initialTransform), N(m.clientRect, 0, X)) : (Se.style.transform = Z(`translate3d(0, ${be}px, 0)`, m.initialTransform), N(m.clientRect, X, 0)); }), this._previousSwap.overlaps = le(f, e, i), this._previousSwap.drag = c.drag, this._previousSwap.delta = a ? n.x : n.y, { previousIndex: l, currentIndex: o }; }
    enter(t, e, i, n) { let s = this._activeDraggables, o = s.indexOf(t), a = t.getPlaceholderElement(); o > -1 && s.splice(o, 1); let l = n == null || n < 0 ? this._getItemIndexFromPointerPosition(t, e, i) : n, c = s[l]; if (c === t && (c = s[l + 1]), !c && (l == null || l === -1 || l < s.length - 1) && this._shouldEnterAsFirstChild(e, i) && (c = s[0]), c && !this._dragDropRegistry.isDragging(c)) {
        let u = c.getRootElement();
        u.parentElement.insertBefore(a, u), s.splice(l, 0, t);
    }
    else
        this._element.appendChild(a), s.push(t); a.style.transform = "", this._cacheItemPositions(); }
    withItems(t) { this._activeDraggables = t.slice(), this._cacheItemPositions(); }
    withSortPredicate(t) { this._sortPredicate = t; }
    reset() { this._activeDraggables?.forEach(t => { let e = t.getRootElement(); if (e) {
        let i = this._itemPositions.find(n => n.drag === t)?.initialTransform;
        e.style.transform = i || "";
    } }), this._itemPositions = [], this._activeDraggables = [], this._previousSwap.drag = null, this._previousSwap.delta = 0, this._previousSwap.overlaps = !1; }
    getActiveItemsSnapshot() { return this._activeDraggables; }
    getItemIndex(t) { return this._getVisualItemPositions().findIndex(e => e.drag === t); }
    getItemAtIndex(t) { return this._getVisualItemPositions()[t]?.drag || null; }
    updateOnScroll(t, e) { this._itemPositions.forEach(({ clientRect: i }) => { N(i, t, e); }), this._itemPositions.forEach(({ drag: i }) => { this._dragDropRegistry.isDragging(i) && i._sortFromLastPointerPosition(); }); }
    withElementContainer(t) { this._element = t; }
    _cacheItemPositions() { let t = this.orientation === "horizontal"; this._itemPositions = this._activeDraggables.map(e => { let i = e.getVisibleElement(); return { drag: e, offset: 0, initialTransform: i.style.transform || "", clientRect: ve(i) }; }).sort((e, i) => t ? e.clientRect.left - i.clientRect.left : e.clientRect.top - i.clientRect.top); }
    _getVisualItemPositions() { return this.orientation === "horizontal" && this.direction === "rtl" ? this._itemPositions.slice().reverse() : this._itemPositions; }
    _getItemOffsetPx(t, e, i) { let n = this.orientation === "horizontal", s = n ? e.left - t.left : e.top - t.top; return i === -1 && (s += n ? e.width - t.width : e.height - t.height), s; }
    _getSiblingOffsetPx(t, e, i) { let n = this.orientation === "horizontal", s = e[t].clientRect, o = e[t + i * -1], a = s[n ? "width" : "height"] * i; if (o) {
        let l = n ? "left" : "top", c = n ? "right" : "bottom";
        i === -1 ? a -= o.clientRect[l] - s[c] : a += s[l] - o.clientRect[c];
    } return a; }
    _shouldEnterAsFirstChild(t, e) { if (!this._activeDraggables.length)
        return !1; let i = this._itemPositions, n = this.orientation === "horizontal"; if (i[0].drag !== this._activeDraggables[0]) {
        let o = i[i.length - 1].clientRect;
        return n ? t >= o.right : e >= o.bottom;
    }
    else {
        let o = i[0].clientRect;
        return n ? t <= o.left : e <= o.top;
    } }
    _getItemIndexFromPointerPosition(t, e, i, n) { let s = this.orientation === "horizontal", o = this._itemPositions.findIndex(({ drag: a, clientRect: l }) => { if (a === t)
        return !1; if (n) {
        let c = s ? n.x : n.y;
        if (a === this._previousSwap.drag && this._previousSwap.overlaps && c === this._previousSwap.delta)
            return !1;
    } return s ? e >= Math.floor(l.left) && e < Math.floor(l.right) : i >= Math.floor(l.top) && i < Math.floor(l.bottom); }); return o === -1 || !this._sortPredicate(o, t) ? -1 : o; }
}, he = class {
    _document;
    _dragDropRegistry;
    _element;
    _sortPredicate;
    _rootNode;
    _activeItems;
    _previousSwap = { drag: null, deltaX: 0, deltaY: 0, overlaps: !1 };
    _relatedNodes = [];
    constructor(t, e) { this._document = t, this._dragDropRegistry = e; }
    start(t) { let e = this._element.childNodes; this._relatedNodes = []; for (let i = 0; i < e.length; i++) {
        let n = e[i];
        this._relatedNodes.push([n, n.nextSibling]);
    } this.withItems(t); }
    sort(t, e, i, n) { let s = this._getItemIndexFromPointerPosition(t, e, i), o = this._previousSwap; if (s === -1 || this._activeItems[s] === t)
        return null; let a = this._activeItems[s]; if (o.drag === a && o.overlaps && o.deltaX === n.x && o.deltaY === n.y)
        return null; let l = this.getItemIndex(t), c = t.getPlaceholderElement(), u = a.getRootElement(); s > l ? u.after(c) : u.before(c), rt(this._activeItems, l, s); let f = this._getRootNode().elementFromPoint(e, i); return o.deltaX = n.x, o.deltaY = n.y, o.drag = a, o.overlaps = u === f || u.contains(f), { previousIndex: l, currentIndex: s }; }
    enter(t, e, i, n) { let s = this._activeItems.indexOf(t); s > -1 && this._activeItems.splice(s, 1); let o = n == null || n < 0 ? this._getItemIndexFromPointerPosition(t, e, i) : n; o === -1 && (o = this._getClosestItemIndexToPointer(t, e, i)); let a = this._activeItems[o]; a && !this._dragDropRegistry.isDragging(a) ? (this._activeItems.splice(o, 0, t), a.getRootElement().before(t.getPlaceholderElement())) : (this._activeItems.push(t), this._element.appendChild(t.getPlaceholderElement())); }
    withItems(t) { this._activeItems = t.slice(); }
    withSortPredicate(t) { this._sortPredicate = t; }
    reset() { let t = this._element, e = this._previousSwap; for (let i = this._relatedNodes.length - 1; i > -1; i--) {
        let [n, s] = this._relatedNodes[i];
        n.parentNode === t && n.nextSibling !== s && (s === null ? t.appendChild(n) : s.parentNode === t && t.insertBefore(n, s));
    } this._relatedNodes = [], this._activeItems = [], e.drag = null, e.deltaX = e.deltaY = 0, e.overlaps = !1; }
    getActiveItemsSnapshot() { return this._activeItems; }
    getItemIndex(t) { return this._activeItems.indexOf(t); }
    getItemAtIndex(t) { return this._activeItems[t] || null; }
    updateOnScroll() { this._activeItems.forEach(t => { this._dragDropRegistry.isDragging(t) && t._sortFromLastPointerPosition(); }); }
    withElementContainer(t) { t !== this._element && (this._element = t, this._rootNode = void 0); }
    _getItemIndexFromPointerPosition(t, e, i) { let n = this._getRootNode().elementFromPoint(Math.floor(e), Math.floor(i)), s = n ? this._activeItems.findIndex(o => { let a = o.getRootElement(); return n === a || a.contains(n); }) : -1; return s === -1 || !this._sortPredicate(s, t) ? -1 : s; }
    _getRootNode() { return this._rootNode || (this._rootNode = V(this._element) || this._document), this._rootNode; }
    _getClosestItemIndexToPointer(t, e, i) { if (this._activeItems.length === 0)
        return -1; if (this._activeItems.length === 1)
        return 0; let n = 1 / 0, s = -1; for (let o = 0; o < this._activeItems.length; o++) {
        let a = this._activeItems[o];
        if (a !== t) {
            let { x: l, y: c } = a.getRootElement().getBoundingClientRect(), u = Math.hypot(e - l, i - c);
            u < n && (n = u, s = o);
        }
    } return s; }
}, qe = .05, st = .05, D = (function (r) { return r[r.NONE = 0] = "NONE", r[r.UP = 1] = "UP", r[r.DOWN = 2] = "DOWN", r; })(D || {}), g = (function (r) { return r[r.NONE = 0] = "NONE", r[r.LEFT = 1] = "LEFT", r[r.RIGHT = 2] = "RIGHT", r; })(g || {});
function ot(r, t) { return new ue(t, r.get(q), r.get(_e), r.get(K), r.get(ne)); }
var ue = class {
    _dragDropRegistry;
    _ngZone;
    _viewportRuler;
    element;
    disabled = !1;
    sortingDisabled = !1;
    lockAxis = null;
    autoScrollDisabled = !1;
    autoScrollStep = 2;
    hasAnchor = !1;
    enterPredicate = () => !0;
    sortPredicate = () => !0;
    beforeStarted = new _;
    entered = new _;
    exited = new _;
    dropped = new _;
    sorted = new _;
    receivingStarted = new _;
    receivingStopped = new _;
    data;
    _container;
    _isDragging = !1;
    _parentPositions;
    _sortStrategy;
    _domRect;
    _draggables = [];
    _siblings = [];
    _activeSiblings = new Set;
    _viewportScrollSubscription = L.EMPTY;
    _verticalScrollDirection = D.NONE;
    _horizontalScrollDirection = g.NONE;
    _scrollNode;
    _stopScrollTimers = new _;
    _cachedShadowRoot = null;
    _document;
    _scrollableElements = [];
    _initialScrollSnap;
    _direction = "ltr";
    constructor(t, e, i, n, s) { this._dragDropRegistry = e, this._ngZone = n, this._viewportRuler = s; let o = this.element = w(t); this._document = i, this.withOrientation("vertical").withElementContainer(o), e.registerDropContainer(this), this._parentPositions = new U(i); }
    dispose() { this._stopScrolling(), this._stopScrollTimers.complete(), this._viewportScrollSubscription.unsubscribe(), this.beforeStarted.complete(), this.entered.complete(), this.exited.complete(), this.dropped.complete(), this.sorted.complete(), this.receivingStarted.complete(), this.receivingStopped.complete(), this._activeSiblings.clear(), this._scrollNode = null, this._parentPositions.clear(), this._dragDropRegistry.removeDropContainer(this); }
    isDragging() { return this._isDragging; }
    start() { this._draggingStarted(), this._notifyReceivingSiblings(); }
    enter(t, e, i, n) { this._draggingStarted(), n == null && this.sortingDisabled && (n = this._draggables.indexOf(t)), this._sortStrategy.enter(t, e, i, n), this._cacheParentPositions(), this._notifyReceivingSiblings(), this.entered.next({ item: t, container: this, currentIndex: this.getItemIndex(t) }); }
    exit(t) { this._reset(), this.exited.next({ item: t, container: this }); }
    drop(t, e, i, n, s, o, a, l = {}) { this._reset(), this.dropped.next({ item: t, currentIndex: e, previousIndex: i, container: this, previousContainer: n, isPointerOverContainer: s, distance: o, dropPoint: a, event: l }); }
    withItems(t) { let e = this._draggables; return this._draggables = t, t.forEach(i => i._withDropContainer(this)), this.isDragging() && (e.filter(n => n.isDragging()).every(n => t.indexOf(n) === -1) ? this._reset() : this._sortStrategy.withItems(this._draggables)), this; }
    withDirection(t) { return this._direction = t, this._sortStrategy instanceof $ && (this._sortStrategy.direction = t), this; }
    connectedTo(t) { return this._siblings = t.slice(), this; }
    withOrientation(t) { if (t === "mixed")
        this._sortStrategy = new he(this._document, this._dragDropRegistry);
    else {
        let e = new $(this._dragDropRegistry);
        e.direction = this._direction, e.orientation = t, this._sortStrategy = e;
    } return this._sortStrategy.withElementContainer(this._container), this._sortStrategy.withSortPredicate((e, i) => this.sortPredicate(e, i, this)), this; }
    withScrollableParents(t) { let e = this._container; return this._scrollableElements = t.indexOf(e) === -1 ? [e, ...t] : t.slice(), this; }
    withElementContainer(t) { if (t === this._container)
        return this; let e = w(this.element), i = this._scrollableElements.indexOf(this._container), n = this._scrollableElements.indexOf(t); return i > -1 && this._scrollableElements.splice(i, 1), n > -1 && this._scrollableElements.splice(n, 1), this._sortStrategy && this._sortStrategy.withElementContainer(t), this._cachedShadowRoot = null, this._scrollableElements.unshift(t), this._container = t, this; }
    getScrollableParents() { return this._scrollableElements; }
    getItemIndex(t) { return this._isDragging ? this._sortStrategy.getItemIndex(t) : this._draggables.indexOf(t); }
    getItemAtIndex(t) { return this._isDragging ? this._sortStrategy.getItemAtIndex(t) : this._draggables[t] || null; }
    isReceiving() { return this._activeSiblings.size > 0; }
    _sortItem(t, e, i, n) { if (this.sortingDisabled || !this._domRect || !Be(this._domRect, qe, e, i))
        return; let s = this._sortStrategy.sort(t, e, i, n); s && this.sorted.next({ previousIndex: s.previousIndex, currentIndex: s.currentIndex, container: this, item: t }); }
    _startScrollingIfNecessary(t, e) { if (this.autoScrollDisabled)
        return; let i, n = D.NONE, s = g.NONE; if (this._parentPositions.positions.forEach((o, a) => { a === this._document || !o.clientRect || i || Be(o.clientRect, qe, t, e) && ([n, s] = ci(a, o.clientRect, this._direction, t, e), (n || s) && (i = a)); }), !n && !s) {
        let { width: o, height: a } = this._viewportRuler.getViewportSize(), l = { width: o, height: a, top: 0, right: o, bottom: a, left: 0 };
        n = at(l, e), s = lt(l, t), i = window;
    } i && (n !== this._verticalScrollDirection || s !== this._horizontalScrollDirection || i !== this._scrollNode) && (this._verticalScrollDirection = n, this._horizontalScrollDirection = s, this._scrollNode = i, (n || s) && i ? this._ngZone.runOutsideAngular(this._startScrollInterval) : this._stopScrolling()); }
    _stopScrolling() { this._stopScrollTimers.next(); }
    _draggingStarted() { let t = this._container.style; this.beforeStarted.next(), this._isDragging = !0, this._initialScrollSnap = t.msScrollSnapType || t.scrollSnapType || "", t.scrollSnapType = t.msScrollSnapType = "none", this._sortStrategy.start(this._draggables), this._cacheParentPositions(), this._viewportScrollSubscription.unsubscribe(), this._listenToScrollEvents(); }
    _cacheParentPositions() { this._parentPositions.cache(this._scrollableElements), this._domRect = this._parentPositions.positions.get(this._container).clientRect; }
    _reset() { this._isDragging = !1; let t = this._container.style; t.scrollSnapType = t.msScrollSnapType = this._initialScrollSnap, this._siblings.forEach(e => e._stopReceiving(this)), this._sortStrategy.reset(), this._stopScrolling(), this._viewportScrollSubscription.unsubscribe(), this._parentPositions.clear(); }
    _startScrollInterval = () => { this._stopScrolling(), $t(0, Kt).pipe(G(this._stopScrollTimers)).subscribe(() => { let t = this._scrollNode, e = this.autoScrollStep; this._verticalScrollDirection === D.UP ? t.scrollBy(0, -e) : this._verticalScrollDirection === D.DOWN && t.scrollBy(0, e), this._horizontalScrollDirection === g.LEFT ? t.scrollBy(-e, 0) : this._horizontalScrollDirection === g.RIGHT && t.scrollBy(e, 0); }); };
    _isOverContainer(t, e) { return this._domRect != null && le(this._domRect, t, e); }
    _getSiblingContainerFromPosition(t, e, i) { return this._siblings.find(n => n._canReceive(t, e, i)); }
    _canReceive(t, e, i) { if (!this._domRect || !le(this._domRect, e, i) || !this.enterPredicate(t, this))
        return !1; let n = this._getShadowRoot().elementFromPoint(e, i); return n ? n === this._container || this._container.contains(n) : !1; }
    _startReceiving(t, e) { let i = this._activeSiblings; !i.has(t) && e.every(n => this.enterPredicate(n, this) || this._draggables.indexOf(n) > -1) && (i.add(t), this._cacheParentPositions(), this._listenToScrollEvents(), this.receivingStarted.next({ initiator: t, receiver: this, items: e })); }
    _stopReceiving(t) { this._activeSiblings.delete(t), this._viewportScrollSubscription.unsubscribe(), this.receivingStopped.next({ initiator: t, receiver: this }); }
    _listenToScrollEvents() { this._viewportScrollSubscription = this._dragDropRegistry.scrolled(this._getShadowRoot()).subscribe(t => { if (this.isDragging()) {
        let e = this._parentPositions.handleScroll(t);
        e && this._sortStrategy.updateOnScroll(e.top, e.left);
    }
    else
        this.isReceiving() && this._cacheParentPositions(); }); }
    _getShadowRoot() { if (!this._cachedShadowRoot) {
        let t = V(this._container);
        this._cachedShadowRoot = t || this._document;
    } return this._cachedShadowRoot; }
    _notifyReceivingSiblings() { let t = this._sortStrategy.getActiveItemsSnapshot().filter(e => e.isDragging()); this._siblings.forEach(e => e._startReceiving(this, t)); }
};
function at(r, t) { let { top: e, bottom: i, height: n } = r, s = n * st; return t >= e - s && t <= e + s ? D.UP : t >= i - s && t <= i + s ? D.DOWN : D.NONE; }
function lt(r, t) { let { left: e, right: i, width: n } = r, s = n * st; return t >= e - s && t <= e + s ? g.LEFT : t >= i - s && t <= i + s ? g.RIGHT : g.NONE; }
function ci(r, t, e, i, n) { let s = at(t, n), o = lt(t, i), a = D.NONE, l = g.NONE; if (s) {
    let c = r.scrollTop;
    s === D.UP ? c > 0 && (a = D.UP) : r.scrollHeight - c > r.clientHeight && (a = D.DOWN);
} if (o) {
    let c = r.scrollLeft;
    e === "rtl" ? o === g.RIGHT ? c < 0 && (l = g.RIGHT) : r.scrollWidth + c > r.clientWidth && (l = g.LEFT) : o === g.LEFT ? c > 0 && (l = g.LEFT) : r.scrollWidth - c > r.clientWidth && (l = g.RIGHT);
} return [a, l]; }
var di = (() => { class r {
    _injector = d(ge);
    constructor() { }
    createDrag(e, i) { return nt(this._injector, e, i); }
    createDropList(e) { return ot(this._injector, e); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275prov = h.\u0275\u0275defineInjectable({ token: r, factory: r.\u0275fac, providedIn: "root" });
} return r; })(), F = new P("CDK_DRAG_PARENT");
var ct = new P("CdkDragHandle"), Wn = (() => { class r {
    element = d(fe);
    _parentDrag = d(F, { optional: !0, skipSelf: !0 });
    _dragDropRegistry = d(q);
    _stateChanges = new _;
    get disabled() { return this._disabled; }
    set disabled(e) { this._disabled = e, this._stateChanges.next(this); }
    _disabled = !1;
    constructor() { this._parentDrag?._addHandle(this); }
    ngAfterViewInit() { if (!this._parentDrag) {
        let e = this.element.nativeElement.parentElement;
        for (; e;) {
            let i = this._dragDropRegistry.getDragDirectiveForNode(e);
            if (i) {
                this._parentDrag = i, i._addHandle(this);
                break;
            }
            e = e.parentElement;
        }
    } }
    ngOnDestroy() { this._parentDrag?._removeHandle(this), this._stateChanges.complete(); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDragHandle", ""]], hostAttrs: [1, "cdk-drag-handle"], inputs: { disabled: [2, "cdkDragHandleDisabled", "disabled", y] }, features: [h.\u0275\u0275ProvidersFeature([{ provide: ct, useExisting: r }])] });
} return r; })(), dt = new P("CDK_DRAG_CONFIG"), ht = new P("CdkDropList"), Gn = (() => { class r {
    element = d(fe);
    dropContainer = d(ht, { optional: !0, skipSelf: !0 });
    _ngZone = d(K);
    _viewContainerRef = d(Gt);
    _dir = d(T, { optional: !0 });
    _changeDetectorRef = d(Qe);
    _selfHandle = d(ct, { optional: !0, self: !0 });
    _parentDrag = d(F, { optional: !0, skipSelf: !0 });
    _dragDropRegistry = d(q);
    _destroyed = new _;
    _handles = new qt([]);
    _previewTemplate = null;
    _placeholderTemplate = null;
    _dragRef;
    data;
    lockAxis = null;
    rootElementSelector;
    boundaryElement;
    dragStartDelay;
    freeDragPosition;
    get disabled() { return this._disabled || !!(this.dropContainer && this.dropContainer.disabled); }
    set disabled(e) { this._disabled = e, this._dragRef.disabled = this._disabled; }
    _disabled = !1;
    constrainPosition;
    previewClass;
    previewContainer;
    scale = 1;
    started = new b;
    released = new b;
    ended = new b;
    entered = new b;
    exited = new b;
    dropped = new b;
    moved = new et(e => { let i = this._dragRef.moved.pipe(Yt(n => ({ source: this, pointerPosition: n.pointerPosition, event: n.event, delta: n.delta, distance: n.distance }))).subscribe(e); return () => { i.unsubscribe(); }; });
    _injector = d(ge);
    constructor() { let e = this.dropContainer, i = d(dt, { optional: !0 }); this._dragRef = nt(this._injector, this.element, { dragStartThreshold: i && i.dragStartThreshold != null ? i.dragStartThreshold : 5, pointerDirectionChangeThreshold: i && i.pointerDirectionChangeThreshold != null ? i.pointerDirectionChangeThreshold : 5, zIndex: i?.zIndex }), this._dragRef.data = this, this._dragDropRegistry.registerDirectiveNode(this.element.nativeElement, this), i && this._assignDefaults(i), e && (e.addItem(this), e._dropListRef.beforeStarted.pipe(G(this._destroyed)).subscribe(() => { this._dragRef.scale = this.scale; })), this._syncInputs(this._dragRef), this._handleEvents(this._dragRef); }
    getPlaceholderElement() { return this._dragRef.getPlaceholderElement(); }
    getRootElement() { return this._dragRef.getRootElement(); }
    reset() { this._dragRef.reset(); }
    resetToBoundary() { this._dragRef.resetToBoundary(); }
    getFreeDragPosition() { return this._dragRef.getFreeDragPosition(); }
    setFreeDragPosition(e) { this._dragRef.setFreeDragPosition(e); }
    ngAfterViewInit() { Ut(() => { this._updateRootElement(), this._setupHandlesListener(), this._dragRef.scale = this.scale, this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition); }, { injector: this._injector }); }
    ngOnChanges(e) { let i = e.rootElementSelector, n = e.freeDragPosition; i && !i.firstChange && this._updateRootElement(), this._dragRef.scale = this.scale, n && !n.firstChange && this.freeDragPosition && this._dragRef.setFreeDragPosition(this.freeDragPosition); }
    ngOnDestroy() { this.dropContainer && this.dropContainer.removeItem(this), this._dragDropRegistry.removeDirectiveNode(this.element.nativeElement), this._ngZone.runOutsideAngular(() => { this._handles.complete(), this._destroyed.next(), this._destroyed.complete(), this._dragRef.dispose(); }); }
    _addHandle(e) { let i = this._handles.getValue(); i.push(e), this._handles.next(i); }
    _removeHandle(e) { let i = this._handles.getValue(), n = i.indexOf(e); n > -1 && (i.splice(n, 1), this._handles.next(i)); }
    _setPreviewTemplate(e) { this._previewTemplate = e; }
    _resetPreviewTemplate(e) { e === this._previewTemplate && (this._previewTemplate = null); }
    _setPlaceholderTemplate(e) { this._placeholderTemplate = e; }
    _resetPlaceholderTemplate(e) { e === this._placeholderTemplate && (this._placeholderTemplate = null); }
    _updateRootElement() { let e = this.element.nativeElement, i = e; this.rootElementSelector && (i = e.closest !== void 0 ? e.closest(this.rootElementSelector) : e.parentElement?.closest(this.rootElementSelector)), this._dragRef.withRootElement(i || e); }
    _getBoundaryElement() { let e = this.boundaryElement; return e ? typeof e == "string" ? this.element.nativeElement.closest(e) : w(e) : null; }
    _syncInputs(e) { e.beforeStarted.subscribe(() => { if (!e.isDragging()) {
        let i = this._dir, n = this.dragStartDelay, s = this._placeholderTemplate ? { template: this._placeholderTemplate.templateRef, context: this._placeholderTemplate.data, viewContainer: this._viewContainerRef } : null, o = this._previewTemplate ? { template: this._previewTemplate.templateRef, context: this._previewTemplate.data, matchSize: this._previewTemplate.matchSize, viewContainer: this._viewContainerRef } : null;
        e.disabled = this.disabled, e.lockAxis = this.lockAxis, e.scale = this.scale, e.dragStartDelay = typeof n == "object" && n ? n : B(n), e.constrainPosition = this.constrainPosition, e.previewClass = this.previewClass, e.withBoundaryElement(this._getBoundaryElement()).withPlaceholderTemplate(s).withPreviewTemplate(o).withPreviewContainer(this.previewContainer || "global"), i && e.withDirection(i.value);
    } }), e.beforeStarted.pipe(Xt(1)).subscribe(() => { if (this._parentDrag) {
        e.withParent(this._parentDrag._dragRef);
        return;
    } let i = this.element.nativeElement.parentElement; for (; i;) {
        let n = this._dragDropRegistry.getDragDirectiveForNode(i);
        if (n) {
            e.withParent(n._dragRef);
            break;
        }
        i = i.parentElement;
    } }); }
    _handleEvents(e) { e.started.subscribe(i => { this.started.emit({ source: this, event: i.event }), this._changeDetectorRef.markForCheck(); }), e.released.subscribe(i => { this.released.emit({ source: this, event: i.event }); }), e.ended.subscribe(i => { this.ended.emit({ source: this, distance: i.distance, dropPoint: i.dropPoint, event: i.event }), this._changeDetectorRef.markForCheck(); }), e.entered.subscribe(i => { this.entered.emit({ container: i.container.data, item: this, currentIndex: i.currentIndex }); }), e.exited.subscribe(i => { this.exited.emit({ container: i.container.data, item: this }); }), e.dropped.subscribe(i => { this.dropped.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, previousContainer: i.previousContainer.data, container: i.container.data, isPointerOverContainer: i.isPointerOverContainer, item: this, distance: i.distance, dropPoint: i.dropPoint, event: i.event }); }); }
    _assignDefaults(e) { let { lockAxis: i, dragStartDelay: n, constrainPosition: s, previewClass: o, boundaryElement: a, draggingDisabled: l, rootElementSelector: c, previewContainer: u } = e; this.disabled = l ?? !1, this.dragStartDelay = n || 0, this.lockAxis = i || null, s && (this.constrainPosition = s), o && (this.previewClass = o), a && (this.boundaryElement = a), c && (this.rootElementSelector = c), u && (this.previewContainer = u); }
    _setupHandlesListener() { this._handles.pipe(Qt(e => { let i = e.map(n => n.element); this._selfHandle && this.rootElementSelector && i.push(this.element), this._dragRef.withHandles(i); }), Jt(e => me(...e.map(i => i._stateChanges.pipe(tt(i))))), G(this._destroyed)).subscribe(e => { let i = this._dragRef, n = e.element.nativeElement; e.disabled ? i.disableHandle(n) : i.enableHandle(n); }); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDrag", ""]], hostAttrs: [1, "cdk-drag"], hostVars: 4, hostBindings: function (i, n) { i & 2 && h.\u0275\u0275classProp("cdk-drag-disabled", n.disabled)("cdk-drag-dragging", n._dragRef.isDragging()); }, inputs: { data: [0, "cdkDragData", "data"], lockAxis: [0, "cdkDragLockAxis", "lockAxis"], rootElementSelector: [0, "cdkDragRootElement", "rootElementSelector"], boundaryElement: [0, "cdkDragBoundary", "boundaryElement"], dragStartDelay: [0, "cdkDragStartDelay", "dragStartDelay"], freeDragPosition: [0, "cdkDragFreeDragPosition", "freeDragPosition"], disabled: [2, "cdkDragDisabled", "disabled", y], constrainPosition: [0, "cdkDragConstrainPosition", "constrainPosition"], previewClass: [0, "cdkDragPreviewClass", "previewClass"], previewContainer: [0, "cdkDragPreviewContainer", "previewContainer"], scale: [2, "cdkDragScale", "scale", Zt] }, outputs: { started: "cdkDragStarted", released: "cdkDragReleased", ended: "cdkDragEnded", entered: "cdkDragEntered", exited: "cdkDragExited", dropped: "cdkDragDropped", moved: "cdkDragMoved" }, exportAs: ["cdkDrag"], features: [h.\u0275\u0275ProvidersFeature([{ provide: F, useExisting: r }]), h.\u0275\u0275NgOnChangesFeature] });
} return r; })(), pe = new P("CdkDropListGroup"), Un = (() => { class r {
    _items = new Set;
    disabled = !1;
    ngOnDestroy() { this._items.clear(); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDropListGroup", ""]], inputs: { disabled: [2, "cdkDropListGroupDisabled", "disabled", y] }, exportAs: ["cdkDropListGroup"], features: [h.\u0275\u0275ProvidersFeature([{ provide: pe, useExisting: r }])] });
} return r; })(), Zn = (() => { class r {
    element = d(fe);
    _changeDetectorRef = d(Qe);
    _scrollDispatcher = d(ie);
    _dir = d(T, { optional: !0 });
    _group = d(pe, { optional: !0, skipSelf: !0 });
    _latestSortedRefs;
    _destroyed = new _;
    _scrollableParentsResolved = !1;
    static _dropLists = [];
    _dropListRef;
    connectedTo = [];
    data;
    orientation = "vertical";
    id = d(W).getId("cdk-drop-list-");
    lockAxis = null;
    get disabled() { return this._disabled || !!this._group && this._group.disabled; }
    set disabled(e) { this._dropListRef.disabled = this._disabled = e; }
    _disabled = !1;
    sortingDisabled = !1;
    enterPredicate = () => !0;
    sortPredicate = () => !0;
    autoScrollDisabled = !1;
    autoScrollStep;
    elementContainerSelector = null;
    hasAnchor = !1;
    dropped = new b;
    entered = new b;
    exited = new b;
    sorted = new b;
    _unsortedItems = new Set;
    constructor() { let e = d(dt, { optional: !0 }), i = d(ge); this._dropListRef = ot(i, this.element), this._dropListRef.data = this, e && this._assignDefaults(e), this._dropListRef.enterPredicate = (n, s) => this.enterPredicate(n.data, s.data), this._dropListRef.sortPredicate = (n, s, o) => this.sortPredicate(n, s.data, o.data), this._setupInputSyncSubscription(this._dropListRef), this._handleEvents(this._dropListRef), r._dropLists.push(this), this._group && this._group._items.add(this); }
    addItem(e) { this._unsortedItems.add(e), e._dragRef._withDropContainer(this._dropListRef), this._dropListRef.isDragging() && this._syncItemsWithRef(this.getSortedItems().map(i => i._dragRef)); }
    removeItem(e) { if (this._unsortedItems.delete(e), this._latestSortedRefs) {
        let i = this._latestSortedRefs.indexOf(e._dragRef);
        i > -1 && (this._latestSortedRefs.splice(i, 1), this._syncItemsWithRef(this._latestSortedRefs));
    } }
    getSortedItems() { return Array.from(this._unsortedItems).sort((e, i) => e._dragRef.getVisibleElement().compareDocumentPosition(i._dragRef.getVisibleElement()) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1); }
    ngOnDestroy() { let e = r._dropLists.indexOf(this); e > -1 && r._dropLists.splice(e, 1), this._group && this._group._items.delete(this), this._latestSortedRefs = void 0, this._unsortedItems.clear(), this._dropListRef.dispose(), this._destroyed.next(), this._destroyed.complete(); }
    _setupInputSyncSubscription(e) { this._dir && this._dir.change.pipe(tt(this._dir.value), G(this._destroyed)).subscribe(i => e.withDirection(i)), e.beforeStarted.subscribe(() => { let i = Ae(this.connectedTo).map(n => { if (typeof n == "string") {
        let s = r._dropLists.find(o => o.id === n);
        return s;
    } return n; }); if (this._group && this._group._items.forEach(n => { i.indexOf(n) === -1 && i.push(n); }), !this._scrollableParentsResolved) {
        let n = this._scrollDispatcher.getAncestorScrollContainers(this.element).map(s => s.getElementRef().nativeElement);
        this._dropListRef.withScrollableParents(n), this._scrollableParentsResolved = !0;
    } if (this.elementContainerSelector) {
        let n = this.element.nativeElement.querySelector(this.elementContainerSelector);
        e.withElementContainer(n);
    } e.disabled = this.disabled, e.lockAxis = this.lockAxis, e.sortingDisabled = this.sortingDisabled, e.autoScrollDisabled = this.autoScrollDisabled, e.autoScrollStep = B(this.autoScrollStep, 2), e.hasAnchor = this.hasAnchor, e.connectedTo(i.filter(n => n && n !== this).map(n => n._dropListRef)).withOrientation(this.orientation); }); }
    _handleEvents(e) { e.beforeStarted.subscribe(() => { this._syncItemsWithRef(this.getSortedItems().map(i => i._dragRef)), this._changeDetectorRef.markForCheck(); }), e.entered.subscribe(i => { this.entered.emit({ container: this, item: i.item.data, currentIndex: i.currentIndex }); }), e.exited.subscribe(i => { this.exited.emit({ container: this, item: i.item.data }), this._changeDetectorRef.markForCheck(); }), e.sorted.subscribe(i => { this.sorted.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, container: this, item: i.item.data }); }), e.dropped.subscribe(i => { this.dropped.emit({ previousIndex: i.previousIndex, currentIndex: i.currentIndex, previousContainer: i.previousContainer.data, container: i.container.data, item: i.item.data, isPointerOverContainer: i.isPointerOverContainer, distance: i.distance, dropPoint: i.dropPoint, event: i.event }), this._changeDetectorRef.markForCheck(); }), me(e.receivingStarted, e.receivingStopped).subscribe(() => this._changeDetectorRef.markForCheck()); }
    _assignDefaults(e) { let { lockAxis: i, draggingDisabled: n, sortingDisabled: s, listAutoScrollDisabled: o, listOrientation: a } = e; this.disabled = n ?? !1, this.sortingDisabled = s ?? !1, this.autoScrollDisabled = o ?? !1, this.orientation = a || "vertical", this.lockAxis = i || null; }
    _syncItemsWithRef(e) { this._latestSortedRefs = e, this._dropListRef.withItems(e); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["", "cdkDropList", ""], ["cdk-drop-list"]], hostAttrs: [1, "cdk-drop-list"], hostVars: 7, hostBindings: function (i, n) { i & 2 && (h.\u0275\u0275attribute("id", n.id), h.\u0275\u0275classProp("cdk-drop-list-disabled", n.disabled)("cdk-drop-list-dragging", n._dropListRef.isDragging())("cdk-drop-list-receiving", n._dropListRef.isReceiving())); }, inputs: { connectedTo: [0, "cdkDropListConnectedTo", "connectedTo"], data: [0, "cdkDropListData", "data"], orientation: [0, "cdkDropListOrientation", "orientation"], id: "id", lockAxis: [0, "cdkDropListLockAxis", "lockAxis"], disabled: [2, "cdkDropListDisabled", "disabled", y], sortingDisabled: [2, "cdkDropListSortingDisabled", "sortingDisabled", y], enterPredicate: [0, "cdkDropListEnterPredicate", "enterPredicate"], sortPredicate: [0, "cdkDropListSortPredicate", "sortPredicate"], autoScrollDisabled: [2, "cdkDropListAutoScrollDisabled", "autoScrollDisabled", y], autoScrollStep: [0, "cdkDropListAutoScrollStep", "autoScrollStep"], elementContainerSelector: [0, "cdkDropListElementContainer", "elementContainerSelector"], hasAnchor: [2, "cdkDropListHasAnchor", "hasAnchor", y] }, outputs: { dropped: "cdkDropListDropped", entered: "cdkDropListEntered", exited: "cdkDropListExited", sorted: "cdkDropListSorted" }, exportAs: ["cdkDropList"], features: [h.\u0275\u0275ProvidersFeature([{ provide: pe, useValue: void 0 }, { provide: ht, useExisting: r }])] });
} return r; })(), hi = new P("CdkDragPreview"), $n = (() => { class r {
    templateRef = d(Je);
    _drag = d(F, { optional: !0 });
    data;
    matchSize = !1;
    constructor() { this._drag?._setPreviewTemplate(this); }
    ngOnDestroy() { this._drag?._resetPreviewTemplate(this); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["ng-template", "cdkDragPreview", ""]], inputs: { data: "data", matchSize: [2, "matchSize", "matchSize", y] }, features: [h.\u0275\u0275ProvidersFeature([{ provide: hi, useExisting: r }])] });
} return r; })(), ui = new P("CdkDragPlaceholder"), Kn = (() => { class r {
    templateRef = d(Je);
    _drag = d(F, { optional: !0 });
    data;
    constructor() { this._drag?._setPlaceholderTemplate(this); }
    ngOnDestroy() { this._drag?._resetPlaceholderTemplate(this); }
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275dir = h.\u0275\u0275defineDirective({ type: r, selectors: [["ng-template", "cdkDragPlaceholder", ""]], inputs: { data: "data" }, features: [h.\u0275\u0275ProvidersFeature([{ provide: ui, useExisting: r }])] });
} return r; })();
var qn = (() => { class r {
    static \u0275fac = function (i) { return new (i || r); };
    static \u0275mod = h.\u0275\u0275defineNgModule({ type: r });
    static \u0275inj = h.\u0275\u0275defineInjector({ providers: [di], imports: [Ne] });
} return r; })();
export { dt as CDK_DRAG_CONFIG, ct as CDK_DRAG_HANDLE, F as CDK_DRAG_PARENT, ui as CDK_DRAG_PLACEHOLDER, hi as CDK_DRAG_PREVIEW, ht as CDK_DROP_LIST, pe as CDK_DROP_LIST_GROUP, Gn as CdkDrag, Wn as CdkDragHandle, Kn as CdkDragPlaceholder, $n as CdkDragPreview, Zn as CdkDropList, Un as CdkDropListGroup, di as DragDrop, qn as DragDropModule, q as DragDropRegistry, de as DragRef, ue as DropListRef, jn as copyArrayItem, nt as createDragRef, ot as createDropListRef, rt as moveItemInArray, Hn as transferArrayItem, Vt as \u0275\u0275CdkScrollable };
