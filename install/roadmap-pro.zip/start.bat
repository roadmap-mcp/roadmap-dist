@echo off
setlocal
cd /d "%~dp0"
REM Python 3.13 or newer: the py launcher's 3.14 / 3.13 first, then python on PATH.
set PY=
for %%c in ("py -3.14" "py -3.13" "python") do if not defined PY (
  %%~c -c "import sys; sys.exit(sys.version_info < (3, 13))" >nul 2>nul && set "PY=%%~c"
)
if not defined PY (echo Python 3.13 or newer is required: install it from python.org. && exit /b 1)
REM A .venv left by an older Python (an earlier failed run) is set up again.
if exist .venv\Scripts\python.exe (
  .venv\Scripts\python -c "import sys; sys.exit(sys.version_info < (3, 13))" >nul 2>nul || rmdir /s /q .venv
)
if not exist .venv (
  echo Creating virtual environment with %PY%...
  %PY% -m venv .venv || goto :err
)
REM Install on the first run, and again when this is a different build than the
REM one installed (a new snapshot unzipped over the old one): .venv\.installed
REM holds the BUILD it was installed from. The bundled wheels keep one version
REM number across snapshots, so an update reinstalls them by force. Delete
REM .venv\.installed to force a re-setup. Plugins added from the in-app registry
REM stay: only this bundle's own are reinstalled.
set "BUILD="
set /p BUILD=<BUILD
set "STAMP="
if exist .venv\.installed set /p STAMP=<.venv\.installed
if "%STAMP%"=="%BUILD%" goto :run
if exist .venv\.installed (echo Updating Roadmap to %BUILD%...) else (echo Installing Roadmap ^(first run^)...)
.venv\Scripts\python -m pip install --upgrade pip >nul
.venv\Scripts\python -m pip install --find-links wheels roadmap-framework roadmap-plugin-ai roadmap-plugin-atlassian roadmap-plugin-bitbucket roadmap-plugin-gitrepos roadmap-plugin-jobs roadmap-plugin-knowledgebase roadmap-plugin-knowledgebase-flows roadmap-plugin-mcp roadmap-plugin-scheduler roadmap-plugin-settings roadmap-plugin-users || goto :err
if exist .venv\.installed .venv\Scripts\python -m pip install --force-reinstall --no-deps --no-index --find-links wheels roadmap-framework roadmap-plugin-ai roadmap-plugin-atlassian roadmap-plugin-bitbucket roadmap-plugin-gitrepos roadmap-plugin-jobs roadmap-plugin-knowledgebase roadmap-plugin-knowledgebase-flows roadmap-plugin-mcp roadmap-plugin-scheduler roadmap-plugin-settings roadmap-plugin-users || goto :err
.venv\Scripts\python -m pip install -r backend\requirements.txt || goto :err
>.venv\.installed echo %BUILD%
:run
REM ROADMAP_HOST=0.0.0.0 serves other machines too (a container, the LAN).
if "%ROADMAP_HOST%"=="" set ROADMAP_HOST=127.0.0.1
if "%ROADMAP_PLUGIN_REGISTRY_URL%"=="" set ROADMAP_PLUGIN_REGISTRY_URL=https://raw.githubusercontent.com/roadmap-mcp/roadmap-dist/main/registry/pro.json
echo.
echo Starting on http://localhost:8090  (press Ctrl+C to stop)
cd backend
..\.venv\Scripts\python -m uvicorn app.main:app --host %ROADMAP_HOST% --port 8090
goto :eof
:err
echo Install failed.
exit /b 1
