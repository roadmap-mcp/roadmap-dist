# Roadmap Pro

Self-contained build. Requires **Python 3.13+** on your PATH.

## Run

- **Windows:** double-click `start.bat` (or run it from a terminal).
- **macOS / Linux:** `bash start.sh`

The first run creates a local `.venv`, installs the bundled plugin wheels
(`wheels/`) plus their dependencies from PyPI, then serves the app at
<http://localhost:8090>. Subsequent runs reuse `.venv` and start immediately.

## Update

Stop it, unzip the new build over this folder, and start it again. The start
script sees a different `BUILD` than the one installed and reinstalls the
bundled wheels; your `config.yaml`, workspaces and data are kept.

## Notes

- Contexts and `config.yaml` are created next to `ROADMAP_CONFIG_PATH`; if unset
  they default under `backend/`. Set `ROADMAP_KEY` to auto-unlock encrypted secrets.
- It listens on 127.0.0.1 only. Set `ROADMAP_HOST=0.0.0.0` to reach it from other
  machines (or from outside a container).
- Server administration → **Plugins** lists the installed plugins and installs extras
  (such as Trello) from the registry.
- Version: 0.2.0-SNAPSHOT
