#!/usr/bin/env bash
set -e
cd "$(dirname "$0")"
# Python 3.13 or newer: python3.14 / python3.13 first (on Ubuntu, python3 stays the
# system's 3.12 when 3.13 is installed beside it), then python3.
new_enough() { "$1" -c 'import sys; sys.exit(sys.version_info < (3, 13))' 2>/dev/null; }
PY=""
for c in python3.14 python3.13 python3; do
  if command -v "$c" >/dev/null && new_enough "$c"; then PY="$c"; break; fi
done
[ -n "$PY" ] || { echo "Python 3.13 or newer is required (python3.13 or python3 on PATH)."; exit 1; }
# A .venv left by an older Python (an earlier failed run) is set up again.
[ ! -x .venv/bin/python ] || new_enough .venv/bin/python || rm -rf .venv
[ -d .venv ] || { echo "Creating virtual environment with $PY..."; "$PY" -m venv .venv; }
# Install only on first run. Delete .venv/.installed to force a re-setup. This
# lets you add/remove plugins (e.g. from the in-app registry) without a restart
# undoing them.
if [ ! -f .venv/.installed ]; then
  .venv/bin/python -m pip install --upgrade pip >/dev/null
  .venv/bin/python -m pip install --find-links wheels roadmap-framework roadmap-plugin-ai roadmap-plugin-atlassian roadmap-plugin-bitbucket roadmap-plugin-context roadmap-plugin-folderpicker roadmap-plugin-jira roadmap-plugin-jobs roadmap-plugin-knowledgebase roadmap-plugin-knowledgebase-flows roadmap-plugin-scheduler roadmap-plugin-settings
  .venv/bin/python -m pip install -r backend/requirements.txt
  touch .venv/.installed
fi
echo "Starting on http://localhost:8090  (press Ctrl+C to stop)"
cd backend
export ROADMAP_PLUGIN_REGISTRY_URL="${ROADMAP_PLUGIN_REGISTRY_URL:-https://raw.githubusercontent.com/roadmap-mcp/roadmap-dist/main/registry/pro.json}"
# ROADMAP_HOST=0.0.0.0 serves other machines too (a container, the LAN).
../.venv/bin/python -m uvicorn app.main:app --host "${ROADMAP_HOST:-127.0.0.1}" --port 8090
